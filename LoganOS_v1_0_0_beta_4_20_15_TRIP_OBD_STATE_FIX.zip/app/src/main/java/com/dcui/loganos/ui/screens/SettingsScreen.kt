package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import android.content.ClipData
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.HeadUnitUiMode
import com.dcui.loganos.model.DefaultMediaApp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.VehicleProfileSupport
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.MenuTheme
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.obd.FUEL_LEVEL_DISCOVERY_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_BEFORE_ENGINE_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_BEFORE_KOEO_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_AFTER_KOEO_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_AFTER_ENGINE_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_DRIVE_TEST_NAME
import com.dcui.loganos.obd.FUEL_REFILL_FINAL_KOEO_TEST_NAME
import com.dcui.loganos.obd.FUEL_CANDIDATE_CONTROL_TEST_NAME
import com.dcui.loganos.obd.CONTROL_DISCOVERY_TEST_NAME
import com.dcui.loganos.obd.CONTROL_HANDBRAKE_TEST_NAME
import com.dcui.loganos.obd.CONTROL_CLUTCH_TEST_NAME
import com.dcui.loganos.obd.CONTROL_BRAKE_TEST_NAME
import com.dcui.loganos.obd.CONTROL_GEAR_STATIC_TEST_NAME
import com.dcui.loganos.obd.CONTROL_GEAR_DRIVE_TEST_NAME
import com.dcui.loganos.obd.TRIP_CONTEXT_IDLE_TEST_NAME
import com.dcui.loganos.obd.TRIP_CONTEXT_DRIVE_TEST_NAME
import com.dcui.loganos.obd.isTripContextDeveloperTest
import com.dcui.loganos.obd.KWP_026_DYNAMIC_TEST_NAME
import com.dcui.loganos.obd.KWP_026_KOEO_TEST_NAME
import com.dcui.loganos.obd.KWP_026_ENGINE_STATIC_TEST_NAME
import com.dcui.loganos.obd.KWP_026_DRIVE_TEST_NAME
import com.dcui.loganos.obd.KWP_026_POST_KOEO_TEST_NAME
import com.dcui.loganos.obd.KWP_026_WIDE_KOEO_TEST_NAME
import com.dcui.loganos.obd.KWP_026_WIDE_IDLE_TEST_NAME
import com.dcui.loganos.obd.KWP_026_WIDE_RPM_TEST_NAME
import com.dcui.loganos.obd.KWP_026_WIDE_DRIVE_TEST_NAME
import com.dcui.loganos.obd.KWP_026_WIDE_POST_TEST_NAME
import com.dcui.loganos.obd.KWP_026_COMBINE_RESULTS_NAME
import com.dcui.loganos.obd.isKwp026DeveloperTest
import com.dcui.loganos.obd.isActiveDeveloperTestName
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.SettingsCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.cockpit.DigitalV2SettingsPanel
import com.dcui.loganos.ui.theme.LoganPalette
import com.dcui.loganos.update.InstallLaunchResult
import com.dcui.loganos.update.SecureUpdateManager
import com.dcui.loganos.update.UpdateUiState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SettingsCategory(val title: String, val desc: String) {
    Language("Dil", "Türkçe / English"),
    AppearanceCockpit("Görünüm & Kokpit", "Tema, vurgu rengi, gösterge stili"),
    SetupDevice("Kurulum ve Cihaz", "Telefon/Double modu ve ilk kurulum"),
    DriveFuel("Sürüş & Yakıt", "Yakıt fiyatı, kalibrasyon, tüketim"),
    VehicleMaintenance("Araç & Bakım", "Profil, kilometre, bakım aralıkları"),
    Connection("Bağlantı", "Bluetooth ve OBD adaptörü"),
    TripRecords("Sürüş ve Kayıtlar", "Smart Trip, geçmiş, dışa aktarma"),
    Developer("Geliştirici", "Testler, ham log, debug"),
    Support("Destek ve Geri Bildirim", "Sorun, öneri ve teknik kayıt gönder"),
    Updates("Güncellemeler", "Güvenli sürüm kontrolü ve kurulum"),
    About("Hakkında", "Sürüm, lisans, proje bilgisi")
}

private fun categoryTitle(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.title
    return when (category) {
        SettingsCategory.Language -> "Language"
        SettingsCategory.AppearanceCockpit -> "Appearance & Cockpit"
        SettingsCategory.SetupDevice -> "Setup & Device"
        SettingsCategory.DriveFuel -> "Trip & Fuel"
        SettingsCategory.VehicleMaintenance -> "Vehicle & Maintenance"
        SettingsCategory.Connection -> "Connection"
        SettingsCategory.TripRecords -> "Trips & Records"
        SettingsCategory.Developer -> "Developer"
        SettingsCategory.Support -> "Support & Feedback"
        SettingsCategory.Updates -> "Updates"
        SettingsCategory.About -> "About"
    }
}

private fun categoryDesc(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.desc
    return when (category) {
        SettingsCategory.Language -> "Turkish / English"
        SettingsCategory.AppearanceCockpit -> "Theme, accent color, gauge style"
        SettingsCategory.SetupDevice -> "Phone/Head Unit mode and initial setup"
        SettingsCategory.DriveFuel -> "Fuel price, calibration, consumption"
        SettingsCategory.VehicleMaintenance -> "Profile, odometer, service intervals"
        SettingsCategory.Connection -> "Bluetooth and OBD adapter"
        SettingsCategory.TripRecords -> "Smart Trip, history, export"
        SettingsCategory.Developer -> "Tests, raw log, debug"
        SettingsCategory.Support -> "Send issues, suggestions and technical records"
        SettingsCategory.Updates -> "Secure version checks and installation"
        SettingsCategory.About -> "Version, license, project info"
    }
}

private fun tx(language: AppLanguage, tr: String, en: String): String =
    if (language == AppLanguage.English) en else tr

private enum class TripRecordsSubPage { Main, DataManagement }
private enum class DeveloperSubPage { Main, Tests, TechnicalHistory, FuelRefill, ControlDiscovery, Dynamic026, Dynamic026Wide }

private sealed class SettingsDialog {
    data class Options(val title: String, val options: List<String>, val onSelect: (String) -> Unit) : SettingsDialog()
    data class TextInput(val title: String, val initial: String, val hint: String, val onSave: (String) -> Unit) : SettingsDialog()
    data class Calibration(
        val sessionActive: Boolean,
        val currentFactor: Double,
        val enabled: Boolean,
        val startTimeMs: Long,
        val startOdometerKm: Int,
        val autoDistanceKm: Double?,
        val autoAppLiters: Double?,
        val initialDistanceText: String,
        val canStart: Boolean,
        val unavailableReason: String?,
        val measurementFactor: Double,
        val onStart: () -> Unit,
        val onSave: (String, String, Double) -> Unit,
        val onCancelSession: () -> Unit,
        val onDisable: () -> Unit,
        val onReset: () -> Unit
    ) : SettingsDialog()
    data class Info(val title: String, val message: String) : SettingsDialog()
    data class GuidedControlTest(
        val testName: String,
        val title: String,
        val preparation: String,
        val sequence: String,
        val duration: String,
        val safety: String,
        val onStart: () -> Unit
    ) : SettingsDialog()
    data class Confirm(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit) : SettingsDialog()
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Uri?,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onFuelRefillLitersSave: (String) -> Boolean
) {
    var selected by remember { mutableStateOf(SettingsCategory.Connection) }
    var portraitPage by remember { mutableStateOf<SettingsCategory?>(null) }
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }
    var vehicleVisualPickerOpen by remember { mutableStateOf(false) }

    BackHandler(enabled = vehicleVisualPickerOpen || portraitPage != null) {
        if (vehicleVisualPickerOpen) vehicleVisualPickerOpen = false else portraitPage = null
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSideMenu(palette, selected, settings.language, onSelect = { selected = it }, modifier = Modifier.width(220.dp).fillMaxHeight())
                if (vehicleVisualPickerOpen) {
                    VehicleVisualSelectionScreen(
                        palette = palette,
                        settings = settings,
                        onSave = { model, color ->
                            onSettingsChange(settings.copy(vehicleVisualModel = model, vehicleColor = color))
                            vehicleVisualPickerOpen = false
                        },
                        onCancel = { vehicleVisualPickerOpen = false },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                } else {
                    SettingsContent(
                        palette = palette,
                        category = selected,
                        settings = settings,
                        obdState = obdState,
                        snapshot = snapshot,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetMetrics = onResetMetrics,
                        onEndTripNow = onEndTripNow,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onExportTechnicalSession = onExportTechnicalSession,
                        onCreateSupportPackage = onCreateSupportPackage,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        onRefreshHistory = onRefreshHistory,
                        onOpenTripHistory = onOpenTripHistory,
                        onExportAllHistory = onExportAllHistory,
                        onCreateDataBackup = onCreateDataBackup,
                        onRestoreDataBackup = onRestoreDataBackup,
                        onFuelRefillLitersSave = onFuelRefillLitersSave,
                        onOpenVehicleVisualPicker = { vehicleVisualPickerOpen = true },
                        openDialog = { dialog = it },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        } else {
            if (vehicleVisualPickerOpen) {
                VehicleVisualSelectionScreen(
                    palette = palette,
                    settings = settings,
                    onSave = { model, color ->
                        onSettingsChange(settings.copy(vehicleVisualModel = model, vehicleColor = color))
                        vehicleVisualPickerOpen = false
                    },
                    onCancel = { vehicleVisualPickerOpen = false },
                    modifier = Modifier.fillMaxSize()
                )
            } else AnimatedContent(
                targetState = portraitPage,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally(animationSpec = tween(250)) { it } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeOut(animationSpec = tween(180)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { it } + fadeOut(animationSpec = tween(180)))
                    }
                },
                label = "settingsPortraitNav"
            ) { page ->
                if (page == null) {
                    SettingsCategoryList(palette = palette, language = settings.language, onOpen = {
                        selected = it
                        portraitPage = it
                    })
                } else {
                    SettingsDetailPage(
                        palette = palette,
                        category = page,
                        settings = settings,
                        obdState = obdState,
                        snapshot = snapshot,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetMetrics = onResetMetrics,
                        onEndTripNow = onEndTripNow,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onExportTechnicalSession = onExportTechnicalSession,
                        onCreateSupportPackage = onCreateSupportPackage,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        onRefreshHistory = onRefreshHistory,
                        onOpenTripHistory = onOpenTripHistory,
                        onExportAllHistory = onExportAllHistory,
                        onCreateDataBackup = onCreateDataBackup,
                        onRestoreDataBackup = onRestoreDataBackup,
                        onFuelRefillLitersSave = onFuelRefillLitersSave,
                        onOpenVehicleVisualPicker = { vehicleVisualPickerOpen = true },
                        openDialog = { dialog = it },
                        onBack = { portraitPage = null }
                    )
                }
            }
        }
    }

    dialog?.let { current ->
        when (current) {
            is SettingsDialog.Options -> OptionDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.TextInput -> TextInputDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Calibration -> FuelCalibrationDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Info -> InfoDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.GuidedControlTest -> GuidedControlTestDialog(
                palette = palette,
                dialog = current,
                language = settings.language,
                obdState = obdState,
                onDismiss = { dialog = null }
            )
            is SettingsDialog.Confirm -> ConfirmDialog(palette, current, settings.language) { dialog = null }
        }
    }
}

@Composable
private fun SettingsCategoryList(palette: LoganPalette, language: AppLanguage, onOpen: (SettingsCategory) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
        }
        SettingsCategory.entries.forEach { cat ->
            item {
                SettingsCard(palette, modifier = Modifier.fillMaxWidth(), onClick = { onOpen(cat) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(categoryTitle(cat, language), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text("›", color = palette.textSecondary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSideMenu(palette: LoganPalette, selected: SettingsCategory, language: AppLanguage, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(modifier = modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (active) palette.accent.copy(alpha = .12f) else palette.surface)
                    .clickable { onSelect(cat) }
                    .padding(12.dp)
            ) {
                Text(categoryTitle(cat, language), color = if (active) palette.accent else palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCompactSideMenu(palette: LoganPalette, selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .verticalScroll(rememberScrollState())
            .padding(vertical = 10.dp, horizontal = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("☰", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            val icon = when (cat) {
                SettingsCategory.Language -> CardIcon.Time
                SettingsCategory.AppearanceCockpit -> CardIcon.Speed
                SettingsCategory.SetupDevice -> CardIcon.Settings
                SettingsCategory.DriveFuel -> CardIcon.Cost
                SettingsCategory.VehicleMaintenance -> CardIcon.Temperature
                SettingsCategory.Connection -> CardIcon.ObdConnection
                SettingsCategory.TripRecords -> CardIcon.Time
                SettingsCategory.Developer -> CardIcon.Injection
                SettingsCategory.Support -> CardIcon.LogsSupport
                SettingsCategory.Updates -> CardIcon.LogsSupport
                SettingsCategory.About -> CardIcon.Time
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) palette.accent else palette.surfaceVariant)
                    .clickable { onSelect(cat) },
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(
                    palette = palette,
                    icon = icon,
                    tint = if (active) palette.background else palette.textSecondary,
                    modifier = Modifier.size(27.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDetailPage(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Uri?,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onFuelRefillLitersSave: (String) -> Boolean,
    onOpenVehicleVisualPicker: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = if (settings.language == AppLanguage.English) "‹ Settings" else "‹ Ayarlar",
            color = palette.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
        )
        SettingsContent(
            palette = palette,
            category = category,
            settings = settings,
            obdState = obdState,
            snapshot = snapshot,
            onSettingsChange = onSettingsChange,
            onResetSetup = onResetSetup,
            onResetMetrics = onResetMetrics,
            onEndTripNow = onEndTripNow,
            onRefreshObdDevices = onRefreshObdDevices,
            onSelectObdDevice = onSelectObdDevice,
            onConnectObd = onConnectObd,
            onDisconnectObd = onDisconnectObd,
            onSaveObdLog = onSaveObdLog,
            onShareObdLog = onShareObdLog,
            onExportTechnicalSession = onExportTechnicalSession,
            onCreateSupportPackage = onCreateSupportPackage,
            onClearLastObdLog = onClearLastObdLog,
            onClearAllObdLogs = onClearAllObdLogs,
            onDeveloperTestStart = onDeveloperTestStart,
            onDeveloperTestEnd = onDeveloperTestEnd,
            onRefreshHistory = onRefreshHistory,
            onOpenTripHistory = onOpenTripHistory,
            onExportAllHistory = onExportAllHistory,
            onCreateDataBackup = onCreateDataBackup,
            onRestoreDataBackup = onRestoreDataBackup,
            onFuelRefillLitersSave = onFuelRefillLitersSave,
            onOpenVehicleVisualPicker = onOpenVehicleVisualPicker,
            openDialog = openDialog,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun SettingsContent(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Uri?,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onFuelRefillLitersSave: (String) -> Boolean,
    onOpenVehicleVisualPicker: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    modifier: Modifier
) {
    val context = LocalContext.current
    val appPrefs = remember(context.applicationContext) { AppPrefs(context.applicationContext) }
    var tripRecordsSubPage by remember(category) { mutableStateOf(TripRecordsSubPage.Main) }
    var developerSubPage by remember(category) { mutableStateOf(DeveloperSubPage.Main) }
    var supportType by remember(category, settings.language) {
        mutableStateOf(tx(settings.language, "Hata bildir", "Report a bug"))
    }
    var supportMessage by remember(category) { mutableStateOf("") }
    var includeSupportPackage by remember(category) { mutableStateOf(true) }

    BackHandler(
        enabled = (category == SettingsCategory.TripRecords && tripRecordsSubPage != TripRecordsSubPage.Main) ||
            (category == SettingsCategory.Developer && developerSubPage != DeveloperSubPage.Main)
    ) {
        when {
            category == SettingsCategory.TripRecords -> tripRecordsSubPage = TripRecordsSubPage.Main
            category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.Dynamic026Wide -> developerSubPage = DeveloperSubPage.Dynamic026
            category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.Dynamic026 -> developerSubPage = DeveloperSubPage.Tests
            category == SettingsCategory.Developer && developerSubPage in setOf(DeveloperSubPage.FuelRefill, DeveloperSubPage.ControlDiscovery) -> developerSubPage = DeveloperSubPage.Tests
            category == SettingsCategory.Developer -> developerSubPage = DeveloperSubPage.Main
        }
    }

    fun openSupportEmail() {
        if (supportMessage.isBlank()) {
            openDialog(
                SettingsDialog.Info(
                    tx(settings.language, "Açıklama gerekli", "Description required"),
                    tx(settings.language, "Göndermeden önce yaşadığınız sorunu veya önerinizi açıklayın.", "Describe the issue or suggestion before sending.")
                )
            )
            return
        }

        val attachmentUri = if (includeSupportPackage) onCreateSupportPackage() else null
        if (includeSupportPackage && attachmentUri == null) {
            openDialog(
                SettingsDialog.Info(
                    tx(settings.language, "Destek paketi oluşturulamadı", "Support package could not be created"),
                    tx(
                        settings.language,
                        "Teknik ZIP hazırlanamadığı için e-posta açılmadı. Tekrar deneyin veya ‘Teknik kayıt ZIP’ini ekle’ seçeneğini kapatın.",
                        "The email was not opened because the technical ZIP could not be prepared. Try again or disable ‘Attach technical log ZIP’."
                    )
                )
            )
            return
        }

        val reportId = "LOS-${SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date())}"
        val subject = "[LoganOS Destek] $supportType – ${BuildConfig.VERSION_NAME}"
        val body = buildString {
            appendLine("LOGANOS DESTEK KAYDI")
            appendLine()
            appendLine("Bildirim türü: $supportType")
            appendLine("Rapor kimliği: $reportId")
            appendLine()
            appendLine("Kullanıcı açıklaması:")
            appendLine(supportMessage.trim())
            appendLine()
            appendLine("--- Otomatik teknik bilgiler ---")
            appendLine("LoganOS sürümü: ${BuildConfig.VERSION_NAME}")
            appendLine("Cihaz: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android: ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("Araç: ${settings.vehicleModel} • ${settings.modelYearText} • ${settings.engine}")
            appendLine("OBD adaptörü: ${obdState.selectedName ?: "Seçilmedi"}")
            appendLine("Bağlantı: ${obdState.connectionHealth.name}")
            appendLine("Teknik ZIP: ${if (attachmentUri != null) "Bu e-postaya otomatik eklendi" else "Eklenmedi"}")
            appendLine()
            appendLine("Not: Şifre, VIN, plaka ve GPS rotası otomatik eklenmez.")
        }

        val emailIntent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("loganos.support@gmail.com"))
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            attachmentUri?.let { uri ->
                putExtra(Intent.EXTRA_STREAM, uri)
                clipData = ClipData.newUri(context.contentResolver, "LoganOS destek paketi", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }

        runCatching {
            context.startActivity(
                Intent.createChooser(
                    emailIntent,
                    tx(settings.language, "Destek e-postasını gönder", "Send support email")
                )
            )
        }.onFailure {
            val fallbackUri = Uri.parse(
                "mailto:loganos.support@gmail.com?subject=${Uri.encode(subject)}&body=${Uri.encode(body)}"
            )
            runCatching { context.startActivity(Intent(Intent.ACTION_SENDTO, fallbackUri)) }
                .onFailure {
                    openDialog(
                        SettingsDialog.Info(
                            tx(settings.language, "E-posta uygulaması bulunamadı", "No email app found"),
                            tx(
                                settings.language,
                                "E-posta uygulaması bulunamadı. Destek adresi: loganos.support@gmail.com",
                                "No email app was found. Support address: loganos.support@gmail.com"
                            )
                        )
                    )
                }
        }
    }

    fun openFuelCalibrationDialog() {
        val activeFactor = if (settings.fuelCalibrationEnabled) {
            settings.fuelCalibrationFactor.coerceIn(0.50, 1.50)
        } else {
            1.0
        }
        val realObdTotalsAvailable = !settings.demoMode && !snapshot.demo && snapshot.connected
        val liveTotalsAvailable = realObdTotalsAvailable &&
            snapshot.tripToken != 0L &&
            snapshot.tripDistanceKm != null &&
            snapshot.fuelUsedL != null
        val currentTripToken = if (liveTotalsAvailable) snapshot.tripToken else obdState.snapshot.tripToken
        val currentDistance = if (liveTotalsAvailable) snapshot.tripDistanceKm else obdState.snapshot.tripDistanceKm
        val currentFuel = if (liveTotalsAvailable) {
            snapshot.fuelUsedL
        } else {
            obdState.snapshot.fuelUsedL?.times(activeFactor)
        }
        val currentOdometer = if (liveTotalsAvailable) {
            snapshot.odometerKm
        } else {
            val base = settings.odometerText.toIntOrNull()
            if (base != null && currentDistance != null) base + currentDistance.toInt() else obdState.snapshot.odometerKm
        }
        val canStart = settings.fuelCalculationSupported &&
            realObdTotalsAvailable &&
            currentTripToken != 0L &&
            currentDistance != null &&
            currentFuel != null

        // Flush the latest frame before opening the result dialog. Progress is
        // accumulated independently from automatic drive-history trip tokens, so
        // one full-tank measurement may safely span many starts and stops.
        val progress = if (
            settings.fuelCalibrationSessionActive &&
            realObdTotalsAvailable &&
            currentTripToken != 0L &&
            currentDistance != null &&
            currentFuel != null
        ) {
            appPrefs.updateFuelCalibrationProgress(
                tripToken = currentTripToken,
                distanceKm = currentDistance,
                fuelLiters = currentFuel,
                force = true
            )
        } else {
            appPrefs.loadFuelCalibrationProgress()
        }
        val autoDistance = progress.accumulatedDistanceKm.takeIf { it > 0.0 }
        val autoAppLiters = progress.accumulatedFuelLiters.takeIf { it > 0.0 }
        val unavailableReason = when {
            settings.demoMode || snapshot.demo -> tx(
                settings.language,
                "Demo Modu sırasında yakıt kalibrasyonu başlatılamaz veya ilerletilemez. Aktif ölçüm korunur ve gerçek OBD bağlantısında devam eder.",
                "Fuel calibration cannot start or advance in Demo Mode. An active measurement is preserved and resumes with a real OBD connection."
            )
            !settings.fuelCalculationSupported -> tx(
                settings.language,
                "Yakıt kalibrasyonu yalnız doğrulanmış dizel yakıt hesabında kullanılabilir.",
                "Fuel calibration is available only for the verified diesel fuel calculation."
            )
            !settings.fuelCalibrationSessionActive && !canStart -> tx(
                settings.language,
                "Ölçümü başlatmak için OBD bağlantısını açın ve yol bilgisayarı verilerinin görünmesini bekleyin.",
                "Connect OBD and wait for trip-computer values before starting the measurement."
            )
            else -> null
        }

        openDialog(
            SettingsDialog.Calibration(
                sessionActive = settings.fuelCalibrationSessionActive,
                currentFactor = settings.fuelCalibrationFactor,
                enabled = settings.fuelCalibrationEnabled,
                startTimeMs = settings.fuelCalibrationStartTimeMs,
                startOdometerKm = settings.fuelCalibrationStartOdometerKm,
                autoDistanceKm = autoDistance,
                autoAppLiters = autoAppLiters,
                initialDistanceText = autoDistance?.let {
                    String.format(Locale.US, "%.1f", it)
                } ?: "",
                canStart = canStart,
                unavailableReason = unavailableReason,
                measurementFactor = settings.fuelCalibrationSessionFactor.coerceIn(0.50, 1.50),
                onStart = {
                    appPrefs.startFuelCalibrationProgress(
                        tripToken = currentTripToken,
                        distanceKm = currentDistance ?: 0.0,
                        fuelLiters = currentFuel ?: 0.0
                    )
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationWarningAccepted = true,
                            fuelCalibrationSessionActive = true,
                            fuelCalibrationStartDistanceKm = currentDistance ?: 0.0,
                            fuelCalibrationStartFuelLiters = currentFuel ?: 0.0,
                            fuelCalibrationStartTripToken = currentTripToken,
                            fuelCalibrationStartOdometerKm = currentOdometer ?: 0,
                            fuelCalibrationStartTimeMs = System.currentTimeMillis(),
                            fuelCalibrationSessionFactor = activeFactor,
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                },
                onSave = { pumpLiters, appLiters, factor ->
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = true,
                            fuelCalibrationFactor = factor,
                            fuelCalibrationAppLitersText = appLiters,
                            fuelCalibrationPumpLitersText = pumpLiters,
                            fuelCalibrationWarningAccepted = true,
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                },
                onCancelSession = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0,
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                },
                onDisable = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) },
                onReset = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = false,
                            fuelCalibrationFactor = 1.0,
                            fuelCalibrationAppLitersText = "",
                            fuelCalibrationPumpLitersText = "",
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                }
            )
        )
    }

    fun openFuelCalibrationFlow() {
        if (settings.fuelCalibrationWarningAccepted) {
            openFuelCalibrationDialog()
        } else {
            openDialog(
                SettingsDialog.Confirm(
                    title = tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                    message = tx(
                        settings.language,
                        "Bu özellik, yakıt tüketimi ve maliyet hesabını full depo yöntemine göre kalibre eder.\n\nDepoyu tamamen doldurduktan sonra ölçümü başlatın. En az 100 km, tercihen 200–300 km kullanıp depoyu yeniden aynı seviyeye kadar doldurun. Ölçüm boyunca LoganOS ve OBD bağlantısını kullanın; OBD olmadan yapılan sürüşler hesaplanan litreye eklenemez. İkinci dolumda yalnızca pompadan alınan litreyi girin; LoganOS kendi hesapladığı yakıtı otomatik kullanır.\n\nYanlış pompa veya mesafe bilgisi hesapları etkileyebilir. İstediğiniz zaman fabrika hesabına dönebilirsiniz.",
                        "This feature calibrates fuel-consumption and cost calculations using the full-tank method.\n\nStart the measurement after filling the tank completely. Drive at least 100 km, preferably 200–300 km, then refill to the same level. Keep LoganOS and the OBD connection active throughout the measurement; driving without OBD cannot be added to the calculated liters. At the second fill, enter only the pump liters; LoganOS uses its own calculated fuel automatically.\n\nIncorrect pump or distance information can affect the calculations. You can return to the factory calculation at any time."
                    ),
                    confirmLabel = tx(settings.language, "Anladım, devam et", "I understand, continue"),
                    onConfirm = {
                        onSettingsChange(settings.copy(fuelCalibrationWarningAccepted = true))
                        openFuelCalibrationDialog()
                    }
                )
            )
        }
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.Tests) {
        val openHandbrakeTest: (String) -> Unit = { requestedTest ->
            if (obdState.activeDeveloperTest == requestedTest) {
                onDeveloperTestStart(requestedTest)
            } else {
                openDialog(
                    controlDiscoveryPreviewDialog(
                        language = settings.language,
                        testName = requestedTest,
                        onStart = { onDeveloperTestStart(requestedTest) }
                    )
                )
            }
        }
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Geliştirici", "‹ Developer"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Main }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Geliştirici testleri", "Developer tests"),
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "Tamamlanan yakıt, 0x26, pedal, vites ve Trip araştırmaları kaldırıldı. Yalnız ürün hedefi devam eden el freni doğrulaması burada tutulur.",
                            "Completed fuel, 0x26, pedal, gear and Trip investigations were retired. Only the handbrake validation with an open product goal remains here."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item {
                    DeveloperTestRows(
                        palette = palette,
                        obdState = obdState,
                        language = settings.language,
                        onStart = openHandbrakeTest,
                        onEnd = onDeveloperTestEnd
                    )
                }
            }
        }
        return
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.FuelRefill) {
        val rpmText = snapshot.rpm?.let { "$it rpm" } ?: tx(settings.language, "RPM bekleniyor", "Waiting for RPM")
        val speedText = snapshot.speedKmh?.let { "$it km/sa" } ?: "-- km/sa"
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Geliştirici testleri", "‹ Developer tests"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Tests }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(FUEL_REFILL_TEST_NAME, color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(
                        tx(
                            settings.language,
                            "Tek bir dolum doğrulaması altı bağımsız bölümden oluşur. Tamamlanan bölümler uygulama veya araç kapansa da korunur. Kontak/marş geçişleri bölüm dışında yapılır. Pompa başında uygulamayla işlem yapılmaz.",
                            "One refill verification consists of six independent sections. Completed sections are preserved across app or vehicle shutdowns. Ignition/cranking changes happen outside a running section; no app interaction is required at the pump."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Canlı durum", "Live status"),
                        subtitle = tx(
                            settings.language,
                            "OBD: ${if (obdState.connected) "Bağlı" else "Bağlı değil"} • RPM: $rpmText • Hız: $speedText",
                            "OBD: ${if (obdState.connected) "Connected" else "Disconnected"} • RPM: $rpmText • Speed: $speedText"
                        )
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Kesin test sırası", "Final test sequence"),
                        subtitle = tx(
                            settings.language,
                            "1) Motor çalışır referans • 2) KOEO referans • 3) Normal yakıt alımı • 4) Yakıt sonrası KOEO • 5) Motor çalışır + 5 km sürüş • 6) Son KOEO. 21DD byte[1] ana adaydır; 21D8/21D9 her bölümde yalnız bir kez denenir.",
                            "1) Engine-running reference • 2) KOEO reference • 3) Normal refuelling • 4) Post-refill KOEO • 5) Engine-running + 5 km drive • 6) Final KOEO. 21DD byte[1] is the primary candidate; 21D8/21D9 are probed once per section."
                        )
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Doğrulama kuralı", "Validation rule"),
                        subtitle = tx(
                            settings.language,
                            "Tek dolum sonucu kesin yakıt seviyesi sayılmaz. Aynı aday en az iki bağımsız yakıt alımında yeniden doğrulanmadan kokpite yakıt seviyesi veya menzil eklenmez.",
                            "A single refill is not accepted as a definitive fuel-level result. Fuel level or range is not added to the cockpit until the same candidate is reproduced in at least two independent refills."
                        )
                    )
                }
                if (obdState.pendingDeveloperTestName != null) {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = tx(settings.language, "OBD oturumu otomatik yenileniyor", "OBD session is refreshing automatically"),
                            subtitle = tx(
                                settings.language,
                                "${obdState.pendingDeveloperTestName} için canlı motor durumu yenileniyor. Bağlantı iki kez otomatik kapatılıp yeniden açılır; doğru RPM/motor durumu gelince bölüm kendiliğinden başlar.",
                                "Refreshing the live engine state for ${obdState.pendingDeveloperTestName}. The connection is hard-refreshed up to twice and the section starts automatically when the correct RPM/engine state returns."
                            )
                        )
                    }
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "1–2 • YAKIT ÖNCESİ • POMPAYA GİTMEDEN", "BEFORE REFUELLING • AWAY FROM PUMP")) }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_BEFORE_ENGINE_TEST_NAME,
                        tx(settings.language, "Uygun yerde araç sabit ve motor rölantide. 10 saniye sabit bekleme ve üç hedefli okuma yapılır.", "Park safely with the engine idling. A 10-second stable wait and three targeted reads are performed."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_BEFORE_KOEO_TEST_NAME,
                        tx(settings.language, "Önceki bölüm bittikten sonra motoru kapatın, kontağı açık bırakın. Bu bölümü ayrı başlatın; üç karşılaştırma okuması alınır.", "After the previous section, stop the engine and leave ignition on. Start this section separately; three comparison reads are taken."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "3 • Sonra normal şekilde yakıt alın", "3 • Then refuel normally"),
                        subtitle = tx(
                            settings.language,
                            "Pompaya yanaşın, aracı stop edin ve yakıtı alın. Pompa başında test başlatmayın veya telefonla uğraşmayın. Yakıt aldıktan sonra uygun bir yere geçin.",
                            "Move to the pump, stop the engine and refuel. Do not start a test or use the phone at the pump. Move to a safe area afterwards."
                        )
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Eklenen yakıt", "Fuel added"),
                        subtitle = tx(settings.language, "Fişte yazan litreyi güvenli yere geçtikten sonra girin.", "Enter the litres shown on the receipt after moving to a safe area."),
                        value = obdState.fuelRefillLitersText.takeIf { it.isNotBlank() }?.let { "$it L" } ?: tx(settings.language, "Girilmedi", "Not entered"),
                        onClick = {
                            openDialog(
                                SettingsDialog.TextInput(
                                    title = tx(settings.language, "Eklenen yakıt miktarı", "Fuel amount added"),
                                    initial = obdState.fuelRefillLitersText,
                                    hint = tx(settings.language, "Örnek: 18,42 litre", "Example: 18.42 litres"),
                                    onSave = { onFuelRefillLitersSave(it) }
                                )
                            )
                        }
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Fiş ve gösterge notunu saklayın", "Keep receipt and gauge notes"),
                        subtitle = tx(
                            settings.language,
                            "Fişteki litreyi, yakıt öncesi/sonrası gösterge çubuk seviyesini ve zeminin düz/eğimli olduğunu not edin. Bunlar ham ECU karşılaştırmasını yorumlarken kullanılacaktır.",
                            "Keep the receipt litres, the gauge-bar level before/after refuelling, and whether the ground was level or sloped. These observations are used when interpreting the raw ECU comparison."
                        )
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "4–6 • YAKIT SONRASI • GÜVENLİ PARK ALANI", "AFTER REFUELLING • SAFE PARKING AREA")) }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_AFTER_KOEO_TEST_NAME,
                        tx(settings.language, "Tercihen ilk olarak motor kapalı, kontak açık ölçümü. Yakıt öncesi KOEO ile en temiz karşılaştırmadır.", "Preferably take this first with the engine off and ignition on. This is the cleanest comparison with the pre-refuel KOEO reading."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_AFTER_ENGINE_TEST_NAME,
                        tx(settings.language, "Motoru çalıştırdıktan sonra bu ayrı bölümü başlatın. İlk 10 saniye ve yaklaşık 60. saniyede hedefli ölçüm alınır.", "Start this separate section after starting the engine. Targeted readings are taken during the first 10 seconds and at about 60 seconds."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_DRIVE_TEST_NAME,
                        tx(settings.language, "Başlangıç taraması bitene kadar durun. Sonra normal sürüşte hareket, 500 m, 2 km ve 5 km ölçümleri otomatik alınır; telefona dokunmayın.", "Remain stopped until the baseline scan finishes. Then motion, 500 m, 2 km and 5 km samples are captured automatically during normal driving; do not touch the phone."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, FUEL_REFILL_FINAL_KOEO_TEST_NAME,
                        tx(settings.language, "Sürüş bölümü bittikten sonra güvenli yerde motoru kapatın, kontağı açık bırakın ve son bölümü ayrı başlatın.", "After the drive section, stop safely, switch the engine off, leave ignition on and start this final section separately."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_COMBINE_RESULTS_NAME,
                        tx(settings.language, "Tamamlanan yakıt öncesi/sonrası bölümleri ve deneme geçmişini tek ZIP içinde toplar.", "Collects the completed pre/post-refuel sections and attempt history into one ZIP."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Text(
                        tx(
                            settings.language,
                            "Marş sonrası RPM gelmezse bölüm sonsuza kadar beklemez: LoganOS eski KWP oturumunu kapatır, OBD'yi en fazla iki kez yeniden bağlar ve aynı adımı otomatik sürdürür. Tamamlanan bölümler korunur.",
                            "If RPM does not return after cranking, the section will not wait forever: LoganOS closes the stale KWP session, reconnects OBD up to twice and resumes the same step automatically. Completed sections are preserved."
                        ),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
        return
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.ControlDiscovery) {
        val openControlTest: (String) -> Unit = { requestedTest ->
            openDialog(
                controlDiscoveryPreviewDialog(
                    language = settings.language,
                    testName = requestedTest,
                    onStart = { onDeveloperTestStart(requestedTest) }
                )
            )
        }
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Geliştirici testleri", "‹ Developer tests"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Tests }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(CONTROL_DISCOVERY_TEST_NAME, color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(
                        tx(
                            settings.language,
                            "Her test bağımsızdır. Ekran hangi konumu kaç saniye tutacağınızı adım adım söyler; bir sonraki yönerge gelene kadar mevcut konumu değiştirmeyin. Araç düz ve güvenli zeminde olmalı; hareketli sürüş bölümünde telefonla ilgilenilmez.",
                            "Each test is independent. The screen tells you which state to hold and for how many seconds; keep that state until the next instruction appears. The vehicle must be on safe level ground; never interact with the phone during the driving section."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, CONTROL_HANDBRAKE_TEST_NAME,
                        tx(settings.language, "Motor kapalı ve kontak açık çalışır. Önce 0x10–0x7F KWP adresleri ile cevap veren modüllerde 2100–21FF tam taranır; ardından yalnız değişen bloklar üç çekili ve üç indirilmiş aşamada doğrulanır.", "Runs with ignition on and engine off. It first scans KWP addresses 0x10–0x7F and the full 2100–21FF range on every responding module, then verifies only changed blocks across three engaged and three released states."),
                        openControlTest, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, CONTROL_CLUTCH_TEST_NAME,
                        tx(settings.language, "Araç boşta ve sabit: debriyaj bırakılmış/basılı durumları üç kez, her biri 5 saniye kaydedilir.", "Vehicle stationary in neutral: clutch released/pressed states are recorded three times, 5 seconds each."),
                        openControlTest, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, CONTROL_BRAKE_TEST_NAME,
                        tx(settings.language, "El freni çekili ve araç boşta: ayak freni bırakılmış/basılı durumları üç kez, her biri 5 saniye kaydedilir.", "Handbrake on and vehicle in neutral: foot brake released/pressed states are recorded three times, 5 seconds each."),
                        openControlTest, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, CONTROL_GEAR_STATIC_TEST_NAME,
                        tx(settings.language, "Motor rölantide, el freni çekili, ayak freni ve debriyaj basılı, araç sabit: Boş→1→Boş→2→Boş→3→Boş→4→Boş→5→Boş→Geri→Boş; ekran her konumu 4–5 saniye tutturur.", "Engine idling, handbrake on, foot brake and clutch pressed, vehicle stationary: N→1→N→2→N→3→N→4→N→5→N→R→N; the screen holds each state for 4–5 seconds."),
                        openControlTest, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, CONTROL_GEAR_DRIVE_TEST_NAME,
                        tx(settings.language, "Güvenli yolda her vitesi kısa süre sabit kullanın. LoganOS hedefli bloklarla RPM/hız oranı örnekleri alır; tam 2100–21FF taraması yapılmaz.", "On a safe road, hold each gear briefly. LoganOS records RPM/speed-ratio samples with targeted blocks; no full 2100–21FF sweep is performed."),
                        openControlTest, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_COMBINE_RESULTS_NAME,
                        tx(settings.language, "El freni, debriyaj, fren ve vites denemelerini tek sonuç ZIP'inde toplar.", "Collects handbrake, clutch, brake and gear attempts into one result ZIP."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Text(
                        tx(
                            settings.language,
                            "Yalnız salt-okuma 10C0/21xx komutları kullanılır. Kontrol testlerinde 0x26/21DB, 21DC, 21DD, 21DE ve gerekli motor bağlam blokları hedefli okunur.",
                            "Only read-only 10C0/21xx commands are used. Control tests target 0x26/21DB, 21DC, 21DD, 21DE and required engine-context blocks."
                        ),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
        return
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.Dynamic026) {
        val coreTests = listOf(
            KWP_026_KOEO_TEST_NAME,
            KWP_026_ENGINE_STATIC_TEST_NAME,
            KWP_026_DRIVE_TEST_NAME,
            KWP_026_POST_KOEO_TEST_NAME
        )
        val completedCount = coreTests.count { name ->
            obdState.testHistory.firstOrNull { it.name == name }?.status == "COMPLETED"
        }
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Geliştirici testleri", "‹ Developer tests"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Tests }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        KWP_026_DYNAMIC_TEST_NAME,
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "Genel ilerleme: $completedCount / 4 bölüm tamamlandı. Her bölüm kendi OBD oturumunu açar; marş veya kontak geçişi sırasında önceki sonuçlar kaybolmaz.",
                            "Overall progress: $completedCount / 4 sections completed. Each section opens its own OBD session, so previous results survive engine-start or ignition transitions."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                if (isKwp026DeveloperTest(obdState.activeDeveloperTest)) {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = tx(settings.language, "Aktif bölüm: ${obdState.activeDeveloperTest}", "Active section: ${obdState.activeDeveloperTest}"),
                            subtitle = buildString {
                                append(obdState.developerTestPhaseText ?: tx(settings.language, "Hazırlanıyor", "Preparing"))
                                obdState.developerTestProgressPercent?.let { append(" • %$it") }
                                obdState.developerTestElapsedSec?.let { append(" • ${formatSettingsDuration(it)}") }
                            },
                            value = tx(settings.language, "Üst karttan aç", "Open from top card"),
                            onClick = { obdState.activeDeveloperTest?.let(onDeveloperTestStart) }
                        )
                    }
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "BAĞIMSIZ DOĞRULAMA BÖLÜMLERİ", "INDEPENDENT VALIDATION SECTIONS")) }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_KOEO_TEST_NAME,
                        tx(settings.language, "Düz zeminde, kontak açık ve motor kapalı. 7A/21A0[39], 7A/21CC[9] ve bağlam blokları yaklaşık 1–2 dakika okunur.", "Level ground, ignition on and engine off. 7A/21A0[39], 7A/21CC[9] and context blocks are read for about 1–2 minutes."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_ENGINE_STATIC_TEST_NAME,
                        tx(settings.language, "Motoru önce çalıştır ve RPM görünmesini bekle. 15 sn rölanti → iki tur ölçüm → 1800–2200 rpm doğrulaması.", "Start the engine first and wait for RPM. 15s idle → two capture passes → 1800–2200 rpm validation."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_DRIVE_TEST_NAME,
                        tx(settings.language, "Motor çalışırken ve araç dururken başlat. 10 km/sa, 500 m ve 2 km noktalarında ölçüm otomatik alınır.", "Start with the engine running and vehicle stopped. Measurements are taken automatically at 10 km/h, 500 m and 2 km."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_POST_KOEO_TEST_NAME,
                        tx(settings.language, "Sürüş bittikten sonra motoru kapat, kontağı açık bırak ve bu bölümü ayrıca başlat.", "After the drive, stop the engine, leave ignition on and start this section separately."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "ARAŞTIRMA ARAÇLARI", "RESEARCH TOOLS")) }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Geniş araştırma taraması", "Broad research scan"),
                        subtitle = tx(settings.language, "Yeni cevap veren 21xx bloklarını bulmak için beş yönlendirmeli ve ayrı çalıştırılan aşama. Hareket halinde tüm aralık taranmaz.", "Five guided, separately run stages for finding newly responding 21xx blocks. The full range is not scanned while moving."),
                        value = tx(settings.language, "Aç ›", "Open ›"),
                        onClick = { developerSubPage = DeveloperSubPage.Dynamic026Wide }
                    )
                }
                item {
                    SettingsRow(
                        palette = palette,
                        title = tx(settings.language, "Birleşik sonuç paketi", "Combined result package"),
                        subtitle = tx(settings.language, "Aynı araştırma grubunda tamamlanan bağımsız ve geniş tarama dosyalarını tek ZIP içinde toplar.", "Collects completed independent and broad-scan files from the same research group into one ZIP."),
                        value = tx(settings.language, "Oluştur", "Create"),
                        onClick = { onDeveloperTestStart(KWP_026_COMBINE_RESULTS_NAME) }
                    )
                }
                obdState.savedLogFileName?.takeIf { it.contains("dynamic_026") }?.let { fileName ->
                    item {
                        Text(
                            tx(settings.language, "Son sonuç: $fileName", "Latest result: $fileName"),
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }
        return
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.Dynamic026Wide) {
        val wideTests = listOf(
            KWP_026_WIDE_KOEO_TEST_NAME,
            KWP_026_WIDE_IDLE_TEST_NAME,
            KWP_026_WIDE_RPM_TEST_NAME,
            KWP_026_WIDE_DRIVE_TEST_NAME,
            KWP_026_WIDE_POST_TEST_NAME
        )
        val completedCount = wideTests.count { name ->
            obdState.testHistory.firstOrNull { it.name == name }?.status == "COMPLETED"
        }
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ 0x26 Dinamik Veri Doğrulama", "‹ 0x26 Dynamic Data Validation"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Dynamic026 }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Geniş araştırma taraması", "Broad research scan"),
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "$completedCount / 5 aşama tamamlandı. Aşamaları sırayla uygula fakat her birini araç gerekli duruma geldikten sonra ayrı başlat. Böylece marş/kontak bağlantı kaybı test akışını kilitlemez.",
                            "$completedCount / 5 stages completed. Follow them in order, but start each stage separately after the vehicle reaches the required state. This prevents engine-start or ignition connection loss from locking the workflow."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                if (isKwp026DeveloperTest(obdState.activeDeveloperTest)) {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = tx(settings.language, "Aktif aşama: ${obdState.activeDeveloperTest}", "Active stage: ${obdState.activeDeveloperTest}"),
                            subtitle = buildString {
                                append(obdState.developerTestPhaseText ?: tx(settings.language, "Hazırlanıyor", "Preparing"))
                                obdState.developerTestProgressPercent?.let { append(" • %$it") }
                                obdState.developerTestElapsedSec?.let { append(" • ${formatSettingsDuration(it)}") }
                            },
                            value = tx(settings.language, "Üst karttan aç", "Open from top card"),
                            onClick = { obdState.activeDeveloperTest?.let(onDeveloperTestStart) }
                        )
                    }
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_WIDE_KOEO_TEST_NAME,
                        tx(settings.language, "1. Motor kapalı, kontak açık ve araç sabit. 0x26 ile 0x7A üzerinde tam 2100–21FF keşif taraması.", "1. Engine off, ignition on, vehicle stationary. Full 2100–21FF discovery on 0x26 and 0x7A."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_WIDE_IDLE_TEST_NAME,
                        tx(settings.language, "2. Motoru çalıştır, OBD'de RPM görünmesini bekle; 15 sn kararlı rölantiden sonra tam aralık taranır.", "2. Start the engine and wait for RPM; after 15s stable idle, the full range is scanned."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_WIDE_RPM_TEST_NAME,
                        tx(settings.language, "3. Araç sabit ve boş viteste. 1800–2200 rpm 8 sn korunur; yalnız bilinen ve koşula bağlı bloklar hızlı okunur.", "3. Vehicle stationary and in neutral. Hold 1800–2200 rpm for 8s; only known and conditional blocks are read quickly."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_WIDE_DRIVE_TEST_NAME,
                        tx(settings.language, "4. Araç dururken başlat, sonra normal sür. 10 km/sa, 500 m, 2 km ve 5 km noktaları otomatik kaydedilir; telefonla ilgilenme.", "4. Start while stopped, then drive normally. 10 km/h, 500 m, 2 km and 5 km points are captured automatically; do not interact with the phone."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Dynamic026TestRow(
                        palette, obdState, settings.language, KWP_026_WIDE_POST_TEST_NAME,
                        tx(settings.language, "5. Güvenli yere park et; motoru kapatıp kontağı açık bırak. Tam aralık son kez karşılaştırılır.", "5. Park safely; stop the engine and leave ignition on. The full range is compared one final time."),
                        onDeveloperTestStart, onDeveloperTestEnd
                    )
                }
                item {
                    Text(
                        tx(
                            settings.language,
                            "Güvenlik: yalnız 10C0/21xx salt-okuma kullanılır. 0x26/21A2 korumalıdır ve tarama dışıdır; 14/27/2E/31/34/36/3B servisleri gönderilmez.",
                            "Safety: only read-only 10C0/21xx requests are used. Protected 0x26/21A2 is excluded; services 14/27/2E/31/34/36/3B are never sent."
                        ),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                }
            }
        }
        return
    }

    if (category == SettingsCategory.Developer && developerSubPage == DeveloperSubPage.TechnicalHistory) {
        val visibleTechnicalHistory = obdState.technicalHistory
            .filter { session ->
                session.activeLike || session.sampleCount > 0 || session.status in setOf("INTERRUPTED", "RECOVERED", "UNSTABLE", "ERROR")
            }
            .take(10)
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Geliştirici", "‹ Developer"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { developerSubPage = DeveloperSubPage.Main }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Teknik kayıt geçmişi", "Technical log history"),
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "OBD bağlantıları, ECU örnekleri ve bağlantı kapanışları hata analizi için tutulur. Veri içermeyen kısa bağlantı denemeleri listede gösterilmez.",
                            "OBD connections, ECU samples and connection endings are stored for diagnostics. Short attempts without data are hidden."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Son geçerli teknik kaydı dışa aktar", "Export last valid technical log"),
                        tx(settings.language, "Örnek içeren en son OBD oturumunu dışa aktarır.", "Exports the latest OBD session containing samples."),
                        tx(settings.language, "Dışa aktar", "Export"),
                        onClick = {
                            openDialog(
                                SettingsDialog.Confirm(
                                    tx(settings.language, "Teknik kayıt dışa aktarılsın mı?", "Export technical log?"),
                                    tx(settings.language, "Teknik kayıt araç ve OBD bilgisi içerebilir. Ham ECU paketleri yalnız Geliştirici Ham Log açıksa dahil edilir.", "The technical log may contain vehicle and OBD information. Raw ECU packets are included only when Developer Raw Log is enabled."),
                                    tx(settings.language, "Dışa aktar", "Export")
                                ) { onSaveObdLog() }
                            )
                        }
                    )
                }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Son geçerli teknik kaydı paylaş", "Share last valid technical log"),
                        tx(settings.language, "Örnek içeren en son OBD oturumunu paylaşır.", "Shares the latest OBD session containing samples."),
                        tx(settings.language, "Paylaş", "Share"),
                        onClick = onShareObdLog
                    )
                }
                visibleTechnicalHistory.forEach { session ->
                    item(key = "technical_session_${session.id}") {
                        val started = if (session.timeTrusted && session.startedAtMs > 0L) {
                            SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date(session.startedAtMs))
                        } else {
                            tx(settings.language, "Saat bekleniyor", "Time pending")
                        }
                        val durationSec = session.durationMs.coerceAtLeast(0L) / 1000L
                        val durationText = "%02d:%02d".format(Locale.US, durationSec / 60L, durationSec % 60L)
                        val statusText = when (session.status) {
                            "ACTIVE" -> tx(settings.language, "Aktif", "Active")
                            "ENDED", "ENDED_IGNITION_OFF" -> tx(settings.language, "Kontak kapatıldı", "Ignition off")
                            "ENDED_IGNITION_WAIT" -> tx(settings.language, "Veri alınmadan sona erdi", "Ended without data")
                            "RECOVERED" -> tx(settings.language, "Kurtarıldı", "Recovered")
                            "INTERRUPTED" -> tx(settings.language, "Yarım kaldı", "Interrupted")
                            "UNSTABLE" -> tx(settings.language, "Bağlantı kararsız", "Connection unstable")
                            "ERROR" -> tx(settings.language, "Bağlantı hatası", "Connection error")
                            else -> session.status.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
                        }
                        SettingsRow(
                            palette,
                            tx(settings.language, "Teknik oturum #${session.id}", "Technical session #${session.id}"),
                            "$started • $durationText • ${session.sampleCount} ${tx(settings.language, "örnek", "samples")} • $statusText",
                            tx(settings.language, "Dışa aktar", "Export"),
                            onClick = { onExportTechnicalSession(session.id) }
                        )
                    }
                }
                if (visibleTechnicalHistory.isEmpty()) {
                    item {
                        Text(
                            tx(settings.language, "Gösterilecek anlamlı teknik oturum bulunmuyor.", "There are no meaningful technical sessions to display."),
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 8.dp)
                        )
                    }
                }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Destek paketi oluştur", "Create support package"),
                        tx(settings.language, "Son geçerli kayıtla birlikte son 10 teknik OBD oturumunu ZIP olarak hazırlar.", "Creates a ZIP with the last valid log and the 10 most recent technical OBD sessions."),
                        tx(settings.language, "Oluştur", "Create"),
                        onClick = {
                            openDialog(
                                SettingsDialog.Confirm(
                                    tx(settings.language, "Destek paketi oluşturulsun mu?", "Create support package?"),
                                    tx(settings.language, "ZIP son geçerli kaydı ve son 10 teknik oturumu içerir. Bluetooth adresi maskelenir; ham ECU paketleri yalnız Geliştirici Ham Log açıksa eklenir.", "The ZIP contains the last valid log and the 10 most recent technical sessions. The Bluetooth address is masked; raw ECU packets are added only when Developer Raw Log is enabled."),
                                    tx(settings.language, "Oluştur", "Create")
                                ) { onCreateSupportPackage() }
                            )
                        }
                    )
                }
                obdState.savedLogPath?.let { path ->
                    item {
                        Text(
                            tx(settings.language, "Son teknik dosya", "Last technical file") + ": $path",
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            maxLines = 2
                        )
                    }
                }
            }
        }
        return
    }

    if (category == SettingsCategory.TripRecords && tripRecordsSubPage == TripRecordsSubPage.DataManagement) {
        SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Sürüş ve Kayıtlar", "‹ Trips & Records"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { tripRecordsSubPage = TripRecordsSubPage.Main }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Yedekleme ve veri yönetimi", "Backup & data management"),
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "Ayarları ve sürüş/test kayıtlarını yedekleyin, geri yükleyin veya temizleyin.",
                            "Back up, restore or clear settings and drive/test records."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "YEDEKLEME", "BACKUP")) }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Yedek oluştur", "Create backup"),
                        tx(settings.language, "Ayarlar ile sürüş/test geçmişini taşınabilir ZIP olarak kaydeder.", "Saves settings and drive/test history as a portable ZIP."),
                        tx(settings.language, "Yedekle", "Backup"),
                        onClick = onCreateDataBackup
                    )
                }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Yedeği geri yükle", "Restore backup"),
                        tx(settings.language, "Seçilen LoganOS yedeği mevcut ayar ve geçmişin yerine geçer.", "The selected LoganOS backup replaces current settings and history."),
                        tx(settings.language, "Geri yükle", "Restore"),
                        onClick = {
                            openDialog(SettingsDialog.Confirm(
                                tx(settings.language, "Yedek geri yüklensin mi?", "Restore backup?"),
                                tx(settings.language, "Mevcut ayarlar ve sürüş/test veritabanı seçilen yedekle değiştirilecek. Dosya yapısı, SHA-256 bütünlüğü ve SQLite veritabanı sağlığı geri yüklemeden önce doğrulanır.", "Current settings and the drive/test database will be replaced by the selected backup. File structure, SHA-256 integrity and SQLite database health are verified before restore."),
                                tx(settings.language, "Dosya seç", "Choose file")
                            ) { onRestoreDataBackup() })
                        }
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "TEMİZLEME", "CLEANUP")) }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Tüm geçmişi ve teknik logları temizle", "Clear all history and technical logs"),
                        tx(settings.language, "Sürüş/test geçmişini, ilişkili örnekleri ve LoganOS loglarını kalıcı olarak siler.", "Permanently deletes drive/test history, related samples and LoganOS logs."),
                        tx(settings.language, "Temizle", "Clear"),
                        onClick = {
                            openDialog(SettingsDialog.Confirm(
                                tx(settings.language, "Tüm kayıtlar temizlensin mi?", "Clear all records?"),
                                tx(settings.language, "Tüm sürüş ve test geçmişi, ilişkili SQL örnekleri ve LoganOS logları kalıcı olarak silinecek. Bu işlem geri alınamaz.", "All drive and test history, related SQL samples and LoganOS logs will be permanently deleted. This cannot be undone."),
                                tx(settings.language, "Tümünü sil", "Delete all")
                            ) { onClearAllObdLogs() })
                        }
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Aktif OBD bağlantısı sırasında yedekleme ve geri yükleme işlemleri güvenlik nedeniyle engellenir.", "Backup and restore are blocked for safety while an OBD connection is active."),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )
                }
            }
        }
        return
    }

    SettingsCard(palette, modifier = modifier.fillMaxWidth()) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            item {
                Text(categoryTitle(category, settings.language), color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(categoryDesc(category, settings.language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.sp)
            }
            item { Spacer(Modifier.height(4.dp)) }
            when (category) {
                SettingsCategory.Language -> {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "Türkçe",
                            subtitle = "Uygulamayı Türkçe kullan",
                            value = if (settings.language == AppLanguage.Turkish) "✓ Seçili" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.Turkish)) }
                        )
                    }
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "English",
                            subtitle = "Use LoganOS in English",
                            value = if (settings.language == AppLanguage.English) "✓ Selected" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.English)) }
                        )
                    }
                }
                SettingsCategory.SetupDevice -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Cihaz kullanım modu", "Device usage mode"),
                            tx(settings.language, "Otomatik algıla veya Telefon / Double seçimini zorla.", "Auto-detect or force Phone / Head Unit mode."),
                            deviceModeLabel(settings.deviceMode, settings.language),
                            onClick = {
                                val options = DeviceMode.entries.map { deviceModeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Cihaz kullanım modu", "Device usage mode"), options) { label ->
                                    DeviceMode.entries.firstOrNull { deviceModeLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(deviceMode = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Double arayüzü", "Head Unit interface"),
                            tx(settings.language, "Double cihazda Standart Kokpit veya Premium Drive kullanın.", "Use Standard Cockpit or Premium Drive on the head unit."),
                            headUnitUiModeLabel(settings.headUnitUiMode, settings.language),
                            onClick = {
                                val options = HeadUnitUiMode.entries.map { headUnitUiModeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Double arayüzü", "Head Unit interface"), options) { label ->
                                    HeadUnitUiMode.entries.firstOrNull { headUnitUiModeLabel(it, settings.language) == label }?.let { mode ->
                                        val dedicatedCockpitSelected = settings.gaugeStyle == GaugeStyle.GhostSingle ||
                                            settings.gaugeStyle == GaugeStyle.GhostDual ||
                                            settings.gaugeStyle == GaugeStyle.GhostSingleOriginal ||
                                            settings.gaugeStyle == GaugeStyle.GhostDualOriginal ||
                                            settings.gaugeStyle == GaugeStyle.DigitalV2
                                        onSettingsChange(
                                            if (mode == HeadUnitUiMode.PremiumDrive && dedicatedCockpitSelected) {
                                                settings.copy(headUnitUiMode = mode, gaugeStyle = GaugeStyle.Digital)
                                            } else {
                                                settings.copy(headUnitUiMode = mode)
                                            }
                                        )
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Kurulum sihirbazını yeniden başlat", "Restart setup wizard"),
                            tx(settings.language, "Kurulum adımlarını yeniden açar; sürüş geçmişi ve kayıtlar silinmez.", "Reopens setup steps; drive history and records are not deleted."),
                            tx(settings.language, "Yeniden başlat", "Restart"),
                            onClick = {
                                openDialog(
                                    SettingsDialog.Confirm(
                                        tx(settings.language, "Kurulum yeniden başlatılsın mı?", "Restart setup?"),
                                        tx(settings.language, "Kurulum adımları yeniden açılacak. Sürüş geçmişi, testler ve kayıtlı veriler silinmeyecek.", "Setup steps will reopen. Drive history, tests and stored data will not be deleted."),
                                        tx(settings.language, "Yeniden başlat", "Restart")
                                    ) { onResetSetup() }
                                )
                            }
                        )
                    }
                }
                SettingsCategory.AppearanceCockpit -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Menü teması", "Menu theme"),
                            tx(settings.language, "Ayarlar ve menülerin arka plan tonunu seçin.", "Choose the background tone used by settings and menus."),
                            menuThemeLabel(settings.menuTheme, settings.language),
                            onClick = {
                                val options = MenuTheme.entries.map { menuThemeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Menü teması", "Menu theme"), options) { label ->
                                    MenuTheme.entries.firstOrNull { menuThemeLabel(it, settings.language) == label }?.let { theme ->
                                        onSettingsChange(settings.copy(menuTheme = theme, darkMode = theme == MenuTheme.Dark))
                                    }
                                })
                            }
                        )
                    }
                    item { SettingsRow(palette, tx(settings.language, "Vurgu Rengi", "Accent Color"), tx(settings.language, "Tüm LOGANOS vurgu rengi", "Main LOGANOS accent color"), settings.accentColor.label, onClick = { openDialog(SettingsDialog.Options(tx(settings.language, "Vurgu Rengi", "Accent Color"), AccentColor.entries.map { it.label }) { label -> AccentColor.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(accentColor = it)) } }) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Varsayılan Müzik Uygulaması", "Default Music App"),
                            tx(settings.language, "Premium Drive medya kartında kullanılacak uygulama", "App used by the Premium Drive media card"),
                            defaultMediaAppLabel(settings.defaultMediaApp, settings.language),
                            onClick = {
                                val options = DefaultMediaApp.entries.map { defaultMediaAppLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Varsayılan Müzik Uygulaması", "Default Music App"), options) { label ->
                                    DefaultMediaApp.entries.firstOrNull { defaultMediaAppLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(defaultMediaApp = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Gösterge Stili", "Gauge Style"),
                            tx(settings.language, "Digital OEM, Dijital V2, Classic veya Ghost kokpit", "Digital OEM, Digital V2, Classic or Ghost cockpit"),
                            gaugeStyleLabel(settings.gaugeStyle, settings.language),
                            onClick = {
                                val enabled = listOf(GaugeStyle.Digital, GaugeStyle.DigitalV2, GaugeStyle.ClassicOem, GaugeStyle.GhostSingle, GaugeStyle.GhostDual, GaugeStyle.GhostSingleOriginal)
                                val options = enabled.map { gaugeStyleLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Gösterge Stili", "Gauge Style"), options) { label ->
                                    enabled.firstOrNull { gaugeStyleLabel(it, settings.language) == label }?.let { style ->
                                        val ghostSelected = style == GaugeStyle.GhostSingle || style == GaugeStyle.GhostDual || style == GaugeStyle.GhostSingleOriginal || style == GaugeStyle.GhostDualOriginal
                                        val ownsCockpitSurface = ghostSelected || style == GaugeStyle.DigitalV2
                                        onSettingsChange(
                                            settings.copy(
                                                gaugeStyle = style,
                                                headUnitUiMode = if (ownsCockpitSurface) HeadUnitUiMode.Standard else settings.headUnitUiMode
                                            )
                                        )
                                    }
                                })
                            }
                        )
                    }
                    if (settings.gaugeStyle == GaugeStyle.DigitalV2) {
                        item {
                            DigitalV2SettingsPanel(
                                palette = palette,
                                settings = settings,
                                onSettingsChange = onSettingsChange,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }
                    }
                    if (settings.gaugeStyle == GaugeStyle.GhostSingleOriginal || settings.gaugeStyle == GaugeStyle.GhostDual || settings.gaugeStyle == GaugeStyle.GhostDualOriginal) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Gösterge Işık Rengi", "Gauge Light Color"),
                                tx(settings.language, "Ghost Single/Dual ufuk ve kadran ışık rengini seç", "Choose the Ghost Single/Dual horizon and gauge light colour"),
                                ghostOriginalAccentLabel(settings.ghostOriginalAccent, settings.language),
                                onClick = {
                                    val accents = listOf(GhostOriginalAccent.Blue, GhostOriginalAccent.Purple, GhostOriginalAccent.Yellow, GhostOriginalAccent.Red, GhostOriginalAccent.Green)
                                    val options = accents.map { ghostOriginalAccentLabel(it, settings.language) }
                                    openDialog(SettingsDialog.Options(tx(settings.language, "Gösterge Işık Rengi", "Gauge Light Color"), options) { label ->
                                        accents.firstOrNull { ghostOriginalAccentLabel(it, settings.language) == label }?.let {
                                            onSettingsChange(settings.copy(ghostOriginalAccent = it))
                                        }
                                    })
                                }
                            )
                        }
                    }
                    if (settings.gaugeStyle != GaugeStyle.GhostSingleOriginal && settings.gaugeStyle != GaugeStyle.GhostDual && settings.gaugeStyle != GaugeStyle.GhostDualOriginal) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Araç Görünümü", "Vehicle Appearance"),
                                tx(settings.language, "Kokpitlerde kullanılacak Logan kasasını ve rengini seç", "Choose the Logan generation and colour used in cockpits"),
                                vehicleVisualSummary(settings, settings.language),
                                onClick = onOpenVehicleVisualPicker
                            )
                        }
                    }

                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yazı Boyutu", "Text Size"),
                            tx(settings.language, "Kart metinleri ve hız göstergesi ölçeği", "Text scale for cards and speed gauge"),
                            cockpitTextSizeLabel(settings.cockpitTextSize, settings.language),
                            onClick = {
                                val options = CockpitTextSize.entries.map { cockpitTextSizeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yazı Boyutu", "Text Size"), options) { label ->
                                    CockpitTextSize.entries.firstOrNull { cockpitTextSizeLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitTextSize = it)) }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"),
                            tx(settings.language, "Kart, boşluk ve gösterge alanı düzeni", "Card, spacing and gauge area layout"),
                            cockpitDensityLabel(settings.cockpitDensity, settings.language),
                            onClick = {
                                val options = CockpitDensity.entries.map { cockpitDensityLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"), options) { label ->
                                    CockpitDensity.entries.firstOrNull { cockpitDensityLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitDensity = it)) }
                                })
                            }
                        )
                    }
                }
                SettingsCategory.DriveFuel -> {
                    if (!settings.fuelCalculationSupported) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Yakıt Hesabı Doğrulanmadı", "Fuel Calculation Not Verified"),
                                tx(
                                    settings.language,
                                    "Benzinli deneysel profilde tüketim, maliyet ve kalibrasyon kapalıdır. Önce enjeksiyon veya ECU yakıt debisi kaynağı doğrulanmalıdır.",
                                    "Consumption, cost and calibration stay disabled for the experimental petrol profile until an injection or ECU fuel-rate source is verified."
                                ),
                                tx(settings.language, "Deneysel", "Experimental")
                            )
                        }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), tx(settings.language, "Maliyet hesabı doğrulandığında kullanılacak litre fiyatı", "Fuel price to use after cost calculation is verified"), fuelPriceDisplay(settings.fuelPriceText, settings.language), onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), settings.fuelPriceText, tx(settings.language, "Örn. 45,50", "e.g. 45.50")) { v -> onSettingsChange(settings.copy(fuelPriceText = v)) }) }) }
                    if (settings.fuelCalculationSupported) {
                        item { SettingsRow(
                            palette,
                            tx(settings.language, "Ortalama + maliyeti sıfırla", "Reset Average + Cost"),
                            tx(settings.language, "Mesafe, toplam yakıt ve sürüş süresi korunur", "Distance, total fuel and trip time are preserved"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Hesaplar sıfırlansın mı?", "Reset calculations?"),
                                    tx(settings.language, "Ortalama tüketim ve sürüş maliyeti bu noktadan yeniden başlayacak. Yolculuk toplamları silinmez.", "Average consumption and trip cost will restart from this point. Trip totals will not be deleted."),
                                    tx(settings.language, "Sıfırla", "Reset")
                                ) { onResetMetrics(TripMetricReset.AverageAndCost) })
                            }
                        ) }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Sürüş sırasında ekranı açık tut", "Keep Screen On While Driving"), tx(settings.language, "Sürüşte telefon ekranının kapanmasını engeller", "Prevents the phone screen from turning off while driving"), trailingSwitch = settings.keepScreenOn, onSwitch = { onSettingsChange(settings.copy(keepScreenOn = it)) }) }
                    item { SettingsRow(
                        palette,
                        tx(settings.language, "Arka planda sürüşü sürdür", "Continue Driving in Background"),
                        tx(settings.language, "Başka uygulamaya geçince OBD bağlantısı ve aktif sürüş kaydı Foreground Service ile devam eder", "Keeps the OBD connection and active drive recording running through a Foreground Service when you leave LoganOS"),
                        trailingSwitch = settings.backgroundTripEnabled,
                        onSwitch = { onSettingsChange(settings.copy(backgroundTripEnabled = it)) }
                    ) }
                    if (settings.fuelCalculationSupported) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                                tx(settings.language, "Full depo yöntemiyle otomatik kalibrasyon", "Automatic calibration with the full-tank method"),
                                when {
                                    settings.fuelCalibrationSessionActive -> tx(settings.language, "Ölçüm sürüyor", "Measuring")
                                    settings.fuelCalibrationEnabled -> "x${String.format(java.util.Locale.US, "%.3f", settings.fuelCalibrationFactor)}"
                                    else -> tx(settings.language, "Kapalı", "Off")
                                },
                                onClick = { openFuelCalibrationFlow() }
                            )
                        }
                    }
                }
                SettingsCategory.VehicleMaintenance -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Motor / Yakıt Profili", "Engine / Fuel Profile"),
                            if (settings.fuelType == FuelType.Petrol) {
                                tx(settings.language, "Deneysel topluluk testi • tüketim hesabı kapalı • değişiklik yeniden bağlantıda uygulanır", "Experimental community test • fuel calculation disabled • applies after reconnect")
                            } else {
                                tx(settings.language, "Doğrulanmış Delphi DCM1.2 dizel profili • değişiklik yeniden bağlantıda uygulanır", "Verified Delphi DCM1.2 diesel profile • applies after reconnect")
                            },
                            if (settings.fuelType == FuelType.Petrol) tx(settings.language, "Benzinli Deneysel", "Petrol Experimental") else tx(settings.language, "1.5 dCi Doğrulanmış", "1.5 dCi Verified"),
                            onClick = {
                                if (settings.fuelType == FuelType.Petrol) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Doğrulanmış dizel profile dönülsün mü?", "Return to the verified diesel profile?"),
                                            tx(settings.language, "Araç profili 1.5 dCi 68 bg / Delphi DCM1.2 olarak ayarlanacak. Aktif OBD bağlantısı varsa yeniden bağlanmanız gerekir.", "The vehicle profile will be set to 1.5 dCi 68 hp / Delphi DCM1.2. Reconnect if OBD is currently active."),
                                            tx(settings.language, "Dizel Profile Geç", "Use Diesel Profile")
                                        ) {
                                            onSettingsChange(
                                                settings.copy(
                                                    engine = "1.5 dCi 68 bg",
                                                    fuelType = FuelType.Diesel,
                                                    profileSupport = VehicleProfileSupport.Verified,
                                                    modelYearText = "2006",
                                                    engineCodeText = "K9K",
                                                    engineDisplacementCcText = "1461",
                                                    enginePowerHpText = "68",
                                                    cylinderCount = 4,
                                                    experimentalProfileAccepted = false
                                                )
                                            )
                                        }
                                    )
                                } else {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Benzinli deneysel profil açılsın mı?", "Enable the experimental petrol profile?"),
                                            tx(settings.language, "Bu profil henüz uyumlu kabul edilmez. RPM, hız ve hararet gibi temel veriler çalışabilir; tüketim ve maliyet gösterilmez. Salt-okunur OBD test kayıtlarını paylaşarak geliştirmeye katkıda bulunabilirsiniz. Aktif bağlantı varsa yeniden bağlanmanız gerekir.", "This profile is not yet considered compatible. Basic values such as RPM, speed and coolant may work; consumption and cost are hidden. You can help development by sharing read-only OBD test records. Reconnect if OBD is active."),
                                            tx(settings.language, "Deneysel Profili Aç", "Enable Experimental Profile")
                                        ) {
                                            onSettingsChange(
                                                settings.copy(
                                                    engine = "Benzinli motor • Topluluk testi",
                                                    fuelType = FuelType.Petrol,
                                                    profileSupport = VehicleProfileSupport.Experimental,
                                                    modelYearText = settings.modelYearText.ifBlank { "2006" },
                                                    engineCodeText = "",
                                                    engineDisplacementCcText = "1390",
                                                    enginePowerHpText = "75",
                                                    cylinderCount = 4,
                                                    experimentalProfileAccepted = true,
                                                    fuelCalibrationEnabled = false
                                                )
                                            )
                                        }
                                    )
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Araç", "Vehicle"),
                            vehicleProfileSubtitle(settings),
                            settings.vehicleModel,
                            onClick = {
                                openDialog(
                                    SettingsDialog.Info(
                                        tx(settings.language, "Araç Profili", "Vehicle Profile"),
                                        vehicleProfileInfo(settings)
                                    )
                                )
                            }
                        )
                    }
                    if (settings.fuelType == FuelType.Petrol) {
                        item { SettingsRow(palette, tx(settings.language, "Model Yılı", "Model Year"), tx(settings.language, "Destek paketi araç kimliği", "Vehicle identity for support packages"), settings.modelYearText, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Model Yılı", "Model Year"), settings.modelYearText, "2006") { v -> onSettingsChange(settings.copy(modelYearText = v.filter(Char::isDigit).take(4))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Hacmi", "Engine Displacement"), tx(settings.language, "Santimetreküp (cc)", "Cubic centimeters (cc)"), "${settings.engineDisplacementCcText} cc", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Hacmi", "Engine Displacement"), settings.engineDisplacementCcText, "1390") { v -> onSettingsChange(settings.copy(engineDisplacementCcText = v.filter(Char::isDigit).take(5))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Kodu", "Engine Code"), tx(settings.language, "Bilinmiyorsa boş bırakılabilir", "May be left blank if unknown"), settings.engineCodeText.ifBlank { "--" }, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Kodu", "Engine Code"), settings.engineCodeText, "K7J") { v -> onSettingsChange(settings.copy(engineCodeText = v.uppercase().take(20))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Gücü", "Engine Power"), tx(settings.language, "Beygir gücü", "Horsepower"), "${settings.enginePowerHpText} bg", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Gücü", "Engine Power"), settings.enginePowerHpText, "75") { v -> onSettingsChange(settings.copy(enginePowerHpText = v.filter(Char::isDigit).take(4))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Silindir Sayısı", "Cylinder Count"), tx(settings.language, "Destek paketi ve gelecekteki ECU profili için", "For the support package and a future ECU profile"), settings.cylinderCount.toString(), onClick = { openDialog(SettingsDialog.Options(tx(settings.language, "Silindir Sayısı", "Cylinder Count"), (1..12).map(Int::toString)) { label -> onSettingsChange(settings.copy(cylinderCount = label.toIntOrNull()?.coerceIn(1, 12) ?: settings.cylinderCount)) }) }) }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), tx(settings.language, "Gösterge kilometresini kalibre et", "Calibrate the dashboard odometer"), settings.odometerText, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), settings.odometerText, tx(settings.language, "Örn. 335420", "e.g. 335420")) { v -> onSettingsChange(settings.copy(odometerText = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Motor Yağı", "Engine Oil"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.oilServiceKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Yağı Aralığı", "Engine Oil Interval"), settings.oilServiceKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(oilServiceKm = v)) }) }) }
                    item { SettingsRow(palette, if (settings.fuelType == FuelType.Petrol) tx(settings.language, "Yakıt Filtresi", "Fuel Filter") else tx(settings.language, "Mazot Filtresi", "Fuel Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.fuelFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Mazot Filtresi Aralığı", "Fuel Filter Interval"), settings.fuelFilterKm, tx(settings.language, "Örn. 20000", "e.g. 20000")) { v -> onSettingsChange(settings.copy(fuelFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Hava Filtresi", "Air Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.airFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Hava Filtresi Aralığı", "Air Filter Interval"), settings.airFilterKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(airFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Polen Filtresi", "Cabin Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.pollenFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Polen Filtresi Aralığı", "Cabin Filter Interval"), settings.pollenFilterKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(pollenFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Triger Seti", "Timing Belt Kit"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.timingBeltKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Triger Seti Aralığı", "Timing Belt Interval"), settings.timingBeltKm, tx(settings.language, "Örn. 60000", "e.g. 60000")) { v -> onSettingsChange(settings.copy(timingBeltKm = v)) }) }) }
                }
                SettingsCategory.Connection -> {
                    item {
                        ObdConnectionPanel(
                            palette = palette,
                            obdState = obdState,
                            demoMode = settings.demoMode,
                            onRefresh = onRefreshObdDevices,
                            onSelect = onSelectObdDevice,
                            onConnect = onConnectObd,
                            onDisconnect = onDisconnectObd,
                            language = settings.language
                        )
                    }
                }
                SettingsCategory.TripRecords -> {
                    item { SettingsSectionHeader(palette, tx(settings.language, "SÜRÜŞ AYARLARI", "TRIP SETTINGS")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yeni sürüş ayırma süresi", "New trip break time"),
                            tx(
                                settings.language,
                                "Kısa molalarda sürüş aynı kayıtta kalır. Seçilen süre aşılırsa yeni sürüş başlatılır.",
                                "Short stops stay in the same record. A new trip starts when the selected time is exceeded."
                            ),
                            smartTripLabel(settings.smartTripMinutes, settings.language),
                            subtitleMaxLines = 3,
                            onClick = {
                                val minutes = listOf(0, 15, 30, 60, 90, 120)
                                val options = minutes.map { smartTripLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yeni sürüş ayırma süresi", "New trip break time"), options) { label ->
                                    minutes.firstOrNull { smartTripLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(smartTripMinutes = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "GPS rota kaydı", "GPS route recording"),
                            if (settings.deviceMode == DeviceMode.HeadUnit) {
                                tx(settings.language, "İlk sürümde yalnız Telefon modu desteklenir.", "The first release supports Phone mode only.")
                            } else {
                                tx(settings.language, "Sürüş sırasında rotayı cihazda kaydeder.", "Records the route on this device while driving.")
                            },
                            trailingSwitch = settings.gpsRouteEnabled,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "GPS rota kaydı", "GPS route recording"),
                                            tx(
                                                settings.language,
                                                "LoganOS sürüş rotasını GPS ile cihazınızda kaydeder ve tamamlanan sürüş analizinde harita üzerinde gösterir. Rota, Sürüş Geçmişi kaydına bağlı olduğu için bu özelliği açmak otomatik sürüş geçmişini de açar. Konum izni verilmezse LoganOS, OBD ve sürüş kaydı normal çalışmaya devam eder; yalnız rota özelliği kapalı kalır. Rota verisi destek paketlerine eklenmez ve varsayılan yedekten hariç tutulur.",
                                                "LoganOS records your driving route with GPS on this device and shows it on the completed-drive analysis map. Because routes belong to Drive History records, enabling this feature also enables automatic drive history. If location permission is denied, LoganOS, OBD and drive recording continue normally; only route recording stays disabled. Route data is excluded from support packages and the default backup."
                                            ),
                                            tx(settings.language, "Konum iznine devam et", "Continue to location permission")
                                        ) { onSettingsChange(settings.copy(gpsRouteEnabled = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(gpsRouteEnabled = false))
                                }
                            }
                        )
                    }
                    if (settings.gpsRouteEnabled) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "GPX başlangıç/bitiş gizliliği", "GPX start/end privacy"),
                                tx(settings.language, "Dışa aktarılan rotanın ilk ve son yaklaşık 200 metresini gizler.", "Hides roughly the first and last 200 meters of the exported route."),
                                trailingSwitch = settings.gpsMaskExportEdges,
                                onSwitch = { enabled -> onSettingsChange(settings.copy(gpsMaskExportEdges = enabled)) }
                            )
                        }
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşü şimdi bitir", "End trip now"),
                            tx(settings.language, "Mevcut geçmiş kaydını tamamlar ve yeni sürüş bekler.", "Completes the current history record and waits for a new trip."),
                            tx(settings.language, "Bitir", "End"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Sürüş şimdi bitirilsin mi?", "End trip now?"),
                                    tx(settings.language, "Mevcut sürüş geçmişi kaydı tamamlanacak. Kokpit mesafe, yakıt, süre, ortalama ve maliyet toplamları korunacak.", "The current drive-history record will be completed. Cockpit distance, fuel, time, average and cost totals will be preserved."),
                                    tx(settings.language, "Sürüşü bitir", "End trip")
                                ) { onEndTripNow() })
                            }
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "GEÇMİŞ", "HISTORY")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüş ve test geçmişi", "Drive and test history"),
                            tx(
                                settings.language,
                                "${obdState.historyStorage.driveRecordCount} sürüş • ${obdState.historyStorage.testRecordCount} test • ${formatHistoryBytes(obdState.historyStorage.databaseBytes)}",
                                "${obdState.historyStorage.driveRecordCount} drives • ${obdState.historyStorage.testRecordCount} tests • ${formatHistoryBytes(obdState.historyStorage.databaseBytes)}"
                            ),
                            tx(settings.language, "Görüntüle", "View"),
                            onClick = {
                                onRefreshHistory()
                                onOpenTripHistory()
                            }
                        )
                    }
                    item {
                        val recordCount = obdState.historyStorage.driveRecordCount + obdState.historyStorage.testRecordCount
                        SettingsRow(
                            palette,
                            tx(settings.language, "Tüm geçmişi dışa aktar", "Export all history"),
                            when {
                                obdState.exportInProgress -> tx(settings.language, "Dışa aktarma paketi hazırlanıyor.", "The export package is being prepared.")
                                recordCount <= 0 -> tx(settings.language, "Dışa aktarılacak sürüş veya test kaydı yok.", "There are no drive or test records to export.")
                                else -> tx(settings.language, "Sürüş ve test kayıtlarını tek paket halinde dışa aktarır.", "Exports drive and test records in one package.")
                            },
                            if (obdState.exportInProgress) tx(settings.language, "Hazırlanıyor…", "Preparing…") else tx(settings.language, "Dışa aktar", "Export"),
                            onClick = if (!obdState.exportInProgress && recordCount > 0) onExportAllHistory else null
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "KAYIT AYARLARI", "RECORDING SETTINGS")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşleri otomatik kaydet", "Save drives automatically"),
                            tx(settings.language, "Tamamlanan sürüşleri geçmişte saklar.", "Keeps completed drives in history."),
                            trailingSwitch = settings.driveHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik sürüş kaydı kapatılsın mı?", "Disable automatic drive history?"),
                                            tx(settings.language, "Yeni sürüşler geçmişe eklenmeyecek. Mevcut kayıtlar silinmez; canlı kokpit ve yol bilgisayarı çalışmaya devam eder.", "New drives will not be added to history. Existing records will remain; the live cockpit and trip computer will continue to work."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(driveHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(driveHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"),
                            tx(settings.language, "Sabitlenen kayıtlar bu sınıra dahil edilmez.", "Pinned records do not count toward this limit."),
                            historyLimitLabel(settings.driveHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.driveHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.driveHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Sürüşler siz silene kadar saklanır ve zamanla depolama alanı kullanabilir.", "Drives will remain until you delete them and may use more storage over time."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski sürüşler silinsin mi?", "Delete older drives?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan sürüş kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned drives."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(driveHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Testleri otomatik kaydet", "Save tests automatically"),
                            tx(settings.language, "Manuel ve geliştirici testlerini geçmişte saklar.", "Keeps manual and developer tests in history."),
                            trailingSwitch = settings.testHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik test kaydı kapatılsın mı?", "Disable automatic test history?"),
                                            tx(settings.language, "Yeni manuel ve geliştirici testleri Test Geçmişi'ne eklenmeyecek. Mevcut test kayıtları silinmez.", "New manual and developer tests will not be added to Test History. Existing test records will remain."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(testHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(testHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Test geçmişi sınırı", "Test history limit"),
                            tx(settings.language, "Sabitlenen testler otomatik silinmez.", "Pinned tests are never auto-deleted."),
                            historyLimitLabel(settings.testHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Test geçmişi sınırı", "Test history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.testHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.testHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Test kayıtları siz silene kadar saklanır ve zamanla depolama alanı kullanabilir.", "Test records will remain until you delete them and may use more storage over time."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski testler silinsin mi?", "Delete older tests?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan test kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned tests."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(testHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "VERİ YÖNETİMİ", "DATA MANAGEMENT")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yedekleme ve veri yönetimi", "Backup & data management"),
                            tx(settings.language, "Ayarları ve kayıtları yedekle, geri yükle veya temizle.", "Back up, restore or clear settings and records."),
                            onClick = { tripRecordsSubPage = TripRecordsSubPage.DataManagement }
                        )
                    }
                }
                SettingsCategory.Developer -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Geliştirici Modu", "Developer Mode"),
                            tx(settings.language, "Testler ve teknik tanılama seçeneklerini açar.", "Enables tests and technical diagnostic options."),
                            trailingSwitch = settings.developerModeEnabled,
                            onSwitch = { enabled ->
                                onSettingsChange(
                                    settings.copy(
                                        developerModeEnabled = enabled,
                                        rawEcuLogEnabled = if (enabled) settings.rawEcuLogEnabled else false
                                    )
                                )
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Demo Modu", "Demo Mode"),
                            tx(settings.language, "Bu oturumda simülasyon kullanır ve gerçek OBD bağlantısını kapatır.", "Uses simulation for this session and closes the real OBD connection."),
                            trailingSwitch = settings.demoMode,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Demo Modu", "Demo Mode"),
                                            tx(settings.language, "Bu mod gerçek araç verisi göstermez. Açılırsa mevcut OBD bağlantısı ve bekleyen yeniden bağlanma işlemi kapatılır. Uygulama yeniden açıldığında Demo Modu kapalı başlar.", "This mode does not show real vehicle data. Enabling it closes the current OBD connection and pending reconnect. Demo Mode starts disabled after reopening the app."),
                                            tx(settings.language, "Demo Modunu Aç", "Enable Demo Mode")
                                        ) { onSettingsChange(settings.copy(demoMode = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(demoMode = false))
                                }
                            }
                        )
                    }
                    if (settings.developerModeEnabled) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Geliştirici Ham Log", "Developer Raw Log"),
                                tx(settings.language, "Ham ECU paketlerini ayrıca kaydeder; normalde kapalı kalmalıdır.", "Stores raw ECU packets separately; normally keep this disabled."),
                                trailingSwitch = settings.rawEcuLogEnabled,
                                onSwitch = { onSettingsChange(settings.copy(rawEcuLogEnabled = it)) }
                            )
                        }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Geliştirici testleri", "Developer tests"),
                                tx(settings.language, "Yalnız devam eden el freni sinyali doğrulaması.", "Only the remaining handbrake-signal validation."),
                                onClick = { developerSubPage = DeveloperSubPage.Tests }
                            )
                        }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Teknik kayıt geçmişi", "Technical log history"),
                                tx(settings.language, "Teknik oturumları görüntüle, dışa aktar veya destek paketi oluştur.", "View and export technical sessions or create a support package."),
                                onClick = { developerSubPage = DeveloperSubPage.TechnicalHistory }
                            )
                        }
                    }
                }
                SettingsCategory.Support -> {
                    item {
                        Text(
                            tx(
                                settings.language,
                                "Mesaj doğrudan loganos.support@gmail.com adresine hazırlanır. LoganOS e-postayı kendi başına göndermez; telefonunuzdaki e-posta uygulaması açılır ve son gönderme onayı sizde kalır.",
                                "The message is prepared for loganos.support@gmail.com. LoganOS does not send it silently; your email app opens and you keep final control."
                            ),
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Bildirim türü", "Message type"),
                            tx(settings.language, "Sorun veya geri bildirim kategorisini seçin.", "Choose the issue or feedback category."),
                            supportType,
                            onClick = {
                                val options = if (settings.language == AppLanguage.English) {
                                    listOf("Report a bug", "OBD connection support", "Report incorrect data", "Send test result", "Suggestion & feedback", "Other")
                                } else {
                                    listOf("Hata bildir", "OBD bağlantı desteği", "Yanlış veri bildir", "Test sonucunu gönder", "Öneri ve geri bildirim", "Diğer")
                                }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Bildirim türü", "Message type"), options) { supportType = it })
                            }
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = supportMessage,
                            onValueChange = { supportMessage = it.take(6000) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text(tx(settings.language, "Açıklamanız", "Your description")) },
                            placeholder = {
                                Text(
                                    tx(
                                        settings.language,
                                        "Ne oldu, ne zaman oldu ve tekrar edilebiliyor mu? Mümkünse izlediğiniz adımları yazın.",
                                        "What happened, when did it happen, and can it be reproduced? Include the steps when possible."
                                    )
                                )
                            },
                            minLines = 7,
                            maxLines = 12
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Teknik kayıt ZIP’ini ekle", "Attach technical log ZIP"),
                            tx(
                                settings.language,
                                "Açıkken son geçerli teknik kayıtlar otomatik hazırlanır ve e-postaya eklenir. Dosya seçmeniz gerekmez; GPS rotası, VIN, plaka ve şifre eklenmez.",
                                "When enabled, recent valid technical logs are prepared and attached automatically. You do not need to select a file; GPS routes, VIN, plate and passwords are excluded."
                            ),
                            trailingSwitch = includeSupportPackage,
                            onSwitch = { includeSupportPackage = it }
                        )
                    }
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 4.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                tx(
                                    settings.language,
                                    "Yazdığınız açıklama, alıcı, konu, cihaz bilgileri ve seçili teknik ZIP e-postaya otomatik aktarılır. E-posta uygulamasında yalnız son gönderme onayını verirsiniz.",
                                    "Your description, recipient, subject, device details and selected technical ZIP are transferred automatically. You only confirm the final send action in the email app."
                                ),
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                lineHeight = 17.sp
                            )
                            Button(
                                onClick = { openSupportEmail() },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(58.dp),
                                shape = RoundedCornerShape(18.dp)
                            ) {
                                Text(
                                    tx(settings.language, "E-postayı hazırla ve gönder", "Prepare and send email"),
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Black
                                )
                            }
                        }
                    }
                    item {
                        Text(
                            tx(
                                settings.language,
                                "Destek adresi: loganos.support@gmail.com\nŞifre, VIN, plaka veya konum bilgisi otomatik eklenmez.",
                                "Support address: loganos.support@gmail.com\nPasswords, VIN, plate or location data are never added automatically."
                            ),
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
                SettingsCategory.Updates -> {
                    item {
                        SecureUpdateSettingsPanel(
                            palette = palette,
                            language = settings.language
                        )
                    }
                }
                SettingsCategory.About -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
                            Text("LOGANOS", color = palette.textPrimary, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text(
                                tx(settings.language, "Sürüm ${BuildConfig.VERSION_NAME}", "Version ${BuildConfig.VERSION_NAME}"),
                                color = palette.accent,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                tx(settings.language, "Dacia Logan 1.5 dCi için geliştirilen bağımsız OBD ve dijital kokpit uygulaması.", "An independent OBD and digital cockpit application developed for the Dacia Logan 1.5 dCi."),
                                color = palette.textSecondary,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Teknik altyapı", "Technical foundation"))
                            AboutBody(palette, "Fuel Truth • Smart Trip")
                            AboutBody(palette, "Delphi DCM1.2 • KWP2000 Fast Init")

                            AboutSectionTitle(palette, tx(settings.language, "Proje", "Project"))
                            AboutBody(palette, tx(settings.language, "Ücretsiz, reklamsız ve GPLv3 açık kaynaklıdır.", "Free, ad-free and open source under GPLv3."))

                            AboutSectionTitle(palette, tx(settings.language, "Gizlilik", "Privacy"))
                            AboutBody(palette, tx(settings.language, "Veriler cihazda saklanır. Kayıtlar yalnızca kullanıcı dışa aktardığında cihaz dışına çıkar.", "Data is stored on the device. Records leave the device only when the user exports them."))

                            AboutSectionTitle(palette, tx(settings.language, "Bağımsızlık bildirimi", "Independence notice"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "LoganOS bağımsız olarak geliştirilmiştir. Renault Group veya Dacia ile resmî bağlantısı bulunmamaktadır.",
                                    "LoganOS is independently developed and is not officially affiliated with Renault Group or Dacia."
                                )
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Geliştirme araçları", "Development tools"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "Geliştirme sürecinde ChatGPT, Gemini ve Claude yapay zekâ araçlarından yararlanılmıştır.",
                                    "ChatGPT, Gemini and Claude AI tools were used during development."
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun SecureUpdateSettingsPanel(
    palette: LoganPalette,
    language: AppLanguage
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val manager = remember { SecureUpdateManager(context.applicationContext) }
    var state by remember { mutableStateOf<UpdateUiState>(manager.initialState()) }

    fun checkNow() {
        if (state is UpdateUiState.Checking || state is UpdateUiState.Downloading) return
        state = UpdateUiState.Checking
        scope.launch { state = manager.checkForUpdate() }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (manager.shouldAutoCheck()) checkNow()
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
        Text(
            tx(language, "Güvenli Güncelleme Merkezi", "Secure Update Center"),
            color = palette.textPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            tx(
                language,
                "Yeni LoganOS sürümlerini kontrol et, indir ve güvenli biçimde yükle.",
                "Check, download and securely install new LoganOS versions."
            ),
            color = palette.textSecondary,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )

        SettingsCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(
                    tx(language, "Mevcut sürüm", "Current version"),
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(BuildConfig.VERSION_NAME, color = palette.textPrimary, fontSize = 19.sp, fontWeight = FontWeight.Black)
            }
        }

        when (val current = state) {
            is UpdateUiState.Idle -> {
                current.lastCheckedAtMs?.let { checkedAt ->
                    Text(
                        tx(language, "Son kontrol", "Last check") + ": " + updateTimeText(checkedAt),
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
                UpdateActionButton(
                    palette,
                    tx(language, "Güncellemeleri kontrol et", "Check for updates"),
                    enabled = manager.isRepositoryConfigured(),
                    onClick = ::checkNow
                )
                if (!manager.isRepositoryConfigured()) {
                    Text(
                        tx(
                            language,
                            "Bu kaynak ZIP'inden yerel derleme yapılırsa depo kimliği boş kalabilir. GitHub Actions derlemesinde GITHUB_REPOSITORY otomatik olarak uygulamaya gömülür.",
                            "A local build from the source ZIP may have no repository identity. GitHub Actions automatically embeds GITHUB_REPOSITORY into the app."
                        ),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
            UpdateUiState.Checking -> {
                Text(tx(language, "Güvenli sürüm kontrolü yapılıyor…", "Checking securely for updates…"), color = palette.accent, fontWeight = FontWeight.Bold)
            }
            is UpdateUiState.UpToDate -> {
                Text(tx(language, "LoganOS güncel", "LoganOS is up to date"), color = palette.accent, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text(updateTimeText(current.checkedAtMs), color = palette.textSecondary, fontSize = 12.sp)
                UpdateActionButton(palette, tx(language, "Tekrar kontrol et", "Check again"), onClick = ::checkNow)
            }
            is UpdateUiState.Available -> {
                UpdateReleaseCard(palette, language, current.release.versionName, current.release.releaseNotes)
                UpdateActionButton(
                    palette,
                    tx(language, "İndir ve doğrula", "Download and verify")
                ) {
                    state = UpdateUiState.Downloading(current.release, 0)
                    scope.launch {
                        state = manager.downloadAndVerify(current.release) { progress ->
                            scope.launch { state = UpdateUiState.Downloading(current.release, progress) }
                        }
                    }
                }
            }
            is UpdateUiState.Downloading -> {
                Text(
                    tx(language, "Güncelleme indiriliyor ve doğrulanıyor", "Downloading and verifying update"),
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Black
                )
                Text("%${current.progressPercent}", color = palette.accent, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(
                    tx(language, "İmza doğrulanmadan kurulum başlatılmaz.", "Installation cannot start until the signature is verified."),
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            }
            is UpdateUiState.ReadyToInstall -> {
                UpdateReleaseCard(palette, language, current.release.versionName, current.release.releaseNotes)
                Text(
                    tx(language, "✓ APK kimliği ve imza sertifikası doğrulandı", "✓ APK identity and signing certificate verified"),
                    color = palette.accent,
                    fontWeight = FontWeight.Black
                )
                Text(
                    tx(language, "İmza SHA-256", "Signer SHA-256") + ": " + current.signerSha256.take(16) + "…",
                    color = palette.textSecondary,
                    fontSize = 11.sp
                )
                UpdateActionButton(palette, tx(language, "Android kurucusunu aç", "Open Android installer")) {
                    try {
                        when (manager.requestInstall(current.apkPath)) {
                            InstallLaunchResult.INSTALLER_OPENED -> Unit
                            InstallLaunchResult.UNKNOWN_SOURCES_SETTINGS_OPENED -> Unit
                        }
                    } catch (error: Exception) {
                        state = UpdateUiState.Error(error.message ?: tx(language, "Kurulum başlatılamadı", "Installation could not be started"))
                    }
                }
            }
            is UpdateUiState.Error -> {
                Text(
                    tx(language, "İşlem tamamlanamadı", "The operation could not be completed"),
                    color = palette.textPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )
                Text(current.message, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
                UpdateActionButton(palette, tx(language, "Yeniden kontrol et", "Check again"), onClick = ::checkNow)
            }
        }

        SettingsCard(palette, modifier = Modifier.fillMaxWidth()) {
            Text(
                tx(
                    language,
                    "✓ Güncellemeler, mevcut LoganOS kurulumunun uygulama imzasıyla doğrulanır.",
                    "✓ Updates are verified against the signing identity of the installed LoganOS app."
                ),
                color = palette.accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun UpdateReleaseCard(
    palette: LoganPalette,
    language: AppLanguage,
    versionName: String,
    releaseNotes: String
) {
    SettingsCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(language, "Yeni sürüm mevcut", "New version available"), color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(versionName, color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
            if (releaseNotes.isNotBlank()) {
                Text(
                    releaseNotes.take(1200),
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    maxLines = 12
                )
            }
        }
    }
}

@Composable
private fun UpdateActionButton(
    palette: LoganPalette,
    label: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (enabled) palette.textPrimary else palette.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (enabled) palette.background else palette.textSecondary,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp
        )
    }
}

private fun updateTimeText(timeMs: Long): String =
    java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(timeMs))


@Composable
private fun AboutSectionTitle(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.accent,
        fontSize = 14.sp,
        fontWeight = FontWeight.Black
    )
}

@Composable
private fun AboutBody(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.textSecondary,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
}

@Composable
private fun SettingsSectionHeader(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 0.7.sp,
        modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 2.dp)
    )
}

private fun historyLimitOptions(language: AppLanguage): List<String> = listOf(
    "10", "25", "50", if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
)

private fun historyLimitFromLabel(label: String): Int = when {
    label.equals("Unlimited", true) || label.equals("Sınırsız", true) -> -1
    else -> label.toIntOrNull() ?: 10
}

private fun historyLimitLabel(limit: Int, language: AppLanguage): String =
    if (limit < 0) {
        if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
    } else limit.toString()

private fun formatHistoryBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(java.util.Locale.US, "%.1f KB", kb)
    return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
}


private fun controlDiscoveryPreviewDialog(
    language: AppLanguage,
    testName: String,
    onStart: () -> Unit
): SettingsDialog.GuidedControlTest {
    return when (testName) {
        CONTROL_HANDBRAKE_TEST_NAME -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = tx(language, "El freni sinyali son doğrulama", "Final handbrake-signal validation"),
            preparation = tx(
                language,
                "Pydroid veya pyjnius kullanılmaz. Motor KAPALI, kontak tamamen AÇIK olmalı; gösterge lambaları yanmalı. Araç düz zeminde tamamen sabit ve vites boşta olmalı. El freni indirilen aşamalarda ayak frenini basılı tutun.",
                "Pydroid or pyjnius is not used. Keep the engine OFF and ignition fully ON with the instrument lights illuminated. The vehicle must remain stationary on level ground and in neutral. Hold the foot brake during released-handbrake steps."
            ),
            sequence = tx(
                language,
                "İlk ÇEKİLİ aşamada 0x10–0x7F fiziksel KWP adresleri araştırılır ve cevap veren her modülde 2100–21FF tam taranır. İlk İNDİRİLMİŞ aşamada aynı tarama karşılaştırma için tekrarlanır. Değişen bloklar bulunursa üç ÇEKİLİ ve üç İNDİRİLMİŞ doğrulama aşamasında üçer tur okunur.",
                "The first ENGAGED step discovers physical KWP addresses 0x10–0x7F and scans 2100–21FF on every responding module. The first RELEASED step repeats the full scan for comparison. Changed blocks are then read in three passes across three ENGAGED and three RELEASED verification steps."
            ),
            duration = tx(language, "8 adım • yanıt veren modül sayısına göre yaklaşık 12–25 dakika", "8 steps • about 12–25 minutes depending on responding modules"),
            safety = tx(
                language,
                "El freni indirildiğinde araç yalnız ayak freniyle sabit tutulur. Eğimli zeminde yapmayın.",
                "When the handbrake is released, the vehicle is held only by the foot brake. Do not run this test on a slope."
            ),
            onStart = onStart
        )
        CONTROL_CLUTCH_TEST_NAME -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = tx(language, "Debriyaj keşfi", "Clutch discovery"),
            preparation = tx(
                language,
                "Motor çalışır, araç sabit, vites boşta ve el freni çekili olmalı.",
                "Keep the engine running, the vehicle stationary, the transmission in neutral and the handbrake engaged."
            ),
            sequence = tx(
                language,
                "Ekran debriyajı tamamen bırakılmış ve sonuna kadar basılmış konumlarda üçer kez tutmanızı ister.",
                "The screen asks you to hold the clutch fully released and fully pressed three times each."
            ),
            duration = tx(language, "6 adım × 5 saniye • toplam yaklaşık 3 dakika", "6 steps × 5 seconds • about 3 minutes total"),
            safety = tx(
                language,
                "Vitesi test boyunca boşta bırakın. Ekran istemeden aracı vitese geçirmeyin.",
                "Leave the transmission in neutral throughout the test. Do not select a gear unless the screen asks you to."
            ),
            onStart = onStart
        )
        CONTROL_BRAKE_TEST_NAME -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = tx(language, "Fren pedalı keşfi", "Brake pedal discovery"),
            preparation = tx(
                language,
                "Motor çalışır, araç sabit, vites boşta ve el freni tam çekili olmalı.",
                "Keep the engine running, the vehicle stationary, the transmission in neutral and the handbrake fully engaged."
            ),
            sequence = tx(
                language,
                "Ekran fren pedalını bırakılmış ve normal kuvvetle basılı konumlarda üçer kez tutmanızı ister.",
                "The screen asks you to hold the brake pedal released and pressed with normal force three times each."
            ),
            duration = tx(language, "6 adım × 5 saniye • toplam yaklaşık 3 dakika", "6 steps × 5 seconds • about 3 minutes total"),
            safety = tx(
                language,
                "Fren bırakma adımları yalnız el freni aracı güvenle sabit tutuyorsa uygulanmalıdır.",
                "Release the foot brake only when the handbrake can safely hold the vehicle stationary."
            ),
            onStart = onStart
        )
        CONTROL_GEAR_STATIC_TEST_NAME -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = tx(language, "Sabit araçta vites keşfi", "Stationary gear discovery"),
            preparation = tx(
                language,
                "Motor rölantide, araç tamamen sabit, el freni çekili; ayak freni ve debriyaj sonuna kadar basılı olmalı.",
                "Keep the engine idling, the vehicle fully stationary, the handbrake engaged and both the foot brake and clutch fully pressed."
            ),
            sequence = tx(
                language,
                "Boş → 1 → Boş → 2 → Boş → 3 → Boş → 4 → Boş → 5 → Boş → Geri → Boş. Her konum 4–5 saniye tutulur.",
                "N → 1 → N → 2 → N → 3 → N → 4 → N → 5 → N → R → N. Each position is held for 4–5 seconds."
            ),
            duration = tx(language, "13 yönlendirmeli adım • toplam yaklaşık 5 dakika", "13 guided steps • about 5 minutes total"),
            safety = tx(
                language,
                "Debriyajı hiçbir adımda bırakmayın ve aracı hareket ettirmeyin. Geri vitese geçerken de araç tamamen sabit kalmalıdır.",
                "Do not release the clutch or move the vehicle at any step. The vehicle must remain fully stationary when selecting reverse."
            ),
            onStart = onStart
        )
        CONTROL_GEAR_DRIVE_TEST_NAME -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = tx(language, "Sürüşte vites oranları", "Driving gear ratios"),
            preparation = tx(
                language,
                "Testi güvenli bir yerde araç dururken ve motor çalışırken başlatın. Telefonu sabitleyin; sürüş başlamadan önce ekranı okuyun.",
                "Start while safely stopped with the engine running. Secure the phone and read the instructions before moving."
            ),
            sequence = tx(
                language,
                "Ekran sırasıyla 1, 2, 3, 4 ve 5. viteste kısa süre sabit ilerlemenizi ister. Uygun hız oluşmadan sayaç başlamaz.",
                "The screen asks you to drive steadily for a short time in gears 1 through 5. The countdown does not start until the required speed is reached."
            ),
            duration = tx(language, "5 sürüş adımı • toplam yaklaşık 5 dakika", "5 driving steps • about 5 minutes total"),
            safety = tx(
                language,
                "Sürüş sırasında telefona dokunmayın. Yol, trafik veya hız sınırı uygun değilse testi başlatmayın ya da güvenli yerde durdurun.",
                "Do not touch the phone while driving. Do not start, or stop safely, if road, traffic or speed-limit conditions are unsuitable."
            ),
            onStart = onStart
        )
        else -> SettingsDialog.GuidedControlTest(
            testName = testName,
            title = testName,
            preparation = tx(language, "Araç ve OBD bağlantısını ekrandaki açıklamaya göre hazırlayın.", "Prepare the vehicle and OBD connection as described on screen."),
            sequence = tx(language, "Bir sonraki yönerge gelene kadar mevcut konumu koruyun.", "Hold the current state until the next instruction appears."),
            duration = tx(language, "Yaklaşık 3–5 dakika", "About 3–5 minutes"),
            safety = tx(language, "Testi yalnız güvenli koşullarda uygulayın.", "Run the test only under safe conditions."),
            onStart = onStart
        )
    }
}

@Composable
private fun GuidedControlTestDialog(
    palette: LoganPalette,
    dialog: SettingsDialog.GuidedControlTest,
    language: AppLanguage,
    obdState: ObdState,
    onDismiss: () -> Unit
) {
    LaunchedEffect(obdState.activeDeveloperTest, dialog.testName) {
        if (obdState.activeDeveloperTest == dialog.testName) onDismiss()
    }
    val anotherTestActive = obdState.activeDeveloperTest != null && obdState.activeDeveloperTest != dialog.testName
    val obdLabel = when {
        obdState.connected -> tx(language, "OBD bağlı", "OBD connected")
        obdState.connecting -> tx(language, "OBD bağlanıyor", "OBD connecting")
        else -> tx(language, "OBD bağlı değil; Başlat düğmesi otomatik bağlantıyı deneyecek", "OBD is not connected; Start will attempt automatic connection")
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 21.sp)
                Text(dialog.duration, color = palette.accent, fontWeight = FontWeight.Black, fontSize = 14.sp)
            }
        },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(tx(language, "HAZIRLIK", "PREPARATION"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(dialog.preparation, color = palette.textSecondary, fontSize = 14.sp, lineHeight = 19.sp)
                Text(tx(language, "TEST SIRASI", "TEST SEQUENCE"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(dialog.sequence, color = palette.textSecondary, fontSize = 14.sp, lineHeight = 19.sp)
                Text(tx(language, "GÜVENLİK", "SAFETY"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 12.sp)
                Text(dialog.safety, color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                Text(obdLabel, color = if (obdState.connected) palette.accent else palette.blue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                if (!obdState.status.isNullOrBlank()) {
                    Text(obdState.status, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 16.sp)
                }
                if (anotherTestActive) {
                    Text(
                        tx(language, "Önce aktif testi bitirin: ${obdState.activeDeveloperTest}", "Finish the active test first: ${obdState.activeDeveloperTest}"),
                        color = palette.accent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = !anotherTestActive,
                onClick = dialog.onStart
            ) {
                Text(tx(language, "Hazırım • Testi başlat", "Ready • Start test"), fontWeight = FontWeight.Black)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(tx(language, "Şimdi değil", "Not now"))
            }
        }
    )
}

@Composable
private fun Dynamic026TestRow(
    palette: LoganPalette,
    obdState: ObdState,
    language: AppLanguage,
    testName: String,
    description: String,
    onStart: (String) -> Unit,
    onEnd: () -> Unit,
    displayTitle: String = testName
) {
    val running = obdState.activeDeveloperTest == testName
    val latest = obdState.testHistory.firstOrNull { it.name == testName }
    val statusText = when (latest?.status) {
        "COMPLETED" -> tx(language, "Tamamlandı", "Completed")
        "COMPLETED_MANUAL", "PARTIAL" -> tx(language, "Kısmi sonuç kaydedildi", "Partial result saved")
        "USER_CANCELLED", "USER_CANCELLED_NO_DATA" -> tx(language, "Kullanıcı iptal etti", "Cancelled by user")
        "FAILED_NO_DATA", "FAILED_TIMEOUT" -> tx(language, "ECU verisi alınamadı", "No ECU data")
        "INTERRUPTED" -> tx(language, "Yarım kaldı", "Interrupted")
        "ERROR" -> tx(language, "Hata ile bitti", "Ended with error")
        "ACTIVE" -> tx(language, "Aktif", "Active")
        else -> tx(language, "Henüz yapılmadı", "Not run yet")
    }
    val liveDetail = if (running) {
        buildString {
            append(obdState.developerTestPhaseText ?: tx(language, "Hazırlanıyor", "Preparing"))
            obdState.developerTestProgressPercent?.let { append(" • %$it") }
            obdState.developerTestCurrentTarget?.let { append(" • $it") }
            append("\n")
            append(tx(language, "Geçerli ${obdState.developerTestValidFrameCount} • Geçersiz ${obdState.developerTestInvalidFrameCount}", "Valid ${obdState.developerTestValidFrameCount} • Invalid ${obdState.developerTestInvalidFrameCount}"))
            obdState.developerTestExpectedPasses?.let { expected ->
                append(tx(language, " • Tur ${obdState.developerTestSuccessfulPasses}/$expected", " • Pass ${obdState.developerTestSuccessfulPasses}/$expected"))
            }
        }
    } else {
        tx(language, "$description\nDurum: $statusText", "$description\nStatus: $statusText")
    }
    SettingsRow(
        palette = palette,
        title = displayTitle,
        subtitle = liveDetail,
        value = when {
            running -> tx(language, "Aç ›", "Open ›")
            latest?.status == "COMPLETED" -> tx(language, "Yeniden", "Run again")
            else -> tx(language, "Başlat", "Start")
        },
        onClick = { onStart(testName) }
    )
}

@Composable
private fun DeveloperTestRows(
    palette: LoganPalette,
    obdState: ObdState,
    language: AppLanguage,
    onStart: (String) -> Unit,
    onEnd: () -> Unit
) {
    val activeTest = obdState.activeDeveloperTest
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (activeTest != null) {
            val activeSupported = isActiveDeveloperTestName(activeTest)
            SettingsRow(
                palette = palette,
                title = if (activeSupported) {
                    tx(language, "Aktif test: El freni sinyali son doğrulama", "Active test: Final handbrake-signal validation")
                } else {
                    tx(language, "Kaldırılmış test bulundu", "Retired test found")
                },
                subtitle = if (activeSupported) {
                    buildString {
                        append(obdState.developerTestPhaseText ?: tx(language, "Hazırlanıyor", "Preparing"))
                        obdState.developerTestProgressPercent?.let { append(" • %$it") }
                        obdState.developerTestElapsedSec?.let { append(" • ${formatSettingsDuration(it)}") }
                        append("\n")
                        append(tx(language, "Geçerli ${obdState.developerTestValidFrameCount} • Geçersiz ${obdState.developerTestInvalidFrameCount}", "Valid ${obdState.developerTestValidFrameCount} • Invalid ${obdState.developerTestInvalidFrameCount}"))
                        obdState.developerTestExpectedPasses?.let { expected ->
                            append(tx(language, " • Tur ${obdState.developerTestSuccessfulPasses}/$expected", " • Pass ${obdState.developerTestSuccessfulPasses}/$expected"))
                        }
                    }
                } else {
                    tx(
                        language,
                        "$activeTest araştırması artık başlatılamaz. Önceki kayıt silinmeden yalnız aktif durum kapatılacak.",
                        "$activeTest can no longer be started. Only the active state will be closed; existing history is preserved."
                    )
                },
                value = if (activeSupported) tx(language, "Aç ›", "Open ›") else tx(language, "Kapat", "Close"),
                onClick = { if (activeSupported) onStart(activeTest) else onEnd() }
            )
        }

        Dynamic026TestRow(
            palette = palette,
            obdState = obdState,
            language = language,
            testName = CONTROL_HANDBRAKE_TEST_NAME,
            description = tx(
                language,
                "Motor kapalı, kontak açık ve araç düz zeminde sabitken çalışır. El freni çekili/indirilmiş durumları karşılaştırılır; yalnız salt-okuma 10C0/21xx komutları kullanılır. Sonuç, hareket halinde el freni uyarısının güvenilir olup olmayacağını belirleyecek.",
                "Runs with the engine off, ignition on and vehicle stationary on level ground. Engaged/released handbrake states are compared using read-only 10C0/21xx requests. The result determines whether a moving-with-handbrake warning can be implemented reliably."
            ),
            onStart = onStart,
            onEnd = onEnd,
            displayTitle = tx(language, "El freni sinyali son doğrulama", "Final handbrake-signal validation")
        )

        Text(
            tx(
                language,
                "Eski test sonuçları Test Geçmişi'nde kalır; bu temizlik hiçbir kayıt veya ZIP dosyasını silmez.",
                "Previous results remain in Test History; this cleanup does not delete any record or ZIP file."
            ),
            color = palette.textSecondary,
            fontSize = 11.sp,
            lineHeight = 15.sp
        )
    }
}



private fun formatSettingsDuration(seconds: Long): String {
    val safe = seconds.coerceAtLeast(0L)
    return "%02d:%02d".format(java.util.Locale.US, safe / 60L, safe % 60L)
}


private fun menuThemeLabel(theme: MenuTheme, language: AppLanguage): String =
    if (language == AppLanguage.English) theme.enLabel else theme.trLabel

private fun ghostOriginalAccentLabel(accent: GhostOriginalAccent, language: AppLanguage): String =
    if (language == AppLanguage.English) accent.enLabel else accent.trLabel

private fun gaugeStyleLabel(style: GaugeStyle, language: AppLanguage): String = when (style) {
    GaugeStyle.Digital -> "Digital OEM"
    GaugeStyle.DigitalV2 -> if (language == AppLanguage.English) "Digital V2" else "Dijital V2"
    GaugeStyle.ClassicOem -> "Classic"
    GaugeStyle.GhostSingle -> "Ghost Single"
    GaugeStyle.GhostDual -> "Ghost Dual"
    GaugeStyle.GhostSingleOriginal -> "Ghost Single Original"
    GaugeStyle.GhostDualOriginal -> "Ghost Dual Original"
}

private fun vehicleProfileSubtitle(settings: LoganSettings): String {
    return if (settings.fuelType == FuelType.Petrol) {
        "${settings.modelYearText} • ${settings.engineDisplacementCcText} cc • ${settings.enginePowerHpText} bg • ${if (settings.language == AppLanguage.English) "experimental petrol" else "deneysel benzinli"}"
    } else {
        "2005-2012 Sedan/MCV • ${settings.engine}"
    }
}

private fun vehicleProfileInfo(settings: LoganSettings): String {
    return if (settings.fuelType == FuelType.Petrol) {
        tx(
            settings.language,
            "Bu profil topluluk testi içindir. RPM, hız, hararet ve standart OBD parametreleri okunabilir. Tüketim ve maliyet, doğrudan enjeksiyon miktarı, enjeksiyon süresi veya ECU yakıt debisi doğrulanana kadar kapalıdır. Destek paketinde araç yılı, hacim, motor kodu, güç ve silindir bilgileri yer alır.",
            "This profile is for community testing. RPM, speed, coolant and standard OBD parameters may work. Consumption and cost stay disabled until a direct injection quantity, injector pulse width or ECU fuel-rate source is verified. Support packages include model year, displacement, engine code, power and cylinder count."
        )
    } else {
        tx(
            settings.language,
            "Tam destek 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. Diğer 1.5 dCi profilleri deneysel olarak değerlendirilir.",
            "Full support is for the 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 hp. Other 1.5 dCi profiles are treated as experimental."
        )
    }
}

private fun deviceModeLabel(mode: DeviceMode, language: AppLanguage): String = when (mode) {
    DeviceMode.Auto -> tx(language, "Otomatik", "Automatic")
    DeviceMode.Phone -> tx(language, "Telefon", "Phone")
    DeviceMode.HeadUnit -> tx(language, "Android Multimedya / Double", "Android Multimedia / Head Unit")
}

private fun headUnitUiModeLabel(mode: HeadUnitUiMode, language: AppLanguage): String =
    if (language == AppLanguage.English) mode.enLabel else mode.trLabel

private fun defaultMediaAppLabel(app: DefaultMediaApp, language: AppLanguage): String =
    if (language == AppLanguage.English) app.enLabel else app.trLabel

private fun smartTripLabel(minutes: Int, language: AppLanguage): String = when (minutes) {
    0 -> tx(language, "Her kontakta yeni sürüş", "New trip at every ignition")
    15 -> tx(language, "15 dakika", "15 minutes")
    30 -> tx(language, "30 dakika", "30 minutes")
    60 -> tx(language, "60 dakika", "60 minutes")
    90 -> tx(language, "90 dakika", "90 minutes")
    120 -> tx(language, "120 dakika", "120 minutes")
    else -> "$minutes ${tx(language, "dakika", "minutes")}"
}


private fun vehicleVisualSummary(settings: LoganSettings, language: AppLanguage): String {
    val model = when (settings.vehicleVisualModel) {
        com.dcui.loganos.model.VehicleVisualModel.LoganI -> "Logan I"
        com.dcui.loganos.model.VehicleVisualModel.LoganIII -> "Logan III"
    }
    return "$model • ${vehicleColorLabel(settings.vehicleColor, language)}"
}

private fun vehicleColorLabel(color: VehicleColor, language: AppLanguage): String =
    if (language == AppLanguage.English) color.enLabel else color.trLabel

private fun cockpitTextSizeLabel(size: CockpitTextSize, language: AppLanguage): String =
    if (language == AppLanguage.English) size.enLabel else size.trLabel

private fun cockpitDensityLabel(density: CockpitDensity, language: AppLanguage): String =
    if (language == AppLanguage.English) density.enLabel else density.trLabel

private fun fuelPriceDisplay(raw: String, language: AppLanguage): String {
    val value = raw.replace(',', '.').toDoubleOrNull() ?: return tx(language, "Girilmedi", "Not set")
    return String.format(java.util.Locale("tr", "TR"), "%.2f TL/L", value)
}

private fun parseCalibrationNumber(raw: String): Double? {
    return raw.trim().replace(',', '.').toDoubleOrNull()
}

@Composable
private fun OptionDialog(palette: LoganPalette, dialog: SettingsDialog.Options, language: AppLanguage, onDismiss: () -> Unit) {
    androidx.compose.ui.window.Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)
    ) {
        androidx.compose.material3.Surface(
            shape = RoundedCornerShape(24.dp),
            color = palette.surface,
            tonalElevation = 6.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 560.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 440.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        dialog.options.forEach { option ->
                            Text(
                                option,
                                color = palette.textPrimary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onDismiss(); dialog.onSelect(option) }
                                    .background(palette.surfaceVariant)
                                    .padding(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TextInputDialog(palette: LoganPalette, dialog: SettingsDialog.TextInput, language: AppLanguage, onDismiss: () -> Unit) {
    var value by remember(dialog.title) { mutableStateOf(dialog.initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(dialog.hint) }, singleLine = true)
                if (dialog.title == "Yakıt Fiyatı" || dialog.title == "Fuel Price") {
                    Text(
                        tx(language, "Daha doğru maliyet hesabı için, yakıt aldığınız zamanki litre fiyatını girin.", "For a more accurate cost calculation, enter the fuel price per liter at the time of refueling."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { dialog.onSave(value); onDismiss() }) { Text(tx(language, "Kaydet", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}

@Composable
private fun FuelCalibrationDialog(
    palette: LoganPalette,
    dialog: SettingsDialog.Calibration,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    var distanceText by remember(dialog.startTimeMs, dialog.autoDistanceKm) {
        mutableStateOf(dialog.initialDistanceText)
    }
    var pumpLiters by remember(dialog.startTimeMs) { mutableStateOf("") }

    val distanceValue = parseCalibrationNumber(distanceText)
    val pumpValue = parseCalibrationNumber(pumpLiters)
    val appValue = dialog.autoAppLiters
    val proposedFactor = if (
        dialog.sessionActive &&
        appValue != null &&
        appValue > 0.0 &&
        pumpValue != null &&
        pumpValue > 0.0
    ) {
        dialog.measurementFactor * (pumpValue / appValue)
    } else {
        null
    }
    val factorValid = proposedFactor != null && proposedFactor in 0.50..1.50
    val distanceValid = distanceValue != null && distanceValue > 0.0
    val realAverage = if (distanceValid && pumpValue != null && pumpValue > 0.0) {
        pumpValue / distanceValue!! * 100.0
    } else null
    val appAverage = if (distanceValid && appValue != null && appValue > 0.0) {
        appValue / distanceValue!! * 100.0
    } else null
    val shortMeasurement = distanceValue != null && distanceValue in 0.01..99.99

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                tx(language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                if (!dialog.sessionActive) {
                    Text(
                        tx(language, "Full depo ölçümü", "Full-tank measurement"),
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        fuelCalibrationStartHelpText(language),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    Text(
                        tx(language, "Mevcut kalibrasyon", "Current calibration") +
                            ": " +
                            (if (dialog.enabled) tx(language, "Açık", "On") else tx(language, "Kapalı", "Off")) +
                            " • x${String.format(Locale.US, "%.3f", dialog.currentFactor)}",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                    dialog.unavailableReason?.let {
                        Text(
                            it,
                            color = if (dialog.canStart) palette.warning else palette.critical,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (dialog.enabled) {
                        TextButton(
                            onClick = {
                                dialog.onReset()
                                onDismiss()
                            }
                        ) {
                            Text(tx(language, "Fabrika hesabına dön", "Return to factory calculation"))
                        }
                    }
                } else {
                    Text(
                        tx(
                            language,
                            "Depoyu yeniden aynı seviyeye kadar doldurduktan sonra pompadan alınan litreyi girin. LoganOS kendi hesapladığı litreyi otomatik kullanır.",
                            "After refilling to the same level, enter the liters taken from the pump. LoganOS uses its own calculated liters automatically."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    if (dialog.startTimeMs > 0L) {
                        Text(
                            tx(language, "Ölçüm başlangıcı", "Measurement started") +
                                ": ${formatCalibrationDate(dialog.startTimeMs)}",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    if (dialog.startOdometerKm > 0) {
                        Text(
                            tx(language, "Başlangıç kilometresi", "Starting odometer") +
                                ": ${dialog.startOdometerKm} km",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        tx(language, "LoganOS’un otomatik hesapladığı yakıt", "Fuel automatically calculated by LoganOS") +
                            ": " +
                            (appValue?.let { String.format(Locale.US, "%.2f L", it) } ?: "--"),
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = distanceText,
                        onValueChange = { distanceText = it },
                        label = { Text(tx(language, "Gidilen mesafe (km)", "Distance driven (km)")) },
                        supportingText = {
                            Text(
                                tx(
                                    language,
                                    "LoganOS otomatik doldurur; gösterge kilometrenize göre düzeltebilirsiniz.",
                                    "LoganOS fills this automatically; you may correct it using the vehicle odometer."
                                )
                            )
                        },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = pumpLiters,
                        onValueChange = { pumpLiters = it },
                        label = { Text(tx(language, "Pompadan alınan litre", "Liters from the pump")) },
                        singleLine = true
                    )
                    dialog.unavailableReason?.let {
                        Text(
                            it,
                            color = palette.critical,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (shortMeasurement) {
                        Text(
                            tx(
                                language,
                                "100 km’den kısa ölçümlerde dolum farklarının etkisi daha büyüktür. 200–300 km ölçüm daha güvenilir sonuç verir.",
                                "Refill differences have a larger effect below 100 km. A 200–300 km measurement is more reliable."
                            ),
                            color = palette.warning,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                    if (realAverage != null && appAverage != null) {
                        Text(
                            tx(language, "Pompa ortalaması", "Pump average") +
                                ": ${String.format(Locale.US, "%.2f L/100 km", realAverage)}",
                            color = palette.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            tx(language, "LoganOS ortalaması", "LoganOS average") +
                                ": ${String.format(Locale.US, "%.2f L/100 km", appAverage)}",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = when {
                            factorValid -> tx(language, "Önerilen yeni katsayı", "Suggested new coefficient") +
                                ": x${String.format(Locale.US, "%.3f", proposedFactor)}"
                            proposedFactor != null -> tx(
                                language,
                                "Sonuç güvenli katsayı aralığının dışında (0,50–1,50). Litre ve mesafe değerlerini kontrol edin.",
                                "The result is outside the safe coefficient range (0.50–1.50). Check the liter and distance values."
                            )
                            else -> tx(
                                language,
                                "Pompa litresini girin; mesafeyi gerekirse gösterge kilometrenize göre düzeltin.",
                                "Enter the pump liters; correct the distance from the vehicle odometer if needed."
                            )
                        },
                        color = when {
                            factorValid -> palette.accent
                            proposedFactor != null -> palette.critical
                            else -> palette.textSecondary
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    TextButton(
                        onClick = {
                            dialog.onCancelSession()
                            onDismiss()
                        }
                    ) {
                        Text(tx(language, "Ölçümü iptal et", "Cancel measurement"))
                    }
                }
            }
        },
        confirmButton = {
            if (dialog.sessionActive) {
                TextButton(
                    enabled = factorValid && distanceValid && dialog.unavailableReason == null,
                    onClick = {
                        dialog.onSave(
                            pumpLiters,
                            appValue?.let { String.format(Locale.US, "%.3f", it) } ?: "",
                            proposedFactor ?: 1.0
                        )
                        onDismiss()
                    }
                ) {
                    Text(tx(language, "Kalibrasyonu uygula", "Apply calibration"))
                }
            } else {
                TextButton(
                    enabled = dialog.canStart,
                    onClick = {
                        dialog.onStart()
                        onDismiss()
                    }
                ) {
                    Text(tx(language, "Ölçümü başlat", "Start measurement"))
                }
            }
        },
        dismissButton = {
            Row {
                if (!dialog.sessionActive && dialog.enabled) {
                    TextButton(
                        onClick = {
                            dialog.onDisable()
                            onDismiss()
                        }
                    ) {
                        Text(tx(language, "Kalibrasyonu kapat", "Disable calibration"))
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(tx(language, "Kapat", "Close"))
                }
            }
        }
    )
}

private fun fuelCalibrationStartHelpText(language: AppLanguage): String =
    if (language == AppLanguage.English) {
        """
        1. Fill the tank completely.
        2. Open OBD and start the measurement.
        3. Keep LoganOS/OBD active and drive at least 100 km; 200–300 km is recommended.
        4. Refill to the same level.
        5. Enter only the pump liters. LoganOS calculates its own fuel automatically.
        """.trimIndent()
    } else {
        """
        1. Depoyu tamamen doldurun.
        2. OBD bağlantısını açıp ölçümü başlatın.
        3. LoganOS/OBD açıkken en az 100 km kullanın; 200–300 km önerilir.
        4. Depoyu yeniden aynı seviyeye kadar doldurun.
        5. Yalnızca pompadan alınan litreyi girin. LoganOS kendi yakıt hesabını otomatik kullanır.
        """.trimIndent()
    }

private fun formatCalibrationDate(timestampMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(timestampMs))

@Composable
private fun InfoDialog(palette: LoganPalette, dialog: SettingsDialog.Info, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tx(language, "Tamam", "OK")) } }
    )
}

@Composable
private fun ConfirmDialog(palette: LoganPalette, dialog: SettingsDialog.Confirm, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = { onDismiss(); dialog.onConfirm() }) { Text(dialog.confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}
