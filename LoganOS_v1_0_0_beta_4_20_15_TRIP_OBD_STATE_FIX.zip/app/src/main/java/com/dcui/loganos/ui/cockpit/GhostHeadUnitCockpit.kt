package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale

/**
 * Double/head-unit-only Ghost overlay configuration.
 *
 * The raster assets are intentionally shared with the approved phone design,
 * but every live text slot is independent. Head-unit typography changes must
 * never alter phone coordinates or font sizes.
 */
private val HeadUnitWhite = Color(0xFFF7F9FF)
private val HeadUnitMuted = Color(0xFFD5DDEC)
private val HeadUnitInstant = Color(0xFF8EDCFF)
private val HeadUnitAverage = Color(0xFFA8E87E)
private val HeadUnitTextStyle = TextStyle(
    fontFeatureSettings = "tnum",
    shadow = Shadow(color = Color(0xA0000000), offset = Offset.Zero, blurRadius = 6f)
)

private data class HeadUnitRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
}

private object HeadUnitSingleSpec {
    val dialText = HeadUnitRect(0.335f, 0.165f, 0.665f, 0.515f)
    val instant = HeadUnitRect(0.066f, 0.642f, 0.267f, 0.928f)
    val average = HeadUnitRect(0.734f, 0.642f, 0.934f, 0.928f)
    val temperature = HeadUnitRect(0.365f, 0.812f, 0.625f, 0.932f)
    val needle = GhostNeedleGeometry(
        centerX = 0.5000f,
        centerY = 0.7696f,
        radiusX = 0.3513f,
        radiusY = 0.7612f,
        startAngle = 220.5f,
        endAngle = 319.5f
    )
}

private object HeadUnitDualSpec {
    val leftDialText = HeadUnitRect(0.100f, 0.290f, 0.295f, 0.600f)
    val rightDialText = HeadUnitRect(0.703f, 0.290f, 0.900f, 0.600f)
    val instant = HeadUnitRect(0.103f, 0.642f, 0.283f, 0.758f)
    val average = HeadUnitRect(0.688f, 0.642f, 0.890f, 0.758f)
    val temperature = HeadUnitRect(0.364f, 0.773f, 0.624f, 0.894f)
    val leftNeedle = GhostNeedleGeometry(
        centerX = 0.1981f,
        centerY = 0.5065f,
        radiusX = 0.1538f,
        radiusY = 0.3333f,
        startAngle = 135f,
        endAngle = 405f
    )
    val rightNeedle = GhostNeedleGeometry(
        centerX = 0.7988f,
        centerY = 0.5084f,
        radiusX = 0.1536f,
        radiusY = 0.3328f,
        startAngle = 135f,
        endAngle = 405f
    )
}

private data class HeadUnitLiveValues(
    val fuelTrusted: Boolean,
    val instant: String,
    val average: String,
    val instantUnit: String,
    val averageUnit: String,
    val temperature: String,
    val temperatureColor: Color
)

@Composable
fun GhostSingleHeadUnitCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val live = headUnitLiveValues(palette, settings, snapshot)
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val rpmMaximum = 7000
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, rpmMaximum)
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    ).takeLast(14)
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = "head-unit-average"
    ).takeLast(14)

    HeadUnitStage(
        drawableId = R.drawable.ghost_single_logan_oem_19_5_9,
        modifier = modifier
    ) { stageWidth, stageHeight ->
        Canvas(Modifier.fillMaxSize()) {
            drawGhostNeedle(
                geometry = HeadUnitSingleSpec.needle,
                ratio = rpm.toFloat() / rpmMaximum.toFloat()
            )
        }
        HeadUnitSingleDialStack(
            stageWidth = stageWidth,
            stageHeight = stageHeight,
            rect = HeadUnitSingleSpec.dialText,
            speed = speed
        )
        HeadUnitSingleMetricCard(
            stageWidth = stageWidth,
            stageHeight = stageHeight,
            rect = HeadUnitSingleSpec.instant,
            label = "ANLIK TÜKETİM",
            value = live.instant,
            unit = live.instantUnit,
            trend = instantTrend,
            trendColor = HeadUnitInstant,
            onClick = onOpenReset
        )
        HeadUnitSingleMetricCard(
            stageWidth = stageWidth,
            stageHeight = stageHeight,
            rect = HeadUnitSingleSpec.average,
            label = "ORTALAMA TÜKETİM",
            value = live.average,
            unit = live.averageUnit,
            trend = averageTrend,
            trendColor = HeadUnitAverage,
            onClick = onOpenReset
        )
        HeadUnitTemperatureCard(
            stageWidth = stageWidth,
            stageHeight = stageHeight,
            rect = HeadUnitSingleSpec.temperature,
            value = live.temperature,
            color = live.temperatureColor,
            compact = false
        )
    }
}

@Composable
fun GhostDualHeadUnitCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostOriginalBakedCockpit(
        palette = palette,
        settings = settings,
        snapshot = snapshot,
        showHeadUnitTabs = true,
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}

@Composable
private fun HeadUnitStage(
    drawableId: Int,
    modifier: Modifier,
    content: @Composable BoxWithConstraintsScope.(Dp, Dp) -> Unit
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(drawableId),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        content(maxWidth, maxHeight)
    }
}

@Composable
private fun BoxWithConstraintsScope.HeadUnitSingleDialStack(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect,
    speed: Int
) {
    BoxWithConstraints(modifier = Modifier.headUnitSlot(stageWidth, stageHeight, rect)) {
        // Head-unit-only: lower the RPM title group without moving the speed
        // readout. Phone coordinates remain in GhostPhoneWideCockpit.kt.
        HeadUnitAutoFitText(
            text = "DEVİR",
            color = HeadUnitWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 0.86f,
            modifier = Modifier
                .offset(y = maxHeight * 0.105f)
                .width(maxWidth)
                .height(maxHeight * 0.17f)
        )
        HeadUnitAutoFitText(
            text = "x100 rpm",
            color = HeadUnitMuted,
            weight = FontWeight.Medium,
            maxFontFraction = 0.80f,
            modifier = Modifier
                .offset(y = maxHeight * 0.275f)
                .width(maxWidth)
                .height(maxHeight * 0.14f)
        )
        HeadUnitAutoFitText(
            text = speed.toString(),
            color = HeadUnitWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 1.40f,
            modifier = Modifier
                .offset(y = maxHeight * 0.405f)
                .width(maxWidth)
                .height(maxHeight * 0.42f)
        )
        HeadUnitAutoFitText(
            text = "km/h",
            color = HeadUnitMuted,
            weight = FontWeight.Medium,
            maxFontFraction = 0.80f,
            modifier = Modifier
                .offset(y = maxHeight * 0.835f)
                .width(maxWidth)
                .height(maxHeight * 0.13f)
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.HeadUnitDualDialStack(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect,
    title: String,
    subtitle: String,
    value: String
) {
    BoxWithConstraints(modifier = Modifier.headUnitSlot(stageWidth, stageHeight, rect)) {
        HeadUnitAutoFitText(
            text = title,
            color = HeadUnitWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 0.86f,
            modifier = Modifier.offset(y = maxHeight * 0.02f).width(maxWidth).height(maxHeight * 0.20f)
        )
        HeadUnitAutoFitText(
            text = subtitle,
            color = HeadUnitMuted,
            weight = FontWeight.Medium,
            maxFontFraction = 0.78f,
            modifier = Modifier.offset(y = maxHeight * 0.20f).width(maxWidth).height(maxHeight * 0.15f)
        )
        HeadUnitAutoFitText(
            text = value,
            color = HeadUnitWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 1.00f,
            modifier = Modifier.offset(y = maxHeight * 0.36f).width(maxWidth).height(maxHeight * 0.52f)
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.HeadUnitSingleMetricCard(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect,
    label: String,
    value: String,
    unit: String,
    trend: List<Float>,
    trendColor: Color,
    onClick: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .headUnitSlot(stageWidth, stageHeight, rect)
            .clickable(onClick = onClick)
    ) {
        HeadUnitAutoFitText(
            text = label,
            color = HeadUnitWhite,
            weight = FontWeight.SemiBold,
            maxFontFraction = 0.84f,
            modifier = Modifier.offset(y = maxHeight * 0.12f).width(maxWidth).height(maxHeight * 0.18f)
        )
        HeadUnitAutoFitText(
            text = value,
            color = HeadUnitWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 0.92f,
            modifier = Modifier.offset(y = maxHeight * 0.32f).width(maxWidth).height(maxHeight * 0.24f)
        )
        HeadUnitAutoFitText(
            text = unit,
            color = HeadUnitMuted,
            weight = FontWeight.Medium,
            maxFontFraction = 0.78f,
            modifier = Modifier.offset(y = maxHeight * 0.54f).width(maxWidth).height(maxHeight * 0.14f)
        )
        if (trend.isNotEmpty()) {
            ConsumptionSparkline(
                values = trend,
                lineColor = trendColor,
                guideColor = trendColor.copy(alpha = 0.25f),
                modifier = Modifier
                    .offset(maxWidth * 0.08f, maxHeight * 0.72f)
                    .width(maxWidth * 0.84f)
                    .height(maxHeight * 0.13f)
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.HeadUnitDualMetricCard(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect,
    label: String,
    value: String,
    unit: String,
    onClick: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .headUnitSlot(stageWidth, stageHeight, rect)
            .clickable(onClick = onClick)
    ) {
        // Capture the BoxWithConstraints dimensions before entering RowScope.
        // Otherwise maxHeight inside Row content is rejected as an implicit
        // receiver by newer Kotlin/Compose compiler versions.
        val cardHeight = maxHeight

        // The Double card uses its full width and never applies the phone's
        // optical left shift. Value and unit share one line to free vertical
        // space and keep the numeric value readable from driving distance.
        HeadUnitAutoFitText(
            text = label,
            color = HeadUnitWhite,
            weight = FontWeight.SemiBold,
            maxFontFraction = 0.96f,
            modifier = Modifier
                .offset(y = maxHeight * 0.08f)
                .width(maxWidth)
                .height(maxHeight * 0.30f)
        )
        Row(
            modifier = Modifier
                .offset(y = maxHeight * 0.40f)
                .width(maxWidth)
                .height(maxHeight * 0.52f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            Text(
                text = value,
                color = HeadUnitWhite,
                fontSize = (cardHeight.value * 0.39f).coerceIn(21f, 31f).sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                textAlign = TextAlign.Center,
                style = HeadUnitTextStyle
            )
            Text(
                text = if (unit.isBlank()) "" else " $unit",
                color = HeadUnitMuted,
                fontSize = (cardHeight.value * 0.17f).coerceIn(10f, 14f).sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                softWrap = false,
                style = HeadUnitTextStyle
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.HeadUnitTemperatureCard(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect,
    value: String,
    color: Color,
    compact: Boolean
) {
    BoxWithConstraints(modifier = Modifier.headUnitSlot(stageWidth, stageHeight, rect)) {
        HeadUnitAutoFitText(
            text = "HARARET",
            color = HeadUnitWhite,
            weight = FontWeight.SemiBold,
            maxFontFraction = if (compact) 1.08f else 1.02f,
            modifier = Modifier
                .offset(y = maxHeight * if (compact) 0.17f else 0.28f)
                .width(maxWidth)
                .height(maxHeight * if (compact) 0.30f else 0.30f)
        )
        HeadUnitAutoFitText(
            text = if (value == "--") "--" else "$value°C",
            color = color,
            weight = FontWeight.Bold,
            maxFontFraction = if (compact) 1.05f else 1.00f,
            modifier = Modifier
                .offset(y = maxHeight * if (compact) 0.51f else 0.60f)
                .width(maxWidth)
                .height(maxHeight * if (compact) 0.42f else 0.37f)
        )
    }
}

@Composable
private fun HeadUnitAutoFitText(
    text: String,
    color: Color,
    weight: FontWeight,
    maxFontFraction: Float,
    modifier: Modifier
) {
    BoxWithConstraints(contentAlignment = Alignment.Center, modifier = modifier) {
        val measurer = rememberTextMeasurer()
        val maxWidthPx = constraints.maxWidth.toFloat() * 0.96f
        val maxHeightPx = constraints.maxHeight.toFloat() * 0.90f
        val maxSp = (maxHeight.value * maxFontFraction.coerceAtLeast(0.05f)).coerceAtLeast(8f)
        val fitted = remember(text, weight, maxWidthPx, maxHeightPx, maxSp) {
            fitHeadUnitText(
                measurer = measurer,
                text = text,
                weight = weight,
                maxSp = maxSp,
                maxWidthPx = maxWidthPx,
                maxHeightPx = maxHeightPx
            )
        }
        Text(
            text = text,
            color = color,
            fontSize = fitted.sp,
            fontWeight = weight,
            maxLines = 1,
            softWrap = false,
            textAlign = TextAlign.Center,
            style = HeadUnitTextStyle
        )
    }
}

private fun fitHeadUnitText(
    measurer: androidx.compose.ui.text.TextMeasurer,
    text: String,
    weight: FontWeight,
    maxSp: Float,
    maxWidthPx: Float,
    maxHeightPx: Float
): Float {
    var low = 4f
    var high = maxSp.coerceAtLeast(low)
    repeat(12) {
        val middle = (low + high) / 2f
        val result = measurer.measure(
            text = AnnotatedString(text),
            style = HeadUnitTextStyle.copy(fontSize = middle.sp, fontWeight = weight),
            maxLines = 1,
            softWrap = false
        )
        if (result.size.width <= maxWidthPx && result.size.height <= maxHeightPx) {
            low = middle
        } else {
            high = middle
        }
    }
    return low
}

private fun Modifier.headUnitSlot(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: HeadUnitRect
): Modifier = this
    .offset(stageWidth * rect.left, stageHeight * rect.top)
    .width(stageWidth * rect.width)
    .height(stageHeight * rect.height)

@Composable
private fun headUnitLiveValues(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot
): HeadUnitLiveValues {
    val trusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    return HeadUnitLiveValues(
        fuelTrusted = trusted,
        instant = if (trusted) headUnitOne(snapshot.instantConsumption) else "--",
        average = if (trusted) headUnitOne(snapshot.averageConsumption) else "--",
        instantUnit = if (trusted) headUnitUnit(snapshot.instantUnit) else "VERİ",
        averageUnit = if (trusted) "L/100 km" else "VERİ",
        temperature = snapshot.engineTempC?.toString() ?: "--",
        temperatureColor = coolantAccentColor(palette, snapshot.engineTempC)
    )
}

private fun headUnitOne(value: Double?): String =
    value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun headUnitUnit(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100 km"
    unit.contains("L/h", true) -> "L/h"
    else -> unit
}

private fun compactHeadUnitUnit(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100 km"
    unit.contains("L/h", true) -> "L/h"
    unit.contains("VERİ", true) -> "VERİ"
    else -> unit
}
