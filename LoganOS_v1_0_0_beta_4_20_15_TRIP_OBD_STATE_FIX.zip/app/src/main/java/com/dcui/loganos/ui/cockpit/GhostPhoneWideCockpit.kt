package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Final Logan-OEM phone Ghost renderer.
 *
 * The scale numerals and tick marks are baked into the three final assets.
 * Compose draws only the live needle, titles, values, units and trends in
 * measured normalized slots, so device scaling cannot move the fixed scale.
 */
private const val WIDE_PHONE_ASPECT = 1846f / 852f
private val WideWhite = Color(0xFFF7F9FF)
private val WideMuted = Color(0xFFD5DDEC)
private val WideInstant = Color(0xFF8EDCFF)
private val WideAverage = Color(0xFFA8E87E)
private val WideTextStyle = TextStyle(
    fontFeatureSettings = "tnum",
    shadow = Shadow(color = Color(0xA0000000), offset = Offset.Zero, blurRadius = 7f)
)

private data class WideRect(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
}

internal data class GhostNeedleGeometry(
    val centerX: Float,
    val centerY: Float,
    val radiusX: Float,
    val radiusY: Float,
    val startAngle: Float,
    val endAngle: Float
)

private object WideSingleSpec {
    // Live overlay slots measured against ghost_single_logan_oem_19_5_9.webp.
    val dialText = WideRect(0.335f, 0.165f, 0.665f, 0.515f)
    val instant = WideRect(0.066f, 0.642f, 0.267f, 0.928f)
    val average = WideRect(0.734f, 0.642f, 0.934f, 0.928f)
    val temperature = WideRect(0.365f, 0.812f, 0.625f, 0.932f)
    val needle = GhostNeedleGeometry(
        centerX = 0.5000f,
        centerY = 0.7696f,
        radiusX = 0.3513f,
        radiusY = 0.7612f,
        startAngle = 220.5f,
        endAngle = 319.5f
    )
}

private object WideDualSpec {
    // Legacy Dual slot geometry retained for source compatibility; new Dual uses baked Ghost Original renderer.
    val leftDialText = WideRect(0.100f, 0.290f, 0.295f, 0.600f)
    val rightDialText = WideRect(0.703f, 0.290f, 0.900f, 0.600f)
    val instant = WideRect(0.103f, 0.642f, 0.283f, 0.758f)
    val average = WideRect(0.688f, 0.642f, 0.890f, 0.758f)
    val temperature = WideRect(0.364f, 0.773f, 0.624f, 0.894f)
    val leftNeedle = GhostNeedleGeometry(
        centerX = 0.1981f,
        centerY = 0.5065f,
        radiusX = 0.1538f,
        radiusY = 0.3333f,
        startAngle = 135f,
        endAngle = 405f
    )
    val rightNeedle = GhostNeedleGeometry(
        centerX = 0.7988f,
        centerY = 0.5084f,
        radiusX = 0.1536f,
        radiusY = 0.3328f,
        startAngle = 135f,
        endAngle = 405f
    )
}

private data class WideLiveValues(
    val fuelTrusted: Boolean,
    val instant: String,
    val average: String,
    val instantUnit: String,
    val averageUnit: String,
    val temperature: String,
    val temperatureColor: Color
)

@Composable
fun GhostSinglePhoneWideCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val live = wideLiveValues(palette, settings, snapshot)
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val rpmMaximum = 7000
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, rpmMaximum)
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    )
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = "wide-trial-average"
    )

    WidePhoneStage(
        drawableId = R.drawable.ghost_single_logan_oem_19_5_9,
        modifier = modifier
    ) { stageWidth, stageHeight ->
        Canvas(Modifier.fillMaxSize()) {
            drawGhostNeedle(
                geometry = WideSingleSpec.needle,
                ratio = rpm.toFloat() / rpmMaximum.toFloat()
            )
        }
        WideDialStack(
            stageWidth = stageWidth,
            stageHeight = stageHeight,
            rect = WideSingleSpec.dialText,
            title = "DEVİR",
            subtitle = "x100 rpm",
            value = speed.toString(),
            unit = "km/h",
            emphasizeValue = true
        )
        WideMetricCard(
            stageWidth, stageHeight, WideSingleSpec.instant,
            label = "ANLIK TÜKETİM",
            value = live.instant,
            unit = live.instantUnit,
            trend = instantTrend,
            trendColor = WideInstant,
            onClick = onOpenReset
        )
        WideMetricCard(
            stageWidth, stageHeight, WideSingleSpec.average,
            label = "ORTALAMA TÜKETİM",
            value = live.average,
            unit = live.averageUnit,
            trend = averageTrend,
            trendColor = WideAverage,
            onClick = onOpenReset
        )
        WideTemperatureCard(
            stageWidth, stageHeight, WideSingleSpec.temperature,
            value = live.temperature,
            color = live.temperatureColor
        )
    }
}

@Composable
fun GhostDualPhoneWideCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostOriginalBakedCockpit(
        palette = palette,
        settings = settings,
        snapshot = snapshot,
        showHeadUnitTabs = false,
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}

@Composable
private fun WidePhoneStage(
    drawableId: Int,
    modifier: Modifier,
    content: @Composable BoxWithConstraintsScope.(Dp, Dp) -> Unit
) {
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        // Fills the available phone cockpit area.
        // The overlay uses the very same stretched coordinate space, so every
        // text slot remains attached to its baked-in gauge/card.
        Image(
            painter = painterResource(drawableId),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        content(maxWidth, maxHeight)
    }
}

@Composable
private fun BoxWithConstraintsScope.WideDialStack(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: WideRect,
    title: String,
    subtitle: String,
    value: String,
    unit: String,
    emphasizeValue: Boolean = false
) {
    BoxWithConstraints(
        modifier = Modifier.slot(stageWidth, stageHeight, rect)
    ) {
        WideAutoFitText(
            text = title,
            color = WideWhite,
            weight = FontWeight.Bold,
            maxFontFraction = 0.82f,
            modifier = Modifier
                .offset(y = maxHeight * if (emphasizeValue) 0.02f else 0.02f)
                .width(maxWidth)
                .height(maxHeight * if (emphasizeValue) 0.17f else 0.20f)
        )
        WideAutoFitText(
            text = subtitle,
            color = WideMuted,
            weight = FontWeight.Medium,
            maxFontFraction = 0.76f,
            modifier = Modifier
                .offset(y = maxHeight * if (emphasizeValue) 0.18f else 0.19f)
                .width(maxWidth)
                .height(maxHeight * if (emphasizeValue) 0.13f else 0.15f)
        )
        WideAutoFitText(
            text = value,
            color = WideWhite,
            weight = FontWeight.Bold,
            maxFontFraction = if (emphasizeValue) 1.43f else 0.88f,
            modifier = Modifier
                .offset(y = maxHeight * if (emphasizeValue) 0.39f else 0.34f)
                .width(maxWidth)
                .height(maxHeight * when {
                    unit.isBlank() -> 0.52f
                    emphasizeValue -> 0.42f
                    else -> 0.42f
                })
        )
        if (unit.isNotBlank()) {
            WideAutoFitText(
                text = unit,
                color = WideMuted,
                weight = FontWeight.Medium,
                maxFontFraction = 0.76f,
                modifier = Modifier
                    .offset(y = maxHeight * if (emphasizeValue) 0.83f else 0.78f)
                    .width(maxWidth)
                    .height(maxHeight * if (emphasizeValue) 0.13f else 0.16f)
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.WideMetricCard(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: WideRect,
    label: String,
    value: String,
    unit: String,
    trend: List<Float>,
    trendColor: Color,
    onClick: () -> Unit
) {
    BoxWithConstraints(
        modifier = Modifier
            .slot(stageWidth, stageHeight, rect)
            .clickable(onClick = onClick)
    ) {
        // Layout geometry is determined only by the baked card size, never by
        // demo/OBD/trend state. Demo toggles may change the displayed strings
        // and whether the sparkline is visible, but every text slot stays fixed.
        val tallCard = rect.height > 0.18f
        val showTrend = tallCard && trend.isNotEmpty()
        WideAutoFitText(
            text = label,
            color = WideWhite,
            weight = FontWeight.SemiBold,
            maxFontFraction = if (tallCard) 0.82f else 1.02f,
            modifier = Modifier
                .offset(
                    x = if (tallCard) maxWidth * 0f else -maxWidth * 0.045f,
                    y = maxHeight * if (tallCard) 0.12f else 0.21f
                )
                .width(if (tallCard) maxWidth else maxWidth * 1.09f)
                .height(maxHeight * if (tallCard) 0.18f else 0.27f)
        )
        WideAutoFitText(
            text = value,
            color = WideWhite,
            weight = FontWeight.Bold,
            maxFontFraction = if (tallCard) 0.88f else 0.96f,
            modifier = Modifier
                .offset(y = maxHeight * if (tallCard) 0.32f else 0.49f)
                .width(maxWidth)
                .height(maxHeight * if (tallCard) 0.24f else 0.29f)
        )
        WideAutoFitText(
            text = unit,
            color = WideMuted,
            weight = FontWeight.Medium,
            maxFontFraction = if (tallCard) 0.76f else 0.84f,
            modifier = Modifier
                .offset(y = maxHeight * if (tallCard) 0.54f else 0.76f)
                .width(maxWidth)
                .height(maxHeight * if (tallCard) 0.14f else 0.18f)
        )
        if (showTrend) {
            ConsumptionSparkline(
                values = trend,
                lineColor = trendColor,
                guideColor = trendColor.copy(alpha = 0.25f),
                modifier = Modifier
                    .offset(maxWidth * 0.08f, maxHeight * 0.72f)
                    .width(maxWidth * 0.84f)
                    .height(maxHeight * 0.13f)
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.WideTemperatureCard(
    stageWidth: Dp,
    stageHeight: Dp,
    rect: WideRect,
    value: String,
    color: Color
) {
    BoxWithConstraints(modifier = Modifier.slot(stageWidth, stageHeight, rect)) {
        WideAutoFitText(
            text = "HARARET",
            color = WideWhite,
            weight = FontWeight.SemiBold,
            maxFontFraction = 0.98f,
            modifier = Modifier
                .offset(y = maxHeight * 0.29f)
                .width(maxWidth)
                .height(maxHeight * 0.30f)
        )
        WideAutoFitText(
            text = if (value == "--") "--" else "$value°C",
            color = color,
            weight = FontWeight.Bold,
            maxFontFraction = 0.96f,
            modifier = Modifier
                .offset(y = maxHeight * 0.61f)
                .width(maxWidth)
                .height(maxHeight * 0.36f)
        )
    }
}

@Composable
private fun WideAutoFitText(
    text: String,
    color: Color,
    weight: FontWeight,
    maxFontFraction: Float,
    modifier: Modifier
) {
    BoxWithConstraints(contentAlignment = Alignment.Center, modifier = modifier) {
        val measurer = rememberTextMeasurer()
        val maxWidthPx = constraints.maxWidth.toFloat() * 0.96f
        val maxHeightPx = constraints.maxHeight.toFloat() * 0.90f
        val maxSp = (maxHeight.value * maxFontFraction.coerceAtLeast(0.05f)).coerceAtLeast(8f)
        val fitted = remember(text, weight, maxWidthPx, maxHeightPx, maxSp) {
            fitWideText(
                measurer = measurer,
                text = text,
                weight = weight,
                maxSp = maxSp,
                maxWidthPx = maxWidthPx,
                maxHeightPx = maxHeightPx
            )
        }
        Text(
            text = text,
            color = color,
            fontSize = fitted.sp,
            fontWeight = weight,
            maxLines = 1,
            softWrap = false,
            textAlign = TextAlign.Center,
            style = WideTextStyle
        )
    }
}

private fun fitWideText(
    measurer: androidx.compose.ui.text.TextMeasurer,
    text: String,
    weight: FontWeight,
    maxSp: Float,
    maxWidthPx: Float,
    maxHeightPx: Float
): Float {
    var low = 4f
    var high = maxSp.coerceAtLeast(low)
    repeat(12) {
        val middle = (low + high) / 2f
        val result = measurer.measure(
            text = AnnotatedString(text),
            style = WideTextStyle.copy(fontSize = middle.sp, fontWeight = weight),
            maxLines = 1,
            softWrap = false
        )
        if (result.size.width <= maxWidthPx && result.size.height <= maxHeightPx) {
            low = middle
        } else {
            high = middle
        }
    }
    return low
}

private fun Modifier.slot(stageWidth: Dp, stageHeight: Dp, rect: WideRect): Modifier =
    this
        .offset(stageWidth * rect.left, stageHeight * rect.top)
        .width(stageWidth * rect.width)
        .height(stageHeight * rect.height)

internal fun DrawScope.drawGhostNeedle(geometry: GhostNeedleGeometry, ratio: Float) {
    val clamped = ratio.coerceIn(0f, 1f)
    val angle = geometry.startAngle + (geometry.endAngle - geometry.startAngle) * clamped
    val radians = Math.toRadians(angle.toDouble())
    val center = Offset(size.width * geometry.centerX, size.height * geometry.centerY)
    val outer = Offset(
        center.x + cos(radians).toFloat() * size.width * geometry.radiusX,
        center.y + sin(radians).toFloat() * size.height * geometry.radiusY
    )
    val vx = outer.x - center.x
    val vy = outer.y - center.y
    val radiusPx = sqrt(vx * vx + vy * vy).coerceAtLeast(1f)
    val ux = vx / radiusPx
    val uy = vy / radiusPx
    val px = -uy
    val py = ux

    // One shared tapered pointer for portrait, single-wide and dual-wide.
    // A minimum on-screen length keeps the smaller Dual needles visible,
    // while the large Single gauge remains compact and inside the baked arc.
    val tipDistance = radiusPx * 0.900f
    val minimumVisibleLength = size.minDimension * 0.160f
    val visibleLength = maxOf(radiusPx * 0.320f, minimumVisibleLength)
        .coerceAtMost(radiusPx * 0.520f)
    val baseDistance = (tipDistance - visibleLength).coerceAtLeast(radiusPx * 0.320f)
    val shoulderDistance = baseDistance + visibleLength * 0.220f
    val base = Offset(center.x + ux * baseDistance, center.y + uy * baseDistance)
    val shoulder = Offset(center.x + ux * shoulderDistance, center.y + uy * shoulderDistance)
    val tip = Offset(center.x + ux * tipDistance, center.y + uy * tipDistance)
    val baseHalfWidth = (radiusPx * 0.014f).coerceIn(
        size.minDimension * 0.0040f,
        size.minDimension * 0.0090f
    )
    val shoulderHalfWidth = baseHalfWidth * 0.48f

    drawLine(
        color = Color(0x42FF302A),
        start = base,
        end = tip,
        strokeWidth = baseHalfWidth * 3.0f,
        cap = StrokeCap.Round
    )

    val outline = Path().apply {
        moveTo(base.x + px * baseHalfWidth * 1.24f, base.y + py * baseHalfWidth * 1.24f)
        lineTo(shoulder.x + px * shoulderHalfWidth * 1.24f, shoulder.y + py * shoulderHalfWidth * 1.24f)
        lineTo(tip.x, tip.y)
        lineTo(shoulder.x - px * shoulderHalfWidth * 1.24f, shoulder.y - py * shoulderHalfWidth * 1.24f)
        lineTo(base.x - px * baseHalfWidth * 1.24f, base.y - py * baseHalfWidth * 1.24f)
        close()
    }
    drawPath(outline, Color(0xFF67120F))

    val needle = Path().apply {
        moveTo(base.x + px * baseHalfWidth, base.y + py * baseHalfWidth)
        lineTo(shoulder.x + px * shoulderHalfWidth, shoulder.y + py * shoulderHalfWidth)
        lineTo(tip.x, tip.y)
        lineTo(shoulder.x - px * shoulderHalfWidth, shoulder.y - py * shoulderHalfWidth)
        lineTo(base.x - px * baseHalfWidth, base.y - py * baseHalfWidth)
        close()
    }
    drawPath(needle, Color(0xFFFF3B30))
    drawLine(
        color = Color(0xFFFF9B91),
        start = Offset(base.x + ux * radiusPx * 0.025f, base.y + uy * radiusPx * 0.025f),
        end = Offset(
            center.x + ux * radiusPx * 0.855f,
            center.y + uy * radiusPx * 0.855f
        ),
        strokeWidth = (baseHalfWidth * 0.34f).coerceAtLeast(1f),
        cap = StrokeCap.Round
    )
}

@Composable
private fun wideLiveValues(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot
): WideLiveValues {
    val trusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    return WideLiveValues(
        fuelTrusted = trusted,
        instant = if (trusted) wideOne(snapshot.instantConsumption) else "--",
        average = if (trusted) wideOne(snapshot.averageConsumption) else "--",
        instantUnit = if (trusted) wideUnit(snapshot.instantUnit) else "VERİ BEKLENİYOR",
        averageUnit = if (trusted) "L/100 km" else "VERİ BEKLENİYOR",
        temperature = snapshot.engineTempC?.toString() ?: "--",
        temperatureColor = coolantAccentColor(palette, snapshot.engineTempC)
    )
}

private fun wideOne(value: Double?): String =
    value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun wideUnit(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100 km"
    unit.contains("L/h", true) -> "L/h"
    else -> unit
}

private fun compactWideUnit(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100km"
    unit.contains("L/h", true) -> "L/h"
    unit.contains("VERİ", true) -> "VERİ"
    else -> unit.replace(" ", "")
}

