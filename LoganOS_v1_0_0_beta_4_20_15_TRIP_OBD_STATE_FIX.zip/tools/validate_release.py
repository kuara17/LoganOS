#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
APP = ROOT / 'app'
GRADLE = APP / 'build.gradle.kts'
MANIFEST = APP / 'src/main/AndroidManifest.xml'
DRAWABLE = APP / 'src/main/res/drawable-nodpi'


def fail(message: str) -> None:
    print(f'[FAIL] {message}')
    raise SystemExit(1)


def ok(message: str) -> None:
    print(f'[OK] {message}')

if not GRADLE.is_file():
    fail('app/build.gradle.kts missing')
if not MANIFEST.is_file():
    fail('AndroidManifest.xml missing')

text = GRADLE.read_text(encoding='utf-8')
vm = re.search(r'versionName\s*=\s*"([^"]+)"', text)
vc = re.search(r'versionCode\s*=\s*(\d+)', text)
if not vm or not vc:
    fail('versionName/versionCode not found')
version_name = vm.group(1)
version_code = int(vc.group(1))
if not re.fullmatch(r'1\.0\.0-beta\.\d+\.\d+\.\d+', version_name):
    fail(f'unexpected versionName: {version_name}')
if version_code <= 0:
    fail('versionCode must be positive')
ok(f'version {version_name} ({version_code})')

colors = ('cherry_red', 'white', 'gray', 'blue', 'green', 'yellow')
scenes = ('mountain_lake', 'snow_road', 'city_day', 'city_night')
models = ('logan1', 'logan3')
expected = {
    f'digital_v2_{scene}_{model}_{color}.webp'
    for scene in scenes for model in models for color in colors
}
actual = {p.name for p in DRAWABLE.glob('digital_v2_*.webp')}
missing = sorted(expected - actual)
extra = sorted(actual - expected)
if missing:
    fail('missing Digital V2 baked assets: ' + ', '.join(missing[:8]))
if extra:
    fail('unexpected/legacy Digital V2 WebP assets remain: ' + ', '.join(extra[:8]))
if len(actual) != 48:
    fail(f'expected 48 Digital V2 baked assets, got {len(actual)}')
ok('48 baked Digital V2 scene/model/color assets present')

legacy_names = (
    'digital_v2_mountain_lake_bg.webp', 'digital_v2_city_day_bg.webp',
    'digital_v2_city_night_bg.webp', 'digital_v2_snow_road_bg.webp',
    'digital_v2_ground_shadow_logan1.webp', 'digital_v2_ground_shadow_logan3.webp',
)
for name in legacy_names:
    if (DRAWABLE / name).exists():
        fail(f'legacy Digital V2 resource still present: {name}')
if list(DRAWABLE.glob('digital_v2_*_road_map.png')):
    fail('legacy Digital V2 road-map resources still present')
if list(DRAWABLE.glob('digital_v2_*_shadow_*.webp')):
    fail('legacy Digital V2 shadow resources still present')
ok('legacy Digital V2 road/car-compositing resources removed')

# Ghost Single Original shared baked scene set.
ghost_expected = {f'ghost_original_baked_{color}.webp' for color in ('blue', 'purple', 'yellow', 'red', 'green')}
ghost_actual = {p.name for p in DRAWABLE.glob('ghost_original_baked_*.webp')}
if ghost_actual != ghost_expected:
    fail('Ghost Original baked asset set mismatch: expected ' + ', '.join(sorted(ghost_expected)))
ok('5 shared Ghost Original baked light-colour assets present')


# Ghost Dual now uses one geometry-locked 19.5:9 baked asset set for phone landscape and Double.
ghost_dual_expected = {f'ghost_dual_original_{color}.webp' for color in ('blue', 'purple', 'yellow', 'red', 'green')}
ghost_dual_actual = {p.name for p in DRAWABLE.glob('ghost_dual_original_*.webp')}
if ghost_dual_actual != ghost_dual_expected:
    fail('Ghost Dual baked asset set mismatch: expected ' + ', '.join(sorted(ghost_dual_expected)))
ok('5 Ghost Dual 19.5:9 baked light-colour assets present')

for name in ('ghost_dual_logan_oem_19_5_9.webp', 'ghost_dual_oem_rpm_shell_4203.webp'):
    if (DRAWABLE / name).exists():
        fail(f'legacy Ghost Dual asset still present: {name}')
ok('legacy Ghost Dual asset/shell removed')

ghost_legacy = (
    'ghost_single_original_background.webp',
    'ghost_single_original_gauge_marks.webp',
    'ghost_single_original_gauge_shell.webp',
    'ghost_single_original_road_base.webp',
    'ghost_single_original_road_edges.webp',
    'ghost_single_original_road_sheen.webp',
    'ghost_single_original_vehicle_shadow.webp',
    'ghost_dual_original_road_base.webp',
    'ghost_dual_original_road_edges.webp',
    'ghost_dual_original_road_sheen.webp',
    'ghost_dual_original_speed_shell.webp',
    'ghost_dual_original_vehicle_shadow.webp',
)
for name in ghost_legacy:
    if (DRAWABLE / name).exists():
        fail(f'legacy Ghost Original resource still present: {name}')
ok('legacy Ghost Original scene/shell/vehicle-layer resources removed')

for pattern in ('*.jks', '*.keystore', '*.apk', '*.aab'):
    found = [p for p in ROOT.rglob(pattern) if '.gradle' not in p.parts]
    if found:
        fail(f'packaging must not include {pattern}: {found[0].relative_to(ROOT)}')
ok('no signing keys/APK/AAB payloads in source tree')
