package com.dcui.loganos.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.data.LoganSqlStore
import com.dcui.loganos.data.TimeMark
import com.dcui.loganos.data.TrustedTimeSource
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.service.ObdForegroundService
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.IOException
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.ArrayDeque
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import org.json.JSONArray
import org.json.JSONObject

private data class DeveloperTestPhase(
    val title: String,
    val seconds: Int
)

private data class PendingTripBoundary(
    val disconnectedAt: TimeMark?,
    val restoredPrefix: TripComputerPersistedState
)

private data class ConnectionGuardDecision(
    val health: ObdConnectionHealth,
    val holdValues: Boolean,
    val blankLiveValues: Boolean,
    val freezeTrip: Boolean,
    val reason: String?
)

private data class IgnitionObservation(
    val engineRunning: Boolean = false,
    val confirmedOffMark: TimeMark? = null,
    val resumedAfterOffMark: TimeMark? = null,
    val shouldReevaluateBoundary: Boolean = false,
    val needsSessionRotation: Boolean = false
)

private enum class FuelDiscoveryStage {
    IDLE,
    BEFORE_DISCOVERY,
    WAITING_FOR_REFUEL_RESTART,
    AFTER_START_SCAN,
    WAITING_FOR_500M,
    AFTER_500M_SCAN,
    WAITING_FOR_2KM,
    AFTER_2KM_SCAN,
    COMPLETED
}

private data class FuelDiscoveryScanRequest(
    val phase: String,
    val discoverModules: Boolean
)

private data class FuelDiscoveryModule(
    val address: Int,
    val label: String,
    val supportedLocalIds: MutableSet<Int> = linkedSetOf(),
    val localIdHits: MutableMap<Int, Int> = linkedMapOf(),
    val localIdAttempts: MutableMap<Int, Int> = linkedMapOf()
)

private enum class Dynamic026Mode {
    FUEL_BEFORE_ENGINE,
    FUEL_BEFORE_KOEO,
    FUEL_AFTER_KOEO,
    FUEL_AFTER_ENGINE,
    FUEL_DRIVE,
    FUEL_FINAL_KOEO,
    CONTROL_HANDBRAKE,
    CONTROL_CLUTCH,
    CONTROL_BRAKE,
    CONTROL_GEAR_STATIC,
    CONTROL_GEAR_DRIVE,
    KOEO,
    ENGINE_STATIC,
    DRIVE,
    POST_KOEO,
    WIDE_KOEO,
    WIDE_IDLE,
    WIDE_RPM,
    WIDE_DRIVE,
    WIDE_POST
}

private enum class Dynamic026Stage {
    IDLE,
    SCAN,
    GUIDED_COUNTDOWN,
    IDLE_STABILIZING,
    WAITING_FOR_2000_RPM,
    RPM2000_STABILIZING,
    WAITING_FOR_MOTION,
    WAITING_FOR_500M,
    WAITING_FOR_2KM,
    WAITING_FOR_5KM,
    COMPLETED
}

private enum class Dynamic026ScanProfile {
    RESEARCH,
    FUEL_REFILL,
    CONTROL_DISCOVERY,
    HANDBRAKE_TARGETED
}

private data class Dynamic026GuidedStep(
    val phase: String,
    val instruction: String,
    val seconds: Int,
    val repeatPasses: Int = 1,
    val profile: Dynamic026ScanProfile,
    val requireStationary: Boolean = true,
    val requireEngineRunning: Boolean = true,
    val minimumSpeedKmh: Int = 0
)

private data class Dynamic026ScanRequest(
    val phase: String,
    val repeatPasses: Int,
    val includeResearchBlocks: Boolean,
    val fullDiscovery: Boolean = false,
    val completeAfterScan: Boolean = false,
    val profile: Dynamic026ScanProfile = Dynamic026ScanProfile.RESEARCH
)

private class FuelDiscoveryStopSignal : RuntimeException()
private class Dynamic026StopSignal : RuntimeException()

class ObdController(private val context: Context) {
    var state by mutableStateOf(ObdState())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var pendingReconnectJob: Job? = null
    private var connectionGeneration: Long = 0L
    private var developerTestJob: Job? = null
    private var fuelDiscoveryStage: FuelDiscoveryStage = FuelDiscoveryStage.IDLE
    private var fuelDiscoveryScanRequest: FuelDiscoveryScanRequest? = null
    private var fuelDiscoveryScanInProgress: Boolean = false
    private var fuelDiscoveryReconnectArmed: Boolean = false
    private var fuelDiscoveryIgnitionOffConfirmed: Boolean = false
    private var fuelDiscoveryDisconnectElapsedMs: Long? = null
    private var fuelDiscoveryStopRequested: Boolean = false
    private var fuelDiscoveryStartDistanceKm: Double? = null
    private val fuelDiscoveryModules: LinkedHashMap<Int, FuelDiscoveryModule> = linkedMapOf()
    private var fuelDiscoveryWorkingFile: File? = null
    private var fuelDiscoveryStartedElapsedMs: Long = 0L
    private var fuelDiscoveryProgressPercent: Int = 0
    private var fuelDiscoveryUiTickerJob: Job? = null
    private val fuelDiscoveryPrefs = context.getSharedPreferences("loganos_fuel_discovery_runtime", Context.MODE_PRIVATE)
    private var dynamic026Mode: Dynamic026Mode? = null
    private var dynamic026Stage: Dynamic026Stage = Dynamic026Stage.IDLE
    private var dynamic026ScanRequest: Dynamic026ScanRequest? = null
    private var dynamic026ScanInProgress: Boolean = false
    private var dynamic026StopRequested: Boolean = false
    private var dynamic026WorkingFile: File? = null
    private var dynamic026ResearchFile: File? = null
    private var dynamic026StartedElapsedMs: Long = 0L
    private var dynamic026ConditionSinceMs: Long? = null
    private var dynamic026StageEnteredElapsedMs: Long = 0L
    private var dynamic026UiTickerJob: Job? = null
    private var dynamic026DriveStartDistanceKm: Double? = null
    private var dynamic026DriveAccumulatedKm: Double = 0.0
    private var dynamic026DriveLastElapsedMs: Long? = null
    private var dynamic026GuidedSteps: List<Dynamic026GuidedStep> = emptyList()
    private var dynamic026GuidedStepIndex: Int = 0
    private var dynamic026GuidedStepStartedMs: Long = 0L
    private var dynamic026GroupId: String = ""
    private var pendingDeveloperTestName: String? = null
    private var pendingDeveloperTestRequestedMs: Long = 0L
    private var pendingDeveloperTestReconnectAttempts: Int = 0
    private var pendingDeveloperTestReconnectJob: Job? = null
    private var lastLiveContextCapturedElapsedMs: Long = 0L
    private var dynamic026MissingRpmSinceMs: Long? = null
    private var dynamic026ActiveReconnectAttempts: Int = 0
    private var dynamic026ActiveReconnectJob: Job? = null
    private var dynamic026ActiveName: String? = null
    private val dynamic026Prefs = context.getSharedPreferences("loganos_dynamic_026_runtime", Context.MODE_PRIVATE)
    private val dynamic026GroupPrefs = context.getSharedPreferences("loganos_dynamic_026_group", Context.MODE_PRIVATE)
    private var socket: BluetoothSocket? = null
    private val parser = DelphiParser()
    private val tripComputer = TripComputer()
    private val persistentCockpitTrip = PersistentCockpitTripStore(context)
    private val tripMutex = Mutex()
    private val timeSource = TrustedTimeSource(context)
    private val sqlStore = LoganSqlStore(context, timeSource)
    private val gpsRouteRecorder = GpsRouteRecorder(context, sqlStore) { gps ->
        scope.launch {
            withMain {
                state = state.copy(
                    gpsRouteEnabled = gps.enabled,
                    gpsRouteEligible = gps.eligible,
                    gpsRouteRecording = gps.recording,
                    gpsRouteStatus = gps.status,
                    gpsRoutePointCount = gps.acceptedPointCount,
                    gpsLastAccuracyM = gps.lastAccuracyM
                )
            }
        }
    }
    private var currentSqlSessionId: Long? = null
    private var lastSqlSessionId: Long? = null
    private var rawEcuLogEnabled: Boolean = false
    private var longTripLogEnabled: Boolean = false
    private var lastSqlSampleMs: Long = 0L
    private var activeTripHistoryId: Long? = null
    private var activeDeveloperTestHistoryId: Long? = null
    private var activeCrankTestHistoryId: Long? = null
    private val engineTempWindow = ArrayDeque<Int>()
    private var runtimeSettings: LoganSettings = LoganSettings()
    @Volatile private var demoModeActive: Boolean = false
    private var activeProfileSignature: String = obdProfileSignature(runtimeSettings)
    private val appPrefs = AppPrefs(context)
    private var lastFuelCalibrationSnapshot: DashboardSnapshot? = null
    private var smartTripMinutes: Int = 60
    private var lastDisconnectMark: TimeMark? = null
    private var lastTrustedEngineRunningMark: TimeMark? = null
    private var ignitionOffCandidateMark: TimeMark? = null
    private var confirmedIgnitionOffMark: TimeMark? = null
    private var engineRunningObservedSinceConnect: Boolean = false
    private var ignitionWakeProbeActive: Boolean = false
    private var ignitionWakeProbeValidated: Boolean = false
    private var lastTrustedCoolantTempC: Int? = null
    private val tripPrefs = context.getSharedPreferences("loganos_trip_runtime", Context.MODE_PRIVATE)
    private var lastTripPersistElapsedMs: Long = 0L
    private var pendingTripBoundary: PendingTripBoundary? = null
    @Volatile private var manualTripEnding: Boolean = false
    private var lastAcMismatchSignature: String? = null
    private var driveHistoryDetailRequestToken: Long = 0L
    private var vehicleHealthEvidenceRefreshElapsedMs: Long = 0L
    private var vehicleHealthHistorySignature: Long = Long.MIN_VALUE

    // Connection Health Guard: keep one last trusted live frame so a dying
    // Bluetooth/KWP link cannot make the cockpit look as if the engine stopped.
    private var lastTrustedLiveSnapshot: DashboardSnapshot? = null
    private var connectionFaultScore: Int = 0
    private var connectionFaultSinceMs: Long = 0L
    private var healthyRecoverySamples: Int = 0
    private var consecutiveMainPacketFailures: Int = 0
    private var fastDropSuspected: Boolean = false
    private var connectionGuardWarmupStartMs: Long = 0L
    private var elmAwaitingLatePrompt: Boolean = false

    private val crankPrefs = context.getSharedPreferences("loganos_crank_tests", Context.MODE_PRIVATE)
    private var lastRpmForCrank: Int? = null
    private var engineOffSinceElapsedMs: Long? = null
    private var crankStartMs: Long? = null
    private var crankStartTimestampMs: Long = 0L
    private var crankStartTimeTrusted: Boolean = false
    private var crankStartVoltage: Double? = null
    private var crankMinVoltage: Double? = null
    private var crankTempC: Int? = null
    private var crankInitialRpm: Int? = null
    private var crankPeakRpm: Int? = null
    private var crankRunningCandidateMs: Long? = null
    private var crankRunningDetectedMs: Long? = null
    private var crankInitialRunningRpm: Int? = null
    private var crankStableSamples: Int = 0
    private var crankStableRpmMin: Int? = null
    private var crankStableRpmMax: Int? = null
    private var crankStopCandidateMs: Long? = null
    private var crankAttemptCount: Int = 1
    private var lastFailedCrankElapsedMs: Long? = null
    private var crankObdGapDetected: Boolean = false
    private var crankManual: Boolean = false
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    init {
        val recovered = runCatching { sqlStore.recoverOpenSessions() }.getOrDefault(0)
        val historyRecovered = runCatching { sqlStore.recoverOpenHistory() }.getOrDefault(0 to 0)
        val recoveredDrives = runCatching { sqlStore.listDriveHistory() }.getOrDefault(emptyList())
        val rememberedHistoryId = tripPrefs.getLong(KEY_ACTIVE_HISTORY_ID, 0L).takeIf { it > 0L }
        activeTripHistoryId = rememberedHistoryId?.takeIf { id -> recoveredDrives.any { it.id == id && it.activeLike } }
        if (rememberedHistoryId != null && activeTripHistoryId == null) saveActiveTripHistory(null)
        val crankRuntimeMark = timeSource.now()
        if (crankPrefs.getString(KEY_CRANK_ATTEMPT_BOOT, null) == crankRuntimeMark.bootSessionId) {
            lastFailedCrankElapsedMs = crankPrefs.getLong(KEY_CRANK_LAST_FAILED_ELAPSED, 0L).takeIf { it > 0L }
            crankAttemptCount = crankPrefs.getInt(KEY_CRANK_ATTEMPT_COUNT, 1).coerceIn(1, 9)
        } else {
            clearCrankAttemptRuntime()
        }
        val recoveredStartEvents = runCatching { sqlStore.listStartEvents(100) }.getOrDefault(emptyList())
        state = state.copy(
            savedManualCrankTests = loadManualCrankTests(),
            startEvents = recoveredStartEvents,
            startAnalysisSummary = StartAnalyzer.summarize(recoveredStartEvents),
            timeTrusted = timeSource.isTrusted(),
            driveHistory = recoveredDrives,
            testHistory = runCatching { sqlStore.listTestHistory() }.getOrDefault(emptyList()),
            historyStorage = runCatching { sqlStore.historyStorageInfo() }.getOrDefault(state.historyStorage),
            fuelRefillLitersText = dynamic026GroupPrefs.getString(KEY_FUEL_REFILL_LITERS, "") ?: "",
            status = when {
                recovered > 0 || historyRecovered.first > 0 || historyRecovered.second > 0 -> "$recovered OBD, ${historyRecovered.first} sürüş ve ${historyRecovered.second} test kaydı kurtarıldı"
                else -> state.status
            }
        )
        // Health evidence may scan recent stored samples, so never do it on the
        // Activity/UI thread during controller construction.
        scope.launch {
            val evidence = runCatching { sqlStore.loadVehicleHealthEvidence() }.getOrDefault(state.vehicleHealthEvidence)
            vehicleHealthEvidenceRefreshElapsedMs = SystemClock.elapsedRealtime()
            vehicleHealthHistorySignature = healthHistorySignature(recoveredDrives)
            withMain { state = state.copy(vehicleHealthEvidence = evidence) }
        }
        recoverInterruptedFuelDiscoveryIfNeeded()
        recoverInterruptedDynamic026IfNeeded()
    }

    fun refreshTrustedTimeState() {
        val trusted = timeSource.isTrusted()
        if (state.timeTrusted != trusted) {
            state = state.copy(timeTrusted = trusted)
        }
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun setLoggingOptions(rawEcuLog: Boolean, longTripLog: Boolean) {
        rawEcuLogEnabled = rawEcuLog
        longTripLogEnabled = longTripLog
        state = state.copy(rawEcuLogEnabled = rawEcuLog, longTripLogEnabled = longTripLog)
    }

    fun setRuntimeSettings(settings: LoganSettings) {
        val previousSettings = runtimeSettings
        val demoChanged = previousSettings.demoMode != settings.demoMode
        val newProfileSignature = obdProfileSignature(settings)
        val obdProfileChanged = activeProfileSignature != newProfileSignature

        // Preserve the last real full-tank calibration delta before Demo Mode
        // takes ownership of the visible dashboard snapshot.
        if (demoChanged && settings.demoMode) flushFuelCalibrationProgress()

        runtimeSettings = settings
        demoModeActive = settings.demoMode
        activeProfileSignature = newProfileSignature

        if (demoChanged) {
            applyDemoModeTransition(settings.demoMode)
        } else if (obdProfileChanged && hasActiveConnectionWork()) {
            // Parser/protocol selection is captured when a connection starts. Never
            // let a changed vehicle profile continue on the old polling session.
            disconnect(silent = true, recordTripStop = true, stopBackgroundService = true)
            state = state.copy(
                status = "Araç/OBD profili değişti • yeniden bağlanın",
                lastError = null,
                snapshot = DashboardSnapshot.empty()
            )
            appendLog("[MODE_ISOLATION] OBD-critical vehicle profile changed; active session closed")
        }

        if (!settings.fuelCalibrationSessionActive) lastFuelCalibrationSnapshot = null
        smartTripMinutes = settings.smartTripMinutes.coerceAtLeast(0)
        gpsRouteRecorder.configure(
            enabled = settings.gpsRouteEnabled && !settings.demoMode,
            allowForDeviceMode = !settings.demoMode && isPhoneModeForGps(settings) && settings.driveHistoryEnabled
        )
        val foregroundNeeded = !settings.demoMode && shouldRunForegroundService(settings)
        if (foregroundNeeded && (state.connected || state.connecting || state.connectionHealth == ObdConnectionHealth.RECONNECTING)) {
            ObdForegroundService.start(context)
        } else if (!foregroundNeeded) {
            ObdForegroundService.stop(context)
        }
        scope.launch {
            runCatching {
                sqlStore.applyHistoryRetention(settings.driveHistoryLimit, settings.testHistoryLimit)
                refreshHistoryState()
            }
        }
    }

    private fun hasActiveConnectionWork(): Boolean =
        state.connected || state.connecting || job?.isActive == true ||
            pendingReconnectJob?.isActive == true || state.connectionHealth == ObdConnectionHealth.RECONNECTING

    private fun applyDemoModeTransition(enabled: Boolean) {
        val hadConnectionWork = hasActiveConnectionWork() || currentSqlSessionId != null
        if (hadConnectionWork) {
            disconnect(silent = true, recordTripStop = true, stopBackgroundService = true)
        } else {
            invalidateConnectionWork("demo transition")
            closeSocket()
            resetConnectionHealthRuntime()
            parser.resetRuntimeState()
        }
        gpsRouteRecorder.onObdDisconnected()
        state = state.copy(
            connecting = false,
            connected = false,
            connectionHealth = ObdConnectionHealth.DISCONNECTED,
            connectionHealthReason = null,
            signalHoldActive = false,
            connectionUnstableCount = 0,
            lastError = null,
            snapshot = DashboardSnapshot.empty(),
            status = if (enabled) {
                "Demo Modu etkin • gerçek OBD ve yeniden bağlanma kapatıldı"
            } else {
                "Demo Modu kapatıldı • OBD bağlantısı bekleniyor"
            }
        )
        appendLog("[MODE_ISOLATION] demo=${if (enabled) "ON" else "OFF"}; real OBD work cleared")
    }

    private fun cancelPendingReconnect(reason: String) {
        if (pendingReconnectJob?.isActive == true) {
            appendLog("[AUTO_RECONNECT_CANCELLED] $reason")
        }
        pendingReconnectJob?.cancel()
        pendingReconnectJob = null
    }

    private fun invalidateConnectionWork(reason: String) {
        connectionGeneration++
        cancelPendingReconnect(reason)
    }

    private fun beginConnectionGeneration(): Long {
        connectionGeneration++
        return connectionGeneration
    }

    private fun scheduleIgnitionWakeProbe(address: String, delayMs: Long = IGNITION_WAKE_PROBE_INTERVAL_MS) {
        if (demoModeActive || runtimeSettings.demoMode) return
        cancelPendingReconnect("ignition wake probe rescheduled")
        pendingReconnectJob = scope.launch {
            delay(delayMs)
            if (
                !demoModeActive && !runtimeSettings.demoMode &&
                !state.connected && !state.connecting &&
                state.selectedAddress == address
            ) {
                pendingReconnectJob = null
                connect(address, autoReconnectAttempt = true, ignitionWakeProbe = true)
            }
        }
    }

    private fun isConnectionCurrent(generation: Long, address: String): Boolean =
        generation == connectionGeneration &&
            state.selectedAddress == address &&
            !demoModeActive && !runtimeSettings.demoMode

    private fun obdProfileSignature(settings: LoganSettings): String = listOf(
        settings.fuelType.name,
        settings.profileSupport.name,
        settings.vehicleModel,
        settings.engine,
        settings.modelYearText,
        settings.engineCodeText,
        settings.engineDisplacementCcText,
        settings.enginePowerHpText,
        settings.cylinderCount.toString(),
        settings.experimentalProfileAccepted.toString()
    ).joinToString("|")

    private fun shouldRunForegroundService(settings: LoganSettings): Boolean =
        settings.backgroundTripEnabled ||
            (settings.gpsRouteEnabled && settings.driveHistoryEnabled && isPhoneModeForGps(settings))

    fun isGpsForegroundLocationEligible(): Boolean = gpsRouteRecorder.isForegroundLocationEligible()

    fun refreshHistory() {
        scope.launch { refreshHistoryState() }
    }

    fun loadDriveHistoryDetail(recordId: Long) {
        val requestToken = ++driveHistoryDetailRequestToken
        state = state.copy(driveHistoryDetailLoading = true, driveHistoryDetail = null)
        scope.launch {
            val detail = runCatching { sqlStore.loadDriveHistoryDetail(recordId) }.getOrNull()
            withMain {
                if (requestToken == driveHistoryDetailRequestToken) {
                    state = state.copy(
                        driveHistoryDetail = detail,
                        driveHistoryDetailLoading = false
                    )
                }
            }
        }
    }

    fun clearDriveHistoryDetail() {
        driveHistoryDetailRequestToken++
        state = state.copy(driveHistoryDetail = null, driveHistoryDetailLoading = false)
    }

    private suspend fun refreshHistoryState() {
        val drives = runCatching { sqlStore.listDriveHistory() }.getOrDefault(emptyList())
        val tests = runCatching { sqlStore.listTestHistory() }.getOrDefault(emptyList())
        val technical = runCatching { sqlStore.listTechnicalSessions(20) }.getOrDefault(emptyList())
        val storage = runCatching { sqlStore.historyStorageInfo() }.getOrDefault(state.historyStorage)
        val currentHealthHistorySignature = healthHistorySignature(drives)
        val nowElapsed = SystemClock.elapsedRealtime()
        val shouldRefreshHealth = currentHealthHistorySignature != vehicleHealthHistorySignature ||
            nowElapsed - vehicleHealthEvidenceRefreshElapsedMs >= VEHICLE_HEALTH_REFRESH_INTERVAL_MS
        val healthEvidence = if (shouldRefreshHealth) {
            runCatching { sqlStore.loadVehicleHealthEvidence() }.getOrDefault(state.vehicleHealthEvidence)
        } else {
            state.vehicleHealthEvidence
        }
        if (shouldRefreshHealth) {
            vehicleHealthHistorySignature = currentHealthHistorySignature
            vehicleHealthEvidenceRefreshElapsedMs = nowElapsed
        }
        withMain {
            state = state.copy(
                driveHistory = drives,
                testHistory = tests,
                technicalHistory = technical,
                historyStorage = storage,
                vehicleHealthEvidence = healthEvidence
            )
        }
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth / Yakındaki cihazlar izni bekleniyor. İzin verilmeden cihaz listesi okunamaz.", error = true)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            appendStatus("Bu cihazda Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        if (!adapter.isEnabled) {
            appendStatus("Bluetooth kapalı. Android Bluetooth ayarlarından açıp tekrar deneyin.", error = true)
            return
        }
        val devices = runCatching {
            adapter.bondedDevices.orEmpty()
                .map { PairedObdDevice(it.name ?: "OBD cihazı", it.address) }
                .sortedWith(compareByDescending<PairedObdDevice> { looksLikeObd(it.name) }.thenBy { it.name })
        }.getOrElse { error ->
            appendStatus("Bluetooth cihaz listesi okunamadı: ${error.message ?: error.javaClass.simpleName}", error = true)
            return
        }
        state = state.copy(
            pairedDevices = devices,
            status = if (devices.isEmpty()) {
                "Eşleşmiş OBD cihazı bulunamadı • Android Bluetooth ayarlarından önce eşleştirin"
            } else {
                "${devices.size} eşleşmiş cihaz bulundu • cihaz listesi güncellendi"
            },
            lastError = null,
            logText = trimLog(state.logText + "\n[BT] Paired devices refreshed: ${devices.joinToString { it.displayName }}")
        )
    }

    fun selectDevice(device: PairedObdDevice) {
        if (device.address != state.selectedAddress) {
            cancelPendingReconnect("device changed")
        }
        state = state.copy(
            selectedAddress = device.address,
            selectedName = device.name,
            status = "Seçildi: ${device.name}",
            lastError = null,
            logText = trimLog(state.logText + "\n[BT] Selected ${device.displayName}")
        )
    }

    fun setFuelRefillLiters(text: String): Boolean {
        val normalized = text.trim().replace(',', '.')
        if (normalized.isBlank()) {
            dynamic026GroupPrefs.edit().remove(KEY_FUEL_REFILL_LITERS).apply()
            state = state.copy(fuelRefillLitersText = "", status = "Eklenen yakıt miktarı temizlendi")
            return true
        }
        val liters = normalized.toDoubleOrNull()
        if (liters == null || liters <= 0.0 || liters > 100.0) {
            state = state.copy(status = "Yakıt miktarını 0–100 litre arasında girin", lastError = "Geçersiz yakıt miktarı")
            return false
        }
        val stored = String.format(Locale.US, "%.3f", liters).trimEnd('0').trimEnd('.')
        dynamic026GroupPrefs.edit().putString(KEY_FUEL_REFILL_LITERS, stored).apply()
        state = state.copy(fuelRefillLitersText = stored.replace('.', ','), status = "Eklenen yakıt: ${stored.replace('.', ',')} litre")
        return true
    }

    private fun clearPendingDeveloperTest(reason: String? = null) {
        pendingDeveloperTestReconnectJob?.cancel()
        pendingDeveloperTestReconnectJob = null
        val old = pendingDeveloperTestName
        pendingDeveloperTestName = null
        pendingDeveloperTestRequestedMs = 0L
        pendingDeveloperTestReconnectAttempts = 0
        state = state.copy(pendingDeveloperTestName = null)
        if (reason != null && old != null) appendLog("[TEST_AUTO_RECOVERY_CLEAR] test=$old reason=$reason")
    }

    private fun requestDeveloperTestConnectionRecovery(name: String) {
        val address = state.selectedAddress
        if (address.isNullOrBlank()) {
            state = state.copy(status = "$name için önce OBD cihazını seçin")
            return
        }
        if (pendingDeveloperTestName != name) {
            clearPendingDeveloperTest("new request")
            pendingDeveloperTestName = name
            pendingDeveloperTestRequestedMs = SystemClock.elapsedRealtime()
            pendingDeveloperTestReconnectAttempts = 0
        }
        state = state.copy(
            pendingDeveloperTestName = name,
            developerTestPhaseText = "OBD oturumu yenileniyor",
            developerTestProgressText = "Kontak/marş geçişinden sonra canlı motor durumu yenilenmedi. LoganOS bağlantıyı kapatıp yeniden açacak; testi yeniden başlatmayın.",
            developerTestProgressPercent = 0,
            status = "$name için OBD bağlantısı otomatik yenileniyor"
        )
        schedulePendingDeveloperTestReconnect(address)
    }

    private fun schedulePendingDeveloperTestReconnect(address: String) {
        if (pendingDeveloperTestReconnectJob?.isActive == true) return
        if (pendingDeveloperTestReconnectAttempts >= DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS) {
            val name = pendingDeveloperTestName
            clearPendingDeveloperTest("attempt limit")
            state = state.copy(
                developerTestPhaseText = "RPM alınamadı",
                developerTestProgressText = "İki otomatik OBD yenilemesi sonuç vermedi. Motorun çalıştığını kontrol edip OBD Bağlan düğmesine basın; sonra bu aşamayı yeniden başlatın.",
                status = "${name ?: "Test"}: RPM alınamadı"
            )
            return
        }
        pendingDeveloperTestReconnectJob = scope.launch {
            pendingDeveloperTestReconnectAttempts++
            val attempt = pendingDeveloperTestReconnectAttempts
            withMain {
                state = state.copy(
                    connectionHealth = ObdConnectionHealth.RECONNECTING,
                    developerTestPhaseText = "OBD yeniden bağlanıyor • deneme $attempt/$DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS",
                    developerTestProgressText = "Bağlantı yenilendikten sonra RPM görünürse aşama otomatik başlayacak.",
                    status = "Test için OBD yeniden bağlanıyor"
                )
            }
            disconnect(silent = true, recordTripStop = false, stopBackgroundService = false)
            delay(DEVELOPER_TEST_RECONNECT_DELAY_MS)
            if (pendingDeveloperTestName != null && state.selectedAddress == address) {
                connect(address, autoReconnectAttempt = true)
            }
            delay(DEVELOPER_TEST_RECONNECT_WAIT_MS)
            pendingDeveloperTestReconnectJob = null
            if (pendingDeveloperTestName != null) schedulePendingDeveloperTestReconnect(address)
        }
    }

    private fun maybeStartPendingDeveloperTest(snapshot: DashboardSnapshot) {
        val name = pendingDeveloperTestName ?: return
        val mode = dynamic026ModeForName(name) ?: run {
            clearPendingDeveloperTest("unknown mode")
            return
        }
        val rpm = snapshot.rpm
        val speed = snapshot.speedKmh ?: 0
        val engineRequired = dynamic026EngineRequired(mode)
        val koeoRequired = dynamic026KoeoRequired(mode)
        val ready = state.connected && speed <= 2 && when {
            engineRequired -> rpm != null && rpm >= 500
            koeoRequired -> rpm == null || rpm <= 50
            else -> true
        }
        if (ready) {
            clearPendingDeveloperTest("ready")
            startDynamic026Test(name, allowConnectionRecovery = false)
        }
    }

    fun connectSelected() {
        if (demoModeActive || runtimeSettings.demoMode) {
            appendStatus("Demo Modu açıkken gerçek OBD bağlantısı başlatılamaz. Önce Demo Modunu kapatın.", error = true)
            return
        }
        if (state.connecting) {
            appendStatus("OBD bağlantı işlemi zaten sürüyor.")
            return
        }
        val address = state.selectedAddress
        if (address == null) {
            appendStatus("Önce vLinker MC+ / ELM327 cihazını seç.", error = true)
            return
        }
        connect(address)
    }

    @SuppressLint("MissingPermission")
    private fun connect(
        address: String,
        autoReconnectAttempt: Boolean = false,
        ignitionWakeProbe: Boolean = false
    ) {
        if (demoModeActive || runtimeSettings.demoMode) {
            appendStatus("Demo Modu açıkken gerçek OBD bağlantısı başlatılamaz.", error = true)
            return
        }
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni yok. Android izin ekranından izin verilmeli.", error = true)
            return
        }
        val adapterBeforeConnect = BluetoothAdapter.getDefaultAdapter()
        if (adapterBeforeConnect == null) {
            appendStatus("Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        if (!adapterBeforeConnect.isEnabled) {
            appendStatus("Bluetooth kapalı. Android Bluetooth ayarlarından açıp tekrar deneyin.", error = true)
            return
        }

        val connectMark = timeSource.now()
        // The stop mark is captured at confirmed ignition-off, not when the
        // Bluetooth socket finally dies. Keep it until a trustworthy running
        // RPM frame proves that the next ignition has actually started.
        val previousDisconnect = lastDisconnectMark ?: loadLastTripStopMark()
        disconnect(silent = true, recordTripStop = false, stopBackgroundService = false)
        val generation = beginConnectionGeneration()
        val smartTripDecision = applySmartTripPolicy(previousDisconnect, connectMark)
        lastDisconnectMark = previousDisconnect
        resetIgnitionTrackingForConnection(inheritedStopMark = previousDisconnect)
        ignitionWakeProbeActive = ignitionWakeProbe
        ignitionWakeProbeValidated = false
        val sessionId = sqlStore.startSession(
            BuildConfig.VERSION_NAME,
            state.selectedName,
            address,
            if (previousDisconnect != null) null else activeTripHistoryId
        )
        currentSqlSessionId = sessionId
        lastSqlSessionId = sessionId
        smartTripDecision?.let { (eventName, note) ->
            sqlStore.insertEvent(sessionId, "SMART_TRIP", eventName, note)
        }
        lastSqlSampleMs = 0L
        engineTempWindow.clear()
        lastAcMismatchSignature = null
        resetConnectionHealthRuntime()
        parser.resetRuntimeState()
        lastRpmForCrank = null
        engineOffSinceElapsedMs = null
        resetCrankRuntime()
        crankManual = false
        val experimentalPetrol = runtimeSettings.fuelType == FuelType.Petrol
        val activeProfile = if (experimentalPetrol) "GENERIC_PETROL_EXPERIMENTAL" else "DELPHI_DCM1_2"
        val profileNote = if (experimentalPetrol) {
            "vehicle=${runtimeSettings.vehicleModel}; year=${runtimeSettings.modelYearText}; engine=${runtimeSettings.engine}; code=${runtimeSettings.engineCodeText}; cc=${runtimeSettings.engineDisplacementCcText}; hp=${runtimeSettings.enginePowerHpText}; cylinders=${runtimeSettings.cylinderCount}"
        } else {
            "vehicle=${runtimeSettings.vehicleModel}; engine=${runtimeSettings.engine}"
        }
        sqlStore.insertEvent(sessionId, "CONNECT_REQUEST", "OBD bağlantısı", state.selectedName ?: address)
        sqlStore.insertEvent(sessionId, "VEHICLE_PROFILE", activeProfile, profileNote)
        state = state.copy(
            connecting = true,
            connected = false,
            connectionHealth = if (autoReconnectAttempt) ObdConnectionHealth.RECONNECTING else ObdConnectionHealth.CONNECTING,
            connectionHealthReason = null,
            signalHoldActive = false,
            status = if (autoReconnectAttempt) "Bluetooth yeniden bağlanıyor..." else "Bluetooth bağlanıyor...",
            lastError = null,
            sqlSessionId = sessionId,
            sqlDbPath = sqlStore.databaseFile().absolutePath,
            loopCount = 0,
            noDataCount = 0,
            stoppedCount = 0,
            busInitCount = 0,
            slowLoopCount = 0,
            connectionUnstableCount = 0,
            rawEcuLogEnabled = rawEcuLogEnabled,
            longTripLogEnabled = longTripLogEnabled,
            activeProfile = activeProfile,
            rawStandardObd = "",
            supportedStandardPids = emptySet(),
            manualCrankArmed = false,
            crankingInProgress = false,
            timeTrusted = connectMark.trusted
        )
        if (!demoModeActive && shouldRunForegroundService(runtimeSettings)) {
            ObdForegroundService.start(context)
        }

        job = scope.launch {
            var ownedSocket: BluetoothSocket? = null
            try {
                val streams = withTimeout(32000L) {
                    val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth adaptörü yok")
                    if (!adapter.isEnabled) error("Bluetooth kapalı")
                    val device = adapter.getRemoteDevice(address)
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            appendLog("[BT] Connecting to ${device.name ?: address} / $address gen=$generation")
                        }
                    }
                    adapter.cancelDiscovery()
                    val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                    ownedSocket = sock
                    sock.connect()
                    if (!isConnectionCurrent(generation, address)) {
                        runCatching { sock.close() }
                        throw CancellationException("stale connection generation")
                    }
                    socket = sock
                    val out = sock.outputStream
                    val input = sock.inputStream
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            state = state.copy(connecting = false, connected = true, status = "Bluetooth bağlı • ELM init başlıyor")
                        }
                    }

                    val initCommands = if (experimentalPetrol) {
                        listOf(
                            Triple("ATZ", 1000L, 2200L),
                            Triple("ATE0", 150L, 1000L),
                            Triple("ATL0", 150L, 1000L),
                            Triple("ATS1", 150L, 1000L),
                            Triple("ATH1", 150L, 1000L),
                            Triple("ATSP0", 250L, 2500L)
                        )
                    } else {
                        listOf(
                            // Alpha 1.4.9 ile çalışan Delphi DCM1.2 / VDIAG08 init dizisi.
                            Triple("ATZ", 1000L, 2200L),
                            Triple("ATE0", 150L, 1000L),
                            Triple("ATL0", 150L, 1000L),
                            Triple("ATS1", 150L, 1000L),
                            Triple("ATH1", 150L, 1000L),
                            Triple("ATSP5", 150L, 1000L),
                            Triple("ATIIA7A", 150L, 1000L),
                            Triple("ATWM817AF1", 150L, 1000L),
                            Triple("ATSH817AF1", 150L, 1000L),
                            Triple("ATFI", 600L, 6500L),
                            Triple("10C0", 250L, 1800L)
                        )
                    }
                    initCommands.forEach { (cmd, wait, timeout) ->
                        if (!isConnectionCurrent(generation, address)) throw CancellationException("stale init")
                        val resp = send(out, input, cmd, wait, timeout)
                        withMain {
                            if (isConnectionCurrent(generation, address)) {
                                appendLog("${if (cmd.isBlank()) "<wake>" else cmd}  =>  $resp")
                            }
                        }
                    }
                    Pair(out, input)
                }
                if (!isConnectionCurrent(generation, address)) throw CancellationException("stale after init")

                if (experimentalPetrol) {
                    val supported = scanSupportedStandardPids(streams.first, streams.second, generation, address)
                    if (!isConnectionCurrent(generation, address)) throw CancellationException("stale petrol scan")
                    sqlStore.insertEvent(
                        sessionId,
                        "CONNECT_OK",
                        "Benzinli deneysel OBD döngüsü",
                        "supported=${supported.sorted().joinToString { "01%02X".format(Locale.US, it) }}"
                    )
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            state = state.copy(
                                connecting = false,
                                connected = true,
                                connectionHealth = ObdConnectionHealth.STABLE,
                                connectionHealthReason = null,
                                signalHoldActive = false,
                                supportedStandardPids = supported,
                                status = "Benzinli deneysel profil • temel OBD okuma aktif"
                            )
                        }
                    }
                    pollGenericPetrolLoop(streams.first, streams.second, supported, generation, address, sessionId)
                } else {
                    sqlStore.insertEvent(sessionId, "CONNECT_OK", "KWP test döngüsü", "poll loop başladı")
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            state = state.copy(
                                connecting = false,
                                connected = true,
                                connectionHealth = ObdConnectionHealth.STABLE,
                                connectionHealthReason = null,
                                signalHoldActive = false,
                                status = "KWP test döngüsü başladı"
                            )
                        }
                    }
                    pollLoop(streams.first, streams.second, generation, address, sessionId)
                }
            } catch (t: TimeoutCancellationException) {
                if (!isConnectionCurrent(generation, address)) {
                    closeSocket(ownedSocket)
                    return@launch
                }
                val effectiveSessionId = currentSqlSessionId ?: sessionId
                val ignitionWaiting = isExpectedIgnitionWait()
                if (ignitionWaiting) {
                    sqlStore.insertEvent(effectiveSessionId, "IGNITION_WAIT", "Kontak kapalı", "Zaman aşımı; düşük frekanslı motor bekleme")
                    markExpectedIgnitionOffDisconnect(effectiveSessionId)
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            state = state.copy(
                                connecting = false,
                                connected = false,
                                connectionHealth = ObdConnectionHealth.DISCONNECTED,
                                connectionHealthReason = "Kontak kapalı • motor bekleniyor",
                                signalHoldActive = false,
                                sqlSessionId = null,
                                lastError = null,
                                status = "Kontak kapalı • motor bekleniyor",
                                snapshot = state.snapshot.copy(connected = false, rpm = 0, speedKmh = 0)
                            )
                        }
                    }
                    closeSocket(ownedSocket)
                    job = null
                    scheduleIgnitionWakeProbe(address)
                } else {
                    sqlStore.insertEvent(effectiveSessionId, "CONNECT_ERROR", "Zaman aşımı", "Tekrar Bağlan ile yeniden denenebilir")
                    markUnexpectedDisconnect(effectiveSessionId)
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            appendStatus("Bağlantı zaman aşımı. Tekrar Bağlan ile yeniden denenebilir.", error = true)
                            state = state.copy(
                                connecting = false,
                                connected = false,
                                connectionHealth = ObdConnectionHealth.DISCONNECTED,
                                connectionHealthReason = "Bağlantı zaman aşımı",
                                signalHoldActive = false,
                                sqlSessionId = null,
                                snapshot = state.snapshot.copy(connected = false)
                            )
                        }
                    }
                    closeSocket(ownedSocket)
                    ObdForegroundService.stop(context)
                }
            } catch (t: CancellationException) {
                closeSocket(ownedSocket)
                withMain {
                    if (isConnectionCurrent(generation, address)) {
                        state = state.copy(
                            connecting = false,
                            connected = false,
                            connectionHealth = ObdConnectionHealth.DISCONNECTED,
                            connectionHealthReason = null,
                            signalHoldActive = false,
                            sqlSessionId = null,
                            snapshot = state.snapshot.copy(connected = false)
                        )
                    }
                }
            } catch (t: Throwable) {
                if (!isConnectionCurrent(generation, address)) {
                    closeSocket(ownedSocket)
                    return@launch
                }
                val message = t.message ?: t.javaClass.simpleName
                val effectiveSessionId = currentSqlSessionId ?: sessionId
                val ignitionWaiting = isExpectedIgnitionWait()
                val wasPolling = state.connected || state.loopCount > 0
                if (crankStartMs != null) {
                    crankObdGapDetected = true
                    val mark = timeSource.now()
                    finishCranking(
                        mark.elapsedMs,
                        mark.epochMs ?: 0L,
                        mark.trusted,
                        lastRpmForCrank ?: 0,
                        completed = crankRunningDetectedMs != null,
                        stableIdleRpm = null
                    )
                }
                if (ignitionWaiting) {
                    sqlStore.insertEvent(effectiveSessionId, "IGNITION_WAIT", "Kontak kapalı", message)
                    markExpectedIgnitionOffDisconnect(effectiveSessionId)
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            state = state.copy(
                                connecting = false,
                                connected = false,
                                connectionHealth = ObdConnectionHealth.DISCONNECTED,
                                connectionHealthReason = "Kontak kapalı • motor bekleniyor",
                                signalHoldActive = false,
                                sqlSessionId = null,
                                lastError = null,
                                status = "Kontak kapalı • motor bekleniyor",
                                snapshot = state.snapshot.copy(connected = false, rpm = 0, speedKmh = 0)
                            )
                        }
                    }
                    closeSocket(ownedSocket)
                    job = null
                    scheduleIgnitionWakeProbe(address)
                } else {
                    sqlStore.insertEvent(effectiveSessionId, "CONNECT_ERROR", "Bağlantı hatası", message)
                    markUnexpectedDisconnect(effectiveSessionId)
                    val shouldRetry = wasPolling && !autoReconnectAttempt && isConnectionCurrent(generation, address)
                    withMain {
                        if (isConnectionCurrent(generation, address)) {
                            appendStatus(
                                if (shouldRetry) "Bağlantı koptu: $message • 2 sn içinde bir kez yeniden denenecek" else "Bağlantı hatası: $message",
                                error = true
                            )
                            state = state.copy(
                                connecting = false,
                                connected = false,
                                connectionHealth = if (shouldRetry) ObdConnectionHealth.RECONNECTING else ObdConnectionHealth.DISCONNECTED,
                                connectionHealthReason = if (shouldRetry) "Bağlantı koptu; otomatik yeniden bağlanma bekleniyor" else message,
                                signalHoldActive = false,
                                sqlSessionId = null,
                                snapshot = state.snapshot.copy(connected = false)
                            )
                            if (shouldRetry) {
                                sqlStore.insertEvent(effectiveSessionId, "AUTO_RECONNECT", "Tek deneme", "2 sn sonra yeniden bağlanılacak")
                            }
                        }
                    }
                    closeSocket(ownedSocket)
                    if (shouldRetry) {
                        job = null
                        cancelPendingReconnect("new reconnect scheduled")
                        pendingReconnectJob = scope.launch {
                            delay(2000L)
                            if (
                                generation == connectionGeneration &&
                                !demoModeActive && !runtimeSettings.demoMode &&
                                !state.connected && !state.connecting &&
                                state.selectedAddress == address
                            ) {
                                pendingReconnectJob = null
                                connect(address, autoReconnectAttempt = true)
                            }
                        }
                    } else {
                        ObdForegroundService.stop(context)
                    }
                }
            }
        }
    }

    private fun isExpectedIgnitionWait(): Boolean {
        val candidate = ignitionOffCandidateMark
        val candidateConfirmedByTime = candidate != null &&
            (timeSource.gapMillis(candidate, timeSource.now()) ?: 0L) >= IGNITION_OFF_DISCONNECT_GRACE_MS
        return confirmedIgnitionOffMark != null || candidateConfirmedByTime ||
            (ignitionWakeProbeActive && !ignitionWakeProbeValidated)
    }

    private fun resetIgnitionTrackingForConnection(inheritedStopMark: TimeMark? = null) {
        lastTrustedEngineRunningMark = null
        ignitionOffCandidateMark = null
        confirmedIgnitionOffMark = inheritedStopMark
        engineRunningObservedSinceConnect = false
        lastTrustedCoolantTempC = null
    }

    private fun observeIgnitionState(
        rpm: Int?,
        reliableMainPacket: Boolean,
        mark: TimeMark
    ): IgnitionObservation {
        if (!reliableMainPacket || rpm == null) {
            val candidate = ignitionOffCandidateMark
            if (candidate != null && confirmedIgnitionOffMark == null) {
                val candidateAge = timeSource.gapMillis(candidate, mark) ?: 0L
                if (candidateAge >= IGNITION_OFF_CONFIRM_MS) {
                    confirmedIgnitionOffMark = candidate
                    return IgnitionObservation(confirmedOffMark = candidate)
                }
            }
            return IgnitionObservation()
        }

        if (rpm > ENGINE_RUNNING_RPM_THRESHOLD) {
            val previousOff = confirmedIgnitionOffMark
            val shouldReevaluateBoundary = previousOff != null
            // The SQL session that waited through ignition-off (or performed a
            // wake probe) must never become the driving session. Rotate at the
            // first trustworthy running-RPM frame so session timestamps and
            // zero-sample filtering remain accurate.
            val needsSessionRotation = previousOff != null
            lastTrustedEngineRunningMark = mark
            ignitionOffCandidateMark = null
            confirmedIgnitionOffMark = null
            engineRunningObservedSinceConnect = true
            ignitionWakeProbeValidated = true
            ignitionWakeProbeActive = false
            lastDisconnectMark = null
            clearLastTripStopMark()
            return IgnitionObservation(
                engineRunning = true,
                resumedAfterOffMark = previousOff,
                shouldReevaluateBoundary = shouldReevaluateBoundary,
                needsSessionRotation = needsSessionRotation
            )
        }

        if (!engineRunningObservedSinceConnect || lastTrustedEngineRunningMark == null) {
            return IgnitionObservation()
        }

        val candidate = ignitionOffCandidateMark ?: mark.also { ignitionOffCandidateMark = it }
        val confirmed = confirmedIgnitionOffMark
        if (confirmed == null) {
            val candidateAge = timeSource.gapMillis(candidate, mark) ?: 0L
            if (candidateAge >= IGNITION_OFF_CONFIRM_MS) {
                confirmedIgnitionOffMark = candidate
                return IgnitionObservation(confirmedOffMark = candidate)
            }
        }
        return IgnitionObservation()
    }

    private fun recordConfirmedIgnitionOff(mark: TimeMark, trip: TripComputerSnapshot) {
        persistentCockpitTrip.update(trip, force = true, nowElapsedMs = mark.elapsedMs)
        persistTripRuntime(mark, force = true)
        saveLastTripStopMark(mark)
        lastDisconnectMark = mark
        sqlStore.parkTripRecord(
            recordId = activeTripHistoryId,
            endMark = mark,
            distanceKm = trip.distanceKm,
            fuelUsedL = trip.fuelUsedL,
            durationMs = trip.durationSec * 1000L,
            averageL100 = trip.averageL100,
            endTempC = lastTrustedCoolantTempC
        )
        val sessionId = currentSqlSessionId
        sqlStore.insertEvent(sessionId ?: lastSqlSessionId, "IGNITION_OFF", "Kontak kapandı", "trip duration frozen at confirmed engine stop")
        sqlStore.endSession(sessionId, state = "ENDED_IGNITION_OFF", endMark = mark)
        if (sessionId != null) lastSqlSessionId = sessionId
        if (currentSqlSessionId == sessionId) currentSqlSessionId = null
        appendLog("[IGNITION_OFF] confirmed at elapsed=${mark.elapsedMs}; trip duration paused")
    }

    private fun markExpectedIgnitionOffDisconnect(sessionId: Long?) {
        flushFuelCalibrationProgress()
        val stopMark = confirmedIgnitionOffMark ?: ignitionOffCandidateMark ?: lastDisconnectMark ?: loadLastTripStopMark() ?: timeSource.now()
        // A wake-probe session starts after the actual ignition-off mark. End
        // that technical session at the current time; never write an end time
        // earlier than its own start. The trip itself still parks at stopMark.
        val waitingProbeSession = ignitionWakeProbeActive && !ignitionWakeProbeValidated
        val sessionEndMark = if (waitingProbeSession) timeSource.now() else stopMark
        val sessionEndState = if (waitingProbeSession) "ENDED_IGNITION_WAIT" else "ENDED_IGNITION_OFF"
        tripComputer.pauseDuration(stopMark.elapsedMs)
        val trip = tripComputer.snapshot(stopMark.elapsedMs)
        persistentCockpitTrip.update(trip, force = true, nowElapsedMs = stopMark.elapsedMs)
        interruptActiveHistoryTests("Kontak kapandı")
        sqlStore.parkTripRecord(
            recordId = activeTripHistoryId,
            endMark = stopMark,
            distanceKm = trip.distanceKm,
            fuelUsedL = trip.fuelUsedL,
            durationMs = trip.durationSec * 1000L,
            averageL100 = trip.averageL100,
            endTempC = lastTrustedCoolantTempC
        )
        persistTripRuntime(stopMark, force = true)
        saveLastTripStopMark(stopMark)
        gpsRouteRecorder.onObdDisconnected()
        sqlStore.endSession(sessionId, state = sessionEndState, endMark = sessionEndMark)
        if (sessionId != null) lastSqlSessionId = sessionId
        if (currentSqlSessionId == sessionId) currentSqlSessionId = null
        lastDisconnectMark = stopMark
    }

    private fun startSessionAfterInPlaceIgnitionRestart(restartMark: TimeMark): Long {
        val waitingSessionId = currentSqlSessionId
        if (waitingSessionId != null) {
            sqlStore.endSession(waitingSessionId, state = "ENDED_IGNITION_WAIT", endMark = restartMark)
            lastSqlSessionId = waitingSessionId
        }
        val id = sqlStore.startSession(
            BuildConfig.VERSION_NAME,
            state.selectedName,
            state.selectedAddress,
            activeTripHistoryId
        )
        currentSqlSessionId = id
        lastSqlSessionId = id
        sqlStore.insertEvent(id, "IGNITION_RESTART", "Motor yeniden çalıştı", "new driving session after confirmed ignition-off")
        return id
    }

    private fun markUnexpectedDisconnect(sessionId: Long?) {
        flushFuelCalibrationProgress()
        val mark = timeSource.now()
        val trip = tripComputer.snapshot(mark.elapsedMs)
        persistentCockpitTrip.update(trip, force = true, nowElapsedMs = mark.elapsedMs)
        interruptActiveHistoryTests("OBD bağlantısı beklenmedik şekilde kesildi")
        sqlStore.parkTripRecord(
            recordId = activeTripHistoryId,
            endMark = mark,
            distanceKm = trip.distanceKm,
            fuelUsedL = trip.fuelUsedL,
            durationMs = trip.durationSec * 1000L,
            averageL100 = trip.averageL100,
            endTempC = lastTrustedCoolantTempC
        )
        persistTripRuntime(mark, force = true)
        // A transport failure is not evidence that the ignition was switched
        // off. Do not start the Smart Trip gap clock from a broken socket.
        clearLastTripStopMark()
        gpsRouteRecorder.onObdDisconnected()
        sqlStore.endSession(sessionId, state = "INTERRUPTED", endMark = mark)
        if (sessionId != null) lastSqlSessionId = sessionId
        if (currentSqlSessionId == sessionId) currentSqlSessionId = null
        lastDisconnectMark = null
    }

    fun disconnect(
        silent: Boolean = false,
        recordTripStop: Boolean = true,
        stopBackgroundService: Boolean = true
    ) {
        flushFuelCalibrationProgress()
        val sessionId = currentSqlSessionId
        invalidateConnectionWork(if (silent) "silent disconnect" else "manual disconnect")
        if (stopBackgroundService) ObdForegroundService.stop(context)
        job?.cancel()
        job = null
        closeSocket()
        if (crankStartMs != null) {
            crankObdGapDetected = true
            val mark = timeSource.now()
            finishCranking(
                mark.elapsedMs,
                mark.epochMs ?: 0L,
                mark.trusted,
                lastRpmForCrank ?: 0,
                completed = crankRunningDetectedMs != null,
                stableIdleRpm = null
            )
        }
        interruptActiveHistoryTests("Kontak veya bağlantı kapandı")
        val nowMark = timeSource.now()
        val disconnectMark = confirmedIgnitionOffMark ?: nowMark
        if (confirmedIgnitionOffMark != null) {
            tripComputer.pauseDuration(disconnectMark.elapsedMs)
        }
        val disconnectTrip = tripComputer.snapshot(disconnectMark.elapsedMs)
        if (recordTripStop || confirmedIgnitionOffMark != null) {
            sqlStore.parkTripRecord(
                recordId = activeTripHistoryId,
                endMark = disconnectMark,
                distanceKm = disconnectTrip.distanceKm,
                fuelUsedL = disconnectTrip.fuelUsedL,
                durationMs = disconnectTrip.durationSec * 1000L,
                averageL100 = disconnectTrip.averageL100,
                endTempC = lastTrustedCoolantTempC
            )
        }
        if (state.connected || sessionId != null) {
            persistentCockpitTrip.update(disconnectTrip, force = true, nowElapsedMs = disconnectMark.elapsedMs)
        }
        gpsRouteRecorder.onObdDisconnected()
        sqlStore.insertEvent(sessionId, if (silent) "DISCONNECT_SILENT" else "DISCONNECT", "OBD bağlantısı", null)
        sqlStore.endSession(
            sessionId,
            state = if (confirmedIgnitionOffMark != null) "ENDED_IGNITION_OFF" else "ENDED",
            endMark = disconnectMark
        )
        if (sessionId != null) lastSqlSessionId = sessionId
        if (recordTripStop && (state.connected || sessionId != null)) {
            persistTripRuntime(disconnectMark, force = true)
            saveLastTripStopMark(disconnectMark)
            lastDisconnectMark = disconnectMark
        }
        if (currentSqlSessionId == sessionId) currentSqlSessionId = null
        engineTempWindow.clear()
        lastRpmForCrank = null
        engineOffSinceElapsedMs = null
        lastTrustedEngineRunningMark = null
        ignitionOffCandidateMark = null
        confirmedIgnitionOffMark = null
        engineRunningObservedSinceConnect = false
        ignitionWakeProbeActive = false
        ignitionWakeProbeValidated = false
        lastTrustedCoolantTempC = null
        resetCrankRuntime()
        crankManual = false
        resetConnectionHealthRuntime()
        parser.resetRuntimeState()
        val updated = state.copy(
            connecting = false,
            connected = false,
            connectionHealth = ObdConnectionHealth.DISCONNECTED,
            connectionHealthReason = null,
            signalHoldActive = false,
            connectionUnstableCount = 0,
            lastError = null,
            snapshot = state.snapshot.copy(connected = false),
            manualCrankArmed = false,
            crankingInProgress = false,
            status = if (silent) state.status else "Bağlantı kesildi",
            sqlSessionId = null,
            sqlDbPath = sqlStore.databaseFile().absolutePath,
            timeTrusted = disconnectMark.trusted
        )
        state = updated
        scope.launch { refreshHistoryState() }
        if (!silent) appendLog("[BT] Disconnected")
    }

    private fun interruptActiveHistoryTests(reason: String) {
        val fuelDiscoveryActive = state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME &&
            (fuelDiscoveryStage != FuelDiscoveryStage.IDLE || fuelDiscoveryStopRequested)
        if (fuelDiscoveryActive) {
            if (fuelDiscoveryStage == FuelDiscoveryStage.WAITING_FOR_REFUEL_RESTART) {
                fuelDiscoveryReconnectArmed = true
                fuelDiscoveryDisconnectElapsedMs = SystemClock.elapsedRealtime()
                if (reason == "Kontak kapandı") {
                    fuelDiscoveryIgnitionOffConfirmed = true
                    appendFuelDiscovery("[REFUEL_IGNITION_OFF_CONFIRMED] reason=$reason")
                }
            }
            appendFuelDiscovery("[CONNECTION_PAUSE] reason=$reason stage=${fuelDiscoveryStage.name}")
            state = state.copy(
                developerTestPhaseText = when {
                    fuelDiscoveryStopRequested -> "Kısmi keşif dosyası hazırlanıyor"
                    fuelDiscoveryStage == FuelDiscoveryStage.WAITING_FOR_REFUEL_RESTART -> "Yakıt alımı ve motorun yeniden çalışması bekleniyor"
                    else -> "OBD yeniden bağlanınca keşif testi devam edecek"
                },
                developerTestRemainingSec = null,
                developerTestProgressText = if (fuelDiscoveryStopRequested) {
                    "Mevcut bütün ölçümler korunacak"
                } else {
                    "Test korunuyor • LoganOS'u kapatma"
                }
            )
            appendLog("[FUEL_DISCOVERY_PAUSE] reason=$reason stage=${fuelDiscoveryStage.name}")
            return
        }

        val dynamic026Active = isKwp026DeveloperTest(state.activeDeveloperTest) &&
            (dynamic026Stage != Dynamic026Stage.IDLE || dynamic026StopRequested)
        if (dynamic026Active) {
            appendDynamic026("CONNECTION_PAUSE", "reason=$reason stage=${dynamic026Stage.name}")
            state = state.copy(
                developerTestPhaseText = "OBD bağlantısı kesildi • bölüm duraklatıldı",
                developerTestRemainingSec = null,
                developerTestProgressText = if (dynamic026StopRequested) {
                    "Kısmi sonuç paketi hazırlanıyor"
                } else {
                    "Tamamlanan okumalar korunuyor • yeniden bağlanınca aynı bölüm devam edecek"
                }
            )
            appendLog("[DYNAMIC_026_PAUSE] reason=$reason stage=${dynamic026Stage.name}")
            return
        }

        developerTestJob?.cancel()
        developerTestJob = null
        activeDeveloperTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", reason) }
        activeCrankTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", reason) }
        activeDeveloperTestHistoryId = null
        activeCrankTestHistoryId = null
        if (state.activeDeveloperTest != null || state.manualCrankArmed || state.crankingInProgress) {
            state = state.copy(
                activeDeveloperTest = null,
                developerTestPhaseText = null,
                developerTestRemainingSec = null,
                developerTestProgressText = null,
                manualCrankArmed = false,
                crankingInProgress = false
            )
        }
    }

    fun canCreateOrRestoreDataBackup(): Boolean =
        !state.snapshot.connected && !hasActiveConnectionWork() && currentSqlSessionId == null

    fun createDatabaseBackupSnapshot(): File? {
        if (!canCreateOrRestoreDataBackup()) return null
        return runCatching { sqlStore.snapshotDatabaseFile() }.getOrNull()
    }

    fun release() {
        disconnect(silent = true)
        runCatching { sqlStore.close() }
        gpsRouteRecorder.release()
        scope.cancel()
    }

    private suspend fun scanSupportedStandardPids(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        address: String
    ): Set<Int> {
        val supported = linkedSetOf<Int>()
        val rawParts = mutableListOf<String>()
        listOf(0x00, 0x20, 0x40, 0x60).forEach { base ->
            if (!isConnectionCurrent(generation, address)) throw CancellationException("stale PID scan")
            val command = "01%02X".format(Locale.US, base)
            val raw = send(out, input, command, 55L, 1300L)
            rawParts += "$command=${raw.replace('\n', ' ').trim()}"
            supported += GenericObdParser.supportedPidCommands(raw, base)
            delay(25L)
        }
        withMain {
            if (isConnectionCurrent(generation, address)) {
                state = state.copy(
                    supportedStandardPids = supported,
                    rawStandardObd = rawParts.joinToString(" | ")
                )
            }
        }
        return supported
    }

    private suspend fun pollGenericPetrolLoop(
        out: OutputStream,
        input: InputStream,
        supported: Set<Int>,
        generation: Long,
        address: String,
        sessionId: Long?
    ) {
        var loopIndex = 0
        var rotationIndex = 0
        var lastAtrv = ""
        val rotatingPids = listOf(0x0B, 0x0F, 0x11, 0x04, 0x03, 0x06, 0x07, 0x10, 0x44, 0x5E)
            .filter { supported.isEmpty() || it in supported }
            .ifEmpty { listOf(0x0B, 0x0F, 0x11, 0x04, 0x03, 0x10, 0x5E) }

        while (currentCoroutineContext().isActive && isConnectionCurrent(generation, address)) {
            val start = SystemClock.elapsedRealtime()
            loopIndex++
            if (loopIndex == 1 || loopIndex % 8 == 0) {
                lastAtrv = send(out, input, "ATRV", 35L, 800L)
                delay(15L)
            }

            val commands = linkedSetOf("010C", "010D", "0105")
            repeat(2) {
                val pid = rotatingPids[rotationIndex % rotatingPids.size]
                rotationIndex++
                commands += "01%02X".format(Locale.US, pid)
            }
            val responses = linkedMapOf<String, String>()
            commands.forEach { command ->
                responses[command] = send(out, input, command, 35L, 850L)
                delay(18L)
            }
            if (!isConnectionCurrent(generation, address)) break

            val reading = GenericObdParser.parse(responses)
            val nowElapsedMs = SystemClock.elapsedRealtime()
            val timeMark = timeSource.now()
            val rawCombined = reading.rawJoined
            val upperRaw = rawCombined.uppercase(Locale.US)
            val hasNoData = upperRaw.contains("NO DATA")
            val hasStopped = upperRaw.contains("STOPPED")
            val hasBusInit = upperRaw.contains("BUS INIT")
            val hasGenericTransportError = upperRaw.contains("UNABLE TO CONNECT") ||
                upperRaw.contains("CAN ERROR") || upperRaw.contains("ERROR")
            val genericCrankSampleReliable = reading.rpm != null &&
                !hasNoData && !hasStopped && !hasBusInit && !hasGenericTransportError
            reading.coolantC?.let { lastTrustedCoolantTempC = it }
            val ignitionObservation = observeIgnitionState(
                rpm = reading.rpm,
                reliableMainPacket = genericCrankSampleReliable,
                mark = timeMark
            )
            var inSessionBoundaryEvent: Pair<String, String>? = null
            val (trip, smartTripEvent) = tripMutex.withLock {
                if (!isConnectionCurrent(generation, address)) {
                    tripComputer.snapshot(nowElapsedMs) to null
                } else {
                    if (ignitionObservation.shouldReevaluateBoundary) {
                        inSessionBoundaryEvent = applySmartTripPolicy(
                            ignitionObservation.resumedAfterOffMark,
                            timeMark
                        )
                    }
                    if (ignitionObservation.engineRunning) {
                        tripComputer.setEngineRunning(true, nowElapsedMs)
                    }
                    tripComputer.update(reading.speedKmh?.toDouble(), null, nowElapsedMs)
                    ignitionObservation.confirmedOffMark?.let { offMark ->
                        tripComputer.pauseDuration(offMark.elapsedMs)
                    }
                    val event = inSessionBoundaryEvent ?: resolvePendingTripBoundary(timeMark)
                    tripComputer.snapshot(nowElapsedMs) to event
                }
            }
            if (!isConnectionCurrent(generation, address)) break
            ignitionObservation.confirmedOffMark?.let { offMark ->
                recordConfirmedIgnitionOff(offMark, trip)
            }
            if (ignitionObservation.needsSessionRotation) {
                startSessionAfterInPlaceIgnitionRestart(timeMark)
            }
            if (ignitionObservation.engineRunning && activeTripHistoryId != null) {
                sqlStore.assignSessionToTrip(currentSqlSessionId, activeTripHistoryId)
            }
            var activeSessionId = currentSqlSessionId ?: lastSqlSessionId ?: sessionId
            smartTripEvent?.let { (eventName, note) ->
                sqlStore.insertEvent(activeSessionId, "SMART_TRIP", eventName, note)
            }
            val ignitionWaiting = confirmedIgnitionOffMark != null && !ignitionObservation.engineRunning
            val voltage = Regex("([0-9]+(?:\\.[0-9]+)?)\\s*V", RegexOption.IGNORE_CASE)
                .find(lastAtrv)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
            val segmentSnapshot = DashboardSnapshot(
                speedKmh = reading.speedKmh,
                averageConsumption = null,
                instantConsumption = null,
                instantUnit = "",
                tripDistanceKm = trip.distanceKm,
                engineTempC = smoothEngineTemp(reading.coolantC) ?: lastTrustedCoolantTempC,
                rpm = reading.rpm,
                acOn = null,
                fuelUsedL = null,
                batteryV = voltage,
                adapterVoltageV = voltage,
                pedalPercent = reading.throttlePercent,
                mapMbar = reading.mapMbar,
                airCharge = reading.calculatedLoadPercent,
                intakeTempC = reading.intakeTempC,
                connected = true,
                fuelSource = "PETROL_UNVERIFIED",
                injectionMg = null,
                engineFuelRateLh = reading.engineFuelRateLh,
                mafGramsPerSec = reading.mafGramsPerSec,
                shortFuelTrimPercent = reading.shortFuelTrimPercent,
                longFuelTrimPercent = reading.longFuelTrimPercent,
                commandedEquivalenceRatio = reading.commandedEquivalenceRatio,
                fuelSystemStatus = reading.fuelSystemStatus,
                rawStandardObd = reading.rawJoined,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState,
                tripToken = trip.tripToken
            )
            val cockpitTrip = persistentCockpitTrip.update(trip, nowElapsedMs = nowElapsedMs)
            val snapshot = segmentSnapshot.copy(
                tripDistanceKm = cockpitTrip.totalDistanceKm,
                tripDurationText = cockpitTrip.durationText
            )
            val elapsed = nowElapsedMs - start
            val visibleGenericSnapshot = if (ignitionWaiting) {
                snapshot.copy(
                    speedKmh = 0,
                    rpm = 0,
                    engineTempC = lastTrustedCoolantTempC,
                    connected = true,
                    fuelSource = "IGNITION_OFF"
                )
            } else snapshot
            if (!ignitionWaiting) processCrankingSample(
                visibleGenericSnapshot,
                timeMark.elapsedMs,
                timeMark.epochMs ?: 0L,
                timeMark.trusted,
                rawCombined,
                sampleReliable = genericCrankSampleReliable
            )

            if (!isConnectionCurrent(generation, address)) break
            val shouldStoreSql = !ignitionWaiting && (
                !longTripLogEnabled || lastSqlSampleMs == 0L ||
                    nowElapsedMs - lastSqlSampleMs >= 1000L || hasNoData || hasStopped || hasBusInit
                )
            if (shouldStoreSql && !manualTripEnding) {
                lastSqlSampleMs = nowElapsedMs
                sqlStore.insertSample(
                    sessionId = activeSessionId,
                    loopIndex = loopIndex,
                    loopMs = elapsed,
                    snapshot = segmentSnapshot,
                    raw21cc = "",
                    raw21a0 = "",
                    raw21a2 = "",
                    raw21cd = "",
                    rawObd = rawCombined
                )
                if (!ignitionWaiting && pendingTripBoundary == null && (runtimeSettings.driveHistoryEnabled || activeTripHistoryId != null)) {
                    val recordId = sqlStore.upsertTripRecord(
                        sessionId = activeSessionId,
                        tripToken = trip.tripToken,
                        snapshot = segmentSnapshot,
                        durationMs = trip.durationSec * 1000L,
                        versionName = BuildConfig.VERSION_NAME
                    )
                    if (recordId != null && recordId != activeTripHistoryId) {
                        activeTripHistoryId = recordId
                        saveActiveTripHistory(recordId)
                    }
                }
                listOfNotNull(activeDeveloperTestHistoryId, activeCrankTestHistoryId).distinct().forEach { testId ->
                    sqlStore.insertTestSample(
                        testSessionId = testId,
                        loopIndex = loopIndex,
                        loopMs = elapsed,
                        snapshot = segmentSnapshot,
                        raw21cc = "",
                        raw21a0 = "",
                        raw21a2 = "",
                        raw21cd = "",
                        rawObd = rawCombined
                    )
                }
                if (loopIndex % 12 == 0) refreshHistoryState()
            }
            gpsRouteRecorder.onObdFrame(
                sessionId = activeSessionId,
                speedKmh = visibleGenericSnapshot.speedKmh,
                isConnected = true
            )

            persistTripRuntime(timeMark)
            val loopClock = timeMark.epochMs?.let { SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(it)) } ?: "TIME_PENDING"
            withMain {
                if (!isConnectionCurrent(generation, address)) return@withMain
                state = state.copy(
                    connected = true,
                    connecting = false,
                    sqlSessionId = currentSqlSessionId,
                    status = if (ignitionWaiting) "Kontak kapalı • motor bekleniyor" else "Benzinli deneysel OBD • ${elapsed} ms • yakıt hesabı doğrulanmadı",
                    snapshot = visibleGenericSnapshot,
                    rawStandardObd = rawCombined,
                    timingText = "Mode 01 • loop=${elapsed}ms",
                    loopCount = loopIndex,
                    noDataCount = state.noDataCount + if (hasNoData) 1 else 0,
                    stoppedCount = state.stoppedCount + if (hasStopped) 1 else 0,
                    busInitCount = state.busInitCount + if (hasBusInit) 1 else 0,
                    slowLoopCount = state.slowLoopCount + if (elapsed > 1000L) 1 else 0,
                    timeTrusted = timeMark.trusted,
                    logText = trimLog(
                        state.logText + "\n[LOOP #$loopIndex at=$loopClock ${elapsed}ms] profile=PETROL_EXPERIMENTAL rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} throttle=${snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} map=${snapshot.mapMbar ?: "--"} maf=${snapshot.mafGramsPerSec?.let { String.format(Locale.US, "%.2f", it) } ?: "--"} fuelRateCandidate=${snapshot.engineFuelRateLh?.let { String.format(Locale.US, "%.2f", it) } ?: "--"} fuelSystem=${snapshot.fuelSystemStatus ?: "--"} src=${snapshot.fuelSource} trip=${snapshot.tripStateText ?: "--"} dist=${snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.3f", it) } ?: "--"}"
                    )
                )
            }
            delay(if (ignitionWaiting) IGNITION_OFF_POLL_DELAY_MS else 70L)
        }
    }

    private suspend fun pollLoop(out: OutputStream, input: InputStream, generation: Long, address: String, sessionId: Long?) {
        var loopIndex = 0
        // Never carry optional raw packets across Bluetooth/KWP sessions.
        var lastValidA2 = ""
        var lastValidCC = ""
        var lastValidCD = ""

        while (currentCoroutineContext().isActive && isConnectionCurrent(generation, address)) {
            if (fuelDiscoveryStage == FuelDiscoveryStage.WAITING_FOR_REFUEL_RESTART && fuelDiscoveryReconnectArmed) {
                val disconnectGapMs = fuelDiscoveryDisconnectElapsedMs?.let {
                    (SystemClock.elapsedRealtime() - it).coerceAtLeast(0L)
                }
                val plausibleRefuelRestart = fuelDiscoveryIgnitionOffConfirmed ||
                    (disconnectGapMs != null && disconnectGapMs >= FUEL_DISCOVERY_MIN_REFUEL_GAP_MS)
                fuelDiscoveryReconnectArmed = false
                if (plausibleRefuelRestart) {
                    fuelDiscoveryStage = FuelDiscoveryStage.AFTER_START_SCAN
                    fuelDiscoveryScanRequest = FuelDiscoveryScanRequest("AFTER_START", discoverModules = false)
                    withMain {
                        state = state.copy(
                            developerTestPhaseText = "Motor yeniden çalıştı • yakıt sonrası ilk tarama",
                            developerTestRemainingSec = null,
                            developerTestProgressText = "Araç hareket edebilir; tarama otomatik sürüyor"
                        )
                    }
                    appendFuelDiscovery("[RESTART_DETECTED] connectionGeneration=$generation gapMs=${disconnectGapMs ?: -1} ignitionOffConfirmed=$fuelDiscoveryIgnitionOffConfirmed")
                    fuelDiscoveryIgnitionOffConfirmed = false
                    fuelDiscoveryDisconnectElapsedMs = null
                } else {
                    appendFuelDiscovery("[RECONNECT_IGNORED] reason=gap_too_short gapMs=${disconnectGapMs ?: -1}")
                    fuelDiscoveryDisconnectElapsedMs = null
                    withMain {
                        state = state.copy(
                            developerTestPhaseText = "Ön tarama hazır • yakıt alımı bekleniyor",
                            developerTestRemainingSec = null,
                            developerTestProgressText = "Motoru kapat, yakıt al, sonra çalıştırıp normal şekilde ayrıl"
                        )
                    }
                }
            }

            val pendingFuelDiscoveryScan = fuelDiscoveryScanRequest
            if (pendingFuelDiscoveryScan != null) {
                performFuelDiscoveryScan(
                    out,
                    input,
                    generation,
                    address,
                    currentSqlSessionId ?: sessionId,
                    pendingFuelDiscoveryScan
                )
                continue
            }

            val pendingDynamic026Scan = dynamic026ScanRequest
            if (pendingDynamic026Scan != null) {
                performDynamic026Scan(
                    out,
                    input,
                    generation,
                    address,
                    currentSqlSessionId ?: sessionId,
                    pendingDynamic026Scan
                )
                continue
            }

            val start = SystemClock.elapsedRealtime()
            loopIndex++
            var activeSessionId = currentSqlSessionId ?: sessionId

            // DCUI v1.5.0 proved this Delphi sequence in real driving:
            // authoritative 21A0 first, then 21A2, 21CC and 21CD. Do not place
            // ATRV or unsupported Mode 01 fallbacks between KWP live requests.
            val a0StartMs = SystemClock.elapsedRealtime()
            val rawA0 = send(out, input, "21A0", 50L, 1300L)
            val a0ElapsedMs = SystemClock.elapsedRealtime() - a0StartMs
            if (!isConnectionCurrent(generation, address)) break

            val rawA2 = send(out, input, "21A2", 50L, 1200L)
            if (!isConnectionCurrent(generation, address)) break

            val rawCCFresh = send(out, input, "21CC", 40L, 1000L)
            if (!isConnectionCurrent(generation, address)) break

            val rawCD = send(out, input, "21CD", 40L, 1000L)
            if (!isConnectionCurrent(generation, address)) break

            val validA0 = hasValidKwpPayload(rawA0, "61A0", 34)
            val validA2 = hasValidKwpPayload(rawA2, "61A2", 34)
            val validCC = hasValidKwpPayload(rawCCFresh, "61CC", 14)
            val validCD = hasValidKwpPayload(rawCD, "61CD", 7)

            if (validA2) lastValidA2 = rawA2
            if (validCC) lastValidCC = rawCCFresh
            if (validCD) lastValidCD = rawCD

            // Optional packets may miss one frame. Reuse only their last fully
            // validated payload; never reuse 21A0 because speed/fuel integration
            // must stop on a missing authoritative frame.
            val parseA2 = if (validA2) rawA2 else lastValidA2
            val parseCC = if (validCC) rawCCFresh else lastValidCC
            val parseCD = if (validCD) rawCD else lastValidCD

            val parsed = parser.parse(rawA0, parseA2, parseCC, parseCD)
            val previous = state.snapshot
            val primaryAc = if (validCC) parsed.acOn else null
            val backupAc = if (validCC) acBackupFrom21cc(rawCCFresh) else null
            val acceptedAc = primaryAc ?: previous.acOn

            val mismatchEvent = if (primaryAc != null && backupAc != null && primaryAc != backupAc) {
                val signature = "$primaryAc/$backupAc"
                if (signature != lastAcMismatchSignature) {
                    lastAcMismatchSignature = signature
                    sqlStore.insertEvent(
                        activeSessionId,
                        "AC_BIT_MISMATCH",
                        "Primary/backup uyuşmazlığı",
                        "primary=$primaryAc backup=$backupAc loop=$loopIndex raw=$rawCCFresh"
                    )
                    "\n[AC_BIT_MISMATCH] primary=$primaryAc backup=$backupAc loop=$loopIndex raw=$rawCCFresh"
                } else ""
            } else {
                lastAcMismatchSignature = null
                ""
            }

            val acEvent = if (validCC && primaryAc != null && primaryAc != previous.acOn) {
                sqlStore.insertEvent(activeSessionId, "AC_FAST", if (primaryAc) "ON" else "OFF", "loop=$loopIndex raw=$rawCCFresh")
                "\n[AC_FAST] ${if (primaryAc) "ON" else "OFF"} loop=$loopIndex raw=$rawCCFresh"
            } else ""

            val baseSnapshot = parsed.toSnapshot(rawA0, rawA2, rawCCFresh, rawCD, connected = true)
                .copy(
                    rpm = parsed.rpm ?: previous.rpm,
                    engineTempC = smoothEngineTemp(parsed.coolantC?.toInt()),
                    adapterVoltageV = parsed.adapterVoltageV ?: previous.adapterVoltageV,
                    acOn = acceptedAc,
                    radiatorFanOn = null
                )

            val nowElapsedMs = SystemClock.elapsedRealtime()
            val elapsed = nowElapsedMs - start
            val rawCombined = "$rawA0 $rawA2 $rawCCFresh $rawCD"

            // A response is authoritative when it contains a complete 61A0
            // payload. Error words left over in the same text do not invalidate
            // a complete packet; this prevents a late optional response from
            // poisoning the next command's health decision.
            val hasNoData = !validA0 && rawA0.contains("NO DATA", ignoreCase = true)
            val hasStopped = !validA0 && rawA0.contains("STOPPED", ignoreCase = true)
            val hasBusInit = !validA0 && rawA0.contains("BUS INIT", ignoreCase = true)

            val guardDecision = evaluateConnectionHealth(
                mainPacketMs = a0ElapsedMs,
                rawA0 = rawA0,
                rawCC = rawCCFresh,
                hasNoData = hasNoData,
                hasStopped = hasStopped,
                hasBusInit = hasBusInit,
                nowMs = nowElapsedMs
            )

            val trustedFuelForTrip = parsed.rpm != null && isTrustedFuelSourceForAccounting(parsed.source)
            val timeMark = timeSource.now()
            if (validA0) {
                baseSnapshot.engineTempC?.let { lastTrustedCoolantTempC = it }
            }
            val ignitionObservation = observeIgnitionState(
                rpm = parsed.rpm,
                reliableMainPacket = validA0,
                mark = timeMark
            )

            var inSessionBoundaryEvent: Pair<String, String>? = null
            val (trip, smartTripEvent) = tripMutex.withLock {
                if (!isConnectionCurrent(generation, address)) {
                    tripComputer.snapshot(nowElapsedMs) to null
                } else {
                    if (ignitionObservation.shouldReevaluateBoundary) {
                        inSessionBoundaryEvent = applySmartTripPolicy(
                            ignitionObservation.resumedAfterOffMark,
                            timeMark
                        )
                    }
                    if (ignitionObservation.engineRunning) {
                        tripComputer.setEngineRunning(true, nowElapsedMs)
                    }
                    if (guardDecision.freezeTrip || !trustedFuelForTrip) {
                        // Advance the integration clock without adding distance or fuel.
                        // This prevents a missing injection frame from under-counting fuel
                        // while still avoiding a large dt jump when valid data returns.
                        tripComputer.update(null, null, nowElapsedMs)
                    } else {
                        tripComputer.update(parsed.speedKmh, parsed.fuelLh, nowElapsedMs)
                    }
                    ignitionObservation.confirmedOffMark?.let { offMark ->
                        tripComputer.pauseDuration(offMark.elapsedMs)
                    }
                    val event = inSessionBoundaryEvent ?: resolvePendingTripBoundary(timeMark)
                    tripComputer.snapshot(nowElapsedMs) to event
                }
            }
            if (!isConnectionCurrent(generation, address)) break

            ignitionObservation.confirmedOffMark?.let { offMark ->
                recordConfirmedIgnitionOff(offMark, trip)
            }
            if (ignitionObservation.needsSessionRotation) {
                startSessionAfterInPlaceIgnitionRestart(timeMark)
            }
            if (ignitionObservation.engineRunning && activeTripHistoryId != null) {
                sqlStore.assignSessionToTrip(currentSqlSessionId, activeTripHistoryId)
            }

            activeSessionId = currentSqlSessionId ?: lastSqlSessionId ?: sessionId
            smartTripEvent?.let { (eventName, note) ->
                sqlStore.insertEvent(activeSessionId, "SMART_TRIP", eventName, note)
            }

            val ignitionWaiting = confirmedIgnitionOffMark != null && !ignitionObservation.engineRunning
            val effectiveGuardDecision = if (ignitionWaiting) {
                ConnectionGuardDecision(
                    health = ObdConnectionHealth.STABLE,
                    holdValues = false,
                    blankLiveValues = false,
                    freezeTrip = true,
                    reason = "Kontak kapalı • motor bekleniyor"
                )
            } else {
                guardDecision
            }

            val segmentSnapshot = baseSnapshot.copy(
                averageConsumption = trip.averageL100,
                tripDistanceKm = trip.distanceKm,
                fuelUsedL = trip.fuelUsedL,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState,
                tripToken = trip.tripToken,
                engineTempC = baseSnapshot.engineTempC ?: lastTrustedCoolantTempC
            )
            val cockpitTrip = persistentCockpitTrip.update(trip, nowElapsedMs = nowElapsedMs)
            val measuredSnapshot = segmentSnapshot.copy(
                averageConsumption = cockpitTrip.averageL100,
                tripDistanceKm = cockpitTrip.totalDistanceKm,
                fuelUsedL = cockpitTrip.totalFuelLiters,
                tripDurationText = cockpitTrip.durationText
            )
            if (!effectiveGuardDecision.freezeTrip && trustedFuelForTrip) {
                trackFuelCalibrationProgress(segmentSnapshot)
            }

            val guardedSnapshot = when {
                ignitionWaiting -> measuredSnapshot.copy(
                    speedKmh = 0,
                    rpm = 0,
                    engineTempC = lastTrustedCoolantTempC,
                    acOn = null,
                    instantConsumption = 0.0,
                    injectionMg = 0.0,
                    fuelSource = "IGNITION_OFF"
                )
                effectiveGuardDecision.holdValues -> {
                    val held = lastTrustedLiveSnapshot ?: state.snapshot
                    held.copy(
                        connected = true,
                        averageConsumption = cockpitTrip.averageL100,
                        tripDistanceKm = cockpitTrip.totalDistanceKm,
                        fuelUsedL = cockpitTrip.totalFuelLiters,
                        tripDurationText = cockpitTrip.durationText,
                        tripStateText = trip.displayState,
                        tripToken = trip.tripToken,
                        fuelSource = "SIGNAL_HOLD"
                    )
                }
                effectiveGuardDecision.blankLiveValues -> measuredSnapshot.copy(
                    speedKmh = null,
                    rpm = null,
                    engineTempC = null,
                    acOn = null,
                    instantConsumption = null,
                    injectionMg = null,
                    fuelSource = "NO_SIGNAL"
                )
                else -> measuredSnapshot
            }

            if (effectiveGuardDecision.health == ObdConnectionHealth.STABLE &&
                !effectiveGuardDecision.holdValues &&
                !effectiveGuardDecision.blankLiveValues &&
                !ignitionWaiting
            ) {
                lastTrustedLiveSnapshot = measuredSnapshot
            }

            if (!effectiveGuardDecision.freezeTrip) {
                processCrankingSample(
                    guardedSnapshot,
                    timeMark.elapsedMs,
                    timeMark.epochMs ?: 0L,
                    timeMark.trusted,
                    rawCombined,
                    sampleReliable = effectiveGuardDecision.health == ObdConnectionHealth.STABLE &&
                        !effectiveGuardDecision.holdValues &&
                        !effectiveGuardDecision.blankLiveValues
                )
            }

            val previousHealth = state.connectionHealth
            val healthChanged = previousHealth != effectiveGuardDecision.health
            val healthEvent = if (healthChanged) {
                val detail = effectiveGuardDecision.reason ?: "health=${effectiveGuardDecision.health.name}"
                sqlStore.insertEvent(
                    activeSessionId,
                    "CONNECTION_HEALTH",
                    effectiveGuardDecision.health.name,
                    "loop=$loopIndex $detail"
                )
                "\n[CONNECTION_HEALTH] ${effectiveGuardDecision.health.name} loop=$loopIndex $detail"
            } else ""

            if (!isConnectionCurrent(generation, address)) break
            val historySnapshot = guardedSnapshot.copy(
                averageConsumption = trip.averageL100,
                tripDistanceKm = trip.distanceKm,
                fuelUsedL = trip.fuelUsedL,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState,
                tripToken = trip.tripToken
            )

            val shouldStoreSql = !ignitionWaiting && (
                !longTripLogEnabled ||
                    lastSqlSampleMs == 0L ||
                    nowElapsedMs - lastSqlSampleMs >= 1000L ||
                    hasNoData ||
                    hasStopped ||
                    hasBusInit ||
                    measuredSnapshot.fuelSource == "CUTOFF" ||
                    effectiveGuardDecision.health == ObdConnectionHealth.UNSTABLE
                )

            if (shouldStoreSql && !manualTripEnding) {
                lastSqlSampleMs = nowElapsedMs
                // Store the measured frame, not the UI-held frame. Raw evidence
                // remains available for diagnosis while TripComputer stays guarded.
                sqlStore.insertSample(
                    activeSessionId,
                    loopIndex,
                    elapsed,
                    segmentSnapshot,
                    if (rawEcuLogEnabled) rawCCFresh else "",
                    if (rawEcuLogEnabled) rawA0 else "",
                    if (rawEcuLogEnabled) rawA2 else "",
                    if (rawEcuLogEnabled) rawCD else ""
                )
                if (pendingTripBoundary == null && (runtimeSettings.driveHistoryEnabled || activeTripHistoryId != null)) {
                    val recordId = sqlStore.upsertTripRecord(
                        sessionId = activeSessionId,
                        tripToken = trip.tripToken,
                        snapshot = historySnapshot,
                        durationMs = trip.durationSec * 1000L,
                        versionName = BuildConfig.VERSION_NAME
                    )
                    if (recordId != null && recordId != activeTripHistoryId) {
                        activeTripHistoryId = recordId
                        saveActiveTripHistory(recordId)
                    }
                }
                listOfNotNull(activeDeveloperTestHistoryId, activeCrankTestHistoryId).distinct().forEach { testId ->
                    sqlStore.insertTestSample(
                        testSessionId = testId,
                        loopIndex = loopIndex,
                        loopMs = elapsed,
                        snapshot = segmentSnapshot,
                        raw21cc = rawCCFresh,
                        raw21a0 = rawA0,
                        raw21a2 = rawA2,
                        raw21cd = rawCD
                    )
                }
                if (loopIndex % 12 == 0) refreshHistoryState()
            }

            gpsRouteRecorder.onObdFrame(
                sessionId = activeSessionId,
                speedKmh = guardedSnapshot.speedKmh,
                isConnected = true
            )

            persistTripRuntime(timeMark)
            val loopClock = timeMark.epochMs?.let {
                SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(it))
            } ?: "TIME_PENDING"

            val visibleSnapshot = if (pendingTripBoundary != null && !timeMark.trusted) {
                guardedSnapshot.copy(
                    averageConsumption = null,
                    tripDistanceKm = 0.0,
                    fuelUsedL = 0.0,
                    tripCostText = null,
                    tripDurationText = "00:00",
                    tripStateText = "Saat eşitleniyor…"
                )
            } else guardedSnapshot

            lastLiveContextCapturedElapsedMs = SystemClock.elapsedRealtime()
            maybeStartPendingDeveloperTest(visibleSnapshot)
            advanceFuelDiscoveryAfterDrive(visibleSnapshot.tripDistanceKm)
            advanceDynamic026FromSnapshot(visibleSnapshot)

            val healthStatus = if (ignitionWaiting) {
                "Kontak kapalı • motor bekleniyor"
            } else when (effectiveGuardDecision.health) {
                ObdConnectionHealth.CONNECTING -> "OBD sinyali doğrulanıyor…"
                ObdConnectionHealth.UNSTABLE -> if (effectiveGuardDecision.holdValues) {
                    "Bağlantı kararsız • son güvenilir veri korunuyor"
                } else {
                    "Bağlantı kararsız • OBD verisi bekleniyor"
                }
                ObdConnectionHealth.RECONNECTING -> "Yeniden bağlanıyor…"
                else -> when {
                    effectiveGuardDecision.holdValues -> "OBD bağlı • geçici veri bekleniyor"
                    effectiveGuardDecision.blankLiveValues -> "OBD bağlı • 21A0 ana verisi bekleniyor"
                    pendingTripBoundary != null && !timeMark.trusted -> "Saat eşitleniyor…"
                    else -> "OBD bağlı • ${elapsed} ms"
                }
            }

            withMain {
                if (!isConnectionCurrent(generation, address)) return@withMain
                state = state.copy(
                    connected = true,
                    connecting = false,
                    sqlSessionId = currentSqlSessionId,
                    connectionHealth = effectiveGuardDecision.health,
                    connectionHealthReason = effectiveGuardDecision.reason,
                    signalHoldActive = effectiveGuardDecision.holdValues,
                    connectionUnstableCount = state.connectionUnstableCount +
                        if (healthChanged && effectiveGuardDecision.health == ObdConnectionHealth.UNSTABLE) 1 else 0,
                    status = healthStatus,
                    snapshot = visibleSnapshot,
                    raw21A0 = rawA0,
                    raw21A2 = rawA2,
                    raw21CC = rawCCFresh,
                    raw21CD = rawCD,
                    timingText = "DCUI poll • loop=${elapsed}ms",
                    loopCount = loopIndex,
                    noDataCount = state.noDataCount + if (hasNoData) 1 else 0,
                    stoppedCount = state.stoppedCount + if (hasStopped) 1 else 0,
                    busInitCount = state.busInitCount + if (hasBusInit) 1 else 0,
                    slowLoopCount = state.slowLoopCount + if (elapsed > 1000L) 1 else 0,
                    timeTrusted = timeMark.trusted,
                    logText = trimLog(
                        state.logText +
                            acEvent +
                            mismatchEvent +
                            healthEvent +
                            "\n[LOOP #$loopIndex at=$loopClock ${elapsed}ms] rpm=${measuredSnapshot.rpm ?: "--"} speed=${measuredSnapshot.speedKmh ?: "--"} temp=${measuredSnapshot.engineTempC ?: "--"} fuel=${measuredSnapshot.injectionMg ?: "--"} pedal=${measuredSnapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} map=${measuredSnapshot.mapMbar ?: "--"} air=${measuredSnapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} ac=${measuredSnapshot.acOn ?: "--"} src=${measuredSnapshot.fuelSource} health=${effectiveGuardDecision.health.name} hold=${effectiveGuardDecision.holdValues} trip=${measuredSnapshot.tripStateText ?: "--"} dist=${measuredSnapshot.tripDistanceKm?.let { String.format(Locale.US, "%.3f", it) } ?: "--"} fuelUsed=${measuredSnapshot.fuelUsedL?.let { String.format(Locale.US, "%.4f", it) } ?: "--"} avg=${measuredSnapshot.averageConsumption?.let { String.format(Locale.US, "%.2f", it) } ?: "--"}"
                    )
                )
            }
            delay(if (ignitionWaiting) IGNITION_OFF_POLL_DELAY_MS else 55L)
        }
    }

    private fun resetConnectionHealthRuntime() {
        lastTrustedLiveSnapshot = null
        connectionFaultScore = 0
        connectionFaultSinceMs = 0L
        healthyRecoverySamples = 0
        consecutiveMainPacketFailures = 0
        fastDropSuspected = false
        elmAwaitingLatePrompt = false
        connectionGuardWarmupStartMs = SystemClock.elapsedRealtime()
    }

    private fun isTrustedFuelSourceForAccounting(source: String): Boolean {
        return when (source.uppercase(Locale.US)) {
            "INJECTION", "HOLD", "CUTOFF", "COAST_GUARD", "CRANK_GUARD" -> true
            else -> false
        }
    }

    private fun evaluateConnectionHealth(
        mainPacketMs: Long,
        rawA0: String,
        rawCC: String,
        hasNoData: Boolean,
        hasStopped: Boolean,
        hasBusInit: Boolean,
        nowMs: Long
    ): ConnectionGuardDecision {
        val previous = lastTrustedLiveSnapshot
        val mainPacketHealthy = hasValidKwpPayload(rawA0, "61A0", 34)
        val auxiliaryCcHealthy = hasValidKwpPayload(rawCC, "61CC", 14)
        val slowMainPacket = mainPacketMs >= 1600L
        val warmupAgeMs = (nowMs - connectionGuardWarmupStartMs).coerceAtLeast(0L)
        val initialValidation = previous == null && warmupAgeMs <= CONNECTION_GUARD_WARMUP_MS

        if (mainPacketHealthy) {
            consecutiveMainPacketFailures = 0
            connectionFaultScore = 0
            connectionFaultSinceMs = 0L
            healthyRecoverySamples = (healthyRecoverySamples + 1).coerceAtMost(12)
            fastDropSuspected = false

            return ConnectionGuardDecision(
                health = ObdConnectionHealth.STABLE,
                holdValues = false,
                blankLiveValues = false,
                freezeTrip = false,
                reason = null
            )
        }

        consecutiveMainPacketFailures = (consecutiveMainPacketFailures + 1).coerceAtMost(20)
        connectionFaultScore = consecutiveMainPacketFailures
        healthyRecoverySamples = 0
        fastDropSuspected = false
        if (connectionFaultSinceMs == 0L) connectionFaultSinceMs = nowMs

        val failureAgeMs = (nowMs - connectionFaultSinceMs).coerceAtLeast(0L)
        val canHold = previous != null && failureAgeMs <= CONNECTION_GUARD_HOLD_MS
        val failureReason = buildList {
            add("21A0 valid payload missing $consecutiveMainPacketFailures/$MAIN_PACKET_FAILURES_FOR_UNSTABLE")
            if (hasNoData) add("NO_DATA")
            if (hasStopped) add("STOPPED")
            if (hasBusInit) add("BUS_INIT")
            if (slowMainPacket) add("21A0=${mainPacketMs}ms")
            if (!auxiliaryCcHealthy) add("21CC optional packet missing")
        }.joinToString(", ")

        // Preserve the beta.4.3.0 real-drive protections: invalid samples never
        // mutate TripComputer, and the last trusted frame is held for ~2.2 s.
        // Unlike the broken guard, transient misses do not show KARARSIZ. The
        // warning is reserved for a sustained run of invalid authoritative A0s.
        if (initialValidation || consecutiveMainPacketFailures < MAIN_PACKET_FAILURES_FOR_UNSTABLE) {
            return ConnectionGuardDecision(
                health = if (previous == null) ObdConnectionHealth.CONNECTING else ObdConnectionHealth.STABLE,
                holdValues = canHold,
                blankLiveValues = !canHold,
                freezeTrip = true,
                reason = failureReason
            )
        }

        return ConnectionGuardDecision(
            health = ObdConnectionHealth.UNSTABLE,
            holdValues = canHold,
            blankLiveValues = !canHold,
            freezeTrip = true,
            reason = failureReason
        )
    }

    private fun smoothEngineTemp(current: Int?): Int? {
        if (current == null) return engineTempWindow.lastOrNull()
        engineTempWindow.addLast(current)
        while (engineTempWindow.size > 3) engineTempWindow.removeFirst()
        if (engineTempWindow.size < 3) return current
        // Sert delta engeli yerine 3 örnekli rolling median: tek örneklik
        // sıçramayı bastırır, birkaç örnek süren gerçek termostat/devirdaim
        // değişimini ise gecikmeden takip eder.
        return engineTempWindow.toList().sorted()[1]
    }

    private fun acBackupFrom21cc(raw: String): Boolean? {
        val bytes = Regex("(?i)\\b[0-9a-f]{2}\\b")
            .findAll(raw)
            .map { it.value.toInt(16) }
            .toList()
        val headerIndex = bytes.indices.firstOrNull { i -> i + 1 < bytes.size && bytes[i] == 0x61 && bytes[i + 1] == 0xCC } ?: return null
        val payload = bytes.drop(headerIndex + 2)
        if (payload.size < 2) return null
        return (payload[1] and 0x80) != 0
    }

    private fun applySmartTripPolicy(disconnectedAt: TimeMark?, connectAt: TimeMark): Pair<String, String>? {
        val persisted = loadTripRuntime()
        val current = tripComputer.snapshot(connectAt.elapsedMs)
        val hasTrip = persisted?.let { it.totalDistanceKm > 0.0 || it.totalFuelL > 0.0 || it.pendingDistanceKm > 0.0 } == true ||
            current.distanceKm > 0.0 || current.fuelUsedL > 0.0
        if (!hasTrip) {
            pendingTripBoundary = null
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            return null
        }

        if (disconnectedAt == null) {
            pendingTripBoundary = null
            if (persisted != null) {
                tripComputer.restore(persisted, connectAt.elapsedMs)
                activeTripHistoryId = sqlStore.findTripRecordId(persisted.tripToken)
                saveActiveTripHistory(activeTripHistoryId)
            }
            return "CONTINUE" to "gap=unknown threshold=${smartTripMinutes}m reason=no_confirmed_ignition_off"
        }

        if (smartTripMinutes == 0) {
            pendingTripBoundary = null
            persisted?.let { finalizePersistedTripHistory(it, disconnectedAt ?: connectAt, "ENDED") }
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            persistentCockpitTrip.update(tripComputer.snapshot(connectAt.elapsedMs), force = true, nowElapsedMs = connectAt.elapsedMs)
            tripComputer.reset(connectAt.elapsedMs)
            persistentCockpitTrip.rebase(tripComputer.snapshot(connectAt.elapsedMs), nowElapsedMs = connectAt.elapsedMs)
            clearTripRuntime()
            return "NEW_TRIP" to "gap=ignition threshold=0m reason=every_ignition"
        }

        val gapMs = timeSource.gapMillis(disconnectedAt, connectAt)
        if (gapMs == null && persisted != null) {
            // A head unit may establish Bluetooth before GPS/system time becomes
            // trustworthy. Continue provisionally and resolve the boundary once
            // a real clock anchor arrives; this prevents silent trip loss.
            tripComputer.restore(persisted, connectAt.elapsedMs)
            activeTripHistoryId = sqlStore.findTripRecordId(persisted.tripToken)
            saveActiveTripHistory(activeTripHistoryId)
            pendingTripBoundary = PendingTripBoundary(disconnectedAt, persisted)
            return "PENDING_TIME" to "gap=unknown threshold=${smartTripMinutes}m reason=waiting_for_trusted_time"
        }

        pendingTripBoundary = null
        val thresholdMs = smartTripMinutes * 60_000L
        val shouldStartNew = gapMs == null || gapMs >= thresholdMs
        return if (shouldStartNew) {
            persisted?.let { finalizePersistedTripHistory(it, disconnectedAt ?: connectAt, "ENDED") }
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            persistentCockpitTrip.update(tripComputer.snapshot(connectAt.elapsedMs), force = true, nowElapsedMs = connectAt.elapsedMs)
            tripComputer.reset(connectAt.elapsedMs)
            persistentCockpitTrip.rebase(tripComputer.snapshot(connectAt.elapsedMs), nowElapsedMs = connectAt.elapsedMs)
            clearTripRuntime()
            val reason = if (gapMs == null) "previous_time_untrusted" else "long_stop"
            val gapText = gapMs?.let(::formatDuration) ?: "unknown"
            "NEW_TRIP" to "gap=$gapText threshold=${smartTripMinutes}m reason=$reason"
        } else {
            val resolvedGapMs = requireNotNull(gapMs)
            if (persisted != null) {
                tripComputer.restore(persisted, connectAt.elapsedMs)
                activeTripHistoryId = sqlStore.findTripRecordId(persisted.tripToken)
                saveActiveTripHistory(activeTripHistoryId)
            }
            "CONTINUE" to "gap=${formatDuration(resolvedGapMs)} threshold=${smartTripMinutes}m reason=short_stop"
        }
    }

    private fun resolvePendingTripBoundary(now: TimeMark): Pair<String, String>? {
        val pending = pendingTripBoundary ?: return null
        if (!now.trusted) return null

        pendingTripBoundary = null
        val gapMs = timeSource.gapMillis(pending.disconnectedAt, now)
        val thresholdMs = smartTripMinutes * 60_000L
        val shouldStartNew = gapMs == null || gapMs >= thresholdMs
        return if (shouldStartNew) {
            finalizePersistedTripHistory(pending.restoredPrefix, pending.disconnectedAt ?: now, "ENDED")
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            persistentCockpitTrip.update(tripComputer.snapshot(now.elapsedMs), force = true, nowElapsedMs = now.elapsedMs)
            tripComputer.detachRestoredPrefix(pending.restoredPrefix, now.elapsedMs)
            persistentCockpitTrip.rebase(tripComputer.snapshot(now.elapsedMs), nowElapsedMs = now.elapsedMs)
            clearTripRuntime()
            val reason = if (gapMs == null) "previous_time_untrusted" else "long_stop_after_time_sync"
            val gapText = gapMs?.let(::formatDuration) ?: "unknown"
            "NEW_TRIP_RESOLVED" to "gap=$gapText threshold=${smartTripMinutes}m reason=$reason"
        } else {
            val resolvedGapMs = requireNotNull(gapMs)
            activeTripHistoryId = sqlStore.findTripRecordId(pending.restoredPrefix.tripToken)
            saveActiveTripHistory(activeTripHistoryId)
            "CONTINUE_RESOLVED" to "gap=${formatDuration(resolvedGapMs)} threshold=${smartTripMinutes}m reason=short_stop_after_time_sync"
        }
    }

    suspend fun finishTripNow(): Boolean = withContext(Dispatchers.IO) {
        tripMutex.withLock {
            val mark = timeSource.now()
            val trip = tripComputer.snapshot(mark.elapsedMs)
            persistentCockpitTrip.update(trip, force = true, nowElapsedMs = mark.elapsedMs)
            if (trip.distanceKm <= 0.0 && trip.fuelUsedL <= 0.0) return@withLock false
            manualTripEnding = true
            try {
                sqlStore.insertEvent(
                    currentSqlSessionId ?: lastSqlSessionId,
                    "TRIP_END_MANUAL",
                    "Sürüşü şimdi bitir",
                    "dist=${String.format(Locale.US, "%.3f", trip.distanceKm)} fuel=${String.format(Locale.US, "%.4f", trip.fuelUsedL)}"
                )
                sqlStore.finalizeTripRecord(
                    tripToken = trip.tripToken,
                    distanceKm = trip.distanceKm,
                    fuelUsedL = trip.fuelUsedL,
                    durationMs = trip.durationSec * 1000L,
                    averageL100 = trip.averageL100,
                    state = "ENDED_MANUAL",
                    endMark = mark
                )
                val endedSessionId = currentSqlSessionId ?: lastSqlSessionId
                endedSessionId?.let { sessionId ->
                    sqlStore.endSession(sessionId, "ENDED_MANUAL")
                    lastSqlSessionId = sessionId
                }

                currentSqlSessionId = null
                var continuationId: Long? = null
                if (state.connected && !state.selectedAddress.isNullOrBlank()) {
                    continuationId = sqlStore.startSession(
                        BuildConfig.VERSION_NAME,
                        state.selectedName,
                        state.selectedAddress,
                        null
                    )
                    currentSqlSessionId = continuationId
                    lastSqlSessionId = continuationId
                    sqlStore.insertEvent(
                        continuationId,
                        "POST_MANUAL_TRIP_SESSION",
                        "Yeni sürüş bekleniyor",
                        "previous_session=${endedSessionId ?: "--"}"
                    )
                }

                activeTripHistoryId = null
                saveActiveTripHistory(null)
                sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)

                tripComputer.reset(mark.elapsedMs)
                val newTrip = tripComputer.snapshot(mark.elapsedMs)
                persistentCockpitTrip.rebase(newTrip, nowElapsedMs = mark.elapsedMs)
                val cockpitTotals = persistentCockpitTrip.snapshot()
                clearTripRuntime()
                clearLastTripStopMark()
                pendingTripBoundary = null
                lastDisconnectMark = null

                withMain {
                    state = state.copy(
                        sqlSessionId = continuationId,
                        snapshot = state.snapshot.copy(
                            averageConsumption = cockpitTotals.averageL100,
                            tripDistanceKm = cockpitTotals.totalDistanceKm,
                            fuelUsedL = cockpitTotals.totalFuelLiters,
                            tripDurationText = cockpitTotals.durationText,
                            tripStateText = "Sürüş bekleniyor",
                            tripToken = newTrip.tripToken
                        )
                    )
                }
                refreshHistoryState()
                appendLog("[TRIP_END_MANUAL] Trip totals reset by user")
                true
            } finally {
                manualTripEnding = false
            }
        }
    }

    private fun persistTripRuntime(mark: TimeMark, force: Boolean = false) {
        if (!force && mark.elapsedMs - lastTripPersistElapsedMs < 3000L) return
        lastTripPersistElapsedMs = mark.elapsedMs
        val trip = tripComputer.exportState(mark.elapsedMs)
        val editor = tripPrefs.edit()
            .putBoolean(KEY_TRIP_HAS_STATE, true)
            .putBoolean(KEY_TRIP_STARTED, trip.tripStarted)
            .putLong(KEY_TRIP_DURATION_MS, trip.durationMs)
            .putLong(KEY_TRIP_DISTANCE_BITS, trip.totalDistanceKm.toBits())
            .putLong(KEY_TRIP_FUEL_BITS, trip.totalFuelL.toBits())
            .putLong(KEY_TRIP_PENDING_DISTANCE_BITS, trip.pendingDistanceKm.toBits())
            .putLong(KEY_TRIP_PENDING_FUEL_BITS, trip.pendingFuelL.toBits())
            .putLong(KEY_TRIP_AVG_BITS, trip.smoothedAverage?.toBits() ?: Long.MIN_VALUE)
            .putLong(KEY_TRIP_TOKEN, trip.tripToken)
            .putLong(KEY_TRIP_LAST_EPOCH, mark.epochMs ?: 0L)
            .putLong(KEY_TRIP_LAST_ELAPSED, mark.elapsedMs)
            .putString(KEY_TRIP_LAST_BOOT, mark.bootSessionId)
            .putBoolean(KEY_TRIP_LAST_TRUSTED, mark.trusted)
        if (force) editor.commit() else editor.apply()
    }

    private fun loadTripRuntime(): TripComputerPersistedState? {
        if (!tripPrefs.getBoolean(KEY_TRIP_HAS_STATE, false)) return null
        val avgBits = tripPrefs.getLong(KEY_TRIP_AVG_BITS, Long.MIN_VALUE)
        return TripComputerPersistedState(
            tripStarted = tripPrefs.getBoolean(KEY_TRIP_STARTED, false),
            durationMs = tripPrefs.getLong(KEY_TRIP_DURATION_MS, 0L),
            totalDistanceKm = Double.fromBits(tripPrefs.getLong(KEY_TRIP_DISTANCE_BITS, 0.0.toBits())),
            totalFuelL = Double.fromBits(tripPrefs.getLong(KEY_TRIP_FUEL_BITS, 0.0.toBits())),
            pendingDistanceKm = Double.fromBits(tripPrefs.getLong(KEY_TRIP_PENDING_DISTANCE_BITS, 0.0.toBits())),
            pendingFuelL = Double.fromBits(tripPrefs.getLong(KEY_TRIP_PENDING_FUEL_BITS, 0.0.toBits())),
            smoothedAverage = if (avgBits == Long.MIN_VALUE) null else Double.fromBits(avgBits),
            tripToken = tripPrefs.getLong(KEY_TRIP_TOKEN, 0L)
        )
    }

    private fun clearTripRuntime() {
        tripPrefs.edit()
            .remove(KEY_TRIP_HAS_STATE)
            .remove(KEY_TRIP_STARTED)
            .remove(KEY_TRIP_DURATION_MS)
            .remove(KEY_TRIP_DISTANCE_BITS)
            .remove(KEY_TRIP_FUEL_BITS)
            .remove(KEY_TRIP_PENDING_DISTANCE_BITS)
            .remove(KEY_TRIP_PENDING_FUEL_BITS)
            .remove(KEY_TRIP_AVG_BITS)
            .remove(KEY_TRIP_TOKEN)
            .remove(KEY_TRIP_LAST_EPOCH)
            .remove(KEY_TRIP_LAST_ELAPSED)
            .remove(KEY_TRIP_LAST_BOOT)
            .remove(KEY_TRIP_LAST_TRUSTED)
            .apply()
    }

    private fun saveLastTripStopMark(mark: TimeMark) {
        tripPrefs.edit()
            .putLong(KEY_STOP_EPOCH, mark.epochMs ?: 0L)
            .putLong(KEY_STOP_ELAPSED, mark.elapsedMs)
            .putString(KEY_STOP_BOOT, mark.bootSessionId)
            .putBoolean(KEY_STOP_TRUSTED, mark.trusted)
            .commit()
    }

    private fun loadLastTripStopMark(): TimeMark? {
        if (tripPrefs.contains(KEY_STOP_ELAPSED)) {
            val boot = tripPrefs.getString(KEY_STOP_BOOT, null) ?: return null
            val elapsed = tripPrefs.getLong(KEY_STOP_ELAPSED, -1L)
            if (elapsed < 0L) return null
            val epoch = tripPrefs.getLong(KEY_STOP_EPOCH, 0L).takeIf { it > 0L }
            val trusted = tripPrefs.getBoolean(KEY_STOP_TRUSTED, false) && epoch != null
            return TimeMark(epoch, elapsed, boot, trusted)
        }
        // Abrupt ignition/power cuts may bypass disconnect callbacks. The last
        // 3-second runtime checkpoint is the safest available stop estimate.
        return loadTripRuntimeMark()
    }

    private fun loadTripRuntimeMark(): TimeMark? {
        if (!tripPrefs.getBoolean(KEY_TRIP_HAS_STATE, false)) return null
        val elapsed = tripPrefs.getLong(KEY_TRIP_LAST_ELAPSED, -1L)
        val boot = tripPrefs.getString(KEY_TRIP_LAST_BOOT, null)
        if (elapsed < 0L || boot.isNullOrBlank()) return null
        val epoch = tripPrefs.getLong(KEY_TRIP_LAST_EPOCH, 0L).takeIf { it > 0L }
        val trusted = tripPrefs.getBoolean(KEY_TRIP_LAST_TRUSTED, false) && epoch != null
        return TimeMark(epoch, elapsed, boot, trusted)
    }

    private fun clearLastTripStopMark() {
        tripPrefs.edit()
            .remove(KEY_STOP_EPOCH)
            .remove(KEY_STOP_ELAPSED)
            .remove(KEY_STOP_BOOT)
            .remove(KEY_STOP_TRUSTED)
            .apply()
    }

    private fun finalizePersistedTripHistory(state: TripComputerPersistedState, mark: TimeMark, status: String) {
        val distance = state.totalDistanceKm.coerceAtLeast(0.0)
        val fuel = state.totalFuelL.coerceAtLeast(0.0)
        if (distance <= 0.00001 && fuel <= 0.0) return
        val average = if (distance >= 0.0001) (fuel / distance) * 100.0 else state.smoothedAverage
        sqlStore.finalizeTripRecord(
            tripToken = state.tripToken,
            distanceKm = distance,
            fuelUsedL = fuel,
            durationMs = state.durationMs,
            averageL100 = average,
            state = status,
            endMark = mark
        )
        scope.launch {
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
        }
    }

    private fun saveActiveTripHistory(id: Long?) {
        val editor = tripPrefs.edit()
        if (id == null) editor.remove(KEY_ACTIVE_HISTORY_ID) else editor.putLong(KEY_ACTIVE_HISTORY_ID, id)
        editor.apply()
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return if (hours > 0) "${hours}h${minutes}m${seconds}s" else "${minutes}m${seconds}s"
    }

    private fun hasValidKwpPayload(raw: String, marker: String, minPayloadBytes: Int): Boolean {
        val bytes = Regex("(?i)\\b[0-9a-f]{2}\\b")
            .findAll(raw)
            .map { it.value.toInt(16) }
            .toList()
        val markerBytes = marker.chunked(2).mapNotNull { it.toIntOrNull(16) }
        if (markerBytes.size != 2) return false
        val headerIndex = bytes.indices.firstOrNull { index ->
            index + 1 < bytes.size &&
                bytes[index] == markerBytes[0] &&
                bytes[index + 1] == markerBytes[1]
        } ?: return false
        return bytes.size - (headerIndex + 2) >= minPayloadBytes
    }

    private fun responseLooksComplete(cmd: String, response: String): Boolean {
        val upper = response.uppercase(Locale.US)
        if (listOf("NO DATA", "STOPPED", "UNABLE TO CONNECT", "CAN ERROR", "BUFFER FULL", "?").any { it in upper }) {
            return true
        }
        val compactHex = Regex("[^0-9A-F]").replace(upper, "")
        return when {
            cmd.matches(Regex("(?i)21[0-9A-F]{2}")) -> compactHex.contains("61" + cmd.substring(2).uppercase(Locale.US))
            cmd.matches(Regex("(?i)01[0-9A-F]{2}")) -> compactHex.contains("41" + cmd.substring(2).uppercase(Locale.US)) || compactHex.contains("7F01")
            cmd.startsWith("AT", ignoreCase = true) ->
                "OK" in upper || "ELM" in upper || ("BUS INIT" in upper && "OK" in upper)
            cmd.startsWith("10", ignoreCase = true) -> compactHex.contains("50") || compactHex.contains("7F10")
            else -> false
        }
    }

    private fun synchronizeBeforeCommand(input: InputStream, forceGraceWait: Boolean) {
        if (!forceGraceWait && input.available() <= 0) return
        val chunk = ByteArray(ELM_READ_CHUNK_BYTES)
        val start = System.currentTimeMillis()
        var lastDataMs = start
        var readTotal = 0
        var sawAny = false
        while (System.currentTimeMillis() - start < ELM_PRE_COMMAND_SYNC_MS) {
            val available = input.available()
            if (available > 0) {
                sawAny = true
                lastDataMs = System.currentTimeMillis()
                val read = input.read(chunk, 0, minOf(available, chunk.size))
                if (read <= 0) break
                readTotal += read
                if (readTotal > MAX_ELM_DRAIN_BYTES) {
                    closeSocket()
                    throw IOException("OBD giriş tamponu güvenlik sınırını aştı")
                }
                for (index in 0 until read) {
                    if ((chunk[index].toInt() and 0xFF).toChar() == '>') return
                }
            } else {
                if (!forceGraceWait && sawAny && System.currentTimeMillis() - lastDataMs > ELM_SYNC_QUIET_MS) return
                Thread.sleep(10)
            }
        }
    }

    private fun send(out: OutputStream, input: InputStream, cmd: String, waitMs: Long, timeoutMs: Long): String {
        // Do not blindly drain the stream. Wait briefly for any late prompt from
        // the previous request, then start this command on a clean boundary.
        synchronizeBeforeCommand(input, forceGraceWait = elmAwaitingLatePrompt)
        elmAwaitingLatePrompt = false
        if (cmd.isNotBlank()) {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        }
        Thread.sleep(waitMs)

        val buffer = StringBuilder(minOf(MAX_ELM_RESPONSE_CHARS, 1024))
        val chunk = ByteArray(ELM_READ_CHUNK_BYTES)
        val start = System.currentTimeMillis()
        var gotAny = false
        var lastData = start

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = input.available()
            if (available > 0) {
                gotAny = true
                lastData = System.currentTimeMillis()
                val read = input.read(chunk, 0, minOf(available, chunk.size))
                if (read < 0) break
                for (index in 0 until read) {
                    if (buffer.length >= MAX_ELM_RESPONSE_CHARS) {
                        closeSocket()
                        throw IOException("OBD yanıtı güvenlik sınırını aştı")
                    }
                    val ch = (chunk[index].toInt() and 0xFF).toChar()
                    buffer.append(ch)
                    if (ch == '>') {
                        elmAwaitingLatePrompt = false
                        return clean(buffer.toString())
                    }
                }
            } else {
                val current = buffer.toString()
                val quietFor = System.currentTimeMillis() - lastData
                val kwpInitInProgress = current.contains("BUS INIT", ignoreCase = true) &&
                    !current.contains("OK", ignoreCase = true) &&
                    !current.contains(">")
                if (gotAny && !kwpInitInProgress && quietFor > ELM_RESPONSE_QUIET_MS && responseLooksComplete(cmd, current)) {
                    // A complete payload without the trailing prompt is usable,
                    // but the next command must wait for and consume that late prompt.
                    elmAwaitingLatePrompt = true
                    return clean(current)
                }
                Thread.sleep(10)
            }
        }

        // Preserve diagnostic evidence on a timeout. The next command performs
        // a forced grace wait, consuming a late response/prompt before writing.
        elmAwaitingLatePrompt = true
        return clean(buffer.toString())
    }

    fun armManualCrankAnalysis() {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Marş analizi için önce OBD bağlantısı gerekli")
            appendLog("[CRANK_MANUAL_BLOCKED] OBD connection required")
            return
        }
        activeCrankTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", "Yeni manuel marş testi başlatıldı") }
        activeCrankTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
                testType = "CRANK",
                name = "Manuel Marş Analizi",
                versionName = BuildConfig.VERSION_NAME,
                note = "Kullanıcı manuel marş analizini kurdu"
            )
        } else null
        state = state.copy(manualCrankArmed = true, status = "Marş analizi hazır • şimdi marşa basın")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_ARMED", "Marş Analizi", "Kullanıcı manuel testi başlattı")
        appendLog("[CRANK_MANUAL_ARMED] Ready; start engine now")
        refreshHistory()
    }

    fun clearManualCrankTests() {
        crankPrefs.edit().remove(KEY_MANUAL_CRANKS).apply()
        state = state.copy(savedManualCrankTests = emptyList(), status = "Manuel marş testleri silindi")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_CLEAR", "Marş Analizi", "Manuel kayıtlar silindi")
        appendLog("[CRANK_MANUAL_CLEAR] Saved manual cranking tests cleared")
    }

    private fun processCrankingSample(
        snapshot: DashboardSnapshot,
        elapsedMs: Long,
        timestampMs: Long,
        timeTrusted: Boolean,
        rawCombined: String,
        sampleReliable: Boolean
    ) {
        val rpm = snapshot.rpm
        val voltage = snapshot.batteryV ?: snapshot.adapterVoltageV
        val rawGap = rawCombined.contains("NO DATA", ignoreCase = true) ||
            rawCombined.contains("STOPPED", ignoreCase = true) ||
            rawCombined.contains("BUS INIT", ignoreCase = true)

        if (!sampleReliable || rpm == null) {
            if (crankStartMs != null || crankRunningDetectedMs != null) crankObdGapDetected = true
            return
        }

        val previousRpm = lastRpmForCrank
        if (rpm <= 120) {
            if (engineOffSinceElapsedMs == null) engineOffSinceElapsedMs = elapsedMs
        } else if (crankStartMs == null && crankRunningDetectedMs == null && rpm < 600) {
            // Keep the established off evidence until a real crank/run transition is resolved.
        }

        if (crankStartMs != null) {
            if (voltage != null) crankMinVoltage = minOf(crankMinVoltage ?: voltage, voltage)
            if (rawGap) crankObdGapDetected = true
            crankPeakRpm = maxOf(crankPeakRpm ?: rpm, rpm)
            val startMs = crankStartMs ?: elapsedMs
            val durationMs = elapsedMs - startMs

            if (crankRunningDetectedMs == null) {
                when {
                    rpm >= 600 -> {
                        if (crankRunningCandidateMs == null) {
                            crankRunningCandidateMs = elapsedMs
                            crankInitialRunningRpm = rpm
                        }
                        if (elapsedMs - (crankRunningCandidateMs ?: elapsedMs) >= 350L) {
                            crankRunningDetectedMs = crankRunningCandidateMs
                            crankStableSamples = 0
                            crankStableRpmMin = null
                            crankStableRpmMax = null
                            crankStopCandidateMs = null
                        }
                    }
                    else -> {
                        crankRunningCandidateMs = null
                        if (rpm <= 120 && durationMs >= 700L) {
                            if (crankStopCandidateMs == null) crankStopCandidateMs = elapsedMs
                            if (elapsedMs - (crankStopCandidateMs ?: elapsedMs) >= 500L) {
                                finishCranking(elapsedMs, timestampMs, timeTrusted, rpm, completed = false, stableIdleRpm = null)
                                lastRpmForCrank = rpm
                                return
                            }
                        } else {
                            crankStopCandidateMs = null
                        }
                    }
                }
                if (durationMs > 10_000L) {
                    finishCranking(elapsedMs, timestampMs, timeTrusted, rpm, completed = false, stableIdleRpm = null)
                    lastRpmForCrank = rpm
                    return
                }
            } else {
                val runningAt = crankRunningDetectedMs ?: elapsedMs
                if (rpm in 600..1_200) {
                    crankStableSamples++
                    crankStableRpmMin = minOf(crankStableRpmMin ?: rpm, rpm)
                    crankStableRpmMax = maxOf(crankStableRpmMax ?: rpm, rpm)
                } else {
                    crankStableSamples = 0
                    crankStableRpmMin = null
                    crankStableRpmMax = null
                }
                val stableSpread = (crankStableRpmMax ?: rpm) - (crankStableRpmMin ?: rpm)
                if (crankStableSamples >= 3 && stableSpread <= 150) {
                    val stableRpm = ((crankStableRpmMin ?: rpm) + (crankStableRpmMax ?: rpm)) / 2
                    finishCranking(elapsedMs, timestampMs, timeTrusted, rpm, completed = true, stableIdleRpm = stableRpm)
                    lastRpmForCrank = rpm
                    return
                }
                if (elapsedMs - runningAt >= 8_000L) {
                    finishCranking(elapsedMs, timestampMs, timeTrusted, rpm, completed = true, stableIdleRpm = null)
                    lastRpmForCrank = rpm
                    return
                }
            }
            lastRpmForCrank = rpm
            return
        }

        val offEvidence = engineOffSinceElapsedMs != null && elapsedMs - (engineOffSinceElapsedMs ?: elapsedMs) >= 500L
        val wasStopped = previousRpm != null && previousRpm <= 120
        val startedTurning = (offEvidence || wasStopped) && rpm in 121..599
        if (startedTurning) {
            crankStartMs = elapsedMs
            crankStartTimestampMs = timestampMs
            crankStartTimeTrusted = timeTrusted
            crankStartVoltage = voltage
            crankMinVoltage = voltage
            crankTempC = snapshot.engineTempC
            crankInitialRpm = rpm
            crankPeakRpm = rpm
            crankRunningCandidateMs = null
            crankRunningDetectedMs = null
            crankInitialRunningRpm = null
            crankStableSamples = 0
            crankStableRpmMin = null
            crankStableRpmMax = null
            crankStopCandidateMs = null
            crankObdGapDetected = rawGap
            crankManual = state.manualCrankArmed
            crankAttemptCount = if (lastFailedCrankElapsedMs != null && elapsedMs - (lastFailedCrankElapsedMs ?: 0L) <= 60_000L) {
                (crankAttemptCount + 1).coerceAtMost(9)
            } else 1
            state = state.copy(crankingInProgress = true, status = if (crankManual) "Manuel marş testi algılandı" else "Marş algılandı • analiz ediliyor")
            if (crankManual) {
                sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_START", "Manuel marş", "rpm=$rpm voltage=${voltage ?: "--"}")
            }
            appendLog("[CRANK_START] manual=$crankManual attempt=$crankAttemptCount rpm=$rpm voltage=${voltage ?: "--"}")
        } else if ((offEvidence || wasStopped) && rpm >= 600) {
            // The polling loop saw the engine off and then already running, so the exact
            // crank duration was missed. Persist the event without inventing a duration.
            recordDirectObservedStart(snapshot, elapsedMs, timestampMs, timeTrusted, rpm, rawGap)
        }
        if (rpm > 120) engineOffSinceElapsedMs = null
        lastRpmForCrank = rpm
    }

    private fun recordDirectObservedStart(
        snapshot: DashboardSnapshot,
        elapsedMs: Long,
        timestampMs: Long,
        timeTrusted: Boolean,
        rpm: Int,
        obdGap: Boolean
    ) {
        val manual = state.manualCrankArmed
        val event = StartEvent(
            driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
            timestampMs = timestampMs,
            elapsedMs = elapsedMs,
            timeTrusted = timeTrusted,
            engineTempC = snapshot.engineTempC,
            thermalClass = StartAnalyzer.thermalClass(snapshot.engineTempC),
            crankDurationMs = null,
            stabilizationDurationMs = null,
            attemptCount = 1,
            successful = true,
            initialCrankRpm = null,
            initialRunningRpm = rpm,
            peakStartRpm = rpm,
            stableIdleRpm = null,
            confidence = if (obdGap) StartConfidence.LOW else StartConfidence.MEDIUM,
            obdGapDetected = obdGap,
            manualTrigger = manual,
            note = "Marşın başlangıcı OBD örnekleri arasında kaldı; süre uydurulmadı."
        )
        persistStartEvent(event)
        clearCrankAttemptRuntime()
        state = state.copy(manualCrankArmed = false, status = "Motor çalışması algılandı • marş başlangıcı örnekler arasında kaldı")
        engineOffSinceElapsedMs = null
    }

    private fun finishCranking(
        elapsedMs: Long,
        timestampMs: Long,
        timeTrusted: Boolean,
        rpmAtFinish: Int,
        completed: Boolean,
        stableIdleRpm: Int?
    ) {
        val startMs = crankStartMs ?: return
        val runningAt = crankRunningDetectedMs
        val crankDurationMs = if (completed && runningAt != null) (runningAt - startMs).coerceAtLeast(0L) else (elapsedMs - startMs).coerceAtLeast(0L)
        val stabilizationDurationMs = if (completed && runningAt != null && stableIdleRpm != null) (elapsedMs - runningAt).coerceAtLeast(0L) else null
        val manual = crankManual
        val confidence = when {
            crankObdGapDetected -> StartConfidence.LOW
            completed && runningAt != null -> StartConfidence.HIGH
            else -> StartConfidence.MEDIUM
        }
        val event = StartEvent(
            driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
            timestampMs = if (crankStartTimestampMs > 0L) crankStartTimestampMs else timestampMs,
            elapsedMs = startMs,
            timeTrusted = crankStartTimeTrusted || timeTrusted,
            engineTempC = crankTempC,
            thermalClass = StartAnalyzer.thermalClass(crankTempC),
            crankDurationMs = crankDurationMs,
            stabilizationDurationMs = stabilizationDurationMs,
            attemptCount = crankAttemptCount,
            successful = completed,
            initialCrankRpm = crankInitialRpm,
            initialRunningRpm = crankInitialRunningRpm,
            peakStartRpm = crankPeakRpm,
            stableIdleRpm = stableIdleRpm,
            confidence = confidence,
            obdGapDetected = crankObdGapDetected,
            manualTrigger = manual,
            note = when {
                !completed -> "Motor çalışmaya geçmeden marş denemesi sona erdi veya zaman aşımına uğradı."
                stableIdleRpm == null -> "Motor çalıştı; stabil rölanti penceresi tam ölçülemedi."
                else -> null
            }
        )
        persistStartEvent(event)
        if (!completed) {
            lastFailedCrankElapsedMs = elapsedMs
            persistCrankAttemptRuntime()
        } else {
            clearCrankAttemptRuntime()
        }

        // Keep the legacy/manual result path for existing Test History compatibility,
        // but remove component-diagnosis claims and do not use it as the long-term trend source.
        val result = buildCrankResult(
            timestampMs = event.timestampMs,
            manual = manual,
            durationSec = crankDurationMs / 1000.0,
            startVoltage = crankStartVoltage,
            minVoltage = crankMinVoltage,
            engineTempC = crankTempC,
            rpmAtFinish = rpmAtFinish,
            obdGapDetected = crankObdGapDetected,
            completed = completed
        )
        val manualTests = if (manual) {
            val updated = (listOf(result) + state.savedManualCrankTests).take(50)
            saveManualCrankTests(updated)
            updated
        } else state.savedManualCrankTests
        state = state.copy(
            manualCrankArmed = false,
            crankingInProgress = false,
            lastAutoCrankResult = if (manual) state.lastAutoCrankResult else result,
            savedManualCrankTests = manualTests,
            status = if (completed) {
                "Marş kaydedildi • ${String.format(Locale.US, "%.1f", crankDurationMs / 1000.0)} sn"
            } else {
                "Başarısız/tamamlanmamış marş denemesi kaydedildi"
            }
        )
        if (manual) {
            sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_RESULT", result.status, result.comment)
            sqlStore.endTestSession(
                activeCrankTestHistoryId,
                status = if (completed) "COMPLETED" else "INTERRUPTED",
                summary = "${result.status} • ${String.format(Locale.US, "%.2f", result.durationSec)} sn • ${result.comment}"
            )
            activeCrankTestHistoryId = null
            scope.launch {
                sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
                refreshHistoryState()
            }
        }
        appendLog("[START_EVENT] success=$completed manual=$manual attempt=${event.attemptCount} durationMs=${event.crankDurationMs ?: "--"} stabilizationMs=${event.stabilizationDurationMs ?: "--"} thermal=${event.thermalClass} confidence=${event.confidence} gap=${event.obdGapDetected}")
        resetCrankRuntime()
    }

    private fun trackFuelCalibrationProgress(snapshot: DashboardSnapshot, force: Boolean = false) {
        if (!runtimeSettings.fuelCalibrationSessionActive ||
            !appPrefs.isFuelCalibrationSessionActive() ||
            !runtimeSettings.fuelCalculationSupported ||
            runtimeSettings.demoMode || snapshot.demo
        ) {
            lastFuelCalibrationSnapshot = null
            return
        }
        val distance = snapshot.tripDistanceKm ?: return
        val rawFuel = snapshot.fuelUsedL ?: return
        if (snapshot.tripToken == 0L) return
        val sessionFactor = runtimeSettings.fuelCalibrationSessionFactor.coerceIn(0.50, 1.50)
        val calibratedDistance = distance.coerceAtLeast(0.0)
        val calibratedFuel = rawFuel.coerceAtLeast(0.0) * sessionFactor

        // Flush the last sub-batch tail before an automatic trip-token change or
        // an in-place total reset establishes a new baseline. Without this, up to
        // the batching threshold could be lost at each history boundary.
        lastFuelCalibrationSnapshot?.let { previous ->
            val previousDistance = previous.tripDistanceKm
            val previousFuel = previous.fuelUsedL
            val boundaryChanged = previous.tripToken != snapshot.tripToken ||
                (previousDistance != null && calibratedDistance + 0.0001 < previousDistance) ||
                (previousFuel != null && calibratedFuel + 0.000001 < previousFuel)
            if (boundaryChanged && previous.tripToken != 0L && previousDistance != null && previousFuel != null) {
                appPrefs.updateFuelCalibrationProgress(
                    tripToken = previous.tripToken,
                    distanceKm = previousDistance.coerceAtLeast(0.0),
                    fuelLiters = previousFuel.coerceAtLeast(0.0),
                    force = true
                )
            }
        }
        appPrefs.updateFuelCalibrationProgress(
            tripToken = snapshot.tripToken,
            distanceKm = calibratedDistance,
            fuelLiters = calibratedFuel,
            force = force
        )
        lastFuelCalibrationSnapshot = snapshot.copy(
            tripDistanceKm = calibratedDistance,
            fuelUsedL = calibratedFuel
        )
    }

    private fun flushFuelCalibrationProgress() {
        lastFuelCalibrationSnapshot?.let { trackFuelCalibrationProgress(it, force = true) }
    }

    private fun persistStartEvent(event: StartEvent) {
        runCatching { sqlStore.insertStartEvent(event) }
            .onFailure { appendLog("[START_EVENT_STORE_ERROR] ${it.message}") }
        scope.launch { refreshStartAnalysisState() }
    }

    private suspend fun refreshStartAnalysisState() {
        val events = runCatching { sqlStore.listStartEvents(100) }.getOrDefault(emptyList())
        val summary = StartAnalyzer.summarize(events)
        withMain { state = state.copy(startEvents = events, startAnalysisSummary = summary) }
    }

    private fun persistCrankAttemptRuntime() {
        val failedAt = lastFailedCrankElapsedMs ?: return
        crankPrefs.edit()
            .putString(KEY_CRANK_ATTEMPT_BOOT, timeSource.now().bootSessionId)
            .putLong(KEY_CRANK_LAST_FAILED_ELAPSED, failedAt)
            .putInt(KEY_CRANK_ATTEMPT_COUNT, crankAttemptCount.coerceIn(1, 9))
            .apply()
    }

    private fun clearCrankAttemptRuntime() {
        lastFailedCrankElapsedMs = null
        crankAttemptCount = 1
        crankPrefs.edit()
            .remove(KEY_CRANK_ATTEMPT_BOOT)
            .remove(KEY_CRANK_LAST_FAILED_ELAPSED)
            .remove(KEY_CRANK_ATTEMPT_COUNT)
            .apply()
    }

    private fun resetCrankRuntime() {
        crankStartMs = null
        crankStartTimestampMs = 0L
        crankStartTimeTrusted = false
        crankStartVoltage = null
        crankMinVoltage = null
        crankTempC = null
        crankInitialRpm = null
        crankPeakRpm = null
        crankRunningCandidateMs = null
        crankRunningDetectedMs = null
        crankInitialRunningRpm = null
        crankStableSamples = 0
        crankStableRpmMin = null
        crankStableRpmMax = null
        crankStopCandidateMs = null
        crankObdGapDetected = false
        crankManual = false
    }

    private fun buildCrankResult(
        timestampMs: Long,
        manual: Boolean,
        durationSec: Double,
        startVoltage: Double?,
        minVoltage: Double?,
        engineTempC: Int?,
        rpmAtFinish: Int?,
        obdGapDetected: Boolean,
        completed: Boolean
    ): CrankAnalysisResult {
        val status = when {
            !completed -> "Tamamlanamadı"
            obdGapDetected -> "Düşük güven"
            else -> "Kaydedildi"
        }
        val batteryStatus = if (minVoltage == null) "Ölçülemedi" else "Bilgi"
        val comment = buildString {
            append(
                when (status) {
                    "Kaydedildi" -> "Marş olayı kaydedildi. Değerlendirme tek bir sabit eşik yerine aracın kendi güvenilir geçmişiyle yapılır."
                    "Düşük güven" -> "Marş sırasında OBD veri boşluğu görüldü; bu kayıt trend karşılaştırmasına dahil edilmez."
                    else -> "Marş denemesi motorun çalışması doğrulanmadan sona erdi veya ölçüm tamamlanamadı."
                }
            )
            if (minVoltage != null) append(" Ölçülen minimum voltaj yalnız bilgi amaçlıdır; tek başına akü teşhisi değildir.")
        }
        return CrankAnalysisResult(timestampMs, manual, durationSec, startVoltage, minVoltage, engineTempC, rpmAtFinish, obdGapDetected, status, batteryStatus, comment)
    }

    private fun loadManualCrankTests(): List<CrankAnalysisResult> {
        val raw = crankPrefs.getString(KEY_MANUAL_CRANKS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lineSequence().mapNotNull { line ->
            val p = line.split("|")
            runCatching {
                if (p.size < 10) return@mapNotNull null
                CrankAnalysisResult(
                    timestampMs = p[0].toLong(),
                    manual = true,
                    durationSec = p[1].toDouble(),
                    startVoltage = p[2].toDoubleOrNull(),
                    minVoltage = p[3].toDoubleOrNull(),
                    engineTempC = p[4].toIntOrNull(),
                    rpmAtFinish = p[5].toIntOrNull(),
                    obdGapDetected = p[6].toBoolean(),
                    status = p[7],
                    batteryStatus = p[8],
                    comment = p.drop(9).joinToString("|")
                )
            }.getOrNull()
        }.toList()
    }

    private fun saveManualCrankTests(items: List<CrankAnalysisResult>) {
        val raw = items.joinToString("\n") { r ->
            listOf(
                r.timestampMs.toString(),
                String.format(Locale.US, "%.3f", r.durationSec),
                r.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.engineTempC?.toString() ?: "",
                r.rpmAtFinish?.toString() ?: "",
                r.obdGapDetected.toString(),
                r.status,
                r.batteryStatus,
                r.comment.replace("\n", " ").replace("|", "/")
            ).joinToString("|")
        }
        crankPrefs.edit().putString(KEY_MANUAL_CRANKS, raw).apply()
    }


    fun logMetricReset(
        action: TripMetricReset,
        distanceKm: Double,
        fuelLiters: Double,
        fuelPriceText: String
    ) {
        val eventType = when (action) {
            TripMetricReset.Average -> "AVG_RESET"
            TripMetricReset.Cost -> "COST_RESET"
            TripMetricReset.AverageAndCost -> "AVG_COST_RESET"
        }
        val name = when (action) {
            TripMetricReset.Average -> "Ortalama tüketimi sıfırla"
            TripMetricReset.Cost -> "Sürüş maliyetini sıfırla"
            TripMetricReset.AverageAndCost -> "Ortalama ve maliyeti sıfırla"
        }
        val note = "dist=${String.format(Locale.US, "%.3f", distanceKm)} fuel=${String.format(Locale.US, "%.4f", fuelLiters)} price=${fuelPriceText.ifBlank { "--" }}"
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, eventType, name, note)
        appendLog("[$eventType] $note")
    }


    private fun fuelDiscoveryElapsedSec(): Long =
        if (fuelDiscoveryStartedElapsedMs > 0L) {
            ((SystemClock.elapsedRealtime() - fuelDiscoveryStartedElapsedMs).coerceAtLeast(0L) / 1000L)
        } else 0L

    private fun estimateFuelDiscoveryRemainingSec(percent: Int, elapsedSec: Long): Long? {
        if (percent !in 2..98 || elapsedSec < 10L) return null
        val estimatedTotal = (elapsedSec * 100L / percent.coerceAtLeast(1)).coerceAtMost(60L * 60L)
        return (estimatedTotal - elapsedSec).coerceAtLeast(0L)
    }

    private fun persistFuelDiscoveryCheckpoint(
        phase: String,
        detail: String,
        percent: Int,
        currentTarget: String?
    ) {
        fuelDiscoveryPrefs.edit()
            .putBoolean(KEY_FUEL_DISCOVERY_ACTIVE, true)
            .putString(KEY_FUEL_DISCOVERY_FILE, fuelDiscoveryWorkingFile?.absolutePath)
            .putString(KEY_FUEL_DISCOVERY_PHASE, phase)
            .putString(KEY_FUEL_DISCOVERY_DETAIL, detail)
            .putInt(KEY_FUEL_DISCOVERY_PERCENT, percent.coerceIn(0, 100))
            .putString(KEY_FUEL_DISCOVERY_TARGET, currentTarget)
            .putLong(KEY_FUEL_DISCOVERY_STARTED_EPOCH, System.currentTimeMillis())
            .apply()
    }

    private fun clearFuelDiscoveryCheckpoint() {
        fuelDiscoveryPrefs.edit().clear().apply()
    }

    private suspend fun updateFuelDiscoveryProgress(
        percent: Int,
        phase: String,
        detail: String,
        currentTarget: String? = null
    ) {
        val safePercent = percent.coerceIn(0, 99)
        fuelDiscoveryProgressPercent = safePercent
        val elapsedSec = fuelDiscoveryElapsedSec()
        val remainingSec = estimateFuelDiscoveryRemainingSec(safePercent, elapsedSec)
        persistFuelDiscoveryCheckpoint(phase, detail, safePercent, currentTarget)
        withMain {
            state = state.copy(
                developerTestPhaseText = phase,
                developerTestProgressText = detail,
                developerTestProgressPercent = safePercent,
                developerTestElapsedSec = elapsedSec,
                developerTestEstimatedRemainingSec = remainingSec,
                developerTestCurrentTarget = currentTarget,
                status = "Depo hazırlık taraması • %$safePercent"
            )
        }
    }

    private fun startFuelDiscoveryUiTicker() {
        fuelDiscoveryUiTickerJob?.cancel()
        fuelDiscoveryUiTickerJob = scope.launch {
            while (isActive && state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME) {
                val elapsedSec = fuelDiscoveryElapsedSec()
                val remainingSec = estimateFuelDiscoveryRemainingSec(fuelDiscoveryProgressPercent, elapsedSec)
                withMain {
                    if (state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME) {
                        state = state.copy(
                            developerTestElapsedSec = elapsedSec,
                            developerTestEstimatedRemainingSec = remainingSec
                        )
                    }
                }
                delay(1000L)
            }
        }
    }

    private fun stopFuelDiscoveryUiTicker() {
        fuelDiscoveryUiTickerJob?.cancel()
        fuelDiscoveryUiTickerJob = null
    }

    private fun recoverInterruptedFuelDiscoveryIfNeeded() {
        if (!fuelDiscoveryPrefs.getBoolean(KEY_FUEL_DISCOVERY_ACTIVE, false)) return
        val previousPath = fuelDiscoveryPrefs.getString(KEY_FUEL_DISCOVERY_FILE, null)
        val previousPhase = fuelDiscoveryPrefs.getString(KEY_FUEL_DISCOVERY_PHASE, null) ?: "Bilinmeyen aşama"
        val previousPercent = fuelDiscoveryPrefs.getInt(KEY_FUEL_DISCOVERY_PERCENT, 0).coerceIn(0, 99)
        clearFuelDiscoveryCheckpoint()
        val source = previousPath?.let(::File)?.takeIf { it.exists() }
        if (source != null) {
            runCatching {
                source.appendText("${System.currentTimeMillis()} [PROCESS_INTERRUPTED] previousPhase=$previousPhase previousPercent=$previousPercent action=partial_package\n")
            }
        }
        scope.launch {
            val fileName = "loganos_fuel_preparation_partial_v${safeVersionTag()}_${trustedFileStamp()}.zip"
            val displayPath = if (source != null) {
                val archiveBytes = ByteArrayOutputStream().use { buffer ->
                    ZipOutputStream(buffer).use { zip ->
                        zip.putNextEntry(ZipEntry("00_partial_scan.txt"))
                        zip.write(source.readBytes())
                        zip.closeEntry()
                        zip.putNextEntry(ZipEntry("BENI_OKU.txt"))
                        zip.write(
                            "Bu tarama uygulama kapandığı veya Android işlemi sonlandırdığı için yarıda kaldı. Kararlı profil oluşturulmadı. Hazırlık taramasını baştan çalıştırın.\n".toByteArray(Charsets.UTF_8)
                        )
                        zip.closeEntry()
                    }
                    buffer.toByteArray()
                }
                saveBytesToDownloads(fileName, "application/zip", archiveBytes)
            } else {
                "Kısmi çalışma dosyası bulunamadı"
            }
            withMain {
                state = state.copy(
                    activeDeveloperTest = null,
                    developerTestPhaseText = null,
                    developerTestProgressText = null,
                    developerTestProgressPercent = null,
                    developerTestElapsedSec = null,
                    developerTestEstimatedRemainingSec = null,
                    developerTestCurrentTarget = null,
                    developerTestDoneMessage = "Yarım kalan depo hazırlık taraması bulundu",
                    savedLogPath = displayPath,
                    savedLogFileName = if (source != null) fileName else null,
                    sharedLogReady = source != null,
                    status = "Önceki depo taraması yarıda kaldı • yeniden başlatılması gerekiyor"
                )
            }
            ObdForegroundService.notifyFuelDiscoveryResult(
                context = context,
                completed = false,
                fileName = if (source != null) fileName else null
            )
        }
    }


    private fun startFuelDiscoveryTest() {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Depo seviyesi testi için önce OBD bağlantısı gerekli")
            appendLog("[FUEL_DISCOVERY_BLOCKED] OBD connection required")
            return
        }
        if ((state.snapshot.speedKmh ?: 0) > 1) {
            state = state.copy(status = "Hazırlık taramasını araç tamamen dururken başlat")
            appendLog("[FUEL_DISCOVERY_BLOCKED] vehicle must be stationary")
            return
        }
        val currentRpm = state.snapshot.rpm
        if (currentRpm != null && currentRpm > 50) {
            state = state.copy(status = "Hazırlık taraması için motoru kapat; kontağı açık bırak")
            appendLog("[FUEL_DISCOVERY_BLOCKED] KOEO required rpm=$currentRpm")
            return
        }

        developerTestJob?.cancel()
        developerTestJob = null
        activeDeveloperTestHistoryId?.let {
            sqlStore.endTestSession(it, "INTERRUPTED", "Depo seviyesi hazırlık taraması başlatıldığı için önceki test kapatıldı")
        }
        activeDeveloperTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
                testType = "FUEL_LEVEL_PREPARATION",
                name = FUEL_LEVEL_DISCOVERY_TEST_NAME,
                versionName = BuildConfig.VERSION_NAME,
                note = "Yakıt alımından önce, kontak açık motor kapalı salt-okunur KWP modül ve 21xx hazırlık taraması"
            )
        } else null

        val workDir = File(context.filesDir, "fuel_level_discovery").apply { mkdirs() }
        fuelDiscoveryWorkingFile = File(workDir, "fuel_preparation_${trustedFileStamp()}.txt").apply {
            writeText(
                buildString {
                    appendLine("LOGANOS FUEL LEVEL PREPARATION SCAN")
                    appendLine("version=${BuildConfig.VERSION_NAME}")
                    appendLine("started=${trustedFileStamp()}")
                    appendLine("vehicle=${runtimeSettings.vehicleModel}")
                    appendLine("engine=${runtimeSettings.engine}")
                    appendLine("adapter=${state.selectedName ?: "--"} / ${maskBluetoothAddress(state.selectedAddress)}")
                    appendLine("profile=${state.activeProfile}")
                    appendLine("purpose=Build a stable read-only KWP module/local-ID profile before the one-time refuelling comparison")
                    appendLine("safe_allowlist=10C0,1Axx,21xx plus ELM header/init commands")
                    appendLine("blocked_services=14,27,2E,31,34,36,3B and all actuator/write/security/programming commands")
                    appendLine("user_note=No refuelling is required in this preparation scan. Send the exported ZIP for analysis before the real refuelling test")
                    appendLine()
                }
            )
        }

        fuelDiscoveryModules.clear()
        fuelDiscoveryModules[0x7A] = FuelDiscoveryModule(0x7A, "Motor ECU")
        fuelDiscoveryStage = FuelDiscoveryStage.BEFORE_DISCOVERY
        fuelDiscoveryScanRequest = FuelDiscoveryScanRequest("PREPARATION", discoverModules = true)
        fuelDiscoveryScanInProgress = false
        fuelDiscoveryReconnectArmed = false
        fuelDiscoveryIgnitionOffConfirmed = false
        fuelDiscoveryDisconnectElapsedMs = null
        fuelDiscoveryStopRequested = false
        fuelDiscoveryStartDistanceKm = null
        fuelDiscoveryStartedElapsedMs = SystemClock.elapsedRealtime()
        fuelDiscoveryProgressPercent = 0
        persistFuelDiscoveryCheckpoint(
            phase = "Hazırlık taraması sıraya alındı",
            detail = "OBD tarama döngüsünün başlaması bekleniyor",
            percent = 0,
            currentTarget = "Motor ECU 0x7A"
        )
        startFuelDiscoveryUiTicker()
        ObdForegroundService.start(context)

        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "FUEL_DISCOVERY_START", FUEL_LEVEL_DISCOVERY_TEST_NAME, "KOEO salt-okunur hazırlık taraması sıraya alındı")
        state = state.copy(
            activeDeveloperTest = FUEL_LEVEL_DISCOVERY_TEST_NAME,
            developerTestPhaseText = "Kontak açık • motor kapalı hazırlık taraması",
            developerTestRemainingSec = null,
            developerTestProgressText = "OBD tarama döngüsü hazırlanıyor • uygulamayı kapatmayın",
            developerTestProgressPercent = 0,
            developerTestElapsedSec = 0L,
            developerTestEstimatedRemainingSec = null,
            developerTestCurrentTarget = "Motor ECU 0x7A",
            developerTestDoneMessage = null,
            status = "Depo seviyesi hazırlık taraması başlatıldı"
        )
        appendLog("[FUEL_DISCOVERY_START] preparation-scan queued")
        refreshHistory()
    }

    private suspend fun performFuelDiscoveryScan(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        address: String,
        sessionId: Long?,
        request: FuelDiscoveryScanRequest
    ) {
        if (fuelDiscoveryScanInProgress || state.activeDeveloperTest != FUEL_LEVEL_DISCOVERY_TEST_NAME) return
        ensureFuelDiscoveryScanActive(generation, address)
        fuelDiscoveryScanRequest = null
        fuelDiscoveryScanInProgress = true
        appendFuelDiscovery("\n===== ${request.phase} =====")
        appendFuelDiscoverySnapshot("${request.phase}_BEGIN")
        sqlStore.insertEvent(sessionId, "FUEL_DISCOVERY_PHASE", FUEL_LEVEL_DISCOVERY_TEST_NAME, request.phase)

        try {
            updateFuelDiscoveryProgress(
                percent = 1,
                phase = fuelDiscoveryPhaseTitle(request.phase),
                detail = "Motor ECU oturumu hazırlanıyor",
                currentTarget = "Motor ECU 0x7A"
            )

            if (request.discoverModules) {
                val engine = fuelDiscoveryModules.getOrPut(0x7A) { FuelDiscoveryModule(0x7A, "Motor ECU") }
                configureKwpTarget(out, input, engine.address, generation, address, "ENGINE_BASELINE")
                readKwpIdentification(out, input, engine, request.phase, generation, address)
                scanKwpLocalIdentifiers(
                    out = out,
                    input = input,
                    module = engine,
                    identifiers = 0x00..0xFF,
                    phase = "${request.phase}_FULL",
                    pass = 1,
                    generation = generation,
                    connectionAddress = address,
                    discover = true,
                    progressStartPercent = 2,
                    progressEndPercent = 20
                )
                discoverKwpModules(out, input, generation, address, request.phase)
                val discoveredModules = fuelDiscoveryModules.values.filter { it.address != 0x7A }
                discoveredModules.forEachIndexed { discoveredIndex, module ->
                    ensureFuelDiscoveryScanActive(generation, address)
                    val rangeStart = 70 + ((discoveredIndex * 16) / discoveredModules.size.coerceAtLeast(1))
                    val rangeEnd = 70 + (((discoveredIndex + 1) * 16) / discoveredModules.size.coerceAtLeast(1))
                    if (configureKwpTarget(out, input, module.address, generation, address, "DISCOVER_${module.address.toString(16)}")) {
                        readKwpIdentification(out, input, module, request.phase, generation, address)
                        scanKwpLocalIdentifiers(
                            out = out,
                            input = input,
                            module = module,
                            identifiers = 0x00..0xFF,
                            phase = "${request.phase}_FULL",
                            pass = 1,
                            generation = generation,
                            connectionAddress = address,
                            discover = true,
                            moduleProgress = "${discoveredIndex + 1}/${discoveredModules.size}",
                            progressStartPercent = rangeStart,
                            progressEndPercent = rangeEnd
                        )
                    }
                }
            }

            val validationModules = fuelDiscoveryModules.values.toList()
            val totalValidationChunks = (validationModules.size * FUEL_DISCOVERY_REPEAT_PASSES).coerceAtLeast(1)
            validationModules.forEachIndexed { moduleIndex, module ->
                ensureFuelDiscoveryScanActive(generation, address)
                val configured = configureKwpTarget(
                    out,
                    input,
                    module.address,
                    generation,
                    address,
                    "${request.phase}_REPEAT"
                )
                if (!configured) {
                    appendFuelDiscovery("[MODULE_UNAVAILABLE] phase=${request.phase} address=0x${module.address.hex2()} label=${module.label} action=exclude_candidates")
                    if (request.discoverModules) module.supportedLocalIds.clear()
                    return@forEachIndexed
                }
                readKwpIdentification(out, input, module, request.phase, generation, address)
                val ids = module.supportedLocalIds.toList().sorted()
                if (ids.isEmpty()) {
                    appendFuelDiscovery("[NO_SUPPORTED_21XX] phase=${request.phase} address=0x${module.address.hex2()} label=${module.label}")
                } else {
                    repeat(FUEL_DISCOVERY_REPEAT_PASSES) { passIndex ->
                        val chunkIndex = moduleIndex * FUEL_DISCOVERY_REPEAT_PASSES + passIndex
                        val rangeStart = 86 + ((chunkIndex * 12) / totalValidationChunks)
                        val rangeEnd = 86 + (((chunkIndex + 1) * 12) / totalValidationChunks)
                        scanKwpLocalIdentifiers(
                            out = out,
                            input = input,
                            module = module,
                            identifiers = ids,
                            phase = request.phase,
                            pass = passIndex + 2,
                            generation = generation,
                            connectionAddress = address,
                            discover = false,
                            moduleProgress = "${moduleIndex + 1}/${validationModules.size}",
                            progressStartPercent = rangeStart,
                            progressEndPercent = rangeEnd
                        )
                    }
                    if (request.discoverModules) {
                        finalizeStableFuelDiscoveryIds(module, request.phase)
                    }
                }
            }

            updateFuelDiscoveryProgress(
                percent = 99,
                phase = "Tarama tamamlanıyor",
                detail = "Kararlı kimlik profili ve ZIP paketi hazırlanıyor",
                currentTarget = "Motor ECU 0x7A geri yükleniyor"
            )
            // Always return the ELM/KWP session to the proven Delphi engine target
            // before the regular 21A0/A2/CC/CD polling loop resumes.
            configureKwpTarget(out, input, 0x7A, generation, address, "RESTORE_ENGINE")
            parser.resetRuntimeState()
            appendFuelDiscoverySnapshot("${request.phase}_END")
            appendFuelDiscoveryModuleSummary(request.phase)
            fuelDiscoveryReconnectArmed = false

            when (request.phase) {
                "PREPARATION" -> {
                    fuelDiscoveryStage = FuelDiscoveryStage.COMPLETED
                    completeFuelDiscoveryTest(
                        "COMPLETED",
                        "Kontak açık motor kapalı hazırlık taraması tamamlandı; yalnız kararlı modül ve 21xx adayları dışa aktarıldı"
                    )
                }
                "AFTER_START" -> {
                    fuelDiscoveryStage = FuelDiscoveryStage.WAITING_FOR_500M
                    fuelDiscoveryStartDistanceKm = null
                    withMain {
                        state = state.copy(
                            developerTestPhaseText = "Yakıt sonrası ilk tarama tamamlandı",
                            developerTestRemainingSec = null,
                            developerTestProgressText = "Normal sürüşe devam et • 500 m sonra ikinci tarama otomatik",
                            status = "Depo testi • 500 m ölçümü bekleniyor"
                        )
                    }
                }
                "AFTER_500M" -> {
                    fuelDiscoveryStage = FuelDiscoveryStage.WAITING_FOR_2KM
                    withMain {
                        state = state.copy(
                            developerTestPhaseText = "500 metre taraması tamamlandı",
                            developerTestRemainingSec = null,
                            developerTestProgressText = "Normal sürüşe devam et • 2 km'de son tarama otomatik",
                            status = "Depo testi • 2 km ölçümü bekleniyor"
                        )
                    }
                }
                "AFTER_2KM" -> {
                    fuelDiscoveryStage = FuelDiscoveryStage.COMPLETED
                    completeFuelDiscoveryTest("COMPLETED", "Yakıt öncesi ve üç yakıt sonrası aşama tamamlandı")
                }
            }
        } catch (_: FuelDiscoveryStopSignal) {
            appendFuelDiscovery("[SCAN_STOPPED] phase=${request.phase} reason=manual_finish")
        } catch (error: Throwable) {
            appendFuelDiscovery("[SCAN_ERROR] phase=${request.phase} type=${error::class.java.simpleName} message=${error.message ?: "--"}")
            if (state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME &&
                fuelDiscoveryStage !in setOf(FuelDiscoveryStage.IDLE, FuelDiscoveryStage.COMPLETED)
            ) {
                fuelDiscoveryScanRequest = request
                fuelDiscoveryReconnectArmed = true
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "Tarama bağlantı nedeniyle durakladı",
                        developerTestRemainingSec = null,
                        developerTestProgressText = "OBD yeniden bağlanınca aynı aşama otomatik tekrar denenecek"
                    )
                }
            }
            throw error
        } finally {
            restoreEngineKwpTargetBestEffort(out, input, generation, address, "RESTORE_ENGINE_FINALLY")
            parser.resetRuntimeState()
            fuelDiscoveryScanInProgress = false
        }
    }

    private suspend fun discoverKwpModules(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        connectionAddress: String,
        phase: String
    ) {
        // Bounded physical-address discovery for older Renault/Dacia K-line.
        // 0x00-0x0F are deliberately skipped to avoid functional/broadcast-like
        // addressing. Only session control and read services are permitted.
        val candidates = (0x10..0x7F).filterNot { it == 0x7A }

        candidates.forEachIndexed { index, target ->
            ensureFuelDiscoveryScanActive(generation, connectionAddress)
            if (index % 2 == 0 || index == candidates.lastIndex) {
                val percent = 20 + (((index + 1) * 50) / candidates.size.coerceAtLeast(1))
                updateFuelDiscoveryProgress(
                    percent = percent,
                    phase = "KWP modülleri araştırılıyor",
                    detail = "Adres ${index + 1}/${candidates.size} • hedef 0x${target.hex2()}",
                    currentTarget = "KWP adresi 0x${target.hex2()}"
                )
            }
            val configured = configureKwpTarget(out, input, target, generation, connectionAddress, "MODULE_DISCOVERY")
            if (!configured) return@forEachIndexed

            val probeResponses = listOf("1A80", "1A87", "1A90", "2180").map { command ->
                command to send(out, input, command, 20L, 650L)
            }
            probeResponses.forEach { (command, response) ->
                appendFuelDiscovery("[MODULE_PROBE] phase=$phase target=0x${target.hex2()} cmd=$command response=$response")
            }
            val identified = probeResponses.any { (command, response) ->
                when {
                    command.startsWith("1A") -> positiveKwpResponse(response, target, 0x5A, command.substring(2).toInt(16))
                    command.startsWith("21") -> positiveKwpResponse(response, target, 0x61, command.substring(2).toInt(16))
                    else -> false
                }
            }
            if (identified) {
                val module = fuelDiscoveryModules.getOrPut(target) {
                    FuelDiscoveryModule(target, fuelDiscoveryModuleLabel(target))
                }
                appendFuelDiscovery("[MODULE_FOUND] phase=$phase address=0x${target.hex2()} label=${module.label}")
            }
        }
    }

    private fun configureKwpTarget(
        out: OutputStream,
        input: InputStream,
        target: Int,
        generation: Long,
        connectionAddress: String,
        reason: String
    ): Boolean {
        ensureFuelDiscoveryScanActive(generation, connectionAddress)
        val hex = target.hex2()
        val commands = listOf(
            "ATIIA$hex" to Pair(40L, 500L),
            "ATWM81${hex}F1" to Pair(40L, 500L),
            "ATSH81${hex}F1" to Pair(40L, 500L),
            "ATFI" to Pair(220L, 1800L),
            "10C0" to Pair(40L, 750L)
        )
        var initResponse = ""
        var sessionResponse = ""
        commands.forEach { (command, timing) ->
            ensureFuelDiscoveryScanActive(generation, connectionAddress)
            val response = send(out, input, command, timing.first, timing.second)
            appendFuelDiscovery("[TARGET_CONFIG] reason=$reason target=0x$hex cmd=$command response=$response")
            if (command == "ATFI") initResponse = response
            if (command == "10C0") sessionResponse = response
        }
        val initOk = initResponse.contains("BUS INIT", ignoreCase = true) && initResponse.contains("OK", ignoreCase = true)
        val sessionOk = positiveKwpResponse(sessionResponse, target, 0x50, 0xC0)
        return initOk || sessionOk
    }

    private fun readKwpIdentification(
        out: OutputStream,
        input: InputStream,
        module: FuelDiscoveryModule,
        phase: String,
        generation: Long,
        connectionAddress: String
    ) {
        val commands = listOf("1A80", "1A81", "1A87", "1A90", "1A91", "1A92")
        commands.forEach { command ->
            ensureFuelDiscoveryScanActive(generation, connectionAddress)
            val response = send(out, input, command, 20L, 700L)
            appendFuelDiscovery(
                "[IDENT] phase=$phase module=0x${module.address.hex2()} label=${module.label} cmd=$command response=$response"
            )
        }
    }

    private suspend fun scanKwpLocalIdentifiers(
        out: OutputStream,
        input: InputStream,
        module: FuelDiscoveryModule,
        identifiers: Iterable<Int>,
        phase: String,
        pass: Int,
        generation: Long,
        connectionAddress: String,
        discover: Boolean,
        moduleProgress: String? = null,
        progressStartPercent: Int? = null,
        progressEndPercent: Int? = null
    ) {
        val ids = identifiers.toList().distinct().sorted()
        ids.forEachIndexed { index, identifier ->
            ensureFuelDiscoveryScanActive(generation, connectionAddress)
            val command = "21${identifier.hex2()}"
            val response = send(out, input, command, 15L, 700L)
            val positive = positiveKwpResponse(response, module.address, 0x61, identifier)
            module.localIdAttempts[identifier] = (module.localIdAttempts[identifier] ?: 0) + 1
            if (positive) {
                module.localIdHits[identifier] = (module.localIdHits[identifier] ?: 0) + 1
                module.supportedLocalIds += identifier
            }
            val marker = "61${identifier.hex2()}"
            val suspicious = !positive && responseContainsHexMarker(response, marker)
            if (suspicious) {
                appendFuelDiscovery("[SUSPICIOUS_RESPONSE] phase=$phase module=0x${module.address.hex2()} id=0x${identifier.hex2()} marker=$marker response=$response")
            }
            appendFuelDiscovery(
                "[LOCAL_ID] phase=$phase pass=$pass module=0x${module.address.hex2()} label=${module.label} id=0x${identifier.hex2()} positive=$positive suspicious=$suspicious hits=${module.localIdHits[identifier] ?: 0} attempts=${module.localIdAttempts[identifier] ?: 0} response=$response"
            )
            if (index % 8 == 0 || index == ids.lastIndex) {
                val rangeStart = progressStartPercent
                val rangeEnd = progressEndPercent
                val percent = if (rangeStart != null && rangeEnd != null && ids.isNotEmpty()) {
                    val fraction = (index + 1).toDouble() / ids.size.toDouble()
                    (rangeStart + ((rangeEnd - rangeStart) * fraction)).toInt().coerceIn(0, 99)
                } else {
                    fuelDiscoveryProgressPercent
                }
                updateFuelDiscoveryProgress(
                    percent = percent,
                    phase = fuelDiscoveryPhaseTitle(phase.removeSuffix("_FULL")),
                    detail = buildString {
                        moduleProgress?.let { append("Modül $it • ") }
                        append("${module.label} • 21${identifier.hex2()} • ${index + 1}/${ids.size}")
                        if (discover) append(" • bulunan aday: ${module.supportedLocalIds.size}")
                        else append(" • doğrulama $pass/$FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES")
                    },
                    currentTarget = "0x${module.address.hex2()} • 21${identifier.hex2()}"
                )
            }
        }
    }

    private fun stableFuelDiscoveryIds(module: FuelDiscoveryModule): Set<Int> =
        module.supportedLocalIds.filter { identifier ->
            val hits = module.localIdHits[identifier] ?: 0
            val attempts = module.localIdAttempts[identifier] ?: 0
            attempts >= FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES && hits >= FUEL_DISCOVERY_MIN_STABLE_HITS
        }.toSet()

    private fun finalizeStableFuelDiscoveryIds(module: FuelDiscoveryModule, phase: String) {
        val candidates = module.supportedLocalIds.toList().sorted()
        val stable = stableFuelDiscoveryIds(module)
        candidates.filterNot { it in stable }.forEach { identifier ->
            appendFuelDiscovery(
                "[UNSTABLE_ID] phase=$phase module=0x${module.address.hex2()} id=0x${identifier.hex2()} hits=${module.localIdHits[identifier] ?: 0} attempts=${module.localIdAttempts[identifier] ?: 0} action=excluded"
            )
        }
        module.supportedLocalIds.retainAll(stable)
        appendFuelDiscovery(
            "[STABLE_ID_SET] phase=$phase module=0x${module.address.hex2()} stableCount=${stable.size} stable=${stable.sorted().joinToString { it.hex2() }} threshold=$FUEL_DISCOVERY_MIN_STABLE_HITS/$FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES"
        )
    }

    private fun restoreEngineKwpTargetBestEffort(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        connectionAddress: String,
        reason: String
    ): Boolean {
        if (!isConnectionCurrent(generation, connectionAddress)) {
            appendFuelDiscovery("[ENGINE_RESTORE_SKIPPED] reason=$reason connection_changed=true")
            return false
        }
        val commands = listOf(
            "ATIIA7A" to Pair(40L, 500L),
            "ATWM817AF1" to Pair(40L, 500L),
            "ATSH817AF1" to Pair(40L, 500L),
            "ATFI" to Pair(220L, 1800L),
            "10C0" to Pair(40L, 750L)
        )
        var restored = false
        commands.forEach { (command, timing) ->
            val response = runCatching { send(out, input, command, timing.first, timing.second) }
                .getOrElse { error ->
                    appendFuelDiscovery("[ENGINE_RESTORE_ERROR] reason=$reason cmd=$command type=${error::class.java.simpleName} message=${error.message ?: "--"}")
                    return@forEach
                }
            appendFuelDiscovery("[ENGINE_RESTORE] reason=$reason cmd=$command response=$response")
            if (command == "ATFI" && response.contains("BUS INIT", ignoreCase = true) && response.contains("OK", ignoreCase = true)) restored = true
            if (command == "10C0" && positiveKwpResponse(response, 0x7A, 0x50, 0xC0)) restored = true
        }
        return restored
    }

    private fun buildFuelDiscoveryProfileJson(status: String, note: String): JSONObject {
        val modules = JSONArray()
        fuelDiscoveryModules.values.forEach { module ->
            val ids = JSONArray()
            stableFuelDiscoveryIds(module).sorted().forEach { identifier ->
                ids.put(
                    JSONObject()
                        .put("id_hex", identifier.hex2())
                        .put("hits", module.localIdHits[identifier] ?: 0)
                        .put("attempts", module.localIdAttempts[identifier] ?: 0)
                        .put("stable", true)
                )
            }
            modules.put(
                JSONObject()
                    .put("address_hex", module.address.hex2())
                    .put("label", module.label)
                    .put("address_verified_role", module.address == 0x7A)
                    .put("stable_local_ids", ids)
            )
        }
        return JSONObject()
            .put("schema", "loganos_fuel_preparation_profile_v1")
            .put("version", BuildConfig.VERSION_NAME)
            .put("status", status)
            .put("note", note)
            .put("vehicle", runtimeSettings.vehicleModel)
            .put("engine", runtimeSettings.engine)
            .put("adapter", state.selectedName ?: "--")
            .put("stable_threshold", "$FUEL_DISCOVERY_MIN_STABLE_HITS/$FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES")
            .put("safety", JSONObject()
                .put("read_only_services", JSONArray(listOf("10C0", "1Axx", "21xx")))
                .put("blocked_services", JSONArray(listOf("14", "27", "2E", "31", "34", "36", "3B")))
                .put("module_roles_unverified_except_engine_0x7A", true)
            )
            .put("modules", modules)
    }

    private suspend fun advanceFuelDiscoveryAfterDrive(distanceKm: Double?) {
        val targetKm = when (fuelDiscoveryStage) {
            FuelDiscoveryStage.WAITING_FOR_500M -> 0.5
            FuelDiscoveryStage.WAITING_FOR_2KM -> 2.0
            else -> return
        }
        val distance = distanceKm ?: run {
            withMain { state = state.copy(developerTestProgressText = "Mesafe verisi bekleniyor…") }
            return
        }
        val start = fuelDiscoveryStartDistanceKm
        if (start == null) {
            fuelDiscoveryStartDistanceKm = distance
            appendFuelDiscovery("[DRIVE_BASELINE] tripDistanceKm=${String.format(Locale.US, "%.6f", distance)}")
            return
        }
        val delta = (distance - start).coerceAtLeast(0.0)
        withMain {
            state = state.copy(
                developerTestProgressText = "${String.format(Locale.US, "%.2f", delta)} / ${String.format(Locale.US, "%.2f", targetKm)} km"
            )
        }
        if (delta + 0.0001 >= targetKm && fuelDiscoveryScanRequest == null && !fuelDiscoveryScanInProgress) {
            if (fuelDiscoveryStage == FuelDiscoveryStage.WAITING_FOR_500M) {
                fuelDiscoveryStage = FuelDiscoveryStage.AFTER_500M_SCAN
                fuelDiscoveryScanRequest = FuelDiscoveryScanRequest("AFTER_500M", discoverModules = false)
            } else if (fuelDiscoveryStage == FuelDiscoveryStage.WAITING_FOR_2KM) {
                fuelDiscoveryStage = FuelDiscoveryStage.AFTER_2KM_SCAN
                fuelDiscoveryScanRequest = FuelDiscoveryScanRequest("AFTER_2KM", discoverModules = false)
            }
            appendFuelDiscovery("[DRIVE_THRESHOLD] deltaKm=${String.format(Locale.US, "%.6f", delta)} targetKm=$targetKm")
        }
    }

    private suspend fun completeFuelDiscoveryTest(status: String, note: String) {
        appendFuelDiscovery("[TEST_COMPLETE] status=$status note=$note")
        appendFuelDiscoveryModuleSummary("FINAL")
        appendFuelDiscovery("[NEXT_STEP] Send this preparation package for analysis. Do not refuel until the short comparison test is generated from the stable profile")
        val source = fuelDiscoveryWorkingFile
        val fileName = "loganos_fuel_preparation_v${safeVersionTag()}_${trustedFileStamp()}.zip"
        val displayPath = if (source != null && source.exists()) {
            val profileJson = buildFuelDiscoveryProfileJson(status, note).toString(2)
            val profileFile = File(source.parentFile, "latest_fuel_preparation_profile.json")
            runCatching { profileFile.writeText(profileJson) }
            val archiveBytes = ByteArrayOutputStream().use { buffer ->
                ZipOutputStream(buffer).use { zip ->
                    zip.putNextEntry(ZipEntry("00_preparation_scan.txt"))
                    zip.write(source.readBytes())
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("01_stable_profile.json"))
                    zip.write(profileJson.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("BENI_OKU.txt"))
                    zip.write(
                        "Bu paket yakıt alma testi değildir. Hazırlık taraması sonucudur. Yakıt almadan önce paketi analiz için gönderin; gerçek yakıt testi yalnız bu profilde doğrulanan modül ve 21xx kimliklerini okuyacaktır.\n".toByteArray(Charsets.UTF_8)
                    )
                    zip.closeEntry()
                }
                buffer.toByteArray()
            }
            saveBytesToDownloads(fileName, "application/zip", archiveBytes)
        } else {
            "Hazırlık çalışma dosyası bulunamadı"
        }
        sqlStore.endTestSession(activeDeveloperTestHistoryId, status, note)
        activeDeveloperTestHistoryId = null
        sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
        refreshHistoryState()

        fuelDiscoveryStage = FuelDiscoveryStage.IDLE
        fuelDiscoveryScanRequest = null
        fuelDiscoveryScanInProgress = false
        stopFuelDiscoveryUiTicker()
        clearFuelDiscoveryCheckpoint()
        fuelDiscoveryReconnectArmed = false
        fuelDiscoveryIgnitionOffConfirmed = false
        fuelDiscoveryDisconnectElapsedMs = null
        fuelDiscoveryStopRequested = false
        fuelDiscoveryStartDistanceKm = null
        withMain {
            state = state.copy(
                activeDeveloperTest = null,
                developerTestPhaseText = "Tarama tamamlandı",
                developerTestRemainingSec = null,
                developerTestProgressText = "Kararlı profil ve hazırlık ZIP'i oluşturuldu",
                developerTestProgressPercent = 100,
                developerTestElapsedSec = fuelDiscoveryElapsedSec(),
                developerTestEstimatedRemainingSec = 0L,
                developerTestCurrentTarget = null,
                developerTestStepLabel = null,
                developerTestStepIndex = null,
                developerTestStepTotal = null,
                developerTestStageLabel = null,
                developerTestDoneMessage = if (status == "COMPLETED") {
                    "Depo seviyesi hazırlık taraması tamamlandı"
                } else {
                    "Kısmi depo hazırlık paketi oluşturuldu"
                },
                savedLogPath = displayPath,
                savedLogFileName = fileName,
                sharedLogReady = true,
                status = "Depo seviyesi hazırlık paketi oluşturuldu: $displayPath"
            )
            appendLog("[FUEL_DISCOVERY_COMPLETE] path=$displayPath")
        }
        ObdForegroundService.notifyFuelDiscoveryResult(
            context = context,
            completed = status == "COMPLETED",
            fileName = fileName
        )
        if (!shouldRunForegroundService(runtimeSettings)) {
            ObdForegroundService.stop(context)
        }
    }

    private fun finishFuelDiscoveryTestManually() {
        if (fuelDiscoveryStage == FuelDiscoveryStage.IDLE || fuelDiscoveryStopRequested) return
        fuelDiscoveryStopRequested = true
        fuelDiscoveryStage = FuelDiscoveryStage.COMPLETED
        fuelDiscoveryScanRequest = null
        fuelDiscoveryReconnectArmed = false
        state = state.copy(
            developerTestPhaseText = "Kısmi hazırlık paketi hazırlanıyor",
            developerTestRemainingSec = null,
            developerTestProgressText = "Mevcut bütün ölçümler korunacak"
        )
        scope.launch {
            var waitedMs = 0L
            while (fuelDiscoveryScanInProgress && waitedMs < FUEL_DISCOVERY_STOP_WAIT_MS) {
                delay(50L)
                waitedMs += 50L
            }
            completeFuelDiscoveryTest("COMPLETED_MANUAL", "Kullanıcı hazırlık taramasını manuel bitirdi; kısmi veri dışa aktarıldı")
        }
    }

    private fun appendFuelDiscoverySnapshot(label: String) {
        val snapshot = state.snapshot
        appendFuelDiscovery(
            "[SNAPSHOT] label=$label connected=${snapshot.connected} rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} tripDistanceKm=${snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.6f", it) } ?: "--"} fuelUsedL=${snapshot.fuelUsedL?.let { String.format(Locale.US, "%.6f", it) } ?: "--"}"
        )
    }

    private fun appendFuelDiscoveryModuleSummary(phase: String) {
        fuelDiscoveryModules.values.forEach { module ->
            appendFuelDiscovery(
                "[MODULE_SUMMARY] phase=$phase address=0x${module.address.hex2()} label=${module.label} stable21xx=${stableFuelDiscoveryIds(module).sorted().joinToString { it.hex2() }} hitStats=${stableFuelDiscoveryIds(module).sorted().joinToString { id -> "${id.hex2()}:${module.localIdHits[id] ?: 0}/${module.localIdAttempts[id] ?: 0}" }}"
            )
        }
    }

    private fun appendFuelDiscovery(line: String) {
        val file = fuelDiscoveryWorkingFile ?: return
        val mark = timeSource.now()
        val timestamp = mark.epochMs?.takeIf { mark.trusted }?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(it))
        } ?: "TIME_PENDING+${mark.elapsedMs}ms"
        runCatching {
            synchronized(this) {
                file.appendText("$timestamp $line\n")
            }
        }
    }

    private fun ensureFuelDiscoveryScanActive(generation: Long, connectionAddress: String) {
        if (fuelDiscoveryStopRequested || fuelDiscoveryStage == FuelDiscoveryStage.COMPLETED) {
            throw FuelDiscoveryStopSignal()
        }
        if (state.activeDeveloperTest != FUEL_LEVEL_DISCOVERY_TEST_NAME) {
            throw FuelDiscoveryStopSignal()
        }
        if (!isConnectionCurrent(generation, connectionAddress)) {
            throw IOException("Fuel discovery connection changed")
        }
    }

    private fun fuelDiscoveryPhaseTitle(phase: String): String = when (phase) {
        "PREPARATION" -> "Kontak açık • motor kapalı kapsamlı hazırlık taraması"
        "AFTER_START" -> "Yakıt sonrası ilk tarama"
        "AFTER_500M" -> "500 metre sonrası tarama"
        "AFTER_2KM" -> "2 kilometre sonrası son tarama"
        else -> "Depo seviyesi hazırlık taraması"
    }

    private fun fuelDiscoveryModuleLabel(address: Int): String = when (address) {
        0x7A -> "Motor ECU"
        else -> "Doğrulanmamış KWP modül adayı 0x${address.hex2()}"
    }

    private fun positiveKwpResponse(
        response: String,
        expectedSource: Int,
        positiveService: Int,
        identifier: Int? = null
    ): Boolean {
        val upper = response.uppercase(Locale.US)
        if (listOf("NO DATA", "STOPPED", "UNABLE TO CONNECT", "BUS ERROR", "CAN ERROR", "?").any { it in upper }) return false
        return extractKwpFrames(response).any { frame ->
            val payloadIndex = when {
                frame.size >= 4 && frame[1] == 0xF1 && frame[2] == (expectedSource and 0xFF) -> 3
                frame.isNotEmpty() && frame[0] == (positiveService and 0xFF) -> 0
                else -> -1
            }
            payloadIndex >= 0 &&
                frame.getOrNull(payloadIndex) == (positiveService and 0xFF) &&
                (identifier == null || frame.getOrNull(payloadIndex + 1) == (identifier and 0xFF))
        }
    }

    private fun extractKwpFrames(response: String): List<List<Int>> {
        val byteRegex = Regex("(?i)(?<![0-9A-F])([0-9A-F]{2})(?![0-9A-F])")
        return response
            .split('>', '\n', '\r')
            .map { segment -> byteRegex.findAll(segment).map { it.groupValues[1].toInt(16) }.toList() }
            .filter { it.isNotEmpty() }
    }

    private fun responseContainsHexMarker(response: String, marker: String): Boolean {
        val compact = Regex("[^0-9A-F]").replace(response.uppercase(Locale.US), "")
        return compact.contains(marker.uppercase(Locale.US))
    }

    private fun Int.hex2(): String = "%02X".format(Locale.US, this and 0xFF)


    private fun dynamic026ElapsedSec(): Long =
        if (dynamic026StartedElapsedMs > 0L) {
            ((SystemClock.elapsedRealtime() - dynamic026StartedElapsedMs).coerceAtLeast(0L) / 1000L)
        } else 0L

    private fun dynamic026ModeForName(name: String): Dynamic026Mode? = when (name) {
        FUEL_REFILL_BEFORE_ENGINE_TEST_NAME -> Dynamic026Mode.FUEL_BEFORE_ENGINE
        FUEL_REFILL_BEFORE_KOEO_TEST_NAME -> Dynamic026Mode.FUEL_BEFORE_KOEO
        FUEL_REFILL_AFTER_KOEO_TEST_NAME -> Dynamic026Mode.FUEL_AFTER_KOEO
        FUEL_REFILL_AFTER_ENGINE_TEST_NAME -> Dynamic026Mode.FUEL_AFTER_ENGINE
        FUEL_REFILL_DRIVE_TEST_NAME -> Dynamic026Mode.FUEL_DRIVE
        FUEL_REFILL_FINAL_KOEO_TEST_NAME -> Dynamic026Mode.FUEL_FINAL_KOEO
        CONTROL_HANDBRAKE_TEST_NAME -> Dynamic026Mode.CONTROL_HANDBRAKE
        CONTROL_CLUTCH_TEST_NAME -> Dynamic026Mode.CONTROL_CLUTCH
        CONTROL_BRAKE_TEST_NAME -> Dynamic026Mode.CONTROL_BRAKE
        CONTROL_GEAR_STATIC_TEST_NAME -> Dynamic026Mode.CONTROL_GEAR_STATIC
        CONTROL_GEAR_DRIVE_TEST_NAME -> Dynamic026Mode.CONTROL_GEAR_DRIVE
        KWP_026_KOEO_TEST_NAME -> Dynamic026Mode.KOEO
        KWP_026_ENGINE_STATIC_TEST_NAME -> Dynamic026Mode.ENGINE_STATIC
        KWP_026_DRIVE_TEST_NAME -> Dynamic026Mode.DRIVE
        KWP_026_POST_KOEO_TEST_NAME -> Dynamic026Mode.POST_KOEO
        KWP_026_WIDE_KOEO_TEST_NAME -> Dynamic026Mode.WIDE_KOEO
        KWP_026_WIDE_IDLE_TEST_NAME -> Dynamic026Mode.WIDE_IDLE
        KWP_026_WIDE_RPM_TEST_NAME -> Dynamic026Mode.WIDE_RPM
        KWP_026_WIDE_DRIVE_TEST_NAME -> Dynamic026Mode.WIDE_DRIVE
        KWP_026_WIDE_POST_TEST_NAME -> Dynamic026Mode.WIDE_POST
        else -> null
    }

    private fun dynamic026ModeTag(mode: Dynamic026Mode?): String = when (mode) {
        Dynamic026Mode.FUEL_BEFORE_ENGINE -> "fuel_before_engine"
        Dynamic026Mode.FUEL_BEFORE_KOEO -> "fuel_before_koeo"
        Dynamic026Mode.FUEL_AFTER_KOEO -> "fuel_after_koeo"
        Dynamic026Mode.FUEL_AFTER_ENGINE -> "fuel_after_engine"
        Dynamic026Mode.FUEL_DRIVE -> "fuel_drive"
        Dynamic026Mode.FUEL_FINAL_KOEO -> "fuel_final_koeo"
        Dynamic026Mode.CONTROL_HANDBRAKE -> "control_handbrake"
        Dynamic026Mode.CONTROL_CLUTCH -> "control_clutch"
        Dynamic026Mode.CONTROL_BRAKE -> "control_brake"
        Dynamic026Mode.CONTROL_GEAR_STATIC -> "control_gear_static"
        Dynamic026Mode.CONTROL_GEAR_DRIVE -> "control_gear_drive"
        Dynamic026Mode.KOEO -> "koeo"
        Dynamic026Mode.ENGINE_STATIC -> "engine_static"
        Dynamic026Mode.DRIVE -> "drive"
        Dynamic026Mode.POST_KOEO -> "post_koeo"
        Dynamic026Mode.WIDE_KOEO -> "wide_koeo"
        Dynamic026Mode.WIDE_IDLE -> "wide_idle"
        Dynamic026Mode.WIDE_RPM -> "wide_rpm"
        Dynamic026Mode.WIDE_DRIVE -> "wide_drive"
        Dynamic026Mode.WIDE_POST -> "wide_post"
        null -> "unknown"
    }

    private fun dynamic026ExpectedTotalSec(mode: Dynamic026Mode?): Long = when (mode) {
        Dynamic026Mode.FUEL_BEFORE_ENGINE -> 75L
        Dynamic026Mode.FUEL_BEFORE_KOEO, Dynamic026Mode.FUEL_AFTER_KOEO, Dynamic026Mode.FUEL_FINAL_KOEO -> 60L
        Dynamic026Mode.FUEL_AFTER_ENGINE -> 120L
        Dynamic026Mode.FUEL_DRIVE -> 10L * 60L
        Dynamic026Mode.CONTROL_HANDBRAKE -> 5L * 60L
        Dynamic026Mode.CONTROL_CLUTCH, Dynamic026Mode.CONTROL_BRAKE -> 3L * 60L
        Dynamic026Mode.CONTROL_GEAR_STATIC -> 5L * 60L
        Dynamic026Mode.CONTROL_GEAR_DRIVE -> 5L * 60L
        Dynamic026Mode.KOEO, Dynamic026Mode.POST_KOEO -> 2L * 60L
        Dynamic026Mode.ENGINE_STATIC -> 4L * 60L
        Dynamic026Mode.DRIVE -> 6L * 60L
        Dynamic026Mode.WIDE_KOEO, Dynamic026Mode.WIDE_IDLE, Dynamic026Mode.WIDE_POST -> 7L * 60L
        Dynamic026Mode.WIDE_RPM -> 3L * 60L
        Dynamic026Mode.WIDE_DRIVE -> 10L * 60L
        null -> 5L * 60L
    }

    private fun dynamic026EngineRequired(mode: Dynamic026Mode): Boolean = mode in setOf(
        Dynamic026Mode.FUEL_BEFORE_ENGINE,
        Dynamic026Mode.FUEL_AFTER_ENGINE,
        Dynamic026Mode.FUEL_DRIVE,
        Dynamic026Mode.CONTROL_HANDBRAKE,
        Dynamic026Mode.CONTROL_CLUTCH,
        Dynamic026Mode.CONTROL_BRAKE,
        Dynamic026Mode.CONTROL_GEAR_STATIC,
        Dynamic026Mode.CONTROL_GEAR_DRIVE,
        Dynamic026Mode.ENGINE_STATIC,
        Dynamic026Mode.DRIVE,
        Dynamic026Mode.WIDE_IDLE,
        Dynamic026Mode.WIDE_RPM,
        Dynamic026Mode.WIDE_DRIVE
    )

    private fun dynamic026KoeoRequired(mode: Dynamic026Mode): Boolean = mode in setOf(
        Dynamic026Mode.FUEL_BEFORE_KOEO,
        Dynamic026Mode.FUEL_AFTER_KOEO,
        Dynamic026Mode.FUEL_FINAL_KOEO,
        Dynamic026Mode.KOEO,
        Dynamic026Mode.POST_KOEO,
        Dynamic026Mode.WIDE_KOEO,
        Dynamic026Mode.WIDE_POST
    )

    private fun dynamic026ProfileForMode(mode: Dynamic026Mode?): Dynamic026ScanProfile = when {
        mode?.name?.startsWith("FUEL_") == true -> Dynamic026ScanProfile.FUEL_REFILL
        mode == Dynamic026Mode.CONTROL_HANDBRAKE -> Dynamic026ScanProfile.HANDBRAKE_TARGETED
        mode?.name?.startsWith("CONTROL_") == true -> Dynamic026ScanProfile.CONTROL_DISCOVERY
        else -> Dynamic026ScanProfile.RESEARCH
    }

    private fun dynamic026NewGroupId(prefix: String = "026"): String = "${prefix}_${trustedFileStamp()}"

    private fun resolveDynamic026Group(mode: Dynamic026Mode): String {
        val startsFuelGroup = mode == Dynamic026Mode.FUEL_BEFORE_ENGINE
        val startsControlGroup = mode == Dynamic026Mode.CONTROL_HANDBRAKE
        val startsResearchGroup = mode == Dynamic026Mode.KOEO || mode == Dynamic026Mode.WIDE_KOEO
        val existing = dynamic026GroupPrefs.getString(KEY_DYNAMIC_026_GROUP_ID, null)
        val prefix = when {
            mode.name.startsWith("FUEL_") -> "fuel"
            mode.name.startsWith("CONTROL_") -> "control"
            else -> "026"
        }
        val existingMatchesProfile = existing?.startsWith("${prefix}_") == true
        val startsNewGroup = startsFuelGroup || startsControlGroup || startsResearchGroup || !existingMatchesProfile
        val group = if (startsNewGroup || existing.isNullOrBlank()) dynamic026NewGroupId(prefix) else existing
        if (prefix == "fuel" && startsNewGroup) {
            dynamic026GroupPrefs.edit().remove(KEY_FUEL_REFILL_LITERS).apply()
            state = state.copy(fuelRefillLitersText = "")
        }
        dynamic026GroupPrefs.edit()
            .putString(KEY_DYNAMIC_026_GROUP_ID, group)
            .putLong(KEY_DYNAMIC_026_GROUP_UPDATED_MS, System.currentTimeMillis())
            .apply()
        return group
    }

    private fun dynamic026GroupDirectory(groupId: String): File =
        File(File(context.filesDir, "dynamic_026_validation"), groupId).apply { mkdirs() }

    private fun persistDynamic026Checkpoint(phase: String, percent: Int) {
        dynamic026Prefs.edit()
            .putBoolean(KEY_DYNAMIC_026_ACTIVE, true)
            .putString(KEY_DYNAMIC_026_RAW_FILE, dynamic026WorkingFile?.absolutePath)
            .putString(KEY_DYNAMIC_026_RESEARCH_FILE, dynamic026ResearchFile?.absolutePath)
            .putString(KEY_DYNAMIC_026_PHASE, phase)
            .putInt(KEY_DYNAMIC_026_PERCENT, percent.coerceIn(0, 99))
            .putString(KEY_DYNAMIC_026_TEST_NAME, dynamic026ActiveName)
            .putString(KEY_DYNAMIC_026_MODE, dynamic026Mode?.name)
            .putString(KEY_DYNAMIC_026_GROUP_ID, dynamic026GroupId)
            .apply()
    }

    private fun clearDynamic026Checkpoint() {
        dynamic026Prefs.edit().clear().apply()
    }

    private fun startDynamic026UiTicker() {
        dynamic026UiTickerJob?.cancel()
        dynamic026UiTickerJob = scope.launch {
            while (currentCoroutineContext().isActive && isKwp026DeveloperTest(state.activeDeveloperTest)) {
                val elapsed = dynamic026ElapsedSec()
                val estimated = (dynamic026ExpectedTotalSec(dynamic026Mode) - elapsed).coerceAtLeast(0L)
                withMain {
                    if (isKwp026DeveloperTest(state.activeDeveloperTest)) {
                        state = state.copy(
                            developerTestElapsedSec = elapsed,
                            developerTestEstimatedRemainingSec = estimated
                        )
                    }
                }
                delay(1_000L)
            }
        }
    }

    private fun stopDynamic026UiTicker() {
        dynamic026UiTickerJob?.cancel()
        dynamic026UiTickerJob = null
    }

    private fun recoverInterruptedDynamic026IfNeeded() {
        if (!dynamic026Prefs.getBoolean(KEY_DYNAMIC_026_ACTIVE, false)) return
        val rawPath = dynamic026Prefs.getString(KEY_DYNAMIC_026_RAW_FILE, null)
        val researchPath = dynamic026Prefs.getString(KEY_DYNAMIC_026_RESEARCH_FILE, null)
        val phase = dynamic026Prefs.getString(KEY_DYNAMIC_026_PHASE, null) ?: "Bilinmeyen aşama"
        val percent = dynamic026Prefs.getInt(KEY_DYNAMIC_026_PERCENT, 0).coerceIn(0, 99)
        val testName = dynamic026Prefs.getString(KEY_DYNAMIC_026_TEST_NAME, null) ?: KWP_026_DYNAMIC_TEST_NAME
        val groupId = dynamic026Prefs.getString(KEY_DYNAMIC_026_GROUP_ID, null) ?: "unknown"
        clearDynamic026Checkpoint()
        val rawFile = rawPath?.let(::File)?.takeIf { it.exists() }
        val researchFile = researchPath?.let(::File)?.takeIf { it.exists() }
        rawFile?.let { file ->
            runCatching {
                file.appendText("${System.currentTimeMillis()} [PROCESS_INTERRUPTED] test=$testName group=$groupId phase=$phase percent=$percent action=partial_package\n")
            }
        }
        if (rawFile == null && researchFile == null) return
        scope.launch {
            val fileName = "loganos_dynamic_026_partial_v${safeVersionTag()}_${trustedFileStamp()}.zip"
            val archiveBytes = ByteArrayOutputStream().use { buffer ->
                ZipOutputStream(buffer).use { zip ->
                    rawFile?.let {
                        zip.putNextEntry(ZipEntry("00_dynamic_test_partial.txt"))
                        zip.write(it.readBytes())
                        zip.closeEntry()
                    }
                    researchFile?.let {
                        zip.putNextEntry(ZipEntry("01_research_blocks_partial.jsonl"))
                        zip.write(it.readBytes())
                        zip.closeEntry()
                    }
                    zip.putNextEntry(ZipEntry("02_interruption.json"))
                    zip.write(
                        JSONObject()
                            .put("test_name", testName)
                            .put("group_id", groupId)
                            .put("phase", phase)
                            .put("progress_percent", percent)
                            .put("status", "PROCESS_INTERRUPTED")
                            .toString(2)
                            .toByteArray(Charsets.UTF_8)
                    )
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("BENI_OKU.txt"))
                    zip.write(
                        "0x26 araştırma bölümü uygulama veya Android işlemi tarafından yarıda kesildi. Tamamlanan diğer bağımsız bölümler korunur; yalnız bu bölümü tekrar çalıştırın.\n".toByteArray(Charsets.UTF_8)
                    )
                    zip.closeEntry()
                }
                buffer.toByteArray()
            }
            val displayPath = saveBytesToDownloads(fileName, "application/zip", archiveBytes)
            withMain {
                state = state.copy(
                    activeDeveloperTest = null,
                    developerTestPhaseText = "Test yarıda kaldı",
                    developerTestProgressText = "Kısmi ham blok paketi kaydedildi; tamamlanan diğer bölümler etkilenmedi",
                    developerTestProgressPercent = percent,
                    developerTestElapsedSec = null,
                    developerTestEstimatedRemainingSec = null,
                    developerTestCurrentTarget = null,
                    developerTestDoneMessage = "Yarım kalan 0x26 araştırma bölümü bulundu",
                    savedLogPath = displayPath,
                    savedLogFileName = fileName,
                    sharedLogReady = true,
                    status = "Yarım kalan 0x26 testi için kısmi paket oluşturuldu: $displayPath"
                )
            }
            ObdForegroundService.notifyDynamic026Result(context, false, fileName)
        }
    }

    private fun createDynamic026CombinedPackage() {
        if (state.activeDeveloperTest != null) {
            state = state.copy(status = "Birleşik paket için önce aktif testi bitir")
            return
        }
        val groupId = dynamic026GroupPrefs.getString(KEY_DYNAMIC_026_GROUP_ID, null)
        if (groupId.isNullOrBlank()) {
            state = state.copy(status = "Birleştirilecek 0x26 araştırma sonucu bulunamadı")
            return
        }
        val groupDir = dynamic026GroupDirectory(groupId)
        val files = groupDir.walkTopDown()
            .filter { it.isFile && it.extension.lowercase(Locale.US) in setOf("txt", "json", "jsonl") }
            .sortedBy { it.name }
            .toList()
        if (files.isEmpty()) {
            state = state.copy(status = "Bu araştırma grubunda henüz tamamlanmış sonuç yok")
            return
        }
        scope.launch {
            val fileName = "loganos_dynamic_026_combined_${groupId}_v${safeVersionTag()}_${trustedFileStamp()}.zip"
            val archiveBytes = ByteArrayOutputStream().use { buffer ->
                ZipOutputStream(buffer).use { zip ->
                    files.forEach { file ->
                        val relative = file.relativeTo(groupDir).invariantSeparatorsPath
                        zip.putNextEntry(ZipEntry("stages/$relative"))
                        zip.write(file.readBytes())
                        zip.closeEntry()
                    }
                    zip.putNextEntry(ZipEntry("00_group_manifest.json"))
                    zip.write(
                        JSONObject()
                            .put("schema", "loganos_dynamic_026_group_v2")
                            .put("version", BuildConfig.VERSION_NAME)
                            .put("group_id", groupId)
                            .put("file_count", files.size)
                            .put("created_at_ms", System.currentTimeMillis())
                            .put("note", "Bağımsız 0x26 doğrulama ve geniş araştırma aşamalarının birleşik ham paketi")
                            .toString(2)
                            .toByteArray(Charsets.UTF_8)
                    )
                    zip.closeEntry()
                    zip.putNextEntry(ZipEntry("BENI_OKU.txt"))
                    zip.write(
                        "Bu birleşik paket aynı araştırma grubunda tamamlanan bağımsız aşamaları içerir. Eksik bir aşama varsa yalnız o aşama tekrar çalıştırılabilir. Yakıt adayları 21DD/21DE önceliklidir; diğer cevap veren bloklar ham olarak korunmuştur.\n".toByteArray(Charsets.UTF_8)
                    )
                    zip.closeEntry()
                }
                buffer.toByteArray()
            }
            val displayPath = saveBytesToDownloads(fileName, "application/zip", archiveBytes)
            withMain {
                state = state.copy(
                    developerTestDoneMessage = "0x26 birleşik sonuç paketi oluşturuldu",
                    savedLogPath = displayPath,
                    savedLogFileName = fileName,
                    sharedLogReady = true,
                    status = "Birleşik 0x26 sonuçları kaydedildi: $displayPath"
                )
            }
            ObdForegroundService.notifyDynamic026Result(context, true, fileName)
        }
    }

    private fun dynamic026GuidedStepsForMode(mode: Dynamic026Mode): List<Dynamic026GuidedStep> = when (mode) {
        Dynamic026Mode.FUEL_BEFORE_ENGINE -> listOf(
            Dynamic026GuidedStep(
                phase = "FUEL_BEFORE_ENGINE",
                instruction = "Motor çalışıyor, araç sabit ve gaz verilmeden rölantide bekle",
                seconds = 10,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.FUEL_REFILL
            )
        )
        Dynamic026Mode.FUEL_AFTER_ENGINE -> listOf(
            Dynamic026GuidedStep(
                phase = "FUEL_AFTER_ENGINE_15S",
                instruction = "Motoru çalıştırdıktan sonra gaz vermeden rölantide bekle",
                seconds = 10,
                repeatPasses = 2,
                profile = Dynamic026ScanProfile.FUEL_REFILL
            ),
            Dynamic026GuidedStep(
                phase = "FUEL_AFTER_ENGINE_60S",
                instruction = "Motor rölantide çalışmaya devam etsin; ikinci ölçüm için bekle",
                seconds = 45,
                repeatPasses = 2,
                profile = Dynamic026ScanProfile.FUEL_REFILL
            )
        )
        Dynamic026Mode.CONTROL_HANDBRAKE -> listOf(
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_ON_1",
                instruction = "El frenini tamamen ÇEK ve sabit tut. Ayak freni basılı, vites boşta kalsın.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            ),
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_OFF_1",
                instruction = "Ayak freni basılı kalırken el frenini tamamen İNDİR ve sabit tut.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            ),
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_ON_2",
                instruction = "El frenini yeniden tamamen ÇEK ve sabit tut.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            ),
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_OFF_2",
                instruction = "El frenini yeniden tamamen İNDİR. Ayak freni basılı kalsın.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            ),
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_ON_3",
                instruction = "El frenini üçüncü kez tamamen ÇEK ve sabit tut.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            ),
            Dynamic026GuidedStep(
                phase = "HANDBRAKE_OFF_3",
                instruction = "El frenini üçüncü kez tamamen İNDİR. Test bitene kadar ayak freni basılı kalsın.",
                seconds = 4,
                repeatPasses = 3,
                profile = Dynamic026ScanProfile.HANDBRAKE_TARGETED
            )
        )
        Dynamic026Mode.CONTROL_CLUTCH -> listOf(
            Dynamic026GuidedStep("CLUTCH_RELEASED_1", "Araç sabit, vites boş ve el freni çekili: debriyaj pedalına dokunma", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("CLUTCH_PRESSED_1", "Debriyaja sonuna kadar bas ve basılı tut", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("CLUTCH_RELEASED_2", "Debriyajı tamamen bırak", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("CLUTCH_PRESSED_2", "Debriyaja yeniden sonuna kadar bas", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("CLUTCH_RELEASED_3", "Debriyajı üçüncü kez tamamen bırak", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("CLUTCH_PRESSED_3", "Debriyaja üçüncü kez bas ve ölçüm bitene kadar tut", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY)
        )
        Dynamic026Mode.CONTROL_BRAKE -> listOf(
            Dynamic026GuidedStep("BRAKE_RELEASED_1", "Araç sabit, vites boş ve el freni çekili: ayak frenine dokunma", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("BRAKE_PRESSED_1", "Fren pedalına normal kuvvetle bas ve basılı tut", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("BRAKE_RELEASED_2", "Fren pedalını tamamen bırak", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("BRAKE_PRESSED_2", "Frene yeniden bas ve basılı tut", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("BRAKE_RELEASED_3", "Fren pedalını üçüncü kez bırak", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("BRAKE_PRESSED_3", "Frene üçüncü kez bas ve ölçüm bitene kadar tut", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY)
        )
        Dynamic026Mode.CONTROL_GEAR_STATIC -> listOf(
            Dynamic026GuidedStep("GEAR_N_1", "Araç sabit, el freni çekili, ayak freni ve debriyaj basılı: vitesi BOŞ konumuna al", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_1", "Debriyaj basılıyken 1. vitese geçir", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_2", "Tekrar BOŞ konumuna al", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_2", "Debriyaj basılıyken 2. vitese geçir", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_3", "Tekrar BOŞ konumuna al", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_3", "Debriyaj basılıyken 3. vitese geçir", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_4", "Tekrar BOŞ konumuna al", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_4", "Debriyaj basılıyken 4. vitese geçir", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_5", "Tekrar BOŞ konumuna al", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_5", "Debriyaj basılıyken 5. vitese geçir", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_6", "Tekrar BOŞ konumuna al", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_R", "Debriyaj basılıyken GERİ vitese geçir; araç kesinlikle hareket etmesin", 5, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY),
            Dynamic026GuidedStep("GEAR_N_FINAL", "Son olarak BOŞ konumuna dön", 4, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY)
        )
        Dynamic026Mode.CONTROL_GEAR_DRIVE -> listOf(
            Dynamic026GuidedStep("GEAR_DRIVE_1", "Güvenli yolda 1. viteste sabit ilerle; telefona dokunma", 10, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY, requireStationary = false, minimumSpeedKmh = 8),
            Dynamic026GuidedStep("GEAR_DRIVE_2", "Uygun olduğunda 2. vitese geç ve sabit ilerle; telefona dokunma", 12, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY, requireStationary = false, minimumSpeedKmh = 15),
            Dynamic026GuidedStep("GEAR_DRIVE_3", "Uygun olduğunda 3. vitese geç ve sabit ilerle; telefona dokunma", 12, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY, requireStationary = false, minimumSpeedKmh = 25),
            Dynamic026GuidedStep("GEAR_DRIVE_4", "Uygun ve güvenli yolda 4. vitese geç ve sabit ilerle", 12, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY, requireStationary = false, minimumSpeedKmh = 35),
            Dynamic026GuidedStep("GEAR_DRIVE_5", "Yol ve hız sınırı uygunsa 5. vitese geç ve sabit ilerle", 12, profile = Dynamic026ScanProfile.CONTROL_DISCOVERY, requireStationary = false, minimumSpeedKmh = 45)
        )
        else -> emptyList()
    }

    private fun handbrakeStepLabel(phase: String): String? = when {
        phase.startsWith("HANDBRAKE_ON_") -> "EL FRENİ ÇEKİLİ"
        phase.startsWith("HANDBRAKE_OFF_") -> "EL FRENİ İNDİRİLMİŞ"
        else -> null
    }

    private fun handbrakeSafetyLine(): String =
        "AYAK FRENİ BASILI • VİTES BOŞ • ARAÇ TAMAMEN SABİT"

    private fun beginDynamic026GuidedStep() {
        val step = dynamic026GuidedSteps.getOrNull(dynamic026GuidedStepIndex) ?: return
        dynamic026Stage = Dynamic026Stage.GUIDED_COUNTDOWN
        dynamic026GuidedStepStartedMs = SystemClock.elapsedRealtime()
        dynamic026ConditionSinceMs = dynamic026GuidedStepStartedMs
        val total = dynamic026GuidedSteps.size.coerceAtLeast(1)
        val percent = ((dynamic026GuidedStepIndex.toDouble() / total.toDouble()) * 90.0).toInt().coerceIn(0, 90)
        persistDynamic026Checkpoint(step.phase, percent)
        val handbrakeLabel = if (dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE) handbrakeStepLabel(step.phase) else null
        state = state.copy(
            developerTestPhaseText = if (handbrakeLabel != null) "Hazırlan • Adım ${dynamic026GuidedStepIndex + 1}/$total" else "Adım ${dynamic026GuidedStepIndex + 1}/$total",
            developerTestRemainingSec = step.seconds,
            developerTestProgressText = if (handbrakeLabel != null) "${handbrakeSafetyLine()}\n${step.instruction}" else step.instruction,
            developerTestProgressPercent = percent,
            developerTestCurrentTarget = null,
            developerTestStepLabel = handbrakeLabel,
            developerTestStepIndex = dynamic026GuidedStepIndex + 1,
            developerTestStepTotal = total,
            developerTestStageLabel = if (handbrakeLabel != null) "HAZIRLAN" else null
        )
        appendDynamic026("GUIDED_STEP", "index=${dynamic026GuidedStepIndex + 1}/$total phase=${step.phase} seconds=${step.seconds} instruction=${step.instruction}")
    }

    private fun startDynamic026Test(name: String, allowConnectionRecovery: Boolean = true) {
        val mode = dynamic026ModeForName(name)
        if (mode == null) {
            state = state.copy(status = "Bilinmeyen 0x26 test bölümü")
            return
        }
        if (state.activeDeveloperTest != null) {
            state = state.copy(status = "Önce aktif geliştirici testini bitir")
            return
        }
        if (!state.connected && !state.connecting) {
            if (allowConnectionRecovery) {
                requestDeveloperTestConnectionRecovery(name)
            } else {
                state = state.copy(status = "$name için OBD bağlantısı gerekli")
            }
            appendLog("[DYNAMIC_026_BLOCKED] test=$name reason=OBD connection required")
            return
        }

        val speed = state.snapshot.speedKmh ?: 0
        val rpm = state.snapshot.rpm
        val koeoRequired = dynamic026KoeoRequired(mode)
        val engineRequired = dynamic026EngineRequired(mode)
        if (speed > 2) {
            state = state.copy(status = "$name araç tamamen dururken başlatılmalı")
            appendLog("[DYNAMIC_026_BLOCKED] test=$name reason=vehicle moving speed=$speed")
            return
        }
        if (koeoRequired && rpm != null && rpm > 50) {
            if (allowConnectionRecovery) {
                requestDeveloperTestConnectionRecovery(name)
            } else {
                state = state.copy(status = "Motor kapalı görünüyor ancak eski RPM verisi kaldı. OBD oturumu yenileniyor")
            }
            appendLog("[DYNAMIC_026_BLOCKED] test=$name reason=KOEO stale RPM rpm=$rpm")
            return
        }
        if (engineRequired && (rpm == null || rpm < 500)) {
            if (allowConnectionRecovery) {
                requestDeveloperTestConnectionRecovery(name)
            } else {
                state = state.copy(status = "Motor çalışıyor ancak RPM alınamadı. OBD bağlantısını yenileyip tekrar deneyin")
            }
            appendLog("[DYNAMIC_026_BLOCKED] test=$name reason=engine RPM required rpm=${rpm ?: -1}")
            return
        }
        clearPendingDeveloperTest("test started")

        developerTestJob?.cancel()
        developerTestJob = null
        activeDeveloperTestHistoryId?.let {
            sqlStore.endTestSession(it, "INTERRUPTED", "$name başlatıldığı için önceki test kapatıldı")
        }
        activeDeveloperTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
                testType = "KWP_026_SEGMENTED_VALIDATION",
                name = name,
                versionName = BuildConfig.VERSION_NAME,
                note = "Bağımsız, salt-okunur 0x26/0x7A araştırma bölümü; motor/kontak geçişi test dışında yapılır"
            )
        } else null

        dynamic026Mode = mode
        dynamic026ActiveName = name
        dynamic026GroupId = resolveDynamic026Group(mode)
        val groupDir = dynamic026GroupDirectory(dynamic026GroupId)
        val stamp = trustedFileStamp()
        val modeTag = dynamic026ModeTag(mode)
        dynamic026WorkingFile = File(groupDir, "${modeTag}_$stamp.txt").apply {
            writeText(
                buildString {
                    appendLine("LOGANOS 0x26 SEGMENTED DYNAMIC VALIDATION")
                    appendLine("version=${BuildConfig.VERSION_NAME}")
                    appendLine("test_name=$name")
                    appendLine("mode=${mode.name}")
                    appendLine("group_id=$dynamic026GroupId")
                    appendLine("started=$stamp")
                    appendLine("vehicle=${runtimeSettings.vehicleModel}")
                    appendLine("engine=${runtimeSettings.engine}")
                    appendLine("adapter=${state.selectedName ?: "--"} / ${maskBluetoothAddress(state.selectedAddress)}")
                    appendLine("profile=${state.activeProfile}")
                    appendLine("scan_profile=${dynamic026ProfileForMode(mode).name}")
                    appendLine("fuel_added_liters=${dynamic026GroupPrefs.getString(KEY_FUEL_REFILL_LITERS, null) ?: "--"}")
                    appendLine("priority_0x26=D0,DC,DD,DE,D8,D9")
                    appendLine("priority_0x7A=91,A0,A2,A7,A8")
                    appendLine("research_0x26=94,D0,D1,DB,DC,DD,DE,D8,D9")
                    appendLine("research_0x7A=91,A0,A1,A2,A4,A5,A6,A7,A8,A9,AE,CC,CD,CE,CF")
                    appendLine("blocked=0x26/21A2 and all security/write/actuator/programming services")
                    appendLine()
                }
            )
        }
        dynamic026ResearchFile = File(groupDir, "${modeTag}_research_$stamp.jsonl").apply { writeText("") }
        dynamic026ScanInProgress = false
        dynamic026StopRequested = false
        dynamic026StartedElapsedMs = SystemClock.elapsedRealtime()
        dynamic026StageEnteredElapsedMs = dynamic026StartedElapsedMs
        dynamic026ConditionSinceMs = null
        dynamic026DriveStartDistanceKm = state.snapshot.tripDistanceKm
        dynamic026DriveAccumulatedKm = 0.0
        dynamic026DriveLastElapsedMs = SystemClock.elapsedRealtime()
        dynamic026GuidedSteps = emptyList()
        dynamic026GuidedStepIndex = 0
        dynamic026GuidedStepStartedMs = 0L
        dynamic026MissingRpmSinceMs = null
        dynamic026ActiveReconnectAttempts = 0
        dynamic026ActiveReconnectJob?.cancel()
        dynamic026ActiveReconnectJob = null
        dynamic026ScanRequest = null
        dynamic026Stage = Dynamic026Stage.SCAN

        val initialPhase: String
        val initialText: String
        val initialDetail: String
        when (mode) {
            Dynamic026Mode.FUEL_BEFORE_ENGINE,
            Dynamic026Mode.FUEL_AFTER_ENGINE,
            Dynamic026Mode.CONTROL_HANDBRAKE,
            Dynamic026Mode.CONTROL_CLUTCH,
            Dynamic026Mode.CONTROL_BRAKE,
            Dynamic026Mode.CONTROL_GEAR_STATIC,
            Dynamic026Mode.CONTROL_GEAR_DRIVE -> {
                dynamic026GuidedSteps = dynamic026GuidedStepsForMode(mode)
                val first = dynamic026GuidedSteps.first()
                initialPhase = first.phase
                initialText = when (mode) {
                    Dynamic026Mode.FUEL_BEFORE_ENGINE -> "Yakıt öncesi • motor çalışır"
                    Dynamic026Mode.FUEL_AFTER_ENGINE -> "Yakıt sonrası • motor çalışır"
                    Dynamic026Mode.CONTROL_HANDBRAKE -> "El freni keşfi"
                    Dynamic026Mode.CONTROL_CLUTCH -> "Debriyaj keşfi"
                    Dynamic026Mode.CONTROL_BRAKE -> "Fren pedalı keşfi"
                    Dynamic026Mode.CONTROL_GEAR_STATIC -> "Sabit araçta vites keşfi"
                    Dynamic026Mode.CONTROL_GEAR_DRIVE -> "Sürüşte vites oranı kaydı"
                    else -> name
                }
                initialDetail = first.instruction
                dynamic026Stage = Dynamic026Stage.GUIDED_COUNTDOWN
                dynamic026GuidedStepStartedMs = SystemClock.elapsedRealtime()
            }
            Dynamic026Mode.FUEL_BEFORE_KOEO -> {
                initialPhase = "FUEL_BEFORE_KOEO"
                initialText = "Yakıt öncesi • kontak açık"
                initialDetail = "Motor kapalı, kontak açık ve araç sabit. Yakıt adayları üç tur okunuyor."
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 3, includeResearchBlocks = false, completeAfterScan = true, profile = Dynamic026ScanProfile.FUEL_REFILL)
            }
            Dynamic026Mode.FUEL_AFTER_KOEO -> {
                initialPhase = "FUEL_AFTER_KOEO"
                initialText = "Yakıt sonrası • kontak açık"
                initialDetail = "Pompadan ayrılıp güvenli yere park ettikten sonra motor kapalı ve kontak açık ölçüm alınıyor."
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 3, includeResearchBlocks = false, completeAfterScan = true, profile = Dynamic026ScanProfile.FUEL_REFILL)
            }
            Dynamic026Mode.FUEL_DRIVE -> {
                initialPhase = "FUEL_DRIVE_BASELINE"
                initialText = "Yakıt sonrası kısa sürüş"
                initialDetail = "Araç sabit ve motor çalışırken başlangıç ölçümü alınıyor. Tamamlanana kadar hareket etme."
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 2, includeResearchBlocks = false, profile = Dynamic026ScanProfile.FUEL_REFILL)
            }
            Dynamic026Mode.FUEL_FINAL_KOEO -> {
                initialPhase = "FUEL_FINAL_KOEO"
                initialText = "Yakıt testi • son kontak açık"
                initialDetail = "Sürüş sonrası motor kapalı ve kontak açık son karşılaştırma üç tur alınıyor."
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 3, includeResearchBlocks = false, completeAfterScan = true, profile = Dynamic026ScanProfile.FUEL_REFILL)
            }
            Dynamic026Mode.KOEO -> {
                initialPhase = "KOEO_BASELINE"
                initialText = "Kontak açık • motor kapalı"
                initialDetail = "Yakıt adayları ve doğrulanmış araştırma blokları iki tur okunuyor"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 2, includeResearchBlocks = true, completeAfterScan = true)
            }
            Dynamic026Mode.POST_KOEO -> {
                initialPhase = "POST_DRIVE_KOEO"
                initialText = "Sürüş sonrası kontak açık"
                initialDetail = "Sürüş öncesi değerlerle karşılaştırılacak son ham ölçümler alınıyor"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 2, includeResearchBlocks = true, completeAfterScan = true)
            }
            Dynamic026Mode.ENGINE_STATIC -> {
                initialPhase = "ENGINE_IDLE_STABILIZING"
                initialText = "Rölanti kararlılığı"
                initialDetail = "Gaz verme; araç sabitken 15 saniye rölantide bekle"
                dynamic026Stage = Dynamic026Stage.IDLE_STABILIZING
                dynamic026ConditionSinceMs = SystemClock.elapsedRealtime()
            }
            Dynamic026Mode.DRIVE -> {
                initialPhase = "DRIVE_BASELINE"
                initialText = "Kısa sürüş başlangıcı"
                initialDetail = "Araç sabit ve motor çalışırken başlangıç blokları okunuyor; sonra güvenli sürüşe çık"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 1, includeResearchBlocks = true)
            }
            Dynamic026Mode.WIDE_KOEO -> {
                initialPhase = "WIDE_KOEO_DISCOVERY"
                initialText = "Geniş araştırma • kontak açık"
                initialDetail = "0x26 ve 0x7A üzerinde 2100–21FF aralığı salt-okunur olarak taranıyor"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 1, includeResearchBlocks = true, fullDiscovery = true, completeAfterScan = true)
            }
            Dynamic026Mode.WIDE_IDLE -> {
                initialPhase = "WIDE_IDLE_STABILIZING"
                initialText = "Geniş araştırma • rölanti"
                initialDetail = "Gaz verme; 15 saniye kararlı rölanti algılanınca geniş tarama başlayacak"
                dynamic026Stage = Dynamic026Stage.IDLE_STABILIZING
                dynamic026ConditionSinceMs = SystemClock.elapsedRealtime()
            }
            Dynamic026Mode.WIDE_RPM -> {
                initialPhase = "WIDE_WAITING_RPM_2000"
                initialText = "Geniş araştırma • 2000 rpm"
                initialDetail = "Araç sabit ve boş vitesteyken 1800–2200 rpm aralığını yakala"
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_2000_RPM
            }
            Dynamic026Mode.WIDE_DRIVE -> {
                initialPhase = "WIDE_DRIVE_BASELINE"
                initialText = "Geniş araştırma • kısa sürüş"
                initialDetail = "Başlangıç blokları okunuyor; sonra güvenli şekilde sürüşe çık ve telefonla ilgilenme"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 1, includeResearchBlocks = true)
            }
            Dynamic026Mode.WIDE_POST -> {
                initialPhase = "WIDE_POST_KOEO_DISCOVERY"
                initialText = "Geniş araştırma • sürüş sonrası"
                initialDetail = "Son kontak açık durumunda tam 2100–21FF karşılaştırması yapılıyor"
                dynamic026ScanRequest = Dynamic026ScanRequest(initialPhase, 1, includeResearchBlocks = true, fullDiscovery = true, completeAfterScan = true)
            }
        }

        persistDynamic026Checkpoint(initialPhase, 0)
        startDynamic026UiTicker()
        ObdForegroundService.start(context)
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "DYNAMIC_026_START", name, "mode=${mode.name} group=$dynamic026GroupId phase=$initialPhase")
        state = state.copy(
            activeDeveloperTest = name,
            developerTestPhaseText = initialText,
            developerTestRemainingSec = if (dynamic026Stage == Dynamic026Stage.IDLE_STABILIZING) DYNAMIC_026_IDLE_STABLE_SEC else null,
            developerTestProgressText = initialDetail,
            developerTestProgressPercent = 0,
            developerTestElapsedSec = 0L,
            developerTestEstimatedRemainingSec = dynamic026ExpectedTotalSec(mode),
            developerTestCurrentTarget = null,
            developerTestStepLabel = null,
            developerTestStepIndex = null,
            developerTestStepTotal = null,
            developerTestStageLabel = null,
            developerTestDoneMessage = null,
            status = "$name başlatıldı"
        )
        if (dynamic026GuidedSteps.isNotEmpty()) beginDynamic026GuidedStep()
        appendDynamic026("TEST_START", "name=$name mode=${mode.name} group=$dynamic026GroupId phase=$initialPhase")
        appendDynamic026Snapshot("START")
        refreshHistory()
    }

    private fun ensureDynamic026ScanActive(generation: Long, connectionAddress: String) {
        if (dynamic026StopRequested || dynamic026Stage == Dynamic026Stage.COMPLETED) throw Dynamic026StopSignal()
        if (!isKwp026DeveloperTest(state.activeDeveloperTest)) throw Dynamic026StopSignal()
        if (dynamic026ActiveName != state.activeDeveloperTest) throw Dynamic026StopSignal()
        if (!isConnectionCurrent(generation, connectionAddress)) throw IOException("Dynamic 0x26 connection changed")
    }

    private fun configureDynamic026Target(
        out: OutputStream,
        input: InputStream,
        target: Int,
        generation: Long,
        connectionAddress: String,
        reason: String
    ): Boolean {
        ensureDynamic026ScanActive(generation, connectionAddress)
        val hex = target.hex2()
        val commands = listOf(
            "ATIIA$hex" to Pair(40L, 500L),
            "ATWM81${hex}F1" to Pair(40L, 500L),
            "ATSH81${hex}F1" to Pair(40L, 500L),
            "ATFI" to Pair(220L, 1800L),
            "10C0" to Pair(40L, 750L)
        )
        for (attempt in 1..DYNAMIC_026_MODULE_RETRY_COUNT) {
            var initResponse = ""
            var sessionResponse = ""
            commands.forEach { (command, timing) ->
                ensureDynamic026ScanActive(generation, connectionAddress)
                val response = send(out, input, command, timing.first, timing.second)
                appendDynamic026("TARGET_CONFIG", "reason=$reason attempt=$attempt/$DYNAMIC_026_MODULE_RETRY_COUNT target=0x$hex cmd=$command response=$response")
                if (command == "ATFI") initResponse = response
                if (command == "10C0") sessionResponse = response
            }
            val initOk = initResponse.contains("BUS INIT", ignoreCase = true) && initResponse.contains("OK", ignoreCase = true)
            val sessionOk = positiveKwpResponse(sessionResponse, target, 0x50, 0xC0)
            if (initOk || sessionOk) return true
            appendDynamic026("TARGET_RETRY", "reason=$reason target=0x$hex attempt=$attempt result=failed")
            parser.resetRuntimeState()
            if (attempt < DYNAMIC_026_MODULE_RETRY_COUNT) Thread.sleep(DYNAMIC_026_MODULE_RETRY_DELAY_MS)
        }
        return false
    }

    private fun restoreEngineDynamic026BestEffort(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        connectionAddress: String,
        reason: String
    ): Boolean {
        if (!isConnectionCurrent(generation, connectionAddress)) {
            appendDynamic026("ENGINE_RESTORE_SKIPPED", "reason=$reason connection_changed=true")
            return false
        }
        val commands = listOf(
            "ATIIA7A" to Pair(40L, 500L),
            "ATWM817AF1" to Pair(40L, 500L),
            "ATSH817AF1" to Pair(40L, 500L),
            "ATFI" to Pair(220L, 1800L),
            "10C0" to Pair(40L, 750L)
        )
        var restored = false
        commands.forEach { (command, timing) ->
            val response = runCatching { send(out, input, command, timing.first, timing.second) }
                .getOrElse { error ->
                    appendDynamic026("ENGINE_RESTORE_ERROR", "reason=$reason cmd=$command type=${error::class.java.simpleName} message=${error.message ?: "--"}")
                    return@forEach
                }
            appendDynamic026("ENGINE_RESTORE", "reason=$reason cmd=$command response=$response")
            if (command == "ATFI" && response.contains("BUS INIT", ignoreCase = true) && response.contains("OK", ignoreCase = true)) restored = true
            if (command == "10C0" && positiveKwpResponse(response, 0x7A, 0x50, 0xC0)) restored = true
        }
        return restored
    }

    private fun dynamic026ProgressRange(phase: String): IntRange = when (phase) {
        "KOEO_BASELINE", "POST_DRIVE_KOEO", "WIDE_KOEO_DISCOVERY", "WIDE_POST_KOEO_DISCOVERY" -> 4..96
        "ENGINE_IDLE", "WIDE_IDLE_DISCOVERY" -> 15..48
        "RPM_2000", "WIDE_RPM_2000" -> 60..96
        "DRIVE_BASELINE", "WIDE_DRIVE_BASELINE", "FUEL_DRIVE_BASELINE" -> 4..14
        "DRIVE_MOTION", "WIDE_DRIVE_MOTION", "FUEL_DRIVE_MOTION" -> 18..28
        "DRIVE_500M", "WIDE_DRIVE_500M", "FUEL_DRIVE_500M" -> 36..48
        "DRIVE_2KM", "WIDE_DRIVE_2KM", "FUEL_DRIVE_2KM" -> 62..74
        "WIDE_DRIVE_5KM", "FUEL_DRIVE_5KM" -> 86..96
        else -> 2..96
    }

    private fun dynamic026PhaseTitle(phase: String): String = when (phase) {
        "FUEL_BEFORE_ENGINE" -> "Yakıt öncesi motor çalışır"
        "FUEL_BEFORE_KOEO" -> "Yakıt öncesi kontak açık"
        "FUEL_AFTER_KOEO" -> "Yakıt sonrası kontak açık"
        "FUEL_AFTER_ENGINE_15S" -> "Yakıt sonrası motor çalışır • ilk ölçüm"
        "FUEL_AFTER_ENGINE_60S" -> "Yakıt sonrası motor çalışır • 60 saniye"
        "FUEL_DRIVE_BASELINE" -> "Yakıt sürüşü başlangıç ölçümü"
        "FUEL_DRIVE_MOTION" -> "Yakıt sürüşü ilk hareket"
        "FUEL_DRIVE_500M" -> "Yakıt sürüşü 500 metre"
        "FUEL_DRIVE_2KM" -> "Yakıt sürüşü 2 kilometre"
        "FUEL_DRIVE_5KM" -> "Yakıt sürüşü 5 kilometre"
        "FUEL_FINAL_KOEO" -> "Yakıt testi son kontak açık"
        "KOEO_BASELINE" -> "Kontak açık • motor kapalı"
        "POST_DRIVE_KOEO" -> "Sürüş sonrası kontak açık"
        "ENGINE_IDLE" -> "Rölanti blok taraması"
        "RPM_2000" -> "2000 rpm doğrulaması"
        "DRIVE_BASELINE" -> "Sürüş başlangıç ölçümü"
        "DRIVE_MOTION" -> "Hareket ölçümü"
        "DRIVE_500M" -> "500 metre ölçümü"
        "DRIVE_2KM" -> "2 kilometre ölçümü"
        "WIDE_KOEO_DISCOVERY" -> "Geniş kontak açık taraması"
        "WIDE_IDLE_DISCOVERY" -> "Geniş rölanti taraması"
        "WIDE_RPM_2000" -> "Geniş 2000 rpm doğrulaması"
        "WIDE_DRIVE_BASELINE" -> "Geniş sürüş başlangıcı"
        "WIDE_DRIVE_MOTION" -> "Geniş hareket ölçümü"
        "WIDE_DRIVE_500M" -> "Geniş 500 metre ölçümü"
        "WIDE_DRIVE_2KM" -> "Geniş 2 kilometre ölçümü"
        "WIDE_DRIVE_5KM" -> "Geniş 5 kilometre ölçümü"
        "WIDE_POST_KOEO_DISCOVERY" -> "Geniş sürüş sonrası taraması"
        else -> dynamic026ActiveName ?: KWP_026_DYNAMIC_TEST_NAME
    }

    private fun dynamic026KnownIds(address: Int): Set<Int> = when (address) {
        0x26 -> setOf(0x80, 0x81, 0x94, 0xD0, 0xD1, 0xDB, 0xDC, 0xDD, 0xDE)
        0x7A -> setOf(0x80, 0x81, 0x82, 0x84, 0x91, 0xA0, 0xA1, 0xA2, 0xA3, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAE, 0xCC, 0xCD, 0xCE, 0xCF, 0xF0, 0xF1, 0xFC, 0xFD, 0xFE, 0xFF)
        else -> emptySet()
    }

    private fun dynamic026ModuleIds(address: Int, request: Dynamic026ScanRequest): List<Int> {
        if (request.fullDiscovery) {
            return (0x00..0xFF).filterNot { address == 0x26 && it == 0xA2 }
        }
        if (request.profile == Dynamic026ScanProfile.FUEL_REFILL) {
            return when (address) {
                0x26 -> listOf(0xD0, 0xDB, 0xDC, 0xDD, 0xDE)
                0x7A -> listOf(0xA0, 0xA2, 0xCC)
                else -> emptyList()
            }
        }
        if (request.profile == Dynamic026ScanProfile.HANDBRAKE_TARGETED) {
            return when (address) {
                0x26 -> listOf(0xDB, 0xDC, 0xDD, 0xDE)
                0x7A -> listOf(0xA0, 0xA1, 0xA2, 0xCC, 0xCD, 0xCE)
                else -> emptyList()
            }
        }
        if (request.profile == Dynamic026ScanProfile.CONTROL_DISCOVERY) {
            return when (address) {
                0x26 -> listOf(0xDB, 0xDC, 0xDD, 0xDE)
                0x7A -> listOf(0xA0, 0xA1, 0xA2, 0xCC, 0xCD, 0xCE)
                else -> emptyList()
            }
        }
        return when (address) {
            0x26 -> if (request.includeResearchBlocks) {
                listOf(0x94, 0xD0, 0xD1, 0xDB, 0xDC, 0xDD, 0xDE, 0xD8, 0xD9)
            } else {
                listOf(0xD0, 0xDC, 0xDD, 0xDE, 0xD8, 0xD9)
            }
            0x7A -> if (request.includeResearchBlocks) {
                listOf(0x91, 0xA0, 0xA1, 0xA2, 0xA4, 0xA5, 0xA6, 0xA7, 0xA8, 0xA9, 0xAE, 0xCC, 0xCD, 0xCE, 0xCF)
            } else {
                listOf(0x91, 0xA0, 0xA2, 0xA7, 0xA8)
            }
            else -> emptyList()
        }
    }

    private fun isDynamic026Priority(address: Int, identifier: Int): Boolean = when (address) {
        0x26 -> identifier in setOf(0xD0, 0xDC, 0xDD, 0xDE, 0xD8, 0xD9)
        0x7A -> identifier in setOf(0x91, 0xA0, 0xA2, 0xA7, 0xA8)
        else -> false
    }

    private suspend fun updateDynamic026Progress(percent: Int, phase: String, detail: String, target: String?) {
        val safePercent = percent.coerceIn(0, 99)
        persistDynamic026Checkpoint(phase, safePercent)
        val guidedInstruction = dynamic026GuidedSteps
            .getOrNull(dynamic026GuidedStepIndex)
            ?.takeIf { it.phase == dynamic026ScanRequest?.phase || dynamic026PhaseTitle(it.phase) == phase }
            ?.instruction
        val visibleDetail = if (guidedInstruction != null) {
            if (dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE) {
                "${handbrakeSafetyLine()}\n$guidedInstruction\nKONUMU DEĞİŞTİRME • $detail"
            } else {
                "$guidedInstruction • Konumu değiştirme; ölçüm sürüyor • $detail"
            }
        } else detail
        withMain {
            if (isKwp026DeveloperTest(state.activeDeveloperTest)) {
                state = state.copy(
                    developerTestPhaseText = if (dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE) {
                        "Ölçüm • Adım ${dynamic026GuidedStepIndex + 1}/${dynamic026GuidedSteps.size}"
                    } else phase,
                    developerTestProgressText = visibleDetail,
                    developerTestProgressPercent = safePercent,
                    developerTestCurrentTarget = target,
                    developerTestStageLabel = if (dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE) "ÖLÇÜM" else state.developerTestStageLabel
                )
            }
        }
    }

    private fun appendDynamic026(event: String, detail: String) {
        val file = dynamic026WorkingFile ?: return
        val mark = timeSource.now()
        val timestamp = mark.epochMs?.takeIf { mark.trusted }?.let {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(it))
        } ?: "TIME_PENDING+${mark.elapsedMs}ms"
        runCatching {
            synchronized(this) { file.appendText("$timestamp [$event] $detail\n") }
        }
    }

    private fun appendDynamic026Snapshot(label: String) {
        val snapshot = state.snapshot
        appendDynamic026(
            "SNAPSHOT",
            "label=$label connected=${snapshot.connected} health=${state.connectionHealth} rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} map=${snapshot.mapMbar ?: "--"} fuelUsedL=${snapshot.fuelUsedL?.let { String.format(Locale.US, "%.6f", it) } ?: "--"} tripDistanceKm=${snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.6f", it) } ?: "--"}"
        )
    }

    private fun dynamic026NegativeResponseCode(response: String): Int? {
        extractKwpFrames(response).forEach { frame ->
            if (frame.size >= 3) {
                for (index in 0..frame.size - 3) {
                    if (frame[index] == 0x7F && frame.getOrNull(index + 1) == 0x21) {
                        return frame.getOrNull(index + 2)
                    }
                }
            }
        }
        return null
    }

    private fun dynamic026ChecksumValid(frame: List<Int>): Boolean? {
        if (frame.size < 5) return null
        val expected = frame.last() and 0xFF
        val calculated = frame.dropLast(1).fold(0) { acc, value -> (acc + value) and 0xFF }
        return calculated == expected
    }

    private fun dynamic026LengthValid(frame: List<Int>): Boolean? {
        if (frame.size < 5) return null
        val payloadLength = frame.first() and 0x3F
        return frame.size == payloadLength + 4
    }

    private fun appendDynamic026Response(
        phase: String,
        pass: Int,
        module: Int,
        identifier: Int,
        response: String,
        priority: Boolean
    ) {
        val positive = positiveKwpResponse(response, module, 0x61, identifier)
        val snapshot = state.snapshot
        val nrc = dynamic026NegativeResponseCode(response)
        appendDynamic026(
            "BLOCK",
            "phase=$phase pass=$pass module=0x${module.hex2()} id=21${identifier.hex2()} priority=$priority positive=$positive nrc=${nrc?.hex2() ?: "--"} rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} response=$response"
        )
        val extractedFrames = extractKwpFrames(response)
        val positiveFrame = extractedFrames.firstOrNull { candidate ->
            val serviceIndex = when {
                candidate.size >= 4 && candidate[1] == 0xF1 && candidate[2] == (module and 0xFF) -> 3
                candidate.isNotEmpty() && candidate[0] == 0x61 -> 0
                else -> -1
            }
            serviceIndex >= 0 && candidate.getOrNull(serviceIndex) == 0x61 && candidate.getOrNull(serviceIndex + 1) == (identifier and 0xFF)
        }
        val negativeFrame = extractedFrames.firstOrNull { candidate ->
            val serviceIndex = when {
                candidate.size >= 4 && candidate[1] == 0xF1 && candidate[2] == (module and 0xFF) -> 3
                candidate.isNotEmpty() && candidate[0] == 0x7F -> 0
                else -> -1
            }
            serviceIndex >= 0 && candidate.getOrNull(serviceIndex) == 0x7F && candidate.getOrNull(serviceIndex + 1) == 0x21
        }
        val frame = positiveFrame ?: negativeFrame
        val payload = if (frame != null) {
            val serviceIndex = if (frame.size >= 4 && frame[1] == 0xF1 && frame[2] == (module and 0xFF)) 3 else 0
            val checksumBytes = if (serviceIndex == 3 && frame.size > serviceIndex + 2) 1 else 0
            frame.drop(serviceIndex + 2).dropLast(checksumBytes.coerceAtMost(frame.size - serviceIndex - 2))
        } else emptyList()
        val known = identifier in dynamic026KnownIds(module)
        val classification = when {
            positive && known -> "POSITIVE_KNOWN"
            positive -> "POSITIVE_NEW"
            nrc == 0x22 -> "CONDITIONS_NOT_CORRECT"
            nrc == 0x33 -> "SECURITY_BLOCKED"
            nrc != null -> "NEGATIVE_NRC_${nrc.hex2()}"
            else -> "NO_VALID_FRAME"
        }
        val json = JSONObject()
            .put("timestamp_ms", timeSource.now().epochMs ?: System.currentTimeMillis())
            .put("group_id", dynamic026GroupId)
            .put("test_name", dynamic026ActiveName ?: JSONObject.NULL)
            .put("mode", dynamic026Mode?.name ?: JSONObject.NULL)
            .put("phase", phase)
            .put("pass", pass)
            .put("module_hex", module.hex2())
            .put("local_id_hex", identifier.hex2())
            .put("priority_candidate", priority)
            .put("known_preparation_profile", known)
            .put("classification", classification)
            .put("positive", positive)
            .put("nrc_hex", nrc?.hex2() ?: JSONObject.NULL)
            .put("payload_hex", payload.joinToString(" ") { it.hex2() })
            .put("raw_response", response)
            .put("checksum_valid", frame?.let(::dynamic026ChecksumValid) ?: JSONObject.NULL)
            .put("length_valid", frame?.let(::dynamic026LengthValid) ?: JSONObject.NULL)
            .put("rpm", snapshot.rpm ?: JSONObject.NULL)
            .put("speed_kmh", snapshot.speedKmh ?: JSONObject.NULL)
            .put("coolant_c", snapshot.engineTempC ?: JSONObject.NULL)
            .put("trip_distance_km", snapshot.tripDistanceKm ?: JSONObject.NULL)
            .put("segment_distance_km", dynamic026CurrentDriveDistanceKm())
            .put("live_context_captured_elapsed_ms", lastLiveContextCapturedElapsedMs.takeIf { it > 0L } ?: JSONObject.NULL)
            .put("live_context_age_ms", if (lastLiveContextCapturedElapsedMs > 0L) (SystemClock.elapsedRealtime() - lastLiveContextCapturedElapsedMs).coerceAtLeast(0L) else JSONObject.NULL)
            .put("live_context_source", "nearest_main_poll_snapshot")
        runCatching {
            synchronized(this) { dynamic026ResearchFile?.appendText(json.toString() + "\n") }
        }
    }

    private fun dynamic026CurrentDriveDistanceKm(): Double {
        val tripBased = dynamic026DriveStartDistanceKm?.let { start ->
            state.snapshot.tripDistanceKm?.let { current -> (current - start).coerceAtLeast(0.0) }
        }
        return maxOf(tripBased ?: 0.0, dynamic026DriveAccumulatedKm)
    }

    private suspend fun performDynamic026Scan(
        out: OutputStream,
        input: InputStream,
        generation: Long,
        connectionAddress: String,
        sessionId: Long?,
        request: Dynamic026ScanRequest
    ) {
        if (dynamic026ScanInProgress || !isKwp026DeveloperTest(state.activeDeveloperTest)) return
        ensureDynamic026ScanActive(generation, connectionAddress)
        dynamic026ScanRequest = null
        dynamic026ScanInProgress = true
        appendDynamic026("PHASE_BEGIN", "phase=${request.phase} passes=${request.repeatPasses} research=${request.includeResearchBlocks} full=${request.fullDiscovery}")
        appendDynamic026Snapshot("${request.phase}_BEGIN")
        sqlStore.insertEvent(sessionId, "DYNAMIC_026_PHASE", dynamic026ActiveName ?: KWP_026_DYNAMIC_TEST_NAME, request.phase)
        val modules = listOf(0x26, 0x7A)
        val totalRequests = request.repeatPasses * modules.sumOf { dynamic026ModuleIds(it, request).size }
        var completedRequests = 0
        val progressRange = dynamic026ProgressRange(request.phase)
        try {
            for (pass in 1..request.repeatPasses) {
                for (module in modules) {
                    ensureDynamic026ScanActive(generation, connectionAddress)
                    val configured = configureDynamic026Target(
                        out,
                        input,
                        module,
                        generation,
                        connectionAddress,
                        "${request.phase}_PASS_$pass"
                    )
                    val ids = dynamic026ModuleIds(module, request)
                    if (!configured) {
                        appendDynamic026("MODULE_UNAVAILABLE", "phase=${request.phase} pass=$pass module=0x${module.hex2()} profile=${request.profile.name}")
                        if (module == 0x26 && request.profile != Dynamic026ScanProfile.RESEARCH) {
                            dynamic026ScanRequest = request
                            throw IOException("0x26 BUS INIT başarısız; hedefli test duraklatıldı")
                        }
                        completedRequests += ids.size
                        continue
                    }
                    for (identifier in ids) {
                        ensureDynamic026ScanActive(generation, connectionAddress)
                        val command = "21${identifier.hex2()}"
                        val response = send(out, input, command, 20L, 750L)
                        completedRequests++
                        appendDynamic026Response(
                            phase = request.phase,
                            pass = pass,
                            module = module,
                            identifier = identifier,
                            response = response,
                            priority = isDynamic026Priority(module, identifier)
                        )
                        val fraction = completedRequests.toDouble() / totalRequests.coerceAtLeast(1).toDouble()
                        val percent = progressRange.first + ((progressRange.last - progressRange.first) * fraction).toInt()
                        updateDynamic026Progress(
                            percent = percent,
                            phase = dynamic026PhaseTitle(request.phase),
                            detail = "Tur $pass/${request.repeatPasses} • 0x${module.hex2()} / 21${identifier.hex2()} • $completedRequests/$totalRequests",
                            target = "0x${module.hex2()} • 21${identifier.hex2()}"
                        )
                    }
                }
            }
            appendDynamic026Snapshot("${request.phase}_END")
            appendDynamic026("PHASE_END", "phase=${request.phase} requests=$completedRequests/$totalRequests")
            onDynamic026ScanCompleted(request)
        } catch (_: Dynamic026StopSignal) {
            appendDynamic026("SCAN_STOPPED", "phase=${request.phase} reason=manual_or_state_change")
        } catch (error: Throwable) {
            appendDynamic026("SCAN_ERROR", "phase=${request.phase} type=${error::class.java.simpleName} message=${error.message ?: "--"}")
            if (isKwp026DeveloperTest(state.activeDeveloperTest) && !dynamic026StopRequested) {
                dynamic026ScanRequest = request
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "OBD bağlantısı kesildi • tarama duraklatıldı",
                        developerTestRemainingSec = null,
                        developerTestProgressText = "Tamamlanan okumalar korundu. Yeniden bağlanınca aynı aşama otomatik tekrar denenecek.",
                        developerTestCurrentTarget = null
                    )
                }
            }
            throw error
        } finally {
            restoreEngineDynamic026BestEffort(out, input, generation, connectionAddress, "${request.phase}_FINALLY")
            parser.resetRuntimeState()
            dynamic026ScanInProgress = false
        }
    }

    private suspend fun onDynamic026ScanCompleted(request: Dynamic026ScanRequest) {
        dynamic026ConditionSinceMs = null
        dynamic026StageEnteredElapsedMs = SystemClock.elapsedRealtime()
        if (dynamic026GuidedSteps.isNotEmpty() && dynamic026GuidedSteps.getOrNull(dynamic026GuidedStepIndex)?.phase == request.phase) {
            dynamic026GuidedStepIndex++
            if (dynamic026GuidedStepIndex >= dynamic026GuidedSteps.size) {
                completeDynamic026Test("COMPLETED", "Tüm yönlendirmeli adımlar ve karşılaştırma okumaları tamamlandı")
            } else {
                withMain { beginDynamic026GuidedStep() }
            }
            return
        }
        if (request.completeAfterScan) {
            completeDynamic026Test("COMPLETED", "${dynamic026PhaseTitle(request.phase)} başarıyla tamamlandı")
            return
        }
        when (request.phase) {
            "ENGINE_IDLE" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_2000_RPM
                persistDynamic026Checkpoint("WAITING_FOR_2000_RPM", 52)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "2000 rpm doğrulaması",
                        developerTestRemainingSec = null,
                        developerTestProgressText = "Araç boşta ve sabitken 1800–2200 rpm aralığını 8 saniye koru",
                        developerTestProgressPercent = 52,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "RPM_2000", "WIDE_RPM_2000" -> completeDynamic026Test("COMPLETED", "Rölanti ve 2000 rpm karşılaştırması tamamlandı")
            "WIDE_IDLE_DISCOVERY" -> completeDynamic026Test("COMPLETED", "Motor rölantide tam 2100–21FF araştırma taraması tamamlandı")
            "DRIVE_BASELINE", "WIDE_DRIVE_BASELINE", "FUEL_DRIVE_BASELINE" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_MOTION
                persistDynamic026Checkpoint("WAITING_FOR_MOTION", 15)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "Güvenli sürüşe başla",
                        developerTestProgressText = "Hız 10 km/saati geçince ilk hareket ölçümü otomatik alınacak; telefonla ilgilenme",
                        developerTestProgressPercent = 15,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "DRIVE_MOTION", "WIDE_DRIVE_MOTION", "FUEL_DRIVE_MOTION" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_500M
                persistDynamic026Checkpoint("WAITING_FOR_500M", 30)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "500 metre ölçümü bekleniyor",
                        developerTestProgressText = "Sürüşe normal şekilde devam et • ${String.format(Locale.US, "%.2f", dynamic026CurrentDriveDistanceKm())} km",
                        developerTestProgressPercent = 30,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "DRIVE_500M", "WIDE_DRIVE_500M", "FUEL_DRIVE_500M" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_2KM
                persistDynamic026Checkpoint("WAITING_FOR_2KM", 50)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "2 kilometre ölçümü bekleniyor",
                        developerTestProgressText = "Sürüşe normal şekilde devam et • ${String.format(Locale.US, "%.2f", dynamic026CurrentDriveDistanceKm())} km",
                        developerTestProgressPercent = 50,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "DRIVE_2KM" -> completeDynamic026Test("COMPLETED", "Hareket, 500 metre ve 2 kilometre ölçümleri tamamlandı")
            "FUEL_DRIVE_2KM" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_5KM
                persistDynamic026Checkpoint("FUEL_WAITING_FOR_5KM", 76)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "5 kilometre yakıt doğrulaması",
                        developerTestProgressText = "Normal sürüşe devam et; 5 km noktasında son hareket ölçümü otomatik alınacak",
                        developerTestProgressPercent = 76,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "FUEL_DRIVE_5KM" -> completeDynamic026Test("COMPLETED", "Yakıt sonrası hareket, 500 m, 2 km ve 5 km ölçümleri tamamlandı")
            "WIDE_DRIVE_2KM" -> {
                dynamic026Stage = Dynamic026Stage.WAITING_FOR_5KM
                persistDynamic026Checkpoint("WAITING_FOR_5KM", 76)
                withMain {
                    state = state.copy(
                        developerTestPhaseText = "5 kilometre son ölçümü bekleniyor",
                        developerTestProgressText = "Geniş araştırma için 5 km'ye kadar normal sürüşe devam et",
                        developerTestProgressPercent = 76,
                        developerTestCurrentTarget = null
                    )
                }
            }
            "WIDE_DRIVE_5KM" -> completeDynamic026Test("COMPLETED", "Geniş sürüş taraması 10 km/sa, 500 m, 2 km ve 5 km noktalarında tamamlandı")
        }
    }

    private fun recoverActiveDynamic026IfRpmMissing(now: Long, rpm: Int) {
        val mode = dynamic026Mode ?: return
        if (!dynamic026EngineRequired(mode) || dynamic026ScanInProgress || dynamic026StopRequested) {
            dynamic026MissingRpmSinceMs = null
            return
        }
        if (rpm >= 500) {
            dynamic026MissingRpmSinceMs = null
            dynamic026ActiveReconnectAttempts = 0
            return
        }
        val since = dynamic026MissingRpmSinceMs ?: now.also { dynamic026MissingRpmSinceMs = it }
        if (now - since < DYNAMIC_026_MISSING_RPM_RECOVERY_MS) return
        if (dynamic026ActiveReconnectJob?.isActive == true) return
        if (dynamic026ActiveReconnectAttempts >= DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS) {
            state = state.copy(
                developerTestPhaseText = "RPM alınamadı • test duraklatıldı",
                developerTestRemainingSec = null,
                developerTestProgressText = "İki otomatik OBD yenilemesi sonuç vermedi. Motor çalışıyorsa OBD Bağlantısını Kes/Bağla yapın; aynı aşama kaldığı yerden devam eder.",
                status = "Aktif testte RPM alınamadı"
            )
            return
        }
        val address = state.selectedAddress ?: return
        dynamic026ActiveReconnectAttempts++
        dynamic026MissingRpmSinceMs = now
        if (dynamic026Stage == Dynamic026Stage.GUIDED_COUNTDOWN) {
            dynamic026GuidedStepStartedMs = now
        }
        dynamic026ConditionSinceMs = now
        val attempt = dynamic026ActiveReconnectAttempts
        appendDynamic026("AUTO_OBD_REFRESH", "reason=rpm_missing attempt=$attempt/$DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS stage=${dynamic026Stage.name}")
        state = state.copy(
            developerTestPhaseText = "RPM gelmedi • OBD otomatik yenileniyor",
            developerTestRemainingSec = null,
            developerTestProgressText = "Marş sonrası eski KWP oturumu kapatılıyor. Yeniden bağlanınca aynı adım otomatik devam edecek.",
            connectionHealth = ObdConnectionHealth.RECONNECTING,
            status = "Test için OBD yeniden bağlanıyor"
        )
        dynamic026ActiveReconnectJob = scope.launch {
            disconnect(silent = true, recordTripStop = false, stopBackgroundService = false)
            delay(DEVELOPER_TEST_RECONNECT_DELAY_MS)
            if (isKwp026DeveloperTest(state.activeDeveloperTest) && state.selectedAddress == address) {
                connect(address, autoReconnectAttempt = true)
            }
            delay(DEVELOPER_TEST_RECONNECT_WAIT_MS)
            dynamic026ActiveReconnectJob = null
        }
    }

    private suspend fun advanceDynamic026FromSnapshot(snapshot: DashboardSnapshot) {
        if (!isKwp026DeveloperTest(state.activeDeveloperTest)) return
        val now = SystemClock.elapsedRealtime()
        val rpm = snapshot.rpm ?: 0
        val speed = snapshot.speedKmh ?: 0
        recoverActiveDynamic026IfRpmMissing(now, rpm)
        if (dynamic026Mode == Dynamic026Mode.DRIVE || dynamic026Mode == Dynamic026Mode.WIDE_DRIVE || dynamic026Mode == Dynamic026Mode.FUEL_DRIVE) {
            val previous = dynamic026DriveLastElapsedMs
            if (previous != null && speed > 0) {
                val deltaHours = ((now - previous).coerceIn(0L, 5_000L)).toDouble() / 3_600_000.0
                dynamic026DriveAccumulatedKm += speed.toDouble() * deltaHours
            }
            dynamic026DriveLastElapsedMs = now
        }
        if (dynamic026ScanInProgress || dynamic026ScanRequest != null) return

        when (dynamic026Stage) {
            Dynamic026Stage.GUIDED_COUNTDOWN -> {
                val step = dynamic026GuidedSteps.getOrNull(dynamic026GuidedStepIndex) ?: return
                val validEngine = !step.requireEngineRunning || rpm >= 500
                val validStationary = !step.requireStationary || speed <= 2
                val validMinimumSpeed = speed >= step.minimumSpeedKmh
                if (!validEngine || !validStationary || !validMinimumSpeed) {
                    dynamic026GuidedStepStartedMs = now
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = step.seconds,
                            developerTestProgressText = buildString {
                                append(step.instruction)
                                if (!validEngine) append(" • RPM bekleniyor: $rpm")
                                if (!validStationary) append(" • Araç durmalı: $speed km/sa")
                                if (!validMinimumSpeed) append(" • Hareket bekleniyor: en az ${step.minimumSpeedKmh} km/sa")
                            }
                        )
                    }
                } else {
                    val elapsed = ((now - dynamic026GuidedStepStartedMs).coerceAtLeast(0L) / 1000L).toInt()
                    val remaining = (step.seconds - elapsed).coerceAtLeast(0)
                    withMain {
                        val handbrake = dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE
                        state = state.copy(
                            developerTestPhaseText = if (handbrake) "Hazırlan • Adım ${dynamic026GuidedStepIndex + 1}/${dynamic026GuidedSteps.size}" else state.developerTestPhaseText,
                            developerTestRemainingSec = remaining,
                            developerTestProgressText = if (handbrake) {
                                "${handbrakeSafetyLine()}\n${step.instruction}\n$remaining saniye sonra 3 ölçüm turu başlayacak."
                            } else {
                                "${step.instruction} • $remaining sn"
                            },
                            developerTestStageLabel = if (handbrake) "HAZIRLAN" else state.developerTestStageLabel
                        )
                    }
                    if (remaining <= 0) {
                        dynamic026Stage = Dynamic026Stage.SCAN
                        withMain {
                            val handbrake = dynamic026Mode == Dynamic026Mode.CONTROL_HANDBRAKE
                            state = state.copy(
                                developerTestPhaseText = if (handbrake) "Ölçüm • Adım ${dynamic026GuidedStepIndex + 1}/${dynamic026GuidedSteps.size}" else state.developerTestPhaseText,
                                developerTestRemainingSec = null,
                                developerTestProgressText = if (handbrake) {
                                    "${handbrakeSafetyLine()}\n${step.instruction}\nKONUMU DEĞİŞTİRME • 3 ölçüm turu alınıyor."
                                } else {
                                    "${step.instruction} • Konumu değiştirme; hedefli ölçüm alınıyor"
                                },
                                developerTestStageLabel = if (handbrake) "ÖLÇÜM" else state.developerTestStageLabel
                            )
                        }
                        dynamic026ScanRequest = Dynamic026ScanRequest(
                            phase = step.phase,
                            repeatPasses = step.repeatPasses,
                            includeResearchBlocks = false,
                            completeAfterScan = false,
                            profile = step.profile
                        )
                    }
                }
            }
            Dynamic026Stage.IDLE_STABILIZING -> {
                if (rpm < 500 || speed > 2) {
                    dynamic026ConditionSinceMs = now
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = DYNAMIC_026_IDLE_STABLE_SEC,
                            developerTestProgressText = "Araç sabit ve motor rölantide olmalı • algılanan RPM: $rpm • hız: $speed km/sa"
                        )
                    }
                } else {
                    val elapsed = ((now - (dynamic026ConditionSinceMs ?: now)) / 1000L).toInt()
                    val remaining = (DYNAMIC_026_IDLE_STABLE_SEC - elapsed).coerceAtLeast(0)
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = remaining,
                            developerTestProgressText = "Rölanti algılandı: $rpm rpm • taramaya $remaining sn"
                        )
                    }
                    if (remaining <= 0) {
                        dynamic026Stage = Dynamic026Stage.SCAN
                        val wide = dynamic026Mode == Dynamic026Mode.WIDE_IDLE
                        dynamic026ScanRequest = Dynamic026ScanRequest(
                            phase = if (wide) "WIDE_IDLE_DISCOVERY" else "ENGINE_IDLE",
                            repeatPasses = if (wide) 1 else 2,
                            includeResearchBlocks = true,
                            fullDiscovery = wide,
                            completeAfterScan = false
                        )
                    }
                }
            }
            Dynamic026Stage.WAITING_FOR_2000_RPM -> {
                withMain {
                    state = state.copy(
                        developerTestProgressText = "Algılanan RPM: $rpm • hız: $speed km/sa • 1800–2200 rpm aralığını yakala"
                    )
                }
                if (rpm in 1800..2200 && speed <= 2) {
                    dynamic026Stage = Dynamic026Stage.RPM2000_STABILIZING
                    dynamic026ConditionSinceMs = now
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = DYNAMIC_026_RPM_STABLE_SEC,
                            developerTestProgressText = "1800–2200 rpm aralığını koru"
                        )
                    }
                }
            }
            Dynamic026Stage.RPM2000_STABILIZING -> {
                if (rpm !in 1800..2200 || speed > 2) {
                    dynamic026Stage = Dynamic026Stage.WAITING_FOR_2000_RPM
                    dynamic026ConditionSinceMs = null
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = null,
                            developerTestProgressText = "Aralık kaybedildi • algılanan RPM: $rpm • yeniden 1800–2200 rpm yap"
                        )
                    }
                } else {
                    val elapsed = ((now - (dynamic026ConditionSinceMs ?: now)) / 1000L).toInt()
                    val remaining = (DYNAMIC_026_RPM_STABLE_SEC - elapsed).coerceAtLeast(0)
                    withMain {
                        state = state.copy(
                            developerTestRemainingSec = remaining,
                            developerTestProgressText = "$rpm rpm algılandı • $remaining sn daha koru"
                        )
                    }
                    if (remaining <= 0) {
                        dynamic026Stage = Dynamic026Stage.SCAN
                        val wide = dynamic026Mode == Dynamic026Mode.WIDE_RPM
                        dynamic026ScanRequest = Dynamic026ScanRequest(
                            phase = if (wide) "WIDE_RPM_2000" else "RPM_2000",
                            repeatPasses = 2,
                            includeResearchBlocks = true,
                            fullDiscovery = false,
                            completeAfterScan = false
                        )
                    }
                }
            }
            Dynamic026Stage.WAITING_FOR_MOTION -> {
                withMain {
                    state = state.copy(
                        developerTestProgressText = "Hız: $speed km/sa • mesafe: ${String.format(Locale.US, "%.2f", dynamic026CurrentDriveDistanceKm())} km"
                    )
                }
                if (rpm >= 500 && speed >= 10) {
                    dynamic026Stage = Dynamic026Stage.SCAN
                    val phase = when (dynamic026Mode) {
                        Dynamic026Mode.WIDE_DRIVE -> "WIDE_DRIVE_MOTION"
                        Dynamic026Mode.FUEL_DRIVE -> "FUEL_DRIVE_MOTION"
                        else -> "DRIVE_MOTION"
                    }
                    val profile = if (dynamic026Mode == Dynamic026Mode.FUEL_DRIVE) Dynamic026ScanProfile.FUEL_REFILL else Dynamic026ScanProfile.RESEARCH
                    dynamic026ScanRequest = Dynamic026ScanRequest(phase, 1, dynamic026Mode != Dynamic026Mode.FUEL_DRIVE, profile = profile)
                }
            }
            Dynamic026Stage.WAITING_FOR_500M -> {
                val distance = dynamic026CurrentDriveDistanceKm()
                withMain { state = state.copy(developerTestProgressText = "500 m hedefi • ${String.format(Locale.US, "%.2f", distance)} km") }
                if (distance >= 0.5) {
                    dynamic026Stage = Dynamic026Stage.SCAN
                    val phase = when (dynamic026Mode) {
                        Dynamic026Mode.WIDE_DRIVE -> "WIDE_DRIVE_500M"
                        Dynamic026Mode.FUEL_DRIVE -> "FUEL_DRIVE_500M"
                        else -> "DRIVE_500M"
                    }
                    val profile = if (dynamic026Mode == Dynamic026Mode.FUEL_DRIVE) Dynamic026ScanProfile.FUEL_REFILL else Dynamic026ScanProfile.RESEARCH
                    dynamic026ScanRequest = Dynamic026ScanRequest(phase, 1, dynamic026Mode != Dynamic026Mode.FUEL_DRIVE, profile = profile)
                }
            }
            Dynamic026Stage.WAITING_FOR_2KM -> {
                val distance = dynamic026CurrentDriveDistanceKm()
                withMain { state = state.copy(developerTestProgressText = "2 km hedefi • ${String.format(Locale.US, "%.2f", distance)} km") }
                if (distance >= 2.0) {
                    dynamic026Stage = Dynamic026Stage.SCAN
                    val phase = when (dynamic026Mode) {
                        Dynamic026Mode.WIDE_DRIVE -> "WIDE_DRIVE_2KM"
                        Dynamic026Mode.FUEL_DRIVE -> "FUEL_DRIVE_2KM"
                        else -> "DRIVE_2KM"
                    }
                    val profile = if (dynamic026Mode == Dynamic026Mode.FUEL_DRIVE) Dynamic026ScanProfile.FUEL_REFILL else Dynamic026ScanProfile.RESEARCH
                    dynamic026ScanRequest = Dynamic026ScanRequest(phase, 1, dynamic026Mode != Dynamic026Mode.FUEL_DRIVE, profile = profile)
                }
            }
            Dynamic026Stage.WAITING_FOR_5KM -> {
                val distance = dynamic026CurrentDriveDistanceKm()
                withMain { state = state.copy(developerTestProgressText = "5 km hedefi • ${String.format(Locale.US, "%.2f", distance)} km") }
                if (distance >= 5.0) {
                    dynamic026Stage = Dynamic026Stage.SCAN
                    if (dynamic026Mode == Dynamic026Mode.FUEL_DRIVE) {
                        dynamic026ScanRequest = Dynamic026ScanRequest("FUEL_DRIVE_5KM", 1, false, profile = Dynamic026ScanProfile.FUEL_REFILL)
                    } else {
                        dynamic026ScanRequest = Dynamic026ScanRequest("WIDE_DRIVE_5KM", 1, true)
                    }
                }
            }
            else -> Unit
        }
    }

    private fun dynamic026QuickAnalysis(): String {
        val file = dynamic026ResearchFile
        if (file == null || !file.exists()) return JSONObject().put("status", "NO_RESEARCH_DATA").toString(2)
        val groups = linkedMapOf<String, MutableList<JSONObject>>()
        file.useLines { lines ->
            lines.filter { it.isNotBlank() }.forEach { line ->
                runCatching { JSONObject(line) }.getOrNull()?.let { obj ->
                    val key = "${obj.optString("module_hex")}/21${obj.optString("local_id_hex")}"
                    groups.getOrPut(key) { mutableListOf() }.add(obj)
                }
            }
        }
        val candidates = JSONArray()
        groups.forEach { (key, records) ->
            val positiveRecords = records.filter { it.optBoolean("positive", false) }
            val payloads = positiveRecords.map { it.optString("payload_hex") }.filter { it.isNotBlank() }.distinct()
            val classifications = records.map { it.optString("classification") }.distinct()
            if (positiveRecords.isNotEmpty() || classifications.any { it == "CONDITIONS_NOT_CORRECT" || it == "SECURITY_BLOCKED" }) {
                candidates.put(
                    JSONObject()
                        .put("block", key)
                        .put("reads", records.size)
                        .put("positive_reads", positiveRecords.size)
                        .put("distinct_payload_count", payloads.size)
                        .put("changed_within_segment", payloads.size > 1)
                        .put("classifications", JSONArray(classifications))
                        .put("priority", records.any { it.optBoolean("priority_candidate", false) })
                )
            }
        }
        return JSONObject()
            .put("schema", "loganos_dynamic_026_quick_analysis_v2")
            .put("group_id", dynamic026GroupId)
            .put("test_name", dynamic026ActiveName ?: JSONObject.NULL)
            .put("mode", dynamic026Mode?.name ?: JSONObject.NULL)
            .put("candidate_count", candidates.length())
            .put("candidates", candidates)
            .put("note", "Bu hızlı sınıflandırma yalnız aynı bağımsız bölüm içindeki değişimleri gösterir; veri adı doğrulaması değildir")
            .toString(2)
    }

    private fun handbrakeCandidateAnalysis(): String {
        if (dynamic026Mode != Dynamic026Mode.CONTROL_HANDBRAKE) {
            return JSONObject().put("status", "NOT_HANDBRAKE_TEST").toString(2)
        }
        val file = dynamic026ResearchFile
        if (file == null || !file.exists()) {
            return JSONObject().put("status", "NO_RESEARCH_DATA").toString(2)
        }
        val grouped = linkedMapOf<String, MutableMap<String, MutableList<List<Int>>>>()
        file.useLines { lines ->
            lines.filter { it.isNotBlank() }.forEach { line ->
                val obj = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
                if (!obj.optBoolean("positive", false)) return@forEach
                val phase = obj.optString("phase")
                if (!phase.startsWith("HANDBRAKE_")) return@forEach
                val payload = obj.optString("payload_hex")
                    .trim()
                    .split(Regex("\\s+"))
                    .mapNotNull { token -> token.toIntOrNull(16) }
                if (payload.isEmpty()) return@forEach
                val block = "${obj.optString("module_hex")}/21${obj.optString("local_id_hex")}" 
                grouped.getOrPut(block) { linkedMapOf() }
                    .getOrPut(phase) { mutableListOf() }
                    .add(payload)
            }
        }

        data class Candidate(
            val block: String,
            val byteIndex: Int,
            val bit: Int,
            val onState: Int,
            val offState: Int,
            val phaseCoverage: Int,
            val sampleCount: Int,
            val confidence: Double
        )

        fun phaseBitMajority(samples: List<List<Int>>, byteIndex: Int, bit: Int): Pair<Int, Double>? {
            val values = samples.mapNotNull { bytes -> bytes.getOrNull(byteIndex)?.let { (it shr bit) and 1 } }
            if (values.isEmpty()) return null
            val ones = values.count { it == 1 }
            val zeros = values.size - ones
            val majority = if (ones >= zeros) 1 else 0
            val confidence = maxOf(ones, zeros).toDouble() / values.size.toDouble()
            return majority to confidence
        }

        val candidates = mutableListOf<Candidate>()
        grouped.forEach { (block, phases) ->
            val maxBytes = phases.values.flatten().maxOfOrNull { it.size } ?: 0
            for (byteIndex in 0 until maxBytes) {
                for (bit in 0..7) {
                    val on = phases.filterKeys { it.startsWith("HANDBRAKE_ON_") }
                        .mapNotNull { (_, samples) -> phaseBitMajority(samples, byteIndex, bit) }
                    val off = phases.filterKeys { it.startsWith("HANDBRAKE_OFF_") }
                        .mapNotNull { (_, samples) -> phaseBitMajority(samples, byteIndex, bit) }
                    if (on.size < 2 || off.size < 2) continue
                    val onStates = on.map { it.first }.distinct()
                    val offStates = off.map { it.first }.distinct()
                    if (onStates.size != 1 || offStates.size != 1 || onStates.first() == offStates.first()) continue
                    val sampleCount = phases.values.flatten().count { it.size > byteIndex }
                    val confidence = (on.map { it.second } + off.map { it.second }).average()
                    candidates += Candidate(
                        block = block,
                        byteIndex = byteIndex,
                        bit = bit,
                        onState = onStates.first(),
                        offState = offStates.first(),
                        phaseCoverage = on.size + off.size,
                        sampleCount = sampleCount,
                        confidence = confidence
                    )
                }
            }
        }

        val sorted = candidates.sortedWith(
            compareByDescending<Candidate> { it.phaseCoverage }
                .thenByDescending { it.confidence }
                .thenByDescending { it.sampleCount }
                .thenBy { it.block }
                .thenBy { it.byteIndex }
                .thenBy { it.bit }
        )
        val jsonCandidates = JSONArray()
        sorted.forEach { item ->
            jsonCandidates.put(
                JSONObject()
                    .put("block", item.block)
                    .put("byte_index_zero_based", item.byteIndex)
                    .put("bit", item.bit)
                    .put("handbrake_on_state", item.onState)
                    .put("handbrake_off_state", item.offState)
                    .put("phase_coverage", item.phaseCoverage)
                    .put("sample_count", item.sampleCount)
                    .put("confidence", item.confidence)
            )
        }
        return JSONObject()
            .put("schema", "loganos_handbrake_candidate_analysis_v1")
            .put("status", if (sorted.isEmpty()) "NO_STABLE_CANDIDATE" else "CANDIDATES_FOUND")
            .put("candidate_count", sorted.size)
            .put("candidates", jsonCandidates)
            .put("note", "Sonuçlar yalnız çekili/indirilmiş adımlar arasında kararlı değişen bit adaylarıdır; kesin el freni sinyali sayılmaz. Ham JSONL ile doğrulanmalıdır.")
            .toString(2)
    }

    private fun dynamic026Manifest(status: String, note: String): String = JSONObject()
        .put("schema", "loganos_dynamic_026_segmented_validation_v2")
        .put("version", BuildConfig.VERSION_NAME)
        .put("group_id", dynamic026GroupId)
        .put("test_name", dynamic026ActiveName ?: JSONObject.NULL)
        .put("mode", dynamic026Mode?.name ?: JSONObject.NULL)
        .put("scan_profile", dynamic026ProfileForMode(dynamic026Mode).name)
        .put("fuel_added_liters", dynamic026GroupPrefs.getString(KEY_FUEL_REFILL_LITERS, null) ?: JSONObject.NULL)
        .put("status", status)
        .put("note", note)
        .put("elapsed_seconds", dynamic026ElapsedSec())
        .put("priority_blocks", JSONObject()
            .put("0x26", JSONArray(listOf("21D0", "21DC", "21DD", "21DE", "21D8", "21D9")))
            .put("0x7A", JSONArray(listOf("2191", "21A0", "21A2", "21A7", "21A8"))))
        .put("research_blocks", JSONObject()
            .put("0x26", JSONArray(listOf("2194", "21D0", "21D1", "21DB", "21DC", "21DD", "21DE", "21D8", "21D9")))
            .put("0x7A", JSONArray(listOf("2191", "21A0", "21A1", "21A2", "21A4", "21A5", "21A6", "21A7", "21A8", "21A9", "21AE", "21CC", "21CD", "21CE", "21CF"))))
        .put("wide_scan", dynamic026Mode?.let { mode -> mode in setOf(Dynamic026Mode.WIDE_KOEO, Dynamic026Mode.WIDE_IDLE, Dynamic026Mode.WIDE_RPM, Dynamic026Mode.WIDE_DRIVE, Dynamic026Mode.WIDE_POST) } == true)
        .put("authoritative_attempt", status == "COMPLETED")
        .put("partial_or_degraded", status != "COMPLETED")
        .put("live_context_schema", JSONObject()
            .put("captured_elapsed_ms", true)
            .put("age_ms", true)
            .put("source", "nearest_main_poll_snapshot"))
        .put("safety", JSONObject()
            .put("read_only", true)
            .put("excluded_0x26_21A2_security_protected", true)
            .put("blocked_services", JSONArray(listOf("14", "27", "2E", "31", "34", "36", "3B"))))
        .toString(2)

    private suspend fun completeDynamic026Test(status: String, note: String) {
        if (dynamic026Stage == Dynamic026Stage.IDLE && !isKwp026DeveloperTest(state.activeDeveloperTest)) return
        val completedName = dynamic026ActiveName ?: state.activeDeveloperTest ?: KWP_026_DYNAMIC_TEST_NAME
        val completedMode = dynamic026Mode
        dynamic026Stage = Dynamic026Stage.COMPLETED
        dynamic026ScanRequest = null
        appendDynamic026("TEST_COMPLETE", "status=$status note=$note")
        appendDynamic026Snapshot("FINAL")
        val rawFile = dynamic026WorkingFile
        val researchFile = dynamic026ResearchFile
        val groupDir = dynamic026GroupDirectory(dynamic026GroupId.ifBlank { "unknown" })
        val analysisFile = File(groupDir, "${dynamic026ModeTag(completedMode)}_quick_analysis_${trustedFileStamp()}.json").apply {
            writeText(dynamic026QuickAnalysis())
        }
        val manifestFile = File(groupDir, "${dynamic026ModeTag(completedMode)}_manifest_${trustedFileStamp()}.json").apply {
            writeText(dynamic026Manifest(status, note))
        }
        val handbrakeAnalysisFile = if (completedMode == Dynamic026Mode.CONTROL_HANDBRAKE) {
            File(groupDir, "control_handbrake_candidates_${trustedFileStamp()}.json").apply {
                writeText(handbrakeCandidateAnalysis())
            }
        } else null
        val fileName = "loganos_dynamic_026_${dynamic026ModeTag(completedMode)}_${dynamic026GroupId}_v${safeVersionTag()}_${trustedFileStamp()}.zip"
        val archiveBytes = ByteArrayOutputStream().use { buffer ->
            ZipOutputStream(buffer).use { zip ->
                rawFile?.takeIf { it.exists() }?.let {
                    zip.putNextEntry(ZipEntry("00_dynamic_test.txt"))
                    zip.write(it.readBytes())
                    zip.closeEntry()
                }
                researchFile?.takeIf { it.exists() }?.let {
                    zip.putNextEntry(ZipEntry("01_research_blocks.jsonl"))
                    zip.write(it.readBytes())
                    zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry("02_test_manifest.json"))
                zip.write(manifestFile.readBytes())
                zip.closeEntry()
                zip.putNextEntry(ZipEntry("03_quick_analysis.json"))
                zip.write(analysisFile.readBytes())
                zip.closeEntry()
                handbrakeAnalysisFile?.takeIf { it.exists() }?.let {
                    zip.putNextEntry(ZipEntry("04_handbrake_candidates.json"))
                    zip.write(it.readBytes())
                    zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry("BENI_OKU.txt"))
                val readme = if (completedMode == Dynamic026Mode.CONTROL_HANDBRAKE) {
                    "Bu paket LoganOS içindeki yönlendirmeli el freni testine aittir. Pydroid veya pyjnius kullanılmaz. 00_dynamic_test.txt adımları, 01_research_blocks.jsonl ham 0x26/0x7A cevaplarını, 04_handbrake_candidates.json ise çekili/indirilmiş adımlarda kararlı değişen bit adaylarını içerir. Aday analizi kesin sinyal adı değildir; ham verilerle doğrulanmalıdır.\n"
                } else {
                    "Bu paket tek bir bağımsız 0x26 doğrulama/araştırma bölümünü içerir. Diğer bölümler ayrı çalıştırılır ve aynı grup kimliğiyle birleşik pakete alınabilir. 21DD/21DE yakıt adayları önceliklidir; yeni cevap veren veya koşula bağlı bloklar ham JSONL kaydında korunmuştur. Doğrulanmamış hiçbir değer kullanıcı arayüzünde kesin adla gösterilmemelidir.\n"
                }
                zip.write(readme.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            buffer.toByteArray()
        }
        val displayPath = saveBytesToDownloads(fileName, "application/zip", archiveBytes)
        sqlStore.endTestSession(activeDeveloperTestHistoryId, status, note)
        activeDeveloperTestHistoryId = null
        sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
        refreshHistoryState()
        val elapsed = dynamic026ElapsedSec()
        stopDynamic026UiTicker()
        clearDynamic026Checkpoint()
        dynamic026ScanInProgress = false
        dynamic026StopRequested = false
        dynamic026ConditionSinceMs = null
        dynamic026Stage = Dynamic026Stage.IDLE
        dynamic026Mode = null
        dynamic026ActiveName = null
        dynamic026DriveStartDistanceKm = null
        dynamic026DriveAccumulatedKm = 0.0
        dynamic026DriveLastElapsedMs = null
        dynamic026GuidedSteps = emptyList()
        dynamic026GuidedStepIndex = 0
        dynamic026GuidedStepStartedMs = 0L
        dynamic026MissingRpmSinceMs = null
        dynamic026ActiveReconnectAttempts = 0
        dynamic026ActiveReconnectJob?.cancel()
        dynamic026ActiveReconnectJob = null
        withMain {
            state = state.copy(
                activeDeveloperTest = null,
                developerTestPhaseText = "Test tamamlandı",
                developerTestRemainingSec = null,
                developerTestProgressText = if (completedMode == Dynamic026Mode.CONTROL_HANDBRAKE) {
                    "El freni adımları, ham 0x26/0x7A blokları ve kararlı bit aday analizi ZIP paketine kaydedildi"
                } else {
                    "Ham bloklar, manifest ve hızlı fark analizi ZIP paketine kaydedildi"
                },
                developerTestProgressPercent = if (status == "COMPLETED") 100 else state.developerTestProgressPercent,
                developerTestElapsedSec = elapsed,
                developerTestEstimatedRemainingSec = 0L,
                developerTestCurrentTarget = null,
                developerTestDoneMessage = if (status == "COMPLETED") {
                    "$completedName tamamlandı"
                } else {
                    "$completedName için kısmi paket oluşturuldu"
                },
                savedLogPath = displayPath,
                savedLogFileName = fileName,
                sharedLogReady = true,
                status = "$completedName sonuçları kaydedildi: $displayPath"
            )
            appendLog("[DYNAMIC_026_COMPLETE] name=$completedName status=$status path=$displayPath")
        }
        ObdForegroundService.notifyDynamic026Result(context, status == "COMPLETED", fileName)
        if (!shouldRunForegroundService(runtimeSettings)) ObdForegroundService.stop(context)
    }

    private fun finishDynamic026TestManually() {
        if (dynamic026Stage == Dynamic026Stage.IDLE || dynamic026StopRequested) return
        dynamic026StopRequested = true
        dynamic026Stage = Dynamic026Stage.COMPLETED
        dynamic026ScanRequest = null
        state = state.copy(
            developerTestPhaseText = "Kısmi 0x26 paketi hazırlanıyor",
            developerTestRemainingSec = null,
            developerTestProgressText = "Bu bağımsız bölümde şimdiye kadar okunan ham bloklar korunacak"
        )
        scope.launch {
            var waitedMs = 0L
            while (dynamic026ScanInProgress && waitedMs < DYNAMIC_026_STOP_WAIT_MS) {
                delay(50L)
                waitedMs += 50L
            }
            completeDynamic026Test("COMPLETED_MANUAL", "Kullanıcı bu bağımsız bölümü manuel bitirdi; kısmi ham blok paketi dışa aktarıldı")
        }
    }

    fun startDeveloperTest(name: String) {
        if (name == FUEL_LEVEL_DISCOVERY_TEST_NAME) {
            startFuelDiscoveryTest()
            return
        }
        if (name == KWP_026_COMBINE_RESULTS_NAME) {
            createDynamic026CombinedPackage()
            return
        }
        if (isKwp026DeveloperTest(name)) {
            startDynamic026Test(name)
            return
        }
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Test için önce OBD bağlantısı gerekli")
            appendLog("[TEST_BLOCKED] $name requires OBD connection")
            return
        }
        developerTestJob?.cancel()
        activeDeveloperTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", "Yeni test başlatıldığı için önceki test kapatıldı") }
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        activeDeveloperTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = sessionId,
                testType = "DEVELOPER",
                name = name,
                versionName = BuildConfig.VERSION_NAME,
                note = "Yönlendirmeli LoganOS testi"
            )
        } else null
        sqlStore.insertEvent(sessionId, "TEST_START", name, "Kullanıcı testi başlattı")
        state = state.copy(
            activeDeveloperTest = name,
            developerTestPhaseText = "Hazırlan",
            developerTestRemainingSec = 3,
            developerTestProgressText = null,
            developerTestProgressPercent = null,
            developerTestElapsedSec = null,
            developerTestEstimatedRemainingSec = null,
            developerTestCurrentTarget = null,
            developerTestDoneMessage = null,
            status = "Test başladı: $name"
        )
        appendLog("[TEST_START] $name")
        developerTestJob = scope.launch {
            runDeveloperTestGuide(name, sessionId)
        }
        refreshHistory()
    }

    fun finishDeveloperTest() {
        val name = state.activeDeveloperTest
        if (name == null) {
            if (state.developerTestDoneMessage != null) {
                state = state.copy(
                    developerTestDoneMessage = null,
                    developerTestPhaseText = null,
                    developerTestProgressText = null,
                    developerTestProgressPercent = null,
                    developerTestElapsedSec = null,
                    developerTestEstimatedRemainingSec = null,
                    developerTestCurrentTarget = null
                )
            }
            return
        }
        if (name == FUEL_LEVEL_DISCOVERY_TEST_NAME) {
            finishFuelDiscoveryTestManually()
            return
        }
        if (isKwp026DeveloperTest(name)) {
            finishDynamic026TestManually()
            return
        }
        developerTestJob?.cancel()
        developerTestJob = null
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "TEST_END", name, "Kullanıcı testi bitirdi")
        sqlStore.endTestSession(activeDeveloperTestHistoryId, "COMPLETED_MANUAL", "Kullanıcı testi manuel olarak bitirdi")
        activeDeveloperTestHistoryId = null
        scope.launch {
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
        }
        state = state.copy(
            activeDeveloperTest = null,
            developerTestPhaseText = null,
            developerTestRemainingSec = null,
            developerTestProgressText = null,
            developerTestProgressPercent = null,
            developerTestElapsedSec = null,
            developerTestEstimatedRemainingSec = null,
            developerTestCurrentTarget = null,
            developerTestDoneMessage = "Test bitti: $name",
            status = "Test bitti: $name"
        )
        appendLog("[TEST_END] $name")
        scope.launch { clearDeveloperTestDoneMessageLater(name) }
    }

    private suspend fun runDeveloperTestGuide(name: String, sessionId: Long?) {
        val phases = developerTestPhases(name)
        try {
            phases.forEach { phase ->
                sqlStore.insertEvent(sessionId, "TEST_PHASE", name, phase.title)
                withMain {
                    state = state.copy(
                        activeDeveloperTest = name,
                        developerTestPhaseText = phase.title,
                        developerTestRemainingSec = phase.seconds,
                        developerTestProgressText = null,
                        developerTestProgressPercent = null,
                        developerTestElapsedSec = null,
                        developerTestEstimatedRemainingSec = null,
                        developerTestCurrentTarget = null,
                        developerTestDoneMessage = null,
                        status = "Test: $name • ${phase.title}"
                    )
                    appendLog("[TEST_PHASE] $name • ${phase.title} • ${phase.seconds}s")
                }
                for (remaining in phase.seconds downTo 1) {
                    withMain {
                        if (state.activeDeveloperTest == name) {
                            state = state.copy(developerTestRemainingSec = remaining)
                        }
                    }
                    delay(1000L)
                }
            }
            sqlStore.insertEvent(sessionId, "TEST_END", name, "Otomatik geri sayım tamamlandı")
            sqlStore.endTestSession(activeDeveloperTestHistoryId, "COMPLETED", "Otomatik test adımları tamamlandı")
            activeDeveloperTestHistoryId = null
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
            withMain {
                state = state.copy(
                    activeDeveloperTest = null,
                    developerTestPhaseText = null,
                    developerTestRemainingSec = null,
                    developerTestProgressText = null,
                    developerTestProgressPercent = null,
                    developerTestElapsedSec = null,
                    developerTestEstimatedRemainingSec = null,
                    developerTestCurrentTarget = null,
                    developerTestDoneMessage = "Test bitti: $name",
                    status = "Test bitti: $name"
                )
                appendLog("[TEST_END] $name")
            }
            clearDeveloperTestDoneMessageLater(name)
        } catch (_: CancellationException) {
            // Kullanıcı testi manuel bitirdiğinde buraya düşer; log finishDeveloperTest içinde yazılır.
        }
    }

    private fun developerTestPhases(name: String): List<DeveloperTestPhase> = when (name) {
        "Benzinli soğuk çalıştırma testi" -> listOf(
            DeveloperTestPhase("Kontak açık, motor kapalı", 15),
            DeveloperTestPhase("Motoru çalıştır", 20),
            DeveloperTestPhase("Gaz vermeden rölantide bekle", 180)
        )
        "Benzinli sıcak rölanti testi" -> listOf(
            DeveloperTestPhase("Tüm yükler kapalı", 60),
            DeveloperTestPhase("Klimayı aç", 60),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Benzinli sabit devir testi" -> listOf(
            DeveloperTestPhase("Rölantide bekle", 20),
            DeveloperTestPhase("2000 rpm sabit tut", 30),
            DeveloperTestPhase("3000 rpm sabit tut", 20),
            DeveloperTestPhase("Rölantiye dön", 20)
        )
        "Benzinli hızlanma testi" -> listOf(
            DeveloperTestPhase("Güvenli sürüşe hazırlan", 20),
            DeveloperTestPhase("Hafif yükte hızlan", 30),
            DeveloperTestPhase("Orta yükte hızlan", 30),
            DeveloperTestPhase("Sabit hızda devam et", 20)
        )
        "Benzinli DFCO testi" -> listOf(
            DeveloperTestPhase("20-30 km/h üstüne çık", 25),
            DeveloperTestPhase("Viteste gazı tamamen bırak", 20),
            DeveloperTestPhase("Tekrar hafif gaz ver", 10),
            DeveloperTestPhase("İkinci kez gazı tamamen bırak", 20)
        )
        "Benzinli serbest sürüş testi" -> listOf(
            DeveloperTestPhase("Normal şehir içi sürüşe başla", 60),
            DeveloperTestPhase("Sürüşe devam et", 240)
        )
        "Sıcak rölanti testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 60),
            DeveloperTestPhase("Klimayı aç", 60),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Klima testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Elektrik/yük testi" -> listOf(
            DeveloperTestPhase("Klima kapalı kalsın; tüm yükler kapalı", 30),
            DeveloperTestPhase("Kısa farları aç; klima kapalı", 30),
            DeveloperTestPhase("Uzun/sis farlarını aç; klima kapalı", 30),
            DeveloperTestPhase("Arka rezistansı aç; klima kapalı", 30),
            DeveloperTestPhase("Kalorifer fanını aç; klima kapalı", 30),
            DeveloperTestPhase("Yükleri kapat", 20)
        )
        "Tam yük testi" -> listOf(
            DeveloperTestPhase("Tüm yükler kapalı", 30),
            DeveloperTestPhase("Farlar + sisler + rezistansı aç", 30),
            DeveloperTestPhase("Kalorifer fanını aç", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Tüm yükleri kapat", 20)
        )
        "CUTOFF testi", "Yakıt kesme (CUTOFF) testi" -> listOf(
            DeveloperTestPhase("20-30 km/h üstüne çık", 20),
            DeveloperTestPhase("Gazı tamamen bırak", 15),
            DeveloperTestPhase("Güvenli şekilde yavaşla", 10)
        )
        "Serbest sürüş testi" -> listOf(
            DeveloperTestPhase("Normal şehir içi sürüşe başla", 60),
            DeveloperTestPhase("Sürüşe devam et", 240)
        )
        else -> listOf(DeveloperTestPhase("Testi uygula", 60))
    }

    private suspend fun clearDeveloperTestDoneMessageLater(name: String) {
        delay(3000L)
        withMain {
            if (state.developerTestDoneMessage == "Test bitti: $name") {
                state = state.copy(developerTestDoneMessage = null)
            }
        }
    }

    fun setDriveHistoryPinned(id: Long, pinned: Boolean): Boolean {
        val changed = sqlStore.setTripPinned(id, pinned)
        if (changed) refreshHistory()
        return changed
    }

    fun setTestHistoryPinned(id: Long, pinned: Boolean): Boolean {
        val changed = sqlStore.setTestPinned(id, pinned)
        if (changed) refreshHistory()
        return changed
    }

    fun deleteDriveHistory(id: Long): Boolean {
        val deleted = sqlStore.deleteTripRecord(id)
        if (deleted) refreshHistory()
        return deleted
    }

    fun deleteTestHistory(id: Long): Boolean {
        val deleted = sqlStore.deleteTestRecord(id)
        if (deleted) refreshHistory()
        return deleted
    }

    fun exportDriveHistory(id: Long) {
        if (state.exportInProgress) return
        state = state.copy(exportInProgress = true, status = "Sürüş dışa aktarılıyor…")
        scope.launch {
            try {
                val text = sqlStore.exportTripRecordText(id, includeRaw = rawEcuLogEnabled)
                if (text == null) {
                    publishExportFeedback("Dışa aktarma başarısız: sürüş kaydı bulunamadı")
                    return@launch
                }
                val fileName = "loganos_drive_v${safeVersionTag()}_${trustedFileStamp()}_id${id}.txt"
                val displayPath = saveBytesToDownloads(fileName, "text/plain", text.toByteArray(Charsets.UTF_8))
                publishExportFeedback(
                    message = "Dışa aktarma tamamlandı: $fileName",
                    status = "Sürüş dışa aktarıldı: $displayPath",
                    displayPath = displayPath,
                    fileName = fileName
                )
                refreshHistoryState()
            } catch (t: Throwable) {
                publishExportFeedback("Dışa aktarma başarısız: ${t.message ?: "bilinmeyen hata"}")
            }
        }
    }

    fun exportGpsRoute(id: Long) {
        if (state.exportInProgress) return
        state = state.copy(exportInProgress = true, status = "GPS rotası dışa aktarılıyor…")
        scope.launch {
            try {
                val gpx = sqlStore.exportTripGpx(
                    recordId = id,
                    maskEdges = runtimeSettings.gpsMaskExportEdges,
                    maskMeters = 200.0
                )
                if (gpx == null) {
                    publishExportFeedback("Dışa aktarma başarısız: bu sürüşte kullanılabilir GPS rotası yok")
                    return@launch
                }
                val fileName = "loganos_route_v${safeVersionTag()}_${trustedFileStamp()}_id${id}.gpx"
                val displayPath = saveBytesToDownloads(fileName, "application/gpx+xml", gpx.toByteArray(Charsets.UTF_8))
                publishExportFeedback(
                    message = "GPS rotası dışa aktarıldı: $fileName",
                    status = "GPS rotası dışa aktarıldı: $displayPath",
                    displayPath = displayPath,
                    fileName = fileName
                )
            } catch (t: Throwable) {
                publishExportFeedback("GPS rota dışa aktarımı başarısız: ${t.message ?: "bilinmeyen hata"}")
            }
        }
    }

    fun exportTestHistory(id: Long) {
        if (state.exportInProgress) return
        state = state.copy(exportInProgress = true, status = "Test dışa aktarılıyor…")
        scope.launch {
            try {
                val text = sqlStore.exportTestRecordText(id, includeRaw = true)
                if (text == null) {
                    publishExportFeedback("Dışa aktarma başarısız: test kaydı bulunamadı")
                    return@launch
                }
                val fileName = "loganos_test_v${safeVersionTag()}_${trustedFileStamp()}_id${id}.txt"
                val displayPath = saveBytesToDownloads(fileName, "text/plain", text.toByteArray(Charsets.UTF_8))
                publishExportFeedback(
                    message = "Dışa aktarma tamamlandı: $fileName",
                    status = "Test dışa aktarıldı: $displayPath",
                    displayPath = displayPath,
                    fileName = fileName
                )
                refreshHistoryState()
            } catch (t: Throwable) {
                publishExportFeedback("Dışa aktarma başarısız: ${t.message ?: "bilinmeyen hata"}")
            }
        }
    }

    fun exportAllHistory() {
        if (state.exportInProgress) return
        state = state.copy(exportInProgress = true, status = "Geçmiş paketi hazırlanıyor…")
        scope.launch {
            try {
                val drives = sqlStore.listDriveHistory(500)
                val tests = sqlStore.listTestHistory(500)
                val fileName = "loganos_history_v${safeVersionTag()}_${trustedFileStamp()}.zip"
                val zipBytes = ByteArrayOutputStream().use { buffer ->
                    ZipOutputStream(buffer).use { zip ->
                        drives.forEach { item ->
                            val text = sqlStore.exportTripRecordText(item.id, includeRaw = false) ?: return@forEach
                            zip.putNextEntry(ZipEntry("drives/drive_id${item.id}_${item.startedAtMs}.txt"))
                            zip.write(text.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                        tests.forEachIndexed { index, item ->
                            val text = sqlStore.exportTestRecordText(item.id, includeRaw = true) ?: return@forEachIndexed
                            zip.putNextEntry(ZipEntry("tests/test_${index + 1}_id${item.id}.txt"))
                            zip.write(text.toByteArray(Charsets.UTF_8))
                            zip.closeEntry()
                        }
                        val summary = buildString {
                            appendLine("LOGANOS HISTORY EXPORT")
                            appendLine("version=${BuildConfig.VERSION_NAME}")
                            appendLine("drive_records=${drives.size}")
                            appendLine("test_records=${tests.size}")
                            appendLine("drive_format=summary")
                            appendLine("drive_raw_ecu_packets=false")
                            appendLine("test_format=summary+raw")
                        }
                        zip.putNextEntry(ZipEntry("summary.txt"))
                        zip.write(summary.toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    buffer.toByteArray()
                }
                val displayPath = saveBytesToDownloads(fileName, "application/zip", zipBytes)
                publishExportFeedback(
                    message = "Dışa aktarma tamamlandı: $fileName",
                    status = "Dışa aktarma tamamlandı: $displayPath",
                    displayPath = displayPath,
                    fileName = fileName
                )
                refreshHistoryState()
            } catch (t: Throwable) {
                publishExportFeedback("Dışa aktarma başarısız: ${t.message ?: "bilinmeyen hata"}")
            }
        }
    }

    private suspend fun publishExportFeedback(
        message: String,
        status: String = message,
        displayPath: String? = null,
        fileName: String? = null
    ) {
        withMain {
            state = state.copy(
                savedLogPath = displayPath ?: state.savedLogPath,
                savedLogFileName = fileName ?: state.savedLogFileName,
                status = status,
                exportInProgress = false,
                exportFeedbackMessage = message,
                exportFeedbackNonce = state.exportFeedbackNonce + 1L
            )
        }
    }

    private fun isPhoneModeForGps(settings: LoganSettings): Boolean {
        return when (settings.deviceMode) {
            DeviceMode.Phone -> true
            DeviceMode.HeadUnit -> false
            DeviceMode.Auto -> {
                val configuration = context.resources.configuration
                val uiModeType = configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK
                uiModeType != android.content.res.Configuration.UI_MODE_TYPE_CAR && configuration.smallestScreenWidthDp < 600
            }
        }
    }

    private fun safeVersionTag(): String = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')

    private fun exportLogText(sessionId: Long? = null, includeRaw: Boolean = true): String {
        val resolvedSessionId = sessionId ?: sqlStore.latestValidTechnicalSessionId(currentSqlSessionId ?: lastSqlSessionId)
        val base = sqlStore.exportSessionText(resolvedSessionId, includeRaw = includeRaw) ?: state.logText.ifBlank { "Log yok" }
        val settingsBlock = buildString {
            append("\n[APP_SETTINGS]\n")
            append("smartTripThreshold=${runtimeSettings.smartTripMinutes}m\n")
            append("vehicleProfile=${state.activeProfile}\n")
            append("fuelType=${runtimeSettings.fuelType.name}\n")
            append("profileSupport=${runtimeSettings.profileSupport.name}\n")
            append("vehicle=${runtimeSettings.vehicleModel}\n")
            append("modelYear=${runtimeSettings.modelYearText}\n")
            append("engine=${runtimeSettings.engine}\n")
            append("engineCode=${runtimeSettings.engineCodeText.ifBlank { "--" }}\n")
            append("engineCc=${runtimeSettings.engineDisplacementCcText.ifBlank { "--" }}\n")
            append("enginePowerHp=${runtimeSettings.enginePowerHpText.ifBlank { "--" }}\n")
            append("cylinders=${runtimeSettings.cylinderCount}\n")
            append("fuelCalculationSupported=${runtimeSettings.fuelCalculationSupported}\n")
            append("supportedStandardPids=${state.supportedStandardPids.sorted().joinToString { "01%02X".format(Locale.US, it) }}\n")
            append("developerRawLog=${runtimeSettings.developerModeEnabled && runtimeSettings.rawEcuLogEnabled}\n")
            append("demoMode=${runtimeSettings.demoMode}\n")
            append("gaugeStyle=${runtimeSettings.gaugeStyle.name}\n")
            append("cockpitDensity=${runtimeSettings.cockpitDensity.name}\n")
            append("cockpitTextSize=${runtimeSettings.cockpitTextSize.name}\n")
        }
        val withSettings = base + settingsBlock
        val lastAuto = state.lastAutoCrankResult ?: return withSettings
        val time = if (lastAuto.timestampMs > 0L) SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(lastAuto.timestampMs)) else "TIME_PENDING"
        val crank = buildString {
            append("\n\n[LAST_AUTO_CRANK_ANALYSIS]\n")
            append("time=").append(time).append('\n')
            append("duration=").append(String.format(Locale.US, "%.2f", lastAuto.durationSec)).append(" s\n")
            append("status=").append(lastAuto.status).append('\n')
            append("battery=").append(lastAuto.batteryStatus).append('\n')
            append("startV=").append(lastAuto.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("minV=").append(lastAuto.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("engineTemp=").append(lastAuto.engineTempC?.toString() ?: "--").append(" °C\n")
            append("obdGap=").append(lastAuto.obdGapDetected).append('\n')
            append("comment=").append(lastAuto.comment).append('\n')
        }
        return withSettings + crank
    }

    fun exportTechnicalSession(sessionId: Long) {
        if (state.exportInProgress) return
        state = state.copy(exportInProgress = true, status = "Teknik oturum dışa aktarılıyor…")
        scope.launch {
            try {
                val text = exportLogText(sessionId = sessionId, includeRaw = rawEcuLogEnabled)
                val fileName = "loganos_obd_v${safeVersionTag()}_${trustedFileStamp()}_session${sessionId}.txt"
                val displayPath = saveBytesToDownloads(fileName, "text/plain", text.toByteArray(Charsets.UTF_8))
                publishExportFeedback(
                    message = "Teknik oturum dışa aktarıldı: $fileName",
                    status = "Teknik oturum dışa aktarıldı: $displayPath",
                    displayPath = displayPath,
                    fileName = fileName
                )
                refreshHistoryState()
            } catch (t: Throwable) {
                publishExportFeedback("Teknik oturum dışa aktarılamadı: ${t.message ?: "bilinmeyen hata"}")
            }
        }
    }

    fun saveLogFile() {
        val fileName = makeLogFileName()
        val text = exportLogText(includeRaw = rawEcuLogEnabled)
        val displayPath = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Download/LoganOS/$fileName"
            } else {
                val file = File(privateExportDir(), fileName)
                file.writeText(text)
                "LoganOS özel depolama/$fileName"
            }
        }.getOrElse {
            val file = File(privateExportDir(), fileName)
            file.writeText(text)
            "LoganOS özel depolama/$fileName"
        }
        state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Kayıt dışa aktarıldı: $displayPath", sharedLogReady = true)
        appendLog("[LOG] Saved to $displayPath")
    }

    fun shareLogText() {
        val text = exportLogText(includeRaw = false)
        val fileName = makeLogFileName(prefix = "loganos_share")
        val shareDir = File(context.cacheDir, "log_share").apply { mkdirs() }
        cleanupExpiredShareFiles(shareDir)
        val shareFile = File(shareDir, fileName).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", shareFile)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "LoganOS teknik dosyası")
            putExtra(Intent.EXTRA_TITLE, shareFile.name)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "LoganOS dosyasını paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = state.copy(status = "Son geçerli teknik kayıt için paylaşım ekranı açıldı")
    }

    fun createSupportPackage() {
        val fileName = makeSupportFileName()
        val latestValidSessionId = sqlStore.latestValidTechnicalSessionId(currentSqlSessionId ?: lastSqlSessionId)
        val summaryText = exportLogText(sessionId = latestValidSessionId, includeRaw = false)
        val includeRawPackets = rawEcuLogEnabled
        val rawText = if (includeRawPackets) exportLogText(sessionId = latestValidSessionId, includeRaw = true) else null
        val recentTechnicalSessions = sqlStore.listTechnicalSessions(10)
        val metadata = buildString {
            appendLine("LOGANOS SUPPORT PACKAGE")
            appendLine("version=${BuildConfig.VERSION_NAME}")
            val generatedMark = timeSource.now()
            val generatedText = generatedMark.epochMs?.takeIf { generatedMark.trusted }?.let {
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(it))
            } ?: "TIME_PENDING+${generatedMark.elapsedMs}ms"
            appendLine("generated=$generatedText")
            appendLine("adapter=${state.selectedName ?: "--"} / ${maskBluetoothAddress(state.selectedAddress)}")
            appendLine("activeProfile=${state.activeProfile}")
            appendLine("fuelType=${runtimeSettings.fuelType.name}")
            appendLine("profileSupport=${runtimeSettings.profileSupport.name}")
            appendLine("vehicle=${runtimeSettings.vehicleModel}")
            appendLine("modelYear=${runtimeSettings.modelYearText}")
            appendLine("engine=${runtimeSettings.engine}")
            appendLine("engineCode=${runtimeSettings.engineCodeText.ifBlank { "--" }}")
            appendLine("engineCc=${runtimeSettings.engineDisplacementCcText.ifBlank { "--" }}")
            appendLine("enginePowerHp=${runtimeSettings.enginePowerHpText.ifBlank { "--" }}")
            appendLine("cylinders=${runtimeSettings.cylinderCount}")
            appendLine("fuelCalculationSupported=${runtimeSettings.fuelCalculationSupported}")
            appendLine("supportedStandardPids=${state.supportedStandardPids.sorted().joinToString { "01%02X".format(Locale.US, it) }}")
            appendLine("connected=${state.connected}")
            appendLine("loopCount=${state.loopCount}")
            appendLine("noDataCount=${state.noDataCount}")
            appendLine("stoppedCount=${state.stoppedCount}")
            appendLine("busInitCount=${state.busInitCount}")
            appendLine("slowLoopCount=${state.slowLoopCount}")
            appendLine("connectionHealth=${state.connectionHealth.name}")
            appendLine("connectionHealthReason=${state.connectionHealthReason ?: "--"}")
            appendLine("connectionUnstableCount=${state.connectionUnstableCount}")
            appendLine("signalHoldActive=${state.signalHoldActive}")
            appendLine("smartTripThreshold=${smartTripMinutes}m")
            appendLine("rawEcuLogIncluded=$includeRawPackets")
            appendLine("latestValidTechnicalSessionId=${latestValidSessionId ?: "--"}")
            appendLine("recentTechnicalSessionCount=${recentTechnicalSessions.size}")
            appendLine("demoMode=${runtimeSettings.demoMode}")
            appendLine("gaugeStyle=${runtimeSettings.gaugeStyle.name}")
            appendLine("headUnitUiMode=${runtimeSettings.headUnitUiMode.name}")
            appendLine("defaultMediaApp=${runtimeSettings.defaultMediaApp.name}")
            appendLine("cockpitDensity=${runtimeSettings.cockpitDensity.name}")
            appendLine("cockpitTextSize=${runtimeSettings.cockpitTextSize.name}")
        }
        val zipBytes = ByteArrayOutputStream().use { buffer ->
            ZipOutputStream(buffer).use { zip ->
                fun add(name: String, text: String) {
                    zip.putNextEntry(ZipEntry(name))
                    zip.write(text.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
                add("summary_log.txt", summaryText)
                rawText?.let { add("raw_obd_log.txt", it) }
                val sessionIndex = buildString {
                    appendLine("LOGANOS RECENT TECHNICAL SESSIONS")
                    appendLine("count=${recentTechnicalSessions.size}")
                    recentTechnicalSessions.forEach { session ->
                        appendLine("id=${session.id} status=${session.status} samples=${session.sampleCount} events=${session.eventCount} durationMs=${session.durationMs} tripRecordId=${session.tripRecordId ?: "--"}")
                    }
                }
                add("technical_sessions/index.txt", sessionIndex)
                recentTechnicalSessions.forEach { session ->
                    val sessionText = sqlStore.exportSessionText(session.id, includeRaw = includeRawPackets)
                    if (sessionText != null) {
                        val safeStatus = session.status.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "_").trim('_')
                        add("technical_sessions/session_${session.id}_${safeStatus}_samples${session.sampleCount}.txt", sessionText)
                    }
                }
                add("metadata.txt", metadata)
            }
            buffer.toByteArray()
        }
        val displayPath = saveBytesToDownloads(fileName, "application/zip", zipBytes)
        state = state.copy(
            savedLogPath = displayPath,
            savedLogFileName = fileName,
            status = "Destek paketi oluşturuldu: $displayPath",
            sharedLogReady = true
        )
        appendLog("[SUPPORT_PACKAGE] Saved to $displayPath")
    }

    private fun saveBytesToDownloads(fileName: String, mimeType: String, bytes: ByteArray): String {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                "Download/LoganOS/$fileName"
            } else {
                val file = File(privateExportDir(), fileName)
                file.writeBytes(bytes)
                "LoganOS özel depolama/$fileName"
            }
        }.getOrElse {
            val file = File(privateExportDir(), fileName)
            file.writeBytes(bytes)
            "LoganOS özel depolama/$fileName"
        }
    }

    fun clearLastLogFile() {
        val fileName = state.savedLogFileName
        if (fileName.isNullOrBlank()) {
            state = state.copy(status = "Silinecek son log yok")
            return
        }
        val deleted = deleteDownloadLogByName(fileName)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = if (deleted) "Son log silindi: $fileName" else "Son log bulunamadı: $fileName"
        )
        appendLog("[LOG] Clear last requested: $fileName deleted=$deleted")
    }

    fun clearAllLogFiles(): Boolean {
        if (state.connected || state.connecting || currentSqlSessionId != null) {
            state = state.copy(status = "Tüm logları temizlemek için önce OBD bağlantısını kesin")
            appendLog("[LOG] Clear all blocked while an OBD session is active")
            return false
        }
        val deleted = deleteAllDownloadLogs()
        val sqlDeleted = sqlStore.clearAll()
        lastSqlSessionId = null
        activeTripHistoryId = null
        saveActiveTripHistory(null)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = "$deleted log dosyası ve $sqlDeleted SQL kaydı silindi",
            sqlSessionId = null,
            driveHistory = emptyList(),
            testHistory = emptyList(),
            technicalHistory = emptyList(),
            historyStorage = com.dcui.loganos.data.HistoryStorageInfo(),
            vehicleHealthEvidence = com.dcui.loganos.data.VehicleHealthEvidence()
        )
        vehicleHealthHistorySignature = Long.MIN_VALUE
        vehicleHealthEvidenceRefreshElapsedMs = 0L
        appendLog("[LOG] Clear all requested: files=$deleted sql=$sqlDeleted")
        return true
    }

    private fun trustedFileStamp(): String {
        val mark = timeSource.now()
        val epoch = mark.epochMs
        return if (mark.trusted && epoch != null) {
            SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS", Locale.US).format(Date(epoch))
        } else {
            val boot = mark.bootSessionId.replace(Regex("[^A-Za-z0-9]"), "").take(8).ifBlank { "boot" }
            "time_pending_${boot}_${mark.elapsedMs}ms"
        }
    }

    private fun makeLogFileName(prefix: String = "loganos_obd"): String {
        val versionTag = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
        return "${prefix}_v${versionTag}_${trustedFileStamp()}.txt"
    }

    private fun makeSupportFileName(): String {
        val versionTag = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
        return "loganos_support_v${versionTag}_${trustedFileStamp()}.zip"
    }

    private fun deleteDownloadLogByName(fileName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf(fileName, Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args) > 0
            } else {
                val file = File(privateExportDir(), fileName)
                file.exists() && file.delete()
            }
        }.getOrDefault(false)
    }

    private fun deleteAllDownloadLogs(): Int {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf("loganos_%", Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args)
            } else {
                privateExportDir().listFiles { f -> f.name.startsWith("loganos_") && (f.name.endsWith(".txt") || f.name.endsWith(".zip")) }?.count { it.delete() } ?: 0
            }
        }.getOrDefault(0)
    }

    private fun privateExportDir(): File = File(context.filesDir, "exports").apply { mkdirs() }

    private fun maskBluetoothAddress(address: String?): String {
        val parts = address?.trim()?.split(':').orEmpty()
        return if (parts.size == 6) "${parts[0]}:${parts[1]}:…:${parts[5]}" else "--"
    }

    private fun cleanupExpiredShareFiles(directory: File) {
        val cutoff = System.currentTimeMillis() - SHARE_FILE_MAX_AGE_MS
        directory.listFiles()?.forEach { file ->
            if (file.isFile && file.lastModified() in 1L until cutoff) file.delete()
        }
    }

    private fun healthHistorySignature(drives: List<com.dcui.loganos.data.DriveHistoryItem>): Long {
        return drives.filterNot { it.activeLike }.take(10).fold(17L) { acc, item -> acc * 31L + item.id }
    }

    private fun clean(text: String): String = text.replace("\r", " ").replace("\n", " ").replace(">", " > ").trim()

    private fun closeSocket(expected: BluetoothSocket? = null) {
        val target = expected ?: socket
        runCatching { target?.close() }
        if (expected == null || socket === expected) socket = null
    }

    private fun appendStatus(text: String, error: Boolean = false) {
        state = state.copy(status = text, lastError = if (error) text else state.lastError, logText = trimLog(state.logText + "\n[STATUS] $text"))
    }

    private fun appendLog(text: String) {
        state = state.copy(logText = trimLog(state.logText + "\n$text"))
    }

    private suspend fun withMain(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun trimLog(log: String): String {
        return if (log.length <= 300000) log else log.takeLast(300000)
    }

    private fun looksLikeObd(name: String): Boolean {
        val n = name.lowercase()
        return listOf("obd", "elm", "vlink", "vgate", "icar", "kwp").any { it in n }
    }

    companion object {
        private const val FUEL_DISCOVERY_REPEAT_PASSES = 3
        private const val FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES = 4
        private const val FUEL_DISCOVERY_MIN_STABLE_HITS = 3
        private const val FUEL_DISCOVERY_MIN_REFUEL_GAP_MS = 15_000L
        private const val FUEL_DISCOVERY_STOP_WAIT_MS = 8_000L
        private const val DYNAMIC_026_IDLE_STABLE_SEC = 15
        private const val DYNAMIC_026_RPM_STABLE_SEC = 8
        private const val DYNAMIC_026_STOP_WAIT_MS = 8_000L
        private const val DYNAMIC_026_MODULE_RETRY_COUNT = 3
        private const val DYNAMIC_026_MODULE_RETRY_DELAY_MS = 350L
        private const val DYNAMIC_026_MISSING_RPM_RECOVERY_MS = 8_000L
        private const val DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS = 2
        private const val DEVELOPER_TEST_RECONNECT_DELAY_MS = 700L
        private const val DEVELOPER_TEST_RECONNECT_WAIT_MS = 12_000L
        private const val KEY_DYNAMIC_026_ACTIVE = "active"
        private const val KEY_DYNAMIC_026_RAW_FILE = "raw_file"
        private const val KEY_DYNAMIC_026_RESEARCH_FILE = "research_file"
        private const val KEY_DYNAMIC_026_PHASE = "phase"
        private const val KEY_DYNAMIC_026_PERCENT = "percent"
        private const val KEY_DYNAMIC_026_TEST_NAME = "test_name"
        private const val KEY_DYNAMIC_026_MODE = "mode"
        private const val KEY_DYNAMIC_026_GROUP_ID = "group_id"
        private const val KEY_DYNAMIC_026_GROUP_UPDATED_MS = "group_updated_ms"
        private const val KEY_FUEL_REFILL_LITERS = "fuel_refill_liters"
        private const val KEY_FUEL_DISCOVERY_ACTIVE = "active"
        private const val KEY_FUEL_DISCOVERY_FILE = "working_file"
        private const val KEY_FUEL_DISCOVERY_PHASE = "phase"
        private const val KEY_FUEL_DISCOVERY_DETAIL = "detail"
        private const val KEY_FUEL_DISCOVERY_PERCENT = "percent"
        private const val KEY_FUEL_DISCOVERY_TARGET = "target"
        private const val KEY_FUEL_DISCOVERY_STARTED_EPOCH = "started_epoch"
        private const val CONNECTION_GUARD_WARMUP_MS = 3500L
        private const val ENGINE_RUNNING_RPM_THRESHOLD = 120
        private const val IGNITION_OFF_CONFIRM_MS = 3_000L
        private const val IGNITION_OFF_DISCONNECT_GRACE_MS = 1_500L
        private const val IGNITION_OFF_POLL_DELAY_MS = 15_000L
        private const val IGNITION_WAKE_PROBE_INTERVAL_MS = 30_000L
        private const val MAIN_PACKET_FAILURES_FOR_UNSTABLE = 5
        private const val CONNECTION_GUARD_HOLD_MS = 2200L
        private const val VEHICLE_HEALTH_REFRESH_INTERVAL_MS = 5L * 60L * 1000L
        private const val MAX_ELM_RESPONSE_CHARS = 32 * 1024
        private const val MAX_ELM_DRAIN_BYTES = 64 * 1024
        private const val ELM_PRE_COMMAND_SYNC_MS = 400L
        private const val ELM_SYNC_QUIET_MS = 140L
        private const val ELM_RESPONSE_QUIET_MS = 140L
        private const val ELM_READ_CHUNK_BYTES = 1024
        private const val SHARE_FILE_MAX_AGE_MS = 24L * 60L * 60L * 1000L
        private const val KEY_MANUAL_CRANKS = "manual_crank_tests"
        private const val KEY_CRANK_ATTEMPT_BOOT = "crank_attempt_boot"
        private const val KEY_CRANK_LAST_FAILED_ELAPSED = "crank_last_failed_elapsed"
        private const val KEY_CRANK_ATTEMPT_COUNT = "crank_attempt_count"
        private const val KEY_TRIP_HAS_STATE = "trip_has_state"
        private const val KEY_ACTIVE_HISTORY_ID = "active_trip_history_id"
        private const val KEY_TRIP_STARTED = "trip_started"
        private const val KEY_TRIP_DURATION_MS = "trip_duration_ms"
        private const val KEY_TRIP_DISTANCE_BITS = "trip_distance_bits"
        private const val KEY_TRIP_FUEL_BITS = "trip_fuel_bits"
        private const val KEY_TRIP_PENDING_DISTANCE_BITS = "trip_pending_distance_bits"
        private const val KEY_TRIP_PENDING_FUEL_BITS = "trip_pending_fuel_bits"
        private const val KEY_TRIP_AVG_BITS = "trip_avg_bits"
        private const val KEY_TRIP_TOKEN = "trip_token"
        private const val KEY_TRIP_LAST_EPOCH = "trip_last_epoch"
        private const val KEY_TRIP_LAST_ELAPSED = "trip_last_elapsed"
        private const val KEY_TRIP_LAST_BOOT = "trip_last_boot"
        private const val KEY_TRIP_LAST_TRUSTED = "trip_last_trusted"
        private const val KEY_STOP_EPOCH = "trip_stop_epoch"
        private const val KEY_STOP_ELAPSED = "trip_stop_elapsed"
        private const val KEY_STOP_BOOT = "trip_stop_boot"
        private const val KEY_STOP_TRUSTED = "trip_stop_trusted"
    }
}
