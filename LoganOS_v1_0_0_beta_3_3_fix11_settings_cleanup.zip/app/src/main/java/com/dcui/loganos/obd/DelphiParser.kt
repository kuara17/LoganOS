package com.dcui.loganos.obd

import com.dcui.loganos.model.DashboardSnapshot
import java.util.Locale
import kotlin.math.max

private const val DIESEL_DENSITY_MG_L = 835000.0

data class DelphiParsedData(
    val rpm: Int? = null,
    val speedKmh: Double? = null,
    val coolantC: Double? = null,
    val batteryV: Double? = null,
    val fuelMg: Double? = null,
    val fuelLh: Double? = null,
    val fuelL100: Double? = null,
    val acOn: Boolean? = null,
    val fanOn: Boolean? = null,
    val source: String = "Bekleniyor"
) {
    fun toSnapshot(rawA0: String, rawA2: String, rawCC: String, rawCD: String, connected: Boolean): DashboardSnapshot {
        val speed = speedKmh?.toInt()
        val instant = if ((speedKmh ?: 0.0) >= 5.0) fuelL100 else fuelLh
        val unit = if ((speedKmh ?: 0.0) >= 5.0) "L/100 km" else "L/h"
        return DashboardSnapshot(
            speedKmh = speed,
            rpm = rpm,
            engineTempC = coolantC?.toInt(),
            batteryV = batteryV,
            acOn = acOn,
            radiatorFanOn = fanOn,
            averageConsumption = null,
            instantConsumption = instant,
            instantUnit = unit,
            tripDistanceKm = null,
            odometerKm = null,
            fuelUsedL = null,
            tripCostText = null,
            connected = connected,
            demo = false,
            fuelSource = source,
            injectionMg = fuelMg,
            raw21A0 = rawA0,
            raw21A2 = rawA2,
            raw21CC = rawCC,
            raw21CD = rawCD,
            tripDurationText = null
        )
    }
}

class DelphiParser {
    private fun hexOnly(text: String): String = Regex("[0-9A-Fa-f]").findAll(text).joinToString("") { it.value }.uppercase(Locale.US)

    private fun payload(raw: String, marker: String): List<String> {
        val h = hexOnly(raw)
        val pos = h.indexOf(marker)
        if (pos < 0) return emptyList()
        val hx = h.substring(pos + marker.length)
        return hx.chunked(2).filter { it.length == 2 }
    }

    private fun u16(p: List<String>, i: Int): Int = (p[i] + p[i + 1]).toInt(16)
    private fun byte(p: List<String>, i: Int): Int = p[i].toInt(16)

    fun parse(rawA0: String, rawA2: String, rawCC: String, rawCD: String, atrv: String = "", stdRpm: String = "", stdSpeed: String = "", stdTemp: String = ""): DelphiParsedData {
        val p0 = payload(rawA0, "61A0")
        val p2 = payload(rawA2, "61A2")
        val pcc = payload(rawCC, "61CC")
        val pcd = payload(rawCD, "61CD")

        var rpm: Int? = null
        var speed: Double? = null
        var coolant: Double? = null
        var battery: Double? = null // ECU akü voltajı yalnızca 21A0 u16[12]/1000 kaynağından alınır; ATRV ile karıştırılmaz.
        var fuelMg: Double? = null
        var acOn: Boolean? = null
        val fanOn: Boolean? = null // Fan bit DC UI/log evidence ile doğrulanmadı; bilinmiyor kalır.
        var source = "Bekleniyor"

        runCatching {
            if (pcc.size >= 12) rpm = u16(pcc, 10)
            else if (pcd.size >= 7) rpm = u16(pcd, 5)
        }
        runCatching {
            if (p0.size >= 30) {
                battery = u16(p0, 12) / 1000.0
                speed = u16(p0, 22) / 128.0
                fuelMg = u16(p0, 28) / 100.0
                source = "BASIC_INJECTION / 21A0"
            }
        }
        runCatching {
            if (p2.size >= 34) coolant = (u16(p2, 22) - 2730) / 10.0
        }
        runCatching {
            if (pcc.size > 13) {
                val stateLow = byte(pcc, 13)
                acOn = (stateLow and 0x08) != 0
                // 0x20 fan biti değildir; eski DC UI ve loglarda gerçek fan biti doğrulanmadı.
            }
        }

        if (rpm == null) rpm = parseStandardRpm(stdRpm)
        if (speed == null) speed = parseStandardSpeed(stdSpeed)
        if (coolant == null) coolant = parseStandardCoolant(stdTemp)

        val fuelLh = if ((rpm ?: 0) > 0 && (fuelMg ?: 0.0) > 0.0) {
            ((fuelMg ?: 0.0) * (rpm ?: 0) * 120.0) / DIESEL_DENSITY_MG_L
        } else null
        val fuelL100 = if ((speed ?: 0.0) >= 5.0 && (fuelLh ?: 0.0) > 0.0) {
            ((fuelLh ?: 0.0) / max(speed ?: 0.0, 1.0)) * 100.0
        } else null

        return DelphiParsedData(
            rpm = rpm,
            speedKmh = speed,
            coolantC = coolant,
            batteryV = battery,
            fuelMg = fuelMg,
            fuelLh = fuelLh,
            fuelL100 = fuelL100,
            acOn = acOn,
            fanOn = fanOn,
            source = source
        )
    }

    private fun parseVoltage(raw: String): Double? {
        val match = Regex("(\\d{1,2}\\.\\d{1,2})").find(raw) ?: return null
        return match.value.toDoubleOrNull()
    }

    private fun parseStandardRpm(raw: String): Int? {
        val h = hexOnly(raw)
        val pos = h.indexOf("410C")
        if (pos < 0 || h.length < pos + 8) return null
        val a = h.substring(pos + 4, pos + 6).toIntOrNull(16) ?: return null
        val b = h.substring(pos + 6, pos + 8).toIntOrNull(16) ?: return null
        return ((a * 256) + b) / 4
    }

    private fun parseStandardSpeed(raw: String): Double? {
        val h = hexOnly(raw)
        val pos = h.indexOf("410D")
        if (pos < 0 || h.length < pos + 6) return null
        return h.substring(pos + 4, pos + 6).toIntOrNull(16)?.toDouble()
    }

    private fun parseStandardCoolant(raw: String): Double? {
        val h = hexOnly(raw)
        val pos = h.indexOf("4105")
        if (pos < 0 || h.length < pos + 6) return null
        return h.substring(pos + 4, pos + 6).toIntOrNull(16)?.minus(40)?.toDouble()
    }
}
