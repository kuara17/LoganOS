# LoganOS v1.0.0-beta.3.9.2

Bu sürüm; tek merkezli sürüm yönetimi, yazılı OBD durum rozeti, kokpit ikon hizalaması, bağımsız ortalama/maliyet sıfırlama, Smart Trip karar logları, AC yedek bit doğrulaması, ECT rolling median ve tek ZIP destek paketini içerir.

APK üretimi için `.github/workflows/build-apk.yml` GitHub Actions iş akışı kullanılabilir. İş akışı sürüm adını `app/build.gradle.kts` içinden otomatik okur.
