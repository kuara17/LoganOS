# LoganOS v1.0.0-beta.3.9.2

- Sürüm bilgisi `BuildConfig.VERSION_NAME` altında merkezileştirildi.
- Eski `beta3_8_2` export dosya adı sabiti ve ayrı `LOGAN_VERSION` değeri kaldırıldı.
- Sürüm yalnızca Ayarlar > Hakkında ekranında gösteriliyor.
- GitHub Actions APK adı uygulamanın `versionName` değerinden otomatik üretiliyor.
- Ana kokpite yazılı `OBD BAĞLI / BAĞLANIYOR / OBD BEKLENİYOR / DEMO` durum rozeti eklendi; çift Demo etiketi kaldırıldı.
- Kokpit ikonları `ContentScale.Fit`, merkez hizalama ve güvenli iç boyutla güncellendi.
- Hararet/Fan kartı için ortalanmış birleşik ikon eklendi.
- Ortalama, maliyet veya ikisini birlikte sıfırlayan, trip toplamlarını koruyan baseline sistemi eklendi.
- Ana kokpitteki sıfırlama menüsüne ikinci onay adımı eklendi.
- Reset olayları `AVG_RESET`, `COST_RESET` ve `AVG_COST_RESET` olarak SQL/geliştirici loguna yazılıyor.
- Smart Trip seçili eşiğe göre `CONTINUE / NEW_TRIP` kararı veriyor; eşik ve mola süresi loga yazılıyor. Eşiğe eşit veya daha uzun mola yeni sürüş başlatıyor.
- AC ana bitine yedek `21CC` kontrolü eklendi; uyuşmazlık sadece geliştirici loguna yazılıyor.
- Fan tahmin edilmiyor ve `UNKNOWN` politikası korunuyor.
- Hararet sert clamp yerine 3 örnek rolling median kullanıyor.
- Normal paylaşım ham ECU paketlerini gizliyor; destek paketi summary + raw + metadata içeren tek ZIP üretiyor.
- Aktif session exportlarında `ended`, `duration` ve session durumu artık yazılıyor.
- Export metadata bölümüne Smart Trip ve kokpit/log ayarları eklendi.
- OBD hız değeri, FuelAlgorithmV3, CUTOFF ve COAST_GUARD mantığı değiştirilmedi.
