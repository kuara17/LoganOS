# Changelog

## v1.0.0-beta.3.2 - Cockpit Layout + Log/Lifecycle Fix

### Changed
- Fuel Truth card removed from the main Cockpit screen.
- Fuel Truth remains available under Technical Veriler as a debug/test panel.
- Added Sürüş Süresi card to Cockpit.
- Moved radiator fan info next to Motor Sıcaklığı to avoid confusion with A/C fan.
- Klima card is now separate and more prominent.
- Sürüş Maliyeti uses `--` when no value is available.
- Gauge preview speed value reduced so the selected style is more visible.
- Settings detail navigation now uses slide/fade transition.
- OBD Bağlan button can be used as Yeniden Bağlan when a stale connection state is present.

### Added
- Unique timestamped OBD log filenames: `loganos_obd_beta3_2_yyyy-MM-dd_HH-mm-ss_SSS.txt`.
- Log sharing now sends a uniquely named text file instead of plain repeated text.
- Confirm dialog for Destek Paketi Oluştur.
- Confirm dialog for Son Log Dosyasını Sil.
- Confirm dialog for Tüm LoganOS Loglarını Temizle.
- Log cleanup helpers for Download/LoganOS.

### Fixed
- Main Cockpit no longer shows Fuel Truth mg/st as a user-facing card.
- Fan/Klima grouping was clarified.
- Duplicate/stale log filename issue reduced by using precise timestamped filenames.
- Stale connected state can be recovered with Yeniden Bağlan.
