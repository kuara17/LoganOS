# LoganOS

**OEM Digital Cockpit** for Renault & Dacia vehicles.  
Powered by **DC UI**.

Version: **1.0.0-beta.3.2**

## Beta 3.2 Focus

This is a Kotlin/Jetpack Compose test release focused on:

- KWP/OBD connection stability after the successful beta.3.1 init test
- Cleaner cockpit card layout
- Motor temperature + radiator fan grouping
- Separate larger Klima card
- Fuel Truth moved from Cockpit to Technical Veriler
- Trip duration card added to Cockpit
- Better log file naming and file sharing
- Confirm dialogs for support package/log cleanup actions
- Settings page transition animation
- Gauge preview improvements

## Important

LoganOS is an independent, community-driven, open-source project. It is not affiliated with, endorsed by, or sponsored by Renault Group, Dacia, or any vehicle manufacturer.
