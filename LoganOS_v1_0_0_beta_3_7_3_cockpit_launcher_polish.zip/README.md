# LoganOS

Version: **1.0.0-beta.3.7.3**

## Beta 3.7.3 Cockpit & Launcher Polish

This package focuses on final visual polish after the 3.7.2 technical fixes.

### Highlights
- Launcher icon reworked for Android adaptive icon masks.
- The small **OS** suffix was removed from the launcher icon; the icon now uses the LoganOS symbol plus centered **LOGAN** text inside the safe area.
- Added **Text Size** under Appearance & Cockpit: Small / Normal / Large.
- Added **Cockpit Density** under Appearance & Cockpit: Compact / Balanced / Wide.
- Cockpit portrait card heights, spacing and text scaling were tuned to reduce clipping.
- Demo cockpit cards keep realistic sample values, including trip cost.

Core OBD, FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, Delphi parser byte positions, fan UNKNOWN policy and fuel calibration logic are intentionally preserved.
