## v1.0.0-beta.3.7.3 - Cockpit & Launcher Polish

### Launcher icon
- Reworked launcher icon assets for Android adaptive icon masking.
- Removed only the small **OS** suffix from the launcher icon.
- Kept the centered **LOGAN** wordmark inside the launcher icon safe area.
- Regenerated legacy mipmap icons and adaptive foreground asset.

### Cockpit polish
- Added `CockpitTextSize` setting: Small / Normal / Large.
- Added `CockpitDensity` setting: Compact / Balanced / Wide.
- Added Settings > Appearance & Cockpit rows for text size and cockpit density.
- Tuned portrait cockpit card heights, spacing and text scale usage.
- Increased bottom padding in the cockpit scroll area to reduce bottom navigation crowding.

### Preserved systems
- FuelAlgorithmV3 unchanged.
- TripComputer unchanged.
- CUTOFF and AC_FAST logic unchanged.
- Delphi DCM1.2 parser byte positions unchanged.
- Fan UNKNOWN / test pending policy unchanged.
- Fuel calibration coefficient remains optional.

### Version
- Updated version metadata to 1.0.0-beta.3.7.3.
