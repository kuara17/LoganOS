## v1.0.0-beta.3.3-fix5 - AC Fast Loop + Settings Polish

- 21CC_FAST klima/fan için ana kaynak yapıldı.
- Klima kapatmada gecikme azaltıldı: false durumu 21CC_FAST ile hemen UI snapshotına yazılır.
- 21A2 ve 21CD ağır teknik paketleri seyrekleştirildi.
- Döngü beklemeleri kısaltıldı; loga AC_FAST / FAN_FAST olay satırları eklendi.
- Dikey Ayarlar ekranında dar sol menü biraz genişletildi, ikonlar büyütüldü.
- Ayarlar içerik kartında başlık/alt açıklama düzeni ve satır görünümü daha premium hale getirildi.
- Önceki fix4 ikon renk paketi korunur.
