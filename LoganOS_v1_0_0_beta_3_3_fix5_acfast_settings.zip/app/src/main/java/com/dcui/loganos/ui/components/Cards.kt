package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.cos
import kotlin.math.sin

/**
 * LoganOS fix5: seçilen kokpit ikon konseptleri Compose Canvas ile çizilir.
 * - Ortalama: pompa + bar chart
 * - Anlık: pompa + pulse çizgisi
 * - Klima: kar tanesi 2A
 * - Hararet: termometre + dalga 3A
 * - Fan: swirl/pervane 4C
 */
enum class CardIcon {
    FuelAverage,
    FuelInstant,
    Distance,
    Cost,
    Temperature,
    Fan,
    Ac,
    Rpm,
    Time,
    Battery,
    Speed,
    Injection
}

@Composable
fun OemCard(
    palette: LoganPalette,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(11.dp)
    Box(
        modifier = modifier
            .shadow(2.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = .10f), spotColor = Color.Black.copy(alpha = .10f))
            .clip(shape)
            .background(palette.surface)
            .border(1.dp, palette.line.copy(alpha = .82f), shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(12.dp)
    ) {
        content()
    }
}

@Composable
fun MetricIcon(
    palette: LoganPalette,
    icon: CardIcon,
    tint: Color = palette.accent,
    modifier: Modifier = Modifier.size(28.dp)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w / 2f, h / 2f)
        val s = minOf(w, h)
        val stroke = (s * .095f).coerceAtLeast(2.15f)
        val thin = (s * .060f).coerceAtLeast(1.45f)
        fun line(a: Offset, b: Offset, sw: Float = stroke, color: Color = tint) = drawLine(color, a, b, sw, cap = StrokeCap.Round)
        fun circle(r: Float, center: Offset = c, sw: Float = stroke, color: Color = tint) = drawCircle(color, r, center, style = Stroke(sw))
        fun rr(x: Float, y: Float, ww: Float, hh: Float, rad: Float, sw: Float = stroke, color: Color = tint) = drawRoundRect(
            color = color,
            topLeft = Offset(w * x, h * y),
            size = Size(w * ww, h * hh),
            cornerRadius = CornerRadius(rad, rad),
            style = Stroke(sw)
        )
        fun filledRr(x: Float, y: Float, ww: Float, hh: Float, rad: Float, color: Color = tint) = drawRoundRect(
            color = color,
            topLeft = Offset(w * x, h * y),
            size = Size(w * ww, h * hh),
            cornerRadius = CornerRadius(rad, rad)
        )

        when (icon) {
            CardIcon.FuelAverage -> {
                // Konsept 1: yakıt pompası + küçük bar chart / istatistik işareti.
                rr(.12f, .16f, .32f, .58f, 5f)
                filledRr(.19f, .25f, .18f, .14f, 2f, tint.copy(alpha = .20f))
                line(Offset(w * .44f, h * .35f), Offset(w * .60f, h * .45f), thin)
                line(Offset(w * .60f, h * .45f), Offset(w * .60f, h * .66f), thin)
                circle(w * .235f, Offset(w * .72f, h * .62f), thin)
                val barTops = listOf(.67f, .56f, .45f)
                barTops.forEachIndexed { index, top ->
                    val x = .62f + index * .075f
                    filledRr(x, top, .045f, .78f - top, 2f)
                }
            }
            CardIcon.FuelInstant -> {
                // Seçilen 1A: yakıt pompası + canlı/pulse çizgisi.
                rr(.12f, .16f, .34f, .60f, 5f)
                filledRr(.20f, .25f, .18f, .14f, 2f, tint.copy(alpha = .20f))
                line(Offset(w * .47f, h * .34f), Offset(w * .63f, h * .45f), thin)
                line(Offset(w * .63f, h * .45f), Offset(w * .63f, h * .66f), thin)
                line(Offset(w * .58f, h * .57f), Offset(w * .68f, h * .57f), thin)
                line(Offset(w * .68f, h * .57f), Offset(w * .73f, h * .42f), thin)
                line(Offset(w * .73f, h * .42f), Offset(w * .82f, h * .72f), thin)
                line(Offset(w * .82f, h * .72f), Offset(w * .88f, h * .57f), thin)
                line(Offset(w * .88f, h * .57f), Offset(w * .96f, h * .57f), thin)
            }
            CardIcon.Distance -> {
                line(Offset(w * .23f, h * .84f), Offset(w * .43f, h * .16f), thin)
                line(Offset(w * .57f, h * .16f), Offset(w * .77f, h * .84f), thin)
                line(Offset(w * .50f, h * .15f), Offset(w * .50f, h * .84f), thin)
                line(Offset(w * .39f, h * .56f), Offset(w * .61f, h * .56f), thin)
                line(Offset(w * .33f, h * .72f), Offset(w * .67f, h * .72f), thin)
            }
            CardIcon.Cost -> {
                line(Offset(w * .45f, h * .16f), Offset(w * .45f, h * .84f), stroke)
                line(Offset(w * .28f, h * .39f), Offset(w * .72f, h * .29f), thin)
                line(Offset(w * .28f, h * .55f), Offset(w * .70f, h * .45f), thin)
                line(Offset(w * .45f, h * .84f), Offset(w * .72f, h * .70f), stroke)
            }
            CardIcon.Temperature -> {
                // Seçilen 3A: hararet / soğutma suyu. Termometre + dalga çizgileri.
                rr(.43f, .10f, .14f, .50f, 8f)
                drawCircle(tint, w * .145f, Offset(w * .50f, h * .70f), style = Stroke(stroke))
                line(Offset(w * .50f, h * .23f), Offset(w * .50f, h * .64f), thin)
                line(Offset(w * .61f, h * .22f), Offset(w * .76f, h * .22f), thin)
                line(Offset(w * .61f, h * .36f), Offset(w * .72f, h * .36f), thin)
                line(Offset(w * .61f, h * .50f), Offset(w * .76f, h * .50f), thin)
                line(Offset(w * .18f, h * .85f), Offset(w * .32f, h * .79f), thin)
                line(Offset(w * .32f, h * .79f), Offset(w * .46f, h * .85f), thin)
                line(Offset(w * .46f, h * .85f), Offset(w * .61f, h * .79f), thin)
                line(Offset(w * .61f, h * .79f), Offset(w * .80f, h * .85f), thin)
            }
            CardIcon.Fan -> {
                // Seçilen 4C: hareket hissi olan swirl/pervane.
                drawCircle(tint, w * .075f, c)
                repeat(4) { i ->
                    val angle = Math.toRadians((i * 90f - 18f).toDouble())
                    val x = c.x + cos(angle).toFloat() * w * .23f
                    val y = c.y + sin(angle).toFloat() * h * .23f
                    drawOval(
                        color = tint.copy(alpha = .92f),
                        topLeft = Offset(x - w * .15f, y - h * .065f),
                        size = Size(w * .30f, h * .13f)
                    )
                }
                drawArc(
                    color = tint.copy(alpha = .55f),
                    startAngle = 205f,
                    sweepAngle = 250f,
                    useCenter = false,
                    topLeft = Offset(w * .10f, h * .10f),
                    size = Size(w * .80f, h * .80f),
                    style = Stroke(thin, cap = StrokeCap.Round)
                )
                drawArc(
                    color = tint.copy(alpha = .35f),
                    startAngle = 25f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(w * .18f, h * .18f),
                    size = Size(w * .64f, h * .64f),
                    style = Stroke(thin, cap = StrokeCap.Round)
                )
            }
            CardIcon.Ac -> {
                // Seçilen 2A: sade kar tanesi. Beyaz temada yıldız gibi değil, gerçek klima simgesi gibi okunur.
                val arm = w * .36f
                repeat(3) { i ->
                    val a = Math.toRadians((i * 60f).toDouble())
                    val dx = cos(a).toFloat() * arm
                    val dy = sin(a).toFloat() * arm
                    line(Offset(c.x - dx, c.y - dy), Offset(c.x + dx, c.y + dy), thin)
                    val bx = cos(a).toFloat() * w * .22f
                    val by = sin(a).toFloat() * h * .22f
                    val wa = Math.toRadians((i * 60f + 34f).toDouble())
                    val wx = cos(wa).toFloat() * w * .085f
                    val wy = sin(wa).toFloat() * h * .085f
                    line(Offset(c.x + bx, c.y + by), Offset(c.x + bx - wx, c.y + by - wy), thin)
                    line(Offset(c.x - bx, c.y - by), Offset(c.x - bx + wx, c.y - by + wy), thin)
                }
                drawCircle(tint, w * .040f, c)
                listOf(
                    Offset(w * .16f, h * .21f), Offset(w * .84f, h * .21f),
                    Offset(w * .16f, h * .79f), Offset(w * .84f, h * .79f)
                ).forEach { dot -> drawCircle(tint.copy(alpha = .45f), w * .025f, dot) }
            }
            CardIcon.Rpm -> {
                drawArc(color = tint, startAngle = 145f, sweepAngle = 250f, useCenter = false, topLeft = Offset(w * .14f, h * .18f), size = Size(w * .72f, h * .72f), style = Stroke(stroke, cap = StrokeCap.Round))
                val angle = Math.toRadians(315.0)
                line(c, Offset(c.x + cos(angle).toFloat() * w * .28f, c.y + sin(angle).toFloat() * h * .28f), stroke)
                circle(w * .045f, c, thin)
            }
            CardIcon.Time -> {
                circle(w * .35f, c, stroke)
                line(c, Offset(c.x, c.y - h * .20f), thin)
                line(c, Offset(c.x + w * .18f, c.y + h * .10f), thin)
            }
            CardIcon.Battery -> {
                rr(.14f, .32f, .63f, .36f, 5f)
                line(Offset(w * .79f, h * .43f), Offset(w * .88f, h * .43f), stroke)
                line(Offset(w * .79f, h * .57f), Offset(w * .88f, h * .57f), stroke)
                line(Offset(w * .30f, h * .50f), Offset(w * .43f, h * .50f), thin)
                line(Offset(w * .57f, h * .43f), Offset(w * .57f, h * .57f), thin)
                line(Offset(w * .50f, h * .50f), Offset(w * .64f, h * .50f), thin)
            }
            CardIcon.Speed -> {
                drawArc(color = tint, startAngle = 150f, sweepAngle = 240f, useCenter = false, topLeft = Offset(w * .16f, h * .22f), size = Size(w * .68f, h * .68f), style = Stroke(stroke, cap = StrokeCap.Round))
                val angle = Math.toRadians(315.0)
                line(c, Offset(c.x + cos(angle).toFloat() * w * .28f, c.y + sin(angle).toFloat() * h * .28f), stroke)
            }
            CardIcon.Injection -> {
                line(Offset(w * .30f, h * .20f), Offset(w * .70f, h * .60f), stroke)
                line(Offset(w * .22f, h * .28f), Offset(w * .42f, h * .08f), thin)
                line(Offset(w * .58f, h * .72f), Offset(w * .76f, h * .54f), thin)
                drawCircle(tint, w * .07f, Offset(w * .76f, h * .77f))
            }
        }
    }
}

@Composable
fun DataCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String? = null,
    accent: Color = palette.accent,
    subtitle: String? = null,
    icon: CardIcon? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val valueSize = when {
        value.length > 12 -> 19.sp
        value.length > 7 -> 23.sp
        else -> 30.sp
    }
    val titleSize = when {
        title.length >= 10 -> 10.sp
        title.length >= 7 -> 10.5f.sp
        else -> 12.sp
    }
    OemCard(palette = palette, modifier = modifier, onClick = onClick) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                if (icon != null) MetricIcon(palette, icon, accent, Modifier.size(24.dp))
                Text(title.uppercase(), color = accent, fontSize = titleSize, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Clip)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = palette.textPrimary, fontSize = valueSize, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (unit != null) {
                    Text(" $unit", color = palette.textSecondary, fontSize = 14.sp, modifier = Modifier.padding(bottom = 4.dp), maxLines = 1)
                }
            }
            if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SettingsRow(
    palette: LoganPalette,
    title: String,
    subtitle: String? = null,
    value: String? = null,
    onClick: (() -> Unit)? = null,
    trailingSwitch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceVariant.copy(alpha = .34f))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailingSwitch != null && onSwitch != null) {
            Switch(checked = trailingSwitch, onCheckedChange = onSwitch)
        } else if (value != null) {
            Text("$value  ›", color = palette.textSecondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
