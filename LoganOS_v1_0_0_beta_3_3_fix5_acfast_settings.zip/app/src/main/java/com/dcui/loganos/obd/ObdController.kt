package com.dcui.loganos.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class ObdController(private val context: Context) {
    var state by mutableStateOf(ObdState())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var socket: BluetoothSocket? = null
    private val parser = DelphiParser()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni bekleniyor. Uygulama izni verilmeden cihaz listesi okunamaz.", error = true)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            appendStatus("Bu cihazda Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        val devices = adapter.bondedDevices.orEmpty()
            .map { PairedObdDevice(it.name ?: "OBD cihazı", it.address) }
            .sortedWith(compareByDescending<PairedObdDevice> { looksLikeObd(it.name) }.thenBy { it.name })
        state = state.copy(
            pairedDevices = devices,
            status = if (devices.isEmpty()) "Eşleşmiş OBD cihazı bulunamadı" else "${devices.size} eşleşmiş cihaz bulundu",
            logText = state.logText + "\n[BT] Paired devices: ${devices.joinToString { it.displayName }}"
        )
    }

    fun selectDevice(device: PairedObdDevice) {
        state = state.copy(
            selectedAddress = device.address,
            selectedName = device.name,
            status = "Seçildi: ${device.name}",
            logText = state.logText + "\n[BT] Selected ${device.displayName}"
        )
    }

    fun connectSelected() {
        val address = state.selectedAddress
        if (address == null) {
            appendStatus("Önce vLinker MC+ / ELM327 cihazını seç.", error = true)
            return
        }
        connect(address)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni yok. Android izin ekranından izin verilmeli.", error = true)
            return
        }
        disconnect(silent = true)
        state = state.copy(connecting = true, connected = false, status = "Bluetooth bağlanıyor...", lastError = null)
        job = scope.launch {
            try {
                val streams = withTimeout(32000L) {
                    val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth adaptörü yok")
                    val device = adapter.getRemoteDevice(address)
                    withMain { appendLog("[BT] Connecting to ${device.name ?: address} / $address") }
                    adapter.cancelDiscovery()
                    val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                    socket = sock
                    sock.connect()
                    val out = sock.outputStream
                    val input = sock.inputStream
                    withMain { state = state.copy(connecting = false, connected = true, status = "Bluetooth bağlı • ELM init başlıyor") }

                    val initCommands = listOf(
                        // Alpha 1.4.9 ile çalışan Delphi DCM1.2 / VDIAG08 init dizisine yaklaştırıldı.
                        // KWP tarafında erken komut gönderip ELM'i STOPPED durumuna düşürmemek için timeoutlar genişletildi.
                        Triple("ATZ", 1000L, 2200L),
                        Triple("ATE0", 150L, 1000L),
                        Triple("ATL0", 150L, 1000L),
                        Triple("ATS1", 150L, 1000L),
                        Triple("ATH1", 150L, 1000L),
                        Triple("ATSP5", 150L, 1000L),
                        Triple("ATIIA7A", 150L, 1000L),
                        Triple("ATWM817AF1", 150L, 1000L),
                        Triple("ATSH817AF1", 150L, 1000L),
                        Triple("ATFI", 600L, 6500L),
                        Triple("10C0", 250L, 1800L)
                    )
                    initCommands.forEach { (cmd, wait, timeout) ->
                        val resp = send(out, input, cmd, wait, timeout)
                        withMain { appendLog("${if (cmd.isBlank()) "<wake>" else cmd}  =>  $resp") }
                    }
                    Pair(out, input)
                }
                withMain { state = state.copy(connecting = false, connected = true, status = "KWP test döngüsü başladı") }
                pollLoop(streams.first, streams.second)
            } catch (t: TimeoutCancellationException) {
                withMain {
                    appendStatus("Bağlantı zaman aşımı. Tekrar Bağlan ile yeniden denenebilir.", error = true)
                    state = state.copy(connecting = false, connected = false)
                }
                closeSocket()
            } catch (t: CancellationException) {
                withMain { state = state.copy(connecting = false, connected = false) }
            } catch (t: Throwable) {
                val message = t.message ?: t.javaClass.simpleName
                withMain {
                    appendStatus("Bağlantı hatası: $message", error = true)
                    state = state.copy(connecting = false, connected = false)
                }
                closeSocket()
            }
        }
    }

    fun disconnect(silent: Boolean = false) {
        job?.cancel()
        job = null
        closeSocket()
        val updated = state.copy(connecting = false, connected = false, status = if (silent) state.status else "Bağlantı kesildi")
        state = updated
        if (!silent) appendLog("[BT] Disconnected")
    }

    private suspend fun pollLoop(out: OutputStream, input: InputStream) {
        var loopIndex = 0
        var lastAtrv = ""
        while (job?.isActive == true) {
            val start = System.currentTimeMillis()
            loopIndex++

            // fix5: 21CC_FAST artık klima/fan için tek ve en hızlı kaynak.
            // Açma da kapatma da bu ilk 21CC cevabıyla UI'a yansır; ağır paketlerin sonucu bunu ezmez.
            if (loopIndex == 1 || loopIndex % 8 == 0) {
                lastAtrv = send(out, input, "ATRV", 35L, 800L)
                delay(15)
            }
            val rawCCFast = send(out, input, "21CC", 20L, 700L)
            val fastParsed = parser.parse("", "", rawCCFast, "", lastAtrv)
            val fastAc = fastParsed.acOn
            val fastFan = fastParsed.fanOn
            withMain {
                val previous = state.snapshot
                val acEvent = if (fastAc != null && fastAc != previous.acOn) {
                    "\n[AC_FAST] ${if (fastAc) "ON" else "OFF"} loop=$loopIndex raw=$rawCCFast"
                } else ""
                val fanEvent = if (fastFan != null && fastFan != previous.radiatorFanOn) {
                    "\n[FAN_FAST] ${if (fastFan) "ON" else "OFF"} loop=$loopIndex raw=$rawCCFast"
                } else ""
                val fastSnapshot = previous.copy(
                    connected = true,
                    rpm = fastParsed.rpm ?: previous.rpm,
                    acOn = fastAc ?: previous.acOn,
                    radiatorFanOn = fastFan ?: previous.radiatorFanOn,
                    batteryV = fastParsed.batteryV ?: previous.batteryV,
                    raw21CC = rawCCFast
                )
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • hızlı 21CC",
                    snapshot = fastSnapshot,
                    raw21CC = rawCCFast,
                    timingText = "fast 21CC",
                    logText = trimLog(state.logText + acEvent + fanEvent)
                )
            }
            delay(15)

            val rawA0 = send(out, input, "21A0", 45L, 1150L)
            delay(15)
            val rawCCFresh = rawCCFast

            // 21A2 ve 21CD ağır teknik paketler. fix5: canlı kokpitte seyrek okunur,
            // böylece klima/fan false durumları 21CC_FAST ile 1 döngü içinde düşer.
            val rawA2 = if (loopIndex % 10 == 0 || state.raw21A2.isBlank()) {
                send(out, input, "21A2", 45L, 1150L)
            } else state.raw21A2
            delay(15)
            val rawCD = if (loopIndex % 16 == 0 || state.raw21CD.isBlank()) {
                send(out, input, "21CD", 40L, 950L)
            } else state.raw21CD

            var stdRpm = ""
            var stdSpeed = ""
            var stdTemp = ""
            if (loopIndex % 3 == 0 && !rawA0.contains("61A0", ignoreCase = true) && !rawA0.contains("BUS INIT", ignoreCase = true)) {
                delay(30)
                stdRpm = send(out, input, "010C", 40L, 750L)
                delay(30)
                stdSpeed = send(out, input, "010D", 40L, 750L)
                delay(30)
                stdTemp = send(out, input, "0105", 40L, 750L)
            }

            val parsed = parser.parse(rawA0, rawA2, rawCCFresh, rawCD, lastAtrv, stdRpm, stdSpeed, stdTemp)
            val baseSnapshot = parsed.toSnapshot(rawA0, rawA2, rawCCFresh, rawCD, connected = true)
            val snapshot = baseSnapshot.copy(
                // 21CC_FAST cevap verdiyse klima/fan değerini final snapshot'ta da koru.
                // Böylece sonraki ağır paketler eski durumu geri yazamaz.
                acOn = fastAc ?: baseSnapshot.acOn,
                radiatorFanOn = fastFan ?: baseSnapshot.radiatorFanOn
            )
            val elapsed = System.currentTimeMillis() - start
            withMain {
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • ${elapsed} ms",
                    snapshot = snapshot,
                    raw21A0 = rawA0,
                    raw21A2 = rawA2,
                    raw21CC = rawCCFresh,
                    raw21CD = rawCD,
                    timingText = "fast 21CC • loop=${elapsed}ms",
                    logText = trimLog(state.logText + "\n[LOOP ${elapsed}ms] rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} fuel=${snapshot.injectionMg ?: "--"} ac=${snapshot.acOn ?: "--"} fan=${snapshot.radiatorFanOn ?: "--"} src=${snapshot.fuelSource}\n21CC_FAST=$rawCCFast\n21A0=$rawA0\n21A2=$rawA2\n21CD=$rawCD")
                )
            }
            delay(55)
        }
    }

    private fun send(out: OutputStream, input: InputStream, cmd: String, waitMs: Long, timeoutMs: Long): String {
        drainInput(input)
        if (cmd.isNotBlank()) {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        }
        Thread.sleep(waitMs)
        val buffer = StringBuilder()
        val start = System.currentTimeMillis()
        var gotAny = false
        var lastData = System.currentTimeMillis()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = input.available()
            if (available > 0) {
                gotAny = true
                lastData = System.currentTimeMillis()
                repeat(available) {
                    val b = input.read()
                    if (b >= 0) {
                        val ch = b.toChar()
                        buffer.append(ch)
                        if (ch == '>') return clean(buffer.toString())
                    }
                }
            } else {
                val current = buffer.toString()
                val quietFor = System.currentTimeMillis() - lastData
                // BUS INIT devam ederken erken çıkma; aksi halde bir sonraki komut ELM'i STOPPED'a düşürüyor.
                val kwpInitInProgress = current.contains("BUS INIT", ignoreCase = true) && !current.contains("OK", ignoreCase = true) && !current.contains(">")
                if (gotAny && !kwpInitInProgress && quietFor > 260L) return clean(current)
                Thread.sleep(10)
            }
        }
        return clean(buffer.toString())
    }

    private fun drainInput(input: InputStream) {
        runCatching {
            var guard = 0
            while (input.available() > 0 && guard < 4096) {
                input.read()
                guard++
            }
        }
    }

    fun saveLogFile() {
        val fileName = makeLogFileName()
        val text = state.logText.ifBlank { "Log yok" }
        val displayPath = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Download/LoganOS/$fileName"
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.mkdirs()
                val file = File(dir, fileName)
                file.writeText(text)
                file.absolutePath
            }
        }.getOrElse {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val file = File(dir, fileName)
            file.writeText(text)
            file.absolutePath
        }
        state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Log kaydedildi: $displayPath", sharedLogReady = true)
        appendLog("[LOG] Saved to $displayPath")
    }

    fun shareLogText() {
        val text = state.logText.ifBlank { "Log yok" }
        val fileName = makeLogFileName(prefix = "loganos_share")
        val shareDir = File(context.cacheDir, "log_share").apply { mkdirs() }
        val file = File(shareDir, fileName).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "LoganOS OBD Log")
            putExtra(Intent.EXTRA_TITLE, fileName)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "LoganOS log paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = state.copy(status = "Log paylaşım ekranı açıldı")
    }

    fun clearLastLogFile() {
        val fileName = state.savedLogFileName
        if (fileName.isNullOrBlank()) {
            state = state.copy(status = "Silinecek son log yok")
            return
        }
        val deleted = deleteDownloadLogByName(fileName)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = if (deleted) "Son log silindi: $fileName" else "Son log bulunamadı: $fileName"
        )
        appendLog("[LOG] Clear last requested: $fileName deleted=$deleted")
    }

    fun clearAllLogFiles() {
        val deleted = deleteAllDownloadLogs()
        state = state.copy(savedLogPath = null, savedLogFileName = null, sharedLogReady = false, status = "$deleted log dosyası silindi")
        appendLog("[LOG] Clear all requested: deleted=$deleted")
    }

    private fun makeLogFileName(prefix: String = "loganos_obd"): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS", Locale.US).format(Date())
        return "${prefix}_beta3_3_fix5_${stamp}.txt"
    }

    private fun deleteDownloadLogByName(fileName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf(fileName, Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args) > 0
            } else {
                val file = File(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS"), fileName)
                file.exists() && file.delete()
            }
        }.getOrDefault(false)
    }

    private fun deleteAllDownloadLogs(): Int {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf("loganos_%", Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.listFiles { f -> f.name.startsWith("loganos_") && f.name.endsWith(".txt") }?.count { it.delete() } ?: 0
            }
        }.getOrDefault(0)
    }

    private fun clean(text: String): String = text.replace("\r", " ").replace("\n", " ").replace(">", " > ").trim()

    private fun closeSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun appendStatus(text: String, error: Boolean = false) {
        state = state.copy(status = text, lastError = if (error) text else state.lastError, logText = trimLog(state.logText + "\n[STATUS] $text"))
    }

    private fun appendLog(text: String) {
        state = state.copy(logText = trimLog(state.logText + "\n$text"))
    }

    private suspend fun withMain(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun trimLog(log: String): String {
        return if (log.length <= 60000) log else log.takeLast(60000)
    }

    private fun looksLikeObd(name: String): Boolean {
        val n = name.lowercase()
        return listOf("obd", "elm", "vlink", "vgate", "icar", "kwp").any { it in n }
    }
}
