# LoganOS v1.0.0-beta.3.8.1 Review Prompt

This ZIP contains LoganOS Android/Kotlin/Jetpack Compose version `1.0.0-beta.3.8.1`.

Please review the project for build blockers and regressions. This version focuses on fixing the beta 3.8.0 cockpit redesign layout and setup gauge previews.

Priority checks:

1. Build blockers
- Kotlin/Compose syntax errors
- Missing imports
- Wrong function signatures
- Broken resources
- Gradle versionName/versionCode consistency

2. Cockpit layout
- Portrait Konsept 4 cockpit no longer wastes too much vertical space
- Speed/gauge block is compact enough
- Bottom navigation does not cover metric rows
- All eight core values are readable or scroll correctly
- Landscape mode still works

3. Settings wiring
- `Yazı Boyutu / Text Size` visibly changes cockpit text/value sizes
- `Kokpit Yoğunluğu / Cockpit Density` visibly changes spacing, row height and gauge block size
- These settings must not be UI-only toggles

4. Gauge styles
- Selected mappings are preserved:
  - Digital C
  - Sport C
  - Classic OEM A
  - Minimal C
  - RS Performance D
- Gauge style selection in setup uses list rows and large preview dialog
- Settings > Gauge Style still updates the actual cockpit gauge

5. Icons and logos
- Approved custom XML icons are used as resources, not redrawn manually in code
- Compose icons preserve their colors with `Color.Unspecified`
- Renault/Dacia brand logos still show in setup brand selection
- Launcher icon is not regressed

Do not suggest unnecessary refactors to:
- FuelAlgorithmV3
- TripComputer
- CUTOFF
- AC_FAST
- Delphi DCM1.2 parser byte positions
- OBD main loop
- Cranking analysis core logic
- Fuel calibration coefficient logic
- Fan UNKNOWN / test pending decision
