## v1.0.0-beta.3.8.1 - Cockpit Layout & Setup Previews

### Fixed
- Reworked the Konsept 4 cockpit proportions after beta 3.8.0.
- Reduced the portrait speed/gauge block so the metric rows fit better on phone screens.
- Added stronger bottom padding so the bottom navigation no longer visually covers the last cockpit rows.
- Made cockpit density settings actually affect card/row height, spacing and gauge area size.
- Made cockpit text size settings visibly affect cockpit metric text and value sizes.
- Improved the SpeedGauge implementation so selected gauge styles have distinct visual accents instead of only changing the stored setting.
- Replaced cramped setup gauge cards with a compact style list and large preview dialog.
- Added setup descriptions for the finalized style choices:
  - Digital C
  - Sport C
  - Classic OEM A
  - Minimal C
  - RS Performance D

### Kept
- Custom LoganOS XML icon assets are preserved and still rendered with `Color.Unspecified`.
- Renault/Dacia setup brand logo resources remain in the setup brand selection screen.
- Launcher icon keeps the OS-free LOGAN composition from the 3.8 line.
- FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, Delphi parser byte positions, fan UNKNOWN state, fuel calibration and cranking analysis core logic were not intentionally changed.
