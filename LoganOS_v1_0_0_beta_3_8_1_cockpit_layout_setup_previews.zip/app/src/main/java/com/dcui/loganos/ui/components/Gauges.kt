package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val LoganGaugeGreen = Color(0xFF107C41)

@Composable
fun SpeedGauge(palette: LoganPalette, speed: Int?, style: GaugeStyle, modifier: Modifier = Modifier, demoMode: Boolean = false) {
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / 240f).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "speedProgress"
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val gaugeSize = minOf(maxWidth, maxHeight).coerceAtMost(214.dp).coerceAtLeast(116.dp)
        val compact = maxHeight < 170.dp
        val accent = when (style) {
            GaugeStyle.Sport -> Color(0xFFFF7A00)
            GaugeStyle.ClassicOem -> Color(0xFF455A64)
            GaugeStyle.Minimal -> LoganGaugeGreen
            GaugeStyle.RsPerformance -> Color(0xFFD62828)
            GaugeStyle.Digital -> LoganGaugeGreen
        }
        Canvas(modifier = Modifier.size(gaugeSize)) {
            val radius = size.minDimension * if (style == GaugeStyle.ClassicOem) 0.40f else 0.43f
            val center = Offset(size.width / 2f, size.height * 0.58f)
            val startDeg = when (style) {
                GaugeStyle.ClassicOem -> 190f
                GaugeStyle.RsPerformance -> 200f
                else -> 205f
            }
            val sweepDeg = when (style) {
                GaugeStyle.ClassicOem -> 160f
                GaugeStyle.RsPerformance -> 140f
                else -> 130f
            }
            val tickCount = when (style) {
                GaugeStyle.Minimal -> 24
                GaugeStyle.ClassicOem -> 36
                else -> 42
            }
            val trackColor = palette.line.copy(alpha = .70f)
            val tickColor = palette.textSecondary.copy(alpha = if (style == GaugeStyle.Minimal) .18f else .26f)
            for (i in 0..tickCount) {
                val frac = i / tickCount.toFloat()
                val angle = (startDeg + sweepDeg * frac) * PI.toFloat() / 180f
                val longTick = i % 6 == 0
                val inner = radius - if (longTick) 13f else 7f
                val outer = radius
                val c = if (frac <= progress) accent.copy(alpha = .78f) else tickColor
                drawLine(
                    color = c,
                    start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                    end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                    strokeWidth = if (longTick) 2.1f else 1.2f,
                    cap = StrokeCap.Round
                )
            }
            drawArc(
                color = trackColor,
                startAngle = startDeg,
                sweepAngle = sweepDeg,
                useCenter = false,
                style = Stroke(width = if (style == GaugeStyle.RsPerformance) 2.0f else 1.1f, cap = StrokeCap.Round),
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
            )
            if (style == GaugeStyle.Sport || style == GaugeStyle.RsPerformance) {
                drawArc(
                    color = accent.copy(alpha = .62f),
                    startAngle = startDeg,
                    sweepAngle = sweepDeg * progress,
                    useCenter = false,
                    style = Stroke(width = 3.2f, cap = StrokeCap.Round),
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                text = speed?.toString() ?: "--",
                color = palette.textPrimary,
                fontSize = when {
                    compact -> if (speed == null) 42.sp else 58.sp
                    speed == null -> 50.sp
                    else -> 68.sp
                },
                fontWeight = if (style == GaugeStyle.ClassicOem) FontWeight.SemiBold else FontWeight.Light,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text("km/h", color = palette.textSecondary, fontSize = if (compact) 11.sp else 13.sp, fontWeight = FontWeight.Medium)
            Text(
                text = when { demoMode -> "DEMO"; speed == null -> "OBD BEKLENİYOR"; else -> "CANLI" },
                color = if (demoMode) palette.warning else if (speed == null) palette.critical else accent,
                fontSize = if (compact) 8.sp else 9.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    val progress = when (style) {
        GaugeStyle.Digital -> .35f
        GaugeStyle.Sport -> .78f
        GaugeStyle.ClassicOem -> .50f
        GaugeStyle.Minimal -> .00f
        GaugeStyle.RsPerformance -> .88f
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = modifier.height(156.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(104.dp)
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (style == GaugeStyle.Minimal) {
                Box(
                    modifier = Modifier
                        .size(width = 98.dp, height = 68.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.surfaceVariant.copy(alpha = .45f))
                        .border(1.dp, palette.line, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { PreviewSpeedText(palette, LoganGaugeGreen) }
            } else {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { progress },
                        color = LoganGaugeGreen,
                        trackColor = palette.line,
                        strokeWidth = 8.dp,
                        modifier = Modifier.size(88.dp)
                    )
                    PreviewSpeedText(palette, LoganGaugeGreen)
                }
            }
        }
        Text(style.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewSpeedText(palette: LoganPalette, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("42", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.size(width = 34.dp, height = 4.dp).clip(CircleShape).background(accent.copy(alpha = .70f)))
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Modern dijital"
    GaugeStyle.Sport -> "Sportif ve dinamik"
    GaugeStyle.ClassicOem -> "Analog ibre"
    GaugeStyle.Minimal -> "Sade dijital"
    GaugeStyle.RsPerformance -> "Performans"
}
