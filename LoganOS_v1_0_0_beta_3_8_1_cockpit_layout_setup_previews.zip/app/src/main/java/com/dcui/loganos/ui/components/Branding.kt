package com.dcui.loganos.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun LoganWordmark(palette: LoganPalette, modifier: Modifier = Modifier, compact: Boolean = false) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        LoganMark(palette = palette, modifier = Modifier.size(if (compact) 26.dp else 40.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = palette.textPrimary)) { append("LOGAN") }
                withStyle(SpanStyle(color = palette.accent)) { append("OS") }
            },
            fontSize = if (compact) 20.sp else 34.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun LoganMark(palette: LoganPalette, modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.loganos_mark_icon),
        contentDescription = "LoganOS",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
fun LoganSetupLogo(modifier: Modifier = Modifier) {
    Image(
        painter = painterResource(id = R.drawable.loganos_setup_logo),
        contentDescription = "LoganOS",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
fun Slogan(palette: LoganPalette, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Know Your Car.", color = palette.textSecondary, fontSize = 16.sp)
        Text("Drive Smarter.", color = palette.accent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun HeaderLine(palette: LoganPalette, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(2.dp)
            .background(Brush.horizontalGradient(listOf(Color.Transparent, palette.accent, Color.Transparent)))
    )
}
