# LoganOS

## Beta 3.8.1 Cockpit Layout & Setup Previews

This package is a follow-up polish build for the beta 3.8 cockpit redesign.

Version: `1.0.0-beta.3.8.1`

Focus areas:

- Fix Konsept 4 cockpit layout proportions after the 3.8.0 test screenshots.
- Make the speed/gauge area more compact in portrait mode.
- Keep all eight main cockpit values readable without bottom navigation overlap.
- Wire `Yazı Boyutu / Text Size` and `Kokpit Yoğunluğu / Cockpit Density` to real cockpit layout changes.
- Add large setup preview dialogs for the selected gauge styles.
- Preserve the approved custom LoganOS XML icon set.

Selected gauge style mapping:

- Digital → C
- Sport → C
- Classic OEM → A
- Minimal → C
- RS Performance → D

Commit message suggestion:

`Fix cockpit layout and setup previews`
