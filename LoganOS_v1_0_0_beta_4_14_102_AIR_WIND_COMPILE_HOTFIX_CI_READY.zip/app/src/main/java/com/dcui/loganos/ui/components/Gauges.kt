package com.dcui.loganos.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.pow

private val LoganGaugeGreen = Color(0xFF18A84F)
private val LoganGaugeRed = Color(0xFFD62828)

@Composable
fun SpeedGauge(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    modifier: Modifier = Modifier,
    demoMode: Boolean = false,
    previewMode: Boolean = false
) {
    val maxSpeed = 240f
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / maxSpeed).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "speedProgress"
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val gaugeSize = minOf(maxWidth, maxHeight)
            .coerceAtMost(340.dp)
            .coerceAtLeast(120.dp)

        // Only very small preview/landscape slots are compact now.
        // The real portrait cockpit (130/150/170dp) must keep full style identity.
        val compact = maxHeight < 110.dp

        Box(modifier = Modifier.size(gaugeSize), contentAlignment = Alignment.Center) {
            when (style) {
                GaugeStyle.Digital -> DigitalCGauge(palette, progress, compact)
                GaugeStyle.ClassicOem -> ClassicOemAGauge(palette, progress, compact)
                GaugeStyle.GhostSingle -> DigitalCGauge(palette, progress, compact)
                GaugeStyle.GhostDual -> DigitalCGauge(palette, progress, compact)
            }
            SpeedReadout(
                palette = palette,
                speed = speed,
                style = style,
                compact = compact,
                demoMode = demoMode,
                previewMode = previewMode
            )
        }
    }
}

@Composable
private fun SpeedReadout(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    compact: Boolean,
    demoMode: Boolean,
    previewMode: Boolean = false
) {
    Column(
        modifier = Modifier.offset(y = if (previewMode) 18.dp else 0.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = speed?.toString() ?: "--",
            color = palette.textPrimary,
            fontSize = when {
                previewMode -> if (speed == null) 46.sp else 58.sp
                compact -> if (speed == null) 38.sp else 48.sp
                style == GaugeStyle.ClassicOem -> 70.sp
                speed == null -> 54.sp
                else -> 70.sp
            },
            fontWeight = if (style == GaugeStyle.ClassicOem) FontWeight.SemiBold else FontWeight.Light,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        Text(
            "km/h",
            color = palette.textSecondary,
            fontSize = if (previewMode) 11.sp else if (compact) 10.sp else 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

private fun styleAccent(style: GaugeStyle, palette: LoganPalette): Color = when (style) {
    GaugeStyle.Digital -> LoganGaugeGreen
    GaugeStyle.ClassicOem -> LoganGaugeGreen
    GaugeStyle.GhostSingle -> Color(0xFF8A5BFF)
    GaugeStyle.GhostDual -> Color(0xFF8A5BFF)
}



@Composable
fun SpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    modifier: Modifier = Modifier,
    demoMode: Boolean = false,
    previewMode: Boolean = false
) {
    if (style == GaugeStyle.ClassicOem && previewMode) {
        ClassicOemSetupPreview(
            palette = palette,
            speed = speed ?: 0,
            modifier = modifier
        )
    } else if (style == GaugeStyle.Digital) {
        val progress by animateFloatAsState(
            targetValue = ((speed ?: 0) / 240f).coerceIn(0f, 1f),
            animationSpec = tween(450),
            label = "digitalSpeedPanelProgress"
        )
        DigitalSpeedPanel(
            palette = palette,
            speed = speed,
            progress = progress,
            modifier = modifier,
            demoMode = demoMode,
            previewMode = previewMode
        )
    } else {
        SpeedGauge(
            palette = palette,
            speed = speed,
            style = style,
            modifier = modifier,
            demoMode = demoMode,
            previewMode = previewMode
        )
    }
}

@Composable
fun DigitalSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean,
    textScale: Float = 1.0f,
    vehicleColor: VehicleColor = VehicleColor.CherryRed,
    vehicleVisualModel: VehicleVisualModel = VehicleVisualModel.LoganI,
    motionEnabled: Boolean = true,
    carScale: Float = 1.0f,
    rpm: Int? = null,
    scenicMode: Boolean = false
) {
    if (scenicMode && !previewMode) {
        ScenicDigitalTachometerPanel(
            palette = palette,
            speed = speed,
            rpm = rpm,
            modifier = modifier,
            vehicleColor = vehicleColor,
            vehicleVisualModel = vehicleVisualModel,
            motionEnabled = motionEnabled,
            carScale = carScale,
            textScale = textScale
        )
        return
    }
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 145.dp || maxWidth < 260.dp
        val showPreviewTitle = previewMode
        val titleHeight = if (showPreviewTitle) {
            if (compact) 20.dp else 26.dp
        } else {
            0.dp
        }
        val titleGap = if (showPreviewTitle) {
            if (compact) 2.dp else 5.dp
        } else {
            0.dp
        }
        val availableDialHeight = (maxHeight - titleHeight - titleGap - if (showPreviewTitle) 0.dp else 4.dp)
            .coerceAtLeast(1.dp)
        val widthFraction = when {
            previewMode -> 0.82f
            maxWidth < 360.dp -> 0.84f
            else -> 0.88f
        }
        val dialSize = minOf(maxWidth * widthFraction, availableDialHeight)
            .coerceAtMost(if (previewMode) 170.dp else 360.dp)
            .coerceAtLeast(1.dp)
        val safeTextScale = textScale.coerceIn(0.86f, 1.24f)
        val speedSize = ((when {
            dialSize < 90.dp -> 38
            dialSize < 125.dp -> 48
            dialSize < 165.dp -> 60
            dialSize < 205.dp -> 70
            dialSize < 275.dp -> 82
            else -> 96
        }) * safeTextScale).toInt().coerceIn(34, 112)
        val currentSpeed = speed ?: 0
        val safeCarScale = carScale.coerceIn(0.85f, 1.35f)
        val roadPhase = rememberRoadPhase(
            speedKmh = speed,
            enabled = motionEnabled && !previewMode
        )

        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (showPreviewTitle) {
                StyleTitle("HIZ", LoganGaugeGreen, compact, safeTextScale)
                Spacer(Modifier.height(titleGap))
            }
            Box(
                modifier = Modifier.size(dialSize),
                contentAlignment = Alignment.Center
            ) {
                DigitalOemGauge(palette = palette, progress = progress, compact = compact)
                PanelReadout(
                    palette = palette,
                    speed = speed,
                    accent = LoganGaugeGreen,
                    demoMode = demoMode,
                    compact = compact,
                    speedSize = if (previewMode) speedSize.coerceAtMost(58) else speedSize,
                    weight = FontWeight.Black,
                    textScale = safeTextScale,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(
                            y = when {
                                previewMode -> 14.dp
                                compact -> 4.dp
                                else -> 8.dp
                            }
                        )
                        .padding(bottom = if (previewMode) 8.dp else if (compact) 8.dp else 12.dp),
                    unitOffsetY = if (previewMode) 0.dp else if (compact) (-11).dp else (-18).dp,
                    unitTopSpacing = if (previewMode) 0.dp else 0.dp
                )
                if (!previewMode) {
                    Canvas(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .fillMaxWidth(if (compact) 0.82f else 0.96f)
                            .fillMaxHeight(if (compact) 0.30f else 0.34f)
                            .padding(bottom = if (compact) 1.dp else 3.dp)
                    ) {
                        // Wide perspective road: the previous geometry looked like two narrow guide lines
                        // behind the car. The new trapezoid uses almost the full gauge width so the road
                        // reads as a surface while keeping the vanishing point inside the speed dial.
                        val roadEdge = palette.line.copy(alpha = .90f)
                        val shoulder = LoganGaugeGreen.copy(alpha = if (currentSpeed > 0) .40f else .24f)
                        val laneColor = palette.textSecondary.copy(alpha = if (currentSpeed > 0) .82f else .50f)
                        val topY = size.height * .16f
                        val bottomY = size.height * .98f
                        val leftBottom = size.width * .015f
                        val rightBottom = size.width * .985f
                        val leftTop = size.width * .34f
                        val rightTop = size.width * .66f

                        val road = Path().apply {
                            moveTo(leftTop, topY)
                            lineTo(rightTop, topY)
                            lineTo(rightBottom, bottomY)
                            lineTo(leftBottom, bottomY)
                            close()
                        }
                        drawPath(road, palette.surfaceVariant.copy(alpha = .58f))

                        // Megane-style road: no center divider. The car stays centered and motion is
                        // read from paired left/right flowing guide segments.
                        drawLine(roadEdge, Offset(leftBottom, bottomY), Offset(leftTop, topY), 2.6f, StrokeCap.Round)
                        drawLine(roadEdge, Offset(rightBottom, bottomY), Offset(rightTop, topY), 2.6f, StrokeCap.Round)
                        repeat(7) { index ->
                            val t = ((index / 7f) + roadPhase) % 1f
                            val perspective = t * t
                            val y = topY + (bottomY - topY) * perspective
                            val leftX = leftTop + (leftBottom - leftTop) * perspective
                            val rightX = rightTop + (rightBottom - rightTop) * perspective
                            val segment = size.height * (.025f + .095f * perspective)
                            val width = 1.2f + 2.8f * perspective
                            drawLine(
                                shoulder,
                                Offset(leftX, y),
                                Offset(leftX - size.width * .012f * perspective, (y + segment).coerceAtMost(bottomY)),
                                width,
                                StrokeCap.Round
                            )
                            drawLine(
                                shoulder,
                                Offset(rightX, y),
                                Offset(rightX + size.width * .012f * perspective, (y + segment).coerceAtMost(bottomY)),
                                width,
                                StrokeCap.Round
                            )
                        }
                    }
                    Image(
                        painter = painterResource(vehicleVisualDrawableRes(vehicleVisualModel, vehicleColor, VehicleAssetStyle.OemSimplified)),
                        contentDescription = null,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .offset(x = 0.dp)
                            .fillMaxWidth((if (compact) 0.20f else 0.23f) * safeCarScale)
                            .fillMaxHeight((if (compact) 0.19f else 0.22f) * safeCarScale)
                            .padding(bottom = if (compact) 1.dp else 3.dp),
                        contentScale = ContentScale.Fit
                    )
                }
            }
        }
    }
}


@Composable
private fun ScenicDigitalTachometerPanel(
    palette: LoganPalette,
    speed: Int?,
    rpm: Int?,
    modifier: Modifier,
    vehicleColor: VehicleColor,
    vehicleVisualModel: VehicleVisualModel,
    motionEnabled: Boolean,
    carScale: Float,
    textScale: Float
) {
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(24.dp)),
        contentAlignment = Alignment.Center
    ) {
        val targetRatio = 1846f / 852f
        val stageWidth = minOf(maxWidth, maxHeight * targetRatio)
        val stageHeight = stageWidth / targetRatio
        val currentSpeed = speed ?: 0
        val targetRpm = (rpm ?: 0).coerceIn(0, 7000) / 7000f
        val animatedRpm by animateFloatAsState(
            targetValue = targetRpm,
            animationSpec = tween(360),
            label = "scenicRpmProgress"
        )
        val roadPhase = rememberRoadPhase(
            speedKmh = speed,
            enabled = motionEnabled
        )
        val moving = motionEnabled && currentSpeed >= 5
        val motionStrength = when {
            !moving -> 0f
            currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
            currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
            currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
            else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
        }.coerceIn(0f, 1f)
        val safeCarScale = carScale.coerceIn(0.86f, 1.05f)
        val safeTextScale = textScale.coerceIn(0.88f, 1.12f)
        val bobWave = if (moving) {
            sin((roadPhase * 2f * PI.toFloat()).toDouble()).toFloat()
        } else {
            0f
        }
        val swayWave = if (moving) {
            sin((roadPhase * 4f * PI.toFloat() + 0.85f).toDouble()).toFloat()
        } else {
            0f
        }

        BoxWithConstraints(
            modifier = Modifier
                .width(stageWidth)
                .height(stageHeight)
                .clip(RoundedCornerShape(24.dp)),
            contentAlignment = Alignment.Center
        ) {
            val sceneWidth = maxWidth
            val sceneHeight = maxHeight
            val compactScene = sceneHeight < 170.dp
            val rpmOffset = if (compactScene) (-22).dp else (-30).dp
            val speedOffset = if (compactScene) (-15).dp else (-22).dp
            val capsuleWidth = (sceneWidth * .28f).coerceIn(118.dp, 172.dp)
            val capsuleHeight = (sceneHeight * .205f).coerceIn(54.dp, 72.dp)
            val vehicleWidth = sceneWidth * (.174f * safeCarScale)
            val vehicleBob = sceneHeight * ((0.00055f + 0.00072f * motionStrength) * bobWave)
            val vehicleSway = sceneWidth * ((0.00024f + 0.00032f * motionStrength) * swayWave)

            Image(
                painter = painterResource(R.drawable.digital_scenic_road_lake_v3),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
            Canvas(modifier = Modifier.fillMaxSize()) {
                val horizonY = size.height * 0.748f
                val bottomY = size.height * 0.998f
                val centerX = size.width * 0.500f
                val farHalfWidth = size.width * 0.045f
                val nearHalfWidth = size.width * 0.492f

                fun perspective(depth: Float): Float = depth.coerceIn(0f, 1f).pow(2.25f)

                fun roadPoint(depth: Float, lateral: Float): Offset {
                    val safeDepth = depth.coerceIn(0f, 1f)
                    val p = perspective(safeDepth)
                    val halfWidth = farHalfWidth + (nearHalfWidth - farHalfWidth) * p
                    val y = horizonY + (bottomY - horizonY) * p
                    return Offset(centerX + halfWidth * lateral, y)
                }

                fun buildRoadClip(lateralInset: Float): Path = Path().apply {
                    val leftNear = roadPoint(1f, -lateralInset)
                    moveTo(leftNear.x, leftNear.y)
                    for (step in 23 downTo 0) {
                        val point = roadPoint(step / 24f, -lateralInset)
                        lineTo(point.x, point.y)
                    }
                    for (step in 0..24) {
                        val point = roadPoint(step / 24f, lateralInset)
                        lineTo(point.x, point.y)
                    }
                    close()
                }

                fun drawPerspectiveGuide(lateral: Float, alpha: Float) {
                    for (step in 0 until 28) {
                        val d0 = step / 28f
                        val d1 = (step + 1) / 28f
                        val p = perspective((d0 + d1) * 0.5f)
                        drawLine(
                            color = Color.White.copy(alpha = alpha * (0.42f + 0.58f * p)),
                            start = roadPoint(d0, lateral),
                            end = roadPoint(d1, lateral),
                            strokeWidth = 0.8.dp.toPx() + 3.0.dp.toPx() * p,
                            cap = StrokeCap.Round
                        )
                    }
                }

                fun drawAirWind(left: Boolean) {
                    val sideMinX = if (left) size.width * 0.05f else size.width * 0.73f
                    val sideMaxX = if (left) size.width * 0.28f else size.width * 0.95f
                    val yMin = size.height * 0.15f
                    val yMax = size.height * 0.43f
                    val dir = if (left) 1f else -1f

                    repeat(6) { index ->
                        val phase = ((roadPhase * 1.15f) + index * 0.17f + if (left) 0.06f else 0.11f) % 1f
                        val lane = index / 5f
                        val laneX = (0.16f + 0.68f * lane).coerceIn(0f, 1f)
                        val startX = sideMinX + (sideMaxX - sideMinX) * laneX +
                            dir * size.width * 0.018f * phase
                        val windWave = kotlin.math.sin(
                            ((roadPhase * 6.28318f) + index.toFloat()).toDouble()
                        ).toFloat()
                        val startY = yMin + (yMax - yMin) * lane +
                            size.height * 0.012f * windWave
                        val length = size.width * (0.028f + 0.020f * lane)
                        val rise = size.height * (0.004f + 0.005f * lane)
                        val end = Offset(startX + dir * length, startY - rise)
                        val start = Offset(startX, startY)
                        val alpha = (0.028f + 0.042f * lane) * motionStrength
                        val core = 0.9.dp.toPx() + 0.8.dp.toPx() * lane
                        val glow = core * 2.6f
                        drawLine(
                            color = Color(0xFFF8FBFF).copy(alpha = alpha * 0.35f),
                            start = start,
                            end = end,
                            strokeWidth = glow,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color(0xFFEAF4FF).copy(alpha = alpha),
                            start = start,
                            end = end,
                            strokeWidth = core,
                            cap = StrokeCap.Round
                        )
                    }
                }

                val roadClip = buildRoadClip(1f)
                val asphaltMatte = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x66394247),
                        Color(0x8843494F),
                        Color(0xA64C5157)
                    ),
                    startY = horizonY,
                    endY = bottomY
                )

                if (moving) {
                    drawAirWind(left = true)
                    drawAirWind(left = false)
                }

                clipPath(roadClip) {
                    drawRect(brush = asphaltMatte, size = size)
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color(0x44D7D4C1),
                                Color(0x18E0DCC8),
                                Color.Transparent
                            ),
                            startY = horizonY - size.height * 0.01f,
                            endY = horizonY + size.height * 0.10f
                        ),
                        topLeft = Offset(0f, horizonY - size.height * 0.01f),
                        size = Size(size.width, size.height * 0.12f)
                    )

                    // Side guide lines removed. Road edge identity now comes only from the base scenic asset.

                    // Static center dashes keep the road readable when demo is off.
                    repeat(7) { index ->
                        val depth = 0.05f + index * 0.12f
                        val p = perspective(depth)
                        val endDepth = (depth + 0.030f + 0.070f * p).coerceAtMost(0.98f)
                        drawLine(
                            color = Color.White.copy(alpha = if (moving) 0.14f + 0.08f * p else 0.54f + 0.18f * p),
                            start = roadPoint(depth, 0f),
                            end = roadPoint(endDepth, 0f),
                            strokeWidth = 0.9.dp.toPx() + 3.6.dp.toPx() * p,
                            cap = StrokeCap.Round
                        )
                    }

                    if (moving) {
                        // Main center motion: clearly runs from horizon to vehicle.
                        repeat(8) { index ->
                            val depth = ((index / 8f) + roadPhase) % 1f
                            val p = perspective(depth)
                            val endDepth = depth + 0.038f + 0.118f * p
                            if (endDepth <= 0.985f) {
                                val alpha = (0.36f + 0.58f * p).coerceAtMost(0.94f) * motionStrength
                                val width = 1.2.dp.toPx() + 7.8.dp.toPx() * p
                                val start = roadPoint(depth, 0f)
                                val end = roadPoint(endDepth, 0f)
                                drawLine(
                                    color = Color(0xFFFFE8A6).copy(alpha = alpha),
                                    start = start,
                                    end = end,
                                    strokeWidth = width,
                                    cap = StrokeCap.Round
                                )
                                drawLine(
                                    color = Color.White.copy(alpha = (alpha * 0.34f).coerceAtMost(0.34f)),
                                    start = start,
                                    end = end,
                                    strokeWidth = (width * 0.34f).coerceAtLeast(1f),
                                    cap = StrokeCap.Round
                                )
                            }
                        }

                        // Side motion visuals removed intentionally; center lane stays the primary motion anchor.

                        // Asphalt streaks reinforce forward travel without moving the lake itself.
                        listOf(-0.52f, -0.30f, 0.30f, 0.52f).forEachIndexed { laneIndex, lateral ->
                            repeat(5) { index ->
                                val depth = ((index / 5f) + roadPhase + laneIndex * 0.048f) % 1f
                                val p = perspective(depth)
                                if (p > 0.08f) {
                                    val endDepth = depth + 0.014f + 0.072f * p
                                    if (endDepth <= 0.99f) {
                                        drawLine(
                                            color = Color(0xFFE9EEF1).copy(alpha = ((0.018f + 0.085f * p) * motionStrength).coerceAtMost(0.10f)),
                                            start = roadPoint(depth, lateral),
                                            end = roadPoint(endDepth, lateral),
                                            strokeWidth = 0.6.dp.toPx() + 1.7.dp.toPx() * p,
                                            cap = StrokeCap.Round
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Image(
                painter = painterResource(R.drawable.digital_rpm_shell_dacia_x100),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .offset(y = rpmOffset),
                contentScale = ContentScale.FillBounds
            )

            Canvas(modifier = Modifier.fillMaxSize()) {
                val assetScale = size.width / 1846f
                val rpmOffsetPx = rpmOffset.toPx()
                val center = Offset(923f * assetScale, 650f * assetScale + rpmOffsetPx)
                val radius = 500f * assetScale
                val arcTopLeft = Offset(center.x - radius, center.y - radius)
                val arcSize = Size(radius * 2f, radius * 2f)
                val activeColor = if (animatedRpm >= (6000f / 7000f)) {
                    Color(0xFFFF554C)
                } else {
                    Color(0xFF4D9CFF)
                }
                if (animatedRpm > .002f) {
                    drawArc(
                        color = activeColor.copy(alpha = .82f),
                        startAngle = 160f,
                        sweepAngle = 220f * animatedRpm,
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = 4.2.dp.toPx(), cap = StrokeCap.Round)
                    )
                    drawArc(
                        color = Color.White.copy(alpha = .98f),
                        startAngle = 160f + (220f * animatedRpm) - 1.5f,
                        sweepAngle = 3f,
                        useCenter = false,
                        topLeft = arcTopLeft,
                        size = arcSize,
                        style = Stroke(width = 5.0.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = speedOffset)
                    .width(capsuleWidth)
                    .height(capsuleHeight)
                    .clip(RoundedCornerShape(999.dp))
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                Color(0xFF233342).copy(alpha = .34f),
                                Color(0xFF2E4354).copy(alpha = .20f),
                                Color.Transparent
                            )
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = speed?.toString() ?: "--",
                        color = Color.White.copy(alpha = .99f),
                        fontSize = ((if (compactScene) 36f else 43f) * safeTextScale).sp,
                        lineHeight = ((if (compactScene) 37f else 44f) * safeTextScale).sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color(0xD02A3440),
                                offset = Offset(0f, 1.4f),
                                blurRadius = 7f
                            )
                        )
                    )
                    Text(
                        text = "km/h",
                        color = Color.White.copy(alpha = .98f),
                        fontSize = ((if (compactScene) 10.5f else 12.0f) * safeTextScale).sp,
                        lineHeight = ((if (compactScene) 11f else 12.5f) * safeTextScale).sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        style = TextStyle(
                            shadow = Shadow(
                                color = Color(0xB02A3440),
                                offset = Offset(0f, 0.9f),
                                blurRadius = 4.6f
                            )
                        )
                    )
                }
            }

            Image(
                painter = painterResource(R.drawable.digital_vehicle_contact_shadow_v3),
                contentDescription = null,
                modifier = Modifier
                    .fillMaxSize()
                    .offset(x = vehicleSway * .20f, y = vehicleBob * .10f + if (compactScene) 2.dp else 4.dp),
                contentScale = ContentScale.FillBounds
            )

            Image(
                painter = painterResource(
                    vehicleVisualDrawableRes(
                        vehicleVisualModel,
                        vehicleColor,
                        VehicleAssetStyle.Detailed
                    )
                ),
                contentDescription = null,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(x = vehicleSway, y = vehicleBob + if (compactScene) 4.dp else 6.dp)
                    .width(vehicleWidth),
                contentScale = ContentScale.Fit
            )
        }
    }
}

@Composable
private fun ClassicOemSetupPreview(
    palette: LoganPalette,
    speed: Int,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val previewWidth = minOf(maxWidth * 0.72f, 520.dp)
        val previewHeight = minOf(maxHeight * 0.96f, 164.dp)
        Box(
            modifier = Modifier
                .width(previewWidth)
                .height(previewHeight),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height * 0.78f)
                val radiusX = size.width * 0.43f
                val radiusY = size.height * 0.68f
                val start = 180f
                val sweep = 180f
                drawArc(
                    color = palette.line.copy(alpha = .86f),
                    startAngle = start,
                    sweepAngle = sweep,
                    useCenter = false,
                    style = Stroke(width = 2.1f, cap = StrokeCap.Round),
                    topLeft = Offset(center.x - radiusX, center.y - radiusY),
                    size = Size(radiusX * 2f, radiusY * 2f)
                )
                for (i in 0..40) {
                    val fraction = i / 40f
                    val angle = (start + sweep * fraction) * PI.toFloat() / 180f
                    val major = i % 10 == 0
                    val innerScale = if (major) 0.82f else 0.90f
                    drawLine(
                        color = if (major) Color(0xFF30343A) else palette.textSecondary.copy(alpha = .42f),
                        start = Offset(
                            center.x + cos(angle) * radiusX * innerScale,
                            center.y + sin(angle) * radiusY * innerScale
                        ),
                        end = Offset(
                            center.x + cos(angle) * radiusX,
                            center.y + sin(angle) * radiusY
                        ),
                        strokeWidth = if (major) 2.8f else 1.2f,
                        cap = StrokeCap.Round
                    )
                }
                listOf(0 to "0", 25 to "50", 50 to "100", 75 to "150", 100 to "200").forEach { (percent, label) ->
                    val fraction = percent / 100f
                    val angle = (start + sweep * fraction) * PI.toFloat() / 180f
                    val position = Offset(
                        center.x + cos(angle) * radiusX * 0.70f,
                        center.y + sin(angle) * radiusY * 0.70f
                    )
                    drawContext.canvas.nativeCanvas.drawText(label, position.x, position.y + 5f, Paint().apply {
                        isAntiAlias = true
                        color = Color(0xFF30343A).toArgb()
                        textSize = if (label.length >= 3) 17f else 19f
                        textAlign = Paint.Align.CENTER
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
                    })
                }
                val progress = (speed / 200f).coerceIn(0f, 1f)
                val needleAngle = (start + sweep * progress) * PI.toFloat() / 180f
                drawLine(
                    color = LoganGaugeGreen,
                    start = center,
                    end = Offset(
                        center.x + cos(needleAngle) * radiusX * 0.76f,
                        center.y + sin(needleAngle) * radiusY * 0.76f
                    ),
                    strokeWidth = 4.8f,
                    cap = StrokeCap.Round
                )
                drawCircle(LoganGaugeGreen, radius = 6.5f, center = center)
                drawLine(
                    palette.textSecondary.copy(alpha = .45f),
                    Offset(size.width * .36f, size.height * .91f),
                    Offset(size.width * .64f, size.height * .91f),
                    1.5f,
                    StrokeCap.Round
                )
                drawTextNative("E", Offset(size.width * .32f, size.height * .86f), 13f, LoganGaugeRed)
                drawTextNative("F", Offset(size.width * .68f, size.height * .86f), 13f, LoganGaugeGreen)
            }
            Column(
                modifier = Modifier.offset(y = previewHeight * 0.10f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = speed.toString(),
                    color = palette.textPrimary,
                    fontSize = 50.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                    maxLines = 1
                )
                Text(
                    text = "km/h",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun ClassicOemSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 125.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StyleTitle("CLASSIC OEM", Color(0xFF30343A), compact)
            Box(modifier = Modifier.fillMaxWidth(.98f).fillMaxHeight(.86f), contentAlignment = Alignment.Center) {
                ClassicOemAGauge(palette, progress, false)
            }
        }
    }
}

@Composable
private fun StyleTitle(text: String, accent: Color, compact: Boolean, textScale: Float = 1.0f) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.width(if (compact) 22.dp else 30.dp).height(1.dp).background(accent.copy(alpha = .60f)))
        Text(
            text = text,
            color = accent,
            fontSize = ((if (compact) 14f else 18f) * textScale.coerceIn(0.86f, 1.16f)).sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.1.sp,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
        Box(Modifier.width(if (compact) 22.dp else 30.dp).height(1.dp).background(accent.copy(alpha = .60f)))
    }
}

@Composable
private fun PanelReadout(
    palette: LoganPalette,
    speed: Int?,
    accent: Color,
    demoMode: Boolean,
    compact: Boolean,
    speedSize: Int,
    weight: FontWeight,
    textScale: Float = 1.0f,
    modifier: Modifier = Modifier,
    unitOffsetY: Dp = 0.dp,
    unitTopSpacing: Dp = 0.dp
) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            text = speed?.toString() ?: "--",
            color = palette.textPrimary,
            fontSize = (if (compact) (speedSize * .74f) else speedSize.toFloat()).sp,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        Spacer(Modifier.height(unitTopSpacing))
        Text(
            "km/h",
            color = palette.textSecondary,
            fontSize = ((if (compact) 10f else 13f) * textScale.coerceIn(0.86f, 1.16f)).sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.offset(y = unitOffsetY)
        )
    }
}

@Composable
fun DigitalOemGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val diameter = size.minDimension
        if (diameter <= 1f) return@Canvas

        val strokeW = if (compact) 4.dp.toPx() else 6.dp.toPx()
        val inset = strokeW / 2f + 3.dp.toPx()
        val arcDiameter = (diameter - inset * 2f).coerceAtLeast(1f)
        val arcSize = Size(arcDiameter, arcDiameter)
        val topLeft = Offset(
            x = (size.width - diameter) / 2f + inset,
            y = (size.height - diameter) / 2f + inset
        )
        val center = Offset(topLeft.x + arcDiameter / 2f, topLeft.y + arcDiameter / 2f)
        val radius = arcDiameter / 2f
        val startAngle = 140f
        val sweepAngle = 260f
        val safeProgress = progress.coerceIn(0f, 1f)

        // Static OEM skeleton remains visible at zero speed.
        drawArc(
            color = palette.line.copy(alpha = .72f),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = strokeW, cap = StrokeCap.Round)
        )

        val tickCount = 26
        val tickOuter = radius - strokeW * .35f
        for (i in 0..tickCount) {
            val fraction = i / tickCount.toFloat()
            val radians = (startAngle + sweepAngle * fraction) * PI.toFloat() / 180f
            val major = i % 5 == 0
            val tickLength = if (major) diameter * .055f else diameter * .032f
            val inner = tickOuter - tickLength
            drawLine(
                color = palette.textSecondary.copy(alpha = if (major) .42f else .22f),
                start = Offset(center.x + cos(radians) * inner, center.y + sin(radians) * inner),
                end = Offset(center.x + cos(radians) * tickOuter, center.y + sin(radians) * tickOuter),
                strokeWidth = if (major) 1.5.dp.toPx() else .9.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        if (safeProgress > 0f) {
            drawArc(
                color = LoganGaugeGreen,
                startAngle = startAngle,
                sweepAngle = sweepAngle * safeProgress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokeW, cap = StrokeCap.Round)
            )
        }

        // A restrained start marker gives the zero-speed gauge a clear origin.
        val startRadians = startAngle * PI.toFloat() / 180f
        drawCircle(
            color = LoganGaugeGreen,
            radius = strokeW * .62f,
            center = Offset(
                center.x + cos(startRadians) * radius,
                center.y + sin(startRadians) * radius
            )
        )
    }
}

@Composable
private fun DigitalCGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    DigitalOemGauge(palette, progress, compact)
}

@Composable
private fun ClassicOemAGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height * .70f)
        val radius = size.minDimension * .50f
        val start = 180f
        val sweep = 180f
        drawArc(
            color = palette.line.copy(alpha = .75f),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            style = Stroke(width = 1.6f, cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2)
        )
        for (i in 0..60) {
            val frac = i / 60f
            val angle = (start + sweep * frac) * PI.toFloat() / 180f
            val major = i % 10 == 0
            val inner = radius - if (major) 20f else 10f
            val outer = radius
            drawLine(
                color = if (major) Color(0xFF2E333A) else palette.textSecondary.copy(alpha = .35f),
                start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                strokeWidth = if (major) 2.6f else 1.1f,
                cap = StrokeCap.Round
            )
        }
        val labels = listOf(0 to "0", 25 to "50", 50 to "100", 75 to "150", 100 to "200")
        val labelRadiusOffset = if (compact) 28f else 36f
        val labelSize = if (compact) 13f else 19f
        labels.forEach { (pct, text) ->
            val frac = pct / 100f
            val angle = (start + sweep * frac) * PI.toFloat() / 180f
            val p = Offset(center.x + cos(angle) * (radius - labelRadiusOffset), center.y + sin(angle) * (radius - labelRadiusOffset))
            drawContext.canvas.nativeCanvas.drawText(text, p.x, p.y + 4f, Paint().apply {
                isAntiAlias = true
                color = Color(0xFF30343A).toArgb()
                textSize = labelSize
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            })
        }
        val angle = (start + sweep * progress) * PI.toFloat() / 180f
        drawLine(LoganGaugeGreen, center, Offset(center.x + cos(angle) * (radius - 18f), center.y + sin(angle) * (radius - 18f)), if (compact) 3.2f else 4.6f, StrokeCap.Round)
        drawCircle(LoganGaugeGreen, radius = if (compact) 4f else 6.5f, center = center)
        // Small fuel scale detail, matching Classic OEM A reference.
        drawLine(palette.textSecondary.copy(alpha = .40f), Offset(size.width * .32f, size.height * .88f), Offset(size.width * .68f, size.height * .88f), 1.7f, StrokeCap.Round)
        drawTextNative("E", Offset(size.width * .27f, size.height * .80f), 14f, LoganGaugeRed)
        drawTextNative("F", Offset(size.width * .73f, size.height * .80f), 14f, LoganGaugeGreen)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArcTicks(
    center: Offset,
    radius: Float,
    startDeg: Float,
    sweepDeg: Float,
    tickCount: Int,
    progress: Float,
    activeColor: Color,
    inactiveColor: Color,
    activeWidth: Float = 2.0f
) {
    for (i in 0..tickCount) {
        val frac = i / tickCount.toFloat()
        val angle = (startDeg + sweepDeg * frac) * PI.toFloat() / 180f
        val longTick = i % 5 == 0
        val inner = radius - if (longTick) 18f else 10f
        val outer = radius
        val c = if (frac <= progress) activeColor.copy(alpha = .88f) else inactiveColor
        drawLine(
            color = c,
            start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
            end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
            strokeWidth = if (longTick) activeWidth else 1.1f,
            cap = StrokeCap.Round
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTextNative(text: String, pos: Offset, sizePx: Float, color: Color) {
    drawContext.canvas.nativeCanvas.drawText(text, pos.x, pos.y, Paint().apply {
        isAntiAlias = true
        this.color = color.toArgb()
        textSize = sizePx
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    })
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    val accent = styleAccent(style, palette)
    Column(
        modifier = modifier.height(262.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(palette.surfaceVariant.copy(alpha = .38f))
                .border(1.dp, if (selected) accent.copy(alpha = .70f) else palette.line, RoundedCornerShape(24.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            when (style) {
                GaugeStyle.GhostSingle,
                GaugeStyle.GhostDual -> Image(
                    painter = painterResource(
                        if (style == GaugeStyle.GhostSingle) {
                            R.drawable.ghost_single_logan_oem_19_5_9
                        } else {
                            R.drawable.ghost_dual_logan_oem_19_5_9
                        }
                    ),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().height(170.dp)
                )

                GaugeStyle.Digital,
                GaugeStyle.ClassicOem -> SpeedPanel(
                    palette = palette,
                    speed = 90,
                    style = style,
                    modifier = Modifier.fillMaxWidth(.96f).height(170.dp),
                    demoMode = false,
                    previewMode = true
                )
            }
        }
        Text(style.label, color = if (selected) accent else palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewSpeedText(palette: LoganPalette, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("42", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.size(width = 34.dp, height = 4.dp).clip(CircleShape).background(accent.copy(alpha = .70f)))
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Digital C • modern dijital"
    GaugeStyle.ClassicOem -> "Classic OEM A • analog ibre"
    GaugeStyle.GhostSingle -> "Ghost Single • 0–200 km/h"
    GaugeStyle.GhostDual -> "Ghost Dual • çift kadran"
}
