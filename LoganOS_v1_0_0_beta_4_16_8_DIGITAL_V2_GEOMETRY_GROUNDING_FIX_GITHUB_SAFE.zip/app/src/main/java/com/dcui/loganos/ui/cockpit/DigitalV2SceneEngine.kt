package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import com.dcui.loganos.R
import com.dcui.loganos.ui.components.rememberScenicMotionPhases
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Digital V2 uses one fixed stage coordinate space for every scene.
 * New scene assets must be exported at the same aspect ratio and obey the
 * same road contract. This removes device-dependent ContentScale.Crop drift.
 */
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO = 1080f / 1320f

internal data class DigitalV2RoadSlice(
    val y: Float,
    val leftX: Float,
    val rightX: Float
)

internal data class DigitalV2SceneSpec(
    val backgroundRes: Int,
    val stageAspectRatio: Float,
    val roadSlices: List<DigitalV2RoadSlice>,
    val vehicleContactY: Float,
    /** Visible body width as a fixed fraction of stage width; independent from road width. */
    val vehicleVisibleWidthRatio: Float,
    /** Position across the road: 0 = left edge, 0.5 = centre line, 1 = right edge. */
    val vehicleLanePosition: Float,
    val windStartY: Float,
    val windEndY: Float,
    val roadLineIntensity: Float = 1f,
    val windIntensity: Float = 1f,
    val roadBlurIntensity: Float = 1f,
    val vehicleAssetVisibleWidthRatio: Float = 0.864f,
    val vehicleAssetContactYRatio: Float = 0.906f
) {
    init {
        require(stageAspectRatio > 0f)
        require(roadSlices.size >= 4)
        require(roadSlices.zipWithNext().all { (a, b) -> b.y > a.y })
        require(roadSlices.all { it.leftX < it.rightX })
        require(vehicleContactY in roadSlices.first().y..roadSlices.last().y)
        require(vehicleVisibleWidthRatio in 0.15f..0.45f)
        require(vehicleLanePosition in 0f..1f)
        require(windStartY < windEndY)
        require(windStartY >= roadSlices.first().y)
        require(windEndY <= roadSlices.last().y)
    }

    fun roadAt(y: Float): DigitalV2RoadSlice {
        val clampedY = y.coerceIn(roadSlices.first().y, roadSlices.last().y)
        val segment = roadSlices.indexOfLast { it.y <= clampedY }
            .coerceIn(0, roadSlices.lastIndex - 1)
        val a = roadSlices[segment]
        val b = roadSlices[segment + 1]
        val dy = (b.y - a.y).coerceAtLeast(0.0001f)
        val t = ((clampedY - a.y) / dy).coerceIn(0f, 1f)

        fun valueAt(index: Int, selector: (DigitalV2RoadSlice) -> Float): Float {
            val i0 = (index - 1).coerceAtLeast(0)
            val i1 = index
            val i2 = (index + 1).coerceAtMost(roadSlices.lastIndex)
            val i3 = (index + 2).coerceAtMost(roadSlices.lastIndex)
            val p0 = selector(roadSlices[i0])
            val p1 = selector(roadSlices[i1])
            val p2 = selector(roadSlices[i2])
            val p3 = selector(roadSlices[i3])
            val t2 = t * t
            val t3 = t2 * t
            return 0.5f * (
                (2f * p1) +
                    (-p0 + p2) * t +
                    (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                    (-p0 + 3f * p1 - 3f * p2 + p3) * t3
                )
        }

        val left = valueAt(segment) { it.leftX }
        val right = valueAt(segment) { it.rightX }
        return DigitalV2RoadSlice(
            y = clampedY,
            leftX = left.coerceIn(-0.08f, 1.08f),
            rightX = right.coerceIn(-0.08f, 1.08f)
        )
    }
}

/**
 * Every road edge below is measured against the exported 1080x1320 asset.
 * The same normalized geometry is used on every phone and head unit.
 */
internal val DigitalV2MountainLakeSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_mountain_lake_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    roadSlices = listOf(
        DigitalV2RoadSlice(0.425f, 0.620f, 0.660f),
        DigitalV2RoadSlice(0.455f, 0.570f, 0.700f),
        DigitalV2RoadSlice(0.490f, 0.485f, 0.760f),
        DigitalV2RoadSlice(0.530f, 0.405f, 0.815f),
        DigitalV2RoadSlice(0.580f, 0.310f, 0.885f),
        DigitalV2RoadSlice(0.640f, 0.185f, 0.965f),
        DigitalV2RoadSlice(0.700f, 0.070f, 1.020f),
        DigitalV2RoadSlice(0.800f, -0.020f, 1.060f),
        DigitalV2RoadSlice(1.000f, -0.060f, 1.080f)
    ),
    vehicleContactY = 0.905f,
    vehicleVisibleWidthRatio = 0.315f,
    vehicleLanePosition = 0.640f,
    windStartY = 0.500f,
    windEndY = 0.820f,
    roadLineIntensity = 1.12f,
    windIntensity = 1.12f,
    roadBlurIntensity = 0.92f
)

internal val DigitalV2CityDaySceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_day_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    roadSlices = listOf(
        DigitalV2RoadSlice(0.435f, 0.490f, 0.510f),
        DigitalV2RoadSlice(0.465f, 0.450f, 0.550f),
        DigitalV2RoadSlice(0.500f, 0.330f, 0.670f),
        DigitalV2RoadSlice(0.535f, 0.130f, 0.870f),
        DigitalV2RoadSlice(0.570f, 0.020f, 0.980f),
        DigitalV2RoadSlice(0.650f, -0.030f, 1.030f),
        DigitalV2RoadSlice(1.000f, -0.050f, 1.050f)
    ),
    vehicleContactY = 0.905f,
    vehicleVisibleWidthRatio = 0.315f,
    vehicleLanePosition = 0.640f,
    windStartY = 0.485f,
    windEndY = 0.800f,
    roadLineIntensity = 1.08f,
    windIntensity = 1.08f,
    roadBlurIntensity = 1.00f
)

internal val DigitalV2CityNightSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_night_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    roadSlices = listOf(
        DigitalV2RoadSlice(0.435f, 0.490f, 0.510f),
        DigitalV2RoadSlice(0.470f, 0.440f, 0.560f),
        DigitalV2RoadSlice(0.500f, 0.300f, 0.700f),
        DigitalV2RoadSlice(0.535f, 0.080f, 0.920f),
        DigitalV2RoadSlice(0.570f, -0.010f, 1.010f),
        DigitalV2RoadSlice(0.650f, -0.030f, 1.030f),
        DigitalV2RoadSlice(1.000f, -0.050f, 1.050f)
    ),
    vehicleContactY = 0.905f,
    vehicleVisibleWidthRatio = 0.315f,
    vehicleLanePosition = 0.640f,
    windStartY = 0.485f,
    windEndY = 0.800f,
    roadLineIntensity = 1.22f,
    windIntensity = 1.20f,
    roadBlurIntensity = 1.12f
)

internal val DigitalV2SnowRoadSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_snow_road_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    roadSlices = listOf(
        DigitalV2RoadSlice(0.470f, 0.470f, 0.530f),
        DigitalV2RoadSlice(0.500f, 0.440f, 0.570f),
        DigitalV2RoadSlice(0.540f, 0.400f, 0.630f),
        DigitalV2RoadSlice(0.580f, 0.340f, 0.690f),
        DigitalV2RoadSlice(0.630f, 0.270f, 0.760f),
        DigitalV2RoadSlice(0.680f, 0.180f, 0.840f),
        DigitalV2RoadSlice(0.740f, 0.080f, 0.940f),
        DigitalV2RoadSlice(0.820f, -0.020f, 1.030f),
        DigitalV2RoadSlice(1.000f, -0.050f, 1.060f)
    ),
    vehicleContactY = 0.905f,
    vehicleVisibleWidthRatio = 0.315f,
    vehicleLanePosition = 0.640f,
    windStartY = 0.520f,
    windEndY = 0.820f,
    roadLineIntensity = 1.16f,
    windIntensity = 1.14f,
    roadBlurIntensity = 0.86f
)

internal fun digitalV2SceneSpec(scene: com.dcui.loganos.model.DigitalV2Scene): DigitalV2SceneSpec = when (scene) {
    com.dcui.loganos.model.DigitalV2Scene.MountainLake -> DigitalV2MountainLakeSceneSpec
    com.dcui.loganos.model.DigitalV2Scene.CityDay -> DigitalV2CityDaySceneSpec
    com.dcui.loganos.model.DigitalV2Scene.CityNight -> DigitalV2CityNightSceneSpec
    com.dcui.loganos.model.DigitalV2Scene.SnowRoad -> DigitalV2SnowRoadSceneSpec
}

internal data class DigitalV2SceneMotion(
    val moving: Boolean,
    val roadPhase: Float,
    val motionStrength: Float,
    val suspensionLift: Float,
    val swayWave: Float,
    val shadowScaleX: Float,
    val shadowScaleY: Float,
    val shadowAlpha: Float
)

@Composable
internal fun rememberDigitalV2SceneMotion(
    speedKmh: Int?,
    enabled: Boolean
): DigitalV2SceneMotion {
    val currentSpeed = speedKmh ?: 0
    val scenic = rememberScenicMotionPhases(speedKmh = speedKmh, enabled = enabled)
    val moving = enabled && currentSpeed >= 5
    val motionStrength = when {
        !moving -> 0f
        currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
        currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
        currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
        else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
    }.coerceIn(0f, 1f)

    val dynamicsAngle = scenic.dynamicsTime * 2f * PI.toFloat()
    val bobWave = if (moving) {
        val primary = sin(dynamicsAngle.toDouble()).toFloat()
        val secondary = 0.30f * sin((dynamicsAngle * 2.70f + 0.62f).toDouble()).toFloat()
        val bodySettle = 0.14f * sin((dynamicsAngle * 0.57f + 1.38f).toDouble()).toFloat()
        (primary + secondary + bodySettle) / 1.44f
    } else {
        0f
    }
    val asphaltMicroWave = if (moving) {
        val coarse = sin((dynamicsAngle * 12f + 0.20f).toDouble()).toFloat()
        val fine = sin((dynamicsAngle * 18.40f + 1.15f).toDouble()).toFloat()
        (coarse * 0.68f + fine * 0.32f) * (0.08f + 0.07f * motionStrength)
    } else {
        0f
    }
    val suspensionLift = (bobWave + asphaltMicroWave).coerceIn(-1.20f, 1.20f)
    val swayWave = if (moving) {
        val slowWeightShift = 0.68f * sin((dynamicsAngle * 0.71f + 0.85f).toDouble()).toFloat()
        val secondaryRoll = 0.22f * sin((dynamicsAngle * 1.93f + 2.10f).toDouble()).toFloat()
        val roadCorrection = 0.10f * sin((dynamicsAngle * 4.40f + 0.22f).toDouble()).toFloat()
        slowWeightShift + secondaryRoll + roadCorrection
    } else {
        0f
    }

    return DigitalV2SceneMotion(
        moving = moving,
        roadPhase = scenic.roadPhase,
        motionStrength = motionStrength,
        suspensionLift = suspensionLift,
        swayWave = swayWave,
        shadowScaleX = (1f + suspensionLift * 0.013f).coerceIn(0.984f, 1.018f),
        shadowScaleY = (1f + suspensionLift * 0.006f).coerceIn(0.992f, 1.009f),
        shadowAlpha = (0.94f - suspensionLift * 0.10f).coerceIn(0.80f, 1f)
    )
}

private data class RoadFrame(
    val point: Offset,
    val tangent: Offset,
    val roadWidthPx: Float,
    val yNorm: Float,
    val cumulativePx: Float
)

private fun buildRoadFrames(
    spec: DigitalV2SceneSpec,
    widthPx: Float,
    heightPx: Float,
    sampleCount: Int = 160
): List<RoadFrame> {
    val yStart = spec.roadSlices.first().y
    val yEnd = spec.roadSlices.last().y
    val raw = ArrayList<RoadFrame>(sampleCount + 1)
    var cumulative = 0f
    var previousPoint: Offset? = null

    repeat(sampleCount + 1) { index ->
        val t = index / sampleCount.toFloat()
        val y = yStart + (yEnd - yStart) * t
        val road = spec.roadAt(y)
        val centerX = (road.leftX + road.rightX) * 0.5f
        val point = Offset(centerX * widthPx, y * heightPx)
        previousPoint?.let { previous ->
            val dx = point.x - previous.x
            val dy = point.y - previous.y
            cumulative += sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        raw += RoadFrame(
            point = point,
            tangent = Offset.Zero,
            roadWidthPx = (road.rightX - road.leftX) * widthPx,
            yNorm = y,
            cumulativePx = cumulative
        )
        previousPoint = point
    }

    return raw.mapIndexed { index, frame ->
        val before = raw[(index - 1).coerceAtLeast(0)].point
        val after = raw[(index + 1).coerceAtMost(raw.lastIndex)].point
        val dx = after.x - before.x
        val dy = after.y - before.y
        val length = sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(0.001f)
        frame.copy(tangent = Offset(dx / length, dy / length))
    }
}

private fun frameAtArc(frames: List<RoadFrame>, normalizedArc: Float): RoadFrame {
    val total = frames.last().cumulativePx.coerceAtLeast(1f)
    val target = normalizedArc.coerceIn(0f, 1f) * total
    var low = 0
    var high = frames.lastIndex
    while (low < high) {
        val mid = (low + high) ushr 1
        if (frames[mid].cumulativePx < target) low = mid + 1 else high = mid
    }
    val upperIndex = low.coerceIn(1, frames.lastIndex)
    val lower = frames[upperIndex - 1]
    val upper = frames[upperIndex]
    val span = (upper.cumulativePx - lower.cumulativePx).coerceAtLeast(0.001f)
    val t = ((target - lower.cumulativePx) / span).coerceIn(0f, 1f)
    fun lerp(a: Float, b: Float) = a + (b - a) * t
    val tangentX = lerp(lower.tangent.x, upper.tangent.x)
    val tangentY = lerp(lower.tangent.y, upper.tangent.y)
    val tangentLength = sqrt((tangentX * tangentX + tangentY * tangentY).toDouble()).toFloat().coerceAtLeast(0.001f)
    return RoadFrame(
        point = Offset(lerp(lower.point.x, upper.point.x), lerp(lower.point.y, upper.point.y)),
        tangent = Offset(tangentX / tangentLength, tangentY / tangentLength),
        roadWidthPx = lerp(lower.roadWidthPx, upper.roadWidthPx),
        yNorm = lerp(lower.yNorm, upper.yNorm),
        cumulativePx = target
    )
}

private fun roadPoint(frame: RoadFrame, lateral: Float): Offset {
    val normal = Offset(-frame.tangent.y, frame.tangent.x)
    val offset = frame.roadWidthPx * lateral * 0.5f
    return Offset(
        frame.point.x + normal.x * offset,
        frame.point.y + normal.y * offset
    )
}

private fun buildRoadMask(
    spec: DigitalV2SceneSpec,
    frames: List<RoadFrame>,
    widthPx: Float,
    heightPx: Float
): Path {
    val mask = Path()
    val rightPoints = ArrayList<Offset>(frames.size)
    frames.forEachIndexed { index, frame ->
        val road = spec.roadAt(frame.yNorm)
        val left = Offset(road.leftX * widthPx, frame.yNorm * heightPx)
        val right = Offset(road.rightX * widthPx, frame.yNorm * heightPx)
        if (index == 0) mask.moveTo(left.x, left.y) else mask.lineTo(left.x, left.y)
        rightPoints += right
    }
    rightPoints.asReversed().forEach { point -> mask.lineTo(point.x, point.y) }
    mask.close()
    return mask
}

@Composable
internal fun DigitalV2RoadLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val frames = buildRoadFrames(spec, size.width, size.height)
        val roadMask = buildRoadMask(spec, frames, size.width, size.height)

        clipPath(roadMask) {
            /*
             * A restrained speed-blur layer. It never blurs the whole photo;
             * only short translucent asphalt streaks inside the measured road
             * polygon are drawn. This preserves clarity while adding motion.
             */
            if (motion.moving && motion.motionStrength > 0.03f) {
                val laterals = floatArrayOf(-0.39f, -0.24f, -0.10f, 0.10f, 0.24f, 0.39f)
                repeat(24) { index ->
                    val arc = ((index / 24f) + motion.roadPhase * 1.12f + (index % 5) * 0.031f) % 1f
                    val frame = frameAtArc(frames, arc)
                    val depth = ((frame.yNorm - spec.roadSlices.first().y) /
                        (spec.roadSlices.last().y - spec.roadSlices.first().y)).coerceIn(0f, 1f)
                    if (depth > 0.34f) {
                        val lateral = laterals[index % laterals.size]
                        val endArc = (arc + 0.010f + 0.040f * depth).coerceAtMost(0.995f)
                        if (endArc > arc) {
                            val endFrame = frameAtArc(frames, endArc)
                            val startPoint = roadPoint(frame, lateral)
                            val endPoint = roadPoint(endFrame, lateral)
                            val fadeIn = ((depth - 0.34f) / 0.30f).coerceIn(0f, 1f)
                            val alpha = (0.025f + 0.080f * depth) *
                                motion.motionStrength * spec.roadBlurIntensity * fadeIn
                            val broadWidth = 5.5.dp.toPx() + 12.dp.toPx() * depth
                            drawLine(
                                color = Color(0xFFEAF3FA).copy(alpha = (alpha * 0.42f).coerceAtMost(0.075f)),
                                start = startPoint,
                                end = endPoint,
                                strokeWidth = broadWidth,
                                cap = StrokeCap.Round,
                                blendMode = BlendMode.Screen
                            )
                            drawLine(
                                color = Color.White.copy(alpha = (alpha * 0.82f).coerceAtMost(0.12f)),
                                start = startPoint,
                                end = endPoint,
                                strokeWidth = (0.7.dp.toPx() + 1.8.dp.toPx() * depth),
                                cap = StrokeCap.Round,
                                blendMode = BlendMode.Screen
                            )
                        }
                    }
                }
            }

            /* The centre divider remains visible from the vanishing point to the foreground. */
            val activePhase = if (motion.moving) motion.roadPhase else 0f
            val dashCount = 11
            repeat(dashCount) { index ->
                val arc = ((index / dashCount.toFloat()) + activePhase) % 1f
                val frame = frameAtArc(frames, arc)
                val depth = ((frame.yNorm - spec.roadSlices.first().y) /
                    (spec.roadSlices.last().y - spec.roadSlices.first().y)).coerceIn(0f, 1f)
                val dashArcLength = (0.022f + 0.070f * depth.pow(1.55f)).coerceAtMost(0.105f)
                val endArc = (arc + dashArcLength).coerceAtMost(0.997f)
                if (endArc > arc) {
                    val dash = Path()
                    repeat(8) { step ->
                        val s = arc + (endArc - arc) * (step / 7f)
                        val point = frameAtArc(frames, s).point
                        if (step == 0) dash.moveTo(point.x, point.y) else dash.lineTo(point.x, point.y)
                    }
                    val horizonFade = ((arc - 0.005f) / 0.105f).coerceIn(0f, 1f)
                    val foregroundFade = ((1f - arc) / 0.028f).coerceIn(0f, 1f)
                    val baseAlpha = if (motion.moving) 0.58f + 0.34f * depth else 0.46f + 0.26f * depth
                    val movement = if (motion.moving) (0.72f + 0.28f * motion.motionStrength) else 1f
                    val alpha = (baseAlpha * horizonFade * foregroundFade * movement * spec.roadLineIntensity)
                        .coerceIn(0f, 0.98f)
                    val width = (frame.roadWidthPx * (0.0075f + 0.0070f * depth)).coerceAtLeast(1.2f)

                    drawPath(
                        path = dash,
                        color = Color(0xFFFFC744).copy(alpha = alpha * 0.18f),
                        style = Stroke(width = width * 3.2f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = dash,
                        color = Color(0xFFFFD85E).copy(alpha = alpha),
                        style = Stroke(width = width, cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = dash,
                        color = Color(0xFFFFF4C4).copy(alpha = alpha * 0.55f),
                        style = Stroke(width = (width * 0.30f).coerceAtLeast(0.9f), cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                }
            }
        }
    }
}

@Composable
internal fun DigitalV2WindLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        if (!motion.moving || motion.motionStrength <= 0.02f) return@Canvas

        fun buildWindClip(left: Boolean): Path = Path().apply {
            val steps = 20
            val startY = spec.windStartY
            val endY = spec.windEndY
            if (left) {
                moveTo(0f, startY * size.height)
                val first = spec.roadAt(startY)
                lineTo(first.leftX * size.width, startY * size.height)
                repeat(steps + 1) { index ->
                    val y = startY + (endY - startY) * index / steps.toFloat()
                    val road = spec.roadAt(y)
                    lineTo(road.leftX * size.width, y * size.height)
                }
                lineTo(0f, endY * size.height)
            } else {
                moveTo(size.width, startY * size.height)
                val first = spec.roadAt(startY)
                lineTo(first.rightX * size.width, startY * size.height)
                repeat(steps + 1) { index ->
                    val y = startY + (endY - startY) * index / steps.toFloat()
                    val road = spec.roadAt(y)
                    lineTo(road.rightX * size.width, y * size.height)
                }
                lineTo(size.width, endY * size.height)
            }
            close()
        }

        fun drawRoadShoulderWind(left: Boolean) {
            val direction = if (left) -1f else 1f
            val clip = buildWindClip(left)
            val phaseOffset = if (left) 0.06f else 0.14f
            val strength = (0.70f + 0.30f * motion.motionStrength) * spec.windIntensity

            clipPath(clip) {
                repeat(8) { index ->
                    val variant = index % 4
                    val phase = (motion.roadPhase * (0.82f + 0.035f * variant) +
                        index / 8f + phaseOffset + variant * 0.021f) % 1f
                    val flow = phase.pow(1.22f)
                    val fade = sin((phase * PI.toFloat()).toDouble()).toFloat()
                        .coerceAtLeast(0f).pow(3.2f)
                    val yNorm = spec.windStartY + (spec.windEndY - spec.windStartY) * flow
                    val road = spec.roadAt(yNorm)
                    val roadWidth = (road.rightX - road.leftX) * size.width
                    val shoulderX = (if (left) road.leftX else road.rightX) * size.width
                    val wave = sin((motion.roadPhase * (7.2f + variant) + index * 1.13f).toDouble()).toFloat()
                    val anchorX = shoulderX + direction * roadWidth * (0.014f + 0.010f * variant)
                    val length = size.width * (0.052f + 0.085f * flow) * (0.90f + variant * 0.055f)
                    val tailX = anchorX - direction * length * 0.18f
                    val headX = anchorX + direction * length * 0.82f
                    val baseY = yNorm * size.height + wave * size.height * 0.0045f
                    val lift = size.height * (0.005f + 0.007f * flow)
                    val gust = Path().apply {
                        moveTo(tailX, baseY)
                        cubicTo(
                            tailX + direction * length * 0.28f,
                            baseY - lift,
                            tailX + direction * length * 0.70f,
                            baseY + lift * 0.45f,
                            headX,
                            baseY + lift * 0.22f
                        )
                    }
                    val alpha = ((0.24f + 0.16f * flow) * fade * strength).coerceAtMost(0.46f)
                    val coreWidth = (0.72.dp.toPx() + 1.20.dp.toPx() * flow) * (0.92f + variant * 0.06f)

                    drawPath(
                        path = gust,
                        color = Color(0xFFCCE8FF).copy(alpha = alpha * 0.10f),
                        style = Stroke(width = coreWidth * 7.0f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color(0xFFE5F3FF).copy(alpha = alpha * 0.24f),
                        style = Stroke(width = coreWidth * 2.6f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color.White.copy(alpha = alpha * 0.58f),
                        style = Stroke(width = coreWidth * 0.62f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                }
            }
        }

        drawRoadShoulderWind(left = true)
        drawRoadShoulderWind(left = false)
    }
}

@Composable
internal fun DigitalV2CalibrationOverlay(
    spec: DigitalV2SceneSpec,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    if (!enabled) return
    Canvas(modifier) {
        repeat(11) { index ->
            val x = size.width * index / 10f
            val y = size.height * index / 10f
            drawLine(Color.Red.copy(alpha = 0.38f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(Color.Yellow.copy(alpha = 0.38f), Offset(0f, y), Offset(size.width, y), 1f)
        }
        val left = Path()
        val center = Path()
        val right = Path()
        repeat(100) { index ->
            val y = spec.roadSlices.first().y +
                (spec.roadSlices.last().y - spec.roadSlices.first().y) * index / 99f
            val road = spec.roadAt(y)
            val leftP = Offset(road.leftX * size.width, y * size.height)
            val centerP = Offset((road.leftX + road.rightX) * 0.5f * size.width, y * size.height)
            val rightP = Offset(road.rightX * size.width, y * size.height)
            if (index == 0) {
                left.moveTo(leftP.x, leftP.y)
                center.moveTo(centerP.x, centerP.y)
                right.moveTo(rightP.x, rightP.y)
            } else {
                left.lineTo(leftP.x, leftP.y)
                center.lineTo(centerP.x, centerP.y)
                right.lineTo(rightP.x, rightP.y)
            }
        }
        drawPath(left, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(right, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(center, Color.Cyan, style = Stroke(2.dp.toPx()))
        val contact = spec.roadAt(spec.vehicleContactY)
        val centerX = (contact.leftX + contact.rightX) * 0.5f * size.width
        val contactY = spec.vehicleContactY * size.height
        drawCircle(Color.Magenta, 6.dp.toPx(), Offset(centerX, contactY))
    }
}

