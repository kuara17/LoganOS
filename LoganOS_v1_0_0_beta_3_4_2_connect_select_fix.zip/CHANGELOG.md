## v1.0.0-beta.3.4.1 - Log Row Cleanup

- Removed action words like Onay/Paylaş/Oluştur from Log & Destek rows.
- Log rows are now cleaner clickable rows with only a subtle chevron.
- Fuel Truth Core from beta.3.4 is preserved.

## v1.0.0-beta.3.4 - Fuel Truth Core

- DC UI Alpha ve Pydroid loglarıyla doğrulanan Delphi DCM1.2 alanları Kotlin parser'a eklendi: pedal %, MAP, requested MAP, air charge, emme/yakıt sıcaklığı, rail/rail hedef, sensor supply V ve ECU akü voltajı.
- FuelAlgorithmV3 Kotlin çekirdeği eklendi: CUTOFF, CRANK_GUARD, INJECTION, HOLD, MAF_FALLBACK, MAP_FALLBACK ve NONE kaynak seçimi.
- BASIC_INJECTION sabit kaynak yazısı yerine gerçek fuelSource seçimi kullanılmaya başlandı.
- Pedal/MAP/Air/Rail gibi değerler Teknik sekmeye ve Fuel Truth paneline eklendi.
- ATRV adaptör voltajı ECU akü voltajından ayrı tutuldu.
- Fan durumu kanıtlanmadığı için UNKNOWN kalmaya devam eder; fan decode geri getirilmedi.
- TripComputer ve SQLite/Room kayıt sistemi bu sürüme eklenmedi; sonraki aşamaya bırakıldı.

## v1.0.0-beta.3.3-fix11 - Settings Cleanup + Data Trust

- Ayarlar kartları daha belirgin hale getirildi.
- Bağlantı & Veri ekranı sadeleştirildi; OBD kartı ve Log & Destek grubu düzenlendi.
- Log & Destek işlemleri dört satıra indirildi: Test Logu Kaydet, Son Test Logunu Paylaş, Tüm Logları Temizle, Destek Paketi Oluştur.
- Son Logu Sil, Verileri Dışa Aktar ve Tüm Verileri Sil bu ekrandan kaldırıldı.
- Tüm Logları Temizle ve Kurulum Sihirbazını Yeniden Başlat için onay penceresi eklendi.
- Kurulum sıfırlama Araç & Bakım bölümüne taşındı.
- SpeedGauge sabit 168dp ölçüye kilitlenmeyecek şekilde düzeltildi.
- Kanıtlanmamış fan biti kaldırıldı; Fan kartı Bilinmiyor/-- gösterir.
- FAN_FAST logları kaldırıldı.

## v1.0.0-beta.3.3-fix11 - Logos, Tech Tab, Gauge Balance

- Kurulum marka ekranında Dacia ve Renault logo çizimleri marka formuna göre yeniden düzenlendi.
- Teknik sekmeden tekrar eden OBD bağlantı paneli kaldırıldı.
- OBD bağlantı yönetimi sadece Ayarlar > Bağlantı & Veri altında toplandı.
- Teknik sekme canlı ECU/decoder verileri, protokol, loop ve ham cevap ekranı olarak sadeleştirildi.
- Hız kadranı açık temada daha okunur olacak şekilde yeniden oranlandı.
- Kokpit ikonları kart içinde daha büyük ve okunur çizilecek şekilde büyütüldü.

## v1.0.0-beta.3.3-fix11 - Brand Logos

- Kurulum marka ekranında Dacia kartı için uygulamanın mevcut DC/LoganOS amblemi kullanıldı.
- Renault için LoganOS tasarım diline uygun özgün çift şeritli baklava logo eklendi.
- Marka kartı logo/yazı hizası güncel düzen üzerinde korundu.

## v1.0.0-beta.3.3-fix11 - AC Fast Loop + Settings Polish

- 21CC_FAST klima/fan için ana kaynak yapıldı.
- Klima kapatmada gecikme azaltıldı: false durumu 21CC_FAST ile hemen UI snapshotına yazılır.
- 21A2 ve 21CD ağır teknik paketleri seyrekleştirildi.
- Döngü beklemeleri kısaltıldı; loga AC_FAST / FAN_FAST olay satırları eklendi.
- Dikey Ayarlar ekranında dar sol menü biraz genişletildi, ikonlar büyütüldü.
- Ayarlar içerik kartında başlık/alt açıklama düzeni ve satır görünümü daha premium hale getirildi.
- Önceki fix4 ikon renk paketi korunur.
