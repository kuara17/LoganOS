package com.dcui.loganos.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.Brand
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.HeadUnitUiMode
import com.dcui.loganos.model.DefaultMediaApp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.VehicleProfileSupport
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel

data class FuelCalibrationProgress(
    val accumulatedDistanceKm: Double = 0.0,
    val accumulatedFuelLiters: Double = 0.0,
    val lastTripToken: Long = 0L,
    val lastTripDistanceKm: Double = 0.0,
    val lastTripFuelLiters: Double = 0.0
)

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("loganos_settings", Context.MODE_PRIVATE)

    fun load(): LoganSettings {
        return LoganSettings(
            setupCompleted = prefs.getBoolean(KEY_SETUP, false),
            language = prefs.getEnum(KEY_LANGUAGE, AppLanguage.Turkish),
            brand = prefs.getEnum(KEY_BRAND, Brand.Dacia),
            vehicleModel = prefs.getString(KEY_MODEL, "Dacia Logan") ?: "Dacia Logan",
            engine = prefs.getString(KEY_ENGINE, "1.5 dCi 68 bg") ?: "1.5 dCi 68 bg",
            fuelType = prefs.getEnum(KEY_FUEL_TYPE, FuelType.Diesel),
            profileSupport = prefs.getEnum(KEY_PROFILE_SUPPORT, VehicleProfileSupport.Verified),
            modelYearText = prefs.getString(KEY_MODEL_YEAR, "2006") ?: "2006",
            engineCodeText = prefs.getString(KEY_ENGINE_CODE, "K9K") ?: "K9K",
            engineDisplacementCcText = prefs.getString(KEY_ENGINE_CC, "1461") ?: "1461",
            enginePowerHpText = prefs.getString(KEY_ENGINE_HP, "68") ?: "68",
            cylinderCount = prefs.getInt(KEY_CYLINDER_COUNT, 4).coerceIn(1, 12),
            experimentalProfileAccepted = prefs.getBoolean(KEY_EXPERIMENTAL_PROFILE_ACCEPTED, false),
            deviceMode = prefs.getEnum(KEY_DEVICE, DeviceMode.Auto),
            headUnitUiMode = prefs.getEnum(KEY_HEAD_UNIT_UI_MODE, HeadUnitUiMode.Standard),
            defaultMediaApp = prefs.getEnum(KEY_DEFAULT_MEDIA_APP, DefaultMediaApp.Aimp),
            gaugeStyle = loadGaugeStyle(),
            vehicleVisualModel = prefs.getEnum(KEY_VEHICLE_VISUAL_MODEL, VehicleVisualModel.LoganI),
            vehicleColor = prefs.getEnum(KEY_VEHICLE_COLOR, VehicleColor.CherryRed),
            ghostDualSpeedOnLeft = prefs.getBoolean(KEY_GHOST_DUAL_SPEED_ON_LEFT, false),
            cockpitTextSize = prefs.getEnum(KEY_COCKPIT_TEXT_SIZE, CockpitTextSize.Normal),
            cockpitDensity = prefs.getEnum(KEY_COCKPIT_DENSITY, CockpitDensity.Balanced),
            accentColor = prefs.getEnum(KEY_ACCENT, AccentColor.OemGreen),
            darkMode = prefs.getBoolean(KEY_DARK, false),
            keepScreenOn = prefs.getBoolean(KEY_KEEP_SCREEN, true),
            backgroundTripEnabled = prefs.getBoolean(KEY_BACKGROUND_TRIP, true),
            gpsRouteEnabled = prefs.getBoolean(KEY_GPS_ROUTE_ENABLED, false),
            gpsMaskExportEdges = prefs.getBoolean(KEY_GPS_MASK_EXPORT_EDGES, true),
            smartTripMinutes = prefs.getInt(KEY_SMART_TRIP, 60),
            driveHistoryEnabled = prefs.getBoolean(KEY_DRIVE_HISTORY_ENABLED, true),
            driveHistoryLimit = prefs.getInt(KEY_DRIVE_HISTORY_LIMIT, 10),
            testHistoryEnabled = prefs.getBoolean(KEY_TEST_HISTORY_ENABLED, true),
            testHistoryLimit = prefs.getInt(KEY_TEST_HISTORY_LIMIT, 10),
            demoMode = prefs.getBoolean(KEY_DEMO_MODE, false),
            disclaimerAccepted = prefs.getBoolean(KEY_DISCLAIMER, false),
            fuelPriceText = prefs.getString(KEY_FUEL_PRICE, "") ?: "",
            odometerText = prefs.getString(KEY_ODOMETER, "335420") ?: "335420",
            oilServiceKm = prefs.getString(KEY_OIL_SERVICE, "10000") ?: "10000",
            fuelFilterKm = prefs.getString(KEY_FUEL_FILTER, "20000") ?: "20000",
            airFilterKm = prefs.getString(KEY_AIR_FILTER, "10000") ?: "10000",
            pollenFilterKm = prefs.getString(KEY_POLLEN_FILTER, "10000") ?: "10000",
            timingBeltKm = prefs.getString(KEY_TIMING_BELT, "60000") ?: "60000",
            developerModeEnabled = prefs.getBoolean(KEY_DEVELOPER_MODE, false),
            rawEcuLogEnabled = prefs.getBoolean(KEY_RAW_ECU_LOG, false),
            longTripLogEnabled = prefs.getBoolean(KEY_LONG_TRIP_LOG, false),
            fuelCalibrationEnabled = prefs.getBoolean(KEY_FUEL_CAL_ENABLED, false),
            fuelCalibrationFactor = Double.fromBits(prefs.getLong(KEY_FUEL_CAL_FACTOR, 1.0.toBits())),
            fuelCalibrationAppLitersText = prefs.getString(KEY_FUEL_CAL_APP_L, "") ?: "",
            fuelCalibrationPumpLitersText = prefs.getString(KEY_FUEL_CAL_PUMP_L, "") ?: "",
            fuelCalibrationWarningAccepted = prefs.getBoolean(KEY_FUEL_CAL_WARNING, false),
            fuelCalibrationSessionActive = prefs.getBoolean(KEY_FUEL_CAL_SESSION_ACTIVE, false),
            fuelCalibrationStartDistanceKm = Double.fromBits(prefs.getLong(KEY_FUEL_CAL_START_DISTANCE, 0.0.toBits())),
            fuelCalibrationStartFuelLiters = Double.fromBits(prefs.getLong(KEY_FUEL_CAL_START_FUEL, 0.0.toBits())),
            fuelCalibrationStartTripToken = prefs.getLong(KEY_FUEL_CAL_START_TRIP_TOKEN, 0L),
            fuelCalibrationStartOdometerKm = prefs.getInt(KEY_FUEL_CAL_START_ODOMETER, 0),
            fuelCalibrationStartTimeMs = prefs.getLong(KEY_FUEL_CAL_START_TIME, 0L),
            fuelCalibrationSessionFactor = Double.fromBits(prefs.getLong(KEY_FUEL_CAL_SESSION_FACTOR, 1.0.toBits())),
            avgResetDistanceKm = Double.fromBits(prefs.getLong(KEY_AVG_RESET_DISTANCE, 0.0.toBits())),
            avgResetFuelLiters = Double.fromBits(prefs.getLong(KEY_AVG_RESET_FUEL, 0.0.toBits())),
            costResetFuelLiters = Double.fromBits(prefs.getLong(KEY_COST_RESET_FUEL, 0.0.toBits())),
            avgResetTripToken = prefs.getLong(KEY_AVG_RESET_TRIP_TOKEN, 0L),
            costResetTripToken = prefs.getLong(KEY_COST_RESET_TRIP_TOKEN, 0L)
        )
    }

    private fun loadGaugeStyle(): GaugeStyle {
        val stored = prefs.getString(KEY_GAUGE, GaugeStyle.Digital.name)
        return when (stored) {
            GaugeStyle.ClassicOem.name -> GaugeStyle.ClassicOem
            GaugeStyle.GhostSingle.name -> GaugeStyle.GhostSingle
            GaugeStyle.GhostDual.name -> GaugeStyle.GhostDual
            GaugeStyle.Digital.name -> GaugeStyle.Digital
            // beta.4.7.3.2: retired cockpit styles migrate safely to Digital OEM.
            "Minimal", "Sport", "RsPerformance" -> {
                prefs.edit().putString(KEY_GAUGE, GaugeStyle.Digital.name).apply()
                GaugeStyle.Digital
            }
            else -> GaugeStyle.Digital
        }
    }

    fun save(settings: LoganSettings) {
        prefs.edit()
            .putBoolean(KEY_SETUP, settings.setupCompleted)
            .putString(KEY_LANGUAGE, settings.language.name)
            .putString(KEY_BRAND, settings.brand.name)
            .putString(KEY_MODEL, settings.vehicleModel)
            .putString(KEY_ENGINE, settings.engine)
            .putString(KEY_FUEL_TYPE, settings.fuelType.name)
            .putString(KEY_PROFILE_SUPPORT, settings.profileSupport.name)
            .putString(KEY_MODEL_YEAR, settings.modelYearText)
            .putString(KEY_ENGINE_CODE, settings.engineCodeText)
            .putString(KEY_ENGINE_CC, settings.engineDisplacementCcText)
            .putString(KEY_ENGINE_HP, settings.enginePowerHpText)
            .putInt(KEY_CYLINDER_COUNT, settings.cylinderCount)
            .putBoolean(KEY_EXPERIMENTAL_PROFILE_ACCEPTED, settings.experimentalProfileAccepted)
            .putString(KEY_DEVICE, settings.deviceMode.name)
            .putString(KEY_HEAD_UNIT_UI_MODE, settings.headUnitUiMode.name)
            .putString(KEY_DEFAULT_MEDIA_APP, settings.defaultMediaApp.name)
            .putString(KEY_GAUGE, settings.gaugeStyle.name)
            .putString(KEY_VEHICLE_VISUAL_MODEL, settings.vehicleVisualModel.name)
            .putString(KEY_VEHICLE_COLOR, settings.vehicleColor.name)
            .putBoolean(KEY_GHOST_DUAL_SPEED_ON_LEFT, settings.ghostDualSpeedOnLeft)
            .putString(KEY_COCKPIT_TEXT_SIZE, settings.cockpitTextSize.name)
            .putString(KEY_COCKPIT_DENSITY, settings.cockpitDensity.name)
            .putString(KEY_ACCENT, settings.accentColor.name)
            .putBoolean(KEY_DARK, settings.darkMode)
            .putBoolean(KEY_KEEP_SCREEN, settings.keepScreenOn)
            .putBoolean(KEY_BACKGROUND_TRIP, settings.backgroundTripEnabled)
            .putBoolean(KEY_GPS_ROUTE_ENABLED, settings.gpsRouteEnabled)
            .putBoolean(KEY_GPS_MASK_EXPORT_EDGES, settings.gpsMaskExportEdges)
            .putInt(KEY_SMART_TRIP, settings.smartTripMinutes)
            .putBoolean(KEY_DRIVE_HISTORY_ENABLED, settings.driveHistoryEnabled)
            .putInt(KEY_DRIVE_HISTORY_LIMIT, settings.driveHistoryLimit)
            .putBoolean(KEY_TEST_HISTORY_ENABLED, settings.testHistoryEnabled)
            .putInt(KEY_TEST_HISTORY_LIMIT, settings.testHistoryLimit)
            .putBoolean(KEY_DEMO_MODE, false) // Demo is deliberately session-only.
            .putBoolean(KEY_DISCLAIMER, settings.disclaimerAccepted)
            .putString(KEY_FUEL_PRICE, settings.fuelPriceText)
            .putString(KEY_ODOMETER, settings.odometerText)
            .putString(KEY_OIL_SERVICE, settings.oilServiceKm)
            .putString(KEY_FUEL_FILTER, settings.fuelFilterKm)
            .putString(KEY_AIR_FILTER, settings.airFilterKm)
            .putString(KEY_POLLEN_FILTER, settings.pollenFilterKm)
            .putString(KEY_TIMING_BELT, settings.timingBeltKm)
            .putBoolean(KEY_DEVELOPER_MODE, settings.developerModeEnabled)
            .putBoolean(KEY_RAW_ECU_LOG, settings.rawEcuLogEnabled)
            .putBoolean(KEY_LONG_TRIP_LOG, settings.longTripLogEnabled)
            .putBoolean(KEY_FUEL_CAL_ENABLED, settings.fuelCalibrationEnabled)
            .putLong(KEY_FUEL_CAL_FACTOR, settings.fuelCalibrationFactor.toBits())
            .putString(KEY_FUEL_CAL_APP_L, settings.fuelCalibrationAppLitersText)
            .putString(KEY_FUEL_CAL_PUMP_L, settings.fuelCalibrationPumpLitersText)
            .putBoolean(KEY_FUEL_CAL_WARNING, settings.fuelCalibrationWarningAccepted)
            .putBoolean(KEY_FUEL_CAL_SESSION_ACTIVE, settings.fuelCalibrationSessionActive)
            .putLong(KEY_FUEL_CAL_START_DISTANCE, settings.fuelCalibrationStartDistanceKm.toBits())
            .putLong(KEY_FUEL_CAL_START_FUEL, settings.fuelCalibrationStartFuelLiters.toBits())
            .putLong(KEY_FUEL_CAL_START_TRIP_TOKEN, settings.fuelCalibrationStartTripToken)
            .putInt(KEY_FUEL_CAL_START_ODOMETER, settings.fuelCalibrationStartOdometerKm)
            .putLong(KEY_FUEL_CAL_START_TIME, settings.fuelCalibrationStartTimeMs)
            .putLong(KEY_FUEL_CAL_SESSION_FACTOR, settings.fuelCalibrationSessionFactor.toBits())
            .putLong(KEY_AVG_RESET_DISTANCE, settings.avgResetDistanceKm.toBits())
            .putLong(KEY_AVG_RESET_FUEL, settings.avgResetFuelLiters.toBits())
            .putLong(KEY_COST_RESET_FUEL, settings.costResetFuelLiters.toBits())
            .putLong(KEY_AVG_RESET_TRIP_TOKEN, settings.avgResetTripToken)
            .putLong(KEY_COST_RESET_TRIP_TOKEN, settings.costResetTripToken)
            .apply()
    }


    fun isFuelCalibrationSessionActive(): Boolean =
        prefs.getBoolean(KEY_FUEL_CAL_SESSION_ACTIVE, false)

    fun loadFuelCalibrationProgress(): FuelCalibrationProgress = FuelCalibrationProgress(
        accumulatedDistanceKm = Double.fromBits(
            prefs.getLong(KEY_FUEL_CAL_PROGRESS_DISTANCE, 0.0.toBits())
        ).coerceAtLeast(0.0),
        accumulatedFuelLiters = Double.fromBits(
            prefs.getLong(KEY_FUEL_CAL_PROGRESS_FUEL, 0.0.toBits())
        ).coerceAtLeast(0.0),
        lastTripToken = prefs.getLong(KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN, 0L),
        lastTripDistanceKm = Double.fromBits(
            prefs.getLong(KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE, 0.0.toBits())
        ).coerceAtLeast(0.0),
        lastTripFuelLiters = Double.fromBits(
            prefs.getLong(KEY_FUEL_CAL_PROGRESS_LAST_FUEL, 0.0.toBits())
        ).coerceAtLeast(0.0)
    )

    /**
     * Starts a full-tank calibration accumulator independently from automatic
     * drive-history segmentation. The current trip totals become the first
     * baseline; subsequent trip-token changes continue the same tank period.
     */
    fun startFuelCalibrationProgress(
        tripToken: Long,
        distanceKm: Double,
        fuelLiters: Double
    ): FuelCalibrationProgress = synchronized(FUEL_CAL_PROGRESS_LOCK) {
        val progress = FuelCalibrationProgress(
            accumulatedDistanceKm = 0.0,
            accumulatedFuelLiters = 0.0,
            lastTripToken = tripToken,
            lastTripDistanceKm = distanceKm.coerceAtLeast(0.0),
            lastTripFuelLiters = fuelLiters.coerceAtLeast(0.0)
        )
        saveFuelCalibrationProgress(progress)
        progress
    }

    /**
     * Adds only positive deltas from the current trip. A new trip token starts
     * from zero without discarding the already accumulated full-tank period.
     * Small deltas are batched to avoid writing SharedPreferences every OBD loop.
     */
    fun updateFuelCalibrationProgress(
        tripToken: Long,
        distanceKm: Double,
        fuelLiters: Double,
        force: Boolean = false
    ): FuelCalibrationProgress = synchronized(FUEL_CAL_PROGRESS_LOCK) {
        if (tripToken == 0L || !distanceKm.isFinite() || !fuelLiters.isFinite()) {
            return@synchronized loadFuelCalibrationProgress()
        }
        val currentDistance = distanceKm.coerceAtLeast(0.0)
        val currentFuel = fuelLiters.coerceAtLeast(0.0)
        val previous = loadFuelCalibrationProgress()
        if (previous.lastTripToken == 0L) {
            return@synchronized startFuelCalibrationProgress(tripToken, currentDistance, currentFuel)
        }

        val tokenChanged = tripToken != previous.lastTripToken
        val totalsReset = !tokenChanged && (
            currentDistance + 0.0001 < previous.lastTripDistanceKm ||
                currentFuel + 0.000001 < previous.lastTripFuelLiters
            )
        val distanceDelta = when {
            tokenChanged -> currentDistance
            totalsReset -> 0.0
            else -> (currentDistance - previous.lastTripDistanceKm).coerceAtLeast(0.0)
        }
        val fuelDelta = when {
            tokenChanged -> currentFuel
            totalsReset -> 0.0
            else -> (currentFuel - previous.lastTripFuelLiters).coerceAtLeast(0.0)
        }
        val shouldPersist = force || tokenChanged || totalsReset ||
            distanceDelta >= FUEL_CAL_PROGRESS_DISTANCE_BATCH_KM ||
            fuelDelta >= FUEL_CAL_PROGRESS_FUEL_BATCH_L
        if (!shouldPersist) return@synchronized previous

        val updated = previous.copy(
            accumulatedDistanceKm = (previous.accumulatedDistanceKm + distanceDelta).coerceAtLeast(0.0),
            accumulatedFuelLiters = (previous.accumulatedFuelLiters + fuelDelta).coerceAtLeast(0.0),
            lastTripToken = tripToken,
            lastTripDistanceKm = currentDistance,
            lastTripFuelLiters = currentFuel
        )
        saveFuelCalibrationProgress(updated)
        updated
    }

    fun clearFuelCalibrationProgress() = synchronized(FUEL_CAL_PROGRESS_LOCK) {
        prefs.edit()
            .remove(KEY_FUEL_CAL_PROGRESS_DISTANCE)
            .remove(KEY_FUEL_CAL_PROGRESS_FUEL)
            .remove(KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN)
            .remove(KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE)
            .remove(KEY_FUEL_CAL_PROGRESS_LAST_FUEL)
            .apply()
    }

    private fun saveFuelCalibrationProgress(progress: FuelCalibrationProgress) {
        prefs.edit()
            .putLong(KEY_FUEL_CAL_PROGRESS_DISTANCE, progress.accumulatedDistanceKm.toBits())
            .putLong(KEY_FUEL_CAL_PROGRESS_FUEL, progress.accumulatedFuelLiters.toBits())
            .putLong(KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN, progress.lastTripToken)
            .putLong(KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE, progress.lastTripDistanceKm.toBits())
            .putLong(KEY_FUEL_CAL_PROGRESS_LAST_FUEL, progress.lastTripFuelLiters.toBits())
            .apply()
    }

    fun exportBackupJson(): String {
        val values = JSONObject()
        prefs.all.filterKeys { it in RESTORABLE_BACKUP_KEYS }.toSortedMap().forEach { (key, value) ->
            val item = JSONObject()
            when (value) {
                is String -> item.put("type", "string").put("value", value)
                is Int -> item.put("type", "int").put("value", value)
                is Long -> item.put("type", "long").put("value", value)
                is Float -> item.put("type", "float").put("value", value.toDouble())
                is Boolean -> item.put("type", "boolean").put("value", value)
                is Set<*> -> {
                    val array = JSONArray()
                    value.filterIsInstance<String>().sorted().forEach { array.put(it) }
                    item.put("type", "string_set").put("value", array)
                }
                null -> return@forEach
                else -> error("Desteklenmeyen ayar türü: ${value::class.java.simpleName}")
            }
            values.put(key, item)
        }
        return JSONObject()
            .put("formatVersion", 1)
            .put("values", values)
            .toString(2)
    }

    fun validateBackupJson(json: String) {
        require(json.length <= 2 * 1024 * 1024) { "Ayar yedeği çok büyük" }
        val root = JSONObject(json)
        require(root.optInt("formatVersion", -1) == 1) { "Desteklenmeyen ayar yedeği biçimi" }
        val values = root.optJSONObject("values") ?: error("Ayar yedeği değerleri eksik")
        val keys = values.keys().asSequence().toList()
        require(keys.size <= RESTORABLE_BACKUP_KEYS.size) { "Ayar yedeğinde çok fazla anahtar var" }
        keys.forEach { key ->
            require(key in RESTORABLE_BACKUP_KEYS) { "Yedekte desteklenmeyen ayar anahtarı var: $key" }
            val item = values.optJSONObject(key) ?: error("Geçersiz ayar girdisi: $key")
            val expectedType = expectedBackupType(key)
            require(item.optString("type") == expectedType) { "Ayar türü beklenen biçimle eşleşmiyor: $key" }
            require(item.has("value")) { "Ayar değeri eksik: $key" }
            validateBackupValue(key, expectedType, item)
        }
    }

    private fun validateBackupValue(key: String, type: String, item: JSONObject) {
        when (type) {
            "string" -> {
                val value = item.getString("value")
                require(value.length <= 16_384) { "Ayar metni çok uzun: $key" }
                when (key) {
                    KEY_LANGUAGE -> require(value in enumNames<AppLanguage>()) { "Geçersiz dil ayarı" }
                    KEY_BRAND -> require(value in enumNames<Brand>()) { "Geçersiz marka ayarı" }
                    KEY_FUEL_TYPE -> require(value in enumNames<FuelType>()) { "Geçersiz yakıt türü" }
                    KEY_PROFILE_SUPPORT -> require(value in enumNames<VehicleProfileSupport>()) { "Geçersiz araç profil desteği" }
                    KEY_DEVICE -> require(value in enumNames<DeviceMode>()) { "Geçersiz cihaz modu" }
                    KEY_HEAD_UNIT_UI_MODE -> require(value in enumNames<HeadUnitUiMode>()) { "Geçersiz double arayüz modu" }
                    KEY_DEFAULT_MEDIA_APP -> require(value in enumNames<DefaultMediaApp>()) { "Geçersiz varsayılan medya uygulaması" }
                    KEY_GAUGE -> require(value in enumNames<GaugeStyle>() + LEGACY_GAUGE_NAMES) { "Geçersiz gösterge stili" }
                    KEY_VEHICLE_VISUAL_MODEL -> require(value in enumNames<VehicleVisualModel>()) { "Geçersiz kokpit araç modeli" }
                    KEY_VEHICLE_COLOR -> require(value in enumNames<VehicleColor>()) { "Geçersiz araç rengi" }
                    KEY_COCKPIT_TEXT_SIZE -> require(value in enumNames<CockpitTextSize>()) { "Geçersiz kokpit yazı boyutu" }
                    KEY_COCKPIT_DENSITY -> require(value in enumNames<CockpitDensity>()) { "Geçersiz kokpit yoğunluğu" }
                    KEY_ACCENT -> require(value in enumNames<AccentColor>()) { "Geçersiz vurgu rengi" }
                    KEY_MODEL_YEAR -> require(value.isBlank() || (value.length == 4 && value.all(Char::isDigit) && value.toInt() in 1886..2100)) { "Geçersiz model yılı" }
                    KEY_ENGINE_CC -> requireNumericString(value, 500.0, 10_000.0, key, allowBlank = true)
                    KEY_ENGINE_HP -> requireNumericString(value, 10.0, 2_000.0, key, allowBlank = true)
                    KEY_FUEL_PRICE -> requireNumericString(value, 0.0, 100_000.0, key, allowBlank = true)
                    KEY_ODOMETER -> requireNumericString(value, 0.0, 5_000_000.0, key, allowBlank = true)
                    KEY_OIL_SERVICE, KEY_FUEL_FILTER, KEY_AIR_FILTER, KEY_POLLEN_FILTER, KEY_TIMING_BELT ->
                        requireNumericString(value, 1_000.0, 500_000.0, key, allowBlank = true)
                    KEY_FUEL_CAL_APP_L, KEY_FUEL_CAL_PUMP_L ->
                        requireNumericString(value, 0.0, 5_000.0, key, allowBlank = true)
                    KEY_MODEL, KEY_ENGINE, KEY_ENGINE_CODE -> require(value.length <= 120) { "Araç metni çok uzun: $key" }
                }
            }
            "int" -> {
                val value = item.getInt("value")
                when (key) {
                    KEY_CYLINDER_COUNT -> require(value in 1..12) { "Geçersiz silindir sayısı" }
                    KEY_SMART_TRIP -> require(value in setOf(15, 30, 60, 90, 120)) { "Geçersiz akıllı sürüş aralığı" }
                    KEY_DRIVE_HISTORY_LIMIT, KEY_TEST_HISTORY_LIMIT -> require(value in -1..500) { "Geçersiz geçmiş sınırı" }
                    KEY_FUEL_CAL_START_ODOMETER -> require(value in 0..5_000_000) { "Geçersiz kalibrasyon kilometresi" }
                }
            }
            "long" -> {
                val value = item.getLong("value")
                when (key) {
                    KEY_FUEL_CAL_FACTOR, KEY_FUEL_CAL_SESSION_FACTOR -> {
                        val decoded = Double.fromBits(value)
                        require(decoded.isFinite() && decoded in 0.50..1.50) { "Geçersiz yakıt kalibrasyon katsayısı" }
                    }
                    in DOUBLE_BITS_BACKUP_KEYS -> {
                        val decoded = Double.fromBits(value)
                        require(decoded.isFinite() && decoded in 0.0..10_000_000.0) { "Geçersiz sayısal yedek değeri: $key" }
                    }
                    KEY_FUEL_CAL_START_TIME -> require(value in 0L..4_102_444_800_000L) { "Geçersiz kalibrasyon zamanı" }
                    else -> require(value >= 0L) { "Geçersiz uzun ayar değeri: $key" }
                }
            }
            "boolean" -> item.getBoolean("value")
            else -> error("Desteklenmeyen ayar türü: $type")
        }
    }

    private fun requireNumericString(value: String, min: Double, max: Double, key: String, allowBlank: Boolean) {
        if (allowBlank && value.isBlank()) return
        val number = value.trim().replace(',', '.').toDoubleOrNull()
        require(number != null && number.isFinite() && number in min..max) { "Geçersiz sayısal ayar: $key" }
    }

    private inline fun <reified T : Enum<T>> enumNames(): Set<String> = enumValues<T>().mapTo(linkedSetOf()) { it.name }

    private fun expectedBackupType(key: String): String = when (key) {
        in STRING_BACKUP_KEYS -> "string"
        in INT_BACKUP_KEYS -> "int"
        in LONG_BACKUP_KEYS -> "long"
        in BOOLEAN_BACKUP_KEYS -> "boolean"
        else -> error("Desteklenmeyen ayar anahtarı: $key")
    }

    fun importBackupJson(json: String): Boolean {
        validateBackupJson(json)
        val values = JSONObject(json).getJSONObject("values")
        val editor = prefs.edit()
        RESTORABLE_BACKUP_KEYS.forEach { editor.remove(it) }
        values.keys().asSequence().filter { it in RESTORABLE_BACKUP_KEYS }.forEach { key ->
            val item = values.getJSONObject(key)
            when (item.getString("type")) {
                "string" -> editor.putString(key, item.getString("value"))
                "int" -> editor.putInt(key, item.getInt("value"))
                "long" -> editor.putLong(key, item.getLong("value"))
                "float" -> editor.putFloat(key, item.getDouble("value").toFloat())
                "boolean" -> editor.putBoolean(key, item.getBoolean("value"))
                "string_set" -> {
                    val array = item.getJSONArray("value")
                    val set = linkedSetOf<String>()
                    for (index in 0 until array.length()) set += array.getString(index)
                    editor.putStringSet(key, set)
                }
            }
        }
        return editor.commit()
    }

    fun resetSetup() {
        // Sıfırlama sonrasında splash/init akışında takılmamak için setup bayrağını
        // senkron olarak commit ediyoruz. Log dosyaları bu SharedPreferences dışında kalır.
        prefs.edit()
            .clear()
            .putBoolean(KEY_SETUP, false)
            .commit()
    }

    private inline fun <reified T : Enum<T>> android.content.SharedPreferences.getEnum(key: String, default: T): T {
        val value = getString(key, default.name) ?: default.name
        return runCatching { enumValueOf<T>(value) }.getOrDefault(default)
    }

    companion object {
        private const val KEY_SETUP = "setup_completed"
        private const val KEY_LANGUAGE = "language"
        private const val KEY_BRAND = "brand"
        private const val KEY_MODEL = "vehicle_model"
        private const val KEY_ENGINE = "engine"
        private const val KEY_FUEL_TYPE = "fuel_type"
        private const val KEY_PROFILE_SUPPORT = "profile_support"
        private const val KEY_MODEL_YEAR = "model_year"
        private const val KEY_ENGINE_CODE = "engine_code"
        private const val KEY_ENGINE_CC = "engine_displacement_cc"
        private const val KEY_ENGINE_HP = "engine_power_hp"
        private const val KEY_CYLINDER_COUNT = "cylinder_count"
        private const val KEY_EXPERIMENTAL_PROFILE_ACCEPTED = "experimental_profile_accepted"
        private const val KEY_DEVICE = "device_mode"
        private const val KEY_HEAD_UNIT_UI_MODE = "head_unit_ui_mode"
        private const val KEY_DEFAULT_MEDIA_APP = "default_media_app"
        private const val KEY_GAUGE = "gauge_style"
        private const val KEY_VEHICLE_VISUAL_MODEL = "vehicle_visual_model"
        private const val KEY_VEHICLE_COLOR = "vehicle_color"
        private const val KEY_GHOST_DUAL_SPEED_ON_LEFT = "ghost_dual_speed_on_left"
        private const val KEY_COCKPIT_TEXT_SIZE = "cockpit_text_size"
        private const val KEY_COCKPIT_DENSITY = "cockpit_density"
        private const val KEY_ACCENT = "accent_color"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_KEEP_SCREEN = "keep_screen_on"
        private const val KEY_BACKGROUND_TRIP = "background_trip"
        private const val KEY_GPS_ROUTE_ENABLED = "gps_route_enabled"
        private const val KEY_GPS_MASK_EXPORT_EDGES = "gps_mask_export_edges"
        private const val KEY_SMART_TRIP = "smart_trip_minutes"
        private const val KEY_DRIVE_HISTORY_ENABLED = "drive_history_enabled"
        private const val KEY_DRIVE_HISTORY_LIMIT = "drive_history_limit"
        private const val KEY_TEST_HISTORY_ENABLED = "test_history_enabled"
        private const val KEY_TEST_HISTORY_LIMIT = "test_history_limit"
        private const val KEY_DEMO_MODE = "demo_mode"
        private const val KEY_DISCLAIMER = "disclaimer_accepted"
        private const val KEY_FUEL_PRICE = "fuel_price"
        private const val KEY_ODOMETER = "odometer"
        private const val KEY_OIL_SERVICE = "oil_service_km"
        private const val KEY_FUEL_FILTER = "fuel_filter_km"
        private const val KEY_AIR_FILTER = "air_filter_km"
        private const val KEY_POLLEN_FILTER = "pollen_filter_km"
        private const val KEY_TIMING_BELT = "timing_belt_km"
        private const val KEY_DEVELOPER_MODE = "developer_mode"
        private const val KEY_RAW_ECU_LOG = "raw_ecu_log"
        private const val KEY_LONG_TRIP_LOG = "long_trip_log"
        private const val KEY_FUEL_CAL_ENABLED = "fuel_calibration_enabled"
        private const val KEY_FUEL_CAL_FACTOR = "fuel_calibration_factor"
        private const val KEY_FUEL_CAL_APP_L = "fuel_calibration_app_liters"
        private const val KEY_FUEL_CAL_PUMP_L = "fuel_calibration_pump_liters"
        private const val KEY_FUEL_CAL_WARNING = "fuel_calibration_warning"
        private const val KEY_FUEL_CAL_SESSION_ACTIVE = "fuel_calibration_session_active"
        private const val KEY_FUEL_CAL_START_DISTANCE = "fuel_calibration_start_distance_km"
        private const val KEY_FUEL_CAL_START_FUEL = "fuel_calibration_start_fuel_liters"
        private const val KEY_FUEL_CAL_START_TRIP_TOKEN = "fuel_calibration_start_trip_token"
        private const val KEY_FUEL_CAL_START_ODOMETER = "fuel_calibration_start_odometer_km"
        private const val KEY_FUEL_CAL_START_TIME = "fuel_calibration_start_time_ms"
        private const val KEY_FUEL_CAL_SESSION_FACTOR = "fuel_calibration_session_factor"
        private const val KEY_FUEL_CAL_PROGRESS_DISTANCE = "fuel_calibration_progress_distance_km"
        private const val KEY_FUEL_CAL_PROGRESS_FUEL = "fuel_calibration_progress_fuel_liters"
        private const val KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN = "fuel_calibration_progress_last_trip_token"
        private const val KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE = "fuel_calibration_progress_last_distance_km"
        private const val KEY_FUEL_CAL_PROGRESS_LAST_FUEL = "fuel_calibration_progress_last_fuel_liters"
        private const val FUEL_CAL_PROGRESS_DISTANCE_BATCH_KM = 0.25
        private const val FUEL_CAL_PROGRESS_FUEL_BATCH_L = 0.02
        private val FUEL_CAL_PROGRESS_LOCK = Any()
        private const val KEY_AVG_RESET_DISTANCE = "avg_reset_distance_km"
        private const val KEY_AVG_RESET_FUEL = "avg_reset_fuel_liters"
        private const val KEY_COST_RESET_FUEL = "cost_reset_fuel_liters"
        private const val KEY_AVG_RESET_TRIP_TOKEN = "avg_reset_trip_token"
        private const val KEY_COST_RESET_TRIP_TOKEN = "cost_reset_trip_token"

        private val LEGACY_GAUGE_NAMES = setOf("Minimal", "Sport", "RsPerformance")

        private val STRING_BACKUP_KEYS = setOf(
            KEY_LANGUAGE, KEY_BRAND, KEY_MODEL, KEY_ENGINE, KEY_FUEL_TYPE, KEY_PROFILE_SUPPORT,
            KEY_MODEL_YEAR, KEY_ENGINE_CODE, KEY_ENGINE_CC, KEY_ENGINE_HP, KEY_DEVICE,
            KEY_HEAD_UNIT_UI_MODE, KEY_DEFAULT_MEDIA_APP, KEY_GAUGE, KEY_VEHICLE_VISUAL_MODEL, KEY_VEHICLE_COLOR, KEY_COCKPIT_TEXT_SIZE, KEY_COCKPIT_DENSITY, KEY_ACCENT,
            KEY_FUEL_PRICE, KEY_ODOMETER, KEY_OIL_SERVICE, KEY_FUEL_FILTER, KEY_AIR_FILTER,
            KEY_POLLEN_FILTER, KEY_TIMING_BELT, KEY_FUEL_CAL_APP_L, KEY_FUEL_CAL_PUMP_L
        )
        private val INT_BACKUP_KEYS = setOf(
            KEY_CYLINDER_COUNT, KEY_SMART_TRIP, KEY_DRIVE_HISTORY_LIMIT, KEY_TEST_HISTORY_LIMIT,
            KEY_FUEL_CAL_START_ODOMETER
        )
        private val LONG_BACKUP_KEYS = setOf(
            KEY_FUEL_CAL_FACTOR, KEY_FUEL_CAL_START_DISTANCE, KEY_FUEL_CAL_START_FUEL,
            KEY_FUEL_CAL_START_TRIP_TOKEN, KEY_FUEL_CAL_START_TIME, KEY_FUEL_CAL_SESSION_FACTOR,
            KEY_FUEL_CAL_PROGRESS_DISTANCE, KEY_FUEL_CAL_PROGRESS_FUEL,
            KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN, KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE,
            KEY_FUEL_CAL_PROGRESS_LAST_FUEL, KEY_AVG_RESET_DISTANCE, KEY_AVG_RESET_FUEL,
            KEY_COST_RESET_FUEL, KEY_AVG_RESET_TRIP_TOKEN, KEY_COST_RESET_TRIP_TOKEN
        )
        private val BOOLEAN_BACKUP_KEYS = setOf(
            KEY_EXPERIMENTAL_PROFILE_ACCEPTED, KEY_DARK, KEY_KEEP_SCREEN, KEY_BACKGROUND_TRIP,
            KEY_GPS_MASK_EXPORT_EDGES, KEY_DRIVE_HISTORY_ENABLED, KEY_TEST_HISTORY_ENABLED,
            KEY_DEMO_MODE, KEY_FUEL_CAL_ENABLED, KEY_FUEL_CAL_WARNING, KEY_FUEL_CAL_SESSION_ACTIVE,
            KEY_GHOST_DUAL_SPEED_ON_LEFT
        )
        private val DOUBLE_BITS_BACKUP_KEYS = setOf(
            KEY_FUEL_CAL_START_DISTANCE, KEY_FUEL_CAL_START_FUEL,
            KEY_FUEL_CAL_PROGRESS_DISTANCE, KEY_FUEL_CAL_PROGRESS_FUEL,
            KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE, KEY_FUEL_CAL_PROGRESS_LAST_FUEL,
            KEY_AVG_RESET_DISTANCE, KEY_AVG_RESET_FUEL, KEY_COST_RESET_FUEL
        )

        private val RESTORABLE_BACKUP_KEYS = setOf(
            KEY_LANGUAGE, KEY_BRAND, KEY_MODEL, KEY_ENGINE, KEY_FUEL_TYPE, KEY_PROFILE_SUPPORT,
            KEY_MODEL_YEAR, KEY_ENGINE_CODE, KEY_ENGINE_CC, KEY_ENGINE_HP, KEY_CYLINDER_COUNT,
            KEY_EXPERIMENTAL_PROFILE_ACCEPTED, KEY_DEVICE, KEY_HEAD_UNIT_UI_MODE,
            KEY_DEFAULT_MEDIA_APP, KEY_GAUGE, KEY_VEHICLE_VISUAL_MODEL, KEY_VEHICLE_COLOR,
            KEY_COCKPIT_TEXT_SIZE, KEY_COCKPIT_DENSITY, KEY_ACCENT, KEY_DARK, KEY_KEEP_SCREEN,
            KEY_GHOST_DUAL_SPEED_ON_LEFT,
            KEY_BACKGROUND_TRIP, KEY_GPS_MASK_EXPORT_EDGES, KEY_SMART_TRIP, KEY_DRIVE_HISTORY_ENABLED, KEY_DRIVE_HISTORY_LIMIT,
            KEY_TEST_HISTORY_ENABLED, KEY_TEST_HISTORY_LIMIT, KEY_DEMO_MODE, KEY_FUEL_PRICE, KEY_ODOMETER,
            KEY_OIL_SERVICE, KEY_FUEL_FILTER, KEY_AIR_FILTER, KEY_POLLEN_FILTER, KEY_TIMING_BELT, KEY_FUEL_CAL_ENABLED,
            KEY_FUEL_CAL_FACTOR, KEY_FUEL_CAL_APP_L, KEY_FUEL_CAL_PUMP_L, KEY_FUEL_CAL_WARNING,
            KEY_FUEL_CAL_SESSION_ACTIVE, KEY_FUEL_CAL_START_DISTANCE, KEY_FUEL_CAL_START_FUEL,
            KEY_FUEL_CAL_START_TRIP_TOKEN, KEY_FUEL_CAL_START_ODOMETER, KEY_FUEL_CAL_START_TIME,
            KEY_FUEL_CAL_SESSION_FACTOR, KEY_FUEL_CAL_PROGRESS_DISTANCE, KEY_FUEL_CAL_PROGRESS_FUEL,
            KEY_FUEL_CAL_PROGRESS_LAST_TRIP_TOKEN, KEY_FUEL_CAL_PROGRESS_LAST_DISTANCE,
            KEY_FUEL_CAL_PROGRESS_LAST_FUEL, KEY_AVG_RESET_DISTANCE, KEY_AVG_RESET_FUEL,
            KEY_COST_RESET_FUEL, KEY_AVG_RESET_TRIP_TOKEN,
            KEY_COST_RESET_TRIP_TOKEN
        )
    }
}
