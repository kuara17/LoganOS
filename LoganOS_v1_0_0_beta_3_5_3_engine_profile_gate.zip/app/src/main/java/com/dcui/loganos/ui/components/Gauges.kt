package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette

private val LoganGaugeGreen = Color(0xFF107C41)

@Composable
fun SpeedGauge(palette: LoganPalette, speed: Int?, style: GaugeStyle, modifier: Modifier = Modifier, demoMode: Boolean = false) {
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / 220f).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "speedProgress"
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val ringSize = minOf(maxWidth, maxHeight).coerceAtMost(188.dp).coerceAtLeast(96.dp) * 0.92f
        CircularProgressIndicator(
            progress = { progress },
            color = LoganGaugeGreen,
            trackColor = palette.line.copy(alpha = .95f),
            strokeWidth = 12.dp,
            modifier = Modifier.size(ringSize)
        )
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                text = speed?.toString() ?: "--",
                color = palette.textPrimary,
                fontSize = if (speed == null) 46.sp else 64.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center
            )
            Text("km/h", color = palette.textSecondary, fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Text(
                text = when { demoMode -> "DEMO"; speed == null -> "OBD BEKLENİYOR"; else -> "CANLI VERİ" },
                color = if (demoMode) palette.warning else if (speed == null) palette.critical else LoganGaugeGreen,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    val progress = when (style) {
        GaugeStyle.Digital -> .35f
        GaugeStyle.Sport -> .78f
        GaugeStyle.ClassicOem -> .50f
        GaugeStyle.Minimal -> .00f
        GaugeStyle.RsPerformance -> .88f
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp),
        modifier = modifier.height(156.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(104.dp)
                .padding(horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            if (style == GaugeStyle.Minimal) {
                Box(
                    modifier = Modifier
                        .size(width = 98.dp, height = 68.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(palette.surfaceVariant.copy(alpha = .45f))
                        .border(1.dp, palette.line, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { PreviewSpeedText(palette, LoganGaugeGreen) }
            } else {
                Box(contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(
                        progress = { progress },
                        color = LoganGaugeGreen,
                        trackColor = palette.line,
                        strokeWidth = 8.dp,
                        modifier = Modifier.size(88.dp)
                    )
                    PreviewSpeedText(palette, LoganGaugeGreen)
                }
            }
        }
        Text(style.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewSpeedText(palette: LoganPalette, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("42", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.size(width = 34.dp, height = 4.dp).clip(CircleShape).background(accent.copy(alpha = .70f)))
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Modern dijital"
    GaugeStyle.Sport -> "Sportif ve dinamik"
    GaugeStyle.ClassicOem -> "Analog ibre"
    GaugeStyle.Minimal -> "Sade dijital"
    GaugeStyle.RsPerformance -> "Performans"
}
