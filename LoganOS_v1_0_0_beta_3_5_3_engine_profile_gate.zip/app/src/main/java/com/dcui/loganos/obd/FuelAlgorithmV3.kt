package com.dcui.loganos.obd

import kotlin.math.max

private const val DEFAULT_DIESEL_DENSITY_MG_L = 835000.0
private const val DEFAULT_AFR_DIESEL = 18.0
private const val DEFAULT_DISPLACEMENT_L = 1.461
private const val DEFAULT_VOL_EFF = 0.80
private const val GAS_CONSTANT_AIR = 287.05

data class FuelAlgorithmResult(
    val source: String,
    val fuelLh: Double?,
    val fuelL100: Double?,
    val usedFuelMg: Double?,
    val note: String = ""
)

class FuelAlgorithmV3(
    private val densityMgL: Double = DEFAULT_DIESEL_DENSITY_MG_L,
    private val holdTimeoutMs: Long = 1000L,
    private val afr: Double = DEFAULT_AFR_DIESEL,
    private val displacementL: Double = DEFAULT_DISPLACEMENT_L,
    private val volumetricEfficiency: Double = DEFAULT_VOL_EFF
) {
    private var lastValidFuelMg: Double? = null
    private var lastValidTimeMs: Long = 0L

    fun update(
        rpm: Int?,
        speedKmh: Double?,
        fuelMg: Double?,
        pedalPercent: Double?,
        airCharge: Double?,
        mapMbar: Int?,
        intakeTempC: Double?,
        nowMs: Long = System.currentTimeMillis()
    ): FuelAlgorithmResult {
        val r = rpm ?: 0
        val s = speedKmh ?: 0.0

        fun l100(lh: Double): Double? = if (s >= 5.0) (lh / max(s, 1.0)) * 100.0 else null
        fun fromMg(source: String, mg: Double, note: String = ""): FuelAlgorithmResult {
            val lh = (mg * r * 120.0) / densityMgL
            return FuelAlgorithmResult(source = source, fuelLh = lh, fuelL100 = l100(lh), usedFuelMg = mg, note = note)
        }
        fun zero(source: String, note: String = ""): FuelAlgorithmResult {
            return FuelAlgorithmResult(source = source, fuelLh = 0.0, fuelL100 = if (s >= 5.0) 0.0 else null, usedFuelMg = 0.0, note = note)
        }

        // DC UI Alpha reference priority: CUTOFF -> CRANK_GUARD -> INJECTION -> HOLD -> MAF -> MAP -> NONE.
        if (s > 10.0 && (pedalPercent ?: 100.0) <= 0.5 && (fuelMg ?: 999.0) <= 0.05 && r > 1300) {
            return zero("CUTOFF", "speed>10 pedal<=0.5 fuel<=0.05 rpm>1300")
        }
        if (r < 500) {
            return zero("CRANK_GUARD", "rpm<500")
        }
        if (fuelMg != null && fuelMg > 0.05 && fuelMg <= 90.0) {
            lastValidFuelMg = fuelMg
            lastValidTimeMs = nowMs
            return fromMg("INJECTION", fuelMg, "21A0 fuel mg/stroke")
        }
        val held = lastValidFuelMg
        if (held != null && r >= 500 && nowMs - lastValidTimeMs <= holdTimeoutMs) {
            return fromMg("HOLD", held, "last valid injection <=1s")
        }
        if (airCharge != null && airCharge > 0.0) {
            val estimatedFuelMg = airCharge / afr
            return fromMg("MAF_FALLBACK", estimatedFuelMg, "air_charge/AFR")
        }
        val mapFuelMg = estimateFuelFromMap(mapMbar, intakeTempC)
        if (mapFuelMg != null && mapFuelMg > 0.0) {
            return fromMg("MAP_FALLBACK", mapFuelMg, "speed-density estimate")
        }
        return zero("NONE", "no valid fuel source")
    }

    private fun estimateFuelFromMap(mapMbar: Int?, intakeTempC: Double?): Double? {
        if (mapMbar == null || intakeTempC == null) return null
        if (mapMbar <= 200) return null
        val tempK = intakeTempC + 273.15
        if (tempK <= 200.0) return null
        val mapPa = mapMbar * 100.0
        val displacementM3 = displacementL / 1000.0
        val airKgPerTwoRev = (mapPa * displacementM3 * volumetricEfficiency) / (GAS_CONSTANT_AIR * tempK)
        val airMgPerTwoRev = airKgPerTwoRev * 1_000_000.0
        return airMgPerTwoRev / afr
    }
}
