package com.dcui.loganos.obd

import java.util.Locale
import kotlin.math.max

data class TripComputerSnapshot(
    val state: String,
    val distanceKm: Double,
    val fuelUsedL: Double,
    val durationSec: Long,
    val averageL100: Double?,
    val displayState: String
) {
    val durationText: String
        get() {
            val hours = durationSec / 3600
            val minutes = (durationSec % 3600) / 60
            val seconds = durationSec % 60
            return if (hours > 0) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
}

class TripComputer(
    private val startSpeedKmh: Double = 5.0,
    private val startDistanceKm: Double = 0.05,
    private val avgDisplayMinDistanceKm: Double = 1.0,
    private val smoothingAlpha: Double = 0.20,
    private val smoothingIntervalMs: Long = 2000L
) {
    private var lastTimeMs: Long? = null
    private var tripStarted: Boolean = false
    private var startTimeMs: Long? = null
    private var totalDistanceKm: Double = 0.0
    private var totalFuelL: Double = 0.0
    private var pendingDistanceKm: Double = 0.0
    private var pendingFuelL: Double = 0.0
    private var smoothedAverage: Double? = null
    private var lastSmoothingMs: Long = 0L

    fun reset(nowMs: Long = System.currentTimeMillis()) {
        lastTimeMs = nowMs
        tripStarted = false
        startTimeMs = null
        totalDistanceKm = 0.0
        totalFuelL = 0.0
        pendingDistanceKm = 0.0
        pendingFuelL = 0.0
        smoothedAverage = null
        lastSmoothingMs = 0L
    }

    fun update(
        speedKmh: Double?,
        fuelLh: Double?,
        nowMs: Long = System.currentTimeMillis()
    ): TripComputerSnapshot {
        val previousTime = lastTimeMs
        lastTimeMs = nowMs
        if (previousTime == null) return snapshot(nowMs)

        val dt = ((nowMs - previousTime).coerceAtLeast(0L)) / 1000.0
        if (dt <= 0.0 || dt > 10.0) {
            // Android lifecycle / sleep jumps are discarded, not backfilled.
            return snapshot(nowMs)
        }

        val speed = (speedKmh ?: 0.0).coerceAtLeast(0.0)
        val lh = (fuelLh ?: 0.0).coerceAtLeast(0.0)
        val distanceStep = speed * dt / 3600.0
        val fuelStep = lh * dt / 3600.0

        if (!tripStarted) {
            if (distanceStep > 0.0) {
                pendingDistanceKm += distanceStep
                pendingFuelL += fuelStep
            }
            if (speed > startSpeedKmh || pendingDistanceKm > startDistanceKm) {
                tripStarted = true
                startTimeMs = nowMs
                totalDistanceKm += pendingDistanceKm
                totalFuelL += pendingFuelL
                pendingDistanceKm = 0.0
                pendingFuelL = 0.0
            }
        } else {
            totalDistanceKm += distanceStep
            totalFuelL += fuelStep
        }

        updateAverage(nowMs)
        return snapshot(nowMs)
    }

    private fun updateAverage(nowMs: Long) {
        if (totalDistanceKm < avgDisplayMinDistanceKm) return
        val raw = (totalFuelL / max(totalDistanceKm, 0.0001)) * 100.0
        if (smoothedAverage == null || nowMs - lastSmoothingMs >= smoothingIntervalMs) {
            smoothedAverage = smoothedAverage?.let { old -> old + smoothingAlpha * (raw - old) } ?: raw
            lastSmoothingMs = nowMs
        }
    }

    fun snapshot(nowMs: Long = System.currentTimeMillis()): TripComputerSnapshot {
        val duration = if (tripStarted) {
            val startedAt = startTimeMs ?: nowMs
            ((nowMs - startedAt).coerceAtLeast(0L)) / 1000L
        } else 0L
        val state = when {
            !tripStarted -> "WAITING"
            totalDistanceKm < avgDisplayMinDistanceKm -> "CALCULATING"
            else -> "ACTIVE"
        }
        val display = when (state) {
            "WAITING" -> "Sürüş bekleniyor"
            "CALCULATING" -> "Hesaplanıyor"
            else -> "Aktif"
        }
        return TripComputerSnapshot(
            state = state,
            distanceKm = totalDistanceKm,
            fuelUsedL = totalFuelL,
            durationSec = duration,
            averageL100 = smoothedAverage,
            displayState = display
        )
    }
}
