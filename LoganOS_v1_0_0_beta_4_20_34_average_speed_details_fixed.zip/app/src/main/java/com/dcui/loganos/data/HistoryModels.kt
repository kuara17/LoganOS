package com.dcui.loganos.data

data class DriveHistoryItem(
    val id: Long,
    val tripToken: Long,
    val startedAtMs: Long,
    val endedAtMs: Long?,
    val timeTrusted: Boolean,
    val status: String,
    val pinned: Boolean,
    val exported: Boolean,
    val distanceKm: Double,
    val fuelUsedL: Double,
    val durationMs: Long,
    val averageL100: Double?,
    val maxSpeedKmh: Int?,
    val maxRpm: Int?,
    val startTempC: Int?,
    val endTempC: Int?,
    val sessionCount: Int
) {
    val activeLike: Boolean get() = status == "ACTIVE" || status == "PARKED" || status == "TIME_PENDING"

    /** Runtime-only average speed derived from persisted drive distance/time. */
    val averageSpeedKmh: Double?
        get() = if (durationMs > 0L && distanceKm.isFinite() && distanceKm >= 0.0) {
            distanceKm / (durationMs / 3_600_000.0)
        } else null

    /**
     * Vehicle Health may use persisted drive evidence once the record is no
     * longer genuinely active. Some older LoganOS versions left a completed
     * record with status ACTIVE while still writing an ended_at timestamp; such
     * records are already closed in storage and must not be invisible to the
     * historical health baseline.
     */
    val healthEligible: Boolean get() =
        (status != "ACTIVE" || endedAtMs != null) &&
            (distanceKm > 0.00001 || fuelUsedL > 0.0 || durationMs > 0L)
}

data class DriveHistoryChartPoint(
    val progress: Float,
    val speedKmh: Float?,
    val rpm: Float?,
    val coolantC: Float?,
    val consumption: Float?
)


data class GpsRoutePoint(
    val latitude: Double,
    val longitude: Double,
    val accuracyM: Float,
    val epochMs: Long?,
    val elapsedMs: Long,
    val timeTrusted: Boolean
)

data class GpsRouteSegment(
    val driveSessionId: Long,
    val points: List<GpsRoutePoint>
)

data class GpsRouteDetail(
    val segments: List<GpsRouteSegment> = emptyList(),
    val pointCount: Int = 0,
    val firstEpochMs: Long? = null,
    val lastEpochMs: Long? = null
) {
    val hasRoute: Boolean get() = segments.any { it.points.size >= 2 }
}

data class DriveHistoryDetail(
    val recordId: Long,
    val points: List<DriveHistoryChartPoint>,
    val sampleCount: Int,
    val analyzedDurationMs: Long,
    val engineRunningDurationMs: Long,
    val movingDurationMs: Long,
    val stationaryDurationMs: Long,
    val stationaryFuelUsedL: Double,
    val movingFuelUsedL: Double?,
    val movingAverageL100: Double?,
    val averageMovingSpeedKmh: Double?,
    val acKnownDurationMs: Long,
    val acOnDurationMs: Long,
    val fuelSourceKnownDurationMs: Long,
    val cutoffDurationMs: Long,
    val gpsRoute: GpsRouteDetail = GpsRouteDetail()
)

data class TestHistoryItem(
    val id: Long,
    val name: String,
    val testType: String,
    val startedAtMs: Long,
    val endedAtMs: Long?,
    val timeTrusted: Boolean,
    val status: String,
    val pinned: Boolean,
    val exported: Boolean,
    val durationMs: Long,
    val sampleCount: Int,
    val summary: String?
) {
    val activeLike: Boolean get() = status == "ACTIVE"
}


data class TechnicalSessionItem(
    val id: Long,
    val startedAtMs: Long,
    val endedAtMs: Long?,
    val timeTrusted: Boolean,
    val status: String,
    val durationMs: Long,
    val sampleCount: Int,
    val eventCount: Int,
    val adapterName: String?,
    val tripRecordId: Long?
) {
    val activeLike: Boolean get() = status == "ACTIVE"
    val hasSamples: Boolean get() = sampleCount > 0
}

data class HistoryStorageInfo(
    val driveRecordCount: Int = 0,
    val testRecordCount: Int = 0,
    val pinnedDriveCount: Int = 0,
    val pinnedTestCount: Int = 0,
    val driveApproxBytes: Long = 0L,
    val testApproxBytes: Long = 0L,
    val databaseBytes: Long = 0L
)
