package com.dcui.loganos.obd

import android.content.Context
import android.os.SystemClock

/** Persists the user-facing cockpit totals across process and ignition cycles. */
class PersistentCockpitTripStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val accumulator = PersistentCockpitTripAccumulator(loadState())
    private var lastPersistElapsedMs: Long = 0L

    @Synchronized
    fun update(
        trip: TripComputerSnapshot,
        force: Boolean = false,
        nowElapsedMs: Long = SystemClock.elapsedRealtime()
    ): PersistentCockpitTripState {
        val previous = accumulator.snapshot()
        val updated = accumulator.update(
            tripToken = trip.tripToken,
            distanceKm = trip.distanceKm,
            fuelLiters = trip.fuelUsedL,
            durationSec = trip.durationSec
        )
        val boundaryChanged = previous.lastTripToken != updated.lastTripToken
        if (force || boundaryChanged || nowElapsedMs - lastPersistElapsedMs >= PERSIST_INTERVAL_MS) {
            persist(updated, force)
            lastPersistElapsedMs = nowElapsedMs
        }
        return updated
    }

    @Synchronized
    fun rebase(
        trip: TripComputerSnapshot,
        force: Boolean = true,
        nowElapsedMs: Long = SystemClock.elapsedRealtime()
    ): PersistentCockpitTripState {
        val updated = accumulator.rebase(
            tripToken = trip.tripToken,
            distanceKm = trip.distanceKm,
            fuelLiters = trip.fuelUsedL,
            durationSec = trip.durationSec
        )
        persist(updated, force)
        lastPersistElapsedMs = nowElapsedMs
        return updated
    }

    @Synchronized
    fun snapshot(): PersistentCockpitTripState = accumulator.snapshot()

    /** Clears only the persistent user-facing cockpit trip totals. */
    @Synchronized
    fun clearAll() {
        accumulator.clearAll()
        persist(accumulator.snapshot(), synchronous = true)
        lastPersistElapsedMs = SystemClock.elapsedRealtime()
    }

    private fun loadState(): PersistentCockpitTripState = PersistentCockpitTripState(
        totalDistanceKm = Double.fromBits(prefs.getLong(KEY_TOTAL_DISTANCE, 0.0.toBits())),
        totalFuelLiters = Double.fromBits(prefs.getLong(KEY_TOTAL_FUEL, 0.0.toBits())),
        totalDurationSec = prefs.getLong(KEY_TOTAL_DURATION, 0L),
        lastTripToken = prefs.getLong(KEY_LAST_TRIP_TOKEN, 0L),
        lastTripDistanceKm = Double.fromBits(prefs.getLong(KEY_LAST_TRIP_DISTANCE, 0.0.toBits())),
        lastTripFuelLiters = Double.fromBits(prefs.getLong(KEY_LAST_TRIP_FUEL, 0.0.toBits())),
        lastTripDurationSec = prefs.getLong(KEY_LAST_TRIP_DURATION, 0L)
    )

    private fun persist(state: PersistentCockpitTripState, synchronous: Boolean) {
        val editor = prefs.edit()
            .putLong(KEY_TOTAL_DISTANCE, state.totalDistanceKm.toBits())
            .putLong(KEY_TOTAL_FUEL, state.totalFuelLiters.toBits())
            .putLong(KEY_TOTAL_DURATION, state.totalDurationSec)
            .putLong(KEY_LAST_TRIP_TOKEN, state.lastTripToken)
            .putLong(KEY_LAST_TRIP_DISTANCE, state.lastTripDistanceKm.toBits())
            .putLong(KEY_LAST_TRIP_FUEL, state.lastTripFuelLiters.toBits())
            .putLong(KEY_LAST_TRIP_DURATION, state.lastTripDurationSec)
        if (synchronous) editor.commit() else editor.apply()
    }

    private companion object {
        const val PREFS_NAME = "loganos_cockpit_trip_metrics"
        const val PERSIST_INTERVAL_MS = 3000L
        const val KEY_TOTAL_DISTANCE = "total_distance_bits"
        const val KEY_TOTAL_FUEL = "total_fuel_bits"
        const val KEY_TOTAL_DURATION = "total_duration_sec"
        const val KEY_LAST_TRIP_TOKEN = "last_trip_token"
        const val KEY_LAST_TRIP_DISTANCE = "last_trip_distance_bits"
        const val KEY_LAST_TRIP_FUEL = "last_trip_fuel_bits"
        const val KEY_LAST_TRIP_DURATION = "last_trip_duration_sec"
    }
}
