package com.dcui.loganos.obd

import java.util.Locale
import kotlin.math.max

/**
 * Cockpit trip totals are independent from automatic drive-history segments.
 *
 * [TripComputer] may start a new token after an ignition gap or when the user
 * finishes a history record. This accumulator converts those per-segment
 * snapshots into one continuous, persistent odometer-like period. The period
 * ends only when a dedicated cockpit-total reset is implemented/requested;
 * average and cost resets use independent baselines and do not clear totals.
 */
data class PersistentCockpitTripState(
    val totalDistanceKm: Double = 0.0,
    val totalFuelLiters: Double = 0.0,
    val totalDurationSec: Long = 0L,
    val lastTripToken: Long = 0L,
    val lastTripDistanceKm: Double = 0.0,
    val lastTripFuelLiters: Double = 0.0,
    val lastTripDurationSec: Long = 0L
) {
    val averageL100: Double?
        get() = if (totalDistanceKm >= 1.0) {
            (totalFuelLiters / max(totalDistanceKm, 0.0001)) * 100.0
        } else null

    val durationText: String
        get() {
            val hours = totalDurationSec / 3600L
            val minutes = (totalDurationSec % 3600L) / 60L
            val seconds = totalDurationSec % 60L
            return if (hours > 0L) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
}

class PersistentCockpitTripAccumulator(
    initialState: PersistentCockpitTripState = PersistentCockpitTripState()
) {
    private var state: PersistentCockpitTripState = sanitize(initialState)

    @Synchronized
    fun snapshot(): PersistentCockpitTripState = state

    @Synchronized
    fun clearAll(): PersistentCockpitTripState {
        state = PersistentCockpitTripState()
        return state
    }

    /**
     * Adds positive distance/fuel deltas from a history-segment snapshot. A
     * confirmed ignition-off may retroactively reduce the latest duration by a
     * few seconds; that correction is preserved. When the trip token changes,
     * the new segment starts at zero without discarding prior cockpit totals.
     */
    @Synchronized
    fun update(
        tripToken: Long,
        distanceKm: Double,
        fuelLiters: Double,
        durationSec: Long
    ): PersistentCockpitTripState {
        if (tripToken == 0L) return state

        val currentDistance = distanceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0
        val currentFuel = fuelLiters.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0
        val currentDuration = durationSec.coerceAtLeast(0L)
        val previous = state

        val firstObservation = previous.lastTripToken == 0L
        val tokenChanged = !firstObservation && previous.lastTripToken != tripToken
        val sameTokenTotalsReset = !firstObservation && !tokenChanged && (
            currentDistance + DISTANCE_EPSILON_KM < previous.lastTripDistanceKm ||
                currentFuel + FUEL_EPSILON_L < previous.lastTripFuelLiters
            )

        val distanceDelta = when {
            firstObservation || tokenChanged || sameTokenTotalsReset -> currentDistance
            else -> (currentDistance - previous.lastTripDistanceKm).coerceAtLeast(0.0)
        }
        val fuelDelta = when {
            firstObservation || tokenChanged || sameTokenTotalsReset -> currentFuel
            else -> (currentFuel - previous.lastTripFuelLiters).coerceAtLeast(0.0)
        }
        val durationDelta = when {
            firstObservation || tokenChanged || sameTokenTotalsReset -> currentDuration
            // Confirmed ignition-off can retroactively move the segment end a
            // few seconds earlier. Preserve that correction instead of treating
            // it as a segment reset or silently keeping inflated cockpit time.
            else -> currentDuration - previous.lastTripDurationSec
        }

        state = PersistentCockpitTripState(
            totalDistanceKm = (previous.totalDistanceKm + distanceDelta).coerceAtLeast(0.0),
            totalFuelLiters = (previous.totalFuelLiters + fuelDelta).coerceAtLeast(0.0),
            totalDurationSec = (previous.totalDurationSec + durationDelta).coerceAtLeast(0L),
            lastTripToken = tripToken,
            lastTripDistanceKm = currentDistance,
            lastTripFuelLiters = currentFuel,
            lastTripDurationSec = currentDuration
        )
        return state
    }

    /**
     * Adopts a new segment/token without adding its already-accounted values.
     * Needed when late trusted time splits a provisionally restored history
     * segment, and after an explicit history-only finish/reset.
     */
    @Synchronized
    fun rebase(
        tripToken: Long,
        distanceKm: Double,
        fuelLiters: Double,
        durationSec: Long
    ): PersistentCockpitTripState {
        if (tripToken == 0L) return state
        state = state.copy(
            lastTripToken = tripToken,
            lastTripDistanceKm = distanceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
            lastTripFuelLiters = fuelLiters.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
            lastTripDurationSec = durationSec.coerceAtLeast(0L)
        )
        return state
    }

    private fun sanitize(value: PersistentCockpitTripState): PersistentCockpitTripState = value.copy(
        totalDistanceKm = value.totalDistanceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
        totalFuelLiters = value.totalFuelLiters.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
        totalDurationSec = value.totalDurationSec.coerceAtLeast(0L),
        lastTripDistanceKm = value.lastTripDistanceKm.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
        lastTripFuelLiters = value.lastTripFuelLiters.takeIf { it.isFinite() }?.coerceAtLeast(0.0) ?: 0.0,
        lastTripDurationSec = value.lastTripDurationSec.coerceAtLeast(0L)
    )

    private companion object {
        const val DISTANCE_EPSILON_KM = 0.0001
        const val FUEL_EPSILON_L = 0.000001
    }
}
