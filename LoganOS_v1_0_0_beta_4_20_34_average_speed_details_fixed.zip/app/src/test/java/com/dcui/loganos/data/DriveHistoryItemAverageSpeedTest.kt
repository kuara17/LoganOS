package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class DriveHistoryItemAverageSpeedTest {
    private fun item(distanceKm: Double, durationMs: Long) = DriveHistoryItem(
        id = 1L,
        tripToken = 1L,
        startedAtMs = 0L,
        endedAtMs = durationMs.takeIf { it > 0L },
        timeTrusted = true,
        status = "ENDED",
        pinned = false,
        exported = false,
        distanceKm = distanceKm,
        fuelUsedL = 2.189,
        durationMs = durationMs,
        averageL100 = 8.889,
        maxSpeedKmh = 87,
        maxRpm = 3020,
        startTempC = 57,
        endTempC = 83,
        sessionCount = 3
    )

    @Test
    fun averageSpeedUsesPersistedDistanceAndDuration() {
        val result = item(24.626, 4_616_000L).averageSpeedKmh
        assertEquals(19.2057, result!!, 0.001)
    }

    @Test
    fun zeroDurationIsSafe() {
        assertNull(item(24.626, 0L).averageSpeedKmh)
    }

    @Test
    fun zeroDistanceProducesZeroSpeed() {
        assertEquals(0.0, item(0.0, 60_000L).averageSpeedKmh!!, 0.0)
    }
}
