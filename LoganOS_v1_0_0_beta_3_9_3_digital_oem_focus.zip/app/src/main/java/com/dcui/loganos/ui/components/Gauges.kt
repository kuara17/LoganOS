package com.dcui.loganos.ui.components

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val LoganGaugeGreen = Color(0xFF18A84F)
private val LoganGaugeDark = Color(0xFF071122)
private val LoganGaugeRed = Color(0xFFD62828)
private val LoganGaugeGrey = Color(0xFFB8C0CC)

@Composable
fun SpeedGauge(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    modifier: Modifier = Modifier,
    demoMode: Boolean = false
) {
    val maxSpeed = if (style == GaugeStyle.RsPerformance) 260f else 240f
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / maxSpeed).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "speedProgress"
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val gaugeSize = minOf(maxWidth, maxHeight)
            .coerceAtMost(340.dp)
            .coerceAtLeast(120.dp)

        // Only very small preview/landscape slots are compact now.
        // The real portrait cockpit (130/150/170dp) must keep full style identity.
        val compact = maxHeight < 110.dp

        Box(modifier = Modifier.size(gaugeSize), contentAlignment = Alignment.Center) {
            when (style) {
                GaugeStyle.Digital -> DigitalCGauge(palette, progress, compact)
                GaugeStyle.Sport -> SportCGauge(palette, progress, compact)
                GaugeStyle.ClassicOem -> ClassicOemAGauge(palette, progress, compact)
                GaugeStyle.Minimal -> MinimalCGauge(palette, progress, compact)
                GaugeStyle.RsPerformance -> RsPerformanceDGauge(palette, progress, compact)
            }
            SpeedReadout(
                palette = palette,
                speed = speed,
                style = style,
                compact = compact,
                demoMode = demoMode
            )
        }
    }
}

@Composable
private fun SpeedReadout(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    compact: Boolean,
    demoMode: Boolean
) {
    val accent = styleAccent(style, palette)
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            text = speed?.toString() ?: "--",
            color = if (style == GaugeStyle.RsPerformance) LoganGaugeDark else palette.textPrimary,
            fontSize = when {
                compact && style == GaugeStyle.RsPerformance -> 52.sp
                compact -> if (speed == null) 38.sp else 48.sp
                style == GaugeStyle.RsPerformance -> 76.sp
                style == GaugeStyle.Minimal -> 74.sp
                style == GaugeStyle.ClassicOem -> 70.sp
                speed == null -> 54.sp
                else -> 70.sp
            },
            fontWeight = when (style) {
                GaugeStyle.RsPerformance -> FontWeight.Black
                GaugeStyle.ClassicOem -> FontWeight.SemiBold
                GaugeStyle.Sport -> FontWeight.Light
                GaugeStyle.Minimal -> FontWeight.Light
                GaugeStyle.Digital -> FontWeight.Light
            },
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        Text(
            "km/h",
            color = palette.textSecondary,
            fontSize = if (compact) 10.sp else 13.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

private fun styleAccent(style: GaugeStyle, palette: LoganPalette): Color = when (style) {
    GaugeStyle.Digital -> LoganGaugeGreen
    GaugeStyle.Sport -> Color(0xFF22B957)
    GaugeStyle.ClassicOem -> LoganGaugeGreen
    GaugeStyle.Minimal -> LoganGaugeGreen
    GaugeStyle.RsPerformance -> LoganGaugeRed
}


@Composable
fun SpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    modifier: Modifier = Modifier,
    demoMode: Boolean = false,
    previewMode: Boolean = false
) {
    // beta.3.9.3 intentionally exposes a single stable gauge: Digital OEM.
    // The style parameter is kept for API compatibility and future gauge themes,
    // but the active cockpit always renders DigitalSpeedPanel in this build.
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / 240f).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "digitalSpeedPanelProgress"
    )
    DigitalSpeedPanel(
        palette = palette,
        speed = speed,
        progress = progress,
        modifier = modifier,
        demoMode = demoMode,
        previewMode = previewMode
    )
}

@Composable
private fun DigitalSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 120.dp
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = if (compact) 4.dp else 6.dp, vertical = if (compact) 2.dp else 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StyleTitle("HIZ", LoganGaugeGreen, compact)
            Spacer(Modifier.height(if (compact) 2.dp else 4.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth(if (previewMode) .90f else .96f)
                    .fillMaxHeight(),
                contentAlignment = Alignment.Center
            ) {
                DigitalOemGauge(palette, progress, compact)
                PanelReadout(
                    palette = palette,
                    speed = speed,
                    accent = LoganGaugeGreen,
                    demoMode = demoMode,
                    compact = compact,
                    speedSize = when {
                        previewMode -> 54
                        compact -> 58
                        else -> 74
                    },
                    weight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun SportSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 120.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StyleTitle("SPORT", Color(0xFF22B957), compact)
            Box(modifier = Modifier.fillMaxWidth(.96f).fillMaxHeight(.84f), contentAlignment = Alignment.Center) {
                SportCGauge(palette, progress, compact)
                // Extra static motion rails: visible even when progress is zero.
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLine(Color(0xFF22B957).copy(alpha = .32f), Offset(size.width * .12f, size.height * .74f), Offset(size.width * .27f, size.height * .21f), 2.5f, StrokeCap.Round)
                    drawLine(Color(0xFF22B957).copy(alpha = .32f), Offset(size.width * .88f, size.height * .74f), Offset(size.width * .73f, size.height * .21f), 2.5f, StrokeCap.Round)
                    drawLine(Color(0xFF22B957).copy(alpha = .28f), Offset(size.width * .22f, size.height * .60f), Offset(size.width * .34f, size.height * .60f), 2.0f, StrokeCap.Round)
                    drawLine(Color(0xFF22B957).copy(alpha = .28f), Offset(size.width * .66f, size.height * .60f), Offset(size.width * .78f, size.height * .60f), 2.0f, StrokeCap.Round)
                }
                PanelReadout(
                    palette = palette,
                    speed = speed,
                    accent = Color(0xFF22B957),
                    demoMode = demoMode,
                    compact = compact,
                    speedSize = if (previewMode) 54 else 68,
                    weight = FontWeight.Light
                )
            }
        }
    }
}

@Composable
private fun ClassicOemSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 125.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StyleTitle("CLASSIC OEM", Color(0xFF30343A), compact)
            Box(modifier = Modifier.fillMaxWidth(.98f).fillMaxHeight(.86f), contentAlignment = Alignment.Center) {
                ClassicOemAGauge(palette, progress, false)
                // In Classic OEM the analog scale is the hero; readout is smaller and lower.
                Column(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = speed?.toString() ?: "--",
                        color = palette.textPrimary,
                        fontSize = (if (previewMode) 46 else 56).sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                    Text("km/h", color = palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun MinimalSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 120.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(modifier = Modifier.fillMaxWidth(.88f).height(if (compact) 28.dp else 34.dp), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLine(LoganGaugeGreen.copy(alpha = .45f), Offset(size.width * .22f, size.height * .50f), Offset(size.width * .34f, size.height * .50f), 1.8f, StrokeCap.Round)
                    drawLine(LoganGaugeGreen.copy(alpha = .45f), Offset(size.width * .66f, size.height * .50f), Offset(size.width * .78f, size.height * .50f), 1.8f, StrokeCap.Round)
                }
            }
            Box(modifier = Modifier.fillMaxWidth(.92f).fillMaxHeight(.86f), contentAlignment = Alignment.Center) {
                MinimalCGauge(palette, progress, compact)
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(
                        text = speed?.toString() ?: "--",
                        color = palette.textPrimary,
                        fontSize = (if (previewMode) 70 else 86).sp,
                        fontWeight = FontWeight.ExtraLight,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                    Text("km/h", color = palette.textSecondary, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }
}

@Composable
private fun RsPerformanceSpeedPanel(
    palette: LoganPalette,
    speed: Int?,
    progress: Float,
    modifier: Modifier,
    demoMode: Boolean,
    previewMode: Boolean
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val compact = maxHeight < 125.dp
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            StyleTitle("RS PERFORMANCE", LoganGaugeRed, compact)
            Box(modifier = Modifier.fillMaxWidth(.98f).fillMaxHeight(.86f), contentAlignment = Alignment.Center) {
                RsPerformanceDGauge(palette, progress, compact)
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLine(LoganGaugeRed.copy(alpha = .55f), Offset(size.width * .28f, size.height * .73f), Offset(size.width * .72f, size.height * .73f), 2.5f, StrokeCap.Butt)
                    drawLine(LoganGaugeRed.copy(alpha = .28f), Offset(size.width * .34f, size.height * .80f), Offset(size.width * .66f, size.height * .80f), 2.0f, StrokeCap.Butt)
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(
                        text = speed?.toString() ?: "--",
                        color = LoganGaugeDark,
                        fontSize = (if (previewMode) 78 else 94).sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                    Text("km/h", color = palette.textSecondary, fontSize = 13.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

@Composable
private fun StyleTitle(text: String, accent: Color, compact: Boolean) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.width(if (compact) 22.dp else 30.dp).height(1.dp).background(accent.copy(alpha = .60f)))
        Text(
            text = text,
            color = accent,
            fontSize = if (compact) 14.sp else 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.1.sp,
            maxLines = 1,
            textAlign = TextAlign.Center
        )
        Box(Modifier.width(if (compact) 22.dp else 30.dp).height(1.dp).background(accent.copy(alpha = .60f)))
    }
}

@Composable
private fun PanelReadout(
    palette: LoganPalette,
    speed: Int?,
    accent: Color,
    demoMode: Boolean,
    compact: Boolean,
    speedSize: Int,
    weight: FontWeight
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(
            text = speed?.toString() ?: "--",
            color = palette.textPrimary,
            fontSize = (if (compact) (speedSize * .74f) else speedSize.toFloat()).sp,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
        Text("km/h", color = palette.textSecondary, fontSize = if (compact) 10.sp else 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun DigitalOemGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val stroke = if (compact) 3.2f else 4.8f
        val tickStroke = if (compact) .9f else 1.25f
        val arcSize = Size(size.width * .78f, size.height * .78f)
        val topLeft = Offset((size.width - arcSize.width) / 2f, size.height * .14f)
        val startAngle = 160f
        val sweepAngle = 220f
        val center = Offset(size.width / 2f, topLeft.y + arcSize.height / 2f)
        val radius = arcSize.width / 2f

        // Digital OEM skeleton: always visible at zero speed / disconnected.
        drawArc(
            color = palette.line.copy(alpha = .34f),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )

        for (i in 0..44) {
            val frac = i / 44f
            val angle = (startAngle + sweepAngle * frac) * PI.toFloat() / 180f
            val major = i % 4 == 0
            val inner = radius - if (major) 17f else 9f
            val outer = radius - 1f
            drawLine(
                color = palette.textSecondary.copy(alpha = if (major) .34f else .18f),
                start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                strokeWidth = if (major) tickStroke + .35f else tickStroke,
                cap = StrokeCap.Round
            )
        }

        if (progress > 0f) {
            drawArc(
                color = LoganGaugeGreen.copy(alpha = .96f),
                startAngle = startAngle,
                sweepAngle = sweepAngle * progress.coerceIn(0f, 1f),
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke + .8f, cap = StrokeCap.Round)
            )
        }

        val dotProgress = progress.coerceIn(0f, 1f)
        val dotAngle = (startAngle + sweepAngle * dotProgress) * PI.toFloat() / 180f
        drawCircle(
            color = LoganGaugeGreen.copy(alpha = if (progress > 0f) 1f else .72f),
            radius = if (compact) 3.8f else 5.5f,
            center = Offset(center.x + cos(dotAngle) * radius, center.y + sin(dotAngle) * radius)
        )
    }
}

@Composable
private fun DigitalCGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    DigitalOemGauge(palette, progress, compact)
}

@Composable
private fun SportCGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val stroke = if (compact) 4.5f else 6.5f
        val arcSize = Size(size.width * .86f, size.height * .80f)
        val topLeft = Offset((size.width - arcSize.width) / 2f, size.height * .11f)
        val startAngle = 158f
        val sweepAngle = 224f
        val center = Offset(size.width / 2f, topLeft.y + arcSize.height / 2f)
        val radius = arcSize.width / 2f

        // Static sport background arc, independent from progress.
        drawArc(
            color = palette.line.copy(alpha = .38f),
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = topLeft,
            size = arcSize,
            style = Stroke(width = stroke, cap = StrokeCap.Round)
        )

        // Static sport frame / motion accents: Sport must be recognizable at speed 0.
        val leftX = size.width * .18f
        val rightX = size.width * .82f
        val yMid = size.height * .54f
        drawLine(LoganGaugeGreen.copy(alpha = .55f), Offset(leftX, yMid), Offset(leftX + size.width * .12f, yMid), 2.2f, StrokeCap.Round)
        drawLine(LoganGaugeGreen.copy(alpha = .55f), Offset(rightX - size.width * .12f, yMid), Offset(rightX, yMid), 2.2f, StrokeCap.Round)
        drawLine(LoganGaugeGreen.copy(alpha = .45f), Offset(size.width * .20f, size.height * .68f), Offset(size.width * .29f, size.height * .23f), 2.0f, StrokeCap.Round)
        drawLine(LoganGaugeGreen.copy(alpha = .45f), Offset(size.width * .80f, size.height * .68f), Offset(size.width * .71f, size.height * .23f), 2.0f, StrokeCap.Round)

        // Static full-dial ticks.
        for (i in 0..28) {
            val frac = i / 28f
            val angle = (startAngle + sweepAngle * frac) * PI.toFloat() / 180f
            val major = i % 4 == 0
            val inner = radius - if (major) 18f else 10f
            val outer = radius - 2f
            drawLine(
                color = palette.textSecondary.copy(alpha = if (major) .42f else .22f),
                start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                strokeWidth = if (major) 1.6f else 1.0f,
                cap = StrokeCap.Round
            )
        }

        if (progress > 0f) {
            drawArc(
                color = LoganGaugeGreen,
                startAngle = startAngle,
                sweepAngle = sweepAngle * progress,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke + 1.2f, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun ClassicOemAGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height * .70f)
        val radius = size.minDimension * .50f
        val start = 180f
        val sweep = 180f
        drawArc(
            color = palette.line.copy(alpha = .75f),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            style = Stroke(width = 1.6f, cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2)
        )
        for (i in 0..60) {
            val frac = i / 60f
            val angle = (start + sweep * frac) * PI.toFloat() / 180f
            val major = i % 10 == 0
            val inner = radius - if (major) 20f else 10f
            val outer = radius
            drawLine(
                color = if (major) Color(0xFF2E333A) else palette.textSecondary.copy(alpha = .35f),
                start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                strokeWidth = if (major) 2.6f else 1.1f,
                cap = StrokeCap.Round
            )
        }
        val labels = listOf(0 to "0", 25 to "50", 50 to "100", 75 to "150", 100 to "200")
        val labelRadiusOffset = if (compact) 28f else 36f
        val labelSize = if (compact) 13f else 19f
        labels.forEach { (pct, text) ->
            val frac = pct / 100f
            val angle = (start + sweep * frac) * PI.toFloat() / 180f
            val p = Offset(center.x + cos(angle) * (radius - labelRadiusOffset), center.y + sin(angle) * (radius - labelRadiusOffset))
            drawContext.canvas.nativeCanvas.drawText(text, p.x, p.y + 4f, Paint().apply {
                isAntiAlias = true
                color = Color(0xFF30343A).toArgb()
                textSize = labelSize
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            })
        }
        val angle = (start + sweep * progress) * PI.toFloat() / 180f
        drawLine(LoganGaugeGreen, center, Offset(center.x + cos(angle) * (radius - 18f), center.y + sin(angle) * (radius - 18f)), if (compact) 3.2f else 4.6f, StrokeCap.Round)
        drawCircle(LoganGaugeGreen, radius = if (compact) 4f else 6.5f, center = center)
        // Small fuel scale detail, matching Classic OEM A reference.
        drawLine(palette.textSecondary.copy(alpha = .40f), Offset(size.width * .32f, size.height * .88f), Offset(size.width * .68f, size.height * .88f), 1.7f, StrokeCap.Round)
        drawTextNative("E", Offset(size.width * .27f, size.height * .80f), 14f, LoganGaugeRed)
        drawTextNative("F", Offset(size.width * .73f, size.height * .80f), 14f, LoganGaugeGreen)
    }
}

@Composable
private fun MinimalCGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height * .66f)
        val radius = size.minDimension * .48f
        val start = 205f
        val sweep = 130f
        drawArc(
            color = palette.line.copy(alpha = .34f),
            startAngle = start,
            sweepAngle = sweep,
            useCenter = false,
            style = Stroke(width = 1.2f, cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2)
        )
        drawArc(
            color = LoganGaugeGreen.copy(alpha = .90f),
            startAngle = start,
            sweepAngle = sweep * progress,
            useCenter = false,
            style = Stroke(width = if (compact) 2.4f else 3.2f, cap = StrokeCap.Round),
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2)
        )
        // Minimal C identity: almost no ticks, only two quiet horizontal strokes.
        drawLine(LoganGaugeGreen.copy(alpha = .55f), Offset(size.width * .08f, size.height * .53f), Offset(size.width * .23f, size.height * .53f), 2.2f, StrokeCap.Round)
        drawLine(LoganGaugeGreen.copy(alpha = .55f), Offset(size.width * .77f, size.height * .53f), Offset(size.width * .92f, size.height * .53f), 2.2f, StrokeCap.Round)
    }
}

@Composable
private fun RsPerformanceDGauge(palette: LoganPalette, progress: Float, compact: Boolean) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val arcSize = Size(size.width * .86f, size.height * .80f)
        val topLeft = Offset((size.width - arcSize.width) / 2f, size.height * .11f)
        val startAngle = 160f
        val sweepAngle = 220f
        val segmentCount = 22
        val gap = 3.2f
        val segmentSweep = (sweepAngle / segmentCount) - gap
        val inactive = Color(0xFFD8DDE4).copy(alpha = .95f)

        // Static segmented RS bar: all segments are visible even when progress == 0.
        for (i in 0 until segmentCount) {
            val segmentStart = startAngle + sweepAngle * (i / segmentCount.toFloat())
            val segmentProgressLimit = (i + 1) / segmentCount.toFloat()
            val color = if (progress >= segmentProgressLimit) LoganGaugeRed else inactive
            drawArc(
                color = color,
                startAngle = segmentStart,
                sweepAngle = segmentSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = if (compact) 5.5f else 8f, cap = StrokeCap.Butt)
            )
        }

        // Red RS corner marks stay visible at zero speed.
        drawLine(LoganGaugeRed.copy(alpha = .95f), Offset(size.width * .20f, size.height * .62f), Offset(size.width * .30f, size.height * .28f), if (compact) 3f else 4.5f, StrokeCap.Butt)
        drawLine(LoganGaugeRed.copy(alpha = .95f), Offset(size.width * .80f, size.height * .62f), Offset(size.width * .70f, size.height * .28f), if (compact) 3f else 4.5f, StrokeCap.Butt)

        // Static performance underline.
        drawLine(palette.textPrimary.copy(alpha = .55f), Offset(size.width * .32f, size.height * .78f), Offset(size.width * .68f, size.height * .78f), 2.2f, StrokeCap.Round)
        drawLine(LoganGaugeRed.copy(alpha = .45f), Offset(size.width * .38f, size.height * .84f), Offset(size.width * .62f, size.height * .84f), 2f, StrokeCap.Round)
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawArcTicks(
    center: Offset,
    radius: Float,
    startDeg: Float,
    sweepDeg: Float,
    tickCount: Int,
    progress: Float,
    activeColor: Color,
    inactiveColor: Color,
    activeWidth: Float = 2.0f
) {
    for (i in 0..tickCount) {
        val frac = i / tickCount.toFloat()
        val angle = (startDeg + sweepDeg * frac) * PI.toFloat() / 180f
        val longTick = i % 5 == 0
        val inner = radius - if (longTick) 18f else 10f
        val outer = radius
        val c = if (frac <= progress) activeColor.copy(alpha = .88f) else inactiveColor
        drawLine(
            color = c,
            start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
            end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
            strokeWidth = if (longTick) activeWidth else 1.1f,
            cap = StrokeCap.Round
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawTextNative(text: String, pos: Offset, sizePx: Float, color: Color) {
    drawContext.canvas.nativeCanvas.drawText(text, pos.x, pos.y, Paint().apply {
        isAntiAlias = true
        this.color = color.toArgb()
        textSize = sizePx
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    })
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    val accent = styleAccent(style, palette)
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.height(262.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(palette.surfaceVariant.copy(alpha = .38f))
                .border(1.dp, if (selected) accent.copy(alpha = .70f) else palette.line, RoundedCornerShape(24.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            SpeedPanel(
                palette = palette,
                speed = when (style) {
                    GaugeStyle.RsPerformance -> 128
                    else -> 90
                },
                style = style,
                modifier = Modifier.fillMaxWidth(.96f).height(170.dp),
                demoMode = false,
                previewMode = true
            )
        }
        Text(style.label, color = if (selected) accent else palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewSpeedText(palette: LoganPalette, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("42", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.size(width = 34.dp, height = 4.dp).clip(CircleShape).background(accent.copy(alpha = .70f)))
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Digital C • modern dijital"
    GaugeStyle.Sport -> "Sport C • dinamik çizgiler"
    GaugeStyle.ClassicOem -> "Classic OEM A • analog ibre"
    GaugeStyle.Minimal -> "Minimal C • sade dijital"
    GaugeStyle.RsPerformance -> "RS D • kırmızı performans"
}
