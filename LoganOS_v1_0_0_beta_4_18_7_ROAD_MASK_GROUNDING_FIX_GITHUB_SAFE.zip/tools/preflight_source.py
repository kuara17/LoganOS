#!/usr/bin/env python3
"""Fast source/resource preflight executed before Gradle.

This does not replace the Android/Kotlin compiler. It catches common packaging
mistakes early: malformed XML, missing app resources, invalid resource names,
and Compose scope-member imports that previously broke LoganOS builds.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RESOURCE_NAME = re.compile(r"^[a-z][a-z0-9_]*$")
R_REF = re.compile(r"\bR\.(drawable|mipmap|string|color|dimen|style|xml|raw|font)\.([A-Za-z0-9_]+)\b")
INVALID_IMPORTS = {
    "import androidx.compose.foundation.layout.matchParentSize": "matchParentSize is a BoxScope member and must not be imported",
    "import androidx.compose.foundation.layout.weight": "weight is a RowScope/ColumnScope member and must not be imported",
}

# Kotlin rejects non-local break/continue from scope-function lambdas unless an
# experimental language feature is enabled. LoganOS does not enable that feature;
# keep polling-loop control flow outside let/run/also/apply lambdas.
INLINE_LAMBDA_LOOP_CONTROL = re.compile(
    r"(?:\?\.|\.)\s*(?:let|run|also|apply)\s*\{(?:(?!\n\s*\}).){0,1200}\b(?:break|continue)\b",
    re.S,
)


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def passed(message: str) -> None:
    print(f"[PASS] {message}")



def read_webp_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if len(data) < 30 or data[:4] != b"RIFF" or data[8:12] != b"WEBP":
        fail(f"Invalid WebP asset: {path}")
    fourcc = data[12:16]
    if fourcc == b"VP8 ":
        payload = 20
        if data[payload + 3:payload + 6] != b"\x9d\x01\x2a":
            fail(f"Unsupported VP8 frame header: {path}")
        width = int.from_bytes(data[payload + 6:payload + 8], "little") & 0x3FFF
        height = int.from_bytes(data[payload + 8:payload + 10], "little") & 0x3FFF
        return width, height
    if fourcc == b"VP8X":
        payload = 20
        width = 1 + int.from_bytes(data[payload + 4:payload + 7], "little")
        height = 1 + int.from_bytes(data[payload + 7:payload + 10], "little")
        return width, height
    if fourcc == b"VP8L":
        payload = 20
        if data[payload] != 0x2F:
            fail(f"Unsupported VP8L frame header: {path}")
        bits = int.from_bytes(data[payload + 1:payload + 5], "little")
        width = (bits & 0x3FFF) + 1
        height = ((bits >> 14) & 0x3FFF) + 1
        return width, height
    fail(f"Unsupported WebP encoding {fourcc!r}: {path}")




def read_png_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if len(data) < 24 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        fail(f"Invalid PNG asset: {path}")
    width = int.from_bytes(data[16:20], "big")
    height = int.from_bytes(data[20:24], "big")
    return width, height

def validate_digital_v2(root: Path) -> None:
    asset_dir = root / "app/src/main/res/drawable-nodpi"
    source_dir = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/opengl"
    cockpit = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt"
    manifest = root / "app/src/main/AndroidManifest.xml"
    build_file = root / "app/build.gradle.kts"

    required_sources = (
        "DigitalV2SceneModel.kt",
        "DigitalV2AnimationMath.kt",
        "DigitalV2RenderState.kt",
        "DigitalV2SceneAssets.kt",
        "DigitalV2Renderer.kt",
        "LoganGLSurfaceView.kt",
        "OpenGLSceneHost.kt",
    )
    for name in required_sources:
        if not (source_dir / name).is_file():
            fail(f"Digital V2 OpenGL source is missing: {name}")

    scene_keys = ("mountain_lake", "city_day", "city_night", "snow_road")
    for key in scene_keys:
        asset = asset_dir / f"digital_v2_{key}_bg.webp"
        if not asset.is_file():
            fail(f"Digital V2 background is missing: {asset.name}")
        width, height = read_webp_size(asset)
        if (width, height) != (1080, 1320):
            fail(f"Digital V2 stage must be exactly 1080x1320: {asset.name} is {width}x{height}")
        if asset.stat().st_size > 500_000:
            fail(f"Digital V2 stage is unexpectedly large: {asset.name}={asset.stat().st_size} bytes")

        road_map = asset_dir / f"digital_v2_{key}_road_map.png"
        if not road_map.is_file():
            fail(f"Digital V2 road visibility map is missing: {road_map.name}")
        if read_png_size(road_map) != (256, 256):
            fail(f"Digital V2 road visibility map must be 256x256: {road_map.name}")
        if road_map.stat().st_size > 80_000:
            fail(f"Digital V2 road visibility map is unexpectedly large: {road_map.name}")

    for name in ("digital_v2_ground_shadow_logan1.webp", "digital_v2_ground_shadow_logan3.webp"):
        asset = asset_dir / name
        if not asset.is_file() or read_webp_size(asset) != (1014, 260):
            fail(f"Digital V2 model-matched ground shadow is missing or invalid: {name}")

    retired_assets = sorted(
        p.name for p in asset_dir.glob("digital_v2_*.webp")
        if re.search(r"_(?:road|wind)_(?:static|blur|\d{2})\.webp$", p.name)
    )
    if retired_assets:
        fail("Retired baked road/wind frame assets are still packaged: " + ", ".join(retired_assets[:8]))

    if (root / "app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2SceneEngine.kt").exists():
        fail("Retired Compose DigitalV2SceneEngine.kt must not coexist with the OpenGL renderer")

    scene_model = (source_dir / "DigitalV2SceneModel.kt").read_text(encoding="utf-8")
    scene_profiles = (source_dir / "DigitalV2SceneProfiles.kt").read_text(encoding="utf-8")
    mesh_builder = (source_dir / "DigitalV2RoadMeshBuilder.kt").read_text(encoding="utf-8")
    shaders = (source_dir / "DigitalV2Shaders.kt").read_text(encoding="utf-8")
    renderer = (source_dir / "DigitalV2Renderer.kt").read_text(encoding="utf-8")
    host = (source_dir / "OpenGLSceneHost.kt").read_text(encoding="utf-8")
    surface = (source_dir / "LoganGLSurfaceView.kt").read_text(encoding="utf-8")
    cockpit_text = cockpit.read_text(encoding="utf-8")

    required_model_tokens = (
        "DIGITAL_V2_LOGICAL_WIDTH = 1080f",
        "DIGITAL_V2_LOGICAL_HEIGHT = 1320f",
        "CalibrationPoint",
        "CalibratedCurve",
        "DigitalV2RoadCalibration",
        "RoadMarkingPattern",
        "centerNearFadeStartMeters",
        "centerNearFadeEndMeters",
        "dashLengthMeters: Float = 3f",
        "gapLengthMeters: Float = 6f",
        "centerLineWidthMeters: Float = 0.15f",
        "VehicleAssetProfile",
        "leftTireContactXRatioInTexture",
        "rightTireContactXRatioInTexture",
        "VehicleShadowProfile",
        "VehicleColorGrade",
        "upperRedMultiplier",
        "lowerBlueMultiplier",
        "VehicleScenePose",
        "WindZoneProfile",
        "RoadSurfaceMotionProfile",
    )
    for token in required_model_tokens:
        if token not in scene_model:
            fail(f"Digital V2 calibrated scene model is incomplete: {token}")

    required_profile_tokens = (
        "object DigitalV2SceneModels",
        "val MountainLake",
        "val CityDay",
        "val CityNight",
        "val SnowRoad",
        "centerLine = curve(",
        "leftRoadEdge = curve(",
        "rightRoadEdge = curve(",
        "visibleWidthRatio = 0.335f",
        "centerXRatio = 0.500f",
        "tireContactYRatio",
        "showLeftEdgeLine = true",
        "showRightEdgeLine = true",
    )
    for token in required_profile_tokens:
        if token not in scene_profiles:
            fail(f"Digital V2 scene-specific calibration is incomplete: {token}")
    if scene_profiles.count("CalibrationPoint(") < 90:
        fail("Digital V2 backgrounds are not independently calibrated with enough road points")

    required_mesh_tokens = (
        "RoadRibbonMeshData",
        "buildCalibratedLineMesh",
        "buildCalibratedRoadSurfaceMesh",
        "buildCalibratedWindZoneMesh",
        "RoadCurveRole.CenterLine",
        "RoadSide.Left",
        "minimumVisibleWidthPixels",
    )
    for token in required_mesh_tokens:
        if token not in mesh_builder:
            fail(f"Digital V2 calibrated mesh builder is incomplete: {token}")

    required_renderer_tokens = (
        "class DigitalV2Renderer",
        "GLSurfaceView.Renderer",
        "AtomicReference",
        "totalTravelledMeters",
        "roadPatternPhaseMeters",
        "windTravelPhaseMeters",
        "roadSurfacePhaseMeters",
        "nextDigitalV2SmoothedSpeedKmh",
        "RoadMarkingProgram",
        "RoadSurfaceProgram",
        "WindProgram",
        "RoadMeshSet",
        "nextRoadMeshRetryNanos",
        "SimpleTexturedProgram",
        "VehicleTexturedProgram",
        "buildCalibratedLineMesh",
        "buildCalibratedRoadSurfaceMesh",
        "buildCalibratedWindZoneMesh",
        "GLES20.glGenBuffers",
        "GLES20.glBufferData",
        "GLES20.GL_TRIANGLE_STRIP",
        "drawVehicleGroundShadow",
        "leftTireX",
        "rightTireX",
        "groundBlendWidthRatio",
        "grade = pose.colorGrade",
        "TEXTURE_RETRY_DELAY_NANOS",
        "GLES20.GL_ONE",
        "roadMapTexture",
        "loadedRoadMapRes",
    )
    for token in required_renderer_tokens:
        if token not in renderer:
            fail(f"Digital V2 OpenGL renderer contract is incomplete: {token}")

    required_shader_tokens = (
        "object DigitalV2Shaders",
        "SIMPLE_TEXTURED_FRAGMENT_SHADER",
        "VEHICLE_FRAGMENT_SHADER",
        "uGradeRgb",
        "uAmbientTop",
        "uAmbientBottom",
        "uRoadMap",
        "uNearFadeStartMeters",
        "uNearFadeEndMeters",
        "sampled.rgb / max(sampled.a",
        "ROAD_SURFACE_VERTEX_SHADER",
        "WIND_VERTEX_SHADER",
        "ROAD_VERTEX_SHADER",
        "gl_Position = vec4(aPosition",
        "aRoadDistance * 0.125",
    )
    for token in required_shader_tokens:
        if token not in shaders:
            fail(f"Digital V2 shader package is incomplete: {token}")

    retired_blob = scene_model + scene_profiles + mesh_builder + renderer + cockpit_text
    for retired_token in (
        "RoadProjectionSample",
        "RoadProjectionProfile",
        "RoadProjectiveCameraProfile",
        "RoadCurveProfile",
        "buildRoadRibbonMesh",
        "val clipMatrix: FloatArray",
        "worldLateralMeters",
        "anchorDistanceMeters",
        "rawT * rawT * (3f - 2f * rawT)",
        "drawRoadStrip(",
        "drawWindParticle(",
    ):
        if retired_token in retired_blob:
            fail(f"Retired generic/projective road system is still packaged: {retired_token}")

    if cockpit_text.count("OpenGLSceneHost(") != 1 or "digitalV2RenderState(" not in cockpit_text:
        fail("Digital V2 cockpit must use exactly one live OpenGL scene host")
    if "DigitalV2StaticVehiclePreview(" not in cockpit_text or "DigitalV2StaticRoadPreview(" not in cockpit_text:
        fail("Digital V2 settings preview must use the same calibrated road and vehicle models without a second GLSurfaceView")
    for retired in ("DigitalV2RoadLayer(", "DigitalV2WindLayer(", "DigitalV2Vehicle(", "DigitalV2SceneSpec"):
        if retired in cockpit_text:
            fail(f"Retired Compose scene layer is still used: {retired}")
    render_state = (source_dir / "DigitalV2RenderState.kt").read_text(encoding="utf-8")
    scene_assets = (source_dir / "DigitalV2SceneAssets.kt").read_text(encoding="utf-8")
    if "roadMapResId" not in render_state or "digitalV2RoadMapRes" not in scene_assets:
        fail("Digital V2 scene road maps are not wired into render state")
    if renderer.count("buildCalibratedLineMesh(") < 2 or "buildCalibratedRoadSurfaceMesh(" not in renderer or renderer.count("buildCalibratedWindZoneMesh(") < 2:
        fail("Digital V2 must upload centre, edges, exact road surface and off-road wind ribbons")
    if "loadedBackgroundRes = state.backgroundResId" in renderer and "candidate != null" not in renderer:
        fail("Texture resource IDs may only advance after a successful GL upload")
    if "precision highp float" in shaders or "varying highp float vRoadDistance" in shaders:
        fail("Digital V2 shaders must preserve ES 2.0 mediump compatibility")
    if shaders.count("aRoadDistance * 0.125") < 3:
        fail("Digital V2 must scale road distance before mediump fragment interpolation")
    if "sabit koordinatlarla hesaplanır" in cockpit_text or "projective OpenGL road mesh" in cockpit_text:
        fail("Digital V2 settings copy still describes the retired generic projection system")

    if "AndroidView(" not in host or "LifecycleEventObserver" not in host:
        fail("OpenGLSceneHost must bind GLSurfaceView to Compose and lifecycle")
    if "setEGLContextClientVersion(2)" not in surface:
        fail("Digital V2 must request an OpenGL ES 2.0 context")
    if "RENDERMODE_WHEN_DIRTY" not in surface or "RENDERMODE_CONTINUOUSLY" not in surface:
        fail("Digital V2 render mode switching is incomplete")

    if 'android:glEsVersion="0x00020000"' not in manifest.read_text(encoding="utf-8"):
        fail("Android manifest does not declare the OpenGL ES 2.0 requirement")
    if "lifecycle-runtime-compose:2.8.7" not in build_file.read_text(encoding="utf-8"):
        fail("Compose lifecycle dependency for OpenGL host is missing")

    passed("Digital V2 image-calibrated road maps, masked road/shoulder VBOs, near-vehicle divider suppression, directional vehicle grading and retired-runtime cleanup validated")


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    res = root / "app/src/main/res"
    source = root / "app/src/main/java"
    if not res.is_dir() or not source.is_dir():
        fail("Android source tree is incomplete")

    resources: dict[str, set[str]] = {key: set() for key in ("drawable", "mipmap", "string", "color", "dimen", "style", "xml", "raw", "font")}

    xml_count = 0
    for path in sorted(res.rglob("*.xml")):
        try:
            tree = ET.parse(path)
        except ET.ParseError as exc:
            fail(f"Malformed XML: {path.relative_to(root)}: {exc}")
        xml_count += 1
        parent = path.parent.name.split("-", 1)[0]
        if parent in ("drawable", "mipmap", "xml", "font"):
            resources[parent].add(path.stem)
        if parent == "values":
            for child in tree.getroot():
                name = child.attrib.get("name")
                tag = child.tag.split("}")[-1]
                if not name:
                    continue
                kind = "style" if tag == "style" else tag
                if kind in resources:
                    resources[kind].add(name)
    passed(f"{xml_count} Android XML file parsed successfully")

    file_types = {
        "drawable": ("drawable",),
        "mipmap": ("mipmap",),
        "raw": ("raw",),
        "font": ("font",),
        "xml": ("xml",),
    }
    for kind, prefixes in file_types.items():
        for directory in res.iterdir():
            if not directory.is_dir() or directory.name.split("-", 1)[0] not in prefixes:
                continue
            for path in directory.iterdir():
                if path.is_file():
                    resources[kind].add(path.stem)
                    if not RESOURCE_NAME.fullmatch(path.stem):
                        fail(f"Invalid Android resource filename: {path.relative_to(root)}")
    passed("Android resource filenames are valid")

    kt_files = list(source.rglob("*.kt"))
    missing: list[str] = []
    for path in kt_files:
        text = path.read_text(encoding="utf-8")
        for token, label in INVALID_IMPORTS.items():
            if token in text:
                fail(f"{label}: {path.relative_to(root)}")
        if INLINE_LAMBDA_LOOP_CONTROL.search(text):
            fail(
                "Kotlin break/continue must not escape an inline scope-function lambda: "
                f"{path.relative_to(root)}"
            )
        for kind, name in R_REF.findall(text):
            if name not in resources[kind]:
                missing.append(f"{path.relative_to(root)} -> R.{kind}.{name}")
    if missing:
        fail("Missing app resource reference(s):\n  " + "\n  ".join(sorted(set(missing))))
    passed(f"{len(kt_files)} Kotlin file checked for resource references and known invalid imports")

    validate_digital_v2(root)

    manifest = root / "app/src/main/AndroidManifest.xml"
    if not manifest.is_file():
        fail("AndroidManifest.xml is missing")
    passed("Android source/resource preflight completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
