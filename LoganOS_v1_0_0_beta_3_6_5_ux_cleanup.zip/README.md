# LoganOS

Version: **1.0.0-beta.3.6.5**

## Beta 3.6.5 UX Hotfix

SQLite migration/lifecycle hotfix, Android 8/9 storage permission fix, and version-label cleanup on top of the beta 3.6.3 test/log/setup/technical-screen work.


This build keeps the validated Fuel Truth, Smart Trip and SQL trip logging foundation, then cleans up test logging, setup selections and the technical screen.

Highlights:

- FuelAlgorithmV3 retained.
- Smart Trip / TripComputer retained.
- SQL trip logging retained and export format improved.
- Normal logs export readable summary values instead of raw ECU hex packets.
- Optional Long Trip Log for lighter long-distance recording.
- Optional Developer Raw Log for 21A0 / 21A2 / 21CC / 21CD packets.
- Technical screen now shows useful advanced live data and OBD quality counters.
- Setup requires explicit user selections.
- Supported vehicle profile is simplified to Dacia Logan 2005-2012 Sedan/MCV 1.5 dCi 68 bg.



### Beta 3.6.5 UX notes
Developer tools are separated from About. Normal users see automatic smart logging; raw ECU logs remain developer-only. Fan remains unverified and is shown with coolant temperature as “test pending”.
