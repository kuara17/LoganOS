# LoganOS beta.4.20.9 — Changed files

## Code
- `app/build.gradle.kts` — version 1.0.0-beta.4.20.9 / code 100000809.
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneAssets.kt` — 48-way scene/model/color mapping; separate Digital V2 vehicle/road/shadow resource IDs disabled.
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2Renderer.kt` — baked scene center-crop UV rendering; no separate vehicle draw for baked scene state; no unused road mesh upload.
- `app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt` — settings preview and scene tiles use the exact baked composite asset; obsolete motion control removed.
- `tools/validate_release.py` and `tools/preflight_source.py` — restored CI validation gates referenced by GitHub Actions.

## Assets
- Added 48 `digital_v2_<scene>_<logan1|logan3>_<color>.webp` files.
- Removed legacy Digital V2 background, road-map, cast/contact-shadow and ground-shadow files.
- Removed unreferenced legacy Ghost scene/horizon/vehicle resources.
- Recompressed five active large opaque scenery WebPs at quality 90 without changing dimensions.

Shared Logan vehicle assets used by Classic/Ghost/Premium/vehicle-selection screens were intentionally retained; Digital V2 no longer references them.
