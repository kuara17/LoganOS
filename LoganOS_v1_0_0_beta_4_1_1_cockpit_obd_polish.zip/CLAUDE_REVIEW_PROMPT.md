# Review Prompt — LoganOS v1.0.0-beta.4.0.0

Review this Android/Kotlin/Jetpack Compose project as a reliability-foundation and build-readiness pass.

## Intended changes

1. SQLite v1 records migrate to v2 without destructive table drops.
2. WAL, foreign keys, transactions and recovery of ACTIVE sessions improve abrupt power-loss behavior.
3. Durations use `SystemClock.elapsedRealtime`; GPS/system wall time may arrive late and is anchored/re-anchored by boot session.
4. Smart Trip supports every ignition / 30 / 60(default) / 90 minute separation, process restart persistence and “End Trip Now”.
5. Device mode supports Automatic / Phone / Android Head Unit without rerunning setup.
6. Portrait/landscape UI adapts to small and large screens.
7. Text Size and Cockpit Density visibly affect both portrait and landscape cockpit.
8. Digital OEM remains the only active gauge and stays circular without clipping.
9. Active cockpit PNG assets are centered and no icon background/border is added.
10. BuildConfig version is `1.0.0-beta.4.0.0`; GitHub Actions supports debug and permanently signed release builds.
11. About includes the independent-project disclaimer and ChatGPT/Gemini/Claude development credit.

## Must remain unchanged

- KWP init/poll command order and timeouts
- Delphi parser byte positions
- FuelAlgorithmV3 formulas
- injection mg/stroke fuel calculation
- CUTOFF / COAST_GUARD behavior
- AC_FAST primary bit
- Fan UNKNOWN policy
- OBD speed value/scaling

## Please report

- Compile blockers and invalid Compose/Kotlin/Gradle calls
- Migration/query errors against a real v1 schema
- Power-cut, reboot, late-clock and Smart Trip boundary edge cases
- Callback/signature wiring mistakes
- Responsive UI clipping/scroll regressions
- Release signing workflow problems
- Any accidental modification to frozen parser/fuel/KWP behavior
