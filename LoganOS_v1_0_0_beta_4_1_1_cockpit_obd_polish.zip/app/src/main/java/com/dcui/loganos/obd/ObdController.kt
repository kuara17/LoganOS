package com.dcui.loganos.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.data.LoganSqlStore
import com.dcui.loganos.data.TimeMark
import com.dcui.loganos.data.TrustedTimeSource
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.TripMetricReset
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.ArrayDeque
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

private data class DeveloperTestPhase(
    val title: String,
    val seconds: Int
)

private data class PendingTripBoundary(
    val disconnectedAt: TimeMark?,
    val restoredPrefix: TripComputerPersistedState
)

class ObdController(private val context: Context) {
    var state by mutableStateOf(ObdState())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var developerTestJob: Job? = null
    private var socket: BluetoothSocket? = null
    private val parser = DelphiParser()
    private val tripComputer = TripComputer()
    private val timeSource = TrustedTimeSource(context)
    private val sqlStore = LoganSqlStore(context, timeSource)
    private var currentSqlSessionId: Long? = null
    private var lastSqlSessionId: Long? = null
    private var rawEcuLogEnabled: Boolean = false
    private var longTripLogEnabled: Boolean = false
    private var lastSqlSampleMs: Long = 0L
    private var activeTripHistoryId: Long? = null
    private var activeDeveloperTestHistoryId: Long? = null
    private var activeCrankTestHistoryId: Long? = null
    private val engineTempWindow = ArrayDeque<Int>()
    private var runtimeSettings: LoganSettings = LoganSettings()
    private var smartTripMinutes: Int = 60
    private var lastDisconnectMark: TimeMark? = null
    private val tripPrefs = context.getSharedPreferences("loganos_trip_runtime", Context.MODE_PRIVATE)
    private var lastTripPersistElapsedMs: Long = 0L
    private var pendingTripBoundary: PendingTripBoundary? = null
    private var lastAcMismatchSignature: String? = null
    private val crankPrefs = context.getSharedPreferences("loganos_crank_tests", Context.MODE_PRIVATE)
    private var lastRpmForCrank: Int? = null
    private var crankStartMs: Long? = null
    private var crankStartVoltage: Double? = null
    private var crankMinVoltage: Double? = null
    private var crankTempC: Int? = null
    private var crankObdGapDetected: Boolean = false
    private var crankManual: Boolean = false
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    init {
        val recovered = runCatching { sqlStore.recoverOpenSessions() }.getOrDefault(0)
        val historyRecovered = runCatching { sqlStore.recoverOpenHistory() }.getOrDefault(0 to 0)
        val recoveredDrives = runCatching { sqlStore.listDriveHistory() }.getOrDefault(emptyList())
        val rememberedHistoryId = tripPrefs.getLong(KEY_ACTIVE_HISTORY_ID, 0L).takeIf { it > 0L }
        activeTripHistoryId = rememberedHistoryId?.takeIf { id -> recoveredDrives.any { it.id == id && it.activeLike } }
        if (rememberedHistoryId != null && activeTripHistoryId == null) saveActiveTripHistory(null)
        state = state.copy(
            savedManualCrankTests = loadManualCrankTests(),
            timeTrusted = timeSource.isTrusted(),
            driveHistory = recoveredDrives,
            testHistory = runCatching { sqlStore.listTestHistory() }.getOrDefault(emptyList()),
            historyStorage = runCatching { sqlStore.historyStorageInfo() }.getOrDefault(state.historyStorage),
            status = when {
                recovered > 0 || historyRecovered.first > 0 || historyRecovered.second > 0 -> "$recovered OBD, ${historyRecovered.first} sürüş ve ${historyRecovered.second} test kaydı kurtarıldı"
                else -> state.status
            }
        )
    }

    fun refreshTrustedTimeState() {
        val trusted = timeSource.isTrusted()
        if (state.timeTrusted != trusted) {
            state = state.copy(timeTrusted = trusted)
        }
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun setLoggingOptions(rawEcuLog: Boolean, longTripLog: Boolean) {
        rawEcuLogEnabled = rawEcuLog
        longTripLogEnabled = longTripLog
        state = state.copy(rawEcuLogEnabled = rawEcuLog, longTripLogEnabled = longTripLog)
    }

    fun setRuntimeSettings(settings: LoganSettings) {
        runtimeSettings = settings
        smartTripMinutes = settings.smartTripMinutes.coerceAtLeast(0)
        scope.launch {
            runCatching {
                sqlStore.applyHistoryRetention(settings.driveHistoryLimit, settings.testHistoryLimit)
                refreshHistoryState()
            }
        }
    }

    fun refreshHistory() {
        scope.launch { refreshHistoryState() }
    }

    private suspend fun refreshHistoryState() {
        val drives = runCatching { sqlStore.listDriveHistory() }.getOrDefault(emptyList())
        val tests = runCatching { sqlStore.listTestHistory() }.getOrDefault(emptyList())
        val storage = runCatching { sqlStore.historyStorageInfo() }.getOrDefault(state.historyStorage)
        withMain { state = state.copy(driveHistory = drives, testHistory = tests, historyStorage = storage) }
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni bekleniyor. Uygulama izni verilmeden cihaz listesi okunamaz.", error = true)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            appendStatus("Bu cihazda Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        val devices = adapter.bondedDevices.orEmpty()
            .map { PairedObdDevice(it.name ?: "OBD cihazı", it.address) }
            .sortedWith(compareByDescending<PairedObdDevice> { looksLikeObd(it.name) }.thenBy { it.name })
        state = state.copy(
            pairedDevices = devices,
            status = if (devices.isEmpty()) "Eşleşmiş OBD cihazı bulunamadı" else "${devices.size} eşleşmiş cihaz bulundu",
            logText = state.logText + "\n[BT] Paired devices: ${devices.joinToString { it.displayName }}"
        )
    }

    fun selectDevice(device: PairedObdDevice) {
        state = state.copy(
            selectedAddress = device.address,
            selectedName = device.name,
            status = "Seçildi: ${device.name}",
            logText = state.logText + "\n[BT] Selected ${device.displayName}"
        )
    }

    fun connectSelected() {
        val address = state.selectedAddress
        if (address == null) {
            appendStatus("Önce vLinker MC+ / ELM327 cihazını seç.", error = true)
            return
        }
        connect(address)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String, autoReconnectAttempt: Boolean = false) {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni yok. Android izin ekranından izin verilmeli.", error = true)
            return
        }
        val connectMark = timeSource.now()
        // A clean disconnect stores an exact stop mark. If ignition cuts power
        // before lifecycle callbacks run, fall back to the last persisted trip
        // sample so the 30/60/90-minute rule still works after reboot.
        val previousDisconnect = lastDisconnectMark ?: loadLastTripStopMark()
        disconnect(silent = true, recordTripStop = false)
        val smartTripDecision = applySmartTripPolicy(previousDisconnect, connectMark)
        lastDisconnectMark = null
        clearLastTripStopMark()
        currentSqlSessionId = sqlStore.startSession(BuildConfig.VERSION_NAME, state.selectedName, address, activeTripHistoryId)
        lastSqlSessionId = currentSqlSessionId
        smartTripDecision?.let { (eventName, note) ->
            sqlStore.insertEvent(currentSqlSessionId, "SMART_TRIP", eventName, note)
        }
        lastSqlSampleMs = 0L
        engineTempWindow.clear()
        lastAcMismatchSignature = null
        lastRpmForCrank = null
        crankStartMs = null
        crankManual = false
        sqlStore.insertEvent(currentSqlSessionId, "CONNECT_REQUEST", "OBD bağlantısı", state.selectedName ?: address)
        state = state.copy(
            connecting = true,
            connected = false,
            status = if (autoReconnectAttempt) "Bluetooth yeniden bağlanıyor..." else "Bluetooth bağlanıyor...",
            lastError = null,
            sqlSessionId = currentSqlSessionId,
            sqlDbPath = sqlStore.databaseFile().absolutePath,
            loopCount = 0,
            noDataCount = 0,
            stoppedCount = 0,
            busInitCount = 0,
            slowLoopCount = 0,
            rawEcuLogEnabled = rawEcuLogEnabled,
            longTripLogEnabled = longTripLogEnabled,
            manualCrankArmed = false,
            crankingInProgress = false,
            timeTrusted = connectMark.trusted
        )
        job = scope.launch {
            try {
                val streams = withTimeout(32000L) {
                    val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth adaptörü yok")
                    val device = adapter.getRemoteDevice(address)
                    withMain { appendLog("[BT] Connecting to ${device.name ?: address} / $address") }
                    adapter.cancelDiscovery()
                    val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                    socket = sock
                    sock.connect()
                    val out = sock.outputStream
                    val input = sock.inputStream
                    withMain { state = state.copy(connecting = false, connected = true, status = "Bluetooth bağlı • ELM init başlıyor") }

                    val initCommands = listOf(
                        // Alpha 1.4.9 ile çalışan Delphi DCM1.2 / VDIAG08 init dizisine yaklaştırıldı.
                        // KWP tarafında erken komut gönderip ELM'i STOPPED durumuna düşürmemek için timeoutlar genişletildi.
                        Triple("ATZ", 1000L, 2200L),
                        Triple("ATE0", 150L, 1000L),
                        Triple("ATL0", 150L, 1000L),
                        Triple("ATS1", 150L, 1000L),
                        Triple("ATH1", 150L, 1000L),
                        Triple("ATSP5", 150L, 1000L),
                        Triple("ATIIA7A", 150L, 1000L),
                        Triple("ATWM817AF1", 150L, 1000L),
                        Triple("ATSH817AF1", 150L, 1000L),
                        Triple("ATFI", 600L, 6500L),
                        Triple("10C0", 250L, 1800L)
                    )
                    initCommands.forEach { (cmd, wait, timeout) ->
                        val resp = send(out, input, cmd, wait, timeout)
                        withMain { appendLog("${if (cmd.isBlank()) "<wake>" else cmd}  =>  $resp") }
                    }
                    Pair(out, input)
                }
                sqlStore.insertEvent(currentSqlSessionId, "CONNECT_OK", "KWP test döngüsü", "poll loop başladı")
                withMain { state = state.copy(connecting = false, connected = true, status = "KWP test döngüsü başladı") }
                pollLoop(streams.first, streams.second)
            } catch (t: TimeoutCancellationException) {
                sqlStore.insertEvent(currentSqlSessionId, "CONNECT_ERROR", "Zaman aşımı", "Tekrar Bağlan ile yeniden denenebilir")
                markUnexpectedDisconnect()
                withMain {
                    appendStatus("Bağlantı zaman aşımı. Tekrar Bağlan ile yeniden denenebilir.", error = true)
                    state = state.copy(connecting = false, connected = false)
                }
                closeSocket()
            } catch (t: CancellationException) {
                withMain { state = state.copy(connecting = false, connected = false) }
            } catch (t: Throwable) {
                val message = t.message ?: t.javaClass.simpleName
                val wasPolling = state.connected || state.loopCount > 0
                if (crankStartMs != null) {
                    run { val mark = timeSource.now(); finishCranking(mark.elapsedMs, mark.epochMs ?: 0L, lastRpmForCrank ?: 0, completed = false) }
                }
                sqlStore.insertEvent(currentSqlSessionId, "CONNECT_ERROR", "Bağlantı hatası", message)
                markUnexpectedDisconnect()
                withMain {
                    val shouldRetry = wasPolling && !autoReconnectAttempt && state.selectedAddress == address
                    appendStatus(
                        if (shouldRetry) "Bağlantı koptu: $message • 2 sn içinde bir kez yeniden denenecek" else "Bağlantı hatası: $message",
                        error = true
                    )
                    state = state.copy(connecting = false, connected = false)
                    if (shouldRetry) {
                        sqlStore.insertEvent(lastSqlSessionId, "AUTO_RECONNECT", "Tek deneme", "2 sn sonra yeniden bağlanılacak")
                    }
                }
                closeSocket()
                if (wasPolling && !autoReconnectAttempt && state.selectedAddress == address) {
                    job = null
                    scope.launch {
                        delay(2000L)
                        if (!state.connected && !state.connecting && state.selectedAddress == address) {
                            connect(address, autoReconnectAttempt = true)
                        }
                    }
                }
            }
        }
    }

    private fun markUnexpectedDisconnect() {
        val mark = timeSource.now()
        interruptActiveHistoryTests("OBD bağlantısı beklenmedik şekilde kesildi")
        sqlStore.parkTripRecord(activeTripHistoryId)
        persistTripRuntime(mark, force = true)
        saveLastTripStopMark(mark)
        val sessionId = currentSqlSessionId
        sqlStore.endSession(sessionId, state = "INTERRUPTED")
        if (sessionId != null) lastSqlSessionId = sessionId
        currentSqlSessionId = null
        lastDisconnectMark = mark
    }

    fun disconnect(silent: Boolean = false, recordTripStop: Boolean = true) {
        job?.cancel()
        job = null
        closeSocket()
        if (crankStartMs != null) {
            run { val mark = timeSource.now(); finishCranking(mark.elapsedMs, mark.epochMs ?: 0L, lastRpmForCrank ?: 0, completed = false) }
        }
        interruptActiveHistoryTests("Kontak veya bağlantı kapandı")
        sqlStore.parkTripRecord(activeTripHistoryId)
        val disconnectMark = timeSource.now()
        sqlStore.insertEvent(currentSqlSessionId, if (silent) "DISCONNECT_SILENT" else "DISCONNECT", "OBD bağlantısı", null)
        sqlStore.endSession(currentSqlSessionId)
        if (currentSqlSessionId != null) lastSqlSessionId = currentSqlSessionId
        if (recordTripStop && (state.connected || currentSqlSessionId != null)) {
            persistTripRuntime(disconnectMark, force = true)
            saveLastTripStopMark(disconnectMark)
            lastDisconnectMark = disconnectMark
        }
        currentSqlSessionId = null
        engineTempWindow.clear()
        lastRpmForCrank = null
        crankStartMs = null
        crankManual = false
        val updated = state.copy(connecting = false, connected = false, manualCrankArmed = false, crankingInProgress = false, status = if (silent) state.status else "Bağlantı kesildi", sqlSessionId = null, sqlDbPath = sqlStore.databaseFile().absolutePath, timeTrusted = disconnectMark.trusted)
        state = updated
        scope.launch { refreshHistoryState() }
        if (!silent) appendLog("[BT] Disconnected")
    }

    private fun interruptActiveHistoryTests(reason: String) {
        developerTestJob?.cancel()
        developerTestJob = null
        activeDeveloperTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", reason) }
        activeCrankTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", reason) }
        activeDeveloperTestHistoryId = null
        activeCrankTestHistoryId = null
        if (state.activeDeveloperTest != null || state.manualCrankArmed || state.crankingInProgress) {
            state = state.copy(
                activeDeveloperTest = null,
                developerTestPhaseText = null,
                developerTestRemainingSec = null,
                manualCrankArmed = false,
                crankingInProgress = false
            )
        }
    }

    fun release() {
        disconnect(silent = true)
        runCatching { sqlStore.close() }
    }

    private suspend fun pollLoop(out: OutputStream, input: InputStream) {
        var loopIndex = 0
        var lastAtrv = ""
        while (job?.isActive == true) {
            val start = SystemClock.elapsedRealtime()
            loopIndex++

            // 21CC_FAST artık doğrulanmış klima biti için hızlı kaynak.
            // Fan biti DC UI/log kanıtıyla doğrulanmadığı için burada işlenmez.
            if (loopIndex == 1 || loopIndex % 8 == 0) {
                lastAtrv = send(out, input, "ATRV", 35L, 800L)
                delay(15)
            }
            val rawCCFast = send(out, input, "21CC", 20L, 700L)
            val fastParsed = parser.parse("", "", rawCCFast, "", lastAtrv, runFuelAlgorithm = false)
            val fastAc = fastParsed.acOn
            val backupAc = acBackupFrom21cc(rawCCFast)
            val mismatchEvent = if (fastAc != null && backupAc != null && fastAc != backupAc) {
                // Aynı uyuşmazlık devam ederken her loop'u loglayıp dosyayı şişirme.
                // Değerler tekrar eşleşirse imza temizlenir ve yeni bir olay yeniden kaydedilebilir.
                val signature = "$fastAc/$backupAc"
                if (signature != lastAcMismatchSignature) {
                    lastAcMismatchSignature = signature
                    sqlStore.insertEvent(currentSqlSessionId, "AC_BIT_MISMATCH", "Primary/backup uyuşmazlığı", "primary=$fastAc backup=$backupAc loop=$loopIndex raw=$rawCCFast")
                    "\n[AC_BIT_MISMATCH] primary=$fastAc backup=$backupAc loop=$loopIndex raw=$rawCCFast"
                } else ""
            } else {
                lastAcMismatchSignature = null
                ""
            }
            withMain {
                val previous = state.snapshot
                val acEvent = if (fastAc != null && fastAc != previous.acOn) {
                    sqlStore.insertEvent(currentSqlSessionId, "AC_FAST", if (fastAc) "ON" else "OFF", "loop=$loopIndex raw=$rawCCFast")
                    "\n[AC_FAST] ${if (fastAc) "ON" else "OFF"} loop=$loopIndex raw=$rawCCFast"
                } else ""
                val fastSnapshot = previous.copy(
                    connected = true,
                    rpm = fastParsed.rpm ?: previous.rpm,
                    acOn = fastAc ?: previous.acOn,
                    radiatorFanOn = null,
                    raw21CC = rawCCFast
                )
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • hızlı 21CC",
                    snapshot = fastSnapshot,
                    raw21CC = rawCCFast,
                    timingText = "fast 21CC",
                    logText = trimLog(state.logText + acEvent + mismatchEvent)
                )
            }
            delay(15)

            val rawA0 = send(out, input, "21A0", 45L, 1150L)
            delay(15)
            val rawCCFresh = rawCCFast

            // 21A2 ve 21CD ağır teknik paketler. beta 3.5: canlı kokpit için seyrek okunur;
            // Teknik sekmede bu paketlerin cached olabileceği kabul edilir.
            val rawA2 = if (loopIndex % 10 == 0 || state.raw21A2.isBlank()) {
                send(out, input, "21A2", 45L, 1150L)
            } else state.raw21A2
            delay(15)
            val rawCD = if (loopIndex % 16 == 0 || state.raw21CD.isBlank()) {
                send(out, input, "21CD", 40L, 950L)
            } else state.raw21CD

            var stdRpm = ""
            var stdSpeed = ""
            var stdTemp = ""
            if (loopIndex % 3 == 0 && !rawA0.contains("61A0", ignoreCase = true) && !rawA0.contains("BUS INIT", ignoreCase = true)) {
                delay(30)
                stdRpm = send(out, input, "010C", 40L, 750L)
                delay(30)
                stdSpeed = send(out, input, "010D", 40L, 750L)
                delay(30)
                stdTemp = send(out, input, "0105", 40L, 750L)
            }

            val parsed = parser.parse(rawA0, rawA2, rawCCFresh, rawCD, lastAtrv, stdRpm, stdSpeed, stdTemp)
            val baseSnapshot = parsed.toSnapshot(rawA0, rawA2, rawCCFresh, rawCD, connected = true)
            val filteredEngineTemp = smoothEngineTemp(baseSnapshot.engineTempC)
            val nowElapsedMs = SystemClock.elapsedRealtime()
            tripComputer.update(parsed.speedKmh, parsed.fuelLh, nowElapsedMs)
            val timeMark = timeSource.now()
            resolvePendingTripBoundary(timeMark)?.let { (eventName, note) ->
                sqlStore.insertEvent(currentSqlSessionId, "SMART_TRIP", eventName, note)
            }
            val trip = tripComputer.snapshot(nowElapsedMs)
            val snapshot = baseSnapshot.copy(
                engineTempC = filteredEngineTemp,
                // 21CC_FAST cevap verdiyse doğrulanmış klima değerini final snapshot'ta da koru.
                // Fan biti doğrulanmadığı için bilinmiyor kalır.
                acOn = fastAc ?: baseSnapshot.acOn,
                radiatorFanOn = null,
                averageConsumption = trip.averageL100,
                tripDistanceKm = trip.distanceKm,
                fuelUsedL = trip.fuelUsedL,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState,
                tripToken = trip.tripToken
            )
            val elapsed = nowElapsedMs - start
            val nowEpochMs = timeMark.epochMs ?: 0L
            val rawCombined = "$rawCCFresh $rawA0 $rawA2 $rawCD"
            processCrankingSample(snapshot, timeMark.elapsedMs, nowEpochMs, rawCombined)
            val hasNoData = rawCombined.contains("NO DATA", ignoreCase = true)
            val hasStopped = rawCombined.contains("STOPPED", ignoreCase = true)
            val hasBusInit = rawCombined.contains("BUS INIT", ignoreCase = true)
            val shouldStoreSql = !longTripLogEnabled || lastSqlSampleMs == 0L || nowElapsedMs - lastSqlSampleMs >= 1000L || hasNoData || hasStopped || hasBusInit || snapshot.fuelSource == "CUTOFF"
            if (shouldStoreSql) {
                lastSqlSampleMs = nowElapsedMs
                sqlStore.insertSample(
                    currentSqlSessionId,
                    loopIndex,
                    elapsed,
                    snapshot,
                    if (rawEcuLogEnabled) rawCCFresh else "",
                    if (rawEcuLogEnabled) rawA0 else "",
                    if (rawEcuLogEnabled) rawA2 else "",
                    if (rawEcuLogEnabled) rawCD else ""
                )
                if (pendingTripBoundary == null && (runtimeSettings.driveHistoryEnabled || activeTripHistoryId != null)) {
                    val recordId = sqlStore.upsertTripRecord(
                        sessionId = currentSqlSessionId,
                        tripToken = trip.tripToken,
                        snapshot = snapshot,
                        durationMs = trip.durationSec * 1000L,
                        versionName = BuildConfig.VERSION_NAME
                    )
                    if (recordId != null && recordId != activeTripHistoryId) {
                        activeTripHistoryId = recordId
                        saveActiveTripHistory(recordId)
                    }
                }
                listOfNotNull(activeDeveloperTestHistoryId, activeCrankTestHistoryId).distinct().forEach { testId ->
                    sqlStore.insertTestSample(
                        testSessionId = testId,
                        loopIndex = loopIndex,
                        loopMs = elapsed,
                        snapshot = snapshot,
                        raw21cc = rawCCFresh,
                        raw21a0 = rawA0,
                        raw21a2 = rawA2,
                        raw21cd = rawCD
                    )
                }
                if (loopIndex % 12 == 0) refreshHistoryState()
            }
            persistTripRuntime(timeMark)
            val loopClock = timeMark.epochMs?.let { SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(it)) } ?: "TIME_PENDING"
            withMain {
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • ${elapsed} ms",
                    snapshot = snapshot,
                    raw21A0 = rawA0,
                    raw21A2 = rawA2,
                    raw21CC = rawCCFresh,
                    raw21CD = rawCD,
                    timingText = "fast 21CC • loop=${elapsed}ms",
                    loopCount = loopIndex,
                    noDataCount = state.noDataCount + if (hasNoData) 1 else 0,
                    stoppedCount = state.stoppedCount + if (hasStopped) 1 else 0,
                    busInitCount = state.busInitCount + if (hasBusInit) 1 else 0,
                    slowLoopCount = state.slowLoopCount + if (elapsed > 1000L) 1 else 0,
                    timeTrusted = timeMark.trusted,
                    logText = trimLog(state.logText + "\n[LOOP #$loopIndex at=$loopClock ${elapsed}ms] rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} fuel=${snapshot.injectionMg ?: "--"} pedal=${snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} map=${snapshot.mapMbar ?: "--"} air=${snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} ac=${snapshot.acOn ?: "--"} fan=UNKNOWN src=${snapshot.fuelSource} trip=${snapshot.tripStateText ?: "--"} dist=${snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.3f", it) } ?: "--"} fuelUsed=${snapshot.fuelUsedL?.let { String.format(Locale.US, "%.4f", it) } ?: "--"} avg=${snapshot.averageConsumption?.let { String.format(Locale.US, "%.2f", it) } ?: "--"}")
                )
            }
            delay(55)
        }
    }

    private fun smoothEngineTemp(current: Int?): Int? {
        if (current == null) return engineTempWindow.lastOrNull()
        engineTempWindow.addLast(current)
        while (engineTempWindow.size > 3) engineTempWindow.removeFirst()
        if (engineTempWindow.size < 3) return current
        // Sert delta engeli yerine 3 örnekli rolling median: tek örneklik
        // sıçramayı bastırır, birkaç örnek süren gerçek termostat/devirdaim
        // değişimini ise gecikmeden takip eder.
        return engineTempWindow.toList().sorted()[1]
    }

    private fun acBackupFrom21cc(raw: String): Boolean? {
        val bytes = Regex("(?i)\\b[0-9a-f]{2}\\b")
            .findAll(raw)
            .map { it.value.toInt(16) }
            .toList()
        val headerIndex = bytes.indices.firstOrNull { i -> i + 1 < bytes.size && bytes[i] == 0x61 && bytes[i + 1] == 0xCC } ?: return null
        val payload = bytes.drop(headerIndex + 2)
        if (payload.size < 2) return null
        return (payload[1] and 0x80) != 0
    }

    private fun applySmartTripPolicy(disconnectedAt: TimeMark?, connectAt: TimeMark): Pair<String, String>? {
        val persisted = loadTripRuntime()
        val current = tripComputer.snapshot(connectAt.elapsedMs)
        val hasTrip = persisted?.let { it.totalDistanceKm > 0.0 || it.totalFuelL > 0.0 || it.pendingDistanceKm > 0.0 } == true ||
            current.distanceKm > 0.0 || current.fuelUsedL > 0.0
        if (!hasTrip) {
            pendingTripBoundary = null
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            return null
        }

        if (smartTripMinutes == 0) {
            pendingTripBoundary = null
            persisted?.let { finalizePersistedTripHistory(it, disconnectedAt ?: connectAt, "ENDED") }
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            tripComputer.reset(connectAt.elapsedMs)
            clearTripRuntime()
            return "NEW_TRIP" to "gap=ignition threshold=0m reason=every_ignition"
        }

        val gapMs = timeSource.gapMillis(disconnectedAt, connectAt)
        if (gapMs == null && persisted != null) {
            // A head unit may establish Bluetooth before GPS/system time becomes
            // trustworthy. Continue provisionally and resolve the boundary once
            // a real clock anchor arrives; this prevents silent trip loss.
            tripComputer.restore(persisted, connectAt.elapsedMs)
            activeTripHistoryId = sqlStore.findTripRecordId(persisted.tripToken)
            saveActiveTripHistory(activeTripHistoryId)
            pendingTripBoundary = PendingTripBoundary(disconnectedAt, persisted)
            return "PENDING_TIME" to "gap=unknown threshold=${smartTripMinutes}m reason=waiting_for_trusted_time"
        }

        pendingTripBoundary = null
        val thresholdMs = smartTripMinutes * 60_000L
        val shouldStartNew = gapMs == null || gapMs >= thresholdMs
        return if (shouldStartNew) {
            persisted?.let { finalizePersistedTripHistory(it, disconnectedAt ?: connectAt, "ENDED") }
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            tripComputer.reset(connectAt.elapsedMs)
            clearTripRuntime()
            val reason = if (gapMs == null) "previous_time_untrusted" else "long_stop"
            val gapText = gapMs?.let(::formatDuration) ?: "unknown"
            "NEW_TRIP" to "gap=$gapText threshold=${smartTripMinutes}m reason=$reason"
        } else {
            val resolvedGapMs = requireNotNull(gapMs)
            if (persisted != null) {
                tripComputer.restore(persisted, connectAt.elapsedMs)
                activeTripHistoryId = sqlStore.findTripRecordId(persisted.tripToken)
                saveActiveTripHistory(activeTripHistoryId)
            }
            "CONTINUE" to "gap=${formatDuration(resolvedGapMs)} threshold=${smartTripMinutes}m reason=short_stop"
        }
    }

    private fun resolvePendingTripBoundary(now: TimeMark): Pair<String, String>? {
        val pending = pendingTripBoundary ?: return null
        if (!now.trusted) return null

        pendingTripBoundary = null
        val gapMs = timeSource.gapMillis(pending.disconnectedAt, now)
        val thresholdMs = smartTripMinutes * 60_000L
        val shouldStartNew = gapMs == null || gapMs >= thresholdMs
        return if (shouldStartNew) {
            finalizePersistedTripHistory(pending.restoredPrefix, pending.disconnectedAt ?: now, "ENDED")
            activeTripHistoryId = null
            saveActiveTripHistory(null)
            tripComputer.detachRestoredPrefix(pending.restoredPrefix, now.elapsedMs)
            clearTripRuntime()
            val reason = if (gapMs == null) "previous_time_untrusted" else "long_stop_after_time_sync"
            val gapText = gapMs?.let(::formatDuration) ?: "unknown"
            "NEW_TRIP_RESOLVED" to "gap=$gapText threshold=${smartTripMinutes}m reason=$reason"
        } else {
            val resolvedGapMs = requireNotNull(gapMs)
            activeTripHistoryId = sqlStore.findTripRecordId(pending.restoredPrefix.tripToken)
            saveActiveTripHistory(activeTripHistoryId)
            "CONTINUE_RESOLVED" to "gap=${formatDuration(resolvedGapMs)} threshold=${smartTripMinutes}m reason=short_stop_after_time_sync"
        }
    }

    fun finishTripNow(): Boolean {
        val mark = timeSource.now()
        val trip = tripComputer.snapshot(mark.elapsedMs)
        if (trip.distanceKm <= 0.0 && trip.fuelUsedL <= 0.0) return false
        sqlStore.insertEvent(
            currentSqlSessionId ?: lastSqlSessionId,
            "TRIP_END_MANUAL",
            "Sürüşü şimdi bitir",
            "dist=${String.format(Locale.US, "%.3f", trip.distanceKm)} fuel=${String.format(Locale.US, "%.4f", trip.fuelUsedL)}"
        )
        sqlStore.finalizeTripRecord(
            tripToken = trip.tripToken,
            distanceKm = trip.distanceKm,
            fuelUsedL = trip.fuelUsedL,
            durationMs = trip.durationSec * 1000L,
            averageL100 = trip.averageL100,
            state = "ENDED_MANUAL",
            endMark = mark
        )
        activeTripHistoryId = null
        saveActiveTripHistory(null)
        scope.launch {
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
        }
        tripComputer.reset(mark.elapsedMs)
        clearTripRuntime()
        clearLastTripStopMark()
        pendingTripBoundary = null
        lastDisconnectMark = null
        state = state.copy(
            snapshot = state.snapshot.copy(
                averageConsumption = null,
                tripDistanceKm = 0.0,
                fuelUsedL = 0.0,
                tripDurationText = "00:00",
                tripStateText = "Sürüş bekleniyor",
                tripToken = tripComputer.snapshot(mark.elapsedMs).tripToken
            )
        )
        appendLog("[TRIP_END_MANUAL] Trip totals reset by user")
        return true
    }

    private fun persistTripRuntime(mark: TimeMark, force: Boolean = false) {
        if (!force && mark.elapsedMs - lastTripPersistElapsedMs < 3000L) return
        lastTripPersistElapsedMs = mark.elapsedMs
        val trip = tripComputer.exportState(mark.elapsedMs)
        val editor = tripPrefs.edit()
            .putBoolean(KEY_TRIP_HAS_STATE, true)
            .putBoolean(KEY_TRIP_STARTED, trip.tripStarted)
            .putLong(KEY_TRIP_DURATION_MS, trip.durationMs)
            .putLong(KEY_TRIP_DISTANCE_BITS, trip.totalDistanceKm.toBits())
            .putLong(KEY_TRIP_FUEL_BITS, trip.totalFuelL.toBits())
            .putLong(KEY_TRIP_PENDING_DISTANCE_BITS, trip.pendingDistanceKm.toBits())
            .putLong(KEY_TRIP_PENDING_FUEL_BITS, trip.pendingFuelL.toBits())
            .putLong(KEY_TRIP_AVG_BITS, trip.smoothedAverage?.toBits() ?: Long.MIN_VALUE)
            .putLong(KEY_TRIP_TOKEN, trip.tripToken)
            .putLong(KEY_TRIP_LAST_EPOCH, mark.epochMs ?: 0L)
            .putLong(KEY_TRIP_LAST_ELAPSED, mark.elapsedMs)
            .putString(KEY_TRIP_LAST_BOOT, mark.bootSessionId)
            .putBoolean(KEY_TRIP_LAST_TRUSTED, mark.trusted)
        if (force) editor.commit() else editor.apply()
    }

    private fun loadTripRuntime(): TripComputerPersistedState? {
        if (!tripPrefs.getBoolean(KEY_TRIP_HAS_STATE, false)) return null
        val avgBits = tripPrefs.getLong(KEY_TRIP_AVG_BITS, Long.MIN_VALUE)
        return TripComputerPersistedState(
            tripStarted = tripPrefs.getBoolean(KEY_TRIP_STARTED, false),
            durationMs = tripPrefs.getLong(KEY_TRIP_DURATION_MS, 0L),
            totalDistanceKm = Double.fromBits(tripPrefs.getLong(KEY_TRIP_DISTANCE_BITS, 0.0.toBits())),
            totalFuelL = Double.fromBits(tripPrefs.getLong(KEY_TRIP_FUEL_BITS, 0.0.toBits())),
            pendingDistanceKm = Double.fromBits(tripPrefs.getLong(KEY_TRIP_PENDING_DISTANCE_BITS, 0.0.toBits())),
            pendingFuelL = Double.fromBits(tripPrefs.getLong(KEY_TRIP_PENDING_FUEL_BITS, 0.0.toBits())),
            smoothedAverage = if (avgBits == Long.MIN_VALUE) null else Double.fromBits(avgBits),
            tripToken = tripPrefs.getLong(KEY_TRIP_TOKEN, 0L)
        )
    }

    private fun clearTripRuntime() {
        tripPrefs.edit()
            .remove(KEY_TRIP_HAS_STATE)
            .remove(KEY_TRIP_STARTED)
            .remove(KEY_TRIP_DURATION_MS)
            .remove(KEY_TRIP_DISTANCE_BITS)
            .remove(KEY_TRIP_FUEL_BITS)
            .remove(KEY_TRIP_PENDING_DISTANCE_BITS)
            .remove(KEY_TRIP_PENDING_FUEL_BITS)
            .remove(KEY_TRIP_AVG_BITS)
            .remove(KEY_TRIP_TOKEN)
            .remove(KEY_TRIP_LAST_EPOCH)
            .remove(KEY_TRIP_LAST_ELAPSED)
            .remove(KEY_TRIP_LAST_BOOT)
            .remove(KEY_TRIP_LAST_TRUSTED)
            .apply()
    }

    private fun saveLastTripStopMark(mark: TimeMark) {
        tripPrefs.edit()
            .putLong(KEY_STOP_EPOCH, mark.epochMs ?: 0L)
            .putLong(KEY_STOP_ELAPSED, mark.elapsedMs)
            .putString(KEY_STOP_BOOT, mark.bootSessionId)
            .putBoolean(KEY_STOP_TRUSTED, mark.trusted)
            .commit()
    }

    private fun loadLastTripStopMark(): TimeMark? {
        if (tripPrefs.contains(KEY_STOP_ELAPSED)) {
            val boot = tripPrefs.getString(KEY_STOP_BOOT, null) ?: return null
            val elapsed = tripPrefs.getLong(KEY_STOP_ELAPSED, -1L)
            if (elapsed < 0L) return null
            val epoch = tripPrefs.getLong(KEY_STOP_EPOCH, 0L).takeIf { it > 0L }
            val trusted = tripPrefs.getBoolean(KEY_STOP_TRUSTED, false) && epoch != null
            return TimeMark(epoch, elapsed, boot, trusted)
        }
        // Abrupt ignition/power cuts may bypass disconnect callbacks. The last
        // 3-second runtime checkpoint is the safest available stop estimate.
        return loadTripRuntimeMark()
    }

    private fun loadTripRuntimeMark(): TimeMark? {
        if (!tripPrefs.getBoolean(KEY_TRIP_HAS_STATE, false)) return null
        val elapsed = tripPrefs.getLong(KEY_TRIP_LAST_ELAPSED, -1L)
        val boot = tripPrefs.getString(KEY_TRIP_LAST_BOOT, null)
        if (elapsed < 0L || boot.isNullOrBlank()) return null
        val epoch = tripPrefs.getLong(KEY_TRIP_LAST_EPOCH, 0L).takeIf { it > 0L }
        val trusted = tripPrefs.getBoolean(KEY_TRIP_LAST_TRUSTED, false) && epoch != null
        return TimeMark(epoch, elapsed, boot, trusted)
    }

    private fun clearLastTripStopMark() {
        tripPrefs.edit()
            .remove(KEY_STOP_EPOCH)
            .remove(KEY_STOP_ELAPSED)
            .remove(KEY_STOP_BOOT)
            .remove(KEY_STOP_TRUSTED)
            .apply()
    }

    private fun finalizePersistedTripHistory(state: TripComputerPersistedState, mark: TimeMark, status: String) {
        val distance = state.totalDistanceKm.coerceAtLeast(0.0)
        val fuel = state.totalFuelL.coerceAtLeast(0.0)
        if (distance <= 0.00001 && fuel <= 0.0) return
        val average = if (distance >= 0.0001) (fuel / distance) * 100.0 else state.smoothedAverage
        sqlStore.finalizeTripRecord(
            tripToken = state.tripToken,
            distanceKm = distance,
            fuelUsedL = fuel,
            durationMs = state.durationMs,
            averageL100 = average,
            state = status,
            endMark = mark
        )
        scope.launch {
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
        }
    }

    private fun saveActiveTripHistory(id: Long?) {
        val editor = tripPrefs.edit()
        if (id == null) editor.remove(KEY_ACTIVE_HISTORY_ID) else editor.putLong(KEY_ACTIVE_HISTORY_ID, id)
        editor.apply()
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return if (hours > 0) "${hours}h${minutes}m${seconds}s" else "${minutes}m${seconds}s"
    }

    private fun send(out: OutputStream, input: InputStream, cmd: String, waitMs: Long, timeoutMs: Long): String {
        drainInput(input)
        if (cmd.isNotBlank()) {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        }
        Thread.sleep(waitMs)
        val buffer = StringBuilder()
        val start = System.currentTimeMillis()
        var gotAny = false
        var lastData = System.currentTimeMillis()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = input.available()
            if (available > 0) {
                gotAny = true
                lastData = System.currentTimeMillis()
                repeat(available) {
                    val b = input.read()
                    if (b >= 0) {
                        val ch = b.toChar()
                        buffer.append(ch)
                        if (ch == '>') return clean(buffer.toString())
                    }
                }
            } else {
                val current = buffer.toString()
                val quietFor = System.currentTimeMillis() - lastData
                // BUS INIT devam ederken erken çıkma; aksi halde bir sonraki komut ELM'i STOPPED'a düşürüyor.
                val kwpInitInProgress = current.contains("BUS INIT", ignoreCase = true) && !current.contains("OK", ignoreCase = true) && !current.contains(">")
                if (gotAny && !kwpInitInProgress && quietFor > 260L) return clean(current)
                Thread.sleep(10)
            }
        }
        return clean(buffer.toString())
    }

    private fun drainInput(input: InputStream) {
        runCatching {
            var guard = 0
            while (input.available() > 0 && guard < 4096) {
                input.read()
                guard++
            }
        }
    }

    fun armManualCrankAnalysis() {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Marş analizi için önce OBD bağlantısı gerekli")
            appendLog("[CRANK_MANUAL_BLOCKED] OBD connection required")
            return
        }
        activeCrankTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", "Yeni manuel marş testi başlatıldı") }
        activeCrankTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = currentSqlSessionId ?: lastSqlSessionId,
                testType = "CRANK",
                name = "Manuel Marş Analizi",
                versionName = BuildConfig.VERSION_NAME,
                note = "Kullanıcı manuel marş analizini kurdu"
            )
        } else null
        state = state.copy(manualCrankArmed = true, status = "Marş analizi hazır • şimdi marşa basın")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_ARMED", "Marş Analizi", "Kullanıcı manuel testi başlattı")
        appendLog("[CRANK_MANUAL_ARMED] Ready; start engine now")
        refreshHistory()
    }

    fun clearManualCrankTests() {
        crankPrefs.edit().remove(KEY_MANUAL_CRANKS).apply()
        state = state.copy(savedManualCrankTests = emptyList(), status = "Manuel marş testleri silindi")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_CLEAR", "Marş Analizi", "Manuel kayıtlar silindi")
        appendLog("[CRANK_MANUAL_CLEAR] Saved manual cranking tests cleared")
    }

    private fun processCrankingSample(
        snapshot: DashboardSnapshot,
        elapsedMs: Long,
        timestampMs: Long,
        rawCombined: String
    ) {
        val rpm = snapshot.rpm
        val voltage = snapshot.batteryV ?: snapshot.adapterVoltageV
        val previousRpm = lastRpmForCrank
        val obdGap = rawCombined.contains("NO DATA", ignoreCase = true) ||
            rawCombined.contains("STOPPED", ignoreCase = true) ||
            rawCombined.contains("BUS INIT", ignoreCase = true) ||
            (crankStartMs != null && rpm == null)

        if (crankStartMs != null) {
            if (voltage != null) crankMinVoltage = minOf(crankMinVoltage ?: voltage, voltage)
            if (obdGap) crankObdGapDetected = true
            val durationMs = elapsedMs - (crankStartMs ?: elapsedMs)
            when {
                rpm != null && rpm >= 600 -> finishCranking(elapsedMs, timestampMs, rpm, completed = true)
                durationMs > 8000L -> finishCranking(elapsedMs, timestampMs, rpm ?: previousRpm ?: 0, completed = false)
                rpm != null -> lastRpmForCrank = rpm
            }
            return
        }

        if (rpm == null) return

        val wasStopped = previousRpm != null && previousRpm <= 120
        val startedTurning = wasStopped && rpm >= 180
        if (startedTurning) {
            // Duration must never jump when GPS/system time is corrected.
            crankStartMs = elapsedMs
            crankStartVoltage = voltage
            crankMinVoltage = voltage
            crankTempC = snapshot.engineTempC
            crankObdGapDetected = obdGap
            crankManual = state.manualCrankArmed
            state = state.copy(crankingInProgress = true, status = if (crankManual) "Manuel marş testi algılandı" else "Marş algılandı • analiz ediliyor")
            if (crankManual) {
                sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_START", "Manuel marş", "rpm=$rpm voltage=${voltage ?: "--"}")
            }
            appendLog("[CRANK_START] manual=$crankManual rpm=$rpm voltage=${voltage ?: "--"}")
        }
        lastRpmForCrank = rpm
    }

    private fun finishCranking(elapsedMs: Long, timestampMs: Long, rpmAtFinish: Int, completed: Boolean) {
        val startMs = crankStartMs ?: return
        val duration = ((elapsedMs - startMs).coerceAtLeast(0L)) / 1000.0
        val manual = crankManual
        val result = buildCrankResult(
            timestampMs = timestampMs,
            manual = manual,
            durationSec = duration,
            startVoltage = crankStartVoltage,
            minVoltage = crankMinVoltage,
            engineTempC = crankTempC,
            rpmAtFinish = rpmAtFinish,
            obdGapDetected = crankObdGapDetected,
            completed = completed
        )
        val autoRecent = if (manual) {
            state.recentAutoCrankResults
        } else {
            val candidates = listOf(result) + state.recentAutoCrankResults
            if (timestampMs > 0L) {
                candidates
                    .filter { it.timestampMs <= 0L || timestampMs - it.timestampMs <= 24L * 60L * 60L * 1000L }
                    .take(5)
            } else {
                // Real time is not trusted yet. Preserve ordering without comparing
                // the placeholder timestamp to old epoch values.
                candidates.take(5)
            }
        }
        val manualTests = if (manual) {
            val updated = (listOf(result) + state.savedManualCrankTests).take(50)
            saveManualCrankTests(updated)
            updated
        } else state.savedManualCrankTests
        state = state.copy(
            manualCrankArmed = false,
            crankingInProgress = false,
            lastAutoCrankResult = if (manual) state.lastAutoCrankResult else result,
            recentAutoCrankResults = autoRecent,
            savedManualCrankTests = manualTests,
            status = "Marş analizi: ${result.status} • ${String.format(Locale.US, "%.1f", result.durationSec)} sn"
        )
        if (manual) {
            sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_RESULT", result.status, result.comment)
            sqlStore.endTestSession(
                activeCrankTestHistoryId,
                status = if (completed) "COMPLETED" else "INTERRUPTED",
                summary = "${result.status} • ${String.format(Locale.US, "%.2f", result.durationSec)} sn • Akü: ${result.batteryStatus} • ${result.comment}"
            )
            activeCrankTestHistoryId = null
            scope.launch {
                sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
                refreshHistoryState()
            }
        }
        appendLog("[CRANK_RESULT] manual=$manual duration=${String.format(Locale.US, "%.2f", result.durationSec)}s startV=${result.startVoltage ?: "--"} minV=${result.minVoltage ?: "--"} status=${result.status} battery=${result.batteryStatus} gap=${result.obdGapDetected}")
        crankStartMs = null
        crankStartVoltage = null
        crankMinVoltage = null
        crankTempC = null
        crankObdGapDetected = false
        crankManual = false
    }

    private fun buildCrankResult(
        timestampMs: Long,
        manual: Boolean,
        durationSec: Double,
        startVoltage: Double?,
        minVoltage: Double?,
        engineTempC: Int?,
        rpmAtFinish: Int?,
        obdGapDetected: Boolean,
        completed: Boolean
    ): CrankAnalysisResult {
        val cold = engineTempC == null || engineTempC < 50
        val status = when {
            !completed -> "Tamamlanamadı"
            cold && durationSec <= 2.0 -> "Normal"
            !cold && durationSec <= 1.2 -> "Normal"
            cold && durationSec <= 3.0 -> "Hafif uzun"
            !cold && durationSec <= 2.0 -> "Hafif uzun"
            durationSec <= 4.0 -> "Geç marş"
            else -> "Belirgin geç marş"
        }
        val batteryStatus = when {
            minVoltage == null -> "Ölçülemedi"
            minVoltage >= 10.0 -> "İyi"
            minVoltage >= 9.6 -> "Sınırda"
            minVoltage >= 9.0 -> "Zayıf"
            else -> "Çok düşük"
        }
        val comment = buildString {
            append(when (status) {
                "Normal" -> "Marş süresi normal görünüyor."
                "Hafif uzun" -> "Marş süresi hafif uzun; tekrar eden durumda takip edilmeli."
                "Geç marş" -> "Marş süresi uzun. Akü, yakıt hattı, krank/eksantrik sinyali ve kızdırma sistemi kontrol edilebilir."
                "Belirgin geç marş" -> "Belirgin geç marş algılandı. Akü/şase, marş motoru, yakıt basıncı ve sensör senkronu kontrol edilmeli."
                else -> "Marş analizi tamamlanamadı; OBD cevabı veya RPM verisi kesilmiş olabilir."
            })
            if (minVoltage != null && minVoltage < 9.6) append(" Marş sırasında voltaj belirgin düşmüş.")
            if (obdGapDetected) append(" Marş sırasında kısa OBD cevap boşluğu görüldü.")
        }
        return CrankAnalysisResult(timestampMs, manual, durationSec, startVoltage, minVoltage, engineTempC, rpmAtFinish, obdGapDetected, status, batteryStatus, comment)
    }

    private fun loadManualCrankTests(): List<CrankAnalysisResult> {
        val raw = crankPrefs.getString(KEY_MANUAL_CRANKS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lineSequence().mapNotNull { line ->
            val p = line.split("|")
            runCatching {
                if (p.size < 10) return@mapNotNull null
                CrankAnalysisResult(
                    timestampMs = p[0].toLong(),
                    manual = true,
                    durationSec = p[1].toDouble(),
                    startVoltage = p[2].toDoubleOrNull(),
                    minVoltage = p[3].toDoubleOrNull(),
                    engineTempC = p[4].toIntOrNull(),
                    rpmAtFinish = p[5].toIntOrNull(),
                    obdGapDetected = p[6].toBoolean(),
                    status = p[7],
                    batteryStatus = p[8],
                    comment = p.drop(9).joinToString("|")
                )
            }.getOrNull()
        }.toList()
    }

    private fun saveManualCrankTests(items: List<CrankAnalysisResult>) {
        val raw = items.joinToString("\n") { r ->
            listOf(
                r.timestampMs.toString(),
                String.format(Locale.US, "%.3f", r.durationSec),
                r.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.engineTempC?.toString() ?: "",
                r.rpmAtFinish?.toString() ?: "",
                r.obdGapDetected.toString(),
                r.status,
                r.batteryStatus,
                r.comment.replace("\n", " ").replace("|", "/")
            ).joinToString("|")
        }
        crankPrefs.edit().putString(KEY_MANUAL_CRANKS, raw).apply()
    }


    fun logMetricReset(
        action: TripMetricReset,
        distanceKm: Double,
        fuelLiters: Double,
        fuelPriceText: String
    ) {
        val eventType = when (action) {
            TripMetricReset.Average -> "AVG_RESET"
            TripMetricReset.Cost -> "COST_RESET"
            TripMetricReset.AverageAndCost -> "AVG_COST_RESET"
        }
        val name = when (action) {
            TripMetricReset.Average -> "Ortalama tüketimi sıfırla"
            TripMetricReset.Cost -> "Sürüş maliyetini sıfırla"
            TripMetricReset.AverageAndCost -> "Ortalama ve maliyeti sıfırla"
        }
        val note = "dist=${String.format(Locale.US, "%.3f", distanceKm)} fuel=${String.format(Locale.US, "%.4f", fuelLiters)} price=${fuelPriceText.ifBlank { "--" }}"
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, eventType, name, note)
        appendLog("[$eventType] $note")
    }


    fun startDeveloperTest(name: String) {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Test için önce OBD bağlantısı gerekli")
            appendLog("[TEST_BLOCKED] $name requires OBD connection")
            return
        }
        developerTestJob?.cancel()
        activeDeveloperTestHistoryId?.let { sqlStore.endTestSession(it, "INTERRUPTED", "Yeni test başlatıldığı için önceki test kapatıldı") }
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        activeDeveloperTestHistoryId = if (runtimeSettings.testHistoryEnabled) {
            sqlStore.startTestSession(
                driveSessionId = sessionId,
                testType = "DEVELOPER",
                name = name,
                versionName = BuildConfig.VERSION_NAME,
                note = "Yönlendirmeli LoganOS testi"
            )
        } else null
        sqlStore.insertEvent(sessionId, "TEST_START", name, "Kullanıcı testi başlattı")
        state = state.copy(
            activeDeveloperTest = name,
            developerTestPhaseText = "Hazırlan",
            developerTestRemainingSec = 3,
            developerTestDoneMessage = null,
            status = "Test başladı: $name"
        )
        appendLog("[TEST_START] $name")
        developerTestJob = scope.launch {
            runDeveloperTestGuide(name, sessionId)
        }
        refreshHistory()
    }

    fun finishDeveloperTest() {
        val name = state.activeDeveloperTest ?: return
        developerTestJob?.cancel()
        developerTestJob = null
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "TEST_END", name, "Kullanıcı testi bitirdi")
        sqlStore.endTestSession(activeDeveloperTestHistoryId, "COMPLETED_MANUAL", "Kullanıcı testi manuel olarak bitirdi")
        activeDeveloperTestHistoryId = null
        scope.launch {
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
        }
        state = state.copy(
            activeDeveloperTest = null,
            developerTestPhaseText = null,
            developerTestRemainingSec = null,
            developerTestDoneMessage = "Test bitti: $name",
            status = "Test bitti: $name"
        )
        appendLog("[TEST_END] $name")
        scope.launch { clearDeveloperTestDoneMessageLater(name) }
    }

    private suspend fun runDeveloperTestGuide(name: String, sessionId: Long?) {
        val phases = developerTestPhases(name)
        try {
            phases.forEach { phase ->
                sqlStore.insertEvent(sessionId, "TEST_PHASE", name, phase.title)
                withMain {
                    state = state.copy(
                        activeDeveloperTest = name,
                        developerTestPhaseText = phase.title,
                        developerTestRemainingSec = phase.seconds,
                        developerTestDoneMessage = null,
                        status = "Test: $name • ${phase.title}"
                    )
                    appendLog("[TEST_PHASE] $name • ${phase.title} • ${phase.seconds}s")
                }
                for (remaining in phase.seconds downTo 1) {
                    withMain {
                        if (state.activeDeveloperTest == name) {
                            state = state.copy(developerTestRemainingSec = remaining)
                        }
                    }
                    delay(1000L)
                }
            }
            sqlStore.insertEvent(sessionId, "TEST_END", name, "Otomatik geri sayım tamamlandı")
            sqlStore.endTestSession(activeDeveloperTestHistoryId, "COMPLETED", "Otomatik test adımları tamamlandı")
            activeDeveloperTestHistoryId = null
            sqlStore.applyHistoryRetention(runtimeSettings.driveHistoryLimit, runtimeSettings.testHistoryLimit)
            refreshHistoryState()
            withMain {
                state = state.copy(
                    activeDeveloperTest = null,
                    developerTestPhaseText = null,
                    developerTestRemainingSec = null,
                    developerTestDoneMessage = "Test bitti: $name",
                    status = "Test bitti: $name"
                )
                appendLog("[TEST_END] $name")
            }
            clearDeveloperTestDoneMessageLater(name)
        } catch (_: CancellationException) {
            // Kullanıcı testi manuel bitirdiğinde buraya düşer; log finishDeveloperTest içinde yazılır.
        }
    }

    private fun developerTestPhases(name: String): List<DeveloperTestPhase> = when (name) {
        "Sıcak rölanti testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 60),
            DeveloperTestPhase("Klimayı aç", 60),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Klima testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Elektrik/yük testi" -> listOf(
            DeveloperTestPhase("Klima kapalı kalsın; tüm yükler kapalı", 30),
            DeveloperTestPhase("Kısa farları aç; klima kapalı", 30),
            DeveloperTestPhase("Uzun/sis farlarını aç; klima kapalı", 30),
            DeveloperTestPhase("Arka rezistansı aç; klima kapalı", 30),
            DeveloperTestPhase("Kalorifer fanını aç; klima kapalı", 30),
            DeveloperTestPhase("Yükleri kapat", 20)
        )
        "Tam yük testi" -> listOf(
            DeveloperTestPhase("Tüm yükler kapalı", 30),
            DeveloperTestPhase("Farlar + sisler + rezistansı aç", 30),
            DeveloperTestPhase("Kalorifer fanını aç", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Tüm yükleri kapat", 20)
        )
        "CUTOFF testi", "Yakıt kesme (CUTOFF) testi" -> listOf(
            DeveloperTestPhase("20-30 km/h üstüne çık", 20),
            DeveloperTestPhase("Gazı tamamen bırak", 15),
            DeveloperTestPhase("Güvenli şekilde yavaşla", 10)
        )
        "Serbest sürüş testi" -> listOf(
            DeveloperTestPhase("Normal şehir içi sürüşe başla", 60),
            DeveloperTestPhase("Sürüşe devam et", 240)
        )
        else -> listOf(DeveloperTestPhase("Testi uygula", 60))
    }

    private suspend fun clearDeveloperTestDoneMessageLater(name: String) {
        delay(3000L)
        withMain {
            if (state.developerTestDoneMessage == "Test bitti: $name") {
                state = state.copy(developerTestDoneMessage = null)
            }
        }
    }

    fun setDriveHistoryPinned(id: Long, pinned: Boolean): Boolean {
        val changed = sqlStore.setTripPinned(id, pinned)
        if (changed) refreshHistory()
        return changed
    }

    fun setTestHistoryPinned(id: Long, pinned: Boolean): Boolean {
        val changed = sqlStore.setTestPinned(id, pinned)
        if (changed) refreshHistory()
        return changed
    }

    fun deleteDriveHistory(id: Long): Boolean {
        val deleted = sqlStore.deleteTripRecord(id)
        if (deleted) refreshHistory()
        return deleted
    }

    fun deleteTestHistory(id: Long): Boolean {
        val deleted = sqlStore.deleteTestRecord(id)
        if (deleted) refreshHistory()
        return deleted
    }

    fun exportDriveHistory(id: Long) {
        scope.launch {
            val text = sqlStore.exportTripRecordText(id, includeRaw = rawEcuLogEnabled)
            if (text == null) {
                withMain { state = state.copy(status = "Sürüş kaydı bulunamadı") }
                return@launch
            }
            val fileName = "loganos_drive_v${safeVersionTag()}_${trustedFileStamp()}_id${id}.txt"
            val displayPath = saveBytesToDownloads(fileName, "text/plain", text.toByteArray(Charsets.UTF_8))
            withMain {
                state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Sürüş dışa aktarıldı: $displayPath")
            }
            refreshHistoryState()
        }
    }

    fun exportTestHistory(id: Long) {
        scope.launch {
            val text = sqlStore.exportTestRecordText(id, includeRaw = true)
            if (text == null) {
                withMain { state = state.copy(status = "Test kaydı bulunamadı") }
                return@launch
            }
            val fileName = "loganos_test_v${safeVersionTag()}_${trustedFileStamp()}_id${id}.txt"
            val displayPath = saveBytesToDownloads(fileName, "text/plain", text.toByteArray(Charsets.UTF_8))
            withMain {
                state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Test dışa aktarıldı: $displayPath")
            }
            refreshHistoryState()
        }
    }

    fun exportAllHistory() {
        scope.launch {
            val drives = sqlStore.listDriveHistory(500)
            val tests = sqlStore.listTestHistory(500)
            val fileName = "loganos_history_v${safeVersionTag()}_${trustedFileStamp()}.zip"
            val zipBytes = ByteArrayOutputStream().use { buffer ->
                ZipOutputStream(buffer).use { zip ->
                    drives.forEachIndexed { index, item ->
                        val text = sqlStore.exportTripRecordText(item.id, includeRaw = false) ?: return@forEachIndexed
                        zip.putNextEntry(ZipEntry("drives/drive_${index + 1}_id${item.id}.txt"))
                        zip.write(text.toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    tests.forEachIndexed { index, item ->
                        val text = sqlStore.exportTestRecordText(item.id, includeRaw = true) ?: return@forEachIndexed
                        zip.putNextEntry(ZipEntry("tests/test_${index + 1}_id${item.id}.txt"))
                        zip.write(text.toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    val summary = buildString {
                        appendLine("LOGANOS HISTORY EXPORT")
                        appendLine("version=${BuildConfig.VERSION_NAME}")
                        appendLine("drive_records=${drives.size}")
                        appendLine("test_records=${tests.size}")
                    }
                    zip.putNextEntry(ZipEntry("summary.txt"))
                    zip.write(summary.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
                buffer.toByteArray()
            }
            val displayPath = saveBytesToDownloads(fileName, "application/zip", zipBytes)
            withMain {
                state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Tüm geçmiş dışa aktarıldı: $displayPath")
            }
            refreshHistoryState()
        }
    }

    private fun safeVersionTag(): String = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')

    private fun exportLogText(includeRaw: Boolean = true): String {
        val base = sqlStore.exportSessionText(currentSqlSessionId ?: lastSqlSessionId, includeRaw = includeRaw) ?: state.logText.ifBlank { "Log yok" }
        val settingsBlock = buildString {
            append("\n[APP_SETTINGS]\n")
            append("smartTripThreshold=${runtimeSettings.smartTripMinutes}m\n")
            append("developerRawLog=${runtimeSettings.developerModeEnabled && runtimeSettings.rawEcuLogEnabled}\n")
            append("demoMode=${runtimeSettings.demoMode}\n")
            append("gaugeStyle=${runtimeSettings.gaugeStyle.name}\n")
            append("cockpitDensity=${runtimeSettings.cockpitDensity.name}\n")
            append("cockpitTextSize=${runtimeSettings.cockpitTextSize.name}\n")
        }
        val withSettings = base + settingsBlock
        val lastAuto = state.lastAutoCrankResult ?: return withSettings
        val time = if (lastAuto.timestampMs > 0L) SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(lastAuto.timestampMs)) else "TIME_PENDING"
        val crank = buildString {
            append("\n\n[LAST_AUTO_CRANK_ANALYSIS]\n")
            append("time=").append(time).append('\n')
            append("duration=").append(String.format(Locale.US, "%.2f", lastAuto.durationSec)).append(" s\n")
            append("status=").append(lastAuto.status).append('\n')
            append("battery=").append(lastAuto.batteryStatus).append('\n')
            append("startV=").append(lastAuto.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("minV=").append(lastAuto.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("engineTemp=").append(lastAuto.engineTempC?.toString() ?: "--").append(" °C\n")
            append("obdGap=").append(lastAuto.obdGapDetected).append('\n')
            append("comment=").append(lastAuto.comment).append('\n')
        }
        return withSettings + crank
    }

    fun saveLogFile() {
        val fileName = makeLogFileName()
        val text = exportLogText(includeRaw = rawEcuLogEnabled)
        val displayPath = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Download/LoganOS/$fileName"
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.mkdirs()
                val file = File(dir, fileName)
                file.writeText(text)
                file.absolutePath
            }
        }.getOrElse {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val file = File(dir, fileName)
            file.writeText(text)
            file.absolutePath
        }
        state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Kayıt dışa aktarıldı: $displayPath", sharedLogReady = true)
        appendLog("[LOG] Saved to $displayPath")
    }

    fun shareLogText() {
        val text = exportLogText(includeRaw = false)
        val fileName = makeLogFileName(prefix = "loganos_share")
        val shareDir = File(context.cacheDir, "log_share").apply { mkdirs() }
        val file = File(shareDir, fileName).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "LoganOS OBD Log")
            putExtra(Intent.EXTRA_TITLE, fileName)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "LoganOS log paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = state.copy(status = "Log paylaşım ekranı açıldı")
    }

    fun createSupportPackage() {
        val fileName = makeSupportFileName()
        val summaryText = exportLogText(includeRaw = false)
        val rawText = exportLogText(includeRaw = true)
        val metadata = buildString {
            appendLine("LOGANOS SUPPORT PACKAGE")
            appendLine("version=${BuildConfig.VERSION_NAME}")
            val generatedMark = timeSource.now()
            val generatedText = generatedMark.epochMs?.takeIf { generatedMark.trusted }?.let {
                SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(it))
            } ?: "TIME_PENDING+${generatedMark.elapsedMs}ms"
            appendLine("generated=$generatedText")
            appendLine("adapter=${state.selectedName ?: "--"} / ${state.selectedAddress ?: "--"}")
            appendLine("connected=${state.connected}")
            appendLine("loopCount=${state.loopCount}")
            appendLine("noDataCount=${state.noDataCount}")
            appendLine("stoppedCount=${state.stoppedCount}")
            appendLine("busInitCount=${state.busInitCount}")
            appendLine("slowLoopCount=${state.slowLoopCount}")
            appendLine("smartTripThreshold=${smartTripMinutes}m")
            appendLine("rawEcuLogEnabled=$rawEcuLogEnabled")
            appendLine("demoMode=${runtimeSettings.demoMode}")
            appendLine("gaugeStyle=${runtimeSettings.gaugeStyle.name}")
            appendLine("cockpitDensity=${runtimeSettings.cockpitDensity.name}")
            appendLine("cockpitTextSize=${runtimeSettings.cockpitTextSize.name}")
        }
        val zipBytes = ByteArrayOutputStream().use { buffer ->
            ZipOutputStream(buffer).use { zip ->
                fun add(name: String, text: String) {
                    zip.putNextEntry(ZipEntry(name))
                    zip.write(text.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                }
                add("summary_log.txt", summaryText)
                add("raw_obd_log.txt", rawText)
                add("metadata.txt", metadata)
            }
            buffer.toByteArray()
        }
        val displayPath = saveBytesToDownloads(fileName, "application/zip", zipBytes)
        state = state.copy(
            savedLogPath = displayPath,
            savedLogFileName = fileName,
            status = "Destek paketi oluşturuldu: $displayPath",
            sharedLogReady = true
        )
        appendLog("[SUPPORT_PACKAGE] Saved to $displayPath")
    }

    private fun saveBytesToDownloads(fileName: String, mimeType: String, bytes: ByteArray): String {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, mimeType)
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                "Download/LoganOS/$fileName"
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.mkdirs()
                val file = File(dir, fileName)
                file.writeBytes(bytes)
                file.absolutePath
            }
        }.getOrElse {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val file = File(dir, fileName)
            file.writeBytes(bytes)
            file.absolutePath
        }
    }

    fun clearLastLogFile() {
        val fileName = state.savedLogFileName
        if (fileName.isNullOrBlank()) {
            state = state.copy(status = "Silinecek son log yok")
            return
        }
        val deleted = deleteDownloadLogByName(fileName)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = if (deleted) "Son log silindi: $fileName" else "Son log bulunamadı: $fileName"
        )
        appendLog("[LOG] Clear last requested: $fileName deleted=$deleted")
    }

    fun clearAllLogFiles(): Boolean {
        if (state.connected || state.connecting || currentSqlSessionId != null) {
            state = state.copy(status = "Tüm logları temizlemek için önce OBD bağlantısını kesin")
            appendLog("[LOG] Clear all blocked while an OBD session is active")
            return false
        }
        val deleted = deleteAllDownloadLogs()
        val sqlDeleted = sqlStore.clearAll()
        lastSqlSessionId = null
        activeTripHistoryId = null
        saveActiveTripHistory(null)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = "$deleted log dosyası ve $sqlDeleted SQL kaydı silindi",
            sqlSessionId = null,
            driveHistory = emptyList(),
            testHistory = emptyList(),
            historyStorage = com.dcui.loganos.data.HistoryStorageInfo()
        )
        appendLog("[LOG] Clear all requested: files=$deleted sql=$sqlDeleted")
        return true
    }

    private fun trustedFileStamp(): String {
        val mark = timeSource.now()
        val epoch = mark.epochMs
        return if (mark.trusted && epoch != null) {
            SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS", Locale.US).format(Date(epoch))
        } else {
            val boot = mark.bootSessionId.replace(Regex("[^A-Za-z0-9]"), "").take(8).ifBlank { "boot" }
            "time_pending_${boot}_${mark.elapsedMs}ms"
        }
    }

    private fun makeLogFileName(prefix: String = "loganos_obd"): String {
        val versionTag = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
        return "${prefix}_v${versionTag}_${trustedFileStamp()}.txt"
    }

    private fun makeSupportFileName(): String {
        val versionTag = BuildConfig.VERSION_NAME.replace(Regex("[^A-Za-z0-9]+"), "_").trim('_')
        return "loganos_support_v${versionTag}_${trustedFileStamp()}.zip"
    }

    private fun deleteDownloadLogByName(fileName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf(fileName, Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args) > 0
            } else {
                val file = File(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS"), fileName)
                file.exists() && file.delete()
            }
        }.getOrDefault(false)
    }

    private fun deleteAllDownloadLogs(): Int {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf("loganos_%", Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.listFiles { f -> f.name.startsWith("loganos_") && (f.name.endsWith(".txt") || f.name.endsWith(".zip")) }?.count { it.delete() } ?: 0
            }
        }.getOrDefault(0)
    }

    private fun clean(text: String): String = text.replace("\r", " ").replace("\n", " ").replace(">", " > ").trim()

    private fun closeSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun appendStatus(text: String, error: Boolean = false) {
        state = state.copy(status = text, lastError = if (error) text else state.lastError, logText = trimLog(state.logText + "\n[STATUS] $text"))
    }

    private fun appendLog(text: String) {
        state = state.copy(logText = trimLog(state.logText + "\n$text"))
    }

    private suspend fun withMain(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun trimLog(log: String): String {
        return if (log.length <= 300000) log else log.takeLast(300000)
    }

    private fun looksLikeObd(name: String): Boolean {
        val n = name.lowercase()
        return listOf("obd", "elm", "vlink", "vgate", "icar", "kwp").any { it in n }
    }

    companion object {
        private const val KEY_MANUAL_CRANKS = "manual_crank_tests"
        private const val KEY_TRIP_HAS_STATE = "trip_has_state"
        private const val KEY_ACTIVE_HISTORY_ID = "active_trip_history_id"
        private const val KEY_TRIP_STARTED = "trip_started"
        private const val KEY_TRIP_DURATION_MS = "trip_duration_ms"
        private const val KEY_TRIP_DISTANCE_BITS = "trip_distance_bits"
        private const val KEY_TRIP_FUEL_BITS = "trip_fuel_bits"
        private const val KEY_TRIP_PENDING_DISTANCE_BITS = "trip_pending_distance_bits"
        private const val KEY_TRIP_PENDING_FUEL_BITS = "trip_pending_fuel_bits"
        private const val KEY_TRIP_AVG_BITS = "trip_avg_bits"
        private const val KEY_TRIP_TOKEN = "trip_token"
        private const val KEY_TRIP_LAST_EPOCH = "trip_last_epoch"
        private const val KEY_TRIP_LAST_ELAPSED = "trip_last_elapsed"
        private const val KEY_TRIP_LAST_BOOT = "trip_last_boot"
        private const val KEY_TRIP_LAST_TRUSTED = "trip_last_trusted"
        private const val KEY_STOP_EPOCH = "trip_stop_epoch"
        private const val KEY_STOP_ELAPSED = "trip_stop_elapsed"
        private const val KEY_STOP_BOOT = "trip_stop_boot"
        private const val KEY_STOP_TRUSTED = "trip_stop_trusted"
    }
}
