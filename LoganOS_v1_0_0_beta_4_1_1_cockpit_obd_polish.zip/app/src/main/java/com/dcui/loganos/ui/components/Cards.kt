package com.dcui.loganos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.Image
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.ui.theme.LoganPalette

enum class CardIcon {
    FuelAverage,
    FuelInstant,
    Distance,
    Cost,
    Temperature,
    TemperatureFan,
    Fan,
    Ac,
    Rpm,
    Time,
    Battery,
    Speed,
    Injection,
    Pedal,
    MapPressure,
    AirFlow,
    TurboPressure,
    IntakeAirTemp,
    OutsideAirTemp,
    AtmosphericPressure,
    FuelPressure,
    FuelPump,
    FuelFilter,
    EgrValve,
    Alternator,
    ChargeStatus,
    GlowPlug,
    EngineFault,
    EcuStatus,
    SteeringAngle,
    RoadIncline,
    DoorStatus,
    Seatbelt,
    Lighting,
    ObdConnection,
    CrankingAnalysis,
    FuelCalibration,
    LogsSupport,
    Settings,
    Engine
}

@Composable
fun OemCard(
    palette: LoganPalette,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(11.dp)
    Box(
        modifier = modifier
            .shadow(2.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = .10f), spotColor = Color.Black.copy(alpha = .10f))
            .clip(shape)
            .background(palette.surface)
            .border(1.dp, palette.line.copy(alpha = .82f), shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(12.dp)
    ) {
        content()
    }
}

private fun CardIcon.drawableRes(): Int = when (this) {
    CardIcon.FuelAverage -> R.drawable.cockpit_fuel_average
    CardIcon.FuelInstant -> R.drawable.cockpit_fuel_instant
    CardIcon.Distance -> R.drawable.cockpit_distance
    CardIcon.Cost -> R.drawable.cockpit_trip_cost
    CardIcon.Temperature -> R.drawable.cockpit_coolant
    CardIcon.TemperatureFan -> R.drawable.cockpit_temp_fan
    CardIcon.Fan -> R.drawable.cockpit_fan
    CardIcon.Ac -> R.drawable.cockpit_ac
    CardIcon.Rpm -> R.drawable.cockpit_rpm
    CardIcon.Time -> R.drawable.cockpit_trip_time
    CardIcon.Battery -> R.drawable.asset_battery_voltage
    CardIcon.Speed -> R.drawable.ic_speed
    CardIcon.Injection -> R.drawable.ic_injection
    CardIcon.Pedal -> R.drawable.ic_accelerator_pedal
    CardIcon.MapPressure -> R.drawable.asset_map_turbo
    CardIcon.AirFlow -> R.drawable.ic_air_flow
    CardIcon.TurboPressure -> R.drawable.asset_map_turbo
    CardIcon.IntakeAirTemp -> R.drawable.asset_intake_air_temp
    CardIcon.OutsideAirTemp -> R.drawable.ic_outside_air_temp
    CardIcon.AtmosphericPressure -> R.drawable.ic_atmospheric_pressure
    CardIcon.FuelPressure -> R.drawable.asset_rail_pressure
    CardIcon.FuelPump -> R.drawable.ic_fuel_pump
    CardIcon.FuelFilter -> R.drawable.ic_fuel_filter
    CardIcon.EgrValve -> R.drawable.ic_egr_valve
    CardIcon.Alternator -> R.drawable.ic_alternator
    CardIcon.ChargeStatus -> R.drawable.ic_charge_status
    CardIcon.GlowPlug -> R.drawable.ic_glow_plug
    CardIcon.EngineFault -> R.drawable.ic_engine_fault
    CardIcon.EcuStatus -> R.drawable.ic_ecu_status
    CardIcon.SteeringAngle -> R.drawable.ic_steering_angle
    CardIcon.RoadIncline -> R.drawable.ic_road_incline
    CardIcon.DoorStatus -> R.drawable.ic_door_status
    CardIcon.Seatbelt -> R.drawable.ic_seatbelt
    CardIcon.Lighting -> R.drawable.ic_lighting
    CardIcon.ObdConnection -> R.drawable.ic_obd_connection
    CardIcon.CrankingAnalysis -> R.drawable.ic_cranking_analysis
    CardIcon.FuelCalibration -> R.drawable.ic_fuel_calibration
    CardIcon.LogsSupport -> R.drawable.ic_logs_support
    CardIcon.Settings -> R.drawable.ic_settings
    CardIcon.Engine -> R.drawable.asset_engine_load
}

@Composable
fun MetricIcon(
    palette: LoganPalette,
    icon: CardIcon,
    tint: Color = Color.Unspecified,
    modifier: Modifier = Modifier
) {
    // Cockpit icons are approved bitmap assets with a normalized transparent
    // canvas. A single centered slot and Fit scaling keeps every symbol fully
    // visible; no runtime vector drawing, offsets, crop or per-icon hacks.
    Image(
        painter = painterResource(id = icon.drawableRes()),
        contentDescription = null,
        modifier = modifier.fillMaxSize(),
        contentScale = ContentScale.Fit,
        alignment = Alignment.Center
    )
}

@Composable
fun DataCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String? = null,
    accent: Color = palette.accent,
    subtitle: String? = null,
    icon: CardIcon? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    textScale: Float = 1.0f
) {
    val scale = textScale.coerceIn(0.82f, 1.24f)
    val valueBase = when {
        value.length > 12 -> 15f
        value.length > 8 -> 18f
        value.length > 5 -> 21f
        else -> 23f
    }
    val titleBase = when {
        title.length >= 13 -> 8.5f
        title.length >= 10 -> 9f
        title.length >= 8 -> 9.5f
        else -> 11f
    }
    val valueSize = (valueBase * scale).sp
    val titleSize = (titleBase * scale).sp
    val unitSize = (12f * scale).sp
    val subtitleSize = (10f * scale).sp
    val iconSlot = (50f * scale.coerceIn(0.96f, 1.08f)).dp
    val iconGap = (11f * scale.coerceIn(0.94f, 1.06f)).dp
    OemCard(palette = palette, modifier = modifier, onClick = onClick) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (icon != null) {
                MetricIcon(
                    palette = palette,
                    icon = icon,
                    tint = Color.Unspecified,
                    modifier = Modifier.size(iconSlot)
                )
                Spacer(modifier = Modifier.width(iconGap))
            }
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    title.uppercase(),
                    color = accent,
                    fontSize = titleSize,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        value,
                        color = palette.textPrimary,
                        fontSize = valueSize,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.alignByBaseline()
                    )
                    if (!unit.isNullOrBlank()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            unit,
                            color = palette.textSecondary,
                            fontSize = unitSize,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.alignByBaseline()
                        )
                    }
                }
                if (subtitle != null) {
                    Text(
                        subtitle,
                        color = palette.textSecondary,
                        fontSize = subtitleSize,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsRow(
    palette: LoganPalette,
    title: String,
    subtitle: String? = null,
    value: String? = null,
    onClick: (() -> Unit)? = null,
    trailingSwitch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null
) {
    val shape = RoundedCornerShape(13.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(1.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = .08f), spotColor = Color.Black.copy(alpha = .08f))
            .clip(shape)
            .background(palette.surfaceVariant.copy(alpha = .72f))
            .border(1.dp, palette.line.copy(alpha = .82f), shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(horizontal = 13.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
            if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailingSwitch != null && onSwitch != null) {
            Switch(checked = trailingSwitch, onCheckedChange = onSwitch)
        } else if (value != null) {
            Text("$value  ›", color = palette.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        } else if (onClick != null) {
            Text("›", color = palette.textSecondary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}
