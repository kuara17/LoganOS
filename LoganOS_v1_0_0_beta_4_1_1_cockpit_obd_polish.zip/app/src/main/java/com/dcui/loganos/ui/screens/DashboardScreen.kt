package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.data.DriveHistoryItem
import com.dcui.loganos.data.TestHistoryItem
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.obd.CrankAnalysisResult
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.DigitalSpeedPanel
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.components.SpeedPanel
import com.dcui.loganos.ui.theme.LoganPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


private val LoganFuelInstantRed = Color(0xFFE53935)
private val LoganTempColdBlue = Color(0xFF4A78E6)
private val LoganTempWarmAmber = Color(0xFFF39C12)
private val LoganTempNormalGreen = Color(0xFF43A047)
private val LoganAcBlue = Color(0xFF2F80ED)

enum class MainTab {
    Cockpit,
    Trip,
    Tests,
    Technical,
    Settings
}

private fun tabLabel(tab: MainTab, language: AppLanguage): String = when (tab) {
    MainTab.Cockpit -> if (language == AppLanguage.English) "Cockpit" else "Kokpit"
    MainTab.Trip -> if (language == AppLanguage.English) "Trip" else "Sürüş"
    MainTab.Tests -> if (language == AppLanguage.English) "Tests" else "Testler"
    MainTab.Technical -> if (language == AppLanguage.English) "Tech" else "Teknik"
    MainTab.Settings -> if (language == AppLanguage.English) "Settings" else "Ayarlar"
}


private fun cockpitTextScale(settings: LoganSettings): Float = when (settings.cockpitTextSize) {
    CockpitTextSize.Small -> 0.90f
    CockpitTextSize.Normal -> 1.00f
    CockpitTextSize.Large -> 1.22f
}

private fun cockpitCardHeight(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 80.dp
    CockpitDensity.Balanced -> 96.dp
    CockpitDensity.Wide -> 112.dp
}

private fun cockpitSpacing(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 2.dp
    CockpitDensity.Balanced -> 6.dp
    CockpitDensity.Wide -> 10.dp
}

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onPinDriveHistory: (Long, Boolean) -> Unit,
    onDeleteDriveHistory: (Long) -> Unit,
    onExportDriveHistory: (Long) -> Unit,
    onPinTestHistory: (Long, Boolean) -> Unit,
    onDeleteTestHistory: (Long) -> Unit,
    onExportTestHistory: (Long) -> Unit,
    onExportAllHistory: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Cockpit) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                MainTab.Cockpit -> DashboardContent(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    obdState = obdState,
                    onResetMetrics = onResetMetrics,
                    onEndTripNow = onEndTripNow,
                    onRefreshObdDevices = onRefreshObdDevices,
                    onSelectObdDevice = onSelectObdDevice,
                    onConnectObd = onConnectObd,
                    onDisconnectObd = onDisconnectObd
                )
                MainTab.Trip -> TripPage(
                    palette = palette,
                    snapshot = snapshot,
                    language = settings.language,
                    obdState = obdState,
                    onRefreshHistory = onRefreshHistory,
                    onPinHistory = onPinDriveHistory,
                    onDeleteHistory = onDeleteDriveHistory,
                    onExportHistory = onExportDriveHistory,
                    onExportAllHistory = onExportAllHistory
                )
                MainTab.Tests -> CrankingPage(
                    palette = palette,
                    language = settings.language,
                    obdState = obdState,
                    onStartCrankAnalysis = onStartCrankAnalysis,
                    onClearManualCrankTests = onClearManualCrankTests,
                    onRefreshHistory = onRefreshHistory,
                    onPinHistory = onPinTestHistory,
                    onDeleteHistory = onDeleteTestHistory,
                    onExportHistory = onExportTestHistory
                )
                MainTab.Technical -> TechnicalPage(palette, settings, snapshot, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onCreateSupportPackage, onClearLastObdLog, onClearAllObdLogs)
                MainTab.Settings -> SettingsScreen(
                    palette, settings, obdState, onSettingsChange, onResetSetup, onResetMetrics, onEndTripNow,
                    onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog,
                    onShareObdLog, onCreateSupportPackage, onClearLastObdLog, onClearAllObdLogs,
                    onDeveloperTestStart, onDeveloperTestEnd, onStartCrankAnalysis, onClearManualCrankTests,
                    onRefreshHistory, onExportAllHistory
                )
            }
            DeveloperTestOverlay(palette, obdState, onDeveloperTestEnd)
        }
        BottomNavigationBar(palette, current = tab, language = settings.language) { tab = it }
    }
}

@Composable
private fun DeveloperTestOverlay(
    palette: LoganPalette,
    obdState: ObdState,
    onEnd: () -> Unit
) {
    val activeTest = obdState.activeDeveloperTest
    val doneMessage = obdState.developerTestDoneMessage
    if (activeTest == null && doneMessage == null) return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        OemCard(
            palette = palette,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (activeTest != null) {
                    Text(
                        text = activeTest,
                        color = palette.textPrimary,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = obdState.developerTestPhaseText ?: "Hazırlan",
                        color = palette.accent,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${obdState.developerTestRemainingSec ?: 0}",
                        color = palette.textPrimary,
                        fontSize = 64.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Ekrandaki komutu uygula. Test boyunca OBD verisi ve SQL log işaretleri kaydedilir.",
                        color = palette.textSecondary,
                        fontSize = 14.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onEnd,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Text("Testi Bitir", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(
                        text = doneMessage ?: "Test bitti",
                        color = palette.accent,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Geri sayım ekranı kapatılıyor.",
                        color = palette.textSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardContent(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit
) {
    var showResetDialog by remember { mutableStateOf(false) }
    var showObdQuickDialog by remember { mutableStateOf(false) }
    var showMovingWarning by remember { mutableStateOf(false) }

    val onObdPillClick = {
        if ((snapshot.speedKmh ?: 0) > 0) {
            showMovingWarning = true
        } else {
            onRefreshObdDevices()
            showObdQuickDialog = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        if (maxWidth > maxHeight) {
            DashboardLandscape(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        } else {
            DashboardPortrait(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        }
    }

    if (showResetDialog) {
        MetricResetDialog(
            palette = palette,
            language = settings.language,
            onDismiss = { showResetDialog = false },
            onReset = { action: TripMetricReset ->
                showResetDialog = false
                onResetMetrics(action)
            },
            onEndTripNow = {
                showResetDialog = false
                onEndTripNow()
            }
        )
    }

    if (showObdQuickDialog) {
        ObdQuickConnectDialog(
            palette = palette,
            language = settings.language,
            obdState = obdState,
            onDismiss = { showObdQuickDialog = false },
            onRefresh = onRefreshObdDevices,
            onSelectAndConnect = { device: PairedObdDevice ->
                onSelectObdDevice(device)
                onConnectObd()
                showObdQuickDialog = false
            },
            onDisconnect = {
                onDisconnectObd()
                showObdQuickDialog = false
            }
        )
    }

    if (showMovingWarning) {
        AlertDialog(
            onDismissRequest = { showMovingWarning = false },
            title = {
                Text(
                    if (settings.language == AppLanguage.English) "Vehicle is moving" else "Araç hareket halinde",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Text(
                    if (settings.language == AppLanguage.English) {
                        "OBD device selection is available when the vehicle is stopped."
                    } else {
                        "OBD cihaz seçimi araç durduğunda kullanılabilir."
                    },
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showMovingWarning = false }) {
                    Text(if (settings.language == AppLanguage.English) "OK" else "Tamam")
                }
            }
        )
    }
}

@Composable
private fun DashboardPortrait(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val smallScreen = maxWidth < 360.dp || maxHeight < 680.dp
        val largeScreen = maxWidth >= 430.dp && maxHeight >= 820.dp
        val screenScale = when {
            smallScreen -> 0.90f
            largeScreen -> 1.05f
            else -> 1.0f
        }
        val textScale = cockpitTextScale(settings) * screenScale
        val spacing = cockpitSpacing(settings) * if (smallScreen) 0.65f else 1f
        val baseMetricHeight = (cockpitCardHeight(settings) * screenScale).coerceIn(74.dp, 118.dp)
        val gaugeFraction = when (settings.cockpitDensity) {
            CockpitDensity.Compact -> 0.20f
            CockpitDensity.Balanced -> 0.23f
            CockpitDensity.Wide -> 0.26f
        }
        val gaugeHeight = (maxHeight * gaugeFraction)
            .coerceIn(if (smallScreen) 122.dp else 136.dp, if (largeScreen) 220.dp else 200.dp)
        val headerEstimate = if (obdState.timeTrusted) 44.dp else 58.dp
        val fixedContent = headerEstimate + gaugeHeight + 4.dp + (spacing * 9f) + 10.dp
        val fillMetricHeight = ((maxHeight - fixedContent).value / 4f).dp
        val metricHeight = maxOf(baseMetricHeight, fillMetricHeight).coerceAtMost(124.dp)
        val horizontalPadding = if (maxWidth < 360.dp) 8.dp else 14.dp

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = horizontalPadding, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(spacing),
            contentPadding = PaddingValues(bottom = 2.dp)
        ) {
            item { DashboardConceptHeader(palette, snapshot, obdState, settings.demoMode, settings.language, onOpenReset = onOpenReset, onObdClick = onObdClick) }
            item {
                ConceptSpeedBlock(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(gaugeHeight)
                )
            }
            item { ConceptDivider(palette) }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, subtitle = if ((snapshot.tripDistanceKm ?: 0.0) < 3.0 && snapshot.averageConsumption != null) "Kısa sürüş" else null, modifier = Modifier.weight(1f), textScale = textScale)
                    ConceptMetricCell(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, modifier = Modifier.weight(1f), textScale = textScale)
                }
            }
            item { ConceptDivider(palette) }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", CardIcon.Distance, modifier = Modifier.weight(1f), textScale = textScale)
                    ConceptMetricCell(palette, "Sürüş Maliyeti", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, subtitle = if (settings.demoMode) "Demo veri" else null, modifier = Modifier.weight(1f), textScale = textScale)
                }
            }
            item { ConceptDivider(palette) }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    val temp = snapshot.engineTempC?.toString() ?: "--"
                    ConceptMetricCell(palette, "Hararet / Fan", temp, "°C", CardIcon.TemperatureFan, subtitle = "Fan: test bekliyor", modifier = Modifier.weight(1f), textScale = textScale)
                    ConceptMetricCell(palette, "Klima", snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", null, CardIcon.Ac, modifier = Modifier.weight(1f), textScale = textScale)
                }
            }
            item { ConceptDivider(palette) }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", CardIcon.Rpm, modifier = Modifier.weight(1f), textScale = textScale)
                    ConceptMetricCell(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, subtitle = if (settings.demoMode) "Demo veri" else null, modifier = Modifier.weight(1f), textScale = textScale)
                }
            }
        }
    }
}

@Composable
private fun DashboardLandscape(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val shortScreen = maxHeight < 360.dp
        val screenScale = if (shortScreen) 0.88f else if (maxHeight > 520.dp) 1.06f else 1f
        val textScale = cockpitTextScale(settings) * screenScale
        val spacing = cockpitSpacing(settings) * if (shortScreen) 0.55f else 1f
        val outerPadding = if (shortScreen) 6.dp else 12.dp
        val gaugeWeight = when (settings.cockpitDensity) {
            CockpitDensity.Compact -> 0.78f
            CockpitDensity.Balanced -> 0.92f
            CockpitDensity.Wide -> 1.06f
        }
        val metricsWeight = when (settings.cockpitDensity) {
            CockpitDensity.Compact -> 1.30f
            CockpitDensity.Balanced -> 1.18f
            CockpitDensity.Wide -> 1.08f
        }

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = outerPadding, vertical = if (shortScreen) 3.dp else 6.dp),
            horizontalArrangement = Arrangement.spacedBy(if (shortScreen) 8.dp else 14.dp)
        ) {
            Column(modifier = Modifier.weight(gaugeWeight).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(spacing)) {
                DashboardConceptHeader(palette, snapshot, obdState, settings.demoMode, settings.language, compact = true, onOpenReset = onOpenReset, onObdClick = onObdClick)
                ConceptSpeedBlock(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    compact = true
                )
            }
            Column(modifier = Modifier.weight(metricsWeight).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(spacing)) {
                ConceptDivider(palette)
                ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                    ConceptMetricCell(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                    ConceptMetricCell(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                }
                ConceptDivider(palette)
                ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                    ConceptMetricCell(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", CardIcon.Distance, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                    ConceptMetricCell(palette, "Maliyet", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                }
                ConceptDivider(palette)
                ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                    ConceptMetricCell(palette, "Hararet / Fan", snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.TemperatureFan, subtitle = "Fan: test bekliyor", modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                    ConceptMetricCell(palette, "Klima", snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", null, CardIcon.Ac, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                }
                ConceptDivider(palette)
                ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                    ConceptMetricCell(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", CardIcon.Rpm, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                    ConceptMetricCell(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                }
            }
        }
    }
}

@Composable
private fun DashboardConceptHeader(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean = false,
    onOpenReset: (() -> Unit)? = null,
    onObdClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 38.dp else 44.dp)
                .clipToBounds(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = if (compact) 2.dp else 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                LoganWordmark(palette, compact = true)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ObdStatusPill(
                    palette = palette,
                    connected = snapshot.connected || obdState.connected,
                    connecting = obdState.connecting,
                    demoMode = demoMode,
                    language = language,
                    compact = true,
                    onClick = onObdClick
                )
                if (onOpenReset != null) {
                    HeaderOverflowButton(palette = palette, compact = true, onClick = onOpenReset)
                }
            }
        }
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .80f)))
        if (!obdState.timeTrusted) {
            Text(
                text = if (language == AppLanguage.English) "Time synchronizing…" else "Saat eşitleniyor…",
                color = palette.warning,
                fontSize = if (compact) 8.sp else 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun HeaderOverflowButton(palette: LoganPalette, compact: Boolean, onClick: () -> Unit) {
    // More visible cockpit menu while keeping a restrained OEM-style footprint.
    val size = if (compact) 32.dp else 36.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(999.dp))
            .background(palette.surfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "⋮",
            color = palette.textPrimary,
            fontSize = if (compact) 20.sp else 22.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            lineHeight = if (compact) 20.sp else 22.sp
        )
    }
}

@Composable
private fun ObdStatusPill(
    palette: LoganPalette,
    connected: Boolean,
    connecting: Boolean,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val english = language == AppLanguage.English
    val label = when {
        demoMode -> "DEMO"
        connected -> if (english) "OBD ON" else "OBD BAĞLI"
        connecting -> if (english) "CONNECTING" else "BAĞLANIYOR"
        else -> if (english) "OBD WAIT" else "OBD BEK."
    }
    val color = when {
        demoMode -> palette.warning
        connected -> palette.accent
        connecting -> palette.warning
        else -> palette.textSecondary
    }
    Row(
        modifier = modifier
            .heightIn(min = if (compact) 32.dp else 36.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = .12f))
            .clickable { onClick() }
            .padding(horizontal = if (compact) 9.dp else 11.dp, vertical = if (compact) 4.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 7.dp else 8.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(color)
        )
        Text(
            text = label,
            color = color,
            fontSize = if (compact) 9.sp else 10.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun ObdQuickConnectDialog(
    palette: LoganPalette,
    language: AppLanguage,
    obdState: ObdState,
    onDismiss: () -> Unit,
    onRefresh: () -> Unit,
    onSelectAndConnect: (PairedObdDevice) -> Unit,
    onDisconnect: () -> Unit
) {
    val english = language == AppLanguage.English
    var chooseDevice by remember(obdState.connected) { mutableStateOf(!obdState.connected) }
    val selectedDevice = obdState.pairedDevices.firstOrNull { it.address == obdState.selectedAddress }
    val orderedDevices = obdState.pairedDevices.sortedWith(
        compareByDescending<PairedObdDevice> { it.address == obdState.selectedAddress }
            .thenBy { it.name.lowercase(Locale.getDefault()) }
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (obdState.connected && !chooseDevice) {
                    if (english) "OBD connected" else "OBD bağlı"
                } else {
                    if (english) "Choose OBD device" else "OBD cihazı seç"
                },
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (obdState.connected && !chooseDevice) {
                    Text(
                        selectedDevice?.name ?: obdState.selectedName ?: if (english) "Connected adapter" else "Bağlı adaptör",
                        color = palette.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    val address = selectedDevice?.address ?: obdState.selectedAddress
                    if (!address.isNullOrBlank()) {
                        Text(address, color = palette.textSecondary, fontSize = 11.sp)
                    }
                    Text(obdState.status, color = palette.textSecondary, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDisconnect,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.surfaceVariant,
                                contentColor = palette.critical
                            )
                        ) {
                            Text(if (english) "Disconnect" else "Bağlantıyı kes")
                        }
                        Button(
                            onClick = {
                                chooseDevice = true
                                onRefresh()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                        ) {
                            Text(if (english) "Change device" else "Cihaz değiştir")
                        }
                    }
                } else {
                    if (obdState.connecting) {
                        Text(
                            if (english) "Connecting…" else "Bağlanıyor…",
                            color = palette.warning,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (orderedDevices.isEmpty()) {
                        Text(
                            if (english) {
                                "No paired OBD adapter was found. Pair the adapter in Android Bluetooth settings, then refresh."
                            } else {
                                "Eşleşmiş OBD adaptörü bulunamadı. Adaptörü Android Bluetooth ayarlarından eşleştirip yenileyin."
                            },
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    } else {
                        orderedDevices.forEach { device: PairedObdDevice ->
                            val lastUsed = device.address == obdState.selectedAddress
                            SettingsRow(
                                palette = palette,
                                title = device.name,
                                subtitle = buildString {
                                    if (lastUsed) {
                                        append(if (english) "Last used" else "Son kullanılan")
                                        append(" • ")
                                    }
                                    append(device.address)
                                },
                                value = if (lastUsed) {
                                    if (english) "Connect" else "Bağlan"
                                } else {
                                    if (english) "Select" else "Seç"
                                },
                                onClick = { onSelectAndConnect(device) }
                            )
                        }
                    }
                    TextButton(
                        onClick = onRefresh,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(if (english) "Refresh devices" else "Cihazları yenile")
                    }
                    if (obdState.lastError != null) {
                        Text(
                            obdState.lastError ?: "",
                            color = palette.critical,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    } else if (obdState.status.isNotBlank()) {
                        Text(
                            obdState.status,
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (english) "Close" else "Kapat")
            }
        }
    )
}

private enum class CockpitAction {
    ResetAverage,
    ResetCost,
    ResetAverageAndCost,
    EndTrip
}

@Composable
private fun MetricResetDialog(
    palette: LoganPalette,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onReset: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit
) {
    var pendingAction by remember { mutableStateOf<CockpitAction?>(null) }
    val english = language == AppLanguage.English
    val pendingLabel = when (pendingAction) {
        CockpitAction.ResetAverage -> if (english) "average consumption" else "ortalama tüketim"
        CockpitAction.ResetCost -> if (english) "trip cost" else "sürüş maliyeti"
        CockpitAction.ResetAverageAndCost -> if (english) "average consumption and trip cost" else "ortalama tüketim ve sürüş maliyeti"
        CockpitAction.EndTrip -> if (english) "the current trip" else "mevcut sürüş"
        null -> ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    pendingAction == null -> if (english) "Cockpit actions" else "Kokpit işlemleri"
                    pendingAction == CockpitAction.EndTrip -> if (english) "End trip now?" else "Sürüş şimdi bitirilsin mi?"
                    else -> if (english) "Confirm reset" else "Sıfırlamayı onayla"
                },
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            if (pendingAction == null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (english) {
                            "Reset calculations without deleting trip totals, or close the current trip manually."
                        } else {
                            "Yolculuk toplamlarını silmeden hesapları sıfırlayın veya mevcut sürüşü elle kapatın."
                        },
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    ResetChoice(palette, if (english) "Reset average consumption" else "Ortalama tüketimi sıfırla") {
                        pendingAction = CockpitAction.ResetAverage
                    }
                    ResetChoice(palette, if (english) "Reset trip cost" else "Sürüş maliyetini sıfırla") {
                        pendingAction = CockpitAction.ResetCost
                    }
                    ResetChoice(palette, if (english) "Reset average + cost" else "Ortalama + maliyeti sıfırla") {
                        pendingAction = CockpitAction.ResetAverageAndCost
                    }
                    ResetChoice(palette, if (english) "End trip now" else "Sürüşü şimdi bitir") {
                        pendingAction = CockpitAction.EndTrip
                    }
                }
            } else {
                Text(
                    if (pendingAction == CockpitAction.EndTrip) {
                        if (english) {
                            "Close $pendingLabel? The next movement will start a new trip."
                        } else {
                            "$pendingLabel kapatılsın mı? Sonraki hareket yeni sürüş olarak başlayacak."
                        }
                    } else {
                        if (english) {
                            "Reset $pendingLabel from this point? Trip totals will not be deleted."
                        } else {
                            "$pendingLabel bu noktadan itibaren sıfırlansın mı? Yolculuk toplamları silinmez."
                        }
                    },
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            pendingAction?.let { action ->
                TextButton(
                    onClick = {
                        when (action) {
                            CockpitAction.ResetAverage -> onReset(TripMetricReset.Average)
                            CockpitAction.ResetCost -> onReset(TripMetricReset.Cost)
                            CockpitAction.ResetAverageAndCost -> onReset(TripMetricReset.AverageAndCost)
                            CockpitAction.EndTrip -> onEndTripNow()
                        }
                    }
                ) {
                    Text(
                        if (action == CockpitAction.EndTrip) {
                            if (english) "End trip" else "Sürüşü bitir"
                        } else {
                            if (english) "Reset" else "Sıfırla"
                        }
                    )
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (pendingAction != null) pendingAction = null else onDismiss()
                }
            ) {
                Text(
                    if (pendingAction != null) {
                        if (english) "Back" else "Geri"
                    } else {
                        if (english) "Cancel" else "İptal"
                    }
                )
            }
        }
    )
}

@Composable
private fun ResetChoice(palette: LoganPalette, label: String, onClick: () -> Unit) {
    Text(
        text = label,
        color = palette.textPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceVariant)
            .clickable { onClick() }
            .padding(12.dp)
    )
}

@Composable
private fun ConceptSpeedBlock(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier,
    compact: Boolean = false
) {
    BoxWithConstraints(
        modifier = modifier
            .padding(top = if (compact) 2.dp else 6.dp, bottom = 3.dp)
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        val maxSpeed = 240f
        val progress = ((snapshot.speedKmh ?: 0) / maxSpeed).coerceIn(0f, 1f)
        DigitalSpeedPanel(
            palette = palette,
            speed = snapshot.speedKmh,
            progress = progress,
            modifier = Modifier.fillMaxSize(),
            demoMode = settings.demoMode,
            previewMode = false,
            textScale = cockpitTextScale(settings)
        )
    }
}

@Composable
private fun ConceptDivider(palette: LoganPalette) {
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .68f)))
}

@Composable
private fun ConceptMetricRow(
    palette: LoganPalette,
    height: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (height.value > 0f) Modifier.height(height) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        content = content
    )
}

@Composable
private fun ConceptMetricCell(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    textScale: Float = 1.0f
) {
    val scale = textScale.coerceIn(0.84f, 1.24f)
    val iconSlot = (54f * scale.coerceIn(0.92f, 1.08f)).dp
    val gap = (11f * scale.coerceIn(0.94f, 1.06f)).dp
    val titleAreaHeight = (28f * scale.coerceIn(0.92f, 1.10f)).dp
    val subtitleAreaHeight = (14f * scale.coerceIn(0.92f, 1.08f)).dp

    Box(modifier = modifier.fillMaxHeight().padding(horizontal = 4.dp, vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MetricIcon(
                palette = palette,
                icon = icon,
                tint = Color.Unspecified,
                modifier = Modifier.size(iconSlot)
            )
            Spacer(modifier = Modifier.width(gap))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(titleAreaHeight),
                    contentAlignment = Alignment.BottomStart
                ) {
                    Text(
                        title.uppercase(),
                        color = palette.accent,
                        fontSize = (12.2f * scale).sp,
                        lineHeight = (13.2f * scale).sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(Modifier.height(2.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        value,
                        color = palette.textPrimary,
                        fontSize = (24f * scale).sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.alignByBaseline()
                    )
                    if (!unit.isNullOrBlank()) {
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            unit,
                            color = palette.textSecondary,
                            fontSize = (12.5f * scale).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.alignByBaseline()
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(subtitleAreaHeight),
                    contentAlignment = Alignment.TopStart
                ) {
                    if (subtitle != null) {
                        Text(
                            subtitle,
                            color = palette.textSecondary,
                            fontSize = (9.6f * scale).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TemperatureCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp < 50 -> LoganTempColdBlue
        temp < 80 -> LoganTempWarmAmber
        temp <= 96 -> LoganTempNormalGreen
        else -> palette.critical
    }
    DataCard(
        palette = palette,
        title = "Hararet",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = tempColor,
        subtitle = "Soğutma suyu",
        icon = CardIcon.Temperature,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun CoolingFanCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp < 50 -> LoganTempColdBlue
        temp < 80 -> LoganTempWarmAmber
        temp <= 96 -> LoganTempNormalGreen
        else -> palette.critical
    }
    DataCard(
        palette = palette,
        title = "Hararet / Fan",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = tempColor,
        subtitle = "Fan: test bekliyor",
        icon = CardIcon.TemperatureFan,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun FanCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    CoolingFanCard(palette, snapshot, modifier)
}

@Composable
private fun ClimateCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val label = snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--"
    DataCard(
        palette = palette,
        title = "Klima",
        value = label,
        accent = if (snapshot.acOn == true) LoganAcBlue else palette.textSecondary,
        subtitle = "A/C durumu",
        icon = CardIcon.Ac,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun BottomNavigationBar(palette: LoganPalette, current: MainTab, language: AppLanguage, onSelect: (MainTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(palette.surface)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        MainTab.entries.forEach { tab ->
            val selected = current == tab
            Text(
                text = tabLabel(tab, language),
                color = if (selected) palette.accent else palette.textSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (selected) palette.accent.copy(alpha = .12f) else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun TripPage(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    language: AppLanguage,
    obdState: ObdState,
    onRefreshHistory: () -> Unit,
    onPinHistory: (Long, Boolean) -> Unit,
    onDeleteHistory: (Long) -> Unit,
    onExportHistory: (Long) -> Unit,
    onExportAllHistory: () -> Unit
) {
    val tr = language != AppLanguage.English
    var selected by remember { mutableStateOf<DriveHistoryItem?>(null) }
    var deleteCandidate by remember { mutableStateOf<DriveHistoryItem?>(null) }
    val moving = (snapshot.speedKmh ?: 0) > 0

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Sürüş Merkezi" else "Trip Center", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
                    Text(if (tr) "Güncel yolculuk ve otomatik sürüş geçmişi" else "Current trip and automatic drive history", color = palette.textSecondary, fontSize = 13.sp)
                }
                TextButton(onClick = onRefreshHistory) { Text(if (tr) "Yenile" else "Refresh") }
            }
        }
        item {
            DataCard(
                palette,
                if (tr) "Güncel Yolculuk" else "Current Trip",
                snapshot.tripStateText ?: if (snapshot.connected || snapshot.demo) (if (tr) "Hesaplanıyor" else "Calculating") else (if (tr) "Beklemede" else "Waiting"),
                subtitle = if (tr) "Hareket edince başlar" else "Starts when the vehicle moves",
                icon = CardIcon.Time,
                modifier = Modifier.fillMaxWidth().height(104.dp)
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, if (tr) "Mesafe" else "Distance", fmt(snapshot.tripDistanceKm), "km", icon = CardIcon.Distance, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, if (tr) "Yakıt" else "Fuel", fmt(snapshot.fuelUsedL), "L", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, if (tr) "Ortalama" else "Average", fmt(snapshot.averageConsumption), "L/100 km", subtitle = if (tr) "1 km sonrası" else "After 1 km", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, if (tr) "Süre" else "Duration", snapshot.tripDurationText ?: "00:00", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Sürüş Geçmişi" else "Drive History", color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (tr) "${obdState.driveHistory.size} kayıt • sabitlenenler otomatik silinmez" else "${obdState.driveHistory.size} records • pinned records are protected",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
                TextButton(onClick = onExportAllHistory, enabled = obdState.driveHistory.isNotEmpty() || obdState.testHistory.isNotEmpty()) {
                    Text(if (tr) "Tümünü Dışa Aktar" else "Export All")
                }
            }
        }
        if (obdState.driveHistory.isEmpty()) {
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Text(if (tr) "Henüz tamamlanmış sürüş kaydı yok. Sürüşler arka planda otomatik kaydedilir." else "No completed drive record yet. Drives are saved automatically in the background.", color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                }
            }
        } else {
            items(obdState.driveHistory.size, key = { obdState.driveHistory[it].id }) { index ->
                val item = obdState.driveHistory[index]
                DriveHistoryCard(
                    palette = palette,
                    item = item,
                    language = language,
                    moving = moving,
                    onInspect = { selected = item },
                    onPin = { onPinHistory(item.id, !item.pinned) },
                    onExport = { onExportHistory(item.id) },
                    onDelete = { deleteCandidate = item }
                )
            }
        }
    }

    selected?.let { item ->
        AlertDialog(
            onDismissRequest = { selected = null },
            title = { Text(if (tr) "Sürüş Detayı" else "Drive Details", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    HistoryDetailLine(palette, if (tr) "Durum" else "Status", driveStatusLabel(item.status, language))
                    HistoryDetailLine(palette, if (tr) "Mesafe" else "Distance", String.format(Locale.US, "%.2f km", item.distanceKm))
                    HistoryDetailLine(palette, if (tr) "Süre" else "Duration", historyDuration(item.durationMs))
                    HistoryDetailLine(palette, if (tr) "Yakıt" else "Fuel", String.format(Locale.US, "%.3f L", item.fuelUsedL))
                    HistoryDetailLine(palette, if (tr) "Ortalama" else "Average", item.averageL100?.let { String.format(Locale.US, "%.2f L/100 km", it) } ?: "--")
                    HistoryDetailLine(palette, if (tr) "Azami hız" else "Max speed", item.maxSpeedKmh?.let { "$it km/h" } ?: "--")
                    HistoryDetailLine(palette, if (tr) "Azami devir" else "Max RPM", item.maxRpm?.let { "$it rpm" } ?: "--")
                    HistoryDetailLine(palette, if (tr) "OBD oturumu" else "OBD sessions", item.sessionCount.toString())
                }
            },
            confirmButton = { TextButton(onClick = { selected = null; onExportHistory(item.id) }) { Text(if (tr) "Dışa aktar" else "Export") } },
            dismissButton = { TextButton(onClick = { selected = null }) { Text(if (tr) "Kapat" else "Close") } }
        )
    }

    deleteCandidate?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text(if (tr) "Sürüş kaydı silinsin mi?" else "Delete drive record?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Bu sürüş ve ilişkili OBD örnekleri kalıcı olarak silinecek. Dışa aktarılmış dosyalar etkilenmez." else "This drive and its related OBD samples will be permanently deleted. Exported files are not affected.", color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = { deleteCandidate = null; onDeleteHistory(item.id) }, enabled = !moving && !item.activeLike) {
                    Text(if (tr) "Sil" else "Delete")
                }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
}

@Composable
private fun DriveHistoryCard(
    palette: LoganPalette,
    item: DriveHistoryItem,
    language: AppLanguage,
    moving: Boolean,
    onInspect: () -> Unit,
    onPin: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val tr = language != AppLanguage.English
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Text(driveStatusLabel(item.status, language), color = if (item.activeLike) palette.accent else palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                if (item.pinned) Text("★", color = palette.accent, fontSize = 21.sp)
            }
            Text(
                "${String.format(Locale.US, "%.2f", item.distanceKm)} km • ${historyDuration(item.durationMs)} • ${item.averageL100?.let { String.format(Locale.US, "%.2f L/100 km", it) } ?: "--"}",
                color = palette.textSecondary,
                fontSize = 13.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(onClick = onInspect, modifier = Modifier.weight(1f)) { Text(if (tr) "İncele" else "Inspect", fontSize = 11.sp) }
                TextButton(onClick = onExport, modifier = Modifier.weight(1f)) { Text(if (tr) "Dışa aktar" else "Export", fontSize = 11.sp) }
                TextButton(onClick = onPin, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (item.pinned) (if (tr) "Korumayı kaldır" else "Unpin") else (if (tr) "Koru" else "Pin"), fontSize = 11.sp) }
                TextButton(onClick = onDelete, enabled = !moving && !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (tr) "Sil" else "Delete", fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun HistoryDetailLine(palette: LoganPalette, label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = palette.textSecondary, fontSize = 13.sp)
        Text(value, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
    }
}

private fun historyDate(ms: Long, trusted: Boolean, language: AppLanguage): String {
    if (!trusted || ms <= 0L) return if (language == AppLanguage.English) "Time pending" else "Saat eşitleniyor"
    return SimpleDateFormat("dd.MM.yyyy • HH:mm", Locale.getDefault()).format(Date(ms))
}

private fun historyDuration(ms: Long): String {
    val totalMinutes = (ms.coerceAtLeast(0L) / 60_000L)
    val hours = totalMinutes / 60L
    val minutes = totalMinutes % 60L
    return if (hours > 0L) "%d sa %02d dk".format(hours, minutes) else "%d dk".format(minutes)
}

private fun driveStatusLabel(status: String, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (status) {
        "ACTIVE" -> if (tr) "Aktif sürüş" else "Active drive"
        "PARKED" -> if (tr) "Mola • devam edebilir" else "Paused • may continue"
        "TIME_PENDING" -> if (tr) "Saat doğrulaması bekleniyor" else "Waiting for trusted time"
        "RECOVERED" -> if (tr) "Kontak kesintisinden kurtarıldı" else "Recovered after power loss"
        else -> if (tr) "Tamamlandı" else "Completed"
    }
}


@Composable
private fun CrankingPage(
    palette: LoganPalette,
    language: AppLanguage,
    obdState: ObdState,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onPinHistory: (Long, Boolean) -> Unit,
    onDeleteHistory: (Long) -> Unit,
    onExportHistory: (Long) -> Unit
) {
    val tr = language != AppLanguage.English
    var confirmClear by remember { mutableStateOf(false) }
    var selectedHistory by remember { mutableStateOf<TestHistoryItem?>(null) }
    var deleteHistory by remember { mutableStateOf<TestHistoryItem?>(null) }
    val last = obdState.lastAutoCrankResult ?: obdState.savedManualCrankTests.firstOrNull()
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(if (tr) "Marş Analizi" else "Cranking Analysis", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text(
                if (tr) "Otomatik algılama + manuel test. Kesin arıza teşhisi değildir." else "Automatic detection + manual test. This is not a definitive diagnosis.",
                color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Manuel Marş Testi" else "Manual Cranking Test", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text(
                        when {
                            obdState.crankingInProgress -> if (tr) "Marş algılandı, veriler analiz ediliyor..." else "Cranking detected, analyzing data..."
                            obdState.manualCrankArmed -> if (tr) "Hazır. Şimdi marşa basın." else "Ready. Start the engine now."
                            obdState.connected -> if (tr) "Motor çalışmadan önce testi başlatın, ardından marşa basın." else "Start the test before the engine is running, then crank the engine."
                            else -> if (tr) "Test için önce OBD bağlantısı gerekli." else "OBD connection is required before testing."
                        },
                        color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        DataCard(palette, if (tr) "RPM" else "RPM", obdState.snapshot.rpm?.toString() ?: "--", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(84.dp))
                        DataCard(palette, if (tr) "Akü" else "Battery", obdState.snapshot.batteryV?.let { String.format(Locale.US, "%.1f", it) } ?: obdState.snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
                    }
                    Button(
                        onClick = onStartCrankAnalysis,
                        enabled = obdState.connected && !obdState.manualCrankArmed && !obdState.crankingInProgress,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) { Text(if (tr) "Marş Analizini Başlat" else "Start Cranking Analysis") }
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Son Otomatik Analiz" else "Last Automatic Analysis", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.lastAutoCrankResult == null) {
                        Text(if (tr) "Henüz otomatik marş analizi yok. Uygulama bağlıyken marş basılırsa arka planda yorum üretir." else "No automatic analysis yet. When the app is connected before cranking, it will analyze in the background.", color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                    } else {
                        CrankResultBlock(palette, obdState.lastAutoCrankResult, language)
                    }
                    Text(if (tr) "Otomatik analizler kalıcı arşive yazılmaz; son 5 kayıt / 24 saat geçici tutulur." else "Automatic analyses are not stored permanently; only the last 5 / 24 hours are kept temporarily.", color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Kayıtlı Manuel Testler" else "Saved Manual Tests", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.savedManualCrankTests.isEmpty()) {
                        Text(if (tr) "Manuel başlatılmış kayıtlı test yok." else "No saved manual tests.", color = palette.textSecondary, fontSize = 13.sp)
                    } else {
                        obdState.savedManualCrankTests.take(8).forEachIndexed { index, result ->
                            Text("#${index + 1} • ${crankDate(result.timestampMs, language)} • ${String.format(Locale.US, "%.1f", result.durationSec)} sn • ${localCrankStatus(result.status, language)}", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        TextButton(onClick = { confirmClear = true }) { Text(if (tr) "Manuel marş testlerini sil" else "Delete manual cranking tests") }
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Test Geçmişi" else "Test History", color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(if (tr) "Başlatılan teknik ve manuel testler otomatik kaydedilir" else "Started technical and manual tests are saved automatically", color = palette.textSecondary, fontSize = 12.sp)
                }
                TextButton(onClick = onRefreshHistory) { Text(if (tr) "Yenile" else "Refresh") }
            }
        }
        if (obdState.testHistory.isEmpty()) {
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Text(if (tr) "Henüz otomatik kaydedilmiş test yok." else "No automatically saved test yet.", color = palette.textSecondary, fontSize = 13.sp)
                }
            }
        } else {
            items(obdState.testHistory.size, key = { obdState.testHistory[it].id }) { index ->
                val item = obdState.testHistory[index]
                TestHistoryCard(
                    palette = palette,
                    item = item,
                    language = language,
                    onInspect = { selectedHistory = item },
                    onPin = { onPinHistory(item.id, !item.pinned) },
                    onExport = { onExportHistory(item.id) },
                    onDelete = { deleteHistory = item }
                )
            }
        }
        if (last != null) {
            item {
                DataCard(palette, if (tr) "Özet" else "Summary", localCrankStatus(last.status, language), subtitle = localCrankComment(last, language), icon = CardIcon.Battery, modifier = Modifier.fillMaxWidth().height(106.dp))
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(if (tr) "Marş kayıtları silinsin mi?" else "Delete cranking records?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Eski geçici manuel marş sonuçları silinecek. Yeni Test Geçmişi kayıtları bu işlemden etkilenmez." else "Legacy temporary manual crank results will be deleted. New Test History records are not affected.", color = palette.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmClear = false; onClearManualCrankTests() }) { Text(if (tr) "Sil" else "Delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
    selectedHistory?.let { item ->
        AlertDialog(
            onDismissRequest = { selectedHistory = null },
            title = { Text(item.name, color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    HistoryDetailLine(palette, if (tr) "Tür" else "Type", item.testType)
                    HistoryDetailLine(palette, if (tr) "Durum" else "Status", testStatusLabel(item.status, language))
                    HistoryDetailLine(palette, if (tr) "Süre" else "Duration", historyDuration(item.durationMs))
                    HistoryDetailLine(palette, if (tr) "Örnek" else "Samples", item.sampleCount.toString())
                    item.summary?.let { Text(it, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { selectedHistory = null; onExportHistory(item.id) }) { Text(if (tr) "Dışa aktar" else "Export") } },
            dismissButton = { TextButton(onClick = { selectedHistory = null }) { Text(if (tr) "Kapat" else "Close") } }
        )
    }
    deleteHistory?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteHistory = null },
            title = { Text(if (tr) "Test kaydı silinsin mi?" else "Delete test record?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Test ve ilişkili örnekler kalıcı olarak silinecek. Dışa aktarılmış dosyalar etkilenmez." else "The test and its related samples will be permanently deleted. Exported files are not affected.", color = palette.textSecondary) },
            confirmButton = { TextButton(onClick = { deleteHistory = null; onDeleteHistory(item.id) }, enabled = !item.activeLike) { Text(if (tr) "Sil" else "Delete") } },
            dismissButton = { TextButton(onClick = { deleteHistory = null }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
}

@Composable
private fun TestHistoryCard(
    palette: LoganPalette,
    item: TestHistoryItem,
    language: AppLanguage,
    onInspect: () -> Unit,
    onPin: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val tr = language != AppLanguage.English
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${historyDate(item.startedAtMs, item.timeTrusted, language)} • ${testStatusLabel(item.status, language)}", color = palette.textSecondary, fontSize = 11.sp)
                }
                if (item.pinned) Text("★", color = palette.accent, fontSize = 21.sp)
            }
            Text("${historyDuration(item.durationMs)} • ${item.sampleCount} ${if (tr) "örnek" else "samples"}", color = palette.textSecondary, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(onClick = onInspect, modifier = Modifier.weight(1f)) { Text(if (tr) "İncele" else "Inspect", fontSize = 11.sp) }
                TextButton(onClick = onExport, modifier = Modifier.weight(1f)) { Text(if (tr) "Dışa aktar" else "Export", fontSize = 11.sp) }
                TextButton(onClick = onPin, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (item.pinned) (if (tr) "Korumayı kaldır" else "Unpin") else (if (tr) "Koru" else "Pin"), fontSize = 11.sp) }
                TextButton(onClick = onDelete, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (tr) "Sil" else "Delete", fontSize = 11.sp) }
            }
        }
    }
}

private fun testStatusLabel(status: String, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (status) {
        "ACTIVE" -> if (tr) "Aktif" else "Active"
        "INTERRUPTED" -> if (tr) "Kesintiye uğradı" else "Interrupted"
        "COMPLETED_MANUAL" -> if (tr) "Manuel tamamlandı" else "Completed manually"
        else -> if (tr) "Tamamlandı" else "Completed"
    }
}

@Composable
private fun CrankResultBlock(palette: LoganPalette, result: CrankAnalysisResult, language: AppLanguage) {
    val tr = language != AppLanguage.English
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        DataCard(palette, if (tr) "Süre" else "Duration", String.format(Locale.US, "%.1f", result.durationSec), if (tr) "sn" else "s", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(84.dp))
        DataCard(palette, if (tr) "Min Volt" else "Min Volt", result.minVoltage?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
    }
    Spacer(Modifier.height(6.dp))
    Text("${localCrankStatus(result.status, language)} • ${localBatteryStatus(result.batteryStatus, language)}", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
    Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
}

private fun crankDate(ms: Long, language: AppLanguage): String = if (ms > 0L) {
    SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(ms))
} else if (language == AppLanguage.English) {
    "Time pending"
} else {
    "Saat bekleniyor"
}

private fun localBatteryStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "İyi" -> "Good"
        "Sınırda" -> "Borderline"
        "Zayıf" -> "Weak"
        "Çok düşük" -> "Very low"
        "Ölçülemedi" -> "Not measured"
        else -> status
    }
}

private fun localCrankStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "Normal" -> "Normal"
        "Hafif uzun" -> "Slightly long"
        "Geç marş" -> "Long crank"
        "Belirgin geç marş" -> "Very long crank"
        "Tamamlanamadı" -> "Incomplete"
        else -> status
    }
}

private fun localCrankComment(result: CrankAnalysisResult, language: AppLanguage): String {
    if (language != AppLanguage.English) return result.comment
    return when (result.status) {
        "Normal" -> "Cranking duration looks normal. Battery voltage and RPM response are within an acceptable range."
        "Hafif uzun" -> "Cranking is slightly long. Monitor it if it repeats."
        "Geç marş" -> "Cranking is long. Battery, fuel line, crank/cam signal and glow-plug system can be checked."
        "Belirgin geç marş" -> "A very long crank was detected. Battery/ground, starter load, fuel pressure and sensor sync should be checked."
        else -> "Cranking analysis could not be completed; OBD response or RPM data may have been interrupted."
    } + if (result.obdGapDetected) " A short OBD response gap was seen during cranking." else ""
}

@Composable
private fun TechnicalPage(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastLog: () -> Unit,
    onClearAllLogs: () -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Teknik Veriler", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("Gelişmiş canlı değerler; ham ECU paketleri geliştirici ham loguna taşındı", color = palette.textSecondary, fontSize = 13.sp)
        }
        item { TechnicalConnectionStatus(palette, snapshot, obdState) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "RPM", snapshot.rpm?.toString() ?: "--", "d/dk", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Hız", snapshot.speedKmh?.toString() ?: "--", "km/h", icon = CardIcon.Speed, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Hararet / Fan", snapshot.engineTempC?.toString() ?: "--", "°C", subtitle = "Fan: test bekliyor", icon = CardIcon.TemperatureFan, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Klima", when (snapshot.acOn) { true -> "Açık"; false -> "Kapalı"; null -> "--" }, null, icon = CardIcon.Ac, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "L/h", if (snapshot.instantUnit == "L/h") fmt(snapshot.instantConsumption) else "--", "L/h", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "L/100", if (snapshot.instantUnit != "L/h") fmt(snapshot.instantConsumption) else "--", "L/100", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Yakıt Hesabı", fuelSourceLabel(snapshot.fuelSource), null, icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Pedal", snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "MAP", snapshot.mapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Rail", snapshot.railBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.FuelPressure, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Rail Hedef", snapshot.railTargetBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.FuelPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Hava Yükü", snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Hedef MAP", snapshot.requestedMapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Emme", snapshot.intakeTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.IntakeAirTemp, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Yakıt Isı", snapshot.fuelTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.Temperature, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Sensör V", snapshot.sensorSupplyV?.let { String.format(Locale.US, "%.3f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Adaptör V", snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "V", icon = CardIcon.ObdConnection, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        if (settings.developerModeEnabled) {
            item { FuelTruthTestPanel(palette, snapshot) }
        }
        item { TechnicalQualityPanel(palette, obdState) }
    }
}


@Composable
private fun TechnicalConnectionStatus(palette: LoganPalette, snapshot: DashboardSnapshot, obdState: ObdState) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("BAĞLANTI DURUMU", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette = palette,
                    label = "OBD",
                    value = if (snapshot.connected || obdState.connected) "Bağlı" else if (obdState.connecting) "Bağlanıyor" else "Bekliyor",
                    color = if (snapshot.connected || obdState.connected) palette.accent else palette.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette = palette,
                    label = "ECU",
                    value = "DCM1.2",
                    color = palette.warning,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Protokol", "KWP Fast Init", palette.blue, Modifier.weight(1f))
                TechnicalStatusItem(palette, "Loop", obdState.timingText.ifBlank { "--" }, palette.accent, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "NO DATA", obdState.noDataCount.toString(), if (obdState.noDataCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
                TechnicalStatusItem(palette, "STOPPED", obdState.stoppedCount.toString(), if (obdState.stoppedCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Text(
                if (obdState.lastError != null) "Son hata: ${obdState.lastError}" else "Bağlantı yönetimi: Ayarlar > Bağlantı & Veri",
                color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                fontSize = 11.sp,
                fontWeight = if (obdState.lastError != null) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TechnicalStatusItem(
    palette: LoganPalette,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceVariant.copy(alpha = .34f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(value, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
fun ObdConnectionPanel(
    palette: LoganPalette,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastLog: () -> Unit = {},
    onClearAllLogs: () -> Unit = {},
    language: AppLanguage = AppLanguage.Turkish
) {
    var confirmTitle by remember { mutableStateOf<String?>(null) }
    var confirmMessage by remember { mutableStateOf("") }
    var confirmLabel by remember { mutableStateOf("Tamam") }
    var confirmAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun l(tr: String, en: String): String = if (language == AppLanguage.English) en else tr

    fun ask(title: String, message: String, label: String, action: () -> Unit) {
        confirmTitle = title
        confirmMessage = message
        confirmLabel = label
        confirmAction = action
    }

    val selectedDevice = obdState.pairedDevices.firstOrNull { it.address == obdState.selectedAddress }
    var showDeviceList by remember { mutableStateOf(obdState.selectedAddress.isNullOrBlank()) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l("OBD BAĞLANTISI", "OBD CONNECTION"), color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    TechnicalStatusItem(
                        palette = palette,
                        label = l("Durum", "Status"),
                        value = if (obdState.connected) l("Bağlı", "Connected") else if (obdState.connecting) l("Bağlanıyor", "Connecting") else l("Bekliyor", "Waiting"),
                        color = if (obdState.lastError != null) palette.critical else if (obdState.connected) palette.accent else palette.textSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    TechnicalStatusItem(
                        palette = palette,
                        label = l("Adaptör", "Adapter"),
                        value = selectedDevice?.name ?: obdState.selectedName ?: l("Seçilmedi", "Not selected"),
                        color = palette.textSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    obdState.status,
                    color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )

                if (obdState.pairedDevices.isEmpty()) {
                    Text(
                        l("Eşleşmiş cihaz yok. Önce Android Bluetooth ayarlarından vLinker MC+ ile eşleştir.", "No paired device. Pair with vLinker MC+ from Android Bluetooth settings first."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(l("Adaptör seçimi", "Adapter selection"), color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        TextButton(onClick = { showDeviceList = !showDeviceList }) {
                            Text(if (showDeviceList) l("Listeyi Gizle", "Hide List") else l("Cihaz Seç", "Choose Device"), color = palette.accent)
                        }
                    }
                    if (showDeviceList) {
                        obdState.pairedDevices.forEach { device ->
                            val selected = obdState.selectedAddress == device.address
                            SettingsRow(
                                palette = palette,
                                title = device.name,
                                subtitle = device.address,
                                value = if (selected) l("Seçili", "Selected") else l("Seç", "Select"),
                                onClick = {
                                    onSelect(device)
                                    showDeviceList = false
                                    onConnect()
                                }
                            )
                        }
                    } else if (selectedDevice != null) {
                        Text(
                            l("Seçili cihaz: ${selectedDevice.name}. Yeni seçim için 'Cihaz Seç' butonunu kullan.", "Selected device: ${selectedDevice.name}. Use the 'Choose Device' button for a new selection."),
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Button(
                    onClick = onRefresh,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                ) { Text(l("Cihazları Tara", "Scan Devices")) }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onConnect,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) { Text(if (obdState.connecting) l("Bağlanıyor...", "Connecting...") else if (obdState.connected) l("Yeniden Bağlan", "Reconnect") else l("OBD’ye Bağlan", "Connect OBD")) }
                    Button(
                        onClick = onDisconnect,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.critical)
                    ) { Text(l("Bağlantıyı Kes", "Disconnect")) }
                }
            }
        }

        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l("LOG & DESTEK", "LOG & SUPPORT"), color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                SettingsRow(
                    palette = palette,
                    title = l("Son Sürüş/Test Kaydını Dışa Aktar", "Export Last Drive/Test Record"),
                    subtitle = l("Son kayıtlı sürüş veya test verisini Download/LoganOS klasörüne aktarır", "Exports the last recorded drive or test data to Download/LoganOS"),
                    onClick = { ask(l("Son Sürüş/Test Kaydını Dışa Aktar", "Export Last Drive/Test Record"), l("Son kayıtlı sürüş veya test verisi Download/LoganOS klasörüne dışa aktarılacak. Devam edilsin mi?", "The last recorded drive or test data will be exported to Download/LoganOS. Continue?"), l("Dışa Aktar", "Export")) { onSaveLog() } }
                )
                SettingsRow(
                    palette = palette,
                    title = l("Tüm Kayıtları ve Logları Temizle", "Clear All Records and Logs"),
                    subtitle = l("Sürüş/test geçmişini, SQL kayıtlarını ve Download/LoganOS loglarını siler", "Deletes drive/test history, SQL records and Download/LoganOS logs"),
                    onClick = { ask(l("Tüm Kayıtları ve Logları Temizle", "Clear All Records and Logs"), l("Tüm sürüş ve test geçmişi, ilişkili SQL örnekleri ve LoganOS dışa aktarım logları kalıcı olarak silinecek. Bu işlem geri alınamaz.", "All drive and test history, related SQL samples and LoganOS export logs will be permanently deleted. This cannot be undone."), l("Tümünü Sil", "Delete All")) { onClearAllLogs() } }
                )
                SettingsRow(
                    palette = palette,
                    title = l("Destek Paketi Oluştur", "Create Support Package"),
                    subtitle = l("Sorun analizi için özet log ve durum bilgisini hazırlar", "Prepares summary log and status information for troubleshooting"),
                    onClick = { ask(l("Destek Paketi Oluştur", "Create Support Package"), l("Özet log, ham OBD logu ve durum bilgisi tek ZIP içinde hazırlanacak. Oluşturulsun mu?", "Summary log, raw OBD log and status information will be prepared in one ZIP. Create it?"), l("Oluştur", "Create")) { onCreateSupportPackage() } }
                )
                if (obdState.savedLogPath != null) Text(l("Son log", "Last log") + ": ${obdState.savedLogPath}", color = palette.textSecondary, fontSize = 11.sp, maxLines = 2)
            }
        }
    }

    confirmTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { confirmTitle = null; confirmAction = null },
            title = { Text(title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(confirmMessage, color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmAction?.invoke()
                    confirmTitle = null
                    confirmAction = null
                }) { Text(confirmLabel) }
            },
            dismissButton = { TextButton(onClick = { confirmTitle = null; confirmAction = null }) { Text(l("İptal", "Cancel")) } }
        )
    }
}

@Composable
private fun FuelTruthTestPanel(palette: LoganPalette, snapshot: DashboardSnapshot) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Fuel Truth Test Panel", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Hesap: ${fuelSourceLabel(snapshot.fuelSource)} • FuelAlgorithmV3 aktif", color = palette.textSecondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Enjeksiyon", snapshot.injectionMg?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "mg/st", icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(92.dp))
                DataCard(palette, "Tüketim", fmt(snapshot.instantConsumption), snapshot.instantUnit, accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(92.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Pedal", snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(92.dp))
                DataCard(palette, "Hava", snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(92.dp))
            }
            Text("Fuel Truth + Smart Trip + SQL kayıt aktif.", color = palette.textSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TechnicalQualityPanel(palette: LoganPalette, obdState: ObdState) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("VERİ KALİTESİ", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Loop", obdState.loopCount.toString(), palette.accent, Modifier.weight(1f))
                TechnicalStatusItem(palette, ">1 sn", obdState.slowLoopCount.toString(), if (obdState.slowLoopCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "BUS INIT", obdState.busInitCount.toString(), if (obdState.busInitCount == 0) palette.accent else palette.critical, Modifier.weight(1f))
                TechnicalStatusItem(palette, "Ham Log", if (obdState.rawEcuLogEnabled) "Açık" else "Kapalı", if (obdState.rawEcuLogEnabled) palette.warning else palette.textSecondary, Modifier.weight(1f))
            }
            Text("Ham ECU paketleri normal ekranda gösterilmez; yalnızca Geliştirici Ham Log açıkken exporta eklenir.", color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun InfoPage(palette: LoganPalette, title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

private fun fmt(value: Double?, suffix: String? = null): String {
    val base = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"
    return if (suffix == null) base else "$base $suffix"
}


private fun fuelSourceLabel(source: String): String = when (source.uppercase(Locale.US)) {
    "INJECTION" -> "Enjeksiyon"
    "CUTOFF" -> "Yakıt kesme"
    "HOLD" -> "Son veri"
    "MAF_FALLBACK" -> "Hava yedek"
    "MAP_FALLBACK" -> "Basınç yedek"
    "CRANK_GUARD" -> "Krank koruma"
    "NONE" -> "Hesap yok"
    "DEMO" -> "Demo"
    else -> if (source.isBlank()) "Bekleniyor" else source
}
