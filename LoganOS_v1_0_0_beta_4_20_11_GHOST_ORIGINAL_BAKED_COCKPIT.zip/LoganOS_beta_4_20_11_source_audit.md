# LoganOS beta.4.20.11 — Source Audit

## Scope
Targeted rebuild of Ghost Single Original and its Double-mode surface. Digital V2 baked scenes were intentionally left unchanged.

## Verified design constraints
- One fixed Logan III launch-red vehicle is baked into all Ghost Original assets.
- Exactly five shared light-colour assets: blue, purple, yellow, red, green.
- Same 1672×941 asset geometry is shared by phone-landscape and Double; no runtime stretching/cropping is used.
- Center speed remains live Compose text.
- Tachometer is fixed 0–7 (7000 rpm); live RPM is a progress arc, with 6000–7000 redline.
- Left live fields: coolant and A/C.
- Right live fields: average consumption above, instant consumption below.
- Existing cockpit icon assets are reused for coolant, A/C, average and instant consumption.
- Double-only tabs: Vehicle, Music, Navigation.
- Music remains in LoganOS and uses the existing MediaSessionBridge.
- Navigation shows only actual Google Maps/Waze notification content when available.

## Removed legacy implementation
The old `ui/cockpit/ghost` procedural Original renderer package and its Original-only scene/shell/road/shadow resources were removed to avoid duplicate render paths and asset conflicts.

## Validation
- `tools/validate_release.py`: expected to verify 48 Digital V2 baked assets + 5 Ghost Original baked assets + no legacy resources.
- `tools/preflight_source.py`: validates all Kotlin `R.drawable` references and resource consistency.
- Local Gradle compilation is unavailable in this environment because the source package intentionally contains no Gradle wrapper and system Gradle is not installed. GitHub Actions installs Gradle 8.10.2 before `testDebugUnitTest assembleDebug`.
