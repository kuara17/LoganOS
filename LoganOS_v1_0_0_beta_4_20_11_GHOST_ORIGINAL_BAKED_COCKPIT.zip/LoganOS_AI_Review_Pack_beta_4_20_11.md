# LoganOS AI Review Pack — beta.4.20.11

## Review target
Ghost Original was rebuilt from a procedural renderer into a shared baked-asset cockpit for phone-landscape and Double.

## Architecture
- Visual scene: one of five full-frame WebP assets (1672×941), selected by `GhostOriginalAccent`.
- Live layer: Compose text/icons + RPM progress arc.
- Double-only interaction: Vehicle / Music / Navigation tabs.
- Media: existing `MediaSessionBridge`, refreshed every 750 ms while the Music tab is active.
- Navigation: read-only Google Maps/Waze notification content via the existing notification-listener permission. No fabricated route data.

## Critical decisions
1. Fixed Logan III launch-red car is baked; vehicle appearance setting is not shown for Ghost Original.
2. RPM max is hard-fixed to 7000 for this visual. 6000–7000 remains redline.
3. Same five assets are shared by phone and Double to minimize APK/source size and eliminate geometry drift.
4. Legacy Ghost Original renderer/assets are removed rather than left dormant.
5. Legacy `GaugeStyle.GhostDualOriginal` stays loadable only for backup/settings compatibility, but is hidden from new selections and routes to the same new surface.

## Files to inspect
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostOriginalBakedCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostDualOriginalCockpit.kt`
- `app/src/main/java/com/dcui/loganos/media/LoganMediaNotificationListener.kt`
- `app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt`
- `tools/validate_release.py`

## Questions for reviewer
- Are the absolute 1672×941 overlay coordinates safe under the Fit-only viewport on both 19.5:9 phones and 16:9 Double units?
- Is the Compose RPM arc aligned closely enough with the baked 0–7 tick shell, especially at 0 and 7 endpoints?
- Are notification-listener reads safe when the service is disconnected/reconnected?
- Any recomposition/lifecycle issue in the 750 ms MediaSession and 1 s navigation polling loops?
