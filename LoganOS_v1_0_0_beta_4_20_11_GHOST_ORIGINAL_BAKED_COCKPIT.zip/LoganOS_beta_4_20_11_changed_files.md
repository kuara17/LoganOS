# LoganOS beta.4.20.11 — Changed Files

## Core UI
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostOriginalBakedCockpit.kt`
  - New shared baked Ghost Original renderer.
  - Phone-landscape vehicle surface.
  - Double-only Vehicle / Music / Navigation tabs.
  - Live speed, 0–7000 RPM progress arc, coolant, A/C, average and instant consumption overlays.
  - MediaSession card and read-only navigation-notification card.
- `GhostSingleOriginalCockpit.kt`
  - Replaced old GhostSceneRenderer with shared baked renderer.
- `GhostDualOriginalCockpit.kt`
  - Backward-compatible legacy style now routes to the same shared baked renderer with Double tabs.
- `DashboardScreen.kt`
  - Resolves Double mode and enables tabs only on head-unit surfaces.
- `SettingsScreen.kt`
  - Adds/renames `Gösterge Işık Rengi` selector with five approved colours.
  - Hides obsolete Ghost Dual Original from new style selection while keeping backup compatibility.
  - Hides vehicle appearance selector for baked Original because its Logan III launch-red car is fixed.

## Media / navigation
- `LoganMediaNotificationListener.kt`
  - Exposes active-notification snapshot for read-only Maps/Waze navigation card.
- `AndroidManifest.xml`
  - Adds Google Maps and Waze package visibility entries.

## Assets
Added shared WebP assets:
- `ghost_original_baked_blue.webp`
- `ghost_original_baked_purple.webp`
- `ghost_original_baked_yellow.webp`
- `ghost_original_baked_red.webp`
- `ghost_original_baked_green.webp`

Removed obsolete Ghost Original scene/shell/road/shadow assets. `ghost_single_original_preview.webp` now uses the new blue baked scene.

## Release tooling
- `tools/validate_release.py`
  - Verifies the exact five baked Ghost Original assets and rejects legacy Ghost Original resources.
