package com.dcui.loganos.ui.cockpit

import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.PlaybackState
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.media.LoganMediaState
import com.dcui.loganos.media.MediaSessionBridge
import com.dcui.loganos.media.PACKAGE_JANCAR_RADIO
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DefaultMediaApp
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdConnectionHealth
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.acAccentColor
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.components.rememberRoadPhase
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val PremiumBackground = Color(0xFF050A12)
private val PremiumSurface = Color(0xEC101A29)
private val PremiumSurfaceStrong = Color(0xF20B1422)
private val PremiumSurfaceSoft = Color(0xD318273B)
private val PremiumLine = Color(0xFF2B405C)
private val PremiumText = Color(0xFFF5F8FC)
private val PremiumMuted = Color(0xFF95A9C0)
private val PremiumBlue = Color(0xFF5BB7FF)
private val PremiumCyan = Color(0xFF7FE7FF)
private val PremiumGreen = Color(0xFF5FE18A)
private val PremiumPink = Color(0xFFFF76C8)
private val PremiumAmber = Color(0xFFFFBD5B)

private enum class PremiumMediaMode {
    Player,
    Radio
}

private data class PremiumMediaLaunchRequest(
    val packageName: String,
    val nonce: Long
)

@Composable
fun PremiumDriveCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val context = LocalContext.current
    val selectedPackage = settings.defaultMediaApp.packageName
    var media by remember(selectedPackage) {
        mutableStateOf(MediaSessionBridge.read(context, selectedPackage))
    }
    var mediaMode by remember { mutableStateOf(PremiumMediaMode.Player) }
    var mediaLaunchRequest by remember { mutableStateOf<PremiumMediaLaunchRequest?>(null) }
    var clockMs by remember { mutableStateOf(System.currentTimeMillis()) }

    LaunchedEffect(selectedPackage) {
        mediaMode = PremiumMediaMode.Player
        while (true) {
            media = MediaSessionBridge.read(context, selectedPackage)
            delay(1_000)
        }
    }
    LaunchedEffect(mediaLaunchRequest) {
        val request = mediaLaunchRequest ?: return@LaunchedEffect
        // Launch after the selected-source state is committed. This keeps the
        // first tap reliable even when the already-selected AIMP pill is used.
        delay(60)
        MediaSessionBridge.launchPackage(context, request.packageName)
        mediaLaunchRequest = null
    }
    LaunchedEffect(Unit) {
        while (true) {
            clockMs = System.currentTimeMillis()
            delay(30_000)
        }
    }

    val fuelTrusted = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    )
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = "average"
    )
    val coolantColor = coolantAccentColor(palette, snapshot.engineTempC)
    val acColor = acAccentColor(palette, snapshot.acOn)

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(PremiumBackground)
    ) {
        val wideHeadUnit = settings.deviceMode == DeviceMode.HeadUnit || maxWidth.value >= maxHeight.value * 1.55f
        val scale = if (wideHeadUnit) {
            (maxHeight.value / 500f).coerceIn(0.95f, 1.12f)
        } else {
            (maxHeight.value / 560f).coerceIn(0.78f, 1.10f)
        }
        val gap = (8f * scale).dp
        val outerH = (10f * scale).dp
        val outerV = (5f * scale).dp
        val bottomCardHeight = (104f * scale).dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = outerH, vertical = outerV),
            verticalArrangement = Arrangement.spacedBy(gap)
        ) {
            PremiumHeader(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                clockMs = clockMs,
                scale = scale,
                onOpenReset = onOpenReset,
                onObdClick = onObdClick
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                PremiumTripSummary(
                    settings = settings,
                    snapshot = snapshot,
                    scale = scale,
                    modifier = Modifier
                        .weight(0.70f)
                        .fillMaxHeight()
                )

                PremiumRoadScene(
                    settings = settings,
                    snapshot = snapshot,
                    motionEnabled = !wideHeadUnit && (snapshot.connected || obdState.connected || settings.demoMode),
                    scale = scale,
                    modifier = Modifier
                        .weight(1.58f)
                        .fillMaxHeight()
                )

                PremiumMediaCard(
                    context = context,
                    settings = settings,
                    media = media,
                    mode = mediaMode,
                    scale = scale,
                    onPlayerMode = {
                        mediaMode = PremiumMediaMode.Player
                        mediaLaunchRequest = PremiumMediaLaunchRequest(selectedPackage, System.nanoTime())
                    },
                    onRadioMode = {
                        mediaMode = PremiumMediaMode.Radio
                        mediaLaunchRequest = PremiumMediaLaunchRequest(PACKAGE_JANCAR_RADIO, System.nanoTime())
                    },
                    modifier = Modifier
                        .weight(0.94f)
                        .fillMaxHeight()
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(bottomCardHeight),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                PremiumConsumptionMetric(
                    iconRes = R.drawable.cockpit_fuel_instant,
                    title = tr(settings, "Anlık Tüketim", "Instant Consumption"),
                    value = if (fuelTrusted) formatOne(snapshot.instantConsumption) else "--",
                    unit = if (fuelTrusted) snapshot.instantUnit else tr(settings, "Doğrulanmadı", "Not verified"),
                    accent = PremiumBlue,
                    trend = instantTrend.takeLast(14),
                    scale = scale,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                PremiumConsumptionMetric(
                    iconRes = R.drawable.cockpit_fuel_average,
                    title = tr(settings, "Ortalama Tüketim", "Average Consumption"),
                    value = if (fuelTrusted) formatOne(snapshot.averageConsumption) else "--",
                    unit = if (fuelTrusted) "L/100 km" else tr(settings, "Doğrulanmadı", "Not verified"),
                    accent = PremiumGreen,
                    trend = averageTrend.takeLast(14),
                    scale = scale,
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
                PremiumCoolantMetric(
                    settings = settings,
                    temperatureC = snapshot.engineTempC,
                    accent = coolantColor,
                    scale = scale,
                    modifier = Modifier.weight(0.96f).fillMaxHeight()
                )
                PremiumAcMetric(
                    settings = settings,
                    acOn = snapshot.acOn,
                    accent = acColor,
                    scale = scale,
                    modifier = Modifier.weight(0.78f).fillMaxHeight()
                )
            }
        }
    }
}

@Composable
private fun PremiumHeader(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    clockMs: Long,
    scale: Float,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val connected = snapshot.connected || obdState.connected
    val statusColor = when {
        settings.demoMode -> PremiumAmber
        obdState.connectionHealth == ObdConnectionHealth.DATA_STALE -> PremiumAmber
        obdState.connectionHealth == ObdConnectionHealth.UNSTABLE -> PremiumAmber
        obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> PremiumAmber
        connected -> PremiumGreen
        obdState.connecting -> PremiumAmber
        else -> PremiumMuted
    }
    val status = when {
        settings.demoMode -> "DEMO"
        obdState.connectionHealth == ObdConnectionHealth.DATA_STALE -> tr(settings, "VERİ BEKLENİYOR", "WAITING DATA")
        obdState.connectionHealth == ObdConnectionHealth.UNSTABLE -> tr(settings, "KARARSIZ", "UNSTABLE")
        obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> tr(settings, "YENİDEN", "RECONNECT")
        connected -> tr(settings, "OBD BAĞLI", "OBD ON")
        obdState.connecting -> tr(settings, "BAĞLANIYOR", "CONNECTING")
        else -> tr(settings, "OBD BEK.", "OBD WAIT")
    }
    val time = remember(clockMs) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(clockMs)) }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height((38f * scale).dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LoganWordmark(palette.copy(textPrimary = PremiumText), compact = true)
        Spacer(Modifier.width((10f * scale).dp))
        Text(
            "PREMIUM DRIVE",
            color = PremiumCyan,
            fontSize = (15.5f * scale).sp,
            fontWeight = FontWeight.Black
        )
        Spacer(Modifier.weight(1f))
        Text(time, color = PremiumText, fontSize = (22f * scale).sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.width((10f * scale).dp))
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(statusColor.copy(alpha = .14f))
                .border(1.dp, statusColor.copy(alpha = .42f), RoundedCornerShape(99.dp))
                .clickable(onClick = onObdClick)
                .padding(horizontal = (9f * scale).dp, vertical = (5f * scale).dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((5f * scale).dp)
        ) {
            Box(Modifier.size((6f * scale).dp).clip(CircleShape).background(statusColor))
            Text(status, color = statusColor, fontSize = (10.5f * scale).sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width((6f * scale).dp))
        Box(
            modifier = Modifier
                .size((30f * scale).dp)
                .clip(CircleShape)
                .background(PremiumSurfaceSoft)
                .border(1.dp, PremiumLine.copy(alpha = .7f), CircleShape)
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = PremiumText, fontSize = (18f * scale).sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun PremiumTripSummary(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    scale: Float,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = premiumCard(modifier, radius = 21f * scale)
            .padding(horizontal = (12f * scale).dp, vertical = (12f * scale).dp),
        verticalArrangement = Arrangement.spacedBy((8f * scale).dp)
    ) {
        Text(
            tr(settings, "SÜRÜŞ ÖZETİ", "DRIVE SUMMARY"),
            color = PremiumCyan,
            fontSize = (15.5f * scale).sp,
            fontWeight = FontWeight.Black
        )
        PremiumSummaryItem(
            iconRes = R.drawable.cockpit_distance,
            value = snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.1f km", it) } ?: "-- km",
            label = tr(settings, "Mesafe", "Distance"),
            accent = PremiumCyan,
            scale = scale,
            modifier = Modifier.weight(1f)
        )
        PremiumSummaryItem(
            iconRes = R.drawable.cockpit_trip_time,
            value = snapshot.tripDurationText ?: "--:--",
            label = tr(settings, "Süre", "Duration"),
            accent = PremiumBlue,
            scale = scale,
            modifier = Modifier.weight(1f)
        )
        PremiumSummaryItem(
            iconRes = R.drawable.cockpit_trip_cost,
            value = snapshot.tripCostText ?: "-- ₺",
            label = tr(settings, "Maliyet", "Cost"),
            accent = PremiumAmber,
            scale = scale,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun PremiumSummaryItem(
    iconRes: Int,
    value: String,
    label: String,
    accent: Color,
    scale: Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape((15f * scale).dp))
            .background(PremiumSurfaceSoft)
            .border(1.dp, PremiumLine.copy(alpha = .55f), RoundedCornerShape((15f * scale).dp))
            .padding(horizontal = (9f * scale).dp, vertical = (7f * scale).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((8f * scale).dp)
    ) {
        Image(
            painter = painterResource(iconRes),
            contentDescription = null,
            modifier = Modifier.size((27f * scale).dp),
            contentScale = ContentScale.Fit
        )
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                value,
                color = PremiumText,
                fontSize = (24f * scale).sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                label.uppercase(),
                color = accent,
                fontSize = (16f * scale).sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun PremiumMediaCard(
    context: Context,
    settings: LoganSettings,
    media: LoganMediaState,
    mode: PremiumMediaMode,
    scale: Float,
    onPlayerMode: () -> Unit,
    onRadioMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    val selectedApp = settings.defaultMediaApp
    val installed = MediaSessionBridge.isInstalled(context, selectedApp.packageName)
    val radioInstalled = MediaSessionBridge.isInstalled(context, PACKAGE_JANCAR_RADIO)
    val artwork = media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        ?: media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
    val playing = media.playbackState == PlaybackState.STATE_PLAYING
    val hasMetadata = media.hasUsableMetadata
    val progress = if (media.durationMs > 0L) {
        (media.positionMs.toFloat() / media.durationMs.toFloat()).coerceIn(0f, 1f)
    } else 0f

    Column(
        modifier = premiumCard(modifier, radius = 21f * scale)
            .padding((11f * scale).dp),
        verticalArrangement = Arrangement.spacedBy((7f * scale).dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((6f * scale).dp)
        ) {
            SourcePill(
                text = if (selectedApp == DefaultMediaApp.Aimp) "AIMP" else "JANCAR",
                selected = mode == PremiumMediaMode.Player,
                enabled = installed,
                accent = PremiumCyan,
                scale = scale,
                onClick = onPlayerMode,
                modifier = Modifier.weight(1f)
            )
            SourcePill(
                text = tr(settings, "RADYO", "RADIO"),
                selected = mode == PremiumMediaMode.Radio,
                enabled = radioInstalled,
                accent = PremiumPink,
                scale = scale,
                onClick = onRadioMode,
                modifier = Modifier.weight(1f)
            )
        }

        if (mode == PremiumMediaMode.Radio) {
            PremiumRadioPanel(
                settings = settings,
                installed = radioInstalled,
                scale = scale,
                onOpenRadio = onRadioMode,
                modifier = Modifier.weight(1f)
            )
        } else {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(0.56f)
                    .clip(RoundedCornerShape((16f * scale).dp))
                    .background(PremiumSurfaceSoft),
                contentAlignment = Alignment.Center
            ) {
                if (artwork != null) {
                    Image(
                        bitmap = artwork.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                    Box(
                        Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    listOf(Color.Transparent, Color(0xE0050A12))
                                )
                            )
                    )
                } else {
                    Image(
                        painter = painterResource(R.drawable.ic_premium_music_note),
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.size((46f * scale).dp)
                    )
                }
                val helper = when {
                    !installed -> tr(settings, "Uygulama yüklü değil", "App not installed")
                    !media.notificationAccess -> tr(settings, "Medya erişimi kapalı", "Media access is off")
                    !hasMetadata && selectedApp == DefaultMediaApp.JancarMusic -> tr(settings, "Jancar Music'i aç", "Open Jancar Music")
                    !hasMetadata -> tr(settings, "AIMP'de bir parça başlatın", "Start a track in AIMP")
                    else -> ""
                }
                if (helper.isNotBlank()) {
                    Text(
                        helper,
                        color = PremiumText,
                        fontSize = (15.5f * scale).sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding((9f * scale).dp)
                    )
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy((2f * scale).dp)) {
                Text(
                    media.title ?: if (selectedApp == DefaultMediaApp.Aimp) "AIMP" else "Jancar Music",
                    color = PremiumText,
                    fontSize = (20f * scale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    media.artist ?: tr(settings, "Medya bilgisi bekleniyor", "Waiting for media information"),
                    color = PremiumMuted,
                    fontSize = (13.5f * scale).sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((4f * scale).dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(PremiumLine)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxHeight()
                        .background(PremiumBlue)
                )
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatMediaTime(media.positionMs), color = PremiumMuted, fontSize = (11.5f * scale).sp)
                Text(formatMediaTime(media.durationMs), color = PremiumMuted, fontSize = (11.5f * scale).sp)
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                MediaControlButton("|◀", enabled = installed, scale = scale) { MediaSessionBridge.previous(context, media) }
                MediaControlButton(if (playing) "Ⅱ" else "▶", prominent = true, enabled = installed, scale = scale) {
                    MediaSessionBridge.playPause(context, media)
                }
                MediaControlButton("▶|", enabled = installed, scale = scale) { MediaSessionBridge.next(context, media) }
            }

            if (!media.notificationAccess) {
                TextButton(
                    modifier = Modifier.fillMaxWidth(),
                    onClick = {
                        context.startActivity(
                            Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                ) {
                    Text(
                        tr(settings, "Medya erişimini aç", "Enable media access"),
                        color = PremiumCyan,
                        fontSize = (13.5f * scale).sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SourcePill(
    text: String,
    selected: Boolean,
    enabled: Boolean,
    accent: Color,
    scale: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(99.dp))
            .background(if (selected) accent.copy(alpha = .18f) else PremiumSurfaceSoft)
            .border(1.dp, if (selected) accent.copy(alpha = .75f) else PremiumLine, RoundedCornerShape(99.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = (9f * scale).dp, vertical = (7f * scale).dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = when {
                !enabled -> PremiumMuted.copy(alpha = .45f)
                selected -> accent
                else -> PremiumMuted
            },
            fontSize = (17f * scale).sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun PremiumRadioPanel(
    settings: LoganSettings,
    installed: Boolean,
    scale: Float,
    onOpenRadio: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape((17f * scale).dp))
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF24152F), Color(0xFF101827), Color(0xFF0A111E))
                )
            )
            .border(1.dp, PremiumPink.copy(alpha = .42f), RoundedCornerShape((17f * scale).dp))
            .clickable(enabled = installed, onClick = onOpenRadio)
            .padding((12f * scale).dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("FM", color = PremiumPink, fontSize = (38f * scale).sp, fontWeight = FontWeight.Light)
        Text("JANCAR RADIO", color = PremiumText, fontSize = (18f * scale).sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height((5f * scale).dp))
        Text(
            if (installed) {
                tr(settings, "Frekans ve istasyon kontrolü radyo uygulamasında", "Frequency and station controls are in the radio app")
            } else {
                tr(settings, "Radyo uygulaması yüklü değil", "Radio app is not installed")
            },
            color = PremiumMuted,
            fontSize = (13f * scale).sp,
            textAlign = TextAlign.Center,
            lineHeight = (16f * scale).sp
        )
        Spacer(Modifier.height((8f * scale).dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(PremiumPink.copy(alpha = if (installed) .18f else .07f))
                .border(1.dp, PremiumPink.copy(alpha = if (installed) .70f else .20f), RoundedCornerShape(99.dp))
                .padding(horizontal = (12f * scale).dp, vertical = (6f * scale).dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                tr(settings, "RADYOYU AÇ", "OPEN RADIO"),
                color = if (installed) PremiumPink else PremiumMuted.copy(alpha = .45f),
                fontSize = (14f * scale).sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun MediaControlButton(
    text: String,
    prominent: Boolean = false,
    enabled: Boolean,
    scale: Float,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size((if (prominent) 43f else 34f).times(scale).dp)
            .clip(CircleShape)
            .background(if (prominent) PremiumBlue else PremiumSurfaceSoft)
            .border(1.dp, if (prominent) PremiumCyan.copy(alpha = .7f) else PremiumLine, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (enabled) PremiumText else PremiumMuted.copy(alpha = .5f),
            fontSize = ((if (prominent) 16f else 11f) * scale).sp,
            fontWeight = FontWeight.Black
        )
    }
}

@Composable
private fun PremiumRoadScene(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    motionEnabled: Boolean,
    scale: Float,
    modifier: Modifier = Modifier
) {
    val speed = snapshot.speedKmh ?: 0
    val phase = rememberRoadPhase(snapshot.speedKmh, enabled = motionEnabled)
    val moving = speed > 0 && motionEnabled
    val flowPrimary = phase
    val flowSecondary = (phase + 0.5f) % 1f

    BoxWithConstraints(
        modifier = modifier
            .clip(RoundedCornerShape((22f * scale).dp))
            .background(PremiumSurfaceStrong)
            .border(1.dp, PremiumLine.copy(alpha = .80f), RoundedCornerShape((22f * scale).dp))
    ) {
        Image(
            painter = painterResource(R.drawable.premium_drive_road_base),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )

        // The old cyan/pink streak assets and Canvas lane lines were removed.
        // Two softly cross-faded road-surface layers now expand toward the viewer.
        // Their reset points are fully transparent, so the loop does not flash or jump.
        if (moving) {
            PremiumRoadFlowLayer(progress = flowPrimary)
            PremiumRoadFlowLayer(progress = flowSecondary)
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        0.0f to Color(0xA9050A12),
                        0.24f to Color.Transparent,
                        0.78f to Color.Transparent,
                        1.0f to Color(0xB8050A12)
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = (8f * scale).dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                snapshot.speedKmh?.toString() ?: "--",
                color = PremiumText,
                fontSize = (64f * scale).sp,
                lineHeight = (60f * scale).sp,
                fontWeight = FontWeight.Light
            )
            Text("km/h", color = PremiumMuted, fontSize = (13f * scale).sp, fontWeight = FontWeight.Bold)
        }

        Image(
            painter = painterResource(R.drawable.premium_drive_vehicle_shadow),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.24f)
                .fillMaxHeight(0.070f)
                .offset(y = (-10f * scale).dp)
        )

        Image(
            painter = painterResource(
                vehicleVisualDrawableRes(
                    settings.vehicleVisualModel,
                    settings.vehicleColor,
                    VehicleAssetStyle.Detailed
                )
            ),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(0.30f)
                .fillMaxHeight(0.35f)
                .offset(y = (-14f * scale).dp)
        )

        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = (8f * scale).dp, bottom = (7f * scale).dp)
                .clip(RoundedCornerShape(99.dp))
                .background(Color(0xB3050A12))
                .border(1.dp, PremiumLine.copy(alpha = .55f), RoundedCornerShape(99.dp))
                .padding(horizontal = (8f * scale).dp, vertical = (4f * scale).dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy((5f * scale).dp)
        ) {
            Box(Modifier.size((5f * scale).dp).clip(CircleShape).background(if (moving) PremiumGreen else PremiumMuted))
            Text(
                if (moving) tr(settings, "HAREKET", "MOVING") else tr(settings, "DURUYOR", "STOPPED"),
                color = PremiumText,
                fontSize = (10f * scale).sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.PremiumRoadFlowLayer(progress: Float) {
    val fade = kotlin.math.sin(Math.PI * progress).toFloat()
    val layerAlpha = (fade * fade * 0.58f).coerceIn(0f, 0.58f)

    Image(
        painter = painterResource(R.drawable.premium_drive_road_flow),
        contentDescription = null,
        contentScale = ContentScale.Crop,
        modifier = Modifier
            .matchParentSize()
            .graphicsLayer {
                alpha = layerAlpha
                scaleX = 1f + progress * 0.10f
                scaleY = 1f + progress * 0.18f
                translationY = progress * 42f
            }
    )
}

@Composable
private fun PremiumConsumptionMetric(
    iconRes: Int,
    title: String,
    value: String,
    unit: String,
    accent: Color,
    trend: List<Float>,
    scale: Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = premiumCard(modifier, radius = 17f * scale)
            .padding(horizontal = (10f * scale).dp, vertical = (8f * scale).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((8f * scale).dp)
    ) {
        Image(
            painter = painterResource(iconRes),
            contentDescription = null,
            modifier = Modifier.size((32f * scale).dp),
            contentScale = ContentScale.Fit
        )
        Column(modifier = Modifier.weight(1.25f), verticalArrangement = Arrangement.Center) {
            Text(title.uppercase(), color = accent, fontSize = (15f * scale).sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = PremiumText, fontSize = (28f * scale).sp, fontWeight = FontWeight.Black, maxLines = 1)
                Spacer(Modifier.width((4f * scale).dp))
                Text(unit, color = PremiumMuted, fontSize = (12.5f * scale).sp, modifier = Modifier.padding(bottom = (3f * scale).dp), maxLines = 1)
            }
        }
        ConsumptionSparkline(
            values = trend,
            lineColor = accent,
            guideColor = PremiumLine,
            modifier = Modifier
                .weight(0.55f)
                .fillMaxHeight(0.62f)
        )
    }
}

@Composable
private fun PremiumCoolantMetric(
    settings: LoganSettings,
    temperatureC: Int?,
    accent: Color,
    scale: Float,
    modifier: Modifier = Modifier
) {
    val progress = temperatureC?.let { ((it - 40f) / 80f).coerceIn(0f, 1f) } ?: 0f
    Row(
        modifier = premiumCard(modifier, radius = 17f * scale)
            .padding(horizontal = (10f * scale).dp, vertical = (8f * scale).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((8f * scale).dp)
    ) {
        Image(
            painter = painterResource(R.drawable.cockpit_coolant),
            contentDescription = null,
            modifier = Modifier.size((29f * scale).dp),
            contentScale = ContentScale.Fit
        )
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                tr(settings, "HARARET", "COOLANT"),
                color = accent,
                fontSize = (15f * scale).sp,
                fontWeight = FontWeight.Black
            )
            Text(
                temperatureC?.let { "$it°C" } ?: "--°C",
                color = accent,
                fontSize = (27f * scale).sp,
                fontWeight = FontWeight.Black
            )
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height((5f * scale).dp)
                    .clip(RoundedCornerShape(99.dp))
                    .background(PremiumLine)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth(progress)
                        .fillMaxHeight()
                        .background(accent)
                )
            }
        }
    }
}

@Composable
private fun PremiumAcMetric(
    settings: LoganSettings,
    acOn: Boolean?,
    accent: Color,
    scale: Float,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = premiumCard(modifier, radius = 17f * scale)
            .padding(horizontal = (10f * scale).dp, vertical = (8f * scale).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy((8f * scale).dp)
    ) {
        Image(
            painter = painterResource(R.drawable.cockpit_ac),
            contentDescription = null,
            modifier = Modifier.size((31f * scale).dp),
            contentScale = ContentScale.Fit
        )
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                tr(settings, "KLİMA", "A/C"),
                color = accent,
                fontSize = (15f * scale).sp,
                fontWeight = FontWeight.Black
            )
            Text(
                acOn?.let { if (it) tr(settings, "Açık", "On") else tr(settings, "Kapalı", "Off") } ?: "--",
                color = accent,
                fontSize = (25f * scale).sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

private fun premiumCard(modifier: Modifier, radius: Float): Modifier = modifier
    .clip(RoundedCornerShape(radius.dp))
    .background(PremiumSurface)
    .border(1.dp, PremiumLine.copy(alpha = .78f), RoundedCornerShape(radius.dp))


private fun tr(settings: LoganSettings, tr: String, en: String): String =
    if (settings.language == AppLanguage.English) en else tr

private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun formatMediaTime(valueMs: Long): String {
    val seconds = valueMs.coerceAtLeast(0L) / 1_000L
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
