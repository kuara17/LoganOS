package com.dcui.loganos.ui.cockpit

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.theme.LoganPalette

/**
 * Backward-compatible renderer for users/backups that still contain
 * GaugeStyle.GhostDualOriginal. The visual surface is now the same shared baked
 * Ghost Original scene used by phone landscape and Double mode.
 */
@Composable
fun GhostDualOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostOriginalBakedCockpit(
        palette = palette,
        settings = settings,
        snapshot = snapshot,
        showHeadUnitTabs = true,
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}
