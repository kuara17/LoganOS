package com.dcui.loganos.ui.cockpit

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.media.LoganMediaNotificationListener
import com.dcui.loganos.media.LoganMediaState
import com.dcui.loganos.media.MediaSessionBridge
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.acAccentColor
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

private const val GhostOriginalDesignWidth = 1672f
private const val GhostOriginalDesignHeight = 941f
private const val GhostOriginalRpmMax = 7000f
private const val GhostOriginalRedlineStart = 6000f

private val GhostOriginalWhite = Color(0xFFF5F7FC)
private val GhostOriginalMuted = Color(0xFFB7C0CE)
private val GhostOriginalPanel = Color(0xD911151D)

enum class GhostOriginalHeadUnitTab { Vehicle, Music, Navigation }

private data class GhostOriginalTransform(
    val width: Dp,
    val height: Dp,
    val scale: Float
) {
    fun x(value: Float): Dp = width * (value / GhostOriginalDesignWidth)
    fun y(value: Float): Dp = height * (value / GhostOriginalDesignHeight)
    fun w(value: Float): Dp = width * (value / GhostOriginalDesignWidth)
    fun h(value: Float): Dp = height * (value / GhostOriginalDesignHeight)
}

@Composable
internal fun GhostOriginalBakedCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    showHeadUnitTabs: Boolean,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableStateOf(GhostOriginalHeadUnitTab.Vehicle) }
    val activeTab = if (showHeadUnitTabs) tab else GhostOriginalHeadUnitTab.Vehicle
    val accent = ghostOriginalAccentColor(settings.ghostOriginalAccent)
    val trustedFuel = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(Color.Black)) {
        val scale = min(
            maxWidth.value / GhostOriginalDesignWidth,
            maxHeight.value / GhostOriginalDesignHeight
        )
        val transform = GhostOriginalTransform(
            width = (GhostOriginalDesignWidth * scale).dp,
            height = (GhostOriginalDesignHeight * scale).dp,
            scale = scale
        )

        Box(
            modifier = Modifier
                .size(transform.width, transform.height)
                .align(Alignment.Center)
        ) {
            Image(
                painter = painterResource(ghostOriginalBackgroundRes(settings.ghostOriginalAccent)),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer(alpha = if (activeTab == GhostOriginalHeadUnitTab.Vehicle) 1f else 0.27f)
            )

            if (activeTab != GhostOriginalHeadUnitTab.Vehicle) {
                Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.38f)))
            }

            when (activeTab) {
                GhostOriginalHeadUnitTab.Vehicle -> {
                    GhostOriginalRpmProgress(
                        rpm = snapshot.rpm ?: 0,
                        accent = accent,
                        modifier = Modifier.fillMaxSize()
                    )
                    GhostOriginalVehicleOverlay(
                        palette = palette,
                        settings = settings,
                        snapshot = snapshot,
                        trustedFuel = trustedFuel,
                        transform = transform,
                        onOpenReset = onOpenReset
                    )
                }
                GhostOriginalHeadUnitTab.Music -> GhostOriginalMusicPanel(
                    settings = settings,
                    snapshot = snapshot,
                    transform = transform
                )
                GhostOriginalHeadUnitTab.Navigation -> GhostOriginalNavigationPanel(
                    snapshot = snapshot,
                    transform = transform
                )
            }

            if (showHeadUnitTabs) {
                GhostOriginalHeadUnitTabs(
                    selected = tab,
                    accent = accent,
                    transform = transform,
                    onSelect = { tab = it }
                )
            }
        }
    }
}

@Composable
private fun GhostOriginalVehicleOverlay(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    trustedFuel: Boolean,
    transform: GhostOriginalTransform,
    onOpenReset: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val coolantColor = coolantAccentColor(palette, snapshot.engineTempC)
    val acColor = acAccentColor(palette, snapshot.acOn)

    GhostOriginalMetric(
        iconRes = R.drawable.cockpit_coolant,
        label = if (tr) "HARARET" else "COOLANT",
        value = snapshot.engineTempC?.let { "$it °C" } ?: "--",
        tint = coolantColor,
        transform = transform,
        x = 82f,
        y = 300f,
        width = 280f,
        height = 170f
    )

    GhostOriginalMetric(
        iconRes = R.drawable.cockpit_ac,
        label = if (tr) "KLİMA" else "A/C",
        value = when (snapshot.acOn) {
            true -> if (tr) "AÇIK" else "ON"
            false -> if (tr) "KAPALI" else "OFF"
            null -> "--"
        },
        tint = acColor,
        transform = transform,
        x = 82f,
        y = 590f,
        width = 280f,
        height = 150f
    )

    GhostOriginalMetric(
        iconRes = R.drawable.cockpit_fuel_average,
        label = if (tr) "ORTALAMA TÜKETİM" else "AVERAGE CONSUMPTION",
        value = if (trustedFuel) formatConsumption(snapshot.averageConsumption, "L/100 km") else "--",
        tint = GhostOriginalWhite,
        transform = transform,
        x = 1285f,
        y = 300f,
        width = 315f,
        height = 175f,
        clickable = true,
        onClick = onOpenReset
    )

    GhostOriginalMetric(
        iconRes = R.drawable.cockpit_fuel_instant,
        label = if (tr) "ANLIK TÜKETİM" else "INSTANT CONSUMPTION",
        value = if (trustedFuel) formatConsumption(snapshot.instantConsumption, snapshot.instantUnit) else "--",
        tint = GhostOriginalWhite,
        transform = transform,
        x = 1285f,
        y = 590f,
        width = 315f,
        height = 175f,
        clickable = true,
        onClick = onOpenReset
    )

    Box(
        modifier = Modifier
            .offset(transform.x(674f), transform.y(242f))
            .size(transform.w(324f), transform.h(205f)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = (snapshot.speedKmh ?: 0).coerceIn(0, 200).toString(),
                color = GhostOriginalWhite,
                fontSize = (104f * transform.scale).sp,
                fontWeight = FontWeight.Light,
                lineHeight = (104f * transform.scale).sp
            )
            Text(
                text = "km/h",
                color = GhostOriginalMuted,
                fontSize = (20f * transform.scale).sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
private fun GhostOriginalMetric(
    @DrawableRes iconRes: Int,
    label: String,
    value: String,
    tint: Color,
    transform: GhostOriginalTransform,
    x: Float,
    y: Float,
    width: Float,
    height: Float,
    clickable: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .offset(transform.x(x), transform.y(y))
            .size(transform.w(width), transform.h(height))
            .then(if (clickable && onClick != null) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(transform.h(8f))
        ) {
            Image(
                painter = painterResource(iconRes),
                contentDescription = null,
                modifier = Modifier.size(transform.w(46f)),
                colorFilter = ColorFilter.tint(tint),
                contentScale = ContentScale.Fit
            )
            Text(
                text = label,
                color = GhostOriginalMuted,
                fontSize = (15f * transform.scale).sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                maxLines = 2
            )
            Text(
                text = value,
                color = GhostOriginalWhite,
                fontSize = (28f * transform.scale).sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun GhostOriginalRpmProgress(
    rpm: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val sx = size.width / GhostOriginalDesignWidth
        val sy = size.height / GhostOriginalDesignHeight
        val center = Offset(836f * sx, 397f * sy)
        val radius = 276f * sx
        val topLeft = Offset(center.x - radius, center.y - radius)
        val arcSize = Size(radius * 2f, radius * 2f)
        val startAngle = 150f
        val totalSweep = 240f
        val safeRpm = rpm.coerceIn(0, GhostOriginalRpmMax.toInt()).toFloat()
        val normalRpm = safeRpm.coerceAtMost(GhostOriginalRedlineStart)
        val normalSweep = totalSweep * (normalRpm / GhostOriginalRpmMax)
        val redSweepStart = totalSweep * (GhostOriginalRedlineStart / GhostOriginalRpmMax)
        val redSweep = if (safeRpm > GhostOriginalRedlineStart) {
            totalSweep * ((safeRpm - GhostOriginalRedlineStart) / GhostOriginalRpmMax)
        } else 0f
        val stroke = 7.5f * sx

        if (normalSweep > 0.4f) {
            drawArc(
                color = accent.copy(alpha = 0.95f),
                startAngle = startAngle,
                sweepAngle = normalSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }
        if (redSweep > 0.4f) {
            drawArc(
                color = Color(0xFFFF2424),
                startAngle = startAngle + redSweepStart,
                sweepAngle = redSweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = stroke, cap = StrokeCap.Round)
            )
        }

        if (safeRpm > 0f) {
            val angle = (startAngle + totalSweep * safeRpm / GhostOriginalRpmMax) * (PI / 180.0)
            val marker = Offset(
                center.x + cos(angle).toFloat() * radius,
                center.y + sin(angle).toFloat() * radius
            )
            drawCircle(
                color = if (safeRpm >= GhostOriginalRedlineStart) Color(0xFFFF5050) else GhostOriginalWhite,
                radius = 4.2f * sx,
                center = marker
            )
        }
    }
}

@Composable
private fun GhostOriginalHeadUnitTabs(
    selected: GhostOriginalHeadUnitTab,
    accent: Color,
    transform: GhostOriginalTransform,
    onSelect: (GhostOriginalHeadUnitTab) -> Unit
) {
    Row(
        modifier = Modifier
            .offset(transform.x(28f), transform.y(24f))
            .height(transform.h(68f)),
        horizontalArrangement = Arrangement.spacedBy(transform.w(8f)),
        verticalAlignment = Alignment.CenterVertically
    ) {
        GhostOriginalTabButton(GhostOriginalHeadUnitTab.Vehicle, selected, accent, transform, onSelect)
        GhostOriginalTabButton(GhostOriginalHeadUnitTab.Music, selected, accent, transform, onSelect)
        GhostOriginalTabButton(GhostOriginalHeadUnitTab.Navigation, selected, accent, transform, onSelect)
    }
}

@Composable
private fun GhostOriginalTabButton(
    tab: GhostOriginalHeadUnitTab,
    selected: GhostOriginalHeadUnitTab,
    accent: Color,
    transform: GhostOriginalTransform,
    onSelect: (GhostOriginalHeadUnitTab) -> Unit
) {
    val active = tab == selected
    Column(
        modifier = Modifier
            .width(transform.w(58f))
            .clickable { onSelect(tab) },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Canvas(modifier = Modifier.size(transform.w(36f))) {
            val c = if (active) GhostOriginalWhite else GhostOriginalMuted.copy(alpha = 0.72f)
            when (tab) {
                GhostOriginalHeadUnitTab.Vehicle -> drawVehicleTabIcon(c)
                GhostOriginalHeadUnitTab.Music -> drawMusicTabIcon(c)
                GhostOriginalHeadUnitTab.Navigation -> drawNavigationTabIcon(c)
            }
        }
        Spacer(Modifier.height(transform.h(5f)))
        Box(
            Modifier
                .width(transform.w(34f))
                .height(transform.h(3f))
                .background(if (active) accent else Color.Transparent, RoundedCornerShape(2.dp))
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawVehicleTabIcon(color: Color) {
    val w = size.width
    val h = size.height
    drawRoundRect(
        color = color,
        topLeft = Offset(w * .18f, h * .35f),
        size = Size(w * .64f, h * .36f),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(w * .10f, w * .10f),
        style = Stroke(width = w * .07f)
    )
    drawLine(color, Offset(w * .28f, h * .35f), Offset(w * .39f, h * .20f), strokeWidth = w * .07f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * .39f, h * .20f), Offset(w * .63f, h * .20f), strokeWidth = w * .07f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * .63f, h * .20f), Offset(w * .74f, h * .35f), strokeWidth = w * .07f, cap = StrokeCap.Round)
    drawCircle(color, w * .07f, Offset(w * .31f, h * .76f))
    drawCircle(color, w * .07f, Offset(w * .69f, h * .76f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawMusicTabIcon(color: Color) {
    val w = size.width
    val h = size.height
    drawLine(color, Offset(w * .58f, h * .18f), Offset(w * .58f, h * .67f), strokeWidth = w * .075f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * .58f, h * .18f), Offset(w * .82f, h * .12f), strokeWidth = w * .075f, cap = StrokeCap.Round)
    drawLine(color, Offset(w * .82f, h * .12f), Offset(w * .82f, h * .58f), strokeWidth = w * .075f, cap = StrokeCap.Round)
    drawCircle(color, w * .12f, Offset(w * .45f, h * .72f))
    drawCircle(color, w * .12f, Offset(w * .69f, h * .63f))
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawNavigationTabIcon(color: Color) {
    val path = androidx.compose.ui.graphics.Path().apply {
        moveTo(size.width * .18f, size.height * .82f)
        lineTo(size.width * .50f, size.height * .14f)
        lineTo(size.width * .82f, size.height * .82f)
        lineTo(size.width * .50f, size.height * .66f)
        close()
    }
    drawPath(path, color = color)
}

@Composable
private fun GhostOriginalMusicPanel(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    transform: GhostOriginalTransform
) {
    val context = LocalContext.current
    var media by remember(settings.defaultMediaApp) {
        mutableStateOf(MediaSessionBridge.read(context, settings.defaultMediaApp.packageName))
    }
    LaunchedEffect(settings.defaultMediaApp) {
        while (true) {
            media = MediaSessionBridge.read(context, settings.defaultMediaApp.packageName)
            delay(750)
        }
    }

    GhostOriginalSmallSpeed(snapshot, transform)
    Box(
        modifier = Modifier
            .offset(transform.x(395f), transform.y(200f))
            .size(transform.w(882f), transform.h(500f))
            .background(GhostOriginalPanel, RoundedCornerShape(transform.w(24f)))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(transform.w(24f)))
            .padding(transform.w(26f)),
        contentAlignment = Alignment.Center
    ) {
        if (!media.notificationAccess) {
            Text(
                "Medya bilgisi için Android bildirim erişimini açın",
                color = GhostOriginalMuted,
                fontSize = (18f * transform.scale).sp,
                textAlign = TextAlign.Center
            )
        } else {
            GhostOriginalMediaContent(context, media, transform)
        }
    }
}

@Composable
private fun GhostOriginalMediaContent(
    context: Context,
    media: LoganMediaState,
    transform: GhostOriginalTransform
) {
    val artwork = media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
        ?: media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(transform.w(28f))
    ) {
        if (artwork != null) {
            Image(
                bitmap = artwork.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.size(transform.w(190f)),
                contentScale = ContentScale.Crop
            )
        } else {
            Box(
                modifier = Modifier
                    .size(transform.w(190f))
                    .background(Color(0xFF172231), RoundedCornerShape(transform.w(18f))),
                contentAlignment = Alignment.Center
            ) {
                Text("♪", color = GhostOriginalWhite, fontSize = (72f * transform.scale).sp)
            }
        }

        Column(modifier = Modifier.width(transform.w(540f))) {
            Text(
                media.title ?: "Medya oynatılmıyor",
                color = GhostOriginalWhite,
                fontSize = (28f * transform.scale).sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(transform.h(8f)))
            Text(
                media.artist ?: media.album ?: "${media.sessionCount} aktif medya oturumu",
                color = GhostOriginalMuted,
                fontSize = (18f * transform.scale).sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(transform.h(28f)))
            Row(horizontalArrangement = Arrangement.spacedBy(transform.w(16f))) {
                GhostOriginalMediaButton("‹‹", transform) { MediaSessionBridge.previous(context, media) }
                GhostOriginalMediaButton(
                    if (media.playbackState == android.media.session.PlaybackState.STATE_PLAYING) "II" else "▶",
                    transform
                ) { MediaSessionBridge.playPause(context, media) }
                GhostOriginalMediaButton("››", transform) { MediaSessionBridge.next(context, media) }
            }
        }
    }
}

@Composable
private fun GhostOriginalMediaButton(
    text: String,
    transform: GhostOriginalTransform,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(transform.w(74f), transform.h(54f))
            .background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(transform.w(12f)))
            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(transform.w(12f)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = GhostOriginalWhite, fontSize = (21f * transform.scale).sp, fontWeight = FontWeight.Bold)
    }
}

private data class GhostNavigationState(
    val notificationAccess: Boolean,
    val appLabel: String? = null,
    val title: String? = null,
    val instruction: String? = null,
    val detail: String? = null
)

@Composable
private fun GhostOriginalNavigationPanel(
    snapshot: DashboardSnapshot,
    transform: GhostOriginalTransform
) {
    val context = LocalContext.current
    var navigation by remember { mutableStateOf(readNavigationState(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            navigation = readNavigationState(context)
            delay(1000)
        }
    }

    GhostOriginalSmallSpeed(snapshot, transform)
    Box(
        modifier = Modifier
            .offset(transform.x(435f), transform.y(210f))
            .size(transform.w(802f), transform.h(455f))
            .background(GhostOriginalPanel, RoundedCornerShape(transform.w(24f)))
            .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(transform.w(24f)))
            .padding(transform.w(34f)),
        contentAlignment = Alignment.Center
    ) {
        if (!navigation.notificationAccess) {
            Text(
                "Navigasyon kartı için Android bildirim erişimini açın",
                color = GhostOriginalMuted,
                fontSize = (18f * transform.scale).sp,
                textAlign = TextAlign.Center
            )
        } else if (navigation.title == null && navigation.instruction == null) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("NAVİGASYON", color = GhostOriginalWhite, fontSize = (24f * transform.scale).sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(transform.h(14f)))
                Text(
                    "Google Maps veya Waze yönlendirmesi bekleniyor",
                    color = GhostOriginalMuted,
                    fontSize = (18f * transform.scale).sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    navigation.appLabel ?: "NAVİGASYON",
                    color = GhostOriginalMuted,
                    fontSize = (15f * transform.scale).sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(transform.h(14f)))
                navigation.title?.let {
                    Text(it, color = GhostOriginalWhite, fontSize = (30f * transform.scale).sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                }
                navigation.instruction?.let {
                    Spacer(Modifier.height(transform.h(10f)))
                    Text(it, color = GhostOriginalWhite, fontSize = (22f * transform.scale).sp, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                navigation.detail?.let {
                    Spacer(Modifier.height(transform.h(12f)))
                    Text(it, color = GhostOriginalMuted, fontSize = (16f * transform.scale).sp, textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}

@Composable
private fun GhostOriginalSmallSpeed(snapshot: DashboardSnapshot, transform: GhostOriginalTransform) {
    Box(
        modifier = Modifier
            .offset(transform.x(1440f), transform.y(38f))
            .size(transform.w(190f), transform.h(82f)),
        contentAlignment = Alignment.Center
    ) {
        Text(
            "${(snapshot.speedKmh ?: 0).coerceIn(0, 200)} km/h",
            color = GhostOriginalWhite,
            fontSize = (22f * transform.scale).sp,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun readNavigationState(context: Context): GhostNavigationState {
    val listener = ComponentName(context, LoganMediaNotificationListener::class.java)
    val notificationManager = context.getSystemService(NotificationManager::class.java)
    val access = notificationManager?.isNotificationListenerAccessGranted(listener) == true
    if (!access) return GhostNavigationState(notificationAccess = false)

    val candidate = LoganMediaNotificationListener.activeNotificationsSnapshot()
        .asSequence()
        .filter { it.packageName == "com.google.android.apps.maps" || it.packageName == "com.waze" }
        .sortedByDescending { it.postTime }
        .firstOrNull()
        ?: return GhostNavigationState(notificationAccess = true)

    val extras = candidate.notification.extras
    fun extra(key: String): String? = extras.getCharSequence(key)?.toString()?.trim()?.takeIf { it.isNotBlank() }
    val title = extra(android.app.Notification.EXTRA_TITLE)
    val text = extra(android.app.Notification.EXTRA_TEXT)
    val big = extra(android.app.Notification.EXTRA_BIG_TEXT)
    val sub = extra(android.app.Notification.EXTRA_SUB_TEXT)
    val label = when (candidate.packageName) {
        "com.google.android.apps.maps" -> "GOOGLE MAPS"
        "com.waze" -> "WAZE"
        else -> "NAVİGASYON"
    }
    return GhostNavigationState(
        notificationAccess = true,
        appLabel = label,
        title = title,
        instruction = big ?: text,
        detail = sub?.takeIf { it != title && it != text }
    )
}

@DrawableRes
private fun ghostOriginalBackgroundRes(accent: GhostOriginalAccent): Int = when (accent) {
    GhostOriginalAccent.Purple -> R.drawable.ghost_original_baked_purple
    GhostOriginalAccent.Red -> R.drawable.ghost_original_baked_red
    GhostOriginalAccent.Green -> R.drawable.ghost_original_baked_green
    GhostOriginalAccent.Blue -> R.drawable.ghost_original_baked_blue
    GhostOriginalAccent.Yellow -> R.drawable.ghost_original_baked_yellow
    GhostOriginalAccent.White -> R.drawable.ghost_original_baked_blue
}

private fun ghostOriginalAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFFD72DFF)
    GhostOriginalAccent.Red -> Color(0xFFFF2525)
    GhostOriginalAccent.Green -> Color(0xFF24F05A)
    GhostOriginalAccent.Blue -> Color(0xFF168BFF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFD22C)
    GhostOriginalAccent.White -> Color(0xFF168BFF)
}

private fun formatConsumption(value: Double?, unit: String): String {
    if (value == null) return "--"
    val resolvedUnit = unit.trim().ifBlank { "L/100 km" }
    return String.format(Locale.US, "%.1f %s", value, resolvedUnit)
}
