#!/usr/bin/env python3
"""Fast source/resource preflight executed before Gradle.

This does not replace the Android/Kotlin compiler. It catches common packaging
mistakes early: malformed XML, missing app resources, invalid resource names,
and Compose scope-member imports that previously broke LoganOS builds.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RESOURCE_NAME = re.compile(r"^[a-z][a-z0-9_]*$")
R_REF = re.compile(r"\bR\.(drawable|mipmap|string|color|dimen|style|xml|raw|font)\.([A-Za-z0-9_]+)\b")
INVALID_IMPORTS = {
    "import androidx.compose.foundation.layout.matchParentSize": "matchParentSize is a BoxScope member and must not be imported",
    "import androidx.compose.foundation.layout.weight": "weight is a RowScope/ColumnScope member and must not be imported",
}

# Kotlin rejects non-local break/continue from scope-function lambdas unless an
# experimental language feature is enabled. LoganOS does not enable that feature;
# keep polling-loop control flow outside let/run/also/apply lambdas.
INLINE_LAMBDA_LOOP_CONTROL = re.compile(
    r"(?:\?\.|\.)\s*(?:let|run|also|apply)\s*\{(?:(?!\n\s*\}).){0,1200}\b(?:break|continue)\b",
    re.S,
)


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def passed(message: str) -> None:
    print(f"[PASS] {message}")


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    res = root / "app/src/main/res"
    source = root / "app/src/main/java"
    if not res.is_dir() or not source.is_dir():
        fail("Android source tree is incomplete")

    resources: dict[str, set[str]] = {key: set() for key in ("drawable", "mipmap", "string", "color", "dimen", "style", "xml", "raw", "font")}

    xml_count = 0
    for path in sorted(res.rglob("*.xml")):
        try:
            tree = ET.parse(path)
        except ET.ParseError as exc:
            fail(f"Malformed XML: {path.relative_to(root)}: {exc}")
        xml_count += 1
        parent = path.parent.name.split("-", 1)[0]
        if parent in ("drawable", "mipmap", "xml", "font"):
            resources[parent].add(path.stem)
        if parent == "values":
            for child in tree.getroot():
                name = child.attrib.get("name")
                tag = child.tag.split("}")[-1]
                if not name:
                    continue
                kind = "style" if tag == "style" else tag
                if kind in resources:
                    resources[kind].add(name)
    passed(f"{xml_count} Android XML file parsed successfully")

    file_types = {
        "drawable": ("drawable",),
        "mipmap": ("mipmap",),
        "raw": ("raw",),
        "font": ("font",),
        "xml": ("xml",),
    }
    for kind, prefixes in file_types.items():
        for directory in res.iterdir():
            if not directory.is_dir() or directory.name.split("-", 1)[0] not in prefixes:
                continue
            for path in directory.iterdir():
                if path.is_file():
                    resources[kind].add(path.stem)
                    if not RESOURCE_NAME.fullmatch(path.stem):
                        fail(f"Invalid Android resource filename: {path.relative_to(root)}")
    passed("Android resource filenames are valid")

    kt_files = list(source.rglob("*.kt"))
    missing: list[str] = []
    for path in kt_files:
        text = path.read_text(encoding="utf-8")
        for token, label in INVALID_IMPORTS.items():
            if token in text:
                fail(f"{label}: {path.relative_to(root)}")
        if INLINE_LAMBDA_LOOP_CONTROL.search(text):
            fail(
                "Kotlin break/continue must not escape an inline scope-function lambda: "
                f"{path.relative_to(root)}"
            )
        for kind, name in R_REF.findall(text):
            if name not in resources[kind]:
                missing.append(f"{path.relative_to(root)} -> R.{kind}.{name}")
    if missing:
        fail("Missing app resource reference(s):\n  " + "\n  ".join(sorted(set(missing))))
    passed(f"{len(kt_files)} Kotlin file checked for resource references and known invalid imports")

    manifest = root / "app/src/main/AndroidManifest.xml"
    if not manifest.is_file():
        fail("AndroidManifest.xml is missing")
    passed("Android source/resource preflight completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
