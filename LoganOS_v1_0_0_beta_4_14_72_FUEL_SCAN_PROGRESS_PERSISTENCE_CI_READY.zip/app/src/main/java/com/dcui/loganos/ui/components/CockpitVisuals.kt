package com.dcui.loganos.ui.components

import android.animation.ValueAnimator
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.dcui.loganos.ui.theme.LoganPalette
import kotlinx.coroutines.isActive

const val COOLANT_COLD_LIMIT_C = 75
const val COOLANT_CRITICAL_LIMIT_C = 103

fun coolantAccentColor(palette: LoganPalette, temperatureC: Int?): Color {
    val dark = palette.background.luminance() < .5f
    val iceBlue = if (dark) Color(0xFF9DE7FF) else Color(0xFF36B9E6)
    val pink = if (dark) Color(0xFFFF7FA4) else Color(0xFFE84E7A)
    val red = if (dark) Color(0xFFFF4B4B) else Color(0xFFD62828)
    return when {
        temperatureC == null -> palette.textSecondary
        temperatureC < COOLANT_COLD_LIMIT_C -> iceBlue
        temperatureC < COOLANT_CRITICAL_LIMIT_C -> pink
        else -> red
    }
}

fun acAccentColor(palette: LoganPalette, acOn: Boolean?): Color {
    val dark = palette.background.luminance() < .5f
    val iceBlue = if (dark) Color(0xFF9DE7FF) else Color(0xFF36B9E6)
    return if (acOn == true) iceBlue else palette.textSecondary
}

fun isTrustedFuelSourceForDisplay(source: String): Boolean {
    return when (source.uppercase()) {
        "INJECTION", "HOLD", "CUTOFF", "COAST_GUARD", "CRANK_GUARD", "DEMO" -> true
        else -> false
    }
}

@Composable
fun rememberConsumptionTrend(
    value: Double?,
    enabled: Boolean,
    tripToken: Long,
    unitKey: String,
    capacity: Int = 24
): List<Float> {
    val history = remember(tripToken, unitKey) { mutableStateListOf<Float>() }
    LaunchedEffect(value, enabled, tripToken, unitKey) {
        if (!enabled) {
            history.clear()
        } else {
            value?.toFloat()
                ?.takeIf { it.isFinite() && it >= 0f }
                ?.let { sample ->
                    history.add(sample)
                    while (history.size > capacity) history.removeAt(0)
                }
        }
    }
    return history
}

@Composable
fun ConsumptionSparkline(
    values: List<Float>,
    lineColor: Color,
    guideColor: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val clean = values.filter { it.isFinite() && it >= 0f }
        val points = when (clean.size) {
            0 -> listOf(0f, 0f)
            1 -> listOf(clean.first(), clean.first())
            else -> clean
        }
        val rawMin = points.minOrNull() ?: 0f
        val rawMax = points.maxOrNull() ?: 0f
        val minimumSpan = if (rawMax <= 15f) .8f else 2.5f
        val span = (rawMax - rawMin).coerceAtLeast(minimumSpan)
        val low = (rawMin - span * .12f).coerceAtLeast(0f)
        val high = rawMax + span * .12f
        val range = (high - low).coerceAtLeast(.01f)

        drawLine(
            color = guideColor.copy(alpha = .50f),
            start = Offset(0f, size.height * .72f),
            end = Offset(size.width, size.height * .72f),
            strokeWidth = 1.dp.toPx()
        )

        val path = Path()
        points.forEachIndexed { index, sample ->
            val x = if (points.size <= 1) 0f else size.width * index / points.lastIndex.toFloat()
            val normalized = ((sample - low) / range).coerceIn(0f, 1f)
            val y = size.height - normalized * size.height
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        drawPath(
            path = path,
            color = lineColor,
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )

        val last = points.last()
        val lastY = size.height - (((last - low) / range).coerceIn(0f, 1f) * size.height)
        drawCircle(
            color = lineColor,
            radius = 2.4.dp.toPx(),
            center = Offset(size.width, lastY)
        )
    }
}

@Composable
fun rememberRoadPhase(speedKmh: Int?, enabled: Boolean = true): Float {
    val context = LocalContext.current
    var phase by remember { mutableFloatStateOf(0f) }
    val speed = speedKmh?.coerceAtLeast(0) ?: 0
    val animationsEnabled = remember(context) { ValueAnimator.areAnimatorsEnabled() }

    LaunchedEffect(speed, enabled, animationsEnabled) {
        if (!enabled || !animationsEnabled || speed <= 0) return@LaunchedEffect
        var previousFrame = 0L
        while (isActive) {
            withFrameNanos { frameNanos ->
                if (previousFrame != 0L) {
                    val deltaSeconds = (frameNanos - previousFrame) / 1_000_000_000f
                    val normalizedSpeed = (speed.coerceAtMost(180) / 180f)
                    phase = (phase + deltaSeconds * (.22f + normalizedSpeed * 1.65f)) % 1f
                }
                previousFrame = frameNanos
            }
        }
    }
    return phase
}
