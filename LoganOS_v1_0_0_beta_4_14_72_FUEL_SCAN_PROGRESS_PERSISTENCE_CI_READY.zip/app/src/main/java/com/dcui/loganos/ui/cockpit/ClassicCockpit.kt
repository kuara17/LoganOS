package com.dcui.loganos.ui.cockpit

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.ObdConnectionHealth
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.acAccentColor
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.rememberRoadPhase
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private data class ClassicColors(
    val background: Color,
    val surface: Color,
    val surface2: Color,
    val dialFace: Color,
    val line: Color,
    val blue: Color,
    val text: Color,
    val muted: Color,
    val green: Color,
    val iceBlue: Color,
    val pink: Color,
    val red: Color
)

private fun classicColors(palette: LoganPalette): ClassicColors {
    val dark = palette.background.luminance() < 0.5f
    return if (dark) {
        ClassicColors(
            background = Color(0xFF090E14),
            surface = Color(0xFF101720),
            surface2 = Color(0xFF141D27),
            dialFace = Color(0xFF090E14),
            line = Color(0xFF2A3542),
            blue = Color(0xFF1F7BFF),
            text = Color(0xFFF1F4F8),
            muted = Color(0xFF9AA6B5),
            green = Color(0xFF35B766),
            iceBlue = Color(0xFF9DE7FF),
            pink = Color(0xFFFF7FA4),
            red = Color(0xFFFF4B4B)
        )
    } else {
        ClassicColors(
            background = palette.background,
            surface = palette.surface,
            surface2 = palette.surfaceVariant,
            dialFace = Color(0xFFF7F9FC),
            line = palette.line,
            blue = Color(0xFF1769D8),
            text = palette.textPrimary,
            muted = palette.textSecondary,
            green = Color(0xFF16883B),
            iceBlue = Color(0xFF2FAAD4),
            pink = Color(0xFFE84E7A),
            red = Color(0xFFD62828)
        )
    }
}

@Composable
fun ClassicCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    portrait: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    textScale: Float = 1.0f
) {
    val colors = classicColors(palette)
    if (portrait) {
        ClassicPortrait(palette, colors, settings, snapshot, obdState, onOpenReset, onObdClick, textScale)
    } else {
        ClassicLandscape(palette, colors, settings, snapshot, obdState, onOpenReset, onObdClick, textScale)
    }
}

@Composable
private fun ClassicPortrait(
    palette: LoganPalette,
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    textScale: Float = 1.0f
) {
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        val spacing = 8.dp
        val hasPetrolBanner = settings.isExperimentalPetrol
        val connected = snapshot.connected || obdState.connected || settings.demoMode
        val adaptiveMinimumHeight = if (hasPetrolBanner) 670.dp else 600.dp

        if (maxHeight >= adaptiveMinimumHeight) {
            val gapCount = if (hasPetrolBanner) 7 else 6
            val fixedDp = 42f + (if (hasPetrolBanner) 46f else 0f) + spacing.value * gapCount
            val flexibleDp = (maxHeight.value - fixedDp).coerceAtLeast(500f)
            val totalWeight = 5.88f
            val speedHeight = (flexibleDp * 1.58f / totalWeight).dp
            val miniHeight = (flexibleDp * 1.02f / totalWeight).dp
            val cardHeight = (flexibleDp * .82f / totalWeight).dp

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(spacing)
            ) {
                ClassicHeader(palette, colors, settings, snapshot, obdState, onOpenReset, onObdClick)
                ClassicPortraitSpeedGauge(
                    colors = colors,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(speedHeight),
                    textScale = textScale
                )
                ClassicPortraitMiniRow(
                    colors = colors,
                    settings = settings,
                    snapshot = snapshot,
                    connected = connected,
                    modifier = Modifier.fillMaxWidth().height(miniHeight),
                    textScale = textScale
                )
                ClassicPortraitFuelRow(
                    colors = colors,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(cardHeight),
                    fillHeight = true,
                    textScale = textScale
                )
                ClassicPortraitClimateRow(
                    colors = colors,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(cardHeight),
                    fillHeight = true,
                    textScale = textScale
                )
                ClassicPortraitTripRow(
                    colors = colors,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(cardHeight),
                    fillHeight = true,
                    textScale = textScale
                )
                ClassicPortraitBottomRow(
                    colors = colors,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(cardHeight),
                    fillHeight = true,
                    textScale = textScale
                )
                if (hasPetrolBanner) {
                    Box(Modifier.height(46.dp)) {
                        ExperimentalPetrolBanner(colors, settings, compact = true)
                    }
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(spacing)
            ) {
                item { ClassicHeader(palette, colors, settings, snapshot, obdState, onOpenReset, onObdClick) }
                item {
                    ClassicPortraitSpeedGauge(
                        colors = colors,
                        snapshot = snapshot,
                        modifier = Modifier.fillMaxWidth().height(154.dp),
                        textScale = textScale
                    )
                }
                item {
                    ClassicPortraitMiniRow(
                        colors = colors,
                        settings = settings,
                        snapshot = snapshot,
                        connected = connected,
                        modifier = Modifier.fillMaxWidth().height(106.dp),
                        textScale = textScale
                    )
                }
                item { ClassicPortraitFuelRow(colors, settings, snapshot, Modifier.fillMaxWidth(), fillHeight = false, textScale = textScale) }
                item { ClassicPortraitClimateRow(colors, settings, snapshot, Modifier.fillMaxWidth(), fillHeight = false, textScale = textScale) }
                item { ClassicPortraitTripRow(colors, settings, snapshot, Modifier.fillMaxWidth(), fillHeight = false, textScale = textScale) }
                item { ClassicPortraitBottomRow(colors, settings, snapshot, Modifier.fillMaxWidth(), fillHeight = false, textScale = textScale) }
                if (hasPetrolBanner) item { ExperimentalPetrolBanner(colors, settings) }
                item { Spacer(Modifier.height(4.dp)) }
            }
        }
    }
}

@Composable
private fun ClassicPortraitSpeedGauge(
    colors: ClassicColors,
    snapshot: DashboardSnapshot,
    modifier: Modifier = Modifier,
    textScale: Float = 1.0f
) {
    ClassicDial(
        colors = colors,
        value = snapshot.speedKmh?.toFloat(),
        maxValue = 220f,
        redZoneStart = null,
        majorStep = 20f,
        labelFormatter = { it.toInt().toString() },
        digitalText = snapshot.speedKmh?.toString() ?: "--",
        unit = "km/h",
        modifier = modifier,
        responseMillis = 260,
        readoutInside = true,
        showReadout = false,
        textScale = textScale
    )
}

@Composable
private fun ClassicPortraitMiniRow(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    connected: Boolean,
    modifier: Modifier = Modifier,
    textScale: Float = 1.0f
) {
    Row(modifier = modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ClassicDial(
            colors = colors,
            value = snapshot.rpm?.toFloat(),
            maxValue = settings.tachometerMaxRpm.toFloat(),
            redZoneStart = settings.tachometerRedZoneStartRpm.toFloat(),
            majorStep = 1000f,
            labelFormatter = { (it / 1000f).toInt().toString() },
            digitalText = snapshot.rpm?.toString() ?: "--",
            unit = "rpm",
            modifier = Modifier.weight(1f).fillMaxHeight(),
            responseMillis = 140,
            textScale = textScale
        )
        ClassicVehiclePanel(
            colors = colors,
            settings = settings,
            snapshot = snapshot,
            motionEnabled = connected,
            modifier = Modifier.weight(1f).fillMaxHeight(),
            compact = true,
            carScale = if (settings.deviceMode == com.dcui.loganos.model.DeviceMode.HeadUnit) 1.0f else 1.25f
        )
    }
}

@Composable
private fun ClassicPortraitFuelRow(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier = Modifier,
    fillHeight: Boolean,
    textScale: Float = 1.0f
) {
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ClassicFuelCard(
            colors,
            settings,
            snapshot,
            average = false,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
        ClassicFuelCard(
            colors,
            settings,
            snapshot,
            average = true,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
    }
}

@Composable
private fun ClassicPortraitClimateRow(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier = Modifier,
    fillHeight: Boolean,
    textScale: Float = 1.0f
) {
    val english = settings.language == AppLanguage.English
    val scale = textScale.coerceIn(0.88f, 1.28f)
    val coolantAccent = coolantAccentColor(classicIconPalette(colors), snapshot.engineTempC)
    val acAccent = acAccentColor(classicIconPalette(colors), snapshot.acOn)
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ClassicMetricCard(
            colors = colors,
            title = if (english) "Coolant" else "Hararet",
            value = snapshot.engineTempC?.toString() ?: "--",
            unit = "°C",
            icon = CardIcon.Temperature,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            iconTint = coolantAccent,
            valueColor = coolantAccent,
            unitColor = coolantAccent.copy(alpha = .86f),
            fillHeight = fillHeight,
            textScale = textScale
        )
        ClassicMetricCard(
            colors = colors,
            title = if (english) "A/C" else "Klima",
            value = snapshot.acOn?.let {
                if (it) if (english) "On" else "Açık" else if (english) "Off" else "Kapalı"
            } ?: "--",
            icon = CardIcon.Ac,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            iconTint = acAccent,
            valueColor = acAccent,
            fillHeight = fillHeight,
            textScale = textScale
        )
    }
}

@Composable
private fun ClassicPortraitTripRow(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier = Modifier,
    fillHeight: Boolean,
    textScale: Float = 1.0f
) {
    val english = settings.language == AppLanguage.English
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ClassicMetricCard(
            colors = colors,
            title = if (english) "Trip Cost" else "Sürüş Maliyeti",
            value = if (settings.fuelCalculationSupported) snapshot.tripCostText ?: "--" else if (english) "Disabled" else "Kapalı",
            icon = CardIcon.Cost,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
        ClassicMetricCard(
            colors = colors,
            title = if (english) "Distance" else "Mesafe",
            value = formatOne(snapshot.tripDistanceKm),
            unit = "km",
            icon = CardIcon.Distance,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
    }
}

@Composable
private fun ClassicPortraitBottomRow(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier = Modifier,
    fillHeight: Boolean,
    textScale: Float = 1.0f
) {
    val english = settings.language == AppLanguage.English
    Row(modifier, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ClassicMetricCard(
            colors = colors,
            title = if (english) "Trip Time" else "Sürüş Süresi",
            value = snapshot.tripDurationText ?: "00:00",
            icon = CardIcon.Time,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
        ClassicMetricCard(
            colors = colors,
            title = if (english) "Fuel Used" else "Kullanılan Yakıt",
            value = if (settings.fuelCalculationSupported) formatFuelUsed(snapshot.fuelUsedL) else if (english) "Not verified" else "Doğrulanmadı",
            unit = if (settings.fuelCalculationSupported) "L" else null,
            icon = CardIcon.FuelAverage,
            modifier = Modifier.weight(1f).then(if (fillHeight) Modifier.fillMaxHeight() else Modifier),
            fillHeight = fillHeight,
            textScale = textScale
        )
    }
}

@Composable
private fun ClassicLandscape(
    palette: LoganPalette,
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    textScale: Float = 1.0f
) {
    val english = settings.language == AppLanguage.English
    val coolantAccent = coolantAccentColor(classicIconPalette(colors), snapshot.engineTempC)
    val acAccent = acAccentColor(classicIconPalette(colors), snapshot.acOn)
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        ClassicHeader(palette, colors, settings, snapshot, obdState, onOpenReset, onObdClick)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1.28f),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ClassicDial(
                colors = colors,
                value = snapshot.rpm?.toFloat(),
                maxValue = settings.tachometerMaxRpm.toFloat(),
                redZoneStart = settings.tachometerRedZoneStartRpm.toFloat(),
                majorStep = 1000f,
                labelFormatter = { (it / 1000f).toInt().toString() },
                digitalText = snapshot.rpm?.toString() ?: "--",
                unit = "rpm",
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                responseMillis = 140,
                textScale = textScale
            )
            ClassicDial(
                colors = colors,
                value = snapshot.speedKmh?.toFloat(),
                maxValue = 220f,
                redZoneStart = null,
                majorStep = 20f,
                labelFormatter = { it.toInt().toString() },
                digitalText = snapshot.speedKmh?.toString() ?: "--",
                unit = "km/h",
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                responseMillis = 260,
                readoutInside = true,
                showReadout = false,
                textScale = textScale
            )
            ClassicVehiclePanel(
                colors = colors,
                settings = settings,
                snapshot = snapshot,
                motionEnabled = snapshot.connected || obdState.connected || settings.demoMode,
                modifier = Modifier
                    .weight(1.08f)
                    .fillMaxHeight()
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(.62f),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            ClassicFuelCard(colors, settings, snapshot, average = false, modifier = Modifier.weight(1.15f), compact = true, textScale = textScale)
            ClassicFuelCard(colors, settings, snapshot, average = true, modifier = Modifier.weight(1.15f), compact = true, textScale = textScale)
            ClassicMetricCard(
                colors = colors,
                title = if (english) "Coolant" else "Hararet",
                value = snapshot.engineTempC?.toString() ?: "--",
                unit = "°C",
                icon = CardIcon.Temperature,
                modifier = Modifier.weight(.8f),
                compact = true,
                iconTint = coolantAccent,
                valueColor = coolantAccent,
                unitColor = coolantAccent.copy(alpha = .86f),
                textScale = textScale
            )
            ClassicMetricCard(
                colors = colors,
                title = if (english) "A/C" else "Klima",
                value = snapshot.acOn?.let {
                    if (it) {
                        if (english) "On" else "Açık"
                    } else {
                        if (english) "Off" else "Kapalı"
                    }
                } ?: "--",
                icon = CardIcon.Ac,
                modifier = Modifier.weight(.8f),
                compact = true,
                iconTint = acAccent,
                valueColor = acAccent,
                textScale = textScale
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(.62f),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            ClassicMetricCard(
                colors,
                if (english) "Trip Cost" else "Sürüş Maliyeti",
                if (settings.fuelCalculationSupported) snapshot.tripCostText ?: "--" else if (english) "Disabled" else "Kapalı",
                null,
                CardIcon.Cost,
                Modifier.weight(1f),
                compact = true,
                textScale = textScale
            )
            ClassicMetricCard(colors, if (english) "Distance" else "Mesafe", formatOne(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f), compact = true, textScale = textScale)
            ClassicMetricCard(colors, if (english) "Trip Time" else "Sürüş Süresi", snapshot.tripDurationText ?: "00:00", null, CardIcon.Time, Modifier.weight(1.15f), compact = true, textScale = textScale)
        }
        if (settings.isExperimentalPetrol) {
            ExperimentalPetrolBanner(colors, settings, compact = true)
        }
    }
}

@Composable
private fun ClassicHeader(
    palette: LoganPalette,
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    textScale: Float = 1.0f
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(42.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        LoganWordmark(palette, compact = true)
        Spacer(Modifier.weight(1f))
        val connected = snapshot.connected || obdState.connected
        val statusColor = when {
            settings.demoMode -> Color(0xFFFFA726)
            obdState.connectionHealth == ObdConnectionHealth.UNSTABLE -> Color(0xFFFFA726)
            obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> Color(0xFFFFA726)
            connected -> colors.green
            obdState.connecting || obdState.connectionHealth == ObdConnectionHealth.CONNECTING -> Color(0xFFFFA726)
            else -> colors.muted
        }
        val statusText = when {
            settings.demoMode -> "DEMO"
            obdState.connectionHealth == ObdConnectionHealth.UNSTABLE -> if (settings.language == AppLanguage.English) "UNSTABLE" else "KARARSIZ"
            obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> if (settings.language == AppLanguage.English) "RECONNECT" else "YENİDEN"
            connected -> if (settings.language == AppLanguage.English) "OBD ON" else "OBD BAĞLI"
            obdState.connecting || obdState.connectionHealth == ObdConnectionHealth.CONNECTING -> if (settings.language == AppLanguage.English) "CONNECTING" else "BAĞLANIYOR"
            else -> if (settings.language == AppLanguage.English) "OBD WAIT" else "OBD BEK."
        }
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(99.dp))
                .background(statusColor.copy(alpha = .13f))
                .clickable(onClick = onObdClick)
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(statusColor))
            Text(statusText, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(colors.surface2)
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = colors.text, fontSize = 20.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ClassicDial(
    colors: ClassicColors,
    value: Float?,
    maxValue: Float,
    redZoneStart: Float?,
    majorStep: Float,
    labelFormatter: (Float) -> String,
    digitalText: String,
    unit: String,
    modifier: Modifier = Modifier,
    responseMillis: Int,
    plateRes: Int? = null,
    readoutInside: Boolean = false,
    showReadout: Boolean = true,
    textScale: Float = 1.0f
) {
    val target = value?.coerceIn(0f, maxValue) ?: 0f
    val animated by animateFloatAsState(
        targetValue = target,
        animationSpec = tween(responseMillis),
        label = "classicDial"
    )
    BoxWithConstraints(
        modifier = modifier.clip(RoundedCornerShape(22.dp)),
        contentAlignment = Alignment.Center
    ) {
        if (plateRes != null) {
            Image(
                painter = painterResource(plateRes),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )
        } else {
            Box(
                Modifier.fillMaxSize()
                    .background(colors.surface)
                    .border(1.dp, colors.line, RoundedCornerShape(22.dp))
            )
        }
        val compact = maxHeight < 135.dp || maxWidth < 170.dp
        val dialTextScale = textScale.coerceIn(0.88f, 1.28f)
        Canvas(Modifier.fillMaxSize().padding(5.dp)) {
            // Speed dials can place the digital readout inside the gauge so the
            // dial itself can grow larger. Small auxiliary dials keep the bottom strip.
            val c = Offset(size.width / 2f, size.height * when {
                !showReadout && compact -> .50f
                !showReadout -> .52f
                readoutInside && compact -> .49f
                readoutInside -> .50f
                compact -> .40f
                else -> .42f
            })
            val radius = minOf(
                size.width * when {
                    !showReadout -> .46f
                    readoutInside -> .44f
                    else -> .43f
                },
                size.height * when {
                    !showReadout && compact -> .40f
                    !showReadout -> .43f
                    readoutInside && compact -> .43f
                    readoutInside -> .45f
                    compact -> .34f
                    else -> .36f
                }
            )
            val start = 135f
            val sweep = 270f
            drawCircle(colors.dialFace, radius, c)
            drawCircle(colors.blue.copy(alpha = .90f), radius, c, style = Stroke(width = if (compact) 2.2f else 3f))
            drawCircle(colors.line, radius * .94f, c, style = Stroke(width = 1.2f))

            val minorStep = majorStep / 5f
            val tickCount = (maxValue / minorStep).toInt()
            for (i in 0..tickCount) {
                val tickValue = i * minorStep
                val fraction = (tickValue / maxValue).coerceIn(0f, 1f)
                val angle = (start + sweep * fraction) * PI.toFloat() / 180f
                val major = i % 5 == 0
                val outer = radius * .91f
                val inner = outer - radius * if (major) .105f else .055f
                val inRed = redZoneStart != null && tickValue >= redZoneStart
                drawLine(
                    color = if (inRed) colors.red else colors.text.copy(alpha = if (major) .95f else .55f),
                    start = Offset(c.x + cos(angle) * inner, c.y + sin(angle) * inner),
                    end = Offset(c.x + cos(angle) * outer, c.y + sin(angle) * outer),
                    strokeWidth = if (major) (if (compact) 1.7f else 2.3f) else 1f,
                    cap = StrokeCap.Round
                )
            }

            var labelValue = 0f
            val paint = Paint().apply {
                isAntiAlias = true
                color = colors.text.toArgb()
                textAlign = Paint.Align.CENTER
                textSize = radius * (if (compact) .10f else .112f) * dialTextScale
                typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
            }
            while (labelValue <= maxValue + .1f) {
                val fraction = (labelValue / maxValue).coerceIn(0f, 1f)
                val angle = (start + sweep * fraction) * PI.toFloat() / 180f
                val labelRadius = radius * .68f
                val p = Offset(c.x + cos(angle) * labelRadius, c.y + sin(angle) * labelRadius)
                drawContext.canvas.nativeCanvas.drawText(labelFormatter(labelValue), p.x, p.y + paint.textSize * .34f, paint)
                labelValue += majorStep
            }

            val progress = (animated / maxValue).coerceIn(0f, 1f)
            val needleAngle = (start + sweep * progress) * PI.toFloat() / 180f
            val needleEnd = Offset(c.x + cos(needleAngle) * radius * .68f, c.y + sin(needleAngle) * radius * .68f)
            drawLine(colors.blue, c, needleEnd, if (compact) 3.6f else 5f, StrokeCap.Round)
            drawCircle(colors.blue, radius * .09f, c)
            drawCircle(colors.dialFace, radius * .048f, c)
        }
        if (showReadout && readoutInside) {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .offset(y = if (compact) 16.dp else 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    digitalText,
                    color = colors.text,
                    fontSize = ((if (compact) 22f else 34f) * dialTextScale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Text(
                    unit,
                    color = colors.blue,
                    fontSize = ((if (compact) 9f else 12f) * dialTextScale).sp,
                    fontWeight = FontWeight.Bold
                )
            }
        } else if (showReadout) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = if (compact) 4.dp else 6.dp),
                verticalAlignment = Alignment.Bottom,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    digitalText,
                    color = colors.text,
                    fontSize = ((if (compact) 20f else 30f) * dialTextScale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1
                )
                Spacer(Modifier.width(if (compact) 3.dp else 5.dp))
                Text(
                    unit,
                    color = colors.blue,
                    fontSize = ((if (compact) 8f else 11f) * dialTextScale).sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = if (compact) 3.dp else 5.dp)
                )
            }
        }
    }
}

@Composable
private fun ClassicMetricCard(
    colors: ClassicColors,
    title: String,
    value: String,
    unit: String? = null,
    icon: CardIcon,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    wide: Boolean = false,
    iconTint: Color = Color.Unspecified,
    valueColor: Color? = null,
    unitColor: Color? = null,
    fillHeight: Boolean = false,
    textScale: Float = 1.0f
) {
    val resolvedValueColor = valueColor ?: colors.text
    val resolvedUnitColor = unitColor ?: colors.blue
    val scale = textScale.coerceIn(0.88f, 1.28f)
    Row(
        modifier = modifier
            .then(
                if (compact || fillHeight) {
                    Modifier.fillMaxHeight()
                } else {
                    Modifier.height(if (wide) 78.dp else 82.dp)
                }
            )
            .heightIn(min = 70.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surface)
            .border(1.dp, colors.line, RoundedCornerShape(16.dp))
            .padding(horizontal = if (compact) 9.dp else 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        MetricIcon(
            palette = classicIconPalette(colors),
            icon = icon,
            tint = iconTint,
            modifier = Modifier.size(if (compact) 36.dp else 40.dp)
        )
        Spacer(Modifier.width(if (compact) 7.dp else 9.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
            Text(
                title.uppercase(),
                color = colors.muted,
                fontSize = (when {
                    compact && title.length > 14 -> 7f
                    compact -> 8.5f
                    title.length > 16 -> 8f
                    title.length > 12 -> 9f
                    else -> 10f
                } * scale).sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    value,
                    color = resolvedValueColor,
                    fontSize = (when {
                        compact && value.length > 10 -> 12f
                        compact && value.length > 7 -> 15f
                        compact -> 20f
                        value.length > 12 -> 13f
                        value.length > 8 -> 16f
                        else -> 23f
                    } * scale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!unit.isNullOrBlank()) {
                    Spacer(Modifier.width(4.dp))
                    Text(unit, color = resolvedUnitColor, fontSize = ((if (compact) 9f else 10f) * scale).sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun ClassicFuelCard(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    average: Boolean,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    fillHeight: Boolean = false,
    textScale: Float = 1.0f
) {
    val english = settings.language == AppLanguage.English
    val scale = textScale.coerceIn(0.88f, 1.28f)
    val supported = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    val title = if (average) {
        if (english) "Average Consumption" else "Ortalama Tüketim"
    } else {
        if (english) "Instant Consumption" else "Anlık Tüketim"
    }
    val rawValue = if (average) snapshot.averageConsumption else snapshot.instantConsumption
    val value = if (!supported) {
        if (english) "Not verified" else "Doğrulanmadı"
    } else {
        formatOne(rawValue)
    }
    val unit = if (supported) {
        if (average) "L/100 km" else snapshot.instantUnit
    } else {
        null
    }

    // Shared UI-only history. It resets on a new trip and whenever the
    // instant-consumption unit changes, so L/h and L/100 km never mix.
    val historyKey = if (average) "average" else snapshot.instantUnit
    val history = rememberConsumptionTrend(
        value = rawValue,
        enabled = supported,
        tripToken = snapshot.tripToken,
        unitKey = historyKey
    )

    Column(
        modifier = modifier
            .then(
                if (compact || fillHeight) {
                    Modifier.fillMaxHeight()
                } else {
                    Modifier.height(88.dp)
                }
            )
            .heightIn(min = 74.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(colors.surface)
            .border(1.dp, colors.line, RoundedCornerShape(16.dp))
            .padding(horizontal = if (compact) 8.dp else 10.dp, vertical = if (compact) 7.dp else 8.dp),
        verticalArrangement = Arrangement.spacedBy(if (compact) 3.dp else 4.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MetricIcon(
                palette = classicIconPalette(colors),
                icon = if (average) CardIcon.FuelAverage else CardIcon.FuelInstant,
                modifier = Modifier.size(if (compact) 24.dp else 27.dp)
            )
            Spacer(Modifier.width(if (compact) 5.dp else 6.dp))
            Text(
                title.uppercase(),
                color = colors.muted,
                fontSize = (when {
                    compact && title.length > 16 -> 7.2f
                    compact -> 7.8f
                    title.length > 16 -> 8.2f
                    else -> 9f
                } * scale).sp,
                lineHeight = ((if (compact) 8f else 9f) * scale).sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Clip,
                modifier = Modifier.weight(1f)
            )
        }

        if (compact) {
            // Double/head-unit layout: value left, wide sparkline right.
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                verticalAlignment = Alignment.Bottom
            ) {
                Column(
                    modifier = Modifier.weight(0.56f),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    ClassicFuelValue(colors, value, unit, compact = true, scale = scale)
                }
                Spacer(Modifier.width(7.dp))
                ConsumptionSparkline(
                    values = history,
                    lineColor = colors.blue,
                    guideColor = colors.line,
                    modifier = Modifier.weight(0.58f).height(30.dp)
                )
            }
        } else {
            // Phone layout: keep value readable and use the full card width below it.
            Column(
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                verticalArrangement = Arrangement.Bottom
            ) {
                ClassicFuelValue(colors, value, unit, compact = false, scale = 1.0f)
                ConsumptionSparkline(
                    values = history,
                    lineColor = colors.blue,
                    guideColor = colors.line,
                    modifier = Modifier.fillMaxWidth().height(20.dp)
                )
            }
        }
    }
}

@Composable
private fun ClassicFuelValue(
    colors: ClassicColors,
    value: String,
    unit: String?,
    compact: Boolean,
    scale: Float
) {
    Text(
        value,
        color = colors.text,
        fontSize = (when {
            compact && value.length > 10 -> 11f
            compact && value.length > 7 -> 14f
            compact -> 19f
            value.length > 12 -> 12f
            value.length > 8 -> 15f
            else -> 22f
        } * scale).sp,
        lineHeight = ((if (compact) 20f else 23f) * scale).sp,
        fontWeight = FontWeight.Black,
        maxLines = 1,
        softWrap = false,
        overflow = TextOverflow.Ellipsis
    )
    if (!unit.isNullOrBlank()) {
        Text(
            unit,
            color = colors.blue,
            fontSize = ((if (compact) 7.5f else 8.5f) * scale).sp,
            lineHeight = ((if (compact) 8f else 9f) * scale).sp,
            maxLines = 1,
            softWrap = false
        )
    }
}

@Composable
private fun ExperimentalPetrolBanner(
    colors: ClassicColors,
    settings: LoganSettings,
    compact: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFFFA726).copy(alpha = .10f))
            .border(1.dp, Color(0xFFFFA726).copy(alpha = .75f), RoundedCornerShape(14.dp))
            .padding(horizontal = 12.dp, vertical = if (compact) 6.dp else 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text("!", color = Color(0xFFFFA726), fontWeight = FontWeight.Black, fontSize = 18.sp)
        Spacer(Modifier.width(9.dp))
        Text(
            if (settings.language == AppLanguage.English) {
                "Experimental petrol profile • fuel calculation disabled • support data collection active"
            } else {
                "Deneysel benzinli profil • yakıt hesabı kapalı • destek verisi toplama aktif"
            },
            color = colors.text,
            fontSize = if (compact) 10.sp else 11.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 2
        )
    }
}

@Composable
private fun ClassicVehiclePanel(
    colors: ClassicColors,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    motionEnabled: Boolean,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    carScale: Float = 1.0f
) {
    val phase = rememberRoadPhase(snapshot.speedKmh, enabled = motionEnabled)
    val speed = snapshot.speedKmh ?: 0
    val safeCarScale = carScale.coerceIn(0.85f, 1.35f)
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(colors.surface)
            .border(1.dp, colors.line, RoundedCornerShape(18.dp))
            .padding(if (compact) 5.dp else 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val topY = size.height * .10f
            val bottomY = size.height * .98f
            val roadEdge = colors.line.copy(alpha = .92f)
            val roadFill = colors.surface2.copy(alpha = .72f)
            val laneColor = colors.text.copy(alpha = if (speed > 0) .72f else .42f)

            val road = Path().apply {
                moveTo(size.width * .39f, topY)
                lineTo(size.width * .61f, topY)
                lineTo(size.width * .92f, bottomY)
                lineTo(size.width * .08f, bottomY)
                close()
            }
            drawPath(road, color = roadFill)
            drawLine(roadEdge, Offset(size.width * .08f, bottomY), Offset(size.width * .39f, topY), 2.2f, StrokeCap.Round)
            drawLine(roadEdge, Offset(size.width * .92f, bottomY), Offset(size.width * .61f, topY), 2.2f, StrokeCap.Round)

            repeat(7) { index ->
                val t = ((index / 7f) + phase) % 1f
                val perspective = t * t
                val y = topY + (bottomY - topY) * perspective
                val leftX = size.width * .39f + (size.width * .08f - size.width * .39f) * perspective
                val rightX = size.width * .61f + (size.width * .92f - size.width * .61f) * perspective
                val segment = size.height * (.03f + .10f * perspective)
                val width = 1.2f + 2.8f * perspective
                drawLine(
                    laneColor,
                    Offset(leftX, y),
                    Offset(leftX - size.width * .01f * perspective, (y + segment).coerceAtMost(bottomY)),
                    width,
                    StrokeCap.Round
                )
                drawLine(
                    laneColor,
                    Offset(rightX, y),
                    Offset(rightX + size.width * .01f * perspective, (y + segment).coerceAtMost(bottomY)),
                    width,
                    StrokeCap.Round
                )
            }
        }
        Image(
            painter = painterResource(vehicleVisualDrawableRes(settings.vehicleVisualModel, settings.vehicleColor, VehicleAssetStyle.OemSimplified)),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(x = 0.dp)
                .fillMaxWidth((if (compact) .35f else .41f) * safeCarScale)
                .fillMaxHeight((if (compact) .50f else .58f) * safeCarScale)
                .padding(bottom = if (compact) 2.dp else 4.dp)
        )
        Row(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .clip(RoundedCornerShape(99.dp))
                .background(colors.background.copy(alpha = .78f))
                .padding(horizontal = 7.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(5.dp)
                    .clip(CircleShape)
                    .background(if (speed > 0 && motionEnabled) colors.green else colors.muted)
            )
            Spacer(Modifier.width(5.dp))
            Text(
                text = if (settings.language == AppLanguage.English) {
                    if (speed > 0 && motionEnabled) "MOVING" else "STOPPED"
                } else {
                    if (speed > 0 && motionEnabled) "HAREKET" else "DURUYOR"
                },
                color = colors.muted,
                fontSize = if (compact) 7.sp else 8.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}


private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun formatFuelUsed(value: Double?): String = value?.let {
    if (it < 1.0) String.format(Locale.US, "%.2f", it) else String.format(Locale.US, "%.1f", it)
} ?: "--"

private fun classicIconPalette(colors: ClassicColors): LoganPalette = LoganPalette(
    background = colors.background,
    surface = colors.surface,
    surfaceVariant = colors.surface2,
    textPrimary = colors.text,
    textSecondary = colors.muted,
    muted = colors.muted,
    line = colors.line,
    accent = colors.blue,
    blue = colors.blue
)
