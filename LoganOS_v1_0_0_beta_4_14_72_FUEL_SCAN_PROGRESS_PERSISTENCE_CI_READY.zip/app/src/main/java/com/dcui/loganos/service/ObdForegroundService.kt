package com.dcui.loganos.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.dcui.loganos.MainActivity
import com.dcui.loganos.R
import com.dcui.loganos.obd.FUEL_LEVEL_DISCOVERY_TEST_NAME
import com.dcui.loganos.obd.ObdConnectionHealth
import com.dcui.loganos.runtime.LoganRuntime
import java.util.Locale

/**
 * Keeps the process in Android's foreground-service class while an OBD session
 * is active. The Bluetooth/KWP engine itself remains in the process-wide
 * ObdController owned by LoganRuntime, so Activity recreation or leaving the
 * app does not create a second connection or stop the current drive session.
 */
class ObdForegroundService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private val controller by lazy { LoganRuntime.obdController(applicationContext) }

    private val notificationUpdater = object : Runnable {
        override fun run() {
            val state = controller.state
            val diagnosticActive = state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME
            if (!diagnosticActive && !state.connected && !state.connecting && state.connectionHealth != ObdConnectionHealth.RECONNECTING) {
                stopSelf()
                return
            }
            runCatching {
                NotificationManagerCompat.from(this@ObdForegroundService)
                    .notify(NOTIFICATION_ID, buildNotification())
            }
            handler.postDelayed(this, NOTIFICATION_REFRESH_MS)
        }
    }

    override fun onCreate() {
        super.onCreate()
        running = true
        createNotificationChannel()
        startAsForeground(buildNotification())
        handler.post(notificationUpdater)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Re-promote with the currently required service type. This is needed when
        // the user enables optional GPS route recording while the OBD service is
        // already running. No second Bluetooth or GPS engine is created here.
        startAsForeground(buildNotification())
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        handler.removeCallbacks(notificationUpdater)
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun startAsForeground(notification: Notification) {
        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE or
                if (controller.isGpsForegroundLocationEligible()) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        } else {
            0
        }
        ServiceCompat.startForeground(
            this,
            NOTIFICATION_ID,
            notification,
            serviceType
        )
    }

    private fun buildNotification(): Notification {
        val state = controller.state
        val snapshot = state.snapshot
        val contentIntent = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            },
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val fuelDiscoveryActive = state.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME
        val title = when {
            fuelDiscoveryActive -> "LoganOS • Depo taraması"
            state.connected -> "LoganOS • Sürüş aktif"
            state.connectionHealth == ObdConnectionHealth.RECONNECTING -> "LoganOS • Yeniden bağlanıyor"
            else -> "LoganOS • OBD bağlanıyor"
        }

        val text = when {
            fuelDiscoveryActive -> {
                val percent = state.developerTestProgressPercent?.let { "%$it" } ?: "hazırlanıyor"
                val phase = state.developerTestPhaseText?.takeIf { it.isNotBlank() } ?: "Hazırlık taraması"
                "$phase • $percent"
            }
            state.connected -> {
                val parts = mutableListOf("OBD bağlı")
                snapshot.tripDistanceKm?.let { parts += String.format(Locale.US, "%.1f km", it) }
                snapshot.tripDurationText?.takeIf { it.isNotBlank() }?.let { parts += it }
                if (state.gpsRouteRecording) parts += "GPS rota"
                parts.joinToString(" • ")
            }
            state.connectionHealth == ObdConnectionHealth.RECONNECTING ->
                "Bağlantı koptu • aktif sürüş korunuyor"
            else -> "OBD bağlantısı hazırlanıyor"
        }

        val publicNotification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_obd_connection)
            .setContentTitle("LoganOS aktif")
            .setContentText("Arka plan sürüş hizmeti çalışıyor")
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_obd_connection)
            .setContentTitle(title)
            .setContentText(text)
            .setContentIntent(contentIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(publicNotification)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Arka planda sürüş",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "OBD bağlantısı ve aktif sürüş kaydının arka planda sürdüğünü gösterir"
            setShowBadge(false)
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    companion object {
        private const val CHANNEL_ID = "loganos_background_drive"
        private const val NOTIFICATION_ID = 4900
        private const val NOTIFICATION_REFRESH_MS = 1_000L
        private const val RESULT_CHANNEL_ID = "loganos_diagnostic_results"
        private const val RESULT_NOTIFICATION_ID = 4901

        @Volatile
        private var running: Boolean = false

        fun start(context: Context): Boolean = synchronized(this) {
            val wasRunning = running
            if (!wasRunning) running = true
            runCatching {
                ContextCompat.startForegroundService(
                    context.applicationContext,
                    Intent(context.applicationContext, ObdForegroundService::class.java)
                )
                true
            }.getOrElse {
                if (!wasRunning) running = false
                false
            }
        }

        fun notifyFuelDiscoveryResult(context: Context, completed: Boolean, fileName: String?) {
            val appContext = context.applicationContext
            val manager = appContext.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    RESULT_CHANNEL_ID,
                    "Tanılama testleri",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = "LoganOS tanılama testlerinin tamamlandığını bildirir"
                    setShowBadge(false)
                }
                manager.createNotificationChannel(channel)
            }
            val contentIntent = PendingIntent.getActivity(
                appContext,
                1,
                Intent(appContext, MainActivity::class.java).apply {
                    flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                },
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val notification = NotificationCompat.Builder(appContext, RESULT_CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_obd_connection)
                .setContentTitle(if (completed) "Depo taraması tamamlandı" else "Kısmi depo taraması oluşturuldu")
                .setContentText(fileName ?: "Sonuç paketini LoganOS içinden açabilirsiniz")
                .setContentIntent(contentIntent)
                .setAutoCancel(true)
                .setOnlyAlertOnce(true)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .build()
            runCatching { NotificationManagerCompat.from(appContext).notify(RESULT_NOTIFICATION_ID, notification) }
        }

        fun stop(context: Context) {
            synchronized(this) { running = false }
            context.applicationContext.stopService(
                Intent(context.applicationContext, ObdForegroundService::class.java)
            )
        }
    }
}
