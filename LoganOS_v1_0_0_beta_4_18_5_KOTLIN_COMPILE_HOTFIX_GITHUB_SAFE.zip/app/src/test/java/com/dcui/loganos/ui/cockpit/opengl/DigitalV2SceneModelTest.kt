package com.dcui.loganos.ui.cockpit.opengl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

class DigitalV2SceneModelTest {
    private val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    @Test
    fun projectiveRoadNarrowsMonotonicallyTowardHorizon() {
        scenes.forEach { scene ->
            var previousY = Float.POSITIVE_INFINITY
            var previousWidth = Float.POSITIVE_INFINITY
            for (distance in 0..scene.road.maxDistanceMeters.toInt()) {
                val projected = scene.road.project(distance.toFloat())
                assertTrue("${scene.key}: y at ${distance}m", distance == 0 || projected.yRatio < previousY)
                assertTrue("${scene.key}: width at ${distance}m", distance == 0 || projected.halfWidthRatio < previousWidth)
                previousY = projected.yRatio
                previousWidth = projected.halfWidthRatio
            }
        }
    }

    @Test
    fun followCameraCentersVehicleAndKeepsCentreLineLeft() {
        scenes.forEach { scene ->
            val road = scene.road
            val pose = scene.vehiclePose
            val centerLine = road.project(pose.anchorDistanceMeters)
            val anchor = road.project(pose.anchorDistanceMeters, pose.worldLateralMeters)
            val leftEdge = road.project(pose.anchorDistanceMeters, -road.roadHalfWidthMeters)
            val rightEdge = road.project(pose.anchorDistanceMeters, road.roadHalfWidthMeters)
            assertTrue("${scene.key}: within road", anchor.xRatio in leftEdge.xRatio..rightEdge.xRatio)
            assertEquals("${scene.key}: centred vehicle", 0.5f, anchor.xRatio, 0.015f)
            assertTrue("${scene.key}: line left of vehicle", anchor.xRatio - centerLine.xRatio > 0.12f)
            assertTrue("${scene.key}: contact Y", anchor.yRatio in 0.82f..0.90f)
            assertTrue("${scene.key}: visible size", pose.visibleWidthRatio in 0.29f..0.31f)
        }
    }

    @Test
    fun projectedDashLengthsDecreaseWithoutReGrowing() {
        scenes.forEach { scene ->
            val road = scene.road
            val pattern = road.markings
            var previousLength = Float.POSITIVE_INFINITY
            var start = 0f
            while (start + pattern.dashLengthMeters <= 96f) {
                val near = road.project(start)
                val far = road.project(start + pattern.dashLengthMeters)
                val pixels = abs(near.yRatio - far.yRatio) * DIGITAL_V2_LOGICAL_HEIGHT
                assertTrue("${scene.key}: dash grew at ${start}m", pixels < previousLength)
                assertTrue("${scene.key}: dash became unstable at ${start}m", pixels >= 2.5f)
                previousLength = pixels
                start += pattern.repeatLengthMeters
            }
        }
    }

    @Test
    fun ribbonMeshIsFiniteAndForwardMonotonic() {
        scenes.forEach { scene ->
            val mesh = buildRoadRibbonMesh(
                road = scene.road,
                lateralCenterMeters = 0f,
                visibleWidthMeters = scene.road.markings.centerLineWidthMeters
            )
            assertEquals(386, mesh.vertexCount)
            assertTrue(mesh.vertices.all { it.isFinite() })
            var previousDistance = -1f
            for (index in 0 until mesh.vertexCount step 2) {
                val left = index * 4
                val right = (index + 1) * 4
                assertEquals(mesh.vertices[left + 2], mesh.vertices[right + 2], 0.0001f)
                assertTrue(mesh.vertices[left + 2] >= previousDistance)
                assertEquals(0f, mesh.vertices[left + 3], 0f)
                assertEquals(1f, mesh.vertices[right + 3], 0f)
                previousDistance = mesh.vertices[left + 2]
            }
        }
    }

    @Test
    fun viewportPreservesLogicalAspectWithoutStretching() {
        listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
            val viewport = calculateDigitalV2Viewport(width, height)
            val aspect = viewport.width.toFloat() / viewport.height.toFloat()
            assertEquals(DIGITAL_V2_STAGE_ASPECT_RATIO, aspect, 0.005f)
            assertTrue(viewport.x >= 0 && viewport.y >= 0)
            assertTrue(viewport.x + viewport.width <= width)
            assertTrue(viewport.y + viewport.height <= height)
        }
    }

    @Test
    fun markingsUseOneWorldSpacePattern() {
        scenes.forEach { scene ->
            assertEquals(3f, scene.road.markings.dashLengthMeters, 0.0001f)
            assertEquals(6f, scene.road.markings.gapLengthMeters, 0.0001f)
            assertEquals(9f, scene.road.markings.repeatLengthMeters, 0.0001f)
        }
    }

    @Test
    fun roadPhaseIsContinuousAcrossFormerTenKilometreBoundary() {
        val repeat = 9f
        val before = roadPatternPhaseMeters(9_999.99, repeat)
        val after = roadPatternPhaseMeters(10_000.01, repeat)
        val forwardDelta = positiveModulo((after - before).toDouble(), repeat.toDouble())
        assertEquals(0.02, forwardDelta, 0.0005)
    }

    @Test
    fun windPhasesWrapOnlyAtTheirOwnExactCycles() {
        val cycle = 51f
        val epsilon = 0.01
        val before = windTravelPhaseMeters(10_000.0 - epsilon, cycle)
        val after = windTravelPhaseMeters(10_000.0 + epsilon, cycle)
        val forwardDelta = positiveModulo((after - before).toDouble(), cycle.toDouble())
        assertEquals(epsilon * 2.0 * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER, forwardDelta, 0.0005)
    }
    @Test
    fun allScenesUseContinuousEdgesAndSeparateCityCalibration() {
        scenes.forEach { scene ->
            assertTrue("${scene.key}: edge lines disabled", scene.road.drawEdgeLines)
        }
        assertTrue(
            "City day/night must not share one camera profile",
            DigitalV2SceneModels.CityDay.road !== DigitalV2SceneModels.CityNight.road
        )
        assertTrue(
            "City day/night calibration values must differ",
            DigitalV2SceneModels.CityDay.road.horizonYRatio !=
                DigitalV2SceneModels.CityNight.road.horizonYRatio
        )
    }

    @Test
    fun windRibbonsRemainOutsideRoadAndRoadMotionCoversOnlyAsphalt() {
        scenes.forEach { scene ->
            val road = scene.road
            val wind = scene.wind
            val windCenter = road.roadHalfWidthMeters +
                wind.shoulderOffsetMeters + wind.zoneWidthMeters * 0.5f
            val nearestWindEdge = windCenter - wind.zoneWidthMeters * 0.5f
            assertTrue("${scene.key}: wind overlaps road", nearestWindEdge > road.roadHalfWidthMeters)

            val surface = buildRoadRibbonMesh(
                road = road,
                lateralCenterMeters = 0f,
                visibleWidthMeters = road.roadHalfWidthMeters * 1.94f
            )
            assertTrue("${scene.key}: road motion mesh invalid", surface.vertices.all { it.isFinite() })
        }
    }

    @Test
    fun stoppedStateClearsSmoothedSpeedBeforeWhenDirtyPause() {
        val stopped = nextDigitalV2SmoothedSpeedKmh(
            currentSpeedKmh = 108f,
            targetSpeedKmh = 0f,
            deltaSeconds = 0.016f
        )
        assertEquals(0f, stopped, 0f)

        val restart = nextDigitalV2SmoothedSpeedKmh(
            currentSpeedKmh = stopped,
            targetSpeedKmh = 8f,
            deltaSeconds = 0.016f
        )
        assertTrue("restart must begin near the requested low speed", restart in 0f..2f)
    }

    @Test
    fun shaderDistanceScalingKeepsMediumpRangeSmall() {
        scenes.forEach { scene ->
            val scaledMax = scene.road.maxDistanceMeters * 0.125f
            assertTrue("${scene.key}: shader distance range too large", scaledMax <= 16f)
        }
    }

}
