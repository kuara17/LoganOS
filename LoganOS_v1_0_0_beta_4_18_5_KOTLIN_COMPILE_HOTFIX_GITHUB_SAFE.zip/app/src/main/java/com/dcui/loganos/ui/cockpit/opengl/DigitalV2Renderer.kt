package com.dcui.loganos.ui.cockpit.opengl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * OpenGL ES 2.0 renderer for the Digital V2 visual scene.
 *
 * Compose owns HUD/controls. OpenGL owns the background, a projective road
 * ribbon, shader-generated 3m/6m markings, wind, road contact shadow and car.
 * The GL thread consumes immutable snapshots through [pendingState].
 */
internal class DigitalV2Renderer(
    private val context: Context
) : GLSurfaceView.Renderer {

    private val pendingState = AtomicReference(DigitalV2RenderState.Empty)
    private var activeState = DigitalV2RenderState.Empty

    private var simpleTexturedProgram: SimpleTexturedProgram? = null
    private var vehicleTexturedProgram: VehicleTexturedProgram? = null
    private var solidProgram: SolidProgram? = null
    private var roadMarkingProgram: RoadMarkingProgram? = null
    private var roadSurfaceProgram: RoadSurfaceProgram? = null
    private var windProgram: WindProgram? = null

    private var backgroundTexture: GlTexture? = null
    private var vehicleTexture: GlTexture? = null
    private var shadowTexture: GlTexture? = null
    private var loadedBackgroundRes = 0
    private var loadedVehicleRes = 0
    private var loadedShadowRes = 0
    private var nextBackgroundTextureRetryNanos = 0L
    private var nextVehicleTextureRetryNanos = 0L
    private var nextShadowTextureRetryNanos = 0L
    private var nextRoadMeshRetryNanos = 0L

    private var roadMeshes: RoadMeshSet? = null
    private var loadedRoadSceneKey: DigitalV2SceneKey? = null

    private var lastFrameNanos = 0L
    private var smoothedSpeedKmh = 0f
    private var totalTravelledMeters = 0.0

    /** Reused GL vertex scratch arrays; no per-draw direct buffers are allocated. */
    private val texturedVertexScratch = FloatArray(16)
    private val solidVertexScratch = FloatArray(12)
    private val vehicleLayoutScratch = VehicleLayout()

    fun submitState(state: DigitalV2RenderState) {
        pendingState.set(state)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // A new EGL context invalidates every old GL object name.
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0
        nextBackgroundTextureRetryNanos = 0L
        nextVehicleTextureRetryNanos = 0L
        nextShadowTextureRetryNanos = 0L
        nextRoadMeshRetryNanos = 0L
        roadMeshes = null
        loadedRoadSceneKey = null

        GLES20.glClearColor(0.03f, 0.05f, 0.08f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        // Android bitmaps uploaded through GLUtils are premultiplied-alpha.
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        simpleTexturedProgram = SimpleTexturedProgram()
        vehicleTexturedProgram = VehicleTexturedProgram()
        solidProgram = SolidProgram()
        roadMarkingProgram = RoadMarkingProgram()
        roadSurfaceProgram = RoadSurfaceProgram()
        windProgram = WindProgram()
        lastFrameNanos = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val viewport = calculateDigitalV2Viewport(width, height)
        GLES20.glViewport(viewport.x, viewport.y, viewport.width, viewport.height)
    }

    override fun onDrawFrame(gl: GL10?) {
        activeState = pendingState.get()
        ensureTextures(activeState)
        ensureRoadMeshes(activeState.sceneModel)
        updateClock(activeState)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        drawBackground()
        drawRoadSurfaceMotion(activeState.sceneModel)
        drawRoadMarkings(activeState.sceneModel)
        drawWind(activeState.sceneModel)
        val vehicleLayout = updateVehicleLayout(activeState)
        drawVehicleGroundShadow(activeState, vehicleLayout)
        drawVehicle(activeState, vehicleLayout)

        if (activeState.calibrationVisible) {
            drawCalibration(activeState.sceneModel)
        }
    }

    fun releaseGlResources() {
        releaseTexture(backgroundTexture)
        releaseTexture(vehicleTexture)
        releaseTexture(shadowTexture)
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0

        roadMeshes?.release()
        roadMeshes = null
        loadedRoadSceneKey = null
        nextRoadMeshRetryNanos = 0L

        simpleTexturedProgram?.release()
        vehicleTexturedProgram?.release()
        solidProgram?.release()
        roadMarkingProgram?.release()
        roadSurfaceProgram?.release()
        windProgram?.release()
        simpleTexturedProgram = null
        vehicleTexturedProgram = null
        solidProgram = null
        roadMarkingProgram = null
        roadSurfaceProgram = null
        windProgram = null
    }

    private fun updateClock(state: DigitalV2RenderState) {
        val now = System.nanoTime()
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now
            smoothedSpeedKmh = if (state.motionEnabled) {
                state.speedKmh.coerceAtLeast(0f)
            } else {
                0f
            }
            return
        }
        val dtSeconds = ((now - lastFrameNanos) / 1_000_000_000.0)
            .toFloat()
            .coerceIn(0f, 0.05f)
        lastFrameNanos = now

        val targetSpeed = if (state.motionEnabled) {
            state.speedKmh.coerceIn(0f, 180f)
        } else {
            0f
        }
        smoothedSpeedKmh = nextDigitalV2SmoothedSpeedKmh(
            currentSpeedKmh = smoothedSpeedKmh,
            targetSpeedKmh = targetSpeed,
            deltaSeconds = dtSeconds
        )

        if (smoothedSpeedKmh >= DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH) {
            totalTravelledMeters +=
                (smoothedSpeedKmh.toDouble() / 3.6) * dtSeconds.toDouble()
        }
    }

    private fun ensureTextures(state: DigitalV2RenderState) {
        val now = System.nanoTime()

        if (state.backgroundResId == 0) {
            releaseTexture(backgroundTexture)
            backgroundTexture = null
            loadedBackgroundRes = 0
        } else if ((state.backgroundResId != loadedBackgroundRes || backgroundTexture == null) &&
            now >= nextBackgroundTextureRetryNanos
        ) {
            val candidate = loadTexture(state.backgroundResId)
            if (candidate != null) {
                releaseTexture(backgroundTexture)
                backgroundTexture = candidate
                loadedBackgroundRes = state.backgroundResId
                nextBackgroundTextureRetryNanos = 0L
            } else {
                nextBackgroundTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }

        if (state.vehicleResId == 0) {
            releaseTexture(vehicleTexture)
            vehicleTexture = null
            loadedVehicleRes = 0
        } else if ((state.vehicleResId != loadedVehicleRes || vehicleTexture == null) &&
            now >= nextVehicleTextureRetryNanos
        ) {
            val candidate = loadTexture(state.vehicleResId)
            if (candidate != null) {
                releaseTexture(vehicleTexture)
                vehicleTexture = candidate
                loadedVehicleRes = state.vehicleResId
                nextVehicleTextureRetryNanos = 0L
            } else {
                nextVehicleTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }

        if (state.shadowResId == 0) {
            releaseTexture(shadowTexture)
            shadowTexture = null
            loadedShadowRes = 0
        } else if ((state.shadowResId != loadedShadowRes || shadowTexture == null) &&
            now >= nextShadowTextureRetryNanos
        ) {
            val candidate = loadTexture(state.shadowResId)
            if (candidate != null) {
                releaseTexture(shadowTexture)
                shadowTexture = candidate
                loadedShadowRes = state.shadowResId
                nextShadowTextureRetryNanos = 0L
            } else {
                nextShadowTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }
    }

    private fun ensureRoadMeshes(scene: DigitalV2SceneModel) {
        if (loadedRoadSceneKey == scene.key && roadMeshes != null) return
        val now = System.nanoTime()
        if (now < nextRoadMeshRetryNanos) return
        val candidate = try {
            RoadMeshSet.create(scene)
        } catch (error: RuntimeException) {
            Log.e(TAG, "Road mesh upload failed for ${scene.key}", error)
            null
        } catch (error: OutOfMemoryError) {
            Log.e(TAG, "Road mesh allocation failed for ${scene.key}", error)
            null
        }
        if (candidate != null) {
            roadMeshes?.release()
            roadMeshes = candidate
            loadedRoadSceneKey = scene.key
            nextRoadMeshRetryNanos = 0L
        } else {
            nextRoadMeshRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
        }
    }

    private fun drawBackground() {
        val texture = backgroundTexture ?: return
        drawSimpleTexturedQuad(
            texture = texture,
            centerX = DIGITAL_V2_LOGICAL_WIDTH * 0.5f,
            centerY = DIGITAL_V2_LOGICAL_HEIGHT * 0.5f,
            width = DIGITAL_V2_LOGICAL_WIDTH,
            height = DIGITAL_V2_LOGICAL_HEIGHT,
            rotationDegrees = 0f,
            alpha = 1f,
            colorMultiplier = WHITE
        )
    }

    private fun drawRoadSurfaceMotion(scene: DigitalV2SceneModel) {
        val profile = scene.roadMotion
        if (!profile.enabled || !activeState.motionEnabled ||
            smoothedSpeedKmh < ROAD_SURFACE_MIN_SPEED_KMH
        ) return
        val mesh = roadMeshes?.roadSurface ?: return
        val strength = ((smoothedSpeedKmh - ROAD_SURFACE_MIN_SPEED_KMH) / 90f)
            .coerceIn(0f, 1f)
        roadSurfaceProgram?.draw(
            mesh = mesh,
            phaseMeters = roadSurfacePhaseMeters(
                totalTravelledMeters,
                profile.cycleLengthMeters
            ),
            cycleLengthMeters = profile.cycleLengthMeters,
            nearFadeDistanceMeters = profile.nearFadeDistanceMeters,
            alpha = profile.maxAlpha * strength,
            tint = ROAD_SURFACE_TINT
        )
    }

    /**
     * One continuous VBO is rendered for the centre line. The 3m dash / 6m gap
     * pattern is generated in the fragment shader from world distance, so dash
     * shape never stretches independently or stalls at calibration knots.
     */
    private fun drawRoadMarkings(scene: DigitalV2SceneModel) {
        val program = roadMarkingProgram ?: return
        val meshes = roadMeshes ?: return
        val road = scene.road
        val pattern = road.markings
        val phase = roadPatternPhaseMeters(totalTravelledMeters, pattern.repeatLengthMeters)

        program.draw(
            mesh = meshes.center,
            color = road.centerLineColor,
            dashed = true,
            phaseMeters = phase,
            pattern = pattern
        )

        if (road.showLeftEdgeLine || road.showRightEdgeLine) {
            meshes.leftEdge?.let {
                program.draw(
                    mesh = it,
                    color = road.leftEdgeLineColor,
                    dashed = false,
                    phaseMeters = 0f,
                    pattern = pattern
                )
            }
            meshes.rightEdge?.let {
                program.draw(
                    mesh = it,
                    color = road.rightEdgeLineColor,
                    dashed = false,
                    phaseMeters = 0f,
                    pattern = pattern
                )
            }
        }
    }

    private fun drawWind(scene: DigitalV2SceneModel) {
        val wind = scene.wind
        if (!wind.enabled || !activeState.motionEnabled || smoothedSpeedKmh < 8f) return
        val meshes = roadMeshes ?: return
        val strength = ((smoothedSpeedKmh - 8f) / 92f).coerceIn(0f, 1f)
        val phase = windTravelPhaseMeters(totalTravelledMeters, wind.spacingMeters)
        val pulse = windPulsePhaseRadians(totalTravelledMeters)
        meshes.leftWind?.let { mesh ->
            windProgram?.draw(
                mesh = mesh,
                phaseMeters = phase,
                spacingMeters = wind.spacingMeters,
                streakLengthMeters = wind.streakLengthMeters,
                pulseRadians = pulse,
                alpha = wind.maxAlpha * strength,
                sideSign = -1f
            )
        }
        meshes.rightWind?.let { mesh ->
            windProgram?.draw(
                mesh = mesh,
                phaseMeters = phase,
                spacingMeters = wind.spacingMeters,
                streakLengthMeters = wind.streakLengthMeters,
                pulseRadians = pulse,
                alpha = wind.maxAlpha * strength,
                sideSign = 1f
            )
        }
    }

    private class VehicleLayout {
        var anchorX = 0f
        var anchorY = 0f
        var fullTextureWidth = 0f
        var fullTextureHeight = 0f
        var top = 0f
        var leftTireX = 0f
        var leftTireY = 0f
        var rightTireX = 0f
        var rightTireY = 0f
    }

    private fun updateVehicleLayout(state: DigitalV2RenderState): VehicleLayout {
        val pose = state.sceneModel.vehiclePose
        val asset = state.vehicleAsset
        val layout = vehicleLayoutScratch
        layout.anchorX = pose.centerXRatio * DIGITAL_V2_LOGICAL_WIDTH
        layout.anchorY = pose.tireContactYRatio * DIGITAL_V2_LOGICAL_HEIGHT
        layout.fullTextureWidth = DIGITAL_V2_LOGICAL_WIDTH *
            (pose.visibleWidthRatio / asset.visibleWidthRatioInTexture)
        layout.fullTextureHeight = layout.fullTextureWidth * asset.textureAspectHeightOverWidth
        layout.top = layout.anchorY - layout.fullTextureHeight * asset.contactYRatioInTexture

        // Store unrotated tyre contacts. Every quad rotates exactly once around
        // the common road-contact anchor inside writeTexturedQuadVertices().
        layout.leftTireX = layout.anchorX +
            (asset.leftTireContactXRatioInTexture - 0.5f) * layout.fullTextureWidth
        layout.leftTireY = layout.anchorY
        layout.rightTireX = layout.anchorX +
            (asset.rightTireContactXRatioInTexture - 0.5f) * layout.fullTextureWidth
        layout.rightTireY = layout.anchorY
        return layout
    }

    private fun drawVehicleGroundShadow(
        state: DigitalV2RenderState,
        layout: VehicleLayout
    ) {
        val texture = shadowTexture ?: return
        val pose = state.sceneModel.vehiclePose
        val shadow = pose.shadow
        val offsetX = shadow.offsetXRatio * DIGITAL_V2_LOGICAL_WIDTH
        val offsetY = shadow.offsetYRatio * DIGITAL_V2_LOGICAL_HEIGHT

        // Broad low-opacity body shadow. It stays on the road anchor while the
        // vehicle sprite may later receive subtle suspension motion.
        drawSimpleTexturedQuad(
            texture = texture,
            centerX = layout.anchorX + offsetX,
            centerY = layout.anchorY + offsetY,
            width = DIGITAL_V2_LOGICAL_WIDTH * shadow.bodyWidthRatio,
            height = DIGITAL_V2_LOGICAL_WIDTH * shadow.bodyHeightRatio,
            rotationDegrees = pose.headingDegrees,
            alpha = shadow.bodyAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = layout.anchorX,
            rotationPivotY = layout.anchorY
        )

        // Darker local tyre contacts remove the final transparent-PNG gap.
        val tireWidth = DIGITAL_V2_LOGICAL_WIDTH * shadow.tireWidthRatio
        val tireHeight = DIGITAL_V2_LOGICAL_WIDTH * shadow.tireHeightRatio
        drawSimpleTexturedQuad(
            texture = texture,
            centerX = layout.leftTireX + offsetX,
            centerY = layout.leftTireY + offsetY * 0.35f,
            width = tireWidth,
            height = tireHeight,
            rotationDegrees = pose.headingDegrees,
            alpha = shadow.tireAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = layout.anchorX,
            rotationPivotY = layout.anchorY
        )
        drawSimpleTexturedQuad(
            texture = texture,
            centerX = layout.rightTireX + offsetX,
            centerY = layout.rightTireY + offsetY * 0.35f,
            width = tireWidth,
            height = tireHeight,
            rotationDegrees = pose.headingDegrees,
            alpha = shadow.tireAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = layout.anchorX,
            rotationPivotY = layout.anchorY
        )

        // A small, very soft road-colour blend directly under the axle prevents
        // a hard cut between tyre pixels and the photographed asphalt.
        drawSimpleTexturedQuad(
            texture = texture,
            centerX = layout.anchorX + offsetX,
            centerY = layout.anchorY + offsetY * 0.25f,
            width = DIGITAL_V2_LOGICAL_WIDTH * shadow.groundBlendWidthRatio,
            height = DIGITAL_V2_LOGICAL_WIDTH * shadow.groundBlendHeightRatio,
            rotationDegrees = pose.headingDegrees,
            alpha = shadow.groundBlendAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = layout.anchorX,
            rotationPivotY = layout.anchorY
        )
    }

    private fun drawVehicle(
        state: DigitalV2RenderState,
        layout: VehicleLayout
    ) {
        val texture = vehicleTexture ?: return
        val pose = state.sceneModel.vehiclePose
        drawVehicleTexturedQuad(
            texture = texture,
            centerX = layout.anchorX,
            centerY = layout.top + layout.fullTextureHeight * 0.5f,
            width = layout.fullTextureWidth,
            height = layout.fullTextureHeight,
            rotationDegrees = pose.headingDegrees,
            alpha = 1f,
            colorMultiplier = WHITE,
            grade = pose.colorGrade,
            rotationPivotX = layout.anchorX,
            rotationPivotY = layout.anchorY
        )
    }

    private fun drawCalibration(scene: DigitalV2SceneModel) {
        var distance = 0f
        while (distance <= scene.road.maxDistanceMeters) {
            listOf(
                scene.road.leftRoadEdge.sample(distance),
                scene.road.centerLine.sample(distance),
                scene.road.rightRoadEdge.sample(distance)
            ).forEach { point ->
                val center = LogicalPoint(
                    point.x * DIGITAL_V2_LOGICAL_WIDTH,
                    point.y * DIGITAL_V2_LOGICAL_HEIGHT
                )
                drawSolidQuad(
                    LogicalPoint(center.x - 3f, center.y - 3f),
                    LogicalPoint(center.x + 3f, center.y - 3f),
                    LogicalPoint(center.x + 3f, center.y + 3f),
                    LogicalPoint(center.x - 3f, center.y + 3f),
                    MAGENTA
                )
            }
            distance += 10f
        }

        val anchorX = scene.vehiclePose.centerXRatio * DIGITAL_V2_LOGICAL_WIDTH
        val anchorY = scene.vehiclePose.tireContactYRatio * DIGITAL_V2_LOGICAL_HEIGHT
        drawSegmentQuad(
            start = LogicalPoint(anchorX - 26f, anchorY),
            end = LogicalPoint(anchorX + 26f, anchorY),
            widthPixels = 3f,
            color = GREEN
        )
    }

    private fun drawSimpleTexturedQuad(
        texture: GlTexture,
        centerX: Float,
        centerY: Float,
        width: Float,
        height: Float,
        rotationDegrees: Float,
        alpha: Float,
        colorMultiplier: GlColor,
        rotationPivotX: Float = centerX,
        rotationPivotY: Float = centerY
    ) {
        writeTexturedQuadVertices(
            centerX, centerY, width, height, rotationDegrees,
            rotationPivotX, rotationPivotY
        )
        simpleTexturedProgram?.draw(texture, texturedVertexScratch, alpha, colorMultiplier)
    }

    private fun drawVehicleTexturedQuad(
        texture: GlTexture,
        centerX: Float,
        centerY: Float,
        width: Float,
        height: Float,
        rotationDegrees: Float,
        alpha: Float,
        colorMultiplier: GlColor,
        grade: VehicleColorGrade,
        rotationPivotX: Float = centerX,
        rotationPivotY: Float = centerY
    ) {
        writeTexturedQuadVertices(
            centerX, centerY, width, height, rotationDegrees,
            rotationPivotX, rotationPivotY
        )
        vehicleTexturedProgram?.draw(
            texture, texturedVertexScratch, alpha, colorMultiplier, grade
        )
    }

    private fun writeTexturedQuadVertices(
        centerX: Float,
        centerY: Float,
        width: Float,
        height: Float,
        rotationDegrees: Float,
        rotationPivotX: Float,
        rotationPivotY: Float
    ) {
        val halfW = width * 0.5f
        val halfH = height * 0.5f
        val radians = rotationDegrees * PI.toFloat() / 180f
        val cosAngle = cos(radians)
        val sinAngle = sin(radians)

        fun writeCorner(outputIndex: Int, localX: Float, localY: Float, u: Float, v: Float) {
            val unrotatedX = centerX + localX
            val unrotatedY = centerY + localY
            val relativeX = unrotatedX - rotationPivotX
            val relativeY = unrotatedY - rotationPivotY
            val x = rotationPivotX + relativeX * cosAngle - relativeY * sinAngle
            val y = rotationPivotY + relativeX * sinAngle + relativeY * cosAngle
            texturedVertexScratch[outputIndex] = x / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
            texturedVertexScratch[outputIndex + 1] = 1f - y / DIGITAL_V2_LOGICAL_HEIGHT * 2f
            texturedVertexScratch[outputIndex + 2] = u
            texturedVertexScratch[outputIndex + 3] = v
        }

        writeCorner(0, -halfW, -halfH, 0f, 0f)
        writeCorner(4, -halfW, halfH, 0f, 1f)
        writeCorner(8, halfW, -halfH, 1f, 0f)
        writeCorner(12, halfW, halfH, 1f, 1f)
    }

    private fun drawSolidQuad(
        p1: LogicalPoint,
        p2: LogicalPoint,
        p3: LogicalPoint,
        p4: LogicalPoint,
        color: GlColor
    ) {
        writeNdc(solidVertexScratch, 0, p1)
        writeNdc(solidVertexScratch, 2, p2)
        writeNdc(solidVertexScratch, 4, p3)
        writeNdc(solidVertexScratch, 6, p1)
        writeNdc(solidVertexScratch, 8, p3)
        writeNdc(solidVertexScratch, 10, p4)
        solidProgram?.draw(solidVertexScratch, color)
    }

    private fun writeNdc(array: FloatArray, index: Int, point: LogicalPoint) {
        array[index] = point.x / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
        array[index + 1] = 1f - point.y / DIGITAL_V2_LOGICAL_HEIGHT * 2f
    }

    private fun drawSegmentQuad(
        start: LogicalPoint,
        end: LogicalPoint,
        widthPixels: Float,
        color: GlColor
    ) {
        val dx = end.x - start.x
        val dy = end.y - start.y
        val length = sqrt(dx * dx + dy * dy)
        if (length < 0.01f) return
        val normalX = -dy / length * widthPixels * 0.5f
        val normalY = dx / length * widthPixels * 0.5f
        drawSolidQuad(
            LogicalPoint(start.x + normalX, start.y + normalY),
            LogicalPoint(start.x - normalX, start.y - normalY),
            LogicalPoint(end.x - normalX, end.y - normalY),
            LogicalPoint(end.x + normalX, end.y + normalY),
            color
        )
    }


    private fun loadTexture(resourceId: Int): GlTexture? {
        val options = BitmapFactory.Options().apply {
            inScaled = false
            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
        }
        var bitmap: android.graphics.Bitmap? = null
        var textureId = 0
        return try {
            bitmap = BitmapFactory.decodeResource(context.resources, resourceId, options) ?: return null
            val pixelCount = bitmap.width.toLong() * bitmap.height.toLong()
            if (pixelCount > MAX_TEXTURE_PIXELS) {
                Log.e(
                    TAG,
                    "Texture rejected for resource $resourceId: ${bitmap.width}x${bitmap.height}",
                    IllegalArgumentException("Texture exceeds $MAX_TEXTURE_PIXELS pixels")
                )
                return null
            }

            val names = IntArray(1)
            GLES20.glGenTextures(1, names, 0)
            textureId = names[0]
            if (textureId == 0) return null

            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
            GlTexture(textureId, bitmap.width, bitmap.height)
        } catch (error: RuntimeException) {
            if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            Log.e(TAG, "Texture load failed for resource $resourceId", error)
            null
        } catch (error: OutOfMemoryError) {
            if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            Log.e(TAG, "Texture allocation failed for resource $resourceId", error)
            null
        } finally {
            bitmap?.recycle()
        }
    }

    private fun releaseTexture(texture: GlTexture?) {
        texture ?: return
        GLES20.glDeleteTextures(1, intArrayOf(texture.id), 0)
    }

    private data class LogicalPoint(val x: Float, val y: Float)
    private data class GlTexture(val id: Int, val width: Int, val height: Int)

    private data class RoadMeshBuffer(
        val bufferId: Int,
        val vertexCount: Int
    ) {
        fun release() {
            GLES20.glDeleteBuffers(1, intArrayOf(bufferId), 0)
        }

    companion object {
            fun upload(data: RoadRibbonMeshData): RoadMeshBuffer {
                val names = IntArray(1)
                GLES20.glGenBuffers(1, names, 0)
                check(names[0] != 0) { "Unable to create road VBO" }
                val buffer = allocateFloatBuffer(data.vertices.size)
                buffer.put(data.vertices)
                buffer.position(0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, names[0])
                GLES20.glBufferData(
                    GLES20.GL_ARRAY_BUFFER,
                    data.vertices.size * 4,
                    buffer,
                    GLES20.GL_STATIC_DRAW
                )
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
                return RoadMeshBuffer(names[0], data.vertexCount)
            }
        }
    }

    private data class RoadMeshSet(
        val center: RoadMeshBuffer,
        val leftEdge: RoadMeshBuffer?,
        val rightEdge: RoadMeshBuffer?,
        val roadSurface: RoadMeshBuffer,
        val leftWind: RoadMeshBuffer?,
        val rightWind: RoadMeshBuffer?
    ) {
        fun release() {
            center.release()
            leftEdge?.release()
            rightEdge?.release()
            roadSurface.release()
            leftWind?.release()
            rightWind?.release()
        }

        companion object {
            fun create(scene: DigitalV2SceneModel): RoadMeshSet {
                val created = ArrayList<RoadMeshBuffer>(6)
                fun upload(data: RoadRibbonMeshData): RoadMeshBuffer =
                    RoadMeshBuffer.upload(data).also(created::add)

                try {
                    val road = scene.road
                    val pattern = road.markings
                    val center = upload(
                        buildCalibratedLineMesh(
                            road = road,
                            role = RoadCurveRole.CenterLine,
                            physicalWidthMeters = pattern.centerLineWidthMeters
                        )
                    )
                    val left = if (road.showLeftEdgeLine) {
                        upload(
                            buildCalibratedLineMesh(
                                road = road,
                                role = RoadCurveRole.LeftEdge,
                                physicalWidthMeters = pattern.edgeLineWidthMeters
                            )
                        )
                    } else null
                    val right = if (road.showRightEdgeLine) {
                        upload(
                            buildCalibratedLineMesh(
                                road = road,
                                role = RoadCurveRole.RightEdge,
                                physicalWidthMeters = pattern.edgeLineWidthMeters
                            )
                        )
                    } else null
                    val roadSurface = upload(buildCalibratedRoadSurfaceMesh(road))
                    val wind = scene.wind
                    val leftWind = if (wind.enabled) {
                        upload(buildCalibratedWindZoneMesh(road, wind, RoadSide.Left))
                    } else null
                    val rightWind = if (wind.enabled) {
                        upload(buildCalibratedWindZoneMesh(road, wind, RoadSide.Right))
                    } else null
                    return RoadMeshSet(center, left, right, roadSurface, leftWind, rightWind)
                } catch (error: Throwable) {
                    created.forEach(RoadMeshBuffer::release)
                    throw error
                }
            }
        }
    }

    private class SimpleTexturedProgram {
        private val programId = createProgram(
            DigitalV2Shaders.TEXTURED_VERTEX_SHADER,
            DigitalV2Shaders.SIMPLE_TEXTURED_FRAGMENT_SHADER
        )
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val textureCoordinateHandle = GLES20.glGetAttribLocation(programId, "aTexCoord")
        private val textureHandle = GLES20.glGetUniformLocation(programId, "uTexture")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val colorMultiplierHandle = GLES20.glGetUniformLocation(programId, "uColorMultiplier")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(16)

        fun draw(
            texture: GlTexture,
            vertices: FloatArray,
            alpha: Float,
            colorMultiplier: GlColor
        ) {
            GLES20.glUseProgram(programId)
            bindTexturedVertices(vertexBuffer, vertices, positionHandle, textureCoordinateHandle)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture.id)
            GLES20.glUniform1i(textureHandle, 0)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 1f))
            GLES20.glUniform4f(
                colorMultiplierHandle,
                colorMultiplier.red,
                colorMultiplier.green,
                colorMultiplier.blue,
                colorMultiplier.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            unbindTexturedVertices(positionHandle, textureCoordinateHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class VehicleTexturedProgram {
        private val programId = createProgram(
            DigitalV2Shaders.TEXTURED_VERTEX_SHADER,
            DigitalV2Shaders.VEHICLE_FRAGMENT_SHADER
        )
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val textureCoordinateHandle = GLES20.glGetAttribLocation(programId, "aTexCoord")
        private val textureHandle = GLES20.glGetUniformLocation(programId, "uTexture")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val colorMultiplierHandle = GLES20.glGetUniformLocation(programId, "uColorMultiplier")
        private val textureInfoHandle = GLES20.glGetUniformLocation(programId, "uTextureInfo")
        private val gradeHandle = GLES20.glGetUniformLocation(programId, "uGrade")
        private val gradeRgbHandle = GLES20.glGetUniformLocation(programId, "uGradeRgb")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(16)

        fun draw(
            texture: GlTexture,
            vertices: FloatArray,
            alpha: Float,
            colorMultiplier: GlColor,
            grade: VehicleColorGrade
        ) {
            GLES20.glUseProgram(programId)
            bindTexturedVertices(vertexBuffer, vertices, positionHandle, textureCoordinateHandle)
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, texture.id)
            GLES20.glUniform1i(textureHandle, 0)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 1f))
            GLES20.glUniform4f(
                colorMultiplierHandle,
                colorMultiplier.red,
                colorMultiplier.green,
                colorMultiplier.blue,
                colorMultiplier.alpha
            )
            GLES20.glUniform4f(
                textureInfoHandle,
                1f / max(1, texture.width).toFloat(),
                1f / max(1, texture.height).toFloat(),
                grade.edgeSoftness,
                0f
            )
            GLES20.glUniform4f(
                gradeHandle,
                grade.exposure,
                grade.contrast,
                grade.saturation,
                grade.edgeSoftness
            )
            GLES20.glUniform4f(
                gradeRgbHandle,
                grade.redMultiplier,
                grade.greenMultiplier,
                grade.blueMultiplier,
                1f
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            unbindTexturedVertices(positionHandle, textureCoordinateHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class SolidProgram {
        private val programId = createProgram(DigitalV2Shaders.SOLID_VERTEX_SHADER, DigitalV2Shaders.SOLID_FRAGMENT_SHADER)
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(12)

        fun draw(vertices: FloatArray, color: GlColor) {
            vertexBuffer.clear()
            vertexBuffer.put(vertices, 0, 12)
            vertexBuffer.position(0)

            GLES20.glUseProgram(programId)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                8,
                vertexBuffer
            )
            GLES20.glUniform4f(
                colorHandle,
                color.red,
                color.green,
                color.blue,
                color.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    private class RoadSurfaceProgram {
        private val programId = createProgram(
            DigitalV2Shaders.ROAD_SURFACE_VERTEX_SHADER,
            DigitalV2Shaders.ROAD_SURFACE_FRAGMENT_SHADER
        )
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val cycleHandle = GLES20.glGetUniformLocation(programId, "uCycleMeters")
        private val nearFadeHandle = GLES20.glGetUniformLocation(programId, "uNearFadeMeters")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val tintHandle = GLES20.glGetUniformLocation(programId, "uTint")

        fun draw(
            mesh: RoadMeshBuffer,
            phaseMeters: Float,
            cycleLengthMeters: Float,
            nearFadeDistanceMeters: Float,
            alpha: Float,
            tint: GlColor
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, positionHandle, distanceHandle, acrossHandle)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(cycleHandle, cycleLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(nearFadeHandle, nearFadeDistanceMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 0.10f))
            GLES20.glUniform3f(tintHandle, tint.red, tint.green, tint.blue)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)
            unbindRoadMesh(positionHandle, distanceHandle, acrossHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class WindProgram {
        private val programId = createProgram(
            DigitalV2Shaders.WIND_VERTEX_SHADER,
            DigitalV2Shaders.WIND_FRAGMENT_SHADER
        )
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val spacingHandle = GLES20.glGetUniformLocation(programId, "uSpacingMeters")
        private val lengthHandle = GLES20.glGetUniformLocation(programId, "uStreakLengthMeters")
        private val pulseHandle = GLES20.glGetUniformLocation(programId, "uPulseRadians")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val sideHandle = GLES20.glGetUniformLocation(programId, "uSideSign")

        fun draw(
            mesh: RoadMeshBuffer,
            phaseMeters: Float,
            spacingMeters: Float,
            streakLengthMeters: Float,
            pulseRadians: Float,
            alpha: Float,
            sideSign: Float
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, positionHandle, distanceHandle, acrossHandle)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(spacingHandle, spacingMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(lengthHandle, streakLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(pulseHandle, pulseRadians)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 0.30f))
            GLES20.glUniform1f(sideHandle, sideSign)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)
            unbindRoadMesh(positionHandle, distanceHandle, acrossHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class RoadMarkingProgram {
        private val programId = createProgram(
            DigitalV2Shaders.ROAD_VERTEX_SHADER,
            DigitalV2Shaders.ROAD_FRAGMENT_SHADER
        )
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val repeatHandle = GLES20.glGetUniformLocation(programId, "uRepeatMeters")
        private val dashLengthHandle = GLES20.glGetUniformLocation(programId, "uDashLengthMeters")
        private val dashSoftnessHandle = GLES20.glGetUniformLocation(programId, "uDashSoftnessMeters")
        private val sideSoftnessHandle = GLES20.glGetUniformLocation(programId, "uSideSoftness")
        private val dashedHandle = GLES20.glGetUniformLocation(programId, "uDashed")

        fun draw(
            mesh: RoadMeshBuffer,
            color: GlColor,
            dashed: Boolean,
            phaseMeters: Float,
            pattern: RoadMarkingPattern
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, positionHandle, distanceHandle, acrossHandle)
            GLES20.glUniform4f(colorHandle, color.red, color.green, color.blue, color.alpha)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(repeatHandle, pattern.repeatLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(dashLengthHandle, pattern.dashLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(dashSoftnessHandle, pattern.dashEdgeSoftnessMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(sideSoftnessHandle, pattern.sideEdgeSoftness)
            GLES20.glUniform1f(dashedHandle, if (dashed) 1f else 0f)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)
            unbindRoadMesh(positionHandle, distanceHandle, acrossHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    companion object {
        private const val TAG = "DigitalV2Renderer"
        private const val ROAD_VERTEX_STRIDE_BYTES = 16
        private const val ROAD_SHADER_DISTANCE_SCALE = 0.125f
        private const val TEXTURE_RETRY_DELAY_NANOS = 1_000_000_000L
        private const val MAX_TEXTURE_PIXELS = 3_000_000L
        private const val ROAD_SURFACE_MIN_SPEED_KMH = 12f
        private val ROAD_SURFACE_TINT = GlColor(0.70f, 0.76f, 0.82f, 1f)
        private val WHITE = GlColor(1f, 1f, 1f, 1f)
        private val MAGENTA = GlColor(1f, 0f, 0.75f, 0.95f)
        private val GREEN = GlColor(0.1f, 1f, 0.3f, 0.95f)

        private fun bindTexturedVertices(
            buffer: FloatBuffer,
            vertices: FloatArray,
            positionHandle: Int,
            textureCoordinateHandle: Int
        ) {
            buffer.clear()
            buffer.put(vertices, 0, 16)
            buffer.position(0)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle, 2, GLES20.GL_FLOAT, false, 16, buffer
            )
            buffer.position(2)
            GLES20.glEnableVertexAttribArray(textureCoordinateHandle)
            GLES20.glVertexAttribPointer(
                textureCoordinateHandle, 2, GLES20.GL_FLOAT, false, 16, buffer
            )
        }

        private fun unbindTexturedVertices(
            positionHandle: Int,
            textureCoordinateHandle: Int
        ) {
            GLES20.glDisableVertexAttribArray(positionHandle)
            GLES20.glDisableVertexAttribArray(textureCoordinateHandle)
        }

        private fun bindRoadMesh(
            mesh: RoadMeshBuffer,
            worldPositionHandle: Int,
            distanceHandle: Int,
            acrossHandle: Int
        ) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, mesh.bufferId)
            GLES20.glEnableVertexAttribArray(worldPositionHandle)
            GLES20.glVertexAttribPointer(worldPositionHandle, 2, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 0)
            GLES20.glEnableVertexAttribArray(distanceHandle)
            GLES20.glVertexAttribPointer(distanceHandle, 1, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 8)
            GLES20.glEnableVertexAttribArray(acrossHandle)
            GLES20.glVertexAttribPointer(acrossHandle, 1, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 12)
        }

        private fun unbindRoadMesh(worldPositionHandle: Int, distanceHandle: Int, acrossHandle: Int) {
            GLES20.glDisableVertexAttribArray(worldPositionHandle)
            GLES20.glDisableVertexAttribArray(distanceHandle)
            GLES20.glDisableVertexAttribArray(acrossHandle)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        }

        private fun createProgram(vertexSource: String, fragmentSource: String): Int {
            val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
            val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
            val program = GLES20.glCreateProgram()
            check(program != 0) { "Unable to create OpenGL program" }
            GLES20.glAttachShader(program, vertexShader)
            GLES20.glAttachShader(program, fragmentShader)
            GLES20.glLinkProgram(program)
            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(program)
                GLES20.glDeleteProgram(program)
                error("OpenGL program link failed: $log")
            }
            GLES20.glDeleteShader(vertexShader)
            GLES20.glDeleteShader(fragmentShader)
            return program
        }

        private fun compileShader(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            check(shader != 0) { "Unable to create OpenGL shader" }
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val compileStatus = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
            if (compileStatus[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                error("OpenGL shader compile failed: $log")
            }
            return shader
        }

        private fun allocateFloatBuffer(floatCount: Int): FloatBuffer =
            ByteBuffer.allocateDirect(floatCount * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
    }
}
