package com.dcui.loganos.ui.cockpit.opengl

import com.dcui.loganos.model.VehicleVisualModel

/** Immutable UI-to-renderer snapshot. No Compose state is read on the GL thread. */
internal data class DigitalV2RenderState(
    val sceneKey: DigitalV2SceneKey,
    val backgroundResId: Int,
    val vehicleResId: Int,
    val shadowResId: Int,
    val vehicleAsset: VehicleAssetProfile,
    val speedKmh: Float,
    val rpm: Float,
    val motionEnabled: Boolean,
    val calibrationVisible: Boolean = false
) {
    val sceneModel: DigitalV2SceneModel
        get() = DigitalV2SceneModels.forKey(sceneKey)

    companion object {
        val Empty = DigitalV2RenderState(
            sceneKey = DigitalV2SceneKey.MountainLake,
            backgroundResId = 0,
            vehicleResId = 0,
            shadowResId = 0,
            vehicleAsset = digitalV2VehicleAssetProfile(VehicleVisualModel.LoganI),
            speedKmh = 0f,
            rpm = 0f,
            motionEnabled = false
        )
    }
}
