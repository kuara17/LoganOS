package com.dcui.loganos.model

import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.sin

enum class AppLanguage(val label: String, val englishLabel: String) {
    Turkish("Türkçe", "Turkish"),
    English("English", "English")
}

enum class DeviceMode(val label: String) {
    Auto("Otomatik"),
    Phone("Telefon"),
    HeadUnit("Android Multimedya / Double")
}

enum class HeadUnitUiMode(val trLabel: String, val enLabel: String) {
    Standard("Standart Kokpit", "Standard Cockpit"),
    PremiumDrive("Premium Drive", "Premium Drive")
}

enum class DefaultMediaApp(val trLabel: String, val enLabel: String, val packageName: String) {
    Aimp("AIMP", "AIMP", "com.aimp.player"),
    JancarMusic("Jancar Music", "Jancar Music", "com.jancar.music")
}

enum class Brand(val label: String) {
    Dacia("Dacia"),
    Renault("Renault")
}

enum class FuelType(val trLabel: String, val enLabel: String) {
    Diesel("Dizel", "Diesel"),
    Petrol("Benzin", "Petrol")
}

enum class VehicleProfileSupport {
    Verified,
    Experimental
}


enum class VehicleVisualModel(val trLabel: String, val enLabel: String) {
    LoganI("Logan I", "Logan I"),
    LoganIII("Logan III", "Logan III")
}

enum class VehicleColor(val trLabel: String, val enLabel: String) {
    CherryRed("Kiraz kırmızısı", "Cherry red"),
    White("Beyaz", "White"),
    Gray("Gri", "Gray"),
    Blue("Mavi", "Blue"),
    Green("Yeşil", "Green"),
    Yellow("Sarı", "Yellow")
}

enum class GaugeStyle(val label: String) {
    Digital("Digital"),
    DigitalV2("Digital V2"),
    ClassicOem("Classic OEM"),
    GhostSingle("Ghost Single"),
    GhostDual("Ghost Dual")
}

enum class DigitalV2GaugeMode(val trLabel: String, val enLabel: String) {
    Speed("Hız kadranı", "Speed gauge"),
    Rpm("Devir kadranı", "RPM gauge")
}

enum class DigitalV2Scene(
    val trLabel: String,
    val enLabel: String,
    val available: Boolean
) {
    MountainLake("Dağ-Göl", "Mountain-Lake", true),
    CityDay("Şehir Gündüz", "City Day", true),
    CityNight("Şehir Gece", "City Night", true),
    SnowRoad("Karlı Yol", "Snow Road", true)
}

enum class CockpitTextSize(val trLabel: String, val enLabel: String) {
    Small("Küçük", "Small"),
    Normal("Normal", "Normal"),
    Large("Büyük", "Large")
}

enum class TripMetricReset {
    Average,
    Cost,
    AverageAndCost
}

enum class CockpitDensity(val trLabel: String, val enLabel: String) {
    Compact("Kompakt", "Compact"),
    Balanced("Dengeli", "Balanced"),
    Wide("Konforlu", "Comfortable")
}

enum class AccentColor(val label: String, val color: Color) {
    OemGreen("OEM Green", Color(0xFF1FAD55)),
    TechBlue("Tech Blue", Color(0xFF207DFF)),
    SportOrange("Sport Orange", Color(0xFFFF8A00)),
    RsRed("RS Red", Color(0xFFFF3B30)),
    NeoPurple("Neo Purple", Color(0xFF9B5CFF)),
    GoldEdition("Gold Edition", Color(0xFFFFC107))
}

enum class MenuTheme(val trLabel: String, val enLabel: String) {
    Light("Açık", "Light"),
    SoftGray("Yumuşak gri", "Soft gray"),
    BlueGray("Mavi gri", "Blue gray"),
    Dark("Koyu", "Dark"),
    System("Sistemle eşleştir", "Follow system")
}

data class LoganSettings(
    val setupCompleted: Boolean = false,
    val language: AppLanguage = AppLanguage.Turkish,
    val brand: Brand = Brand.Dacia,
    val vehicleModel: String = "Dacia Logan",
    val engine: String = "1.5 dCi 68 bg",
    val fuelType: FuelType = FuelType.Diesel,
    val profileSupport: VehicleProfileSupport = VehicleProfileSupport.Verified,
    val modelYearText: String = "2006",
    val engineCodeText: String = "K9K",
    val engineDisplacementCcText: String = "1461",
    val enginePowerHpText: String = "68",
    val cylinderCount: Int = 4,
    val experimentalProfileAccepted: Boolean = false,
    val deviceMode: DeviceMode = DeviceMode.Auto,
    val headUnitUiMode: HeadUnitUiMode = HeadUnitUiMode.Standard,
    val defaultMediaApp: DefaultMediaApp = DefaultMediaApp.Aimp,
    val gaugeStyle: GaugeStyle = GaugeStyle.Digital,
    val digitalV2GaugeMode: DigitalV2GaugeMode = DigitalV2GaugeMode.Speed,
    val digitalV2Scene: DigitalV2Scene = DigitalV2Scene.MountainLake,
    val digitalV2MotionEnabled: Boolean = true,
    val vehicleVisualModel: VehicleVisualModel = VehicleVisualModel.LoganI,
    val vehicleColor: VehicleColor = VehicleColor.CherryRed,
    val ghostDualSpeedOnLeft: Boolean = false,
    val cockpitTextSize: CockpitTextSize = CockpitTextSize.Normal,
    val cockpitDensity: CockpitDensity = CockpitDensity.Balanced,
    val accentColor: AccentColor = AccentColor.OemGreen,
    val menuTheme: MenuTheme = MenuTheme.Light,
    // Kept for backward-compatible backup restore; new UI uses menuTheme.
    val darkMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val backgroundTripEnabled: Boolean = true,
    val gpsRouteEnabled: Boolean = false,
    val gpsMaskExportEdges: Boolean = true,
    val smartTripMinutes: Int = 60,
    val driveHistoryEnabled: Boolean = true,
    val driveHistoryLimit: Int = 10,
    val testHistoryEnabled: Boolean = true,
    val testHistoryLimit: Int = 10,
    val demoMode: Boolean = false,
    val disclaimerAccepted: Boolean = false,
    val fuelPriceText: String = "",
    val odometerText: String = "335420",
    val oilServiceKm: String = "10000",
    val fuelFilterKm: String = "20000",
    val airFilterKm: String = "10000",
    val pollenFilterKm: String = "10000",
    val timingBeltKm: String = "60000",
    val developerModeEnabled: Boolean = false,
    val rawEcuLogEnabled: Boolean = false,
    val longTripLogEnabled: Boolean = false,
    val fuelCalibrationEnabled: Boolean = false,
    val fuelCalibrationFactor: Double = 1.0,
    val fuelCalibrationAppLitersText: String = "",
    val fuelCalibrationPumpLitersText: String = "",
    val fuelCalibrationWarningAccepted: Boolean = false,
    val fuelCalibrationSessionActive: Boolean = false,
    val fuelCalibrationStartDistanceKm: Double = 0.0,
    val fuelCalibrationStartFuelLiters: Double = 0.0,
    val fuelCalibrationStartTripToken: Long = 0L,
    val fuelCalibrationStartOdometerKm: Int = 0,
    val fuelCalibrationStartTimeMs: Long = 0L,
    val fuelCalibrationSessionFactor: Double = 1.0,
    val avgResetDistanceKm: Double = 0.0,
    val avgResetFuelLiters: Double = 0.0,
    val costResetFuelLiters: Double = 0.0,
    val avgResetTripToken: Long = 0L,
    val costResetTripToken: Long = 0L
) {
    val isExperimentalPetrol: Boolean
        get() = fuelType == FuelType.Petrol

    val fuelCalculationSupported: Boolean
        get() = fuelType == FuelType.Diesel && profileSupport == VehicleProfileSupport.Verified

    val tachometerMaxRpm: Int
        get() = if (fuelType == FuelType.Petrol) 8000 else 6000

    val tachometerRedZoneStartRpm: Int
        get() = if (fuelType == FuelType.Petrol) 6500 else 4500
}

data class DashboardSnapshot(
    val speedKmh: Int? = null,
    val averageConsumption: Double? = null,
    val instantConsumption: Double? = null,
    val instantUnit: String = "L/h",
    val tripDistanceKm: Double? = null,
    val odometerKm: Int? = null,
    val engineTempC: Int? = null,
    val radiatorFanOn: Boolean? = null,
    val rpm: Int? = null,
    val acOn: Boolean? = null,
    val fuelUsedL: Double? = null,
    val tripCostText: String? = null,
    val batteryV: Double? = null,
    val adapterVoltageV: Double? = null,
    val pedalPercent: Double? = null,
    val mapMbar: Int? = null,
    val requestedMapMbar: Int? = null,
    val airCharge: Double? = null,
    val intakeTempC: Double? = null,
    val fuelTempC: Double? = null,
    val railBar: Double? = null,
    val railTargetBar: Double? = null,
    val sensorSupplyV: Double? = null,
    val connected: Boolean = false,
    val demo: Boolean = false,
    val fuelSource: String = "Bekleniyor",
    val injectionMg: Double? = null,
    val engineFuelRateLh: Double? = null,
    val mafGramsPerSec: Double? = null,
    val shortFuelTrimPercent: Double? = null,
    val longFuelTrimPercent: Double? = null,
    val commandedEquivalenceRatio: Double? = null,
    val fuelSystemStatus: String? = null,
    val rawStandardObd: String = "",
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val tripDurationText: String? = null,
    val tripStateText: String? = null,
    val tripToken: Long = 0L
) {
    companion object {
        fun empty() = DashboardSnapshot()

        fun demoLive(tick: Int): DashboardSnapshot {
            val phase = (tick % 120) / 120.0
            val wave = (sin(phase * 2.0 * PI) + 1.0) / 2.0
            val cityPulse = (sin(phase * 10.0 * PI) + 1.0) / 2.0
            val speed = (18 + wave * 82 + cityPulse * 12).toInt().coerceIn(0, 110)
            val rpm = (850 + speed * 18 + cityPulse * 380).toInt().coerceIn(820, 3100)
            val temp = (58 + (tick.coerceAtMost(340) * 0.12)).toInt().coerceIn(58, 98)
            val ac = (tick / 18) % 2 == 0
            val lh = if (speed < 5) 0.7 + if (ac) 0.15 else 0.0 else 1.1 + wave * 2.2 + if (ac) 0.25 else 0.0
            val l100 = if (speed < 5) 0.0 else (lh / speed) * 100.0
            val distance = (tick * speed / 3600.0 * 0.8).coerceAtLeast(0.0)
            val fuelUsed = distance * 4.9 / 100.0
            return DashboardSnapshot(
                speedKmh = speed,
                averageConsumption = 4.7 + wave * 0.5,
                instantConsumption = if (speed < 5) lh else l100,
                instantUnit = if (speed < 5) "L/h" else "L/100 km",
                tripDistanceKm = distance,
                odometerKm = 335420 + distance.toInt(),
                engineTempC = temp,
                radiatorFanOn = null,
                rpm = rpm,
                acOn = ac,
                fuelUsedL = fuelUsed,
                tripCostText = "12.80 ₺",
                batteryV = 13.7 + (wave * 0.2),
                adapterVoltageV = 13.8 + (wave * 0.2),
                pedalPercent = (cityPulse * 38.0),
                mapMbar = (980 + wave * 420).toInt(),
                requestedMapMbar = (1000 + wave * 390).toInt(),
                airCharge = 320.0 + wave * 120.0,
                intakeTempC = 28.0 + wave * 8.0,
                fuelTempC = 32.0 + wave * 10.0,
                railBar = 260.0 + wave * 280.0,
                railTargetBar = 270.0 + wave * 260.0,
                sensorSupplyV = 5.0,
                connected = false,
                demo = true,
                fuelSource = "DEMO",
                injectionMg = 3.2 + wave * 8.0,
                raw21A0 = "DEMO 61 A0 ...",
                raw21A2 = "DEMO 61 A2 ...",
                raw21CC = "DEMO 61 CC ...",
                raw21CD = "DEMO 61 CD ...",
                tripDurationText = run {
                    val totalSeconds = (tick * 0.8).toInt().coerceAtLeast(0)
                    "%02d:%02d".format(totalSeconds / 60, totalSeconds % 60)
                },
                tripStateText = "Demo",
                tripToken = 1L
            )
        }

        fun demo() = demoLive(42)
    }
}
