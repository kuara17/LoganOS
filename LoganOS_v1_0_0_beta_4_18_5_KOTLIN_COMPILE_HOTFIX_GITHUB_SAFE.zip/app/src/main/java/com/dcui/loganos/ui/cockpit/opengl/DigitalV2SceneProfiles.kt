package com.dcui.loganos.ui.cockpit.opengl

/**
 * Scene-specific calibration measured directly on the 1080x1320 backgrounds.
 *
 * Distance 0m is the bottom/near road and 120m is the visible horizon. The
 * centre line is the lane divider left of the follow-camera vehicle, not the
 * geometric middle of the whole road. Edge curves follow the photographed
 * asphalt boundaries independently.
 */
internal object DigitalV2SceneModels {

    private fun curve(vararg points: CalibrationPoint): CalibratedCurve =
        CalibratedCurve(points.toList())

    private val mountainRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.245f, 1.000f),
            CalibrationPoint(8f, 0.285f, 0.880f),
            CalibrationPoint(18f, 0.345f, 0.770f),
            CalibrationPoint(32f, 0.430f, 0.660f),
            CalibrationPoint(50f, 0.520f, 0.570f),
            CalibrationPoint(75f, 0.610f, 0.500f),
            CalibrationPoint(100f, 0.640f, 0.455f),
            CalibrationPoint(120f, 0.655f, 0.435f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.000f, 1.000f),
            CalibrationPoint(8f, 0.040f, 0.880f),
            CalibrationPoint(18f, 0.140f, 0.770f),
            CalibrationPoint(32f, 0.280f, 0.660f),
            CalibrationPoint(50f, 0.420f, 0.570f),
            CalibrationPoint(75f, 0.530f, 0.500f),
            CalibrationPoint(100f, 0.600f, 0.455f),
            CalibrationPoint(120f, 0.635f, 0.435f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 1.000f, 1.000f),
            CalibrationPoint(8f, 0.960f, 0.880f),
            CalibrationPoint(18f, 0.870f, 0.770f),
            CalibrationPoint(32f, 0.780f, 0.660f),
            CalibrationPoint(50f, 0.700f, 0.570f),
            CalibrationPoint(75f, 0.670f, 0.500f),
            CalibrationPoint(100f, 0.670f, 0.455f),
            CalibrationPoint(120f, 0.675f, 0.435f)
        ),
        roadWidthMeters = 10.8f,
        centerLineColor = GlColor(0.98f, 0.98f, 0.96f, 0.94f),
        leftEdgeLineColor = GlColor(0.94f, 0.97f, 1.00f, 0.30f),
        rightEdgeLineColor = GlColor(0.94f, 0.97f, 1.00f, 0.30f),
        showLeftEdgeLine = true,
        showRightEdgeLine = true
    )

    val MountainLake = DigitalV2SceneModel(
        key = DigitalV2SceneKey.MountainLake,
        road = mountainRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f,
            tireContactYRatio = 0.862f,
            visibleWidthRatio = 0.325f,
            headingDegrees = 0.85f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.290f,
                bodyHeightRatio = 0.060f,
                bodyAlpha = 0.58f,
                tireWidthRatio = 0.047f,
                tireHeightRatio = 0.020f,
                tireAlpha = 0.82f,
                groundBlendWidthRatio = 0.205f,
                groundBlendHeightRatio = 0.025f,
                groundBlendAlpha = 0.30f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.92f,
                contrast = 0.93f,
                saturation = 0.93f,
                redMultiplier = 0.94f,
                greenMultiplier = 0.98f,
                blueMultiplier = 1.04f,
                edgeSoftness = 0.48f
            )
        ),
        wind = WindZoneProfile(
            edgeOffsetRoadWidthRatio = 0.050f,
            zoneWidthRoadWidthRatio = 0.080f,
            maxAlpha = 0.070f
        ),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.024f)
    )

    private val cityDayRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.285f, 1.000f),
            CalibrationPoint(8f, 0.315f, 0.880f),
            CalibrationPoint(18f, 0.355f, 0.760f),
            CalibrationPoint(32f, 0.405f, 0.650f),
            CalibrationPoint(50f, 0.450f, 0.560f),
            CalibrationPoint(75f, 0.490f, 0.490f),
            CalibrationPoint(100f, 0.497f, 0.455f),
            CalibrationPoint(120f, 0.500f, 0.440f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.000f, 1.000f),
            CalibrationPoint(8f, 0.050f, 0.880f),
            CalibrationPoint(18f, 0.140f, 0.760f),
            CalibrationPoint(32f, 0.250f, 0.650f),
            CalibrationPoint(50f, 0.360f, 0.560f),
            CalibrationPoint(75f, 0.430f, 0.490f),
            CalibrationPoint(100f, 0.470f, 0.455f),
            CalibrationPoint(120f, 0.485f, 0.440f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 1.000f, 1.000f),
            CalibrationPoint(8f, 0.950f, 0.880f),
            CalibrationPoint(18f, 0.860f, 0.760f),
            CalibrationPoint(32f, 0.750f, 0.650f),
            CalibrationPoint(50f, 0.640f, 0.560f),
            CalibrationPoint(75f, 0.570f, 0.490f),
            CalibrationPoint(100f, 0.530f, 0.455f),
            CalibrationPoint(120f, 0.515f, 0.440f)
        ),
        roadWidthMeters = 12.0f,
        centerLineColor = GlColor(0.98f, 0.98f, 0.97f, 0.94f),
        leftEdgeLineColor = GlColor(0.95f, 0.98f, 1.00f, 0.27f),
        rightEdgeLineColor = GlColor(0.95f, 0.98f, 1.00f, 0.27f),
        showLeftEdgeLine = true,
        showRightEdgeLine = true
    )

    val CityDay = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityDay,
        road = cityDayRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f,
            tireContactYRatio = 0.858f,
            visibleWidthRatio = 0.320f,
            headingDegrees = 0f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.285f,
                bodyHeightRatio = 0.056f,
                bodyAlpha = 0.55f,
                tireWidthRatio = 0.046f,
                tireHeightRatio = 0.019f,
                tireAlpha = 0.78f,
                groundBlendWidthRatio = 0.200f,
                groundBlendHeightRatio = 0.024f,
                groundBlendAlpha = 0.27f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.94f,
                contrast = 0.94f,
                saturation = 0.94f,
                edgeSoftness = 0.44f
            )
        ),
        wind = WindZoneProfile(
            edgeOffsetRoadWidthRatio = 0.045f,
            zoneWidthRoadWidthRatio = 0.072f,
            maxAlpha = 0.062f
        ),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.022f)
    )

    private val cityNightRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.295f, 1.000f),
            CalibrationPoint(8f, 0.325f, 0.880f),
            CalibrationPoint(18f, 0.365f, 0.760f),
            CalibrationPoint(32f, 0.415f, 0.650f),
            CalibrationPoint(50f, 0.458f, 0.570f),
            CalibrationPoint(75f, 0.495f, 0.510f),
            CalibrationPoint(100f, 0.499f, 0.475f),
            CalibrationPoint(120f, 0.500f, 0.460f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.000f, 1.000f),
            CalibrationPoint(8f, 0.050f, 0.880f),
            CalibrationPoint(18f, 0.140f, 0.760f),
            CalibrationPoint(32f, 0.260f, 0.650f),
            CalibrationPoint(50f, 0.370f, 0.570f),
            CalibrationPoint(75f, 0.440f, 0.510f),
            CalibrationPoint(100f, 0.480f, 0.475f),
            CalibrationPoint(120f, 0.490f, 0.460f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 1.000f, 1.000f),
            CalibrationPoint(8f, 0.950f, 0.880f),
            CalibrationPoint(18f, 0.860f, 0.760f),
            CalibrationPoint(32f, 0.740f, 0.650f),
            CalibrationPoint(50f, 0.630f, 0.570f),
            CalibrationPoint(75f, 0.560f, 0.510f),
            CalibrationPoint(100f, 0.520f, 0.475f),
            CalibrationPoint(120f, 0.510f, 0.460f)
        ),
        roadWidthMeters = 12.4f,
        centerLineColor = GlColor(1.00f, 0.96f, 0.86f, 0.92f),
        leftEdgeLineColor = GlColor(0.88f, 0.92f, 1.00f, 0.24f),
        rightEdgeLineColor = GlColor(0.88f, 0.92f, 1.00f, 0.24f),
        showLeftEdgeLine = true,
        showRightEdgeLine = true
    )

    val CityNight = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityNight,
        road = cityNightRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f,
            tireContactYRatio = 0.858f,
            visibleWidthRatio = 0.320f,
            headingDegrees = 0f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.290f,
                bodyHeightRatio = 0.060f,
                bodyAlpha = 0.45f,
                tireWidthRatio = 0.047f,
                tireHeightRatio = 0.020f,
                tireAlpha = 0.70f,
                groundBlendWidthRatio = 0.205f,
                groundBlendHeightRatio = 0.025f,
                groundBlendAlpha = 0.22f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.72f,
                contrast = 0.90f,
                saturation = 0.84f,
                redMultiplier = 1.08f,
                greenMultiplier = 0.92f,
                blueMultiplier = 0.78f,
                edgeSoftness = 0.54f
            )
        ),
        wind = WindZoneProfile(
            edgeOffsetRoadWidthRatio = 0.045f,
            zoneWidthRoadWidthRatio = 0.075f,
            maxAlpha = 0.068f
        ),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.018f)
    )

    private val snowRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.285f, 1.000f),
            CalibrationPoint(8f, 0.315f, 0.880f),
            CalibrationPoint(18f, 0.350f, 0.770f),
            CalibrationPoint(32f, 0.400f, 0.670f),
            CalibrationPoint(50f, 0.445f, 0.590f),
            CalibrationPoint(75f, 0.480f, 0.530f),
            CalibrationPoint(100f, 0.490f, 0.490f),
            CalibrationPoint(120f, 0.495f, 0.470f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.000f, 1.000f),
            CalibrationPoint(8f, 0.040f, 0.880f),
            CalibrationPoint(18f, 0.120f, 0.770f),
            CalibrationPoint(32f, 0.230f, 0.670f),
            CalibrationPoint(50f, 0.340f, 0.590f),
            CalibrationPoint(75f, 0.420f, 0.530f),
            CalibrationPoint(100f, 0.460f, 0.490f),
            CalibrationPoint(120f, 0.480f, 0.470f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 1.000f, 1.000f),
            CalibrationPoint(8f, 0.960f, 0.880f),
            CalibrationPoint(18f, 0.880f, 0.770f),
            CalibrationPoint(32f, 0.770f, 0.670f),
            CalibrationPoint(50f, 0.660f, 0.590f),
            CalibrationPoint(75f, 0.580f, 0.530f),
            CalibrationPoint(100f, 0.530f, 0.490f),
            CalibrationPoint(120f, 0.510f, 0.470f)
        ),
        roadWidthMeters = 10.5f,
        centerLineColor = GlColor(0.99f, 0.99f, 0.98f, 0.94f),
        leftEdgeLineColor = GlColor(0.94f, 0.98f, 1.00f, 0.32f),
        rightEdgeLineColor = GlColor(0.94f, 0.98f, 1.00f, 0.32f),
        showLeftEdgeLine = true,
        showRightEdgeLine = true
    )

    val SnowRoad = DigitalV2SceneModel(
        key = DigitalV2SceneKey.SnowRoad,
        road = snowRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f,
            tireContactYRatio = 0.862f,
            visibleWidthRatio = 0.325f,
            headingDegrees = -0.45f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.295f,
                bodyHeightRatio = 0.062f,
                bodyAlpha = 0.52f,
                tireWidthRatio = 0.048f,
                tireHeightRatio = 0.021f,
                tireAlpha = 0.76f,
                groundBlendWidthRatio = 0.210f,
                groundBlendHeightRatio = 0.026f,
                groundBlendAlpha = 0.25f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.88f,
                contrast = 0.92f,
                saturation = 0.88f,
                redMultiplier = 0.88f,
                greenMultiplier = 0.98f,
                blueMultiplier = 1.10f,
                edgeSoftness = 0.50f
            )
        ),
        wind = WindZoneProfile(
            edgeOffsetRoadWidthRatio = 0.055f,
            zoneWidthRoadWidthRatio = 0.078f,
            maxAlpha = 0.062f
        ),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.022f)
    )

    fun forKey(key: DigitalV2SceneKey): DigitalV2SceneModel = when (key) {
        DigitalV2SceneKey.MountainLake -> MountainLake
        DigitalV2SceneKey.CityDay -> CityDay
        DigitalV2SceneKey.CityNight -> CityNight
        DigitalV2SceneKey.SnowRoad -> SnowRoad
    }
}
