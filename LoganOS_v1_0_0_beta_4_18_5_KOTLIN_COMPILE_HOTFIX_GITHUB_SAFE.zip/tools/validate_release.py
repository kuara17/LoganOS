#!/usr/bin/env python3
"""Static release gate for LoganOS source packages.

This intentionally uses only the Python standard library so GitHub Actions can
run it before Gradle. It checks high-value invariants that should not regress
between beta releases; device/runtime behavior is covered by the companion
manual test checklist.
"""
from __future__ import annotations

import re
import struct
import sys
from pathlib import Path


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def passed(message: str) -> None:
    print(f"[PASS] {message}")


def require(condition: bool, message: str) -> None:
    if not condition:
        fail(message)
    passed(message)


def read(root: Path, relative: str) -> str:
    path = root / relative
    if not path.is_file():
        fail(f"Required file missing: {relative}")
    return path.read_text(encoding="utf-8")


def image_dimensions(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        return struct.unpack(">II", data[16:24])
    if len(data) >= 30 and data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        chunk = data[12:16]
        if chunk == b"VP8X":
            width = 1 + int.from_bytes(data[24:27], "little")
            height = 1 + int.from_bytes(data[27:30], "little")
            return width, height
        if chunk == b"VP8 " and data[23:26] == b"\x9d\x01\x2a":
            width = int.from_bytes(data[26:28], "little") & 0x3FFF
            height = int.from_bytes(data[28:30], "little") & 0x3FFF
            return width, height
        if chunk == b"VP8L" and data[20] == 0x2F:
            bits = int.from_bytes(data[21:25], "little")
            width = 1 + (bits & 0x3FFF)
            height = 1 + ((bits >> 14) & 0x3FFF)
            return width, height
    fail(f"Unsupported or malformed image: {path}")
    raise AssertionError("unreachable")


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    print(f"LoganOS release validation root: {root}")

    gradle = read(root, "app/build.gradle.kts")
    version_name = re.search(r'versionName\s*=\s*"([^"]+)"', gradle)
    version_code = re.search(r'versionCode\s*=\s*(\d+)', gradle)
    require(version_name is not None, "versionName is present")
    require(version_code is not None, "versionCode is present")
    require('applicationId = "com.dcui.loganos"' in gradle, "release applicationId is com.dcui.loganos")
    print(f"[INFO] versionName={version_name.group(1)} versionCode={version_code.group(1)}")

    publish_workflow = read(root, ".github/workflows/publish-secure-release.yml")
    require("release_notes:" in publish_workflow and "required: true" in publish_workflow, "secure publish workflow requires the OTA note as workflow input")
    require("OTA_RELEASE_NOTE_TR.txt" not in publish_workflow, "source package does not depend on an embedded OTA note file")
    require('--notes "$NOTES"' in publish_workflow, "secure publish workflow publishes the supplied OTA note")

    manifest = read(root, "app/src/main/AndroidManifest.xml")
    require('android:allowBackup="false"' in manifest, "Android Auto Backup remains disabled")
    require('android:name=".service.ObdForegroundService"' in manifest, "OBD Foreground Service is registered")
    require('android:foregroundServiceType="connectedDevice|location"' in manifest, "Foreground Service declares connectedDevice + location types")
    require('android.permission.FOREGROUND_SERVICE_CONNECTED_DEVICE' in manifest, "connected-device foreground-service permission is present")
    require('android.permission.FOREGROUND_SERVICE_LOCATION' in manifest, "location foreground-service permission is present")
    require('android.permission.ACCESS_FINE_LOCATION' in manifest, "precise location permission is declared for optional route recording")
    require('android.permission.ACCESS_BACKGROUND_LOCATION' not in manifest, "background-location permission is intentionally not requested")
    require('android.permission.POST_NOTIFICATIONS' in manifest, "Android 13+ notification permission is declared")

    models = read(root, "app/src/main/java/com/dcui/loganos/model/Models.kt")
    enum_match = re.search(r'enum class GaugeStyle\([^)]*\)\s*\{(.*?)\n\}', models, re.S)
    require(enum_match is not None, "GaugeStyle enum is readable")
    enum_body = enum_match.group(1)
    require("Digital(" in enum_body and "ClassicOem(" in enum_body, "Digital and Classic cockpit styles remain")
    require(all(token not in enum_body for token in ("Minimal(", "Sport(", "RsPerformance(")), "retired cockpit styles are absent from GaugeStyle")

    app_prefs = read(root, "app/src/main/java/com/dcui/loganos/data/AppPrefs.kt")
    require('"Minimal", "Sport", "RsPerformance"' in app_prefs and 'GaugeStyle.Digital' in app_prefs, "legacy cockpit preferences migrate to Digital")

    dashboard = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt")
    require("resolvedHeadUnit && !portrait && ghostSingle" in dashboard and "resolvedHeadUnit && !portrait && ghostDual" in dashboard, "Double Ghost routes use independent head-unit overlays")
    require("GhostSinglePhoneWideCockpit" in dashboard and "GhostDualPhoneWideCockpit" in dashboard, "phone landscape Ghost routes remain available")
    require("GhostSingleHeadUnitCockpit" in dashboard and "GhostDualHeadUnitCockpit" in dashboard, "Double Ghost routes use the dedicated head-unit renderers")

    digital_v2_cockpit = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt")
    require(
        "DIGITAL_V2_LOGICAL_WIDTH" not in digital_v2_cockpit
        or "import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_LOGICAL_WIDTH" in digital_v2_cockpit,
        "DigitalV2Cockpit imports DIGITAL_V2_LOGICAL_WIDTH when using the OpenGL logical-width constant",
    )
    require(
        "DIGITAL_V2_LOGICAL_HEIGHT" not in digital_v2_cockpit
        or "import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_LOGICAL_HEIGHT" in digital_v2_cockpit,
        "DigitalV2Cockpit imports DIGITAL_V2_LOGICAL_HEIGHT when using the OpenGL logical-height constant",
    )

    cockpit_root = root / "app/src/main/java/com/dcui/loganos/ui/cockpit"
    require(not (cockpit_root / "GhostReferencePlateCockpit.kt").exists(), "legacy GhostReferencePlateCockpit source is removed")
    require(not (cockpit_root / "GhostHeadUnitPortraitCockpit.kt").exists(), "mixed head-unit/portrait Ghost source is removed")
    portrait = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPortraitCockpit.kt")
    require("fun GhostSinglePortraitCockpit" in portrait, "portrait Ghost remains available")
    require("HeadUnit" not in portrait and "GhostSingleOverlay" not in portrait and "GhostDualOverlay" not in portrait, "portrait source contains no legacy landscape renderer")

    drawable_root = root / "app/src/main/res/drawable-nodpi"
    ghost_assets = sorted(path.name for path in drawable_root.glob("ghost_*"))
    require(
        ghost_assets == [
            "ghost_dual_logan_oem_19_5_9.webp",
            "ghost_single_logan_oem_19_5_9.webp",
            "ghost_single_portrait_logan_oem_19_5_9.webp",
        ],
        "only the three final Logan-OEM Ghost assets remain",
    )
    legacy_landscape_assets = [
        "ghost_single_master_headunit.webp",
        "ghost_dual_speed_left_master_headunit.webp",
        "ghost_landscape_extension.webp",
    ]
    require(not any((drawable_root / name).exists() for name in legacy_landscape_assets), "all legacy landscape Ghost assets are physically absent")
    require(not (drawable_root / "ghost_setup_single_preview.webp").exists() and not (drawable_root / "ghost_setup_dual_preview.webp").exists(), "legacy Ghost setup preview assets are removed")
    gauges = read(root, "app/src/main/java/com/dcui/loganos/ui/components/Gauges.kt")
    require("ghost_single_logan_oem_19_5_9" in gauges and "ghost_dual_logan_oem_19_5_9" in gauges, "setup preview reuses the final Logan-OEM 19.5:9 assets")

    source_root = root / "app/src/main/java"

    kotlin_sources = list(source_root.rglob("*.kt"))
    invalid_compose_member_imports = {
        "import androidx.compose.foundation.layout.matchParentSize": "BoxScope.matchParentSize must not be imported as a top-level extension",
        "import androidx.compose.foundation.layout.weight": "RowScope/ColumnScope.weight must not be imported as a top-level extension",
        "import androidx.compose.ui.draw.graphicsLayer": "graphicsLayer must be imported from androidx.compose.ui.graphics",
    }
    for source in kotlin_sources:
        text = source.read_text(encoding="utf-8")
        for token, label in invalid_compose_member_imports.items():
            require(token not in text, f"{label}: {source.relative_to(root)}")

    retired_files = [
        source_root / "com/dcui/loganos/ui/cockpit/MinimalCockpit.kt",
        source_root / "com/dcui/loganos/ui/cockpit/SportCockpit.kt",
        source_root / "com/dcui/loganos/ui/cockpit/RsPerformanceCockpit.kt",
    ]
    require(not any(path.exists() for path in retired_files), "retired cockpit source files remain removed")

    update = read(root, "app/src/main/java/com/dcui/loganos/update/SecureUpdateManager.kt")
    for token, label in [
        ("APK SHA-256 doğrulaması başarısız", "OTA SHA-256 verification"),
        ("archiveInfo.packageName != context.packageName", "OTA package identity verification"),
        ("signatureMatches", "OTA signing-certificate verification"),
        ("updateVersionCode <= currentVersionCode", "OTA downgrade/reinstall prevention"),
        ("APK indirmesi yarım kaldı", "partial APK download rejection"),
        ("UnknownHostException", "offline/DNS error classification"),
        ("SocketTimeoutException", "network timeout classification"),
        ("SSLException", "TLS error classification"),
        ("cleanupStaleUpdateFilesAfterVersionChange", "version-aware OTA cache cleanup"),
        ("KEY_LAST_LAUNCHED_VERSION", "OTA cleanup version marker"),
    ]:
        require(token in update, label)

    backup = read(root, "app/src/main/java/com/dcui/loganos/data/DataBackupManager.kt")
    for token, label in [
        ("extractAllowedEntries", "backup ZIP allow-list validation"),
        ("PRAGMA quick_check(1)", "SQLite quick_check validation"),
        ("validateDatabaseSchema", "SQLite schema allow-list validation"),
        ("PRAGMA table_info", "backup exact column validation"),
        ("PRAGMA index_info", "backup exact index-column validation"),
        ("PRAGMA foreign_key_list", "backup foreign-key validation"),
        ("BoundedInputStream", "streamed bounded backup restore"),
        ("BoundedOutputStream", "streamed bounded backup creation"),
        ("smokeTestDatabase", "post-migration restore smoke test"),
        ("restore-rollback", "restore rollback path"),
        ("settingsSha256", "settings integrity hash"),
        ("databaseSha256", "database integrity hash"),
    ]:
        require(token in backup, label)

    history_models = read(root, "app/src/main/java/com/dcui/loganos/data/HistoryModels.kt")
    require("data class TechnicalSessionItem" in history_models, "technical OBD session history model is present")

    sql_store = read(root, "app/src/main/java/com/dcui/loganos/data/LoganSqlStore.kt")
    require("fun listTechnicalSessions" in sql_store, "technical OBD sessions can be listed independently of drive/test history")
    require("fun latestValidTechnicalSessionId" in sql_store and "EXISTS(SELECT 1 FROM obd_samples" in sql_store, "last technical export selects a session that actually contains OBD samples")
    require("sessionId ?: latestValidTechnicalSessionId()" in sql_store, "default technical export ignores later zero-sample sessions")

    obd_models = read(root, "app/src/main/java/com/dcui/loganos/obd/ObdModels.kt")
    require("technicalHistory: List<TechnicalSessionItem>" in obd_models, "technical OBD history is exposed in controller state")

    obd_controller = read(root, "app/src/main/java/com/dcui/loganos/obd/ObdController.kt")
    require("fun exportTechnicalSession(sessionId: Long)" in obd_controller, "individual technical sessions can be exported")
    require("sqlStore.listTechnicalSessions(10)" in obd_controller and "technical_sessions/index.txt" in obd_controller, "support package includes the 10 most recent technical sessions")
    require("latestValidTechnicalSessionId" in obd_controller, "save/share support paths resolve the last valid technical session")
    require("Son geçerli teknik kayıt için paylaşım ekranı açıldı" in obd_controller and "savedPrivateFile" not in obd_controller, "technical share always creates a fresh last-valid-session file")

    settings_screen = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt")
    require("Teknik kayıt geçmişi" in settings_screen and "onExportTechnicalSession(session.id)" in settings_screen, "developer settings expose filtered technical session history and per-session export")
    require("Veri içermeyen kısa bağlantı denemeleri listede gösterilmez" in settings_screen and "session.sampleCount > 0" in settings_screen, "zero-sample technical sessions are hidden from the user-facing list")
    require("Kısa molalarda sürüş aynı kayıtta kalır. Seçilen süre aşılırsa yeni sürüş başlatılır." in settings_screen, "Smart Trip explanation is complete and untruncated")
    require("TripRecordsSubPage.DataManagement" in settings_screen and "Yedekleme ve veri yönetimi" in settings_screen, "backup and data management opens as a dedicated subpage")
    require("SÜRÜŞ AYARLARI" in settings_screen and "KAYIT AYARLARI" in settings_screen and "VERİ YÖNETİMİ" in settings_screen, "Trip & Records uses explicit visual section headings")
    require("onOpenTripHistory()" in settings_screen and "Görüntüle" in settings_screen, "history summary is an explicit navigation row")
    require("FUEL_REFILL_TEST_NAME" in settings_screen and "Pompa başında uygulamayla işlem yapılmaz" in settings_screen and "FUEL_REFILL_BEFORE_ENGINE_TEST_NAME" in settings_screen and "FUEL_REFILL_AFTER_KOEO_TEST_NAME" in settings_screen, "guided fuel refill verification is exposed as separate safe-area stages")
    require("CONTROL_DISCOVERY_TEST_NAME" in settings_screen and "CONTROL_HANDBRAKE_TEST_NAME" in settings_screen and "CONTROL_CLUTCH_TEST_NAME" in settings_screen and "CONTROL_GEAR_STATIC_TEST_NAME" in settings_screen, "handbrake clutch brake and gear discovery stages are exposed")
    require("FUEL_LEVEL_DISCOVERY_TEST_NAME to tx" not in settings_screen and "title = KWP_026_DYNAMIC_TEST_NAME" not in settings_screen.split("private fun DeveloperTestRows", 1)[1], "retired fuel preparation and monolithic dynamic cards are hidden from the developer-test menu")
    require(
        "KWP_026_DYNAMIC_TEST_NAME" in settings_screen
        and "DeveloperSubPage.Dynamic026" in settings_screen
        and "BAĞIMSIZ DOĞRULAMA BÖLÜMLERİ" in settings_screen
        and "21DD/21DE" in settings_screen,
        "0x26 validation is exposed as a dedicated hub with independent sections and fuel-candidate guidance"
    )
    require("SettingsCategory.SetupDevice" in settings_screen and "Kurulum ve Cihaz" in settings_screen, "setup and device controls have a dedicated settings category")
    require(
        "DeveloperSubPage.Tests" in settings_screen
        and "DeveloperSubPage.TechnicalHistory" in settings_screen
        and "DeveloperSubPage.Dynamic026" in settings_screen
        and "DeveloperSubPage.Dynamic026Wide" in settings_screen,
        "developer tests, technical history and nested 0x26 research tools open as dedicated subpages"
    )
    require("Menü teması" in settings_screen and "MenuTheme.entries" in settings_screen, "menu theme presets are exposed in Appearance settings")
    cards = read(root, "app/src/main/java/com/dcui/loganos/ui/components/Cards.kt")
    require("fun SettingsCard" in cards and "RoundedCornerShape(26.dp)" in cards and "RoundedCornerShape(22.dp)" in cards, "settings use the new rounded layered-white card system")
    models = read(root, "app/src/main/java/com/dcui/loganos/model/Models.kt")
    prefs = read(root, "app/src/main/java/com/dcui/loganos/data/AppPrefs.kt")
    require("enum class MenuTheme" in models and "KEY_MENU_THEME" in prefs and "loadMenuTheme" in prefs, "menu theme selection persists with legacy dark-mode migration")

    dashboard_fuel_overlay = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt")
    require("fuelDiscovery" in dashboard_fuel_overlay and "Arka planda sürdür" in dashboard_fuel_overlay, "fuel preparation overlay can be minimized while the parked scan runs")
    require("Bu yalnız hazırlık taramasıdır; bugün yakıt alma" in dashboard_fuel_overlay, "fuel preparation overlay prevents premature refuelling")
    require("Kontak açık, motor kapalı" in dashboard_fuel_overlay and "Canlı OBD değerleri" in dashboard_fuel_overlay, "fuel preparation overlay clearly states KOEO and live-data pause")
    require("developerTestProgressPercent" in obd_models and "developerTestEstimatedRemainingSec" in obd_models and "developerTestCurrentTarget" in obd_models, "fuel preparation exposes structured progress state")
    require("updateFuelDiscoveryProgress" in obd_controller and "persistFuelDiscoveryCheckpoint" in obd_controller and "recoverInterruptedFuelDiscoveryIfNeeded" in obd_controller, "fuel preparation progress and interrupted-run checkpointing are implemented")
    require("LinearProgressIndicator" in dashboard_fuel_overlay and "Yaklaşık kalan" in dashboard_fuel_overlay and "keepScreenOn" in dashboard_fuel_overlay, "fuel preparation has visible progress, remaining-time guidance and screen-on protection")
    foreground_service = read(root, "app/src/main/java/com/dcui/loganos/service/ObdForegroundService.kt")
    require("Depo taraması" in foreground_service and "developerTestProgressPercent" in foreground_service and "notifyFuelDiscoveryResult" in foreground_service, "fuel preparation progress and completion are exposed through notifications")
    require("0x26 dinamik testi" in foreground_service and "notifyDynamic026Result" in foreground_service, "0x26 dynamic test progress and completion are exposed through notifications")
    require("Yakıt doğrulama" in foreground_service and "Kontrol keşfi" in foreground_service, "new fuel and control tests have distinct foreground notification titles")
    require("requestDeveloperTestConnectionRecovery" in obd_controller and "recoverActiveDynamic026IfRpmMissing" in obd_controller and "DEVELOPER_TEST_RECONNECT_MAX_ATTEMPTS = 2" in obd_controller, "engine-required developer stages hard-refresh stale OBD sessions when RPM is missing")
    require("DYNAMIC_026_MODULE_RETRY_COUNT = 3" in obd_controller and "TARGET_RETRY" in obd_controller and "0x26 BUS INIT başarısız; hedefli test duraklatıldı" in obd_controller, "targeted fuel/control scans retry module init and never silently omit 0x26")
    require(
        "live_context_captured_elapsed_ms" in obd_controller
        and "live_context_age_ms" in obd_controller
        and "persistent_cockpit_accumulator_main_poll" in obd_controller
        and "trip_context_session_fresh" in obd_controller
        and "trip_context_stale" in obd_controller,
        "dynamic records expose fresh/stale Trip-context metadata from the persistent cockpit accumulator"
    )
    require(
        "TRIP_CONTEXT_IDLE_TEST_NAME" in obd_models
        and "TRIP_CONTEXT_DRIVE_TEST_NAME" in obd_models
        and "runTripContextValidationTest" in obd_controller
        and "isTripContextDeveloperTest" in dashboard,
        "guided idle and short-drive Trip-context validation tests are wired into the UI"
    )
    require("Dynamic026ScanProfile.FUEL_REFILL" in obd_controller and "Dynamic026ScanProfile.CONTROL_DISCOVERY" in obd_controller and "fullDiscovery = false" in obd_controller, "fuel and control workflows use targeted read-only profiles rather than full moving sweeps")
    require(
        "bağımsız bir bölümdür" in dashboard_fuel_overlay
        and "Bağlantı kesilirse bölüm duraklar" in dashboard_fuel_overlay
        and "diğer araştırma blokları" in dashboard_fuel_overlay,
        "0x26 overlay explains independent sections, reconnect behavior and broader raw capture"
    )
    main_activity = read(root, "app/src/main/java/com/dcui/loganos/MainActivity.kt")
    require("val started = current.activeDeveloperTest == name" in main_activity and "else current.status" in main_activity, "developer-test start feedback reports blocked starts instead of a false success toast")

    runtime = read(root, "app/src/main/java/com/dcui/loganos/runtime/LoganRuntime.kt")
    require("object LoganRuntime" in runtime and "ObdController(context.applicationContext)" in runtime, "process-wide OBD runtime owner is present")
    require("releaseObdController" in runtime, "application-scoped OBD controller can be explicitly recreated for restore")

    service = read(root, "app/src/main/java/com/dcui/loganos/service/ObdForegroundService.kt")
    for token, label in [
        ("ServiceCompat.startForeground", "foreground service enters foreground state"),
        ("FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE", "connected-device service type is used at runtime"),
        ("FOREGROUND_SERVICE_TYPE_LOCATION", "location service type is added when optional GPS routing is eligible"),
        ("isGpsForegroundLocationEligible", "foreground service location type follows optional GPS eligibility"),
        ("START_NOT_STICKY", "service does not create a ghost OBD session after process death"),
        ("LoganRuntime.obdController", "service shares the application-scoped OBD controller"),
        ("Sürüş aktif", "ongoing driving notification content is present"),
    ]:
        require(token in service, label)

    obd = read(root, "app/src/main/java/com/dcui/loganos/obd/ObdController.kt")
    for token, label in [
        ("evaluateConnectionHealth", "Connection Health Guard remains present"),
        ("tripMutex.withLock", "TripComputer mutation remains serialized"),
        ("suspend fun finishTripNow", "manual trip finish remains suspend/async"),
        ("Dispatchers.IO", "blocking controller work retains IO dispatcher usage"),
        ("NO DATA", "transport gap handling remains present"),
        ("ObdForegroundService.start(context)", "OBD connection can start background continuity"),
        ("ObdForegroundService.stop(context)", "explicit/final disconnect can stop background service"),
        ("backgroundTripEnabled", "background driving preference remains supported"),
        ("shouldRunForegroundService", "foreground continuity also covers optional GPS routing"),
        ("exportGpsRoute", "GPX route export is exposed by the controller"),
        ("IGNITION_OFF_CONFIRM_MS", "confirmed ignition-off detection is present"),
        ("scheduleIgnitionWakeProbe", "ignition-off waiting uses low-frequency wake probes"),
        ("tripComputer.pauseDuration", "confirmed engine-off pauses trip duration at the real stop mark"),
        ("ENDED_IGNITION_OFF", "normal ignition-off has a dedicated session end state"),
    ]:
        require(token in obd, label)
    require("MAX_ELM_RESPONSE_CHARS" in obd and "OBD yanıtı güvenlik sınırını aştı" in obd, "OBD response size limit")
    require("MAX_ELM_DRAIN_BYTES" in obd and "OBD giriş tamponu güvenlik sınırını aştı" in obd, "OBD stale-input drain limit")
    require("maskBluetoothAddress" in obd and "rawEcuLogIncluded" in obd, "support-package identifier/raw-data privacy")

    fuel_discovery = obd.split("private fun startFuelDiscoveryTest", 1)[-1].split("fun startDeveloperTest", 1)[0]
    require("identifiers = 0x00..0xFF" in fuel_discovery, "fuel preparation scans the complete KWP 21xx local-identifier range")
    require("val candidates = (0x10..0x7F)" in fuel_discovery, "fuel preparation attempts bounded physical KWP module discovery")
    require('FuelDiscoveryScanRequest("PREPARATION", discoverModules = true)' in fuel_discovery, "refuelling workflow is split so this release performs preparation only")
    require("FUEL_DISCOVERY_TOTAL_VALIDATION_PASSES = 4" in obd and "FUEL_DISCOVERY_MIN_STABLE_HITS = 3" in obd, "fuel preparation requires at least three hits across four validation attempts")
    require("finalizeStableFuelDiscoveryIds" in fuel_discovery and "[UNSTABLE_ID]" in fuel_discovery, "unstable or one-off positive local IDs are excluded")
    require("safe_allowlist=10C0,1Axx,21xx" in fuel_discovery and "blocked_services=14,27,2E,31,34,36,3B" in fuel_discovery, "fuel preparation documents its read-only service allowlist and forbidden services")
    require(all(f'send(out, input, "{service}' not in fuel_discovery for service in ("14", "27", "2E", "31", "34", "36", "3B")), "fuel preparation sends no clear/write/actuator/security/programming service")
    require("vehicle must be stationary" in fuel_discovery and "KOEO required" in fuel_discovery and "speedKmh" in fuel_discovery, "fuel preparation requires stationary ignition-on engine-off conditions")
    require("restoreEngineKwpTargetBestEffort" in fuel_discovery and "RESTORE_ENGINE_FINALLY" in fuel_discovery, "engine ECU target is restored from finally even after manual stop or failure")
    require("extractKwpFrames" in fuel_discovery and "expectedSource" in fuel_discovery and "SUSPICIOUS_RESPONSE" in fuel_discovery, "positive KWP replies use structural source/service/identifier validation")
    require("ensureFuelDiscoveryScanActive" in fuel_discovery and "FuelDiscoveryStopSignal" in obd and "FUEL_DISCOVERY_STOP_WAIT_MS = 8_000L" in obd, "fuel preparation aborts safely and waits beyond the longest single command timeout")
    require("loganos_fuel_preparation" in fuel_discovery and "01_stable_profile.json" in fuel_discovery and "BENI_OKU.txt" in fuel_discovery, "fuel preparation exports a focused ZIP with raw scan and stable JSON profile")
    require("Doğrulanmamış KWP modül adayı" in fuel_discovery and "address_verified_role" in fuel_discovery, "non-engine module roles remain explicitly unverified")
    require("val pendingFuelDiscoveryScan = fuelDiscoveryScanRequest" in obd and "fuelDiscoveryScanRequest?.let" not in obd, "fuel preparation polling avoids experimental break/continue from inline lambdas")

    dynamic_026 = obd.split("private fun startDynamic026Test", 1)[-1].split("fun startDeveloperTest", 1)[0]
    require(
        all(token in dynamic_026 for token in ("Dynamic026Mode.KOEO", "Dynamic026Mode.ENGINE_STATIC", "Dynamic026Mode.DRIVE", "Dynamic026Mode.POST_KOEO")),
        "0x26 validation is split into independent KOEO, engine-static, drive and post-drive sections"
    )
    require(
        all(token in dynamic_026 for token in ("WIDE_KOEO_DISCOVERY", "WIDE_IDLE_DISCOVERY", "WIDE_RPM_2000", "WIDE_DRIVE_5KM", "WIDE_POST_KOEO_DISCOVERY")),
        "guided broad research has separate ignition, idle, RPM, drive and post-drive stages"
    )
    require("21DD" in dynamic_026 and "21DE" in dynamic_026 and "21D8" in dynamic_026 and "21D9" in dynamic_026, "0x26 tests retain priority fuel and conditional-ID candidates")
    require("fullDiscovery" in dynamic_026 and "0x00..0xFF" in dynamic_026, "broad parked stages can scan the complete read-only 21xx identifier range")
    require("01_research_blocks.jsonl" in dynamic_026 and "02_test_manifest.json" in dynamic_026 and "03_quick_analysis.json" in dynamic_026, "each 0x26 section exports raw research, manifest and quick-analysis files")
    require("createDynamic026CombinedPackage" in obd and "00_group_manifest.json" in obd, "completed independent sections can be collected into one combined result package")
    require("excluded_0x26_21A2_security_protected" in dynamic_026 and "address == 0x26 && it == 0xA2" in dynamic_026, "protected 0x26/21A2 remains excluded from broad scans")
    require("restoreEngineDynamic026BestEffort" in dynamic_026 and "_FINALLY" in dynamic_026, "every 0x26 scan restores the engine ECU target from finally")
    require("recoverInterruptedDynamic026IfNeeded" in obd and "persistDynamic026Checkpoint" in dynamic_026, "0x26 sections preserve interrupted-run evidence")
    require("val pendingDynamic026Scan = dynamic026ScanRequest" in obd and "dynamic026ScanRequest?.let" not in obd, "0x26 dynamic polling avoids experimental break/continue from inline lambdas")

    trip_computer = read(root, "app/src/main/java/com/dcui/loganos/obd/TripComputer.kt")
    for token, label in [
        ("activeDurationStartedAtMs", "trip duration has an explicit engine-running interval anchor"),
        ("fun setEngineRunning", "TripComputer can resume duration only on confirmed engine-running data"),
        ("fun pauseDuration", "TripComputer can freeze duration at a confirmed ignition-off mark"),
        ("Android lifecycle / sleep jumps are discarded", "large lifecycle gaps are excluded from trip duration"),
    ]:
        require(token in trip_computer, label)

    cockpit_accumulator = read(root, "app/src/main/java/com/dcui/loganos/obd/PersistentCockpitTripAccumulator.kt")
    require(
        "currentDuration - previous.lastTripDurationSec" in cockpit_accumulator,
        "persistent cockpit duration accepts a retroactive ignition-off correction"
    )

    gps_recorder = read(root, "app/src/main/java/com/dcui/loganos/obd/GpsRouteRecorder.kt")
    for token, label in [
        ("LocationManager.GPS_PROVIDER", "native GPS_PROVIDER is used without Google Play Services"),
        ("START_SPEED_KMH = 3", "GPS recording is motion-gated by trusted OBD speed"),
        ("STOP_AFTER_MS = 25_000L", "stationary GPS requests stop after a sustained halt"),
        ("MAX_ACCURACY_M = 35f", "low-quality GPS fixes are rejected"),
        ("MIN_ACCEPT_DISTANCE_M = 8f", "near-duplicate route points are filtered"),
        ("sqlStore.insertGpsPoint", "accepted GPS points are persisted through the SQL store"),
    ]:
        require(token in gps_recorder, label)
    require("com.google.android.gms.location" not in gps_recorder, "GPS recorder has no Fused Location / Play Services dependency")

    health = read(root, "app/src/main/java/com/dcui/loganos/health/VehicleHealthAnalyzer.kt")
    for token, label in [
        ("VehicleHealthLevel", "Vehicle Health status model"),
        ("coolantFinding", "coolant health analysis"),
        ("warmupFinding", "warm-up health analysis"),
        ("idleFinding", "idle stability analysis"),
        ("consumptionFinding", "consumption trend analysis"),
        ("dataQualityFinding", "OBD data-quality analysis"),
        ("INSUFFICIENT_DATA", "insufficient-data safety state"),
    ]:
        require(token in health, label)

    store = read(root, "app/src/main/java/com/dcui/loganos/data/LoganSqlStore.kt")
    for token, label in [
        ("CREATE TABLE IF NOT EXISTS gps_points", "GPS points have a dedicated SQLite table"),
        ("FOREIGN KEY(drive_session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE", "GPS retention follows drive-session deletion"),
        ("DB_VERSION = 6", "database version remains at or beyond the GPS route schema"),
        ("loadGpsRoute", "completed drive details can load segmented GPS routes"),
        ("GPS_SEGMENT_GAP_MS", "long unknown GPS windows are split instead of drawn as fake straight lines"),
        ("exportTripGpx", "GPX 1.1 route export is available"),
        ("maskRouteEdges", "GPX export can mask route start/end edges"),
        ('backupDb.delete("gps_points", null, null)', "default backup strips sensitive GPS rows"),
    ]:
        require(token in store, label)
    require("loadVehicleHealthEvidence" in store, "read-only Vehicle Health evidence aggregation")
    require(
        "EXISTS(SELECT 1 FROM obd_samples os WHERE os.session_id=s.id)" in store,
        "drive-history session counts exclude zero-sample reconnect attempts"
    )
    require(
        "s.started_elapsed_ms <= r.ended_elapsed_ms" in store,
        "drive-history session counts use the same logical-end cutoff as text export"
    )
    require(
        'snapshot.engineTempC?.let { put("end_temp_c", it) }' in store,
        "a missing terminal frame cannot erase the last trusted coolant value"
    )
    require("CREATE TABLE health_" not in store, "Vehicle Health adds no new database table in beta.4.8.0")
    for token, label in [
        ("movingAverageL100", "moving-only consumption analysis"),
        ("averageMovingSpeedKmh", "average moving-speed analysis"),
        ("acKnownDurationMs", "A/C ratio uses known-state duration"),
        ("normalizedSource == \"CUTOFF\"", "fuel cut-off counts only exact verified CUTOFF samples"),
        ("fuelSourceKnownDurationMs", "fuel cut-off ratio has a trusted-source denominator"),
    ]:
        require(token in store, label)

    setup = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/SetupWizard.kt")
    require(
        "listOf(GaugeStyle.Digital, GaugeStyle.DigitalV2, GaugeStyle.ClassicOem, GaugeStyle.GhostSingle, GaugeStyle.GhostDual)" in setup,
        "Setup Wizard exposes Digital, Digital V2, Classic, Ghost Single and Ghost Dual"
    )

    gauges = read(root, "app/src/main/java/com/dcui/loganos/ui/components/Gauges.kt")
    require(gauges.count("previewMode = true") == 1, "preview-only positioning is enabled only by GaugePreview")
    require("compact -> 4.dp" in gauges and "else -> 8.dp" in gauges, "Digital live speed readout has optical downward centering")
    require("R.drawable.ghost_single_logan_oem_19_5_9" in gauges and "R.drawable.ghost_dual_logan_oem_19_5_9" in gauges, "Ghost setup cards reuse the final Logan-OEM 19.5:9 assets")
    require(
        not (root / "app/src/main/res/drawable-nodpi/ghost_setup_single_preview.webp").exists()
        and not (root / "app/src/main/res/drawable-nodpi/ghost_setup_dual_preview.webp").exists(),
        "legacy Ghost setup preview raster assets are removed"
    )
    require(
        not (root / "app/src/main/res/drawable/ghost_setup_single_preview.xml").exists()
        and not (root / "app/src/main/res/drawable/ghost_setup_dual_preview.xml").exists(),
        "unsupported bitmap XML preview wrappers are removed"
    )
    require(
        "GaugeStyle.Digital," in gauges and "GaugeStyle.ClassicOem -> SpeedPanel" in gauges,
        "Digital and Classic setup previews keep their live preview entry path"
    )
    require(
        "style == GaugeStyle.ClassicOem && previewMode" in gauges
        and "ClassicOemSetupPreview" in gauges,
        "Classic setup uses a dedicated non-overlapping preview layout"
    )
    classic = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/ClassicCockpit.kt")
    portrait_speed = classic.split("private fun ClassicPortraitSpeedGauge", 1)[-1].split("@Composable", 1)[0]
    require("plateRes =" not in portrait_speed, "Classic portrait speed card does not stretch a pre-rendered plate")
    dashboard = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt")
    require("previewMode = true" not in dashboard, "live dashboard does not enable setup preview mode")
    require("configuration.smallestScreenWidthDp >= 600" in dashboard, "phone and Double device-class detection uses smallest-screen width")
    dashboard_content = dashboard.split("private fun DashboardContent", 1)[-1].split("@Composable", 1)[0]
    require("val configuration = LocalConfiguration.current" in dashboard_content, "DashboardContent resolves LocalConfiguration in its own composable scope")
    require("!portrait && maxWidth >= 600.dp" not in dashboard, "landscape phones are not misclassified as Double")
    require("private fun HeadUnitConsumptionCard" in dashboard and "modifier = Modifier.fillMaxWidth().height(28.dp)" in dashboard, "Double Digital consumption sparklines are rendered below the value text")
    require("MainTab.VehicleHealth" in dashboard and "VehicleHealthOverviewCard" in dashboard and "VehicleHealthFindingCard" in dashboard, "Vehicle Health UI is exposed in the dedicated Health tab")
    for token, label in [
        ("Gelişmiş Sürüş Analizi", "Advanced Drive Analysis UI section"),
        ("Hareketli ortalama", "moving-only consumption is shown"),
        ("Klima kullanım oranı", "A/C usage ratio is shown"),
        ("Yakıt kesme süresi", "fuel cut-off duration is shown"),
        ("GPS Rotası", "completed drive analysis exposes the GPS route map"),
        ("RouteMapCard", "route map component is wired into drive analysis"),
        ("Rotayı GPX olarak dışa aktar", "GPX export action is exposed in drive analysis"),
    ]:
        require(token in dashboard, label)


    route_map = read(root, "app/src/main/java/com/dcui/loganos/ui/components/RouteMap.kt")
    for token, label in [
        ("https://tile.openstreetmap.org/", "map basemap uses the standard OpenStreetMap raster tile endpoint"),
        ("© OpenStreetMap contributors", "OpenStreetMap attribution is visible"),
        ("route_map_tiles", "visible basemap tiles are cached locally"),
        ("drawFallbackGrid", "route remains visible even when basemap tiles are unavailable"),
        ("drawRoute", "GPS polyline is drawn locally by LoganOS"),
        ("MAX_TILE_CACHE_BYTES", "route tile disk cache has a hard size limit"),
        ("pruneDiskCache", "route tile disk cache has LRU cleanup"),
    ]:
        require(token in route_map, label)
    require("fun prefetch" not in route_map.lower() and "prefetchtiles" not in route_map.lower(), "map implementation has no bulk/offline tile prefetch feature")

    main_activity = read(root, "app/src/main/java/com/dcui/loganos/MainActivity.kt")
    require("LoganRuntime.obdController(applicationContext)" in main_activity, "MainActivity uses the shared OBD controller")
    require("onDispose { obdController.release() }" not in main_activity, "Activity disposal no longer tears down an active OBD session")
    require("LoganRuntime.releaseObdController()" in main_activity, "backup restore explicitly releases the shared controller")
    require("requestNotificationPermissionIfNeeded" in main_activity, "Android 13+ notification permission is requested when needed")
    require("gpsPermissionLauncher" in main_activity and "ACCESS_FINE_LOCATION" in main_activity, "GPS permission is requested contextually when route recording is enabled")
    require("Konum izni verilmedi. LoganOS normal çalışmaya devam edecek" in main_activity, "denying GPS permission leaves core LoganOS operation available")
    require("driveHistoryEnabled = true" in main_activity, "enabling GPS routing also enables the drive history it belongs to")
    require("updated.copy(gpsRouteEnabled = false)" in main_activity, "disabling drive history cannot leave orphan GPS recording enabled")

    settings_screen = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt")
    require("Arka planda sürüşü sürdür" in settings_screen and "backgroundTripEnabled" in settings_screen, "background driving toggle is exposed in Settings")
    require("GPS rota kaydı" in settings_screen and "gpsRouteEnabled" in settings_screen, "optional GPS route recording toggle is exposed in Settings")
    require("GPX başlangıç/bitiş gizliliği" in settings_screen, "GPX edge privacy control is exposed in Settings")
    require("fuelCalibrationSessionActive" in settings_screen and "Ölçümü başlat" in settings_screen, "persistent full-tank calibration workflow is exposed")
    require("LoganOS’un otomatik hesapladığı yakıt" in settings_screen, "calibration no longer asks the user to retype LoganOS liters")
    require("Yedekleme ve veri yönetimi" in settings_screen, "backup/history settings use an accurate section title")

    prefs = read(root, "app/src/main/java/com/dcui/loganos/data/AppPrefs.kt")
    require("KEY_GPS_ROUTE_ENABLED" in prefs and "KEY_GPS_MASK_EXPORT_EDGES" in prefs, "GPS route preferences are persisted")
    require("KEY_FUEL_CAL_SESSION_ACTIVE" in prefs and "KEY_FUEL_CAL_START_TRIP_TOKEN" in prefs, "full-tank calibration baseline is persisted")
    require("KEY_FUEL_CAL_PROGRESS_DISTANCE" in prefs and "updateFuelCalibrationProgress" in prefs and "tokenChanged" in prefs, "full-tank calibration accumulation survives automatic trip boundaries")
    persistent_trip = read(root, "app/src/main/java/com/dcui/loganos/obd/PersistentCockpitTripAccumulator.kt")
    persistent_store = read(root, "app/src/main/java/com/dcui/loganos/obd/PersistentCockpitTripStore.kt")
    require("PersistentCockpitTripAccumulator" in persistent_trip and "tokenChanged" in persistent_trip, "cockpit trip totals survive automatic history-token changes")
    require("loganos_cockpit_trip_metrics" in persistent_store and "PERSIST_INTERVAL_MS" in persistent_store, "cockpit trip totals are persisted across process and ignition cycles")
    require("persistentCockpitTrip.update(trip" in obd and "persistentCockpitTrip.rebase" in obd, "OBD controller maintains persistent cockpit totals independently of history segments")
    require("avgBaselineMatchesTrip" not in main_activity and "costBaselineMatchesTrip" not in main_activity, "average and cost reset baselines are no longer tied to drive-history trip tokens")
    require(("trackFuelCalibrationProgress(segmentSnapshot)" in obd or "trackFuelCalibrationProgress(measuredSnapshot)" in obd) and "flushFuelCalibrationProgress" in obd, "active full-tank calibration is accumulated by the background-capable OBD controller")
    require("boundaryChanged" in obd and "last sub-batch tail" in obd, "full-tank calibration flushes pending deltas before trip boundaries")
    require("isFuelCalibrationSessionActive" in prefs and "appPrefs.isFuelCalibrationSessionActive()" in obd, "stopped calibration sessions cannot be recreated by a stale polling frame")
    backup_keys_block = prefs.split("RESTORABLE_BACKUP_KEYS", 1)[-1]
    require("KEY_GPS_ROUTE_ENABLED" not in backup_keys_block.split(")", 1)[0], "GPS route opt-in is not silently restored from settings backup")


    # beta.4.10.0 start-analysis gates
    start_analysis = read(root, "app/src/main/java/com/dcui/loganos/obd/StartAnalysis.kt")
    require("object StartAnalyzer" in start_analysis, "persistent start-analysis model/analyzer")
    store = read(root, "app/src/main/java/com/dcui/loganos/data/LoganSqlStore.kt")
    require("CREATE TABLE IF NOT EXISTS start_events" in store, "persistent start_events table")
    require("COALESCE(tr.pinned,0)=0" in store and "LEFT JOIN trip_records" in store, "pinned-drive start events are excluded from rolling retention")
    require("DB_VERSION = 6" in store, "database version migrated for start analysis")
    controller = read(root, "app/src/main/java/com/dcui/loganos/obd/ObdController.kt")
    require("recordDirectObservedStart" in controller, "direct-start observation does not invent crank duration")
    require("StartConfidence.LOW" in controller, "low-confidence OBD-gap handling")
    require("genericCrankSampleReliable" in controller and "sampleReliable = genericCrankSampleReliable" in controller, "generic/petrol start analysis rejects transport-error samples")
    require("KEY_CRANK_ATTEMPT_BOOT" in controller and "persistCrankAttemptRuntime" in controller, "short-window failed-start attempts survive same-boot process restarts")
    require("crankStableSamples >= 3" in controller, "post-start stabilization confirmation")
    require("personal baseline" in start_analysis and "same temperature group" in start_analysis, "personal-history thermal-group trend messaging")
    require("UPDATE start_events SET time_ms" in store, "start events participate in trusted-time re-anchoring")
    require("UPDATE gps_points SET time_ms" in store, "GPS points participate in trusted-time re-anchoring")


    # Ghost runtime gates. Phone, portrait and Double overlays are independent;
    # the approved raster assets remain shared.
    ghost = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPortraitCockpit.kt")
    wide_ghost = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPhoneWideCockpit.kt")
    headunit_ghost = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostHeadUnitCockpit.kt")
    require("val cardHeight = maxHeight" in headunit_ghost, "head-unit card captures BoxWithConstraints height before RowScope")
    require("fontSize = (cardHeight.value * 0.39f)" in headunit_ghost, "head-unit consumption value uses explicit captured height")
    require("fontSize = (cardHeight.value * 0.17f)" in headunit_ghost, "head-unit consumption unit uses explicit captured height")
    for token, label in [
        ("R.drawable.ghost_single_portrait_logan_oem_19_5_9", "Ghost portrait uses the final Logan-OEM asset"),
        ("PortraitNeedleLayer", "Ghost portrait keeps its live RPM needle"),
        ("val rpmMaximum = 7000", "Ghost portrait needle matches the baked 10-70 x100 RPM scale"),
        ('"x100 rpm"', "Ghost portrait labels the Logan OEM RPM scale correctly"),
        ('fontFeatureSettings = "tnum"', "Ghost portrait live values use tabular figures"),
        ("LocalDensity.current.fontScale", "Ghost portrait values compensate for device font scale"),
        ("private object GhostPortraitSlots", "Ghost portrait uses independent measured slots"),
        ("TEMP_WIDTH = 0.6750f", "Ghost portrait coolant card uses the new measured width"),
        ("val absoluteFloor = 1f", "Ghost portrait text fitting can shrink below the old invalid floor"),
    ]:
        require(token in ghost, label)
    require("TextOverflow.Visible" not in ghost, "Ghost portrait text never escapes its measured slot")
    require("ghost_portrait_master" not in ghost, "obsolete portrait asset is not referenced")
    require(
        "fun GhostSinglePortraitCockpit" in ghost
        and "private fun GhostPortraitStage" in ghost
        and "modifier.fillMaxSize()" in ghost
        and "PORTRAIT_ASPECT" not in ghost
        and ".background(Color.Black)" not in ghost,
        "Ghost portrait uses the full-bleed asset path without letterbox bands"
    )

    for token, label in [
        ("R.drawable.ghost_single_logan_oem_19_5_9", "phone Ghost Single uses the final Logan-OEM asset"),
        ("R.drawable.ghost_dual_logan_oem_19_5_9", "phone Ghost Dual uses the final Logan-OEM asset"),
        ("ContentScale.FillBounds", "phone 19.5:9 assets fill the cockpit stage"),
        ("val rpmMaximum = 7000", "phone RPM needles match the baked 10-70 x100 scale"),
        ('subtitle = "x100 rpm"', "phone RPM units match the baked Logan scale"),
        ("WidePhoneStage", "phone landscape Ghost keeps its measured renderer"),
    ]:
        require(token in wide_ghost, label)
    for token, label in [
        ("fun GhostSingleHeadUnitCockpit", "Double Ghost Single has an independent overlay"),
        ("fun GhostDualHeadUnitCockpit", "Double Ghost Dual has an independent overlay"),
        ("R.drawable.ghost_single_logan_oem_19_5_9", "Double Single reuses the approved asset"),
        ("R.drawable.ghost_dual_logan_oem_19_5_9", "Double Dual reuses the approved asset"),
        ("HeadUnitDualMetricCard", "Double Dual has head-unit-specific metric typography"),
        ("takeLast(14)", "Double trend history is bounded for AC8227L"),
        ('text = if (unit.isBlank()) "" else " $unit"', "Double value and unit share one line"),
    ]:
        require(token in headunit_ghost, label)
    require("WideDialLabels" not in wide_ghost and "WideDialLabelAnchor" not in wide_ghost, "scale numerals are baked into assets, not redrawn by Compose")
    require("speedOnLeft" not in wide_ghost and "speedOnLeft" not in headunit_ghost, "Dual is fixed to left RPM and right speed")
    for source in (wide_ghost, headunit_ghost):
        for forbidden, label in [
            ("ghost_single_master_headunit", "old Single head-unit asset is not referenced"),
            ("ghost_dual_speed_left_master_headunit", "old Dual head-unit asset is not referenced"),
            ("ghost_landscape_extension", "old letterbox extension is not referenced"),
            ("GhostStageHost", "old contained/letterboxed landscape host is removed"),
        ]:
            require(forbidden not in source, label)

    for forbidden, label in [
        ("REFERENCE_INTRO_MS", "Ghost opening timeline is fully removed"),
        ("GhostReferenceIntroOverlay", "Ghost procedural opening overlay is fully removed"),
        ("GhostIntroController", "Ghost intro state controller is fully removed"),
        ("timeline.animateTo", "Ghost screens open directly without an intro wait"),
        ("RpmBar", "obsolete short Single RPM strip is removed"),
        ("ghost_reference_single_runtime_plate", "old Ghost Single runtime plate is no longer referenced"),
        ("ghost_reference_dual_runtime_plate", "old Ghost Dual runtime plate is no longer referenced"),
        ("ghost_reference_portrait_runtime_plate", "old Ghost portrait runtime plate is no longer referenced"),
    ]:
        require(forbidden not in ghost and forbidden not in wide_ghost, label)
    require(not (root / "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostCockpit.kt").exists(), "obsolete GhostCockpit implementation is removed")
    obsolete_assets = [
        "ghost_opening_scene.webp", "ghost_landscape_scene.webp", "ghost_portrait_scene.webp",
        "ghost_single_shell.png", "ghost_single_portrait_shell.png",
        "ghost_dual_diesel_rpm_left_shell.png", "ghost_dual_diesel_speed_left_shell.png",
        "ghost_dual_petrol_rpm_left_shell.png", "ghost_dual_petrol_speed_left_shell.png",
        "ghost_reference_single_runtime_plate.webp", "ghost_reference_dual_runtime_plate.webp",
        "ghost_reference_portrait_runtime_plate.webp",
        "ghost_single_master_headunit.webp", "ghost_dual_speed_left_master_headunit.webp",
        "ghost_landscape_extension.webp",
    ]
    drawable_root = root / "app/src/main/res/drawable-nodpi"
    require(all(not (drawable_root / name).exists() for name in obsolete_assets), "obsolete Ghost assets are removed from the runtime package")

    manifest_for_media = read(root, "app/src/main/AndroidManifest.xml")
    media_marker = 'android:name=".media.MediaIntegrationTestActivity"'
    require(media_marker in manifest_for_media, "Media Integration Test activity remains registered for developer-only access")
    media_tail = manifest_for_media[manifest_for_media.index(media_marker):]
    media_ends = [index for index in (media_tail.find('/>'), media_tail.find('</activity>')) if index >= 0]
    require(bool(media_ends), "Media Integration Test activity manifest block is readable")
    media_block = media_tail[: min(media_ends) + 11]
    require('android:exported="false"' in media_block, "Media Integration Test activity is no longer exported")
    require('android.intent.category.LAUNCHER' not in media_block, "Media Integration Test no longer creates a second launcher icon")

    for forbidden, label in [
        ("YAKIT SEVİYESİ", "Ghost UI does not invent a fuel-level field"),
        ("KALAN MENZİL", "Ghost UI does not invent remaining range"),
        ("DIŞ SICAKLIK", "Ghost UI does not invent outside temperature"),
        ("ECO", "Ghost UI does not invent ECO state"),
        ("VİTES", "Ghost UI does not invent gear position"),
    ]:
        require(forbidden not in ghost and forbidden not in wide_ghost, label)

    premium_drive = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/PremiumDriveCockpit.kt")
    for token, label in [
        ("R.drawable.premium_drive_road_base", "Premium Drive uses the prepared city-road master asset"),
        ("R.drawable.premium_drive_road_flow", "Premium Drive uses the clean road-surface motion layer"),
        ("R.drawable.premium_drive_vehicle_shadow", "Premium Drive uses the prepared vehicle contact-shadow asset"),
        ("PremiumRoadFlowLayer", "Premium Drive has the cross-faded forward-road motion loop"),
        ("fillMaxWidth(0.30f)", "Premium Drive Logan is reduced for a deeper road perspective"),
        ("fillMaxHeight(0.35f)", "Premium Drive Logan height is reduced for a deeper road perspective"),
        ("offset(y = (-14f * scale).dp)", "Premium Drive Logan is moved forward into the road scene"),
        ("wideHeadUnit", "Premium Drive has a dedicated wide-head-unit readability scale"),
        ("PremiumTripSummary", "Premium Drive has the approved drive-summary column"),
        ("PremiumConsumptionMetric", "Premium Drive has bottom consumption widgets"),
        ("PremiumCoolantMetric", "Premium Drive has the requested coolant bar widget"),
        ("PremiumMediaMode.Radio", "Premium Drive media card can switch to radio mode"),
    ]:
        require(token in premium_drive, label)
    require("R.drawable.ic_premium_music_note" in premium_drive, "Premium Drive uses a non-clipping vector music icon")
    require("PremiumMediaLaunchRequest" in premium_drive and "System.nanoTime()" in premium_drive, "Premium media source tabs process every tap, including the selected source")
    require("fontSize = (17f * scale).sp" in premium_drive, "Premium Drive AIMP/Radio source labels are enlarged for Double")
    require("fontSize = (16f * scale).sp" in premium_drive, "Premium Drive summary labels are enlarged for Double")
    require("R.drawable.premium_drive_lane_lights_left" not in premium_drive, "old left neon-streak layer is removed from Premium Drive")
    require("R.drawable.premium_drive_lane_lights_right" not in premium_drive, "old right neon-streak layer is removed from Premium Drive")
    require("Canvas(" not in premium_drive, "Premium Drive no longer draws artifact-prone road lines in Canvas")
    require("Static perspective guides" not in premium_drive, "Premium Drive no longer draws the old long static guide rays")
    require(
        not (root / "app/src/main/res/drawable-nodpi/premium_drive_lane_lights_left.webp").exists(),
        "obsolete Premium Drive left neon-streak asset is removed"
    )
    require(
        not (root / "app/src/main/res/drawable-nodpi/premium_drive_lane_lights_right.webp").exists(),
        "obsolete Premium Drive right neon-streak asset is removed"
    )
    require(
        not (root / "app/src/main/res/drawable-nodpi/premium_drive_city_skyline_far.webp").exists(),
        "redundant Premium Drive skyline layer is removed"
    )
    require(
        not (root / "app/src/main/res/drawable-nodpi/premium_drive_horizon_glow.webp").exists(),
        "redundant Premium Drive horizon layer is removed"
    )

    cockpit_visuals = read(root, "app/src/main/java/com/dcui/loganos/ui/components/CockpitVisuals.kt")
    require("COOLANT_COLD_LIMIT_C = 75" in cockpit_visuals, "cold coolant colour remains ice blue below 75 C")
    require("COOLANT_CRITICAL_LIMIT_C = 103" in cockpit_visuals, "critical coolant threshold remains 103 C")

    models_demo = read(root, "app/src/main/java/com/dcui/loganos/model/Models.kt")
    require("tick.coerceAtMost(340) * 0.12" in models_demo, "demo coolant warm-up uses the slower natural curve")

    dashboard_nav = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt")
    require("MainTab.VehicleHealth -> CardIcon.EngineFault" in dashboard_nav, "Vehicle Health uses a distinct navigation icon")
    require("MainTab.Technical -> CardIcon.EcuStatus" in dashboard_nav, "Technical keeps the ECU navigation icon")
    require("tint = if (selected) palette.accent else Color.Unspecified" in dashboard_nav, "selected navigation icon follows the accent colour")

    main_activity = read(root, "app/src/main/java/com/dcui/loganos/MainActivity.kt")
    require(
        "phoneGhostDualLandscape" in main_activity
        and "settings.gaugeStyle == GaugeStyle.GhostDual" in main_activity
        and "GaugeStyle.GhostSingle || settings.gaugeStyle == GaugeStyle.GhostDual" not in main_activity,
        "phone Ghost Single follows device rotation while Ghost Dual remains landscape-only"
    )
    require("ghostPhoneWideTrialEnabled" not in main_activity, "obsolete phone Ghost trial preference is removed from orientation logic")
    wide_phone = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPhoneWideCockpit.kt")
    wide_headunit = read(root, "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostHeadUnitCockpit.kt")
    require("ghost_single_logan_oem_19_5_9" in wide_phone and "ghost_dual_logan_oem_19_5_9" in wide_phone, "final Logan-OEM 19.5:9 assets are wired into phone runtime")
    require("ghost_single_logan_oem_19_5_9" in wide_headunit and "ghost_dual_logan_oem_19_5_9" in wide_headunit, "approved assets are reused by Double without replacements")
    require("GhostSinglePhoneWideCockpit" in dashboard_nav and "GhostDualPhoneWideCockpit" in dashboard_nav, "phone Ghost Single and Dual keep their own renderer")
    require("GhostSingleHeadUnitCockpit" in dashboard_nav and "GhostDualHeadUnitCockpit" in dashboard_nav, "Double Ghost Single and Dual use separate overlays")
    require(
        "portrait && ghostSingle" in dashboard_nav
        and "GhostSinglePortraitCockpit" in dashboard_nav,
        "phone Ghost Single portrait mode remains reachable"
    )
    for token, label in [
        ("ghost_single_logan_oem_19_5_9", "Ghost Single uses the baked Logan-OEM scale asset"),
        ("ghost_dual_logan_oem_19_5_9", "Ghost Dual uses the baked Logan-OEM scale asset"),
        ("val rpmMaximum = 7000", "RPM needles use the fixed Logan OEM full scale"),
        ('title = "DEVİR"', "Dual left gauge remains RPM"),
        ('title = "HIZ"', "Dual right gauge remains speed"),
        ("emphasizeValue = true", "Ghost Single digital speed readout is enlarged"),
        ("0.21f", "phone Ghost metric text is optically shifted downward"),
        ("maxHeight * 0.61f", "phone Ghost coolant value is shifted downward with its label"),
    ]:
        require(token in wide_phone, label)
    require("minimumVisibleLength = size.minDimension * 0.160f" in wide_phone and "tipDistance = radiusPx * 0.900f" in wide_phone and "visibleLength = maxOf" in wide_phone, "all Ghost gauges use the shared tapered OEM needle")
    require("private fun wideLiveValues(" in wide_phone and "private fun compactWideUnit(" in wide_phone and "private fun wideOne(" in wide_phone and "private fun wideUnit(" in wide_phone, "phone Ghost live-value formatting helpers are present")
    require("drawPath(needle" in wide_phone and "GhostNeedleGeometry" in wide_phone and "drawGhostNeedle(" in ghost, "Ghost needle shape and layering are standardized")
    require("headUnitCockpit" in dashboard and "immersiveCockpit" in dashboard and "WindowInsetsCompat.Type.statusBars()" in dashboard, "Double cockpit and phone Ghost hide the status bar")
    require("View.SYSTEM_UI_FLAG_FULLSCREEN" in dashboard and "View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN" in dashboard, "API 27 head-unit fullscreen fallback is present")
    require("displayCutoutPadding" in dashboard and "navigationBarsPadding" in dashboard, "phone cutout and navigation safety remain separate from Double")
    require("WideDialLabels" not in wide_phone and "WideDialLabelAnchor" not in wide_phone, "Compose scale-number overlay is removed")
    require("ghostPhoneWideTrialEnabled" not in models and "ghostPhoneWideTrialEnabled" not in app_prefs, "obsolete phone Ghost trial setting is removed")

    vehicle_assets = read(root, "app/src/main/java/com/dcui/loganos/ui/components/VehicleVisualAssets.kt")
    require("VehicleVisualModel.LoganI" in vehicle_assets and "VehicleVisualModel.LoganIII" in vehicle_assets, "both Logan generations remain mapped")
    require("VehicleAssetStyle.OemSimplified" in vehicle_assets, "Digital/Classic OEM vehicle asset path remains available")

    drawable_root = root / "app/src/main/res/drawable-nodpi"
    expected_vehicle_assets = [
        *(f"loganos_logan_rear_{color}" for color in ("cherry_red", "white", "gray", "blue", "green", "yellow")),
        *(f"loganos_logan_rear_oem_{color}" for color in ("cherry_red", "white", "gray", "blue", "green", "yellow")),
        *(f"loganos_logan3_rear_{color}" for color in ("cherry_red", "white", "gray", "blue", "green", "yellow")),
    ]
    for stem in expected_vehicle_assets:
        candidates = [drawable_root / f"{stem}.webp", drawable_root / f"{stem}.png"]
        image_path = next((path for path in candidates if path.is_file()), None)
        require(image_path is not None, f"vehicle asset exists: {stem}.webp/.png")
        require(image_path.stat().st_size > 0, f"vehicle asset is non-empty: {image_path.name}")

    for stem in ("ghost_single_logan_oem_19_5_9", "ghost_dual_logan_oem_19_5_9"):
        asset_path = drawable_root / f"{stem}.webp"
        require(asset_path.is_file() and asset_path.stat().st_size > 0, f"final landscape Ghost asset exists: {stem}.webp")
        require(image_dimensions(asset_path) == (1846, 852), f"final landscape Ghost asset is exactly 1846x852: {stem}.webp")

    portrait_asset = drawable_root / "ghost_single_portrait_logan_oem_19_5_9.webp"
    require(portrait_asset.is_file() and portrait_asset.stat().st_size > 0, "final portrait Ghost asset exists")
    require(image_dimensions(portrait_asset) == (852, 1846), "final portrait Ghost asset is exactly 852x1846")
    for obsolete in ("ghost_single_phone_19_5_9.webp", "ghost_dual_phone_19_5_9.webp", "ghost_portrait_master.png"):
        require(not (drawable_root / obsolete).exists(), f"obsolete Ghost asset is physically removed: {obsolete}")
    require(not (drawable_root / "ghost_single_master.png").exists(), "obsolete phone Ghost Single asset is removed")
    require(not (drawable_root / "ghost_dual_speed_left_master.png").exists(), "obsolete phone Ghost Dual asset is removed")

    drawable_xml_root = root / "app/src/main/res/drawable"
    for stem in ("ghost_setup_single_preview", "ghost_setup_dual_preview"):
        require(not (drawable_root / f"{stem}.webp").exists(), f"legacy Ghost setup raster preview is removed: {stem}.webp")
        require(not (drawable_xml_root / f"{stem}.xml").exists(), f"legacy Ghost setup XML preview is removed: {stem}.xml")

    selection = read(root, "app/src/main/java/com/dcui/loganos/ui/screens/VehicleVisualSelectionScreen.kt")
    require("Logan I (2005–2012)" in selection and "Logan III (2021+)" in selection, "vehicle picker identifies both Logan generations clearly")
    require("VehicleColor.entries" in selection and "onSave(selectedModel, selectedColor)" in selection, "vehicle picker saves model and colour together")

    workflow = read(root, ".github/workflows/build-apk.yml")
    uses_lines = [line.strip() for line in workflow.splitlines() if line.strip().startswith("uses:")]
    require(bool(uses_lines) and all(re.search(r"@[0-9a-f]{40}(?:\s|$)", line) for line in uses_lines), "build workflow actions are pinned to immutable SHAs")
    require("permissions:\n  contents: read" in workflow, "build workflow uses minimum contents permission")
    forbidden_signing_refs = (
        "release-signing",
        "secrets.LOGANOS_",
        "assembleRelease",
        "app-release.apk",
        "Build release APK",
    )
    require(not any(token in workflow for token in forbidden_signing_refs), "general build workflow is isolated from production signing")
    require("assembleDebug" in workflow and "app-debug.apk" in workflow, "general build workflow produces debug APK only")

    publish_workflow = read(root, ".github/workflows/publish-secure-release.yml")
    publish_uses = [line.strip() for line in publish_workflow.splitlines() if line.strip().startswith("uses:")]
    require(bool(publish_uses) and all(re.search(r"@[0-9a-f]{40}(?:\s|$)", line) for line in publish_uses), "secure publish workflow actions are pinned to immutable SHAs")
    require("environment: release-signing" in publish_workflow, "release signing is protected by environment approval")
    require("secrets.LOGANOS_KEYSTORE_BASE64" in publish_workflow, "production signing secrets remain exclusive to secure publish workflow")

    file_paths = read(root, "app/src/main/res/xml/file_paths.xml")
    require('path="."' not in file_paths, "FileProvider does not expose broad root paths")
    require('path="exports/"' in file_paths, "private legacy export path is explicitly allow-listed")
    require("WRITE_EXTERNAL_STORAGE" not in manifest, "legacy public-storage permission is removed")

    route_map = read(root, "app/src/main/java/com/dcui/loganos/ui/components/RouteMap.kt")
    require("MAX_TILE_RESPONSE_BYTES" in route_map and "hasPngSignature" in route_map, "OSM tile size/type validation")
    require("instanceFollowRedirects = false" in route_map, "OSM redirects are not followed implicitly")

    require("VISIBILITY_PRIVATE" in service and "setPublicVersion" in service, "foreground notification lock-screen privacy")

    gradle = read(root, "app/build.gradle.kts")
    debug_block = gradle.split("debug {", 1)[1].split("}", 1)[0] if "debug {" in gradle else ""
    require("signingConfig" not in debug_block, "debug APK never uses production signing key")

    print("\nAll static release gates passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


# Ghost metric layout must not depend on live trend availability.
_ghost_wide = ROOT / "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPhoneWideCockpit.kt"
if _ghost_wide.exists():
    _ghost_text = _ghost_wide.read_text(encoding="utf-8")
    if "val hasTrend = trend.isNotEmpty()" in _ghost_text:
        fail("Ghost metric text layout still changes with trend/demo state")
    require_text(_ghost_text, "val tallCard = rect.height > 0.18f", str(_ghost_wide))
    require_text(_ghost_text, "val showTrend = tallCard && trend.isNotEmpty()", str(_ghost_wide))
