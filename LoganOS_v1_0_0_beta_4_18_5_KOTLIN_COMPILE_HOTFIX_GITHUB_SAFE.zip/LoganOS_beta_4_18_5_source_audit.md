# LoganOS beta.4.18.5 — Kaynak Denetimi

## Bulunan hata

GitHub Actions `compileReleaseKotlin`, `DigitalV2Cockpit.kt` içindeki statik
ayarlar önizlemesinde kullanılan `DIGITAL_V2_LOGICAL_WIDTH` sabitini
çözemedi. Sabit OpenGL alt paketinde tanımlıydı fakat cockpit dosyasına import
edilmemişti. Logdaki `times` hataları bu çözülmeyen değerin ikincil sonucuydu.

## Uygulanan düzeltme

- Doğru çapraz paket importu eklendi.
- Sürüm `1.0.0-beta.4.18.5 / 100000685` olarak artırıldı.
- validate_release ve Digital V2 audit kapılarına zorunlu import kontrolü eklendi.

## Ayrıntılı tarama

OpenGL modelinde tanımlı tüm `DIGITAL_V2_*` sabitleri tarandı. OpenGL paketi
dışında kullanılan sabitlerin yalnız `DigitalV2Cockpit.kt` içinde bulunduğu ve
şimdi gerekli importlara sahip olduğu doğrulandı.

Eski Digital V2 runtime sistemi, eski baked road/wind kareleri veya yeni
renderer'ı devre dışı bırakacak alternatif çağrı yolu bulunmadı. Görsel kod
beta.4.18.4 ile aynıdır.

## Sonuç

Kaynak seviyesindeki bildirilen Kotlin derleme hatası giderildi. Gerçek Android
Gradle derlemesi yalnız GitHub Actions üzerinde kesinleşebilir.
