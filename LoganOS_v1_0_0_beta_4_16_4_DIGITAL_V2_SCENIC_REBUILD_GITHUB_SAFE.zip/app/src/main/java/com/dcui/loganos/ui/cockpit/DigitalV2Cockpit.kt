package com.dcui.loganos.ui.cockpit

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DigitalV2GaugeMode
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.rememberScenicMotionPhases
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.cos
import kotlin.math.sin

private val DigitalV2Blue = Color(0xFF1479FF)
private val DigitalV2Red = Color(0xFFFF3B30)
private val DigitalV2Glass = Color(0xEAF7F9FC)

private data class DigitalV2SceneMotion(
    val moving: Boolean,
    val roadPhase: Float,
    val motionStrength: Float,
    val suspensionLift: Float,
    val swayWave: Float,
    val shadowScaleX: Float,
    val shadowScaleY: Float,
    val shadowAlpha: Float
)

@Composable
private fun rememberDigitalV2SceneMotion(speedKmh: Int?, enabled: Boolean): DigitalV2SceneMotion {
    val currentSpeed = speedKmh ?: 0
    val scenic = rememberScenicMotionPhases(speedKmh = speedKmh, enabled = enabled)
    val moving = enabled && currentSpeed >= 5
    val motionStrength = when {
        !moving -> 0f
        currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
        currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
        currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
        else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
    }.coerceIn(0f, 1f)
    val dynamicsAngle = scenic.dynamicsTime * 2f * PI.toFloat()
    val bobWave = if (moving) {
        val primary = sin(dynamicsAngle.toDouble()).toFloat()
        val secondary = 0.30f * sin((dynamicsAngle * 2.70f + 0.62f).toDouble()).toFloat()
        val bodySettle = 0.14f * sin((dynamicsAngle * 0.57f + 1.38f).toDouble()).toFloat()
        (primary + secondary + bodySettle) / 1.44f
    } else 0f
    val asphaltMicroWave = if (moving) {
        val coarse = sin((dynamicsAngle * 12f + 0.20f).toDouble()).toFloat()
        val fine = sin((dynamicsAngle * 18.40f + 1.15f).toDouble()).toFloat()
        (coarse * 0.68f + fine * 0.32f) * (0.08f + 0.07f * motionStrength)
    } else 0f
    val suspensionLift = (bobWave + asphaltMicroWave).coerceIn(-1.20f, 1.20f)
    val swayWave = if (moving) {
        val slowWeightShift = 0.68f * sin((dynamicsAngle * 0.71f + 0.85f).toDouble()).toFloat()
        val secondaryRoll = 0.22f * sin((dynamicsAngle * 1.93f + 2.10f).toDouble()).toFloat()
        val roadCorrection = 0.10f * sin((dynamicsAngle * 4.40f + 0.22f).toDouble()).toFloat()
        slowWeightShift + secondaryRoll + roadCorrection
    } else 0f
    val shadowScaleX = (1f + suspensionLift * 0.013f).coerceIn(0.984f, 1.018f)
    val shadowScaleY = (1f + suspensionLift * 0.006f).coerceIn(0.992f, 1.009f)
    val shadowAlpha = (0.94f - suspensionLift * 0.10f).coerceIn(0.80f, 1f)
    return DigitalV2SceneMotion(
        moving = moving,
        roadPhase = scenic.roadPhase,
        motionStrength = motionStrength,
        suspensionLift = suspensionLift,
        swayWave = swayWave,
        shadowScaleX = shadowScaleX,
        shadowScaleY = shadowScaleY,
        shadowAlpha = shadowAlpha
    )
}


@Composable
fun DigitalV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    portrait: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    if (portrait) {
        DigitalV2PortraitCockpit(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick
        )
    } else {
        DigitalV2LandscapeCockpit(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick
        )
    }
}

@Composable
private fun DigitalV2PortraitCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        val sceneHeight = maxHeight * 0.61f
        val panelTop = maxHeight * 0.585f
        val gaugeHeight = sceneHeight * 0.78f
        val carWidth = maxWidth * 0.31f
        val movement = settings.digitalV2MotionEnabled
        val sceneMotion = rememberDigitalV2SceneMotion(snapshot.speedKmh, movement)

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(sceneHeight)
        ) {
            Image(
                painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = Alignment.BottomCenter,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0x3006244A),
                                Color.Transparent,
                                Color(0x18071324),
                                Color(0x4A081420)
                            )
                        )
                    )
            )

            DigitalV2RoadMotion(
                roadPhase = sceneMotion.roadPhase,
                motionStrength = sceneMotion.motionStrength,
                modifier = Modifier.fillMaxSize()
            )

            DigitalV2WindOverlay(
                roadPhase = sceneMotion.roadPhase,
                motionStrength = sceneMotion.motionStrength,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(42.dp)
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color(0xDDE9EEF4))
                        )
                    )
            )

            DigitalV2Header(
                tr = tr,
                connected = snapshot.connected || obdState.connected,
                demo = settings.demoMode || snapshot.demo,
                onOpenReset = onOpenReset,
                onObdClick = onObdClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            )

            DigitalV2Gauge(
                mode = settings.digitalV2GaugeMode,
                speedKmh = snapshot.speedKmh,
                rpm = snapshot.rpm,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 6.dp)
                    .fillMaxWidth(0.985f)
                    .height(gaugeHeight)
            )

            DigitalV2Vehicle(
                settings = settings,
                width = carWidth,
                motion = sceneMotion,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = 12.dp)
            )
        }

        DigitalV2DataPanel(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            tr = tr,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(top = panelTop)
        )
    }
}

@Composable
private fun DigitalV2LandscapeCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val movement = settings.digitalV2MotionEnabled
    val sceneMotion = rememberDigitalV2SceneMotion(snapshot.speedKmh, movement)
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        Box(modifier = Modifier.weight(1.55f).fillMaxHeight()) {
            Image(
                painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                alignment = Alignment.BottomCenter,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0x32052242), Color.Transparent, Color(0x60061018))))
            )
            DigitalV2RoadMotion(sceneMotion.roadPhase, sceneMotion.motionStrength, Modifier.fillMaxSize())
            DigitalV2WindOverlay(sceneMotion.roadPhase, sceneMotion.motionStrength, Modifier.fillMaxSize())
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(36.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color(0xDDE9EEF4))))
            )
            DigitalV2Header(
                tr = tr,
                connected = snapshot.connected || obdState.connected,
                demo = settings.demoMode || snapshot.demo,
                onOpenReset = onOpenReset,
                onObdClick = onObdClick,
                modifier = Modifier.fillMaxWidth().padding(10.dp)
            )
            DigitalV2Gauge(
                mode = settings.digitalV2GaugeMode,
                speedKmh = snapshot.speedKmh,
                rpm = snapshot.rpm,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp).fillMaxWidth(0.94f).fillMaxHeight(0.86f)
            )
            DigitalV2Vehicle(
                settings = settings,
                width = 166.dp,
                motion = sceneMotion,
                modifier = Modifier.align(Alignment.BottomCenter).offset(y = 10.dp)
            )
        }
        DigitalV2CompactDataPanel(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            tr = tr,
            modifier = Modifier.weight(1f).fillMaxHeight()
        )
    }
}

@Composable
private fun DigitalV2Header(
    tr: Boolean,
    connected: Boolean,
    demo: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White.copy(alpha = .16f))
                .border(1.dp, Color.White.copy(alpha = .30f), RoundedCornerShape(13.dp))
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xB2123657))
                .border(1.dp, Color.White.copy(alpha = .27f), RoundedCornerShape(14.dp))
                .clickable(onClick = onObdClick)
                .padding(horizontal = 11.dp, vertical = 9.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    demo -> "DEMO"
                    connected -> if (tr) "OBD BAĞLI" else "OBD ON"
                    else -> if (tr) "OBD BEKLENİYOR" else "OBD WAITING"
                },
                color = if (connected || demo) Color(0xFF9BE8B5) else Color.White,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DigitalV2Gauge(
    mode: DigitalV2GaugeMode,
    speedKmh: Int?,
    rpm: Int?,
    modifier: Modifier = Modifier,
    preview: Boolean = false
) {
    val rawProgress = when (mode) {
        DigitalV2GaugeMode.Speed -> ((speedKmh ?: 0) / 200f).coerceIn(0f, 1f)
        DigitalV2GaugeMode.Rpm -> ((rpm ?: 0) / 7000f).coerceIn(0f, 1f)
    }

    val progress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(if (preview) 0 else 380),
        label = "digitalV2GaugeProgress"
    )

    val labels = if (mode == DigitalV2GaugeMode.Speed) (0..200 step 20).toList() else (0..70 step 10).toList()
    val majorCount = labels.lastIndex.coerceAtLeast(1)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * 0.485f
            val center = Offset(size.width / 2f, size.height * 0.60f)
            val startAngle = 145f
            val sweep = 250f
            val arcTopLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = Size(radius * 2f, radius * 2f)

            drawArc(
                color = Color.White.copy(alpha = .92f),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.014f, cap = StrokeCap.Round)
            )

            drawArc(
                brush = Brush.sweepGradient(listOf(DigitalV2Blue, Color.White, Color.White, DigitalV2Red), center),
                startAngle = startAngle,
                sweepAngle = sweep * progress,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.021f, cap = StrokeCap.Round)
            )

            val minorTicks = majorCount * 5
            repeat(minorTicks + 1) { index ->
                val fraction = index / minorTicks.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val major = index % 5 == 0
                val outer = radius * 0.99f
                val inner = radius * if (major) 0.865f else 0.925f

                val p1 = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner)
                val p2 = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer)

                drawLine(
                    color = Color.White.copy(alpha = if (major) .98f else .67f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (major) radius * .014f else radius * .0055f,
                    cap = StrokeCap.Round
                )
            }

            labels.forEachIndexed { index, value ->
                val fraction = index / majorCount.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val labelRadius = radius * .735f
                val x = center.x + cos(angle).toFloat() * labelRadius
                val y = center.y + sin(angle).toFloat() * labelRadius + radius * .038f

                drawContext.canvas.nativeCanvas.drawText(
                    value.toString(),
                    x,
                    y,
                    Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.WHITE
                        textAlign = Paint.Align.CENTER
                        textSize = radius * if (preview) .112f else .124f
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        setShadowLayer(radius * .020f, 0f, radius * .009f, android.graphics.Color.argb(175, 0, 0, 0))
                    }
                )
            }

            val needleAngle = Math.toRadians((startAngle + sweep * progress).toDouble())
            val needleStart = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .14f,
                center.y + sin(needleAngle).toFloat() * radius * .14f
            )
            val needleEnd = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .80f,
                center.y + sin(needleAngle).toFloat() * radius * .80f
            )

            // Keep the centre clear so the needle never cuts through the digital value.
            drawLine(Color.White.copy(alpha = .98f), needleStart, needleEnd, radius * .018f, StrokeCap.Round)
        }

        // The ring and needle show the selected gauge; the centre shows the other live value.
        val centerValue = when (mode) {
            DigitalV2GaugeMode.Speed -> rpm?.let { (it / 100).toString() } ?: "--"
            DigitalV2GaugeMode.Rpm -> speedKmh?.toString() ?: "--"
        }
        val centerUnit = if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h"
        val textShadow = Shadow(
            Color.Black.copy(alpha = .70f),
            Offset(0f, if (preview) 1f else 2f),
            if (preview) 3f else 7f
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = maxHeight * 0.075f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                centerValue,
                color = Color.White,
                fontSize = if (preview) 34.sp else 72.sp,
                fontWeight = FontWeight.Black,
                lineHeight = if (preview) 34.sp else 72.sp,
                style = TextStyle(shadow = textShadow)
            )
            Text(
                centerUnit,
                color = Color.White.copy(alpha = .96f),
                fontSize = if (preview) 9.5.sp else 16.sp,
                fontWeight = FontWeight.Black,
                style = TextStyle(shadow = textShadow)
            )
        }
    }
}

@Composable
private fun DigitalV2Vehicle(
    settings: LoganSettings,
    width: Dp,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val verticalPx = with(density) { (0.90.dp + 1.05.dp * motion.motionStrength).toPx() }
    val horizontalPx = with(density) { (0.22.dp + 0.32.dp * motion.motionStrength).toPx() }
    Box(modifier = modifier.width(width), contentAlignment = Alignment.BottomCenter) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth(.68f)
                .height(width * .12f)
                .align(Alignment.BottomCenter)
                .offset(y = width * .016f)
                .graphicsLayer {
                    scaleX = motion.shadowScaleX
                    scaleY = motion.shadowScaleY
                    alpha = motion.shadowAlpha
                }
        ) {
            drawOval(
                brush = Brush.radialGradient(
                    listOf(
                        Color.Black.copy(alpha = .28f),
                        Color.Black.copy(alpha = .10f),
                        Color.Transparent
                    )
                )
            )
        }
        Image(
            painter = painterResource(
                vehicleVisualDrawableRes(
                    settings.vehicleVisualModel,
                    settings.vehicleColor,
                    VehicleAssetStyle.Detailed
                )
            ),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationY = -motion.suspensionLift * verticalPx
                    translationX = motion.swayWave * horizontalPx
                    rotationZ = motion.swayWave * .12f * motion.motionStrength
                    transformOrigin = TransformOrigin(0.5f, 0.90f)
                }
        )
    }
}

@Composable
private fun DigitalV2RoadMotion(
    roadPhase: Float,
    motionStrength: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val wide = size.width / size.height > 1.15f
        val p0: Offset
        val p1: Offset
        val p2: Offset
        val p3: Offset
        val farHalfWidth: Float
        val nearHalfWidth: Float
        if (wide) {
            p0 = Offset(size.width * .60f, size.height * .62f)
            p1 = Offset(size.width * .70f, size.height * .67f)
            p2 = Offset(size.width * .64f, size.height * .83f)
            p3 = Offset(size.width * .53f, size.height * 1.02f)
            farHalfWidth = size.width * .024f
            nearHalfWidth = size.width * .315f
        } else {
            p0 = Offset(size.width * .60f, size.height * .69f)
            p1 = Offset(size.width * .71f, size.height * .75f)
            p2 = Offset(size.width * .66f, size.height * .87f)
            p3 = Offset(size.width * .56f, size.height * 1.03f)
            farHalfWidth = size.width * .020f
            nearHalfWidth = size.width * .370f
        }

        fun point(t: Float): Offset {
            val u = 1f - t
            val uu = u * u
            val tt = t * t
            return Offset(
                uu * u * p0.x + 3f * uu * t * p1.x + 3f * u * tt * p2.x + tt * t * p3.x,
                uu * u * p0.y + 3f * uu * t * p1.y + 3f * u * tt * p2.y + tt * t * p3.y
            )
        }

        fun tangent(t: Float): Offset {
            val u = 1f - t
            val x = 3f * u * u * (p1.x - p0.x) + 6f * u * t * (p2.x - p1.x) + 3f * t * t * (p3.x - p2.x)
            val y = 3f * u * u * (p1.y - p0.y) + 6f * u * t * (p2.y - p1.y) + 3f * t * t * (p3.y - p2.y)
            val len = kotlin.math.sqrt(x * x + y * y).coerceAtLeast(.001f)
            return Offset(x / len, y / len)
        }

        fun perspective(t: Float): Float = t.coerceIn(0f, 1f).pow(2.10f)

        fun roadPoint(t: Float, lateral: Float): Offset {
            val c = point(t)
            val tan = tangent(t)
            val normal = Offset(-tan.y, tan.x)
            val hw = farHalfWidth + (nearHalfWidth - farHalfWidth) * perspective(t)
            return Offset(c.x + normal.x * hw * lateral, c.y + normal.y * hw * lateral)
        }

        val roadMask = Path().apply {
            val leftNear = roadPoint(1f, -1f)
            moveTo(leftNear.x, leftNear.y)
            for (step in 26 downTo 0) {
                val tt = step / 26f
                val pt = roadPoint(tt, -1f)
                lineTo(pt.x, pt.y)
            }
            for (step in 0..26) {
                val tt = step / 26f
                val pt = roadPoint(tt, 1f)
                lineTo(pt.x, pt.y)
            }
            close()
        }

        clipPath(roadMask) {
            repeat(6) { index ->
                val depth = 0.07f + index * 0.12f
                val p = perspective(depth)
                val endDepth = (depth + 0.020f + 0.060f * p).coerceAtMost(0.97f)
                drawLine(
                    color = Color.White.copy(alpha = 0.18f + 0.18f * p),
                    start = roadPoint(depth, 0f),
                    end = roadPoint(endDepth, 0f),
                    strokeWidth = 0.7.dp.toPx() + 2.6.dp.toPx() * p,
                    cap = StrokeCap.Round
                )
            }

            if (motionStrength > 0.01f) {
                repeat(8) { index ->
                    val depth = ((index / 8f) + roadPhase) % 1f
                    val p = perspective(depth)
                    val endDepth = depth + 0.035f + 0.105f * p
                    if (endDepth <= 0.985f) {
                        val start = roadPoint(depth, 0f)
                        val end = roadPoint(endDepth, 0f)
                        val alpha = (0.34f + 0.54f * p).coerceAtMost(0.92f) * motionStrength
                        val width = 1.1.dp.toPx() + 6.8.dp.toPx() * p
                        drawLine(
                            color = Color(0xFFFFE29A).copy(alpha = alpha),
                            start = start,
                            end = end,
                            strokeWidth = width,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color.White.copy(alpha = (alpha * 0.32f).coerceAtMost(0.28f)),
                            start = start,
                            end = end,
                            strokeWidth = (width * 0.32f).coerceAtLeast(1f),
                            cap = StrokeCap.Round
                        )
                    }
                }

                listOf(-0.46f, -0.24f, 0.24f, 0.46f).forEachIndexed { laneIndex, lateral ->
                    repeat(5) { index ->
                        val depth = ((index / 5f) + roadPhase + laneIndex * 0.05f) % 1f
                        val p = perspective(depth)
                        if (p > 0.08f) {
                            val endDepth = depth + 0.014f + 0.062f * p
                            if (endDepth <= 0.99f) {
                                drawLine(
                                    color = Color(0xFFE9EEF1).copy(alpha = ((0.014f + 0.060f * p) * motionStrength).coerceAtMost(0.08f)),
                                    start = roadPoint(depth, lateral),
                                    end = roadPoint(endDepth, lateral),
                                    strokeWidth = 0.5.dp.toPx() + 1.3.dp.toPx() * p,
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DigitalV2WindOverlay(
    roadPhase: Float,
    motionStrength: Float,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        if (motionStrength <= 0.02f) return@Canvas
        val wide = size.width / size.height > 1.15f

        fun buildSceneryWindClip(left: Boolean): Path = Path().apply {
            val topY = size.height * if (wide) 0.44f else 0.50f
            val shoulderY = size.height * if (wide) 0.50f else 0.58f
            val lowerY = size.height * if (wide) 0.64f else 0.72f
            val bottomY = size.height * if (wide) 0.73f else 0.80f
            if (left) {
                moveTo(size.width * 0.018f, topY)
                cubicTo(
                    size.width * 0.070f,
                    topY - size.height * 0.016f,
                    size.width * 0.165f,
                    topY - size.height * 0.004f,
                    size.width * 0.205f,
                    shoulderY
                )
                lineTo(size.width * 0.225f, lowerY)
                lineTo(size.width * 0.215f, bottomY)
                lineTo(size.width * 0.018f, bottomY)
            } else {
                moveTo(size.width * 0.982f, topY)
                cubicTo(
                    size.width * 0.930f,
                    topY - size.height * 0.016f,
                    size.width * 0.835f,
                    topY - size.height * 0.004f,
                    size.width * 0.795f,
                    shoulderY
                )
                lineTo(size.width * 0.775f, lowerY)
                lineTo(size.width * 0.785f, bottomY)
                lineTo(size.width * 0.982f, bottomY)
            }
            close()
        }

        fun drawSceneryWind(left: Boolean) {
            val clip = buildSceneryWindClip(left)
            val sideOffset = if (left) 0.04f else 0.12f
            val direction = if (left) -1f else 1f
            val windStrength = (0.56f + 0.44f * motionStrength).coerceIn(0f, 1f)

            clipPath(clip) {
                repeat(6) { index ->
                    val variant = index % 3
                    val phaseJitter = when (variant) {
                        0 -> 0.000f
                        1 -> 0.037f
                        else -> 0.081f
                    }
                    val thicknessVariance = when (variant) {
                        0 -> 0.78f
                        1 -> 1.08f
                        else -> 0.92f
                    }
                    val waveVariance = when (variant) {
                        0 -> 0.68f
                        1 -> 1.18f
                        else -> 0.92f
                    }
                    val lengthVariance = when (variant) {
                        0 -> 0.88f
                        1 -> 1.12f
                        else -> 1.00f
                    }

                    val phase = ((roadPhase * (0.88f + 0.05f * variant)) + index / 6f + sideOffset + phaseJitter) % 1f
                    val flow = phase.coerceIn(0f, 1f).pow(1.30f)
                    val fade = sin((phase * PI.toFloat()).toDouble()).toFloat().coerceAtLeast(0f).pow(4.0f)
                    val primaryWave = sin((roadPhase * (5.60f + variant * 0.73f) + index * 0.94f + sideOffset * 4f).toDouble()).toFloat()
                    val secondaryWave = sin((roadPhase * (11.30f + variant * 0.41f) + index * 1.77f + 0.45f).toDouble()).toFloat()
                    val laneWave = (primaryWave + secondaryWave * 0.28f) * waveVariance
                    val headX = if (left) size.width * (0.225f - 0.190f * flow) else size.width * (0.775f + 0.190f * flow)
                    val length = size.width * (0.052f + 0.082f * flow) * lengthVariance
                    val tailX = headX - direction * length
                    val baseY = size.height * (0.532f + 0.174f * flow + variant * 0.011f)
                    val tailY = baseY - size.height * (0.0025f + 0.0045f * laneWave)
                    val headY = baseY + size.height * (0.005f + 0.008f * flow)
                    val curveLift = size.height * (0.007f + 0.004f * flow + 0.0035f * laneWave)

                    val gust = Path().apply {
                        moveTo(tailX, tailY)
                        cubicTo(
                            tailX + direction * length * 0.31f,
                            tailY - curveLift,
                            tailX + direction * length * 0.74f,
                            headY + curveLift * 0.48f,
                            headX,
                            headY
                        )
                    }

                    val alpha = ((0.34f + 0.08f * thicknessVariance) * fade * windStrength).coerceAtMost(0.45f)
                    val coreWidth = (0.58.dp.toPx() + 0.92.dp.toPx() * flow) * thicknessVariance
                    drawPath(
                        path = gust,
                        color = Color(0xFFDDEEFF).copy(alpha = alpha * 0.04f),
                        style = Stroke(width = coreWidth * 8f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color(0xFFEAF5FF).copy(alpha = alpha * 0.12f),
                        style = Stroke(width = coreWidth * 3f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color.White.copy(alpha = alpha * 0.25f),
                        style = Stroke(width = coreWidth * 0.60f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                }
            }
        }

        drawSceneryWind(left = true)
        drawSceneryWind(left = false)
    }
}

@Composable
private fun DigitalV2DataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(DigitalV2Glass, Color(0xFFF0F3F7), Color(0xFFE3E8EF))
                )
            )
            .border(1.dp, Color.White.copy(alpha = .82f), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1.12f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Hararet", "Coolant"), snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.Temperature, Modifier.weight(1f), compact = true, accent = if ((snapshot.engineTempC ?: 0) >= 100) palette.critical else DigitalV2Red)
            DigitalV2MetricCard(palette, trLabel(tr, "Klima", "A/C"), snapshot.acOn?.let { if (it) "A/C" else trLabel(tr, "Kapalı", "Off") } ?: "--", snapshot.acOn?.let { if (it) "ON" else null }, CardIcon.Ac, Modifier.weight(1f), compact = true, accent = DigitalV2Blue)
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Süresi", "Trip Time"), snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, Modifier.weight(1f), compact = true)
            DigitalV2MetricCard(palette, trLabel(tr, "Kullanılan Yakıt", "Fuel Used"), format1(snapshot.fuelUsedL), "L", CardIcon.FuelCalculation, Modifier.weight(1f), compact = true)
        }
    }
}

@Composable
private fun DigitalV2CompactDataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFFE7ECF2))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
    }
}

@Composable
private fun DigitalV2MetricCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    accent: Color = DigitalV2Blue
) {
    if (compact) {
        Column(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(16.dp))
                .padding(horizontal = 5.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title.uppercase(),
                color = Color(0xFF596778),
                fontSize = 8.8.sp,
                lineHeight = 9.4.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Box(
                modifier = Modifier
                    .size(29.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                value,
                color = Color(0xFF172235),
                fontSize = 19.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!unit.isNullOrBlank()) {
                Text(unit, color = Color(0xFF596778), fontSize = 9.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(20.dp))
                .padding(horizontal = 11.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title.uppercase(), color = Color(0xFF596778), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, color = Color(0xFF172235), fontSize = 26.sp, lineHeight = 27.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!unit.isNullOrBlank()) {
                        Spacer(Modifier.width(4.dp))
                        Text(unit, color = Color(0xFF596778), fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 3.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalV2SettingsPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    onSettingsChange: (LoganSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dijital V2", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(
            trLabel(tr, "Dağ-Göl ilk aktif sahnedir. Diğer sahneler hazırlandıkça açılacaktır.", "Mountain-Lake is the first active scene. Other scenes will unlock when completed."),
            color = palette.textSecondary,
            fontSize = 12.5.sp
        )
        DigitalV2MiniPreview(
            settings = settings,
            mode = settings.digitalV2GaugeMode,
            modifier = Modifier.fillMaxWidth().height(184.dp)
        )
        Text(trLabel(tr, "Kadran Türü", "Gauge Type"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Speed,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Speed,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Speed)) }
            )
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Rpm,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Rpm,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Rpm)) }
            )
        }
        Text(trLabel(tr, "Arka Plan Sahnesi", "Background Scene"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.take(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.drop(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceVariant.copy(alpha = .72f))
                .border(1.dp, palette.line, RoundedCornerShape(16.dp))
                .clickable { onSettingsChange(settings.copy(digitalV2MotionEnabled = !settings.digitalV2MotionEnabled)) }
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(trLabel(tr, "Hareket efektleri", "Motion effects"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text(trLabel(tr, "Şerit akışı, hafif rüzgâr ve araç mikro sallantısı", "Lane flow, light wind and subtle vehicle movement"), color = palette.textSecondary, fontSize = 10.sp)
            }
            Switch(
                checked = settings.digitalV2MotionEnabled,
                onCheckedChange = { onSettingsChange(settings.copy(digitalV2MotionEnabled = it)) }
            )
        }
    }
}

@Composable
private fun DigitalV2MiniPreview(settings: LoganSettings, mode: DigitalV2GaugeMode, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, DigitalV2Blue.copy(alpha = .70f), RoundedCornerShape(20.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x50062A51), Color.Transparent, Color(0x79061018)))))
        DigitalV2Gauge(mode, 78, 2400, Modifier.align(Alignment.TopCenter).fillMaxWidth(.88f).fillMaxHeight(.90f), preview = true)
        Image(
            painter = painterResource(vehicleVisualDrawableRes(settings.vehicleVisualModel, settings.vehicleColor, VehicleAssetStyle.Detailed)),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(.20f).padding(bottom = 5.dp)
        )
        Text("DAĞ-GÖL • AKTİF", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
    }
}

@Composable
private fun DigitalV2GaugeThumbnail(
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * .47f
            val center = Offset(size.width / 2f, size.height * .68f)
            val start = 150f
            val sweep = 240f
            drawArc(
                color = Color.White.copy(alpha = .90f),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(radius * .022f, cap = StrokeCap.Round)
            )
            repeat(9) { i ->
                val f = i / 8f
                val a = Math.toRadians((start + sweep * f).toDouble())
                val p1 = Offset(center.x + cos(a).toFloat() * radius * .84f, center.y + sin(a).toFloat() * radius * .84f)
                val p2 = Offset(center.x + cos(a).toFloat() * radius, center.y + sin(a).toFloat() * radius)
                drawLine(Color.White.copy(alpha = .90f), p1, p2, radius * .016f, StrokeCap.Round)
            }
            val progress = if (mode == DigitalV2GaugeMode.Speed) 78f / 200f else 2400f / 7000f
            val needleAngle = Math.toRadians((start + sweep * progress).toDouble())
            val needleStart = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .13f,
                center.y + sin(needleAngle).toFloat() * radius * .13f
            )
            drawLine(
                Color.White,
                needleStart,
                Offset(center.x + cos(needleAngle).toFloat() * radius * .76f, center.y + sin(needleAngle).toFloat() * radius * .76f),
                radius * .020f,
                StrokeCap.Round
            )
        }
        Column(
            modifier = Modifier.align(Alignment.Center).offset(y = maxHeight * .14f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // The thumbnail follows the same rule as the cockpit: the centre shows the other value.
            Text(
                if (mode == DigitalV2GaugeMode.Speed) "24" else "78",
                color = Color.White,
                fontSize = 31.sp,
                lineHeight = 31.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h",
                color = Color.White.copy(alpha = .94f),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DigitalV2ModeTile(
    palette: LoganPalette,
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) DigitalV2Blue.copy(alpha = .10f) else palette.surfaceVariant.copy(alpha = .62f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1B5D91))
        ) {
            DigitalV2GaugeThumbnail(mode, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(6.dp))
        Text(if (tr) mode.trLabel else mode.enLabel, color = if (selected) DigitalV2Blue else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(
            if (mode == DigitalV2GaugeMode.Speed) trLabel(tr, "Ortada devir", "RPM in center") else trLabel(tr, "Ortada hız", "Speed in center"),
            color = palette.textSecondary,
            fontSize = 10.5.sp
        )
    }
}

@Composable
private fun DigitalV2SceneTile(
    palette: LoganPalette,
    settings: LoganSettings,
    scene: DigitalV2Scene,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val selected = settings.digitalV2Scene == scene && scene.available
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (scene.available) Color(0xFF4C86AD) else palette.surfaceVariant.copy(alpha = .80f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(15.dp))
            .clickable(enabled = scene.available, onClick = onClick)
    ) {
        if (scene == DigitalV2Scene.MountainLake) {
            Image(
                painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .20f)))
        }
        Text(if (tr) scene.trLabel else scene.enLabel, color = if (scene.available) Color.White else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
        Text(
            if (scene.available) trLabel(tr, "Aktif", "Active") else trLabel(tr, "Pasif", "Inactive"),
            color = if (scene.available) Color.White else palette.textSecondary,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = if (scene.available) .35f else .08f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

private fun trLabel(tr: Boolean, trValue: String, enValue: String): String = if (tr) trValue else enValue

private fun format1(value: Double?): String = value?.takeIf { it.isFinite() }?.let {
    String.format(Locale.US, "%.1f", it)
} ?: "--"
