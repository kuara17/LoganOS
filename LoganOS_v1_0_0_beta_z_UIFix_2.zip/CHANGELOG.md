# Changelog

## 1.0.0-beta.2

- Fixed Android status bar / navigation bar safe-area spacing.
- Added visible bottom navigation: Kokpit, Sürüş, Araç, Bakım, Ayarlar.
- Added reachable Settings screen with category chips.
- Demo values are no longer shown by default when OBD is disconnected.
- Added Developer > Demo Modu switch; demo values appear only when enabled.
- Reworked dashboard layout for phone portrait mode.
- Rebalanced speed gauge proportions and centered circular gauge behavior.
- Fixed fuel cost card text overflow with shorter fallback text.
- Improved average/instant consumption unit layout.
- Added Dacia/Renault brand-selection logos in setup.
- Split vehicle model list by selected brand.
- Marked 1.5 dCi 48 kW as the LoganOS Beta target engine.
- Updated app launcher icon and splash branding assets.
- Version updated to 1.0.0-beta.2.

## 1.0.0-beta.1

- Initial Kotlin/Jetpack Compose project structure.
- Added LOGANOS splash screen.
- Added first setup wizard.
- Added dashboard shell.
- Added gauge style models: Digital, Sport, Classic OEM, Minimal, RS Performance.
- Added accent color system with OEM Green default.
- Added settings shell.
- Added GitHub Actions APK workflow.
