package com.dcui.loganos.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.ui.components.HeaderLine
import com.dcui.loganos.ui.components.Slogan
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun SplashScreen(palette: LoganPalette) {
    val visible = remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible.value = true }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
            .padding(horizontal = 28.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedVisibility(visible = visible.value, enter = fadeIn(animationSpec = tween(450))) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Image(
                    painter = painterResource(id = R.drawable.loganos_splash_brand),
                    contentDescription = "LoganOS",
                    modifier = Modifier.fillMaxWidth(.86f).height(300.dp),
                    contentScale = ContentScale.Fit
                )
                HeaderLine(palette, modifier = Modifier.fillMaxWidth(.60f))
                Spacer(Modifier.height(16.dp))
                Text("Fuel Truth Technology", color = palette.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Delphi DCM1.2 Optimized • KWP2000 Fast Init", color = palette.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(30.dp))
                Slogan(palette)
            }
        }
    }
}
