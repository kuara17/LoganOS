package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedGauge(
    palette: LoganPalette,
    speed: Int?,
    style: GaugeStyle,
    modifier: Modifier = Modifier,
    demoMode: Boolean = false
) {
    when (style) {
        GaugeStyle.Digital -> DigitalGauge(palette, speed, modifier, demoMode)
        GaugeStyle.Sport -> SportGauge(palette, speed, modifier, demoMode)
        GaugeStyle.ClassicOem -> ClassicGauge(palette, speed, modifier, demoMode)
        GaugeStyle.Minimal -> MinimalGauge(palette, speed, modifier, demoMode)
        GaugeStyle.RsPerformance -> RsGauge(palette, speed, modifier, demoMode)
    }
}

@Composable
private fun DigitalGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(targetValue = ((speed ?: 0) / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "speed")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GaugeArc(palette, progress)
        SpeedCenter(palette, speed, label = if (demoMode) "DEMO" else "OBD BEKLENİYOR", labelColor = if (demoMode) palette.warning else palette.textSecondary)
    }
}

@Composable
private fun SportGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(targetValue = ((speed ?: 0) / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "speedSport")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val side = size.minDimension
            val left = (size.width - side) / 2f
            val top = (size.height - side) / 2f
            val stroke = 13.dp.toPx()
            val pad = stroke / 2 + 8.dp.toPx()
            val sizeArc = Size(side - pad * 2, side - pad * 2)
            drawArc(color = palette.line, startAngle = 150f, sweepAngle = 240f, useCenter = false, topLeft = Offset(left + pad, top + pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(brush = Brush.sweepGradient(listOf(palette.accent, palette.warning, palette.critical)), startAngle = 150f, sweepAngle = 240f * progress, useCenter = false, topLeft = Offset(left + pad, top + pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
            repeat(32) { i ->
                val angle = Math.toRadians((150 + i * 240 / 31.0).toDouble())
                val r1 = side / 2 - 24.dp.toPx()
                val r2 = side / 2 - 12.dp.toPx()
                val c = Offset(size.width / 2, size.height / 2)
                drawLine(
                    color = palette.muted.copy(alpha = .55f),
                    start = Offset(c.x + cos(angle).toFloat() * r1, c.y + sin(angle).toFloat() * r1),
                    end = Offset(c.x + cos(angle).toFloat() * r2, c.y + sin(angle).toFloat() * r2),
                    strokeWidth = 2f
                )
            }
        }
        SpeedCenter(palette, speed, label = if (demoMode) "DEMO" else "SPORT", labelColor = if (demoMode) palette.warning else palette.accent)
    }
}

@Composable
private fun ClassicGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(targetValue = ((speed ?: 0) / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "classic")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GaugeArc(palette, progress, strokeDp = 9)
        SpeedCenter(palette, speed, label = if (demoMode) "DEMO" else "CLASSIC", labelColor = if (demoMode) palette.warning else palette.accent)
    }
}

@Composable
private fun MinimalGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        SpeedCenter(palette, speed, label = if (demoMode) "DEMO" else "MINIMAL", labelColor = if (demoMode) palette.warning else palette.accent)
    }
}

@Composable
private fun RsGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(targetValue = ((speed ?: 0) / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "rs")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GaugeArc(palette.copy(accent = palette.critical), progress, strokeDp = 13)
        SpeedCenter(palette, speed, label = if (demoMode) "DEMO" else "RS", labelColor = if (demoMode) palette.warning else palette.critical)
    }
}

@Composable
private fun GaugeArc(palette: LoganPalette, progress: Float, strokeDp: Int = 12) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val side = size.minDimension
        val left = (size.width - side) / 2f
        val top = (size.height - side) / 2f
        val stroke = strokeDp.dp.toPx()
        val pad = stroke / 2 + 8.dp.toPx()
        val sizeArc = Size(side - pad * 2, side - pad * 2)
        drawArc(
            color = palette.line,
            startAngle = 145f,
            sweepAngle = 250f,
            useCenter = false,
            topLeft = Offset(left + pad, top + pad),
            size = sizeArc,
            style = Stroke(stroke, cap = StrokeCap.Round)
        )
        if (progress > 0f) {
            drawArc(
                brush = Brush.sweepGradient(listOf(palette.accent, palette.accent.copy(alpha = .65f), palette.accent)),
                startAngle = 145f,
                sweepAngle = 250f * progress,
                useCenter = false,
                topLeft = Offset(left + pad, top + pad),
                size = sizeArc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
    }
}

@Composable
private fun SpeedCenter(palette: LoganPalette, speed: Int?, label: String, labelColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(speed?.toString() ?: "--", color = palette.textPrimary, fontSize = if (speed == null) 64.sp else 72.sp, fontWeight = FontWeight.Black)
        Text("km/h", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text(label, color = labelColor, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier.height(126.dp)) {
        SpeedGauge(palette, 92, style, modifier = Modifier.weight(1f).fillMaxWidth(), demoMode = true)
        Text(style.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
