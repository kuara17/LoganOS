package com.dcui.loganos.model

import androidx.compose.ui.graphics.Color

enum class DeviceMode(val label: String) {
    Phone("Telefon"),
    HeadUnit("Android Multimedya / Double")
}

enum class Brand(val label: String) {
    Dacia("Dacia"),
    Renault("Renault")
}

enum class GaugeStyle(val label: String) {
    Digital("Digital"),
    Sport("Sport"),
    ClassicOem("Classic OEM"),
    Minimal("Minimal"),
    RsPerformance("RS Performance")
}

enum class AccentColor(val label: String, val color: Color) {
    OemGreen("OEM Green", Color(0xFF34C759)),
    TechBlue("Tech Blue", Color(0xFF207DFF)),
    SportOrange("Sport Orange", Color(0xFFFF8A00)),
    RsRed("RS Red", Color(0xFFFF3B30)),
    NeoPurple("Neo Purple", Color(0xFF9B5CFF)),
    GoldEdition("Gold Edition", Color(0xFFFFC107))
}

data class LoganSettings(
    val setupCompleted: Boolean = false,
    val brand: Brand = Brand.Dacia,
    val vehicleModel: String = "Dacia Logan",
    val engine: String = "1.5 dCi 48 kW",
    val deviceMode: DeviceMode = DeviceMode.Phone,
    val gaugeStyle: GaugeStyle = GaugeStyle.Digital,
    val accentColor: AccentColor = AccentColor.OemGreen,
    val darkMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val backgroundTripEnabled: Boolean = true,
    val smartTripMinutes: Int = 60,
    val demoMode: Boolean = false,
    val disclaimerAccepted: Boolean = false
)

data class DashboardSnapshot(
    val speedKmh: Int? = null,
    val averageConsumption: Double? = null,
    val instantConsumption: Double? = null,
    val instantUnit: String = "L/h",
    val tripDistanceKm: Double? = null,
    val odometerKm: Int? = null,
    val engineTempC: Int? = null,
    val radiatorFanOn: Boolean? = null,
    val rpm: Int? = null,
    val acOn: Boolean? = null,
    val fuelUsedL: Double? = null,
    val tripCostText: String? = null,
    val batteryV: Double? = null,
    val connected: Boolean = false,
    val demo: Boolean = false
) {
    companion object {
        fun empty() = DashboardSnapshot()
        fun demo() = DashboardSnapshot(
            speedKmh = 92,
            averageConsumption = 4.6,
            instantConsumption = 1.2,
            instantUnit = "L/h",
            tripDistanceKm = 125.4,
            odometerKm = 335420,
            engineTempC = 82,
            radiatorFanOn = true,
            rpm = 2180,
            acOn = true,
            fuelUsedL = 1.88,
            tripCostText = "Yakıt fiyatı yok",
            batteryV = 13.7,
            connected = false,
            demo = true
        )
    }
}
