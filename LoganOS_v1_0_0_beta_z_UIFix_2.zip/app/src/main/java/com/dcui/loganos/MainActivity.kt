package com.dcui.loganos

import android.content.pm.ActivityInfo
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.view.WindowCompat
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.screens.LoganAppShell
import com.dcui.loganos.ui.screens.SetupWizard
import com.dcui.loganos.ui.screens.SplashScreen
import com.dcui.loganos.ui.theme.LoganOSTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = AppPrefs(this)

        setContent {
            var settings by remember { mutableStateOf(prefs.load()) }
            var showSplash by remember { mutableStateOf(true) }
            val dark = settings.darkMode

            fun persist(updated: LoganSettings) {
                settings = updated
                prefs.save(updated)
            }

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(settings.deviceMode, settings.setupCompleted) {
                requestedOrientation = if (settings.setupCompleted && settings.deviceMode == DeviceMode.HeadUnit) {
                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            LaunchedEffect(Unit) {
                delay(2100)
                showSplash = false
            }

            LoganOSTheme(accentColor = settings.accentColor, darkTheme = dark) { palette ->
                when {
                    showSplash -> SplashScreen(palette)
                    !settings.setupCompleted -> SetupWizard(
                        palette = palette,
                        initial = settings,
                        onComplete = { updated -> persist(updated) }
                    )
                    else -> LoganAppShell(
                        palette = palette,
                        settings = settings,
                        snapshot = if (settings.demoMode) DashboardSnapshot.demo() else DashboardSnapshot.empty(),
                        onSettingsChange = { updated -> persist(updated) },
                        onResetSetup = {
                            prefs.resetSetup()
                            settings = LoganSettings()
                            showSplash = true
                        }
                    )
                }
            }
        }
    }
}
