package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SpeedGauge
import com.dcui.loganos.ui.theme.LoganPalette

enum class MainTab(val label: String) {
    Cockpit("Kokpit"),
    Trip("Sürüş"),
    Vehicle("Araç"),
    Maintenance("Bakım"),
    Settings("Ayarlar")
}

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Cockpit) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                MainTab.Cockpit -> DashboardContent(palette, settings, snapshot)
                MainTab.Trip -> TripPage(palette, snapshot)
                MainTab.Vehicle -> VehiclePage(palette, settings, snapshot)
                MainTab.Maintenance -> MaintenancePage(palette)
                MainTab.Settings -> SettingsScreen(palette, settings, onSettingsChange, onResetSetup)
            }
        }
        BottomNavigationBar(palette, current = tab) { tab = it }
    }
}

@Composable
private fun DashboardContent(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { DashboardHeader(palette, snapshot) }
        item { ConnectionBanner(palette, snapshot, settings.demoMode) }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.fillMaxWidth()) {
                    Text("HIZ", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 16.sp)
                    SpeedGauge(
                        palette = palette,
                        speed = snapshot.speedKmh,
                        style = settings.gaugeStyle,
                        modifier = Modifier.fillMaxWidth(.78f).aspectRatio(1f).heightIn(max = 270.dp),
                        demoMode = settings.demoMode
                    )
                    Text("Trip A ${fmt(snapshot.tripDistanceKm, "km")}  •  ODO ${snapshot.odometerKm?.let { "$it km" } ?: "--"}", color = palette.textSecondary, fontSize = 12.sp)
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", subtitle = "Sürüş ortalaması", modifier = Modifier.weight(1f).height(110.dp))
                DataCard(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, subtitle = "Canlı tüketim", modifier = Modifier.weight(1f).height(110.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", subtitle = "Toplam mesafe", accent = palette.blue, modifier = Modifier.weight(1f).height(110.dp))
                DataCard(palette, "Sürüş Maliyeti", snapshot.tripCostText ?: "Yakıt fiyatı yok", subtitle = if (snapshot.tripCostText == null) "Ayarlar > Yakıt" else "${fmt(snapshot.fuelUsedL, "L")}", accent = palette.warning, modifier = Modifier.weight(1f).height(110.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                EngineTempCard(palette, snapshot, Modifier.weight(1f).height(110.dp))
                DataCard(palette, "Devir", snapshot.rpm?.toString() ?: "--", "d/dk", accent = palette.accent, subtitle = "Motor devri", modifier = Modifier.weight(1f).height(110.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Klima", snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", accent = palette.blue, subtitle = "21CC bit 0x08", modifier = Modifier.weight(1f).height(110.dp))
                DataCard(palette, "Fan", snapshot.radiatorFanOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", accent = palette.accent, subtitle = "21CC bit 0x20", modifier = Modifier.weight(1f).height(110.dp))
            }
        }
    }
}

@Composable
private fun DashboardHeader(palette: LoganPalette, snapshot: DashboardSnapshot) {
    Row(
        modifier = Modifier.fillMaxWidth().height(48.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        LoganWordmark(palette, compact = true)
        Column(horizontalAlignment = Alignment.End) {
            Text(if (snapshot.connected) "OBD Bağlı" else "OBD Bekleniyor", color = if (snapshot.connected) palette.accent else palette.textSecondary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(snapshot.batteryV?.let { "BT • ${it} V" } ?: "Bluetooth bekleniyor", color = palette.textSecondary, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ConnectionBanner(palette: LoganPalette, snapshot: DashboardSnapshot, demoMode: Boolean) {
    val text = when {
        demoMode -> "Demo Modu Aktif • Gerçek OBD verisi gösterilmiyor"
        snapshot.connected -> "OBD bağlı • Yolculuk kaydı hazır"
        else -> "OBD bağlantısı bekleniyor • Canlı değerler bağlı olmadan gösterilmez"
    }
    val accent = if (demoMode) palette.warning else if (snapshot.connected) palette.accent else palette.textSecondary
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Text(text, color = accent, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
private fun EngineTempCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp >= 105 -> palette.critical
        temp >= 90 -> palette.warning
        else -> palette.accent
    }
    DataCard(
        palette = palette,
        title = "Motor Sıcaklığı",
        value = temp?.toString() ?: "--",
        unit = "°C",
        subtitle = "Fan: ${snapshot.radiatorFanOn?.let { if (it) "Açık" else "Kapalı" } ?: "--"}",
        accent = tempColor,
        modifier = modifier
    )
}

@Composable
private fun BottomNavigationBar(palette: LoganPalette, current: MainTab, onSelect: (MainTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(62.dp)
            .background(palette.surface)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        MainTab.entries.forEach { tab ->
            val selected = current == tab
            Text(
                text = tab.label,
                color = if (selected) palette.accent else palette.textSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (selected) palette.accent.copy(alpha = .12f) else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun TripPage(palette: LoganPalette, snapshot: DashboardSnapshot) {
    InfoPage(palette, "Sürüş Merkezi") {
        DataCard(palette, "Güncel Yolculuk", if (snapshot.connected || snapshot.demo) "Aktif" else "Beklemede", subtitle = "Smart Trip bağlantı gelince başlar", modifier = Modifier.fillMaxWidth().height(110.dp))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", modifier = Modifier.weight(1f).height(105.dp))
            DataCard(palette, "Yakıt", fmt(snapshot.fuelUsedL), "L", modifier = Modifier.weight(1f).height(105.dp))
        }
        Spacer(Modifier.height(10.dp))
        DataCard(palette, "Yolculuk Özeti", "Hazır değil", subtitle = "Gerçek OBD bağlantısından sonra aktif olacak", modifier = Modifier.fillMaxWidth().height(105.dp))
    }
}

@Composable
private fun VehiclePage(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot) {
    InfoPage(palette, "Araç Sağlığı") {
        DataCard(palette, "Araç", settings.vehicleModel, subtitle = settings.engine, modifier = Modifier.fillMaxWidth().height(110.dp))
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Soğutma", if (snapshot.engineTempC == null) "Veri yok" else "Normal", subtitle = "Fan/hararet takibi", modifier = Modifier.weight(1f).height(105.dp))
            DataCard(palette, "Akü", snapshot.batteryV?.toString() ?: "--", "V", subtitle = "Araç Sağlığı detayında", modifier = Modifier.weight(1f).height(105.dp))
        }
        Spacer(Modifier.height(10.dp))
        DataCard(palette, "OBD Durumu", if (snapshot.connected) "Bağlı" else "Bekleniyor", subtitle = "KWP2000 Fast Init hazırlandı", modifier = Modifier.fillMaxWidth().height(105.dp))
    }
}

@Composable
private fun MaintenancePage(palette: LoganPalette) {
    InfoPage(palette, "Bakım Takibi") {
        listOf("Motor Yağı", "Yağ Filtresi", "Mazot Filtresi", "Hava Filtresi", "Polen Filtresi", "Triger Seti", "Muayene", "Trafik Sigortası").forEach {
            DataCard(palette, it, "Ayarla", subtitle = "Km + tarih takibi", modifier = Modifier.fillMaxWidth().height(88.dp))
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
private fun InfoPage(palette: LoganPalette, title: String, content: @Composable () -> Unit) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp)) {
        item {
            Column {
                Text(title, color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
                Text("LoganOS v1.0.0-beta.2 iskelet ekranı", color = palette.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                content()
            }
        }
    }
}

private fun fmt(value: Double?, suffix: String? = null): String {
    val base = value?.let { String.format(java.util.Locale.US, "%.1f", it) } ?: "--"
    return if (suffix == null) base else "$base $suffix"
}
