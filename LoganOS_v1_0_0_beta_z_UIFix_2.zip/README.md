# LOGANOS

**OEM Digital Cockpit**  
**Powered by DC UI**  
**Know Your Car. Drive Smarter.**

LoganOS is an independent, community-driven, open-source OEM-style digital cockpit project for Renault and Dacia vehicles.

> LoganOS is not affiliated with, endorsed by, or sponsored by Renault Group, Dacia, or any vehicle manufacturer. Renault and Dacia names/trademarks belong to their respective owners and are referenced only for compatibility and vehicle-profile selection.

## Current package

This repository is the **LoganOS v1.0.0-beta.2 Kotlin starter**.

Included now:

- Android Kotlin project
- Jetpack Compose UI foundation
- Splash screen
- First setup wizard
- Dashboard shell
- Gauge style selector concept
- Settings shell
- Accent color system
- App icon placeholder based on the LoganOS mark
- GitHub Actions APK build workflow

Not included yet:

- Real Bluetooth / KWP communication
- Fuel Truth live calculation
- SQLite/Room database implementation
- Foreground OBD service
- Technical screen live data

Those modules will be added step-by-step after the Compose foundation is confirmed on device.

## Privacy-first project

- No ads
- No tracking
- No forced cloud account
- Data stays on the device by default
- GPS route recording is optional
- Support packages are created only with user action

## Build APK on GitHub

1. Upload this project to a GitHub repository.
2. Open **Actions**.
3. Run **Build LoganOS APK**.
4. Download the generated APK artifact.

## License

GPLv3-or-later. See `LICENSE`.


## 1.0.0-beta.2 test notları

Bu sürüm, ilk Kotlin iskeletinin UI düzeltme paketidir. Canlı OBD/KWP bağlantısı henüz eklenmedi. OBD bağlı değilken gerçek veri alanları `--` olarak görünür. Örnek değerleri görmek için Ayarlar > Geliştirici > Demo Modu açılmalıdır.
