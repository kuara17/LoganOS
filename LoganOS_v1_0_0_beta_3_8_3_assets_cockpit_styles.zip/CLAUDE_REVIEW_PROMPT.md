# LoganOS v1.0.0-beta.3.8.3 review prompt

Please review this Android/Kotlin/Jetpack Compose project. This version is a visual asset/style fix after v3.8.2.

Focus areas:

1. Build blockers
- Check Kotlin/Compose compile errors, missing imports, resource names, duplicate resources, versionCode/versionName, and GitHub Actions workflow.

2. Cockpit asset rendering
- Main cockpit icons were switched from auto-generated vector XMLs to approved transparent PNG assets under `res/drawable-nodpi/asset_*.png`.
- Verify they are rendered with `Image(...)` / no tinting, not flattened through Material `Icon`.
- Verify the icons are large enough and do not look like the previous degraded XML icons.

3. Brand logos in setup
- Dacia/Renault logos now use transparent PNG assets (`asset_brand_dacia`, `asset_brand_renault`) rather than the rough XML versions.
- Check sizing, alignment, and disabled Renault alpha behavior in the brand selection screen.

4. Cockpit layout readability
- Check that long labels such as `Sürüş Maliyeti`, `Hararet / Fan`, and `Sürüş Süresi` are not clipped.
- Check icon sizes, text sizes, unit alignment, bottom nav overlap, and portrait/landscape behavior.

5. Gauge styles
- Verify that selected gauge styles actually change the real cockpit and setup preview:
  - Digital -> selected Digital style
  - Sport -> selected Sport C style
  - Classic OEM -> selected Classic OEM A style
  - Minimal -> selected Minimal C style
  - RS Performance -> selected RS Performance D style
- If they still look too similar, recommend concrete file/function changes.

6. Do not refactor critical OBD/fuel systems unless a definite bug exists:
- FuelAlgorithmV3
- TripComputer
- CUTOFF
- AC_FAST
- Delphi parser byte positions
- OBD connection loop
- Cranking analysis core
- Fuel calibration coefficient
- Fan UNKNOWN/test-pending behavior

Expected output:
1. Build blockers
2. Visual/resource issues
3. Cockpit layout issues
4. Gauge style wiring issues
5. Small patches to apply
6. Parts that should not be changed
