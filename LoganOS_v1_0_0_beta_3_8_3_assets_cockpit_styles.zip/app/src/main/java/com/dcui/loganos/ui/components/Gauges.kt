package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val LoganGaugeGreen = Color(0xFF107C41)

@Composable
fun SpeedGauge(palette: LoganPalette, speed: Int?, style: GaugeStyle, modifier: Modifier = Modifier, demoMode: Boolean = false) {
    val maxSpeed = if (style == GaugeStyle.RsPerformance) 260f else 240f
    val progress by animateFloatAsState(
        targetValue = ((speed ?: 0) / maxSpeed).coerceIn(0f, 1f),
        animationSpec = tween(450),
        label = "speedProgress"
    )

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val gaugeSize = minOf(maxWidth, maxHeight).coerceAtMost(232.dp).coerceAtLeast(122.dp)
        val compact = maxHeight < 165.dp
        val accent = when (style) {
            GaugeStyle.Sport -> Color(0xFF1FAD55)
            GaugeStyle.ClassicOem -> Color(0xFF263238)
            GaugeStyle.Minimal -> LoganGaugeGreen
            GaugeStyle.RsPerformance -> Color(0xFFD62828)
            GaugeStyle.Digital -> LoganGaugeGreen
        }
        Canvas(modifier = Modifier.size(gaugeSize)) {
            val radius = size.minDimension * when (style) {
                GaugeStyle.Minimal -> 0.44f
                GaugeStyle.ClassicOem -> 0.46f
                GaugeStyle.RsPerformance -> 0.45f
                else -> 0.43f
            }
            val center = Offset(size.width / 2f, size.height * if (style == GaugeStyle.Minimal) 0.56f else 0.58f)
            val startDeg = when (style) {
                GaugeStyle.ClassicOem -> 180f
                GaugeStyle.RsPerformance -> 195f
                GaugeStyle.Sport -> 200f
                GaugeStyle.Minimal -> 205f
                GaugeStyle.Digital -> 205f
            }
            val sweepDeg = when (style) {
                GaugeStyle.ClassicOem -> 180f
                GaugeStyle.RsPerformance -> 150f
                GaugeStyle.Sport -> 145f
                GaugeStyle.Minimal -> 130f
                GaugeStyle.Digital -> 130f
            }
            val tickCount = when (style) {
                GaugeStyle.Minimal -> 16
                GaugeStyle.ClassicOem -> 48
                GaugeStyle.Sport -> 44
                GaugeStyle.RsPerformance -> 30
                GaugeStyle.Digital -> 34
            }
            val trackColor = palette.line.copy(alpha = if (style == GaugeStyle.RsPerformance) .95f else .72f)
            val tickColor = palette.textSecondary.copy(alpha = if (style == GaugeStyle.Minimal) .16f else .30f)

            // Outer track
            drawArc(
                color = trackColor,
                startAngle = startDeg,
                sweepAngle = sweepDeg,
                useCenter = false,
                style = Stroke(width = when (style) { GaugeStyle.RsPerformance -> 4.2f; GaugeStyle.Sport -> 3.0f; else -> 1.4f }, cap = StrokeCap.Round),
                topLeft = Offset(center.x - radius, center.y - radius),
                size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
            )

            // Style-specific visible progress arc
            if (style == GaugeStyle.Sport || style == GaugeStyle.RsPerformance || style == GaugeStyle.Minimal) {
                drawArc(
                    color = accent.copy(alpha = if (style == GaugeStyle.RsPerformance) .90f else .72f),
                    startAngle = startDeg,
                    sweepAngle = sweepDeg * progress,
                    useCenter = false,
                    style = Stroke(width = when (style) { GaugeStyle.RsPerformance -> 7.0f; GaugeStyle.Sport -> 5.2f; else -> 3.2f }, cap = StrokeCap.Round),
                    topLeft = Offset(center.x - radius, center.y - radius),
                    size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2)
                )
            }

            for (i in 0..tickCount) {
                val frac = i / tickCount.toFloat()
                val angle = (startDeg + sweepDeg * frac) * PI.toFloat() / 180f
                val longTick = when (style) {
                    GaugeStyle.ClassicOem -> i % 4 == 0
                    GaugeStyle.RsPerformance -> i % 3 == 0
                    else -> i % 5 == 0
                }
                val inner = radius - if (longTick) 15f else 8f
                val outer = radius
                val c = if (frac <= progress) accent.copy(alpha = .88f) else tickColor
                drawLine(
                    color = c,
                    start = Offset(center.x + cos(angle) * inner, center.y + sin(angle) * inner),
                    end = Offset(center.x + cos(angle) * outer, center.y + sin(angle) * outer),
                    strokeWidth = when { style == GaugeStyle.RsPerformance && frac <= progress -> 3.0f; longTick -> 2.0f; else -> 1.0f },
                    cap = StrokeCap.Round
                )
            }

            // Classic OEM needle so Classic is not visually identical to Digital.
            if (style == GaugeStyle.ClassicOem) {
                val angle = (startDeg + sweepDeg * progress) * PI.toFloat() / 180f
                drawLine(
                    color = LoganGaugeGreen,
                    start = center,
                    end = Offset(center.x + cos(angle) * (radius - 19f), center.y + sin(angle) * (radius - 19f)),
                    strokeWidth = 3.0f,
                    cap = StrokeCap.Round
                )
                drawCircle(color = LoganGaugeGreen, radius = 5.0f, center = center)
            }

            // RS/Sport decorative side bars inspired by the approved alternatives.
            if (style == GaugeStyle.RsPerformance) {
                drawLine(Color(0xFFD62828), Offset(size.width * .17f, size.height * .28f), Offset(size.width * .31f, size.height * .24f), 3.8f, StrokeCap.Round)
                drawLine(Color(0xFFD62828), Offset(size.width * .69f, size.height * .24f), Offset(size.width * .83f, size.height * .28f), 3.8f, StrokeCap.Round)
            }
            if (style == GaugeStyle.Sport) {
                drawLine(LoganGaugeGreen.copy(alpha = .50f), Offset(size.width * .08f, size.height * .57f), Offset(size.width * .22f, size.height * .57f), 2.6f, StrokeCap.Round)
                drawLine(LoganGaugeGreen.copy(alpha = .50f), Offset(size.width * .78f, size.height * .57f), Offset(size.width * .92f, size.height * .57f), 2.6f, StrokeCap.Round)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                text = speed?.toString() ?: "--",
                color = palette.textPrimary,
                fontSize = when {
                    compact -> if (speed == null) 48.sp else 62.sp
                    speed == null -> 58.sp
                    style == GaugeStyle.RsPerformance -> 76.sp
                    else -> 72.sp
                },
                fontWeight = when (style) {
                    GaugeStyle.RsPerformance -> FontWeight.Black
                    GaugeStyle.ClassicOem -> FontWeight.SemiBold
                    else -> FontWeight.Light
                },
                textAlign = TextAlign.Center,
                maxLines = 1
            )
            Text("km/h", color = palette.textSecondary, fontSize = if (compact) 12.sp else 14.sp, fontWeight = FontWeight.Medium)
            Text(
                text = when { demoMode -> "DEMO"; speed == null -> "OBD BEKLENİYOR"; else -> "CANLI" },
                color = if (demoMode) palette.warning else if (speed == null) palette.critical else accent,
                fontSize = if (compact) 8.5.sp else 10.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    val accent = when (style) {
        GaugeStyle.Digital -> LoganGaugeGreen
        GaugeStyle.Sport -> Color(0xFF1FAD55)
        GaugeStyle.ClassicOem -> Color(0xFF263238)
        GaugeStyle.Minimal -> LoganGaugeGreen
        GaugeStyle.RsPerformance -> Color(0xFFD62828)
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
        modifier = modifier.height(224.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(22.dp))
                .background(palette.surfaceVariant.copy(alpha = .38f))
                .border(1.dp, if (selected) accent.copy(alpha = .65f) else palette.line, RoundedCornerShape(22.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            SpeedGauge(
                palette = palette,
                speed = when (style) {
                    GaugeStyle.RsPerformance -> 128
                    GaugeStyle.Sport -> 90
                    GaugeStyle.ClassicOem -> 90
                    GaugeStyle.Minimal -> 90
                    GaugeStyle.Digital -> 90
                },
                style = style,
                modifier = Modifier.fillMaxWidth(.92f).height(138.dp),
                demoMode = false
            )
        }
        Text(style.label, color = if (selected) palette.accent else palette.textPrimary, fontSize = 15.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewSpeedText(palette: LoganPalette, accent: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("42", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(3.dp))
        Box(modifier = Modifier.size(width = 34.dp, height = 4.dp).clip(CircleShape).background(accent.copy(alpha = .70f)))
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Modern dijital"
    GaugeStyle.Sport -> "Sportif ve dinamik"
    GaugeStyle.ClassicOem -> "Analog ibre"
    GaugeStyle.Minimal -> "Sade dijital"
    GaugeStyle.RsPerformance -> "Performans"
}
