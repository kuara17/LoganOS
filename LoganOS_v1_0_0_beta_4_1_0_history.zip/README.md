# LoganOS v1.0.0-beta.4.1.0 — History

LoganOS, Dacia Logan 2005–2012 1.5 dCi / Delphi DCM1.2 için geliştirilen Kotlin + Jetpack Compose tabanlı bağımsız bir Android OBD kokpit uygulamasıdır.

## Beta 4.1.0 odağı

- Sürüşler kullanıcıdan ayrıca **Kaydet** istemeden otomatik geçmişe alınır.
- Başlatılan manuel marş ve geliştirici testleri ayrı **Test Geçmişi**ne kaydedilir.
- Varsayılan saklama sınırı sürüş ve test için ayrı ayrı **10** kayıttır; 25, 50 veya sınırsız seçilebilir.
- **Koru/Sabitle** yapılan kayıtlar otomatik temizlikte silinmez.
- Her kayıt **İncele**, **Dışa aktar** ve onaylı **Sil** işlemlerine sahiptir.
- Sürüş ve test geçmişinin tamamı tek ZIP paketi olarak dışa aktarılabilir.
- Ayarlar ekranında kayıt sayısı, sabitlenen kayıt sayısı ve yaklaşık veritabanı kullanımı gösterilir.
- Aktif, mola nedeniyle devam edebilecek (`PARKED`) veya saat doğrulaması bekleyen sürüşler otomatik silinmez.
- Kontak/güç kesintisi sırasında açık kalan testler sonraki açılışta `INTERRUPTED` olarak kurtarılır.
- Eski beta teknik OBD oturumları migration veya retention sırasında sessizce silinmez.

## Beta 4.0.0 temelinin korunan özellikleri

- Kayıtları silmeyen SQLite migration altyapısı, WAL ve foreign-key desteği
- `elapsedRealtime` + boot session tabanlı güvenilir zaman yönetimi
- GPS/sistem saati geldikten sonra zaman damgalarının geriye dönük eşlenmesi
- Her kontak / 30 / 60 / 90 dakika Smart Trip mola seçimi
- **Sürüşü şimdi bitir**
- Otomatik / Telefon / Android Multimedya-Double cihaz modu
- Küçük/büyük telefon ve yatay double ekran için uyarlanabilir kokpit
- Digital OEM tek aktif gösterge
- Kalıcı release imzasına hazır GitHub Actions altyapısı

## Bilerek ertelenenler

- `beta.4.2.0`: GitHub tabanlı uygulama içi OTA, yedekleme ve geri yükleme
- Classic OEM / Minimal / Sport / RS Performance gösterge stilleri

## APK oluşturma

`.github/workflows/build-apk.yml` manuel olarak `debug` veya `release` APK üretebilir.

- Test için `debug` seçilebilir.
- Kalıcı dağıtım ve gelecekteki OTA zinciri için aynı release anahtarı kullanılmalıdır.
- Release imza kurulumu: `docs/RELEASE_SIGNING_SETUP_TR.md`

> Mevcut debug paket kimliği `com.dcui.loganos.debug`, release paket kimliği `com.dcui.loganos` değeridir. İlk release geçişi bir defaya mahsus ayrı kurulum gerektirebilir.

## Değiştirilmeyen doğrulanmış çekirdek

Delphi parser byte konumları, FuelAlgorithmV3, injection mg/stroke hesabı, KWP komut/polling dizisi, CUTOFF, COAST_GUARD, AC_FAST ana biti, fan `UNKNOWN` kararı, OBD hız değeri ve TripComputer core logic korunmuştur.

## Bağımsızlık

LoganOS bağımsız olarak geliştirilen bir araç bilgi ve OBD uygulamasıdır. Renault Group veya Dacia ile resmî bağlantısı bulunmamaktadır.
