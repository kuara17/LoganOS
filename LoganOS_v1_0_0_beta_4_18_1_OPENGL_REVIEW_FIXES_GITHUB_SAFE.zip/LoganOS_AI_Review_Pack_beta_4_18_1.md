# LoganOS AI Kod İnceleme Paketi — v1.0.0-beta.4.18.1

## Amaç

Bu paket, beta.4.18.0 Compose + OpenGL ES temelinin Gemini ve Claude incelemelerinden sonra yapılan düzeltmeleri içerir. İnceleme odağı yalnız değişen mimari ve kodlardır.

## Birleştirilmiş dış inceleme sonucu

### Doğrulanan ve uygulanan bulgular

1. **10.000 m dış sarma hatası:** 9 m yol deseniyle uyumsuz dış modül, her yaklaşık 10 km'de yol ve rüzgâr fazında sıçrama oluşturuyordu.
2. **Portrait/landscape dalında GL host yeniden oluşturma riski:** OpenGL host iki ayrı Compose dalındaydı.
3. **Ayarlar önizlemesinde SurfaceView kırpma riski:** Yuvarlatılmış Compose clip içinde GLSurfaceView kullanılıyordu.
4. **Araç dönüş pivotu:** Araç geometrik merkez etrafında dönüyor, lastik temas anchor'ı sabit kalmıyordu.
5. **Tekrarlanan VehicleAssetProfile sabitleri:** Empty state ile gerçek asset profili iki ayrı yerde tutuluyordu.

### İncelenip uygulanmayan bulgular

- `setZOrderOnTop(true)` veya `setZOrderMediaOverlay(true)` eklenmedi. Compose HUD'un SurfaceView üzerinde kalması gerektiğinden bu değişiklik riskliydi.
- `requestRender()` eksik değildi; `submitState()` her yeni snapshot'ta zaten çağırıyordu.
- Shader'da double-premultiplication bulunmadı; mevcut `GL_ONE / GL_ONE_MINUS_SRC_ALPHA` ve shader çarpanları korundu.
- Ayarlar ve kokpitin eşzamanlı iki EGL context açtığı iddiası tam kaynakta doğrulanmadı: `MainTab` yalnız aktif dalı compose ediyor. Buna rağmen ayarlar önizlemesindeki ikinci GL yüzeyi tamamen kaldırıldı.
- Smoothstep tabanlı 2.5D projeksiyon bu sürümde gerçek kamera matrisiyle değiştirilmedi. Önce gerçek cihazdaki Dağ-Göl temel görüntüsü doğrulanacak; kontrolsüz ikinci bir geometri yeniden yazımı yapılmayacak.

## Değiştirilen dosyalar

- `app/build.gradle.kts`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2Renderer.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2RenderState.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2AnimationMath.kt` (yeni)
- `app/src/test/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneModelTest.kt`
- `tools/validate_digital_v2_geometry.kt`
- `tools/preflight_source.py`

## Kritik değişiklikler

### 1. Kesintisiz animasyon mesafesi

Eski:

```kotlin
travelledMeters = positiveModulo(
    travelledMeters + delta,
    10_000f
)
```

Yeni:

```kotlin
private var totalTravelledMeters = 0.0

totalTravelledMeters += speedMps * dtSeconds
val roadPhase = roadPatternPhaseMeters(totalTravelledMeters, 9f)
```

- Ana mesafe `Double` ve dışarıdan sarılmıyor.
- Yol yalnız 9 m'lik kendi tam deseninde sarılıyor.
- Rüzgâr ilerleme ve alfa fazları kendi kesin periyotlarında ayrı hesaplanıyor.

### 2. Tek ve sabit OpenGL host

`DigitalV2Cockpit()` artık portrait ve landscape için iki ayrı GL composable dalı üretmiyor. Bir `BoxWithConstraints` içinde tek `DigitalV2SceneStage()` çağrısı bulunuyor; yalnız modifier boyutu/konumu değişiyor.

Beklenen sonuç:

- Yön değişiminde Compose çağrı konumu korunur.
- `LoganGLSurfaceView` gereksiz yere dispose edilip yeniden yaratılmaz.
- Surface yeniden boyutlandığında mevcut renderer `onSurfaceChanged()` üzerinden devam eder.

### 3. Ayarlar önizlemesi

Ayarlar, `LazyColumn` içindedir. Canlı `GLSurfaceView` kaldırıldı. Yeni önizleme:

- normal Compose `Image` katmanları kullanır,
- aynı `DigitalV2SceneModel`, araç pose ve asset profiliyle araç/gölge anchor'ını hesaplar,
- yuvarlatılmış köşe clip'ini güvenilir biçimde uygular,
- ikinci EGL context ve SurfaceView scrolling/clipping riskini ortadan kaldırır.

Önizleme statiktir; yol/rüzgâr animasyonu yalnız gerçek kokpit OpenGL yüzeyinde çalışır.

### 4. Araç ve gölge pivotu

`drawTexturedQuad()` artık isteğe bağlı dönüş pivotu kabul eder. Araç ve gölge için pivot:

```kotlin
rotationPivotX = anchor.x
rotationPivotY = anchor.y
```

Bu nedenle heading artırıldığında lastik temas noktası yol üzerinde sabit kalır.

### 5. Tek asset profili kaynağı

`DigitalV2RenderState.Empty`, Logan I profilini artık elle tekrar yazmıyor:

```kotlin
vehicleAsset = digitalV2VehicleAssetProfile(VehicleVisualModel.LoganI)
```

## Uygulanan kontroller

- `tools/preflight_source.py`: PASS
- `tools/validate_release.py`: PASS
- `DigitalV2SceneModel.kt + DigitalV2AnimationMath.kt + validate_digital_v2_geometry.kt`: `kotlinc` ile derlendi ve çalıştırıldı
- Dört sahnede viewport, yol daralması, sağ şerit araç anchor'ı, 3 m çizgi + 6 m boşluk: PASS
- Eski 10.000 m sınırının iki tarafında yol fazı sürekliliği: PASS
- Eski 10.000 m sınırının iki tarafında rüzgâr fazı sürekliliği: PASS
- OpenGL renderer/host/surface sınıfları Android/Compose API stub'larıyla Kotlin derleme kontrolü: PASS
- `DigitalV2Cockpit.kt` parse kontrolü: sözdizimi hatası bulunmadı; Android/Compose bağımlılıkları yerel ortamda olmadığı için gerçek modül derlemesi yapılmadı
- ZIP bütünlük ve yeniden-açma kontrolleri paketleme sonrasında çalıştırılacaktır

## Bilinen ve dürüstçe açık kalan noktalar

1. Yerel ortamda Android SDK, Gradle ve wrapper olmadığı için `assembleDebug` çalıştırılamadı.
2. EGL context loss, gerçek SurfaceView katman sırası ve GPU shader derlemesi gerçek cihazda test edilmedi.
3. Yol projeksiyonu hâlâ sahneye özel kalibre edilmiş parçalı 2.5D profildir; tam 3D kamera/projection matrix değildir.
4. Görsel yerleşim henüz Samsung S23 FE ve 2 GB Double ekran görüntüsüyle onaylanmadı.
5. İlk cihaz testinde yalnız Dağ-Göl sahnesi esas alınmalı; araç, gölge ve çizgi onaylanmadan diğer sahnelerin kalibrasyonu değiştirilmemelidir.

## Claude/Gemini için inceleme talimatı

> Ekteki LoganOS beta.4.18.1 değişen kaynaklarını kıdemli Android, Jetpack Compose ve OpenGL ES geliştiricisi gibi incele. Özellikle şu noktaları gerçek kod üzerinden doğrula: (1) Double toplam mesafe ve ayrı yol/rüzgâr fazlarında herhangi bir wrap sıçraması veya precision problemi kaldı mı, (2) tek `DigitalV2SceneStage` çağrı konumu portrait/landscape değişiminde `GLSurfaceView` örneğini gerçekten korur mu, (3) statik ayarlar önizlemesinin ölçü/anchor hesaplarında Compose Dp veya aspect-ratio hatası var mı, (4) araç ve gölge dönüş pivotu lastik temasını gerçekten sabit tutuyor mu, (5) yeni kodda derleme hatası, lifecycle yarışı, kaynak sızıntısı veya 2 GB cihaz performans riski var mı. Genel övgü yerine dosya/fonksiyon/satır düzeyinde somut bulgu üret. Yanlış alarm ihtimalini açıkça belirt. En sonda gerçek APK cihaz testine hazır olup olmadığını gerekçelendir.
