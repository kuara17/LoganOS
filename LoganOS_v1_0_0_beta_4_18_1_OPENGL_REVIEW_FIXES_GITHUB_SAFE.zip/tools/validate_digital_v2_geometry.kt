package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.abs

private fun requireGeometry(condition: Boolean, message: String) {
    check(condition) { message }
}

fun main() {

    listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
        val viewport = calculateDigitalV2Viewport(width, height)
        val aspect = viewport.width.toFloat() / viewport.height.toFloat()
        requireGeometry(abs(aspect - DIGITAL_V2_STAGE_ASPECT_RATIO) < 0.005f, "Viewport $width x $height stretches the logical stage")
        requireGeometry(viewport.x >= 0 && viewport.y >= 0, "Viewport offset is negative")
        requireGeometry(viewport.x + viewport.width <= width, "Viewport exceeds surface width")
        requireGeometry(viewport.y + viewport.height <= height, "Viewport exceeds surface height")
    }
    println("[PASS] viewport: fixed 1080x1320 stage fits phone, Double and preview surfaces without stretching")

    val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    scenes.forEach { scene ->
        val road = scene.road
        requireGeometry(road.samples.first().distanceMeters == 0f, "${scene.key}: road must start at zero metres")
        requireGeometry(road.samples.zipWithNext().all { (near, far) -> far.distanceMeters > near.distanceMeters }, "${scene.key}: distance must be strictly increasing")
        requireGeometry(road.samples.zipWithNext().all { (near, far) -> far.screenYRatio < near.screenYRatio }, "${scene.key}: farther road samples must move toward the horizon")
        requireGeometry(road.samples.zipWithNext().all { (near, far) -> far.halfWidthRatio < near.halfWidthRatio }, "${scene.key}: farther road samples must become narrower")

        val pose = scene.vehiclePose
        val vehicleAnchor = road.project(pose.anchorDistanceMeters, pose.lateralMeters)
        val roadLeft = road.project(pose.anchorDistanceMeters, -road.roadHalfWidthMeters)
        val roadRight = road.project(pose.anchorDistanceMeters, road.roadHalfWidthMeters)
        requireGeometry(vehicleAnchor.xRatio in roadLeft.xRatio..roadRight.xRatio, "${scene.key}: vehicle anchor must stay inside the road")
        requireGeometry(vehicleAnchor.xRatio > road.project(pose.anchorDistanceMeters).xRatio, "${scene.key}: vehicle must remain in the right lane")
        requireGeometry(vehicleAnchor.yRatio in 0.70f..0.92f, "${scene.key}: vehicle contact must not be too near or too high")
        requireGeometry(pose.visibleWidthRatio in 0.20f..0.23f, "${scene.key}: vehicle size must remain in the accepted follow-camera range")

        val pattern = road.markings
        requireGeometry(abs(pattern.dashLengthMeters - 3f) < 0.001f, "${scene.key}: dash length changed")
        requireGeometry(abs(pattern.gapLengthMeters - 6f) < 0.001f, "${scene.key}: gap length changed")
        requireGeometry(pattern.repeatLengthMeters == 9f, "${scene.key}: road marking repeat must be 9 metres")

        // Projection continuity check around every calibration knot.
        road.samples.drop(1).dropLast(1).forEach { sample ->
            val before = road.project(sample.distanceMeters - 0.01f)
            val after = road.project(sample.distanceMeters + 0.01f)
            requireGeometry(abs(before.xRatio - after.xRatio) < 0.01f, "${scene.key}: centerline discontinuity near ${sample.distanceMeters}m")
            requireGeometry(abs(before.yRatio - after.yRatio) < 0.01f, "${scene.key}: Y discontinuity near ${sample.distanceMeters}m")
        }

        println("[PASS] ${scene.key}: projection, vehicle anchor and 3m/6m marking contract")
    }
    val formerBoundaryBefore = roadPatternPhaseMeters(9_999.99, 9f)
    val formerBoundaryAfter = roadPatternPhaseMeters(10_000.01, 9f)
    val roadForwardDelta = positiveModulo(
        (formerBoundaryAfter - formerBoundaryBefore).toDouble(),
        9.0
    )
    requireGeometry(abs(roadForwardDelta - 0.02) < 0.0005, "Road phase jumps at the former 10,000m wrap")

    val windCycle = 51f
    val windBefore = windTravelPhaseMeters(9_999.99, windCycle)
    val windAfter = windTravelPhaseMeters(10_000.01, windCycle)
    val windForwardDelta = positiveModulo(
        (windAfter - windBefore).toDouble(),
        windCycle.toDouble()
    )
    val expectedWindDelta = 0.02 * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER
    requireGeometry(abs(windForwardDelta - expectedWindDelta) < 0.0005, "Wind phase jumps at the former 10,000m wrap")
    println("[PASS] animation: road and wind phases remain continuous across the former 10,000m boundary")

}
