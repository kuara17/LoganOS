package com.dcui.loganos.ui.cockpit.opengl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DigitalV2SceneModelTest {
    private val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    @Test
    fun projectionNarrowsTowardHorizon() {
        scenes.forEach { scene ->
            scene.road.samples.zipWithNext().forEach { (near, far) ->
                assertTrue("${scene.key}: distance", far.distanceMeters > near.distanceMeters)
                assertTrue("${scene.key}: y", far.screenYRatio < near.screenYRatio)
                assertTrue("${scene.key}: width", far.halfWidthRatio < near.halfWidthRatio)
            }
        }
    }

    @Test
    fun vehicleAnchorRemainsInRightLane() {
        scenes.forEach { scene ->
            val road = scene.road
            val pose = scene.vehiclePose
            val center = road.project(pose.anchorDistanceMeters)
            val anchor = road.project(pose.anchorDistanceMeters, pose.lateralMeters)
            val rightEdge = road.project(pose.anchorDistanceMeters, road.roadHalfWidthMeters)
            assertTrue("${scene.key}: right lane", anchor.xRatio > center.xRatio)
            assertTrue("${scene.key}: within road", anchor.xRatio < rightEdge.xRatio)
            assertTrue("${scene.key}: contact Y", anchor.yRatio in 0.70f..0.92f)
        }
    }

    @Test
    fun viewportPreservesLogicalAspectWithoutStretching() {
        listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
            val viewport = calculateDigitalV2Viewport(width, height)
            val aspect = viewport.width.toFloat() / viewport.height.toFloat()
            assertEquals(DIGITAL_V2_STAGE_ASPECT_RATIO, aspect, 0.005f)
            assertTrue(viewport.x >= 0 && viewport.y >= 0)
            assertTrue(viewport.x + viewport.width <= width)
            assertTrue(viewport.y + viewport.height <= height)
        }
    }

    @Test
    fun markingsUseOneWorldSpacePattern() {
        scenes.forEach { scene ->
            assertEquals(3f, scene.road.markings.dashLengthMeters, 0.0001f)
            assertEquals(6f, scene.road.markings.gapLengthMeters, 0.0001f)
            assertEquals(9f, scene.road.markings.repeatLengthMeters, 0.0001f)
        }
    }
    @Test
    fun roadPhaseIsContinuousAcrossFormerTenKilometreBoundary() {
        val repeat = 9f
        val beforeDistance = 9_999.99
        val afterDistance = 10_000.01
        val before = roadPatternPhaseMeters(beforeDistance, repeat)
        val after = roadPatternPhaseMeters(afterDistance, repeat)
        val forwardDelta = positiveModulo(
            (after - before).toDouble(),
            repeat.toDouble()
        )
        assertEquals(0.02, forwardDelta, 0.0005)
    }

    @Test
    fun windPhasesWrapOnlyAtTheirOwnExactCycles() {
        val cycle = 51f
        val distance = 10_000.0
        val epsilon = 0.01
        val before = windTravelPhaseMeters(distance - epsilon, cycle)
        val after = windTravelPhaseMeters(distance + epsilon, cycle)
        val forwardDelta = positiveModulo(
            (after - before).toDouble(),
            cycle.toDouble()
        )
        assertEquals(epsilon * 2.0 * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER, forwardDelta, 0.0005)
    }

}
