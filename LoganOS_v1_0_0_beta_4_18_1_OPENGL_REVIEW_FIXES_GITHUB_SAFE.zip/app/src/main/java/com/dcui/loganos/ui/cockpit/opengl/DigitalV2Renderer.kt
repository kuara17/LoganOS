package com.dcui.loganos.ui.cockpit.opengl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * OpenGL ES 2.0 renderer for the Digital V2 visual scene.
 *
 * Compose owns the HUD, controls and data cards. This renderer owns the
 * background, projected road markings, off-road wind, road contact shadow and
 * vehicle sprite. The GL thread only consumes immutable snapshots.
 */
internal class DigitalV2Renderer(
    private val context: Context
) : GLSurfaceView.Renderer {

    private val pendingState = AtomicReference(DigitalV2RenderState.Empty)
    private var activeState = DigitalV2RenderState.Empty

    private var texturedProgram: TexturedProgram? = null
    private var solidProgram: SolidProgram? = null

    private var backgroundTexture: GlTexture? = null
    private var vehicleTexture: GlTexture? = null
    private var shadowTexture: GlTexture? = null
    private var loadedBackgroundRes = 0
    private var loadedVehicleRes = 0
    private var loadedShadowRes = 0

    private var lastFrameNanos = 0L
    private var smoothedSpeedKmh = 0f
    private var totalTravelledMeters = 0.0

    /** Reused GL vertex scratch arrays; no per-draw direct buffers are allocated. */
    private val texturedVertexScratch = FloatArray(16)
    private val solidVertexScratch = FloatArray(12)

    fun submitState(state: DigitalV2RenderState) {
        pendingState.set(state)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // A new EGL context invalidates all previous GL object names even when
        // the Kotlin renderer instance survives a lifecycle transition.
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0

        GLES20.glClearColor(0.03f, 0.05f, 0.08f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        // Android bitmaps uploaded through GLUtils are premultiplied-alpha.
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        texturedProgram = TexturedProgram()
        solidProgram = SolidProgram()
        lastFrameNanos = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val viewport = calculateDigitalV2Viewport(width, height)
        GLES20.glViewport(viewport.x, viewport.y, viewport.width, viewport.height)
    }

    override fun onDrawFrame(gl: GL10?) {
        activeState = pendingState.get()
        ensureTextures(activeState)
        updateClock(activeState)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        drawBackground()
        drawRoadMarkings(activeState.sceneModel)
        drawWind(activeState.sceneModel)
        drawVehicleGroundShadow(activeState)
        drawVehicle(activeState)

        if (activeState.calibrationVisible) {
            drawCalibration(activeState.sceneModel)
        }
    }

    fun releaseGlResources() {
        releaseTexture(backgroundTexture)
        releaseTexture(vehicleTexture)
        releaseTexture(shadowTexture)
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0
        texturedProgram?.release()
        solidProgram?.release()
        texturedProgram = null
        solidProgram = null
    }

    private fun updateClock(state: DigitalV2RenderState) {
        val now = System.nanoTime()
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now
            return
        }
        val dtSeconds = ((now - lastFrameNanos) / 1_000_000_000.0)
            .toFloat()
            .coerceIn(0f, 0.05f)
        lastFrameNanos = now

        val targetSpeed = if (state.motionEnabled) {
            state.speedKmh.coerceIn(0f, 180f)
        } else {
            0f
        }
        val smoothingSeconds = 0.32f
        val blend = (1f - exp((-dtSeconds / smoothingSeconds).toDouble()).toFloat())
            .coerceIn(0f, 1f)
        smoothedSpeedKmh += (targetSpeed - smoothedSpeedKmh) * blend

        if (state.motionEnabled && smoothedSpeedKmh >= 2f) {
            totalTravelledMeters +=
                (smoothedSpeedKmh.toDouble() / 3.6) * dtSeconds.toDouble()
        }
    }

    private fun ensureTextures(state: DigitalV2RenderState) {
        if (state.backgroundResId != 0 && state.backgroundResId != loadedBackgroundRes) {
            releaseTexture(backgroundTexture)
            backgroundTexture = loadTexture(state.backgroundResId)
            loadedBackgroundRes = state.backgroundResId
        }
        if (state.vehicleResId != 0 && state.vehicleResId != loadedVehicleRes) {
            releaseTexture(vehicleTexture)
            vehicleTexture = loadTexture(state.vehicleResId)
            loadedVehicleRes = state.vehicleResId
        }
        if (state.shadowResId != 0 && state.shadowResId != loadedShadowRes) {
            releaseTexture(shadowTexture)
            shadowTexture = loadTexture(state.shadowResId)
            loadedShadowRes = state.shadowResId
        }
    }

    private fun drawBackground() {
        val texture = backgroundTexture ?: return
        drawTexturedQuad(
            texture = texture,
            centerX = DIGITAL_V2_LOGICAL_WIDTH * 0.5f,
            centerY = DIGITAL_V2_LOGICAL_HEIGHT * 0.5f,
            width = DIGITAL_V2_LOGICAL_WIDTH,
            height = DIGITAL_V2_LOGICAL_HEIGHT,
            rotationDegrees = 0f,
            alpha = 1f,
            colorMultiplier = WHITE
        )
    }

    private fun drawRoadMarkings(scene: DigitalV2SceneModel) {
        val road = scene.road
        val pattern = road.markings
        val phase = roadPatternPhaseMeters(totalTravelledMeters, pattern.repeatLengthMeters)

        var dashStart = -phase
        while (dashStart < road.maxDistanceMeters) {
            val dashEnd = dashStart + pattern.dashLengthMeters
            if (dashEnd > 0f && dashStart < road.maxDistanceMeters) {
                drawRoadStrip(
                    road = road,
                    startDistance = max(0f, dashStart),
                    endDistance = min(road.maxDistanceMeters, dashEnd),
                    lateralCenterMeters = 0f,
                    widthMeters = pattern.centerLineWidthMeters,
                    color = road.centerLineColor
                )
            }
            dashStart += pattern.repeatLengthMeters
        }

        if (road.drawEdgeLines) {
            val inset = pattern.edgeLineWidthMeters * 0.6f
            drawContinuousRoadStrip(
                road = road,
                lateralCenterMeters = -(road.roadHalfWidthMeters - inset),
                widthMeters = pattern.edgeLineWidthMeters,
                color = road.edgeLineColor
            )
            drawContinuousRoadStrip(
                road = road,
                lateralCenterMeters = road.roadHalfWidthMeters - inset,
                widthMeters = pattern.edgeLineWidthMeters,
                color = road.edgeLineColor
            )
        }
    }

    private fun drawContinuousRoadStrip(
        road: RoadProjectionProfile,
        lateralCenterMeters: Float,
        widthMeters: Float,
        color: GlColor
    ) {
        var start = 0f
        val segmentLength = 2.5f
        while (start < road.maxDistanceMeters) {
            val end = min(road.maxDistanceMeters, start + segmentLength)
            drawRoadStrip(road, start, end, lateralCenterMeters, widthMeters, color)
            start = end
        }
    }

    private fun drawRoadStrip(
        road: RoadProjectionProfile,
        startDistance: Float,
        endDistance: Float,
        lateralCenterMeters: Float,
        widthMeters: Float,
        color: GlColor
    ) {
        if (endDistance <= startDistance + 0.001f) return
        val half = widthMeters * 0.5f
        val nearLeft = road.project(startDistance, lateralCenterMeters - half).toLogicalPoint()
        val nearRight = road.project(startDistance, lateralCenterMeters + half).toLogicalPoint()
        val farRight = road.project(endDistance, lateralCenterMeters + half).toLogicalPoint()
        val farLeft = road.project(endDistance, lateralCenterMeters - half).toLogicalPoint()
        drawSolidQuad(nearLeft, nearRight, farRight, farLeft, color)
    }

    private fun drawWind(scene: DigitalV2SceneModel) {
        val wind = scene.wind
        if (!wind.enabled || !activeState.motionEnabled || smoothedSpeedKmh < 8f) return

        val strength = ((smoothedSpeedKmh - 8f) / 92f).coerceIn(0f, 1f)
        val maxDistance = min(58f, scene.road.maxDistanceMeters - 4f)
        val movementCycleMeters = maxDistance - 7f
        val travelPhase = windTravelPhaseMeters(totalTravelledMeters, movementCycleMeters)
        val pulsePhase = windPulsePhaseRadians(totalTravelledMeters)
        repeat(wind.particleCountPerSide) { index ->
            val base = index * (maxDistance / max(1, wind.particleCountPerSide))
            val distance = 7f + positiveModulo(
                (base - travelPhase).toDouble(),
                movementCycleMeters.toDouble()
            ).toFloat()
            drawWindParticle(scene, wind, distance, index, -1f, strength, pulsePhase)
            drawWindParticle(scene, wind, distance, index, 1f, strength, pulsePhase)
        }
    }

    private fun drawWindParticle(
        scene: DigitalV2SceneModel,
        wind: WindProfile,
        distance: Float,
        index: Int,
        side: Float,
        strength: Float,
        pulsePhase: Float
    ) {
        val lateral = side * (scene.road.roadHalfWidthMeters + wind.shoulderOffsetMeters)
        val tail = scene.road.project(distance + 3.4f, lateral).toLogicalPoint()
        val headBase = scene.road.project(distance, lateral).toLogicalPoint()
        val outward = side * (12f + 26f * strength)
        val head = LogicalPoint(headBase.x + outward, headBase.y + 4f + 10f * strength)
        val alphaPulse = 0.55f + 0.45f *
            sin((pulsePhase + index * 1.17f).toDouble()).toFloat()
        drawSegmentQuad(
            start = tail,
            end = head,
            widthPixels = 1.1f + 1.7f * strength,
            color = GlColor(
                red = 0.88f,
                green = 0.95f,
                blue = 1f,
                alpha = (wind.maxAlpha * strength * alphaPulse).coerceIn(0f, 1f)
            )
        )
    }

    private fun drawVehicleGroundShadow(state: DigitalV2RenderState) {
        val texture = shadowTexture ?: return
        val scene = state.sceneModel
        val pose = scene.vehiclePose
        val anchor = scene.road
            .project(pose.anchorDistanceMeters, pose.lateralMeters)
            .toLogicalPoint()
        val width = DIGITAL_V2_LOGICAL_WIDTH * pose.shadowWidthRatio
        val height = width * (texture.height.toFloat() / max(1, texture.width).toFloat())
        drawTexturedQuad(
            texture = texture,
            centerX = anchor.x,
            centerY = anchor.y - height * 0.05f,
            width = width,
            height = height,
            rotationDegrees = pose.headingDegrees,
            alpha = pose.shadowAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = anchor.x,
            rotationPivotY = anchor.y
        )
    }

    private fun drawVehicle(state: DigitalV2RenderState) {
        val texture = vehicleTexture ?: return
        val scene = state.sceneModel
        val pose = scene.vehiclePose
        val anchor = scene.road
            .project(pose.anchorDistanceMeters, pose.lateralMeters)
            .toLogicalPoint()
        val fullTextureWidth = DIGITAL_V2_LOGICAL_WIDTH *
            (pose.visibleWidthRatio / state.vehicleAsset.visibleWidthRatioInTexture)
        val fullTextureHeight = fullTextureWidth * state.vehicleAsset.textureAspectHeightOverWidth
        val top = anchor.y - fullTextureHeight * state.vehicleAsset.contactYRatioInTexture

        // Vehicle body movement is intentionally disabled in this grounding
        // phase. The road moves beneath a fixed tyre-contact anchor.
        drawTexturedQuad(
            texture = texture,
            centerX = anchor.x,
            centerY = top + fullTextureHeight * 0.5f,
            width = fullTextureWidth,
            height = fullTextureHeight,
            rotationDegrees = pose.headingDegrees,
            alpha = 1f,
            colorMultiplier = pose.colorMultiplier,
            rotationPivotX = anchor.x,
            rotationPivotY = anchor.y
        )
    }

    private fun drawCalibration(scene: DigitalV2SceneModel) {
        scene.road.samples.forEach { sample ->
            val center = scene.road.project(sample.distanceMeters).toLogicalPoint()
            drawSolidQuad(
                LogicalPoint(center.x - 4f, center.y - 4f),
                LogicalPoint(center.x + 4f, center.y - 4f),
                LogicalPoint(center.x + 4f, center.y + 4f),
                LogicalPoint(center.x - 4f, center.y + 4f),
                MAGENTA
            )
        }
        val anchor = scene.road
            .project(scene.vehiclePose.anchorDistanceMeters, scene.vehiclePose.lateralMeters)
            .toLogicalPoint()
        drawSegmentQuad(
            start = LogicalPoint(anchor.x - 22f, anchor.y),
            end = LogicalPoint(anchor.x + 22f, anchor.y),
            widthPixels = 3f,
            color = GREEN
        )
    }

    private fun drawTexturedQuad(
        texture: GlTexture,
        centerX: Float,
        centerY: Float,
        width: Float,
        height: Float,
        rotationDegrees: Float,
        alpha: Float,
        colorMultiplier: GlColor,
        rotationPivotX: Float = centerX,
        rotationPivotY: Float = centerY
    ) {
        val program = texturedProgram ?: return
        val halfW = width * 0.5f
        val halfH = height * 0.5f
        val radians = rotationDegrees * PI.toFloat() / 180f
        val cosAngle = cos(radians)
        val sinAngle = sin(radians)

        fun corner(localX: Float, localY: Float): NdcPoint {
            val unrotatedX = centerX + localX
            val unrotatedY = centerY + localY
            val relativeX = unrotatedX - rotationPivotX
            val relativeY = unrotatedY - rotationPivotY
            val x = rotationPivotX + relativeX * cosAngle - relativeY * sinAngle
            val y = rotationPivotY + relativeX * sinAngle + relativeY * cosAngle
            return logicalToNdc(x, y)
        }

        val topLeft = corner(-halfW, -halfH)
        val bottomLeft = corner(-halfW, halfH)
        val topRight = corner(halfW, -halfH)
        val bottomRight = corner(halfW, halfH)

        texturedVertexScratch[0] = topLeft.x
        texturedVertexScratch[1] = topLeft.y
        texturedVertexScratch[2] = 0f
        texturedVertexScratch[3] = 0f
        texturedVertexScratch[4] = bottomLeft.x
        texturedVertexScratch[5] = bottomLeft.y
        texturedVertexScratch[6] = 0f
        texturedVertexScratch[7] = 1f
        texturedVertexScratch[8] = topRight.x
        texturedVertexScratch[9] = topRight.y
        texturedVertexScratch[10] = 1f
        texturedVertexScratch[11] = 0f
        texturedVertexScratch[12] = bottomRight.x
        texturedVertexScratch[13] = bottomRight.y
        texturedVertexScratch[14] = 1f
        texturedVertexScratch[15] = 1f

        program.draw(texture.id, texturedVertexScratch, alpha, colorMultiplier)
    }

    private fun drawSolidQuad(
        p1: LogicalPoint,
        p2: LogicalPoint,
        p3: LogicalPoint,
        p4: LogicalPoint,
        color: GlColor
    ) {
        val a = logicalToNdc(p1.x, p1.y)
        val b = logicalToNdc(p2.x, p2.y)
        val c = logicalToNdc(p3.x, p3.y)
        val d = logicalToNdc(p4.x, p4.y)

        solidVertexScratch[0] = a.x
        solidVertexScratch[1] = a.y
        solidVertexScratch[2] = b.x
        solidVertexScratch[3] = b.y
        solidVertexScratch[4] = c.x
        solidVertexScratch[5] = c.y
        solidVertexScratch[6] = a.x
        solidVertexScratch[7] = a.y
        solidVertexScratch[8] = c.x
        solidVertexScratch[9] = c.y
        solidVertexScratch[10] = d.x
        solidVertexScratch[11] = d.y

        solidProgram?.draw(solidVertexScratch, color)
    }

    private fun drawSegmentQuad(
        start: LogicalPoint,
        end: LogicalPoint,
        widthPixels: Float,
        color: GlColor
    ) {
        val dx = end.x - start.x
        val dy = end.y - start.y
        val length = sqrt(dx * dx + dy * dy)
        if (length < 0.01f) return
        val normalX = -dy / length * widthPixels * 0.5f
        val normalY = dx / length * widthPixels * 0.5f
        drawSolidQuad(
            LogicalPoint(start.x + normalX, start.y + normalY),
            LogicalPoint(start.x - normalX, start.y - normalY),
            LogicalPoint(end.x - normalX, end.y - normalY),
            LogicalPoint(end.x + normalX, end.y + normalY),
            color
        )
    }

    private fun ProjectedRoadPoint.toLogicalPoint(): LogicalPoint = LogicalPoint(
        x = xRatio * DIGITAL_V2_LOGICAL_WIDTH,
        y = yRatio * DIGITAL_V2_LOGICAL_HEIGHT
    )

    private fun logicalToNdc(x: Float, y: Float): NdcPoint = NdcPoint(
        x = x / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f,
        y = 1f - y / DIGITAL_V2_LOGICAL_HEIGHT * 2f
    )

    private fun loadTexture(resourceId: Int): GlTexture? {
        val bitmap = BitmapFactory.decodeResource(context.resources, resourceId) ?: return null
        return try {
            val names = IntArray(1)
            GLES20.glGenTextures(1, names, 0)
            val textureId = names[0]
            if (textureId == 0) return null

            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MIN_FILTER,
                GLES20.GL_LINEAR
            )
            GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_MAG_FILTER,
                GLES20.GL_LINEAR
            )
            GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_S,
                GLES20.GL_CLAMP_TO_EDGE
            )
            GLES20.glTexParameteri(
                GLES20.GL_TEXTURE_2D,
                GLES20.GL_TEXTURE_WRAP_T,
                GLES20.GL_CLAMP_TO_EDGE
            )
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
            GlTexture(textureId, bitmap.width, bitmap.height)
        } catch (error: RuntimeException) {
            Log.e(TAG, "Texture load failed for resource $resourceId", error)
            null
        } finally {
            bitmap.recycle()
        }
    }

    private fun releaseTexture(texture: GlTexture?) {
        texture ?: return
        GLES20.glDeleteTextures(1, intArrayOf(texture.id), 0)
    }

    private data class LogicalPoint(val x: Float, val y: Float)
    private data class NdcPoint(val x: Float, val y: Float)
    private data class GlTexture(val id: Int, val width: Int, val height: Int)

    private class TexturedProgram {
        private val programId = createProgram(TEXTURED_VERTEX_SHADER, TEXTURED_FRAGMENT_SHADER)
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val textureCoordinateHandle = GLES20.glGetAttribLocation(programId, "aTexCoord")
        private val textureHandle = GLES20.glGetUniformLocation(programId, "uTexture")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val colorMultiplierHandle = GLES20.glGetUniformLocation(programId, "uColorMultiplier")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(16)

        fun draw(
            textureId: Int,
            vertices: FloatArray,
            alpha: Float,
            colorMultiplier: GlColor
        ) {
            vertexBuffer.clear()
            vertexBuffer.put(vertices, 0, 16)
            vertexBuffer.position(0)

            GLES20.glUseProgram(programId)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                16,
                vertexBuffer
            )
            vertexBuffer.position(2)
            GLES20.glEnableVertexAttribArray(textureCoordinateHandle)
            GLES20.glVertexAttribPointer(
                textureCoordinateHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                16,
                vertexBuffer
            )
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLES20.glUniform1i(textureHandle, 0)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 1f))
            GLES20.glUniform4f(
                colorMultiplierHandle,
                colorMultiplier.red,
                colorMultiplier.green,
                colorMultiplier.blue,
                colorMultiplier.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(positionHandle)
            GLES20.glDisableVertexAttribArray(textureCoordinateHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    private class SolidProgram {
        private val programId = createProgram(SOLID_VERTEX_SHADER, SOLID_FRAGMENT_SHADER)
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(12)

        fun draw(vertices: FloatArray, color: GlColor) {
            vertexBuffer.clear()
            vertexBuffer.put(vertices, 0, 12)
            vertexBuffer.position(0)

            GLES20.glUseProgram(programId)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                8,
                vertexBuffer
            )
            GLES20.glUniform4f(
                colorHandle,
                color.red,
                color.green,
                color.blue,
                color.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    companion object {
        private const val TAG = "DigitalV2Renderer"
        private val WHITE = GlColor(1f, 1f, 1f, 1f)
        private val MAGENTA = GlColor(1f, 0f, 0.75f, 0.95f)
        private val GREEN = GlColor(0.1f, 1f, 0.3f, 0.95f)

        private const val TEXTURED_VERTEX_SHADER = """
            attribute vec2 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
                vTexCoord = aTexCoord;
            }
        """

        private const val TEXTURED_FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexture;
            uniform float uAlpha;
            uniform vec4 uColorMultiplier;
            varying vec2 vTexCoord;
            void main() {
                vec4 sampled = texture2D(uTexture, vTexCoord);
                float extraAlpha = uAlpha * uColorMultiplier.a;
                gl_FragColor = vec4(
                    sampled.rgb * uColorMultiplier.rgb * extraAlpha,
                    sampled.a * extraAlpha
                );
            }
        """

        private const val SOLID_VERTEX_SHADER = """
            attribute vec2 aPosition;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
            }
        """

        private const val SOLID_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            void main() {
                gl_FragColor = vec4(uColor.rgb * uColor.a, uColor.a);
            }
        """

        private fun createProgram(vertexSource: String, fragmentSource: String): Int {
            val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
            val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
            val program = GLES20.glCreateProgram()
            check(program != 0) { "Unable to create OpenGL program" }
            GLES20.glAttachShader(program, vertexShader)
            GLES20.glAttachShader(program, fragmentShader)
            GLES20.glLinkProgram(program)
            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(program)
                GLES20.glDeleteProgram(program)
                error("OpenGL program link failed: $log")
            }
            GLES20.glDeleteShader(vertexShader)
            GLES20.glDeleteShader(fragmentShader)
            return program
        }

        private fun compileShader(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            check(shader != 0) { "Unable to create OpenGL shader" }
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val compileStatus = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
            if (compileStatus[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                error("OpenGL shader compile failed: $log")
            }
            return shader
        }

        private fun allocateFloatBuffer(floatCount: Int): FloatBuffer =
            ByteBuffer.allocateDirect(floatCount * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()

    }
}
