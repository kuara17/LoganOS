package com.dcui.loganos.ui.cockpit.opengl

import com.dcui.loganos.R
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleVisualModel
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes

internal fun DigitalV2Scene.toOpenGlKey(): DigitalV2SceneKey = when (this) {
    DigitalV2Scene.MountainLake -> DigitalV2SceneKey.MountainLake
    DigitalV2Scene.CityDay -> DigitalV2SceneKey.CityDay
    DigitalV2Scene.CityNight -> DigitalV2SceneKey.CityNight
    DigitalV2Scene.SnowRoad -> DigitalV2SceneKey.SnowRoad
}

internal fun digitalV2BackgroundRes(scene: DigitalV2Scene): Int = when (scene) {
    DigitalV2Scene.MountainLake -> R.drawable.digital_v2_mountain_lake_bg
    DigitalV2Scene.CityDay -> R.drawable.digital_v2_city_day_bg
    DigitalV2Scene.CityNight -> R.drawable.digital_v2_city_night_bg
    DigitalV2Scene.SnowRoad -> R.drawable.digital_v2_snow_road_bg
}

internal fun digitalV2ShadowRes(model: VehicleVisualModel): Int = when (model) {
    VehicleVisualModel.LoganI -> R.drawable.digital_v2_ground_shadow_logan1
    VehicleVisualModel.LoganIII -> R.drawable.digital_v2_ground_shadow_logan3
}

internal fun digitalV2VehicleAssetProfile(model: VehicleVisualModel): VehicleAssetProfile = when (model) {
    VehicleVisualModel.LoganI -> VehicleAssetProfile(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleWidthRatioInTexture = 877f / 1014f,
        contactYRatioInTexture = 828f / 914f
    )
    VehicleVisualModel.LoganIII -> VehicleAssetProfile(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleWidthRatioInTexture = 901f / 1014f,
        contactYRatioInTexture = 828f / 914f
    )
}

internal fun digitalV2RenderState(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    calibrationVisible: Boolean = false
): DigitalV2RenderState = DigitalV2RenderState(
    sceneKey = settings.digitalV2Scene.toOpenGlKey(),
    backgroundResId = digitalV2BackgroundRes(settings.digitalV2Scene),
    vehicleResId = vehicleVisualDrawableRes(
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor,
        style = VehicleAssetStyle.Detailed
    ),
    shadowResId = digitalV2ShadowRes(settings.vehicleVisualModel),
    vehicleAsset = digitalV2VehicleAssetProfile(settings.vehicleVisualModel),
    speedKmh = (snapshot.speedKmh ?: 0).toFloat().coerceAtLeast(0f),
    rpm = (snapshot.rpm ?: 0).toFloat().coerceAtLeast(0f),
    motionEnabled = settings.digitalV2MotionEnabled,
    calibrationVisible = calibrationVisible
)
