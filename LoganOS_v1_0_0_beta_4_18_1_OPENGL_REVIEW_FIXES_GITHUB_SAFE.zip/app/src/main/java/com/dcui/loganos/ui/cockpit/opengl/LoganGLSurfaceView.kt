package com.dcui.loganos.ui.cockpit.opengl

import android.content.Context
import android.opengl.GLSurfaceView
import java.util.concurrent.atomic.AtomicBoolean

/** Small lifecycle-safe host around GLSurfaceView. */
internal class LoganGLSurfaceView(context: Context) : GLSurfaceView(context) {
    private val sceneRenderer = DigitalV2Renderer(context.applicationContext)
    private val resumed = AtomicBoolean(false)
    private var released = false

    init {
        setEGLContextClientVersion(2)
        preserveEGLContextOnPause = true
        setRenderer(sceneRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
    }

    fun submitState(state: DigitalV2RenderState) {
        if (released) return
        sceneRenderer.submitState(state)
        val shouldAnimate = state.motionEnabled && state.speedKmh >= 2f
        val targetRenderMode = if (shouldAnimate) {
            RENDERMODE_CONTINUOUSLY
        } else {
            RENDERMODE_WHEN_DIRTY
        }
        if (renderMode != targetRenderMode) {
            renderMode = targetRenderMode
        }
        requestRender()
    }

    fun resumeRenderer() {
        if (!released && resumed.compareAndSet(false, true)) {
            onResume()
            requestRender()
        }
    }

    fun pauseRenderer() {
        if (!released && resumed.compareAndSet(true, false)) {
            onPause()
        }
    }

    fun releaseRenderer() {
        if (released) return
        released = true
        // Queue cleanup while the render thread is still alive. EGL context
        // loss also releases driver resources if the queued call cannot run.
        queueEvent { sceneRenderer.releaseGlResources() }
        requestRender()
        if (resumed.compareAndSet(true, false)) {
            onPause()
        }
    }
}
