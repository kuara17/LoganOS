package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.PI

/**
 * Stable animation phases derived from an unbounded Double-precision distance.
 * Each visual subsystem wraps only at its own exact repeat length, preventing
 * discontinuities such as the previous 10,000 m outer wrap.
 */
internal fun positiveModulo(value: Double, modulus: Double): Double {
    if (modulus <= 0.0 || !value.isFinite() || !modulus.isFinite()) return 0.0
    val result = value % modulus
    return if (result < 0.0) result + modulus else result
}

internal fun roadPatternPhaseMeters(
    totalDistanceMeters: Double,
    repeatLengthMeters: Float
): Float = positiveModulo(
    totalDistanceMeters,
    repeatLengthMeters.toDouble()
).toFloat()

internal fun windTravelPhaseMeters(
    totalDistanceMeters: Double,
    cycleLengthMeters: Float
): Float = positiveModulo(
    totalDistanceMeters * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER,
    cycleLengthMeters.toDouble()
).toFloat()

internal fun windPulsePhaseRadians(totalDistanceMeters: Double): Float = positiveModulo(
    totalDistanceMeters * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER * DIGITAL_V2_WIND_PULSE_RADIANS_PER_METER,
    PI * 2.0
).toFloat()

internal const val DIGITAL_V2_WIND_TRAVEL_MULTIPLIER = 1.35
internal const val DIGITAL_V2_WIND_PULSE_RADIANS_PER_METER = 0.08
