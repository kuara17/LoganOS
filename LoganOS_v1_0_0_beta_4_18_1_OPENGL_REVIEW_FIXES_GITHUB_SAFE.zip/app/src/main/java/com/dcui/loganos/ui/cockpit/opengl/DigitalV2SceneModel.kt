package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.max
import kotlin.math.min

/**
 * Renderer-independent geometry for Digital V2.
 *
 * All positions are expressed in the fixed logical stage (1080 x 1320) through
 * normalized ratios. Distances are world metres measured forward from the
 * camera. The OpenGL renderer is only one consumer of this model.
 */
internal const val DIGITAL_V2_LOGICAL_WIDTH = 1080f
internal const val DIGITAL_V2_LOGICAL_HEIGHT = 1320f
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO =
    DIGITAL_V2_LOGICAL_WIDTH / DIGITAL_V2_LOGICAL_HEIGHT


internal data class DigitalV2PixelViewport(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

/**
 * Fits the fixed 1080x1320 logical stage into any Surface without stretching.
 * Unused pixels become centered letterbox/pillarbox margins.
 */
internal fun calculateDigitalV2Viewport(surfaceWidth: Int, surfaceHeight: Int): DigitalV2PixelViewport {
    require(surfaceWidth > 0 && surfaceHeight > 0)
    val surfaceAspect = surfaceWidth.toFloat() / surfaceHeight.toFloat()
    return if (surfaceAspect > DIGITAL_V2_STAGE_ASPECT_RATIO) {
        val viewportHeight = surfaceHeight
        val viewportWidth = (viewportHeight * DIGITAL_V2_STAGE_ASPECT_RATIO).toInt().coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = (surfaceWidth - viewportWidth) / 2,
            y = 0,
            width = viewportWidth,
            height = viewportHeight
        )
    } else {
        val viewportWidth = surfaceWidth
        val viewportHeight = (viewportWidth / DIGITAL_V2_STAGE_ASPECT_RATIO).toInt().coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = 0,
            y = (surfaceHeight - viewportHeight) / 2,
            width = viewportWidth,
            height = viewportHeight
        )
    }
}

internal enum class DigitalV2SceneKey {
    MountainLake,
    CityDay,
    CityNight,
    SnowRoad
}

internal data class ScenePoint(
    val xRatio: Float,
    val yRatio: Float
)

internal data class GlColor(
    val red: Float,
    val green: Float,
    val blue: Float,
    val alpha: Float
) {
    init {
        require(red in 0f..1f)
        require(green in 0f..1f)
        require(blue in 0f..1f)
        require(alpha in 0f..1f)
    }
}


internal data class RoadProjectionSample(
    /** Metres forward from the camera. Zero is below/at the near edge. */
    val distanceMeters: Float,
    val centerXRatio: Float,
    val screenYRatio: Float,
    val halfWidthRatio: Float
)

internal data class ProjectedRoadPoint(
    val xRatio: Float,
    val yRatio: Float,
    val halfWidthRatio: Float
)

internal data class RoadMarkingPattern(
    val dashLengthMeters: Float = 3f,
    val gapLengthMeters: Float = 6f,
    val centerLineWidthMeters: Float = 0.15f,
    val edgeLineWidthMeters: Float = 0.13f
) {
    val repeatLengthMeters: Float
        get() = dashLengthMeters + gapLengthMeters

    init {
        require(dashLengthMeters > 0f)
        require(gapLengthMeters > 0f)
        require(centerLineWidthMeters > 0f)
        require(edgeLineWidthMeters > 0f)
    }
}

internal data class RoadProjectionProfile(
    val samples: List<RoadProjectionSample>,
    /** Half-width of the calibrated road in world metres. */
    val roadHalfWidthMeters: Float = 5.5f,
    val markings: RoadMarkingPattern = RoadMarkingPattern(),
    val centerLineColor: GlColor = GlColor(1f, 0.82f, 0.20f, 0.96f),
    val edgeLineColor: GlColor = GlColor(0.98f, 0.99f, 1f, 0.62f),
    val drawEdgeLines: Boolean = true
) {
    val maxDistanceMeters: Float
        get() = samples.last().distanceMeters

    init {
        require(samples.size >= 2)
        require(roadHalfWidthMeters > 0f)
        require(samples.first().distanceMeters == 0f)
        require(samples.zipWithNext().all { (a, b) -> b.distanceMeters > a.distanceMeters })
        require(samples.all {
            it.centerXRatio in -0.25f..1.25f &&
                it.screenYRatio in -0.25f..1.25f &&
                it.halfWidthRatio > 0f
        })
    }

    /** Projects one road-space point into the normalized logical stage. */
    fun project(distanceMeters: Float, lateralMeters: Float = 0f): ProjectedRoadPoint {
        val distance = distanceMeters.coerceIn(0f, maxDistanceMeters)
        val upperIndex = samples.indexOfFirst { it.distanceMeters >= distance }
            .let { if (it < 0) samples.lastIndex else it }
        if (upperIndex == 0) {
            val sample = samples.first()
            return sample.toProjected(lateralMeters)
        }

        val lower = samples[upperIndex - 1]
        val upper = samples[upperIndex]
        val span = max(0.0001f, upper.distanceMeters - lower.distanceMeters)
        val rawT = ((distance - lower.distanceMeters) / span).coerceIn(0f, 1f)
        // Smooth interpolation prevents visible direction changes at calibration samples.
        val t = rawT * rawT * (3f - 2f * rawT)
        val center = lerp(lower.centerXRatio, upper.centerXRatio, t)
        val y = lerp(lower.screenYRatio, upper.screenYRatio, t)
        val halfWidth = lerp(lower.halfWidthRatio, upper.halfWidthRatio, t)
        val lateralRatio = lateralMeters / roadHalfWidthMeters
        return ProjectedRoadPoint(
            xRatio = center + halfWidth * lateralRatio,
            yRatio = y,
            halfWidthRatio = halfWidth
        )
    }

    private fun RoadProjectionSample.toProjected(lateralMeters: Float): ProjectedRoadPoint {
        val lateralRatio = lateralMeters / roadHalfWidthMeters
        return ProjectedRoadPoint(
            xRatio = centerXRatio + halfWidthRatio * lateralRatio,
            yRatio = screenYRatio,
            halfWidthRatio = halfWidthRatio
        )
    }
}

internal data class VehicleAssetProfile(
    val textureAspectHeightOverWidth: Float,
    /** Width of non-transparent vehicle pixels divided by full texture width. */
    val visibleWidthRatioInTexture: Float,
    /** Rear tyre contact Y divided by full texture height. */
    val contactYRatioInTexture: Float
) {
    init {
        require(textureAspectHeightOverWidth > 0f)
        require(visibleWidthRatioInTexture in 0.5f..1f)
        require(contactYRatioInTexture in 0.5f..1f)
    }
}

internal data class VehicleScenePose(
    /** Camera-follow distance used only to obtain the road/lane anchor. */
    val anchorDistanceMeters: Float,
    /** Positive is the right side of the road. */
    val lateralMeters: Float,
    /** Visible body width relative to the logical stage width. */
    val visibleWidthRatio: Float,
    val headingDegrees: Float,
    val shadowWidthRatio: Float,
    val shadowAlpha: Float,
    val colorMultiplier: GlColor = GlColor(1f, 1f, 1f, 1f)
) {
    init {
        require(anchorDistanceMeters >= 0f)
        require(visibleWidthRatio in 0.12f..0.32f)
        require(shadowWidthRatio in 0.10f..0.35f)
        require(shadowAlpha in 0f..1f)
    }
}

internal data class WindProfile(
    val enabled: Boolean = true,
    val shoulderOffsetMeters: Float = 0.65f,
    val particleCountPerSide: Int = 6,
    val maxAlpha: Float = 0.20f
) {
    init {
        require(shoulderOffsetMeters >= 0f)
        require(particleCountPerSide in 0..16)
        require(maxAlpha in 0f..0.6f)
    }
}

internal data class DigitalV2SceneModel(
    val key: DigitalV2SceneKey,
    val road: RoadProjectionProfile,
    val vehiclePose: VehicleScenePose,
    val wind: WindProfile
)

internal object DigitalV2SceneModels {
    val MountainLake = DigitalV2SceneModel(
        key = DigitalV2SceneKey.MountainLake,
        road = RoadProjectionProfile(
            samples = listOf(
                RoadProjectionSample(0f, 0.485f, 1.035f, 0.575f),
                RoadProjectionSample(4f, 0.490f, 0.875f, 0.490f),
                RoadProjectionSample(8f, 0.495f, 0.760f, 0.405f),
                RoadProjectionSample(14f, 0.503f, 0.665f, 0.300f),
                RoadProjectionSample(24f, 0.512f, 0.585f, 0.205f),
                RoadProjectionSample(40f, 0.515f, 0.520f, 0.115f),
                RoadProjectionSample(65f, 0.510f, 0.475f, 0.055f),
                RoadProjectionSample(95f, 0.505f, 0.445f, 0.020f)
            ),
            drawEdgeLines = false
        ),
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.8f,
            lateralMeters = 2.20f,
            visibleWidthRatio = 0.220f,
            headingDegrees = 0.6f,
            shadowWidthRatio = 0.205f,
            shadowAlpha = 0.58f,
            colorMultiplier = GlColor(0.97f, 0.99f, 1f, 1f)
        ),
        wind = WindProfile(maxAlpha = 0.14f)
    )

    val CityDay = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityDay,
        road = RoadProjectionProfile(
            samples = listOf(
                RoadProjectionSample(0f, 0.500f, 1.035f, 0.555f),
                RoadProjectionSample(4f, 0.500f, 0.875f, 0.475f),
                RoadProjectionSample(8f, 0.500f, 0.755f, 0.395f),
                RoadProjectionSample(14f, 0.500f, 0.655f, 0.300f),
                RoadProjectionSample(24f, 0.500f, 0.570f, 0.205f),
                RoadProjectionSample(40f, 0.500f, 0.505f, 0.115f),
                RoadProjectionSample(65f, 0.500f, 0.462f, 0.050f),
                RoadProjectionSample(95f, 0.500f, 0.438f, 0.017f)
            ),
            drawEdgeLines = false
        ),
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.8f,
            lateralMeters = 2.15f,
            visibleWidthRatio = 0.215f,
            headingDegrees = 0f,
            shadowWidthRatio = 0.200f,
            shadowAlpha = 0.53f
        ),
        wind = WindProfile(maxAlpha = 0.12f)
    )

    val CityNight = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityNight,
        road = CityDay.road.copy(
            centerLineColor = GlColor(1f, 0.83f, 0.22f, 0.98f),
            edgeLineColor = GlColor(0.92f, 0.94f, 1f, 0.50f)
        ),
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.8f,
            lateralMeters = 2.15f,
            visibleWidthRatio = 0.215f,
            headingDegrees = 0f,
            shadowWidthRatio = 0.200f,
            shadowAlpha = 0.46f,
            colorMultiplier = GlColor(0.82f, 0.78f, 0.73f, 1f)
        ),
        wind = WindProfile(maxAlpha = 0.16f)
    )

    val SnowRoad = DigitalV2SceneModel(
        key = DigitalV2SceneKey.SnowRoad,
        road = RoadProjectionProfile(
            samples = listOf(
                RoadProjectionSample(0f, 0.500f, 1.035f, 0.560f),
                RoadProjectionSample(4f, 0.502f, 0.875f, 0.480f),
                RoadProjectionSample(8f, 0.505f, 0.760f, 0.395f),
                RoadProjectionSample(14f, 0.508f, 0.665f, 0.300f),
                RoadProjectionSample(24f, 0.510f, 0.585f, 0.205f),
                RoadProjectionSample(40f, 0.507f, 0.525f, 0.115f),
                RoadProjectionSample(65f, 0.500f, 0.485f, 0.052f),
                RoadProjectionSample(95f, 0.495f, 0.458f, 0.018f)
            ),
            drawEdgeLines = false
        ),
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.8f,
            lateralMeters = 2.20f,
            visibleWidthRatio = 0.220f,
            headingDegrees = -0.35f,
            shadowWidthRatio = 0.205f,
            shadowAlpha = 0.48f,
            colorMultiplier = GlColor(0.93f, 0.98f, 1f, 1f)
        ),
        wind = WindProfile(maxAlpha = 0.15f)
    )

    fun forKey(key: DigitalV2SceneKey): DigitalV2SceneModel = when (key) {
        DigitalV2SceneKey.MountainLake -> MountainLake
        DigitalV2SceneKey.CityDay -> CityDay
        DigitalV2SceneKey.CityNight -> CityNight
        DigitalV2SceneKey.SnowRoad -> SnowRoad
    }
}

private fun lerp(start: Float, end: Float, t: Float): Float =
    start + (end - start) * min(1f, max(0f, t))
