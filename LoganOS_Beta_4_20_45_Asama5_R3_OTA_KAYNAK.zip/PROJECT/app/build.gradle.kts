plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val releaseKeystorePath = providers.environmentVariable("LOGANOS_KEYSTORE_PATH").orNull
val releaseStorePassword = providers.environmentVariable("LOGANOS_STORE_PASSWORD").orNull
val releaseKeyAlias = providers.environmentVariable("LOGANOS_KEY_ALIAS").orNull
val releaseKeyPassword = providers.environmentVariable("LOGANOS_KEY_PASSWORD").orNull

val explicitUpdateRepository = providers.environmentVariable("LOGANOS_UPDATE_REPOSITORY").orNull?.takeIf { it.isNotBlank() }
    ?: providers.gradleProperty("LOGANOS_UPDATE_REPOSITORY").orNull?.takeIf { it.isNotBlank() }
val updateRepository = explicitUpdateRepository
    ?: providers.environmentVariable("GITHUB_REPOSITORY").orNull?.takeIf { it.isNotBlank() }
    ?: ""

fun String.asBuildConfigString(): String =
    "\"" + replace("\\", "\\\\").replace("\"", "\\\"") + "\""

val releaseSigningAvailable = listOf(
    releaseKeystorePath,
    releaseStorePassword,
    releaseKeyAlias,
    releaseKeyPassword
).all { !it.isNullOrBlank() }

// Never allow a release APK to be produced without the production signing material
// and an explicitly configured update repository. Debug builds remain unaffected.
gradle.taskGraph.whenReady {
    val releasePackagingRequested = allTasks.any { task ->
        task.name in setOf("assembleRelease", "bundleRelease", "packageRelease", "installRelease")
    }
    if (releasePackagingRequested) {
        if (!releaseSigningAvailable) {
            throw GradleException(
                "Release signing is not configured. Set LOGANOS_KEYSTORE_PATH, " +
                    "LOGANOS_STORE_PASSWORD, LOGANOS_KEY_ALIAS and LOGANOS_KEY_PASSWORD."
            )
        }
        if (explicitUpdateRepository.isNullOrBlank()) {
            throw GradleException(
                "LOGANOS_UPDATE_REPOSITORY must be explicitly set for release builds."
            )
        }
    }
}

android {
    namespace = "com.dcui.loganos"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.dcui.loganos"
        minSdk = 26
        targetSdk = 35
        versionCode = 100000844
        versionName = "1.0.0-beta.4.20.45"
        buildConfigField("String", "UPDATE_REPOSITORY", updateRepository.asBuildConfigString())
    }

    signingConfigs {
        if (releaseSigningAvailable) {
            create("release") {
                storeFile = file(requireNotNull(releaseKeystorePath))
                storePassword = requireNotNull(releaseStorePassword)
                keyAlias = requireNotNull(releaseKeyAlias)
                keyPassword = requireNotNull(releaseKeyPassword)
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
            signingConfigs.findByName("release")?.let { signingConfig = it }
        }
        debug {
            applicationIdSuffix = ".debug"
            // Debug builds always use the Android debug key. Production signing
            // material is available only to the protected release job.
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    testOptions {
        unitTests {
            // TripComputer reads android.os.SystemClock (default clock, trip token).
            // Unit tests pass explicit timestamps; this only lets the stub return defaults.
            isReturnDefaultValues = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    // Coroutines are used directly by app and JVM test sources; do not rely on
    // lifecycle-runtime-ktx to provide them transitively.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation(platform("androidx.compose:compose-bom:2024.11.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")
    testImplementation("junit:junit:4.13.2")
}
