# LoganOS 4.20.45 — A5 Build & Validation

## Release identity

- Application ID: `com.dcui.loganos`
- Version name: `1.0.0-beta.4.20.45`
- Version code: `100000844`
- Database version: `7`
- JDK: `17`
- Android Gradle Plugin: `8.7.3`
- Gradle: `8.9`
- Kotlin / Compose compiler plugin: `2.0.21`
- compileSdk / targetSdk: `35`
- minSdk: `26`

## Workflow ownership and source-package boundaries

This source package intentionally contains `.github/workflows/android-ci.yml` only.

- `android-ci.yml` is the debug/CI workflow. It provisions JDK 17 and Gradle 8.9, generates the official Gradle Wrapper with the pinned Gradle distribution SHA-256, runs `:app:testDebugUnitTest` and `:app:assembleDebug` through `./gradlew`, and uploads the generated Wrapper files and debug APK as artifacts.
- `.github/workflows/android-release.yml` is intentionally absent. It was removed to avoid maintaining a second, redundant release pipeline. Do not recreate it.
- Production signing and OTA publication use the existing repository workflow `.github/workflows/publish-secure-release.yml`. That workflow lives in the GitHub repository and is intentionally not copied into this source ZIP. Its current contents and run history must be checked in GitHub when validating a release; this ZIP alone cannot prove the live workflow configuration.

The user reports that version 4.20.45 was successfully published through the existing GitHub OTA workflow and installed on the phone. For an auditable release record, retain the GitHub Actions run URL, release/tag URL, APK asset name, APK SHA-256, signer certificate output, and any attestation evidence. Do not delete or overwrite the already-published 4.20.45 release as part of validation.

## Gradle Wrapper and debug validation

The source ZIP intentionally does not include Gradle Wrapper scripts or the Wrapper JAR. The CI workflow provisions a trusted Gradle 8.9 installation and generates the Wrapper using the official binary distribution checksum:

```bash
gradle --no-daemon wrapper --gradle-version 8.9 --distribution-type bin --gradle-distribution-sha256-sum=d725d707bfabd4dfdc958c624003b3c80accc03f7037b5122c4b1d0ef15cecab
```

The checksum is pinned in `gradle-wrapper.properties` and is enforced by the Wrapper when it downloads the Gradle distribution. Do not hand-create or substitute an unverified Wrapper JAR.

After the Wrapper has been generated, the CI build commands are:

```bash
./gradlew --no-daemon :app:testDebugUnitTest
./gradlew --no-daemon :app:assembleDebug
```

The `Android CI` workflow uploads the generated Wrapper artifact and the debug APK. The existence of this workflow or its YAML file is not evidence that a run succeeded; record the actual run URL and job results.

## Release signing and OTA validation

The release build requires these environment values:

- `LOGANOS_KEYSTORE_PATH`
- `LOGANOS_STORE_PASSWORD`
- `LOGANOS_KEY_ALIAS`
- `LOGANOS_KEY_PASSWORD`
- `LOGANOS_UPDATE_REPOSITORY` (environment variable or Gradle project property)

The corresponding GitHub secrets used by the existing publishing workflow include `LOGANOS_KEYSTORE_BASE64`, `LOGANOS_STORE_PASSWORD`, `LOGANOS_KEY_ALIAS`, and `LOGANOS_KEY_PASSWORD`. The keystore path is a temporary runner file and must never be committed.

`LOGANOS_UPDATE_REPOSITORY` may be configured as an optional GitHub Actions repository variable override. The existing publishing workflow must resolve an empty/unset override to the current `github.repository` and pass that resolved value to Gradle as `LOGANOS_UPDATE_REPOSITORY`. This matters because the Gradle release guard requires an explicit environment variable or Gradle property for release packaging; the `GITHUB_REPOSITORY` fallback used to populate `BuildConfig.UPDATE_REPOSITORY` does not by itself satisfy that guard.

The live `.github/workflows/publish-secure-release.yml` must be inspected in GitHub before changing release configuration. Verify, using the actual workflow and run evidence, that it:

- safely decodes the keystore secret to a temporary file and passes the path to the Gradle step;
- passes the resolved update repository to the release build;
- does not expose secrets in logs or uploaded artifacts;
- validates the produced APK's package, version name/code and signing certificate;
- calculates and publishes the APK SHA-256 alongside the correct OTA metadata;
- preserves the already-published release/tag until the new build and validations have succeeded;
- reports failures and uploads diagnostics without making a successful build fail because of a duplicate diagnostic artifact name on a workflow rerun.

Do not create another release workflow and do not trigger or republish 4.20.45 merely to perform a read-only audit.

For a locally available release APK, the expected verification commands are:

```bash
$ANDROID_HOME/build-tools/35.0.0/apksigner verify --verbose --print-certs path/to/LoganOS-release.apk
sha256sum path/to/LoganOS-release.apk
```

Record the actual APK path, package/version metadata, signer certificate digest and SHA-256. Do not report these checks as passed without command output.

## Device acceptance gates still required

- API 26 and API 28: SAF folder selection, cancel, persisted permission, permission loss, and partial-file cleanup.
- API 29+: MediaStore export/delete regression.
- Real Android SQLite: only records actually included in a successful export are marked with `exported_at_ms`; write, ZIP, close, and destination failures must not mark records.
- Concurrent export, delete, retention, and clear-all behavior.
- OBD connected: perform a large bulk ZIP while pressing “Sürüşü şimdi bitir”; polling and gauges must remain responsive.
- Inject file-write and ZIP failures and verify database state after each failure.
- 2 GB head unit: test 500 trip + 500 test records; record peak heap, elapsed time, and OOM behavior.

## Prior A4 review notes carried into A5

- The narrow export-contract mutation coverage still needs independent review; do not treat the existing contract test as exhaustive without mutation evidence.
- The technical-session export path now isolates a post-save history refresh exception and logs it separately, so a refresh failure cannot overwrite the already-published successful export message with a false export failure. This is a source-level correction; Android runtime behavior remains part of device validation.
- Developer-test completion paths still await the shared history-retention gate in some flows. Review this as a responsiveness note and change it only if a reproducible user-visible stall or correctness issue is demonstrated.

## A5 verification ledger

Keep evidence separate by verification type. Do not treat a source inspection, a local Kotlin harness, or a mocked workflow step as a real Gradle/JUnit/GitHub/device test.

| Gate | Evidence to record | Initial status for this source package |
|---|---|---|
| ZIP integrity and source identity | SHA-256, `unzip -t`, file inventory | PASS (checked during preparation) |
| Version and toolchain identity | Gradle/Android configuration values | PASS (source inspection) |
| Pure Kotlin cooldown policy | Compile/run output for the exact production class and test scenarios | Local harness only; not a Gradle/JUnit run |
| Android CI | GitHub Actions run URL, test job, debug APK artifact | NOT VERIFIED here |
| Signed release / OTA | Existing GitHub workflow, run URL, APK, signer, SHA-256, metadata | User reports successful 4.20.45 OTA; independent artifact verification pending |
| API 26/28 SAF and API 29+ MediaStore | Device/API test evidence | NOT RUN here |
| Android SQLite export failure/concurrency tests | Device or instrumentation evidence | NOT RUN here |
| 2 GB head-unit bulk ZIP | Peak heap, elapsed time, OOM and UI responsiveness | NOT RUN here |

A5 is complete only when the required CI/release evidence and device acceptance gates have been reviewed and any confirmed blocker has been resolved. Never convert `NOT RUN` or `NOT VERIFIED` into `PASS` based only on source code.
