# LoganOS

**OEM Digital Cockpit • Powered by DC UI**

Version: **1.0.0-beta.3.3-fix3**

## Beta 3.3 Fix 3 Focus

This fix focuses on closing the visual gap between the approved mockup and the APK: custom OEM-style cockpit icons, less rounded/premium cards, clearer portrait settings, and a better digital cockpit silhouette.

### Highlights

- Custom OEM-style cockpit icons replace the Material-looking symbols.
- Average and instant fuel icons are now clearly different.
- A/C, radiator fan and hararet icons were redrawn for a dashboard/OEM look.
- Cards use smaller radius and subtle elevation for a less toy-like feel.
- The red car in the gauge is now drawn as a sedan silhouette.
- Faster 21CC quick-status polling for A/C and radiator fan state.
- A/C and fan state can update before the slower technical packets complete.
- Log creation now asks for confirmation from the OBD panel.
- Last log / all log deletion actions require confirmation.
- OEM-style drawn metric icons added to cockpit and technical cards.
- Motor temperature + radiator fan card alignment improved.
- Climate card remains separate and clearer.
- Fuel Truth stays in Technical as a test/debug panel.
- Gauge style labels removed from the main cockpit gauge center.
- Setup gauge previews improved; preview speed value reduced.
- Dacia/Renault brand selection card indicator made more consistent.

## Status

Bluetooth, ELM init, KWP Fast Init and raw ECU response are working in Beta testing.
Trip Computer / Smart Trip persistence is planned for a later beta after live-data validation.
