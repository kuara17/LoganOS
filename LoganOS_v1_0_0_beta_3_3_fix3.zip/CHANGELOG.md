# Changelog

## v1.0.0-beta.3.3-fix3 - OEM Icon and Portrait UI Correction

### Fixed

- Reworked cockpit metric icons with custom OEM-style Canvas drawings instead of generic Material-looking symbols.
- Average and instant fuel consumption icons are now visually distinct and swapped into the approved direction.
- Reworked A/C snowflake, radiator fan and hararet/soğutma suyu icons for a more dashboard-like look.
- Reduced cockpit card corner radius and added subtle elevation for a less toy-like, more automotive card style.
- Tuned OEM green to a deeper, less neon tone.
- Improved portrait cockpit sizing so the speed gauge uses its card area better and lower cards are less likely to be clipped.
- Replaced the toy-like red car drawing with a sedan silhouette used in digital/sport gauge art.
- Reorganized OBD connection/log controls into clearer OBD and LOG groups with explicit button labels.
- Optimized portrait Settings compact left menu with OEM-style icons and updated fix3 version labels.

### Notes

- This is a Beta 3.3 fix package, not the Beta 3.4 cockpit-layout release.
- User-selectable cockpit layouts/cards remain planned for Beta 3.4.

## v1.0.0-beta.3.3 - Live Data Refresh + Cockpit UI Polish

### Fixed

- Reduced A/C and radiator fan display delay by adding a fast 21CC read before the slower data packets.
- Log Kaydet now opens a confirmation dialog instead of saving immediately.
- Son Logu Sil and Tüm Logları Sil buttons now exist in the OBD panel and require confirmation.
- Main cockpit no longer shows Fuel Truth as a user-facing card.
- Motor Sıcaklığı / Radyatör Fanı typography and alignment were refined.
- Klima card remains separate and visually clearer.
- Average consumption unit changed to `L/100 km`.
- Sürüş Maliyeti now shows `-- ₺` when no price/cost is available.
- Gauge style names such as SPORT / CLASSIC / RS are no longer shown inside the main speed gauge.
- Setup gauge preview speed value reduced so the design is more visible.
- Dacia/Renault brand card selection icon language made consistent.

### Added

- OEM-style drawn metric icons for average fuel, instant fuel, distance, cost, temperature, fan, A/C, RPM, time, battery, speed and injection.
- 21CC_FAST entries in logs to help diagnose A/C and radiator fan response time.
- Faster UI update path for A/C / radiator fan state.

### Notes

- Beta 3.3 is not the full Trip Computer release.
- User-selectable cockpit data and ready-made cockpit layouts are planned for Beta 3.4.
- Smart Trip, stored trip history, and full Fuel Truth trip computer remain planned for Beta 4.
