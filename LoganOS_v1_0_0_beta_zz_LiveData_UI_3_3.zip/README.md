# LoganOS

**OEM Digital Cockpit • Powered by DC UI**

Version: **1.0.0-beta.3.3**

## Beta 3.3 Focus

This build focuses on live data refresh, cockpit visual polish, log confirmation safety, and clearer OEM-style metric cards.

### Highlights

- Faster 21CC quick-status polling for A/C and radiator fan state.
- A/C and fan state can update before the slower technical packets complete.
- Log creation now asks for confirmation from the OBD panel.
- Last log / all log deletion actions require confirmation.
- OEM-style drawn metric icons added to cockpit and technical cards.
- Motor temperature + radiator fan card alignment improved.
- Climate card remains separate and clearer.
- Fuel Truth stays in Technical as a test/debug panel.
- Gauge style labels removed from the main cockpit gauge center.
- Setup gauge previews improved; preview speed value reduced.
- Dacia/Renault brand selection card indicator made more consistent.

## Status

Bluetooth, ELM init, KWP Fast Init and raw ECU response are working in Beta testing.
Trip Computer / Smart Trip persistence is planned for a later beta after live-data validation.
