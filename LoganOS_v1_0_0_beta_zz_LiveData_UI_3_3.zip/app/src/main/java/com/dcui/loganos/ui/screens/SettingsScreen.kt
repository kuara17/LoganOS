package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.theme.LoganPalette

enum class SettingsCategory(val title: String, val desc: String) {
    AppearanceCockpit("Görünüm & Kokpit", "Tema, vurgu rengi, gösterge stili"),
    DriveFuel("Sürüş & Yakıt", "Smart Trip, yakıt fiyatı, tüketim"),
    VehicleMaintenance("Araç & Bakım", "Profil, kilometre, bakım aralıkları"),
    ConnectionData("Bağlantı & Veri", "Bluetooth, OBD, log, yedek"),
    DeveloperAbout("Geliştirici & Hakkında", "Demo modu, teknik notlar, lisans")
}

private sealed class SettingsDialog {
    data class Options(val title: String, val options: List<String>, val onSelect: (String) -> Unit) : SettingsDialog()
    data class TextInput(val title: String, val initial: String, val hint: String, val onSave: (String) -> Unit) : SettingsDialog()
    data class Info(val title: String, val message: String) : SettingsDialog()
    data class Confirm(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit) : SettingsDialog()
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit
) {
    var selected by remember { mutableStateOf(SettingsCategory.AppearanceCockpit) }
    var portraitDetail by remember { mutableStateOf<SettingsCategory?>(null) }
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }

    BackHandler(enabled = portraitDetail != null) { portraitDetail = null }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSideMenu(palette, selected, onSelect = { selected = it }, modifier = Modifier.width(220.dp).fillMaxHeight())
                SettingsContent(
                    palette = palette,
                    category = selected,
                    settings = settings,
                    obdState = obdState,
                    onSettingsChange = onSettingsChange,
                    onResetSetup = onResetSetup,
                    onRefreshObdDevices = onRefreshObdDevices,
                    onSelectObdDevice = onSelectObdDevice,
                    onConnectObd = onConnectObd,
                    onDisconnectObd = onDisconnectObd,
                    onSaveObdLog = onSaveObdLog,
                    onShareObdLog = onShareObdLog,
                    onClearLastObdLog = onClearLastObdLog,
                    onClearAllObdLogs = onClearAllObdLogs,
                    openDialog = { dialog = it },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        } else {
            AnimatedContent(
                targetState = portraitDetail,
                transitionSpec = {
                    (slideInHorizontally(animationSpec = tween(210)) { it / 5 } + fadeIn(animationSpec = tween(210))) togetherWith
                        (slideOutHorizontally(animationSpec = tween(210)) { -it / 5 } + fadeOut(animationSpec = tween(210)))
                },
                label = "settingsNavigation"
            ) { detail ->
                if (detail == null) {
                    SettingsCategoryList(palette = palette, onOpen = { portraitDetail = it })
                } else {
                    Column(Modifier.fillMaxSize()) {
                        Text(
                            "‹ Ayarlar",
                            color = palette.textSecondary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { portraitDetail = null }
                                .padding(vertical = 6.dp)
                        )
                        SettingsContent(
                            palette = palette,
                            category = detail,
                            settings = settings,
                            obdState = obdState,
                            onSettingsChange = onSettingsChange,
                            onResetSetup = onResetSetup,
                            onRefreshObdDevices = onRefreshObdDevices,
                            onSelectObdDevice = onSelectObdDevice,
                            onConnectObd = onConnectObd,
                            onDisconnectObd = onDisconnectObd,
                            onSaveObdLog = onSaveObdLog,
                            onShareObdLog = onShareObdLog,
                            onClearLastObdLog = onClearLastObdLog,
                            onClearAllObdLogs = onClearAllObdLogs,
                            openDialog = { dialog = it },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }

    dialog?.let { current ->
        when (current) {
            is SettingsDialog.Options -> OptionDialog(palette, current) { dialog = null }
            is SettingsDialog.TextInput -> TextInputDialog(palette, current) { dialog = null }
            is SettingsDialog.Info -> InfoDialog(palette, current) { dialog = null }
            is SettingsDialog.Confirm -> ConfirmDialog(palette, current) { dialog = null }
        }
    }
}

@Composable
private fun SettingsCategoryList(palette: LoganPalette, onOpen: (SettingsCategory) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("Ayarlar", color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("LoganOS v1.0.0-beta.3.3", color = palette.textSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }
        SettingsCategory.entries.forEach { cat ->
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth(), onClick = { onOpen(cat) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(cat.title, color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text(cat.desc, color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text("›", color = palette.textSecondary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSideMenu(palette: LoganPalette, selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(modifier = modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("v1.0.0-beta.3.3", color = palette.textSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (active) palette.accent.copy(alpha = .12f) else palette.surface)
                    .clickable { onSelect(cat) }
                    .padding(12.dp)
            ) {
                Text(cat.title, color = if (active) palette.accent else palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(cat.desc, color = palette.textSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsContent(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    modifier: Modifier
) {
    OemCard(palette, modifier = modifier.fillMaxWidth()) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            item { Text(category.title, color = palette.accent, fontSize = 23.sp, fontWeight = FontWeight.Black) }
            item { Spacer(Modifier.height(6.dp)) }
            when (category) {
                SettingsCategory.AppearanceCockpit -> {
                    item { SettingsRow(palette, "Koyu Tema", "OEM Dark görünümü", trailingSwitch = settings.darkMode, onSwitch = { onSettingsChange(settings.copy(darkMode = it)) }) }
                    item { SettingsRow(palette, "Vurgu Rengi", "Tüm LOGANOS vurgu rengi", settings.accentColor.label, onClick = { openDialog(SettingsDialog.Options("Vurgu Rengi", AccentColor.entries.map { it.label }) { label -> AccentColor.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(accentColor = it)) } }) }) }
                    item { SettingsRow(palette, "Gösterge Stili", "Digital, Sport, Classic OEM, Minimal, RS", settings.gaugeStyle.label, onClick = { openDialog(SettingsDialog.Options("Gösterge Stili", GaugeStyle.entries.map { it.label }) { label -> GaugeStyle.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(gaugeStyle = it)) } }) }) }
                    item { SettingsRow(palette, "Yazı Boyutu", "Beta 3: Normal / Büyük hazırlığı", "Normal", onClick = { openDialog(SettingsDialog.Info("Yazı Boyutu", "Bu seçenek Beta 3'te tepki verir; kalıcı ölçeklendirme Beta 4'te genişletilecek.")) }) }
                    item { SettingsRow(palette, "Kokpit Düzenleri", "Hazır şablonlar ve gösterilecek veriler", "Beta 3.4", onClick = { openDialog(SettingsDialog.Info("Kokpit Düzenleri", "Hazır kokpit şablonları ve Klima yerine Akü Voltajı gibi kart seçimi Beta 3.4 ile aktif edilecek.")) }) }
                }
                SettingsCategory.DriveFuel -> {
                    item { SettingsRow(palette, "Akıllı Yolculuk", "Motor stop sonrası aynı yolculuğu sürdürme", "${settings.smartTripMinutes} dk", onClick = { openDialog(SettingsDialog.Options("Akıllı Yolculuk Süresi", listOf("15", "30", "60", "120", "240")) { v -> onSettingsChange(settings.copy(smartTripMinutes = v.toIntOrNull() ?: 60)) }) }) }
                    item { SettingsRow(palette, "Yakıt Fiyatı", "Sürüş maliyeti için", settings.fuelPriceText.ifBlank { "Girilmedi" }, onClick = { openDialog(SettingsDialog.TextInput("Yakıt Fiyatı", settings.fuelPriceText, "Örn. 45.50") { v -> onSettingsChange(settings.copy(fuelPriceText = v)) }) }) }
                    item { SettingsRow(palette, "Sürüş sırasında ekranı açık tut", "Screen timeout engellenir", trailingSwitch = settings.keepScreenOn, onSwitch = { onSettingsChange(settings.copy(keepScreenOn = it)) }) }
                    item { SettingsRow(palette, "Arka planda yolculuğu sürdür", "Home tuşuyla çıkınca bağlantı/trip devam eder", trailingSwitch = settings.backgroundTripEnabled, onSwitch = { onSettingsChange(settings.copy(backgroundTripEnabled = it)) }) }
                    item { SettingsRow(palette, "Fuel Truth Kalibrasyonu", "Pompa litresi + uygulama değeri", "Beta 4", onClick = { openDialog(SettingsDialog.Info("Fuel Truth Kalibrasyonu", "Beta 3'te bağlantı ve ham injection testi yapılır. Kalibrasyon Beta 4'te aktif olacak.")) }) }
                }
                SettingsCategory.VehicleMaintenance -> {
                    item { SettingsRow(palette, "Araç", "${settings.brand.label} • ${settings.engine}", settings.vehicleModel, onClick = { openDialog(SettingsDialog.Info("Araç Profili", "Araç profilini değiştirmek için şimdilik Hakkında bölümünden kurulumu sıfırlayıp yeniden seçim yapabilirsin.")) }) }
                    item { SettingsRow(palette, "Kilometre Eşitleme", "Gösterge kilometresini kalibre et", settings.odometerText, onClick = { openDialog(SettingsDialog.TextInput("Kilometre Eşitleme", settings.odometerText, "Örn. 335420") { v -> onSettingsChange(settings.copy(odometerText = v)) }) }) }
                    item { SettingsRow(palette, "Motor Yağı", "Bakım aralığı", "${settings.oilServiceKm} km", onClick = { openDialog(SettingsDialog.TextInput("Motor Yağı Aralığı", settings.oilServiceKm, "Örn. 10000") { v -> onSettingsChange(settings.copy(oilServiceKm = v)) }) }) }
                    item { SettingsRow(palette, "Mazot Filtresi", "Bakım aralığı", "${settings.fuelFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput("Mazot Filtresi Aralığı", settings.fuelFilterKm, "Örn. 20000") { v -> onSettingsChange(settings.copy(fuelFilterKm = v)) }) }) }
                    item { SettingsRow(palette, "Hava Filtresi", "Bakım aralığı", "${settings.airFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput("Hava Filtresi Aralığı", settings.airFilterKm, "Örn. 10000") { v -> onSettingsChange(settings.copy(airFilterKm = v)) }) }) }
                    item { SettingsRow(palette, "Triger Seti", "Bakım aralığı", "${settings.timingBeltKm} km", onClick = { openDialog(SettingsDialog.TextInput("Triger Seti Aralığı", settings.timingBeltKm, "Örn. 60000") { v -> onSettingsChange(settings.copy(timingBeltKm = v)) }) }) }
                }
                SettingsCategory.ConnectionData -> {
                    item { ObdConnectionPanel(palette, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onClearLastObdLog, onClearAllObdLogs) }
                    item { SettingsRow(palette, "Destek Paketi Oluştur", "Loglar, cihaz bilgisi ve hata kayıtları", "Onay", onClick = { openDialog(SettingsDialog.Confirm("Destek Paketi Oluştur", "Mevcut OBD logu ve uygulama bilgileri Download/LoganOS klasörüne kaydedilecek.", "Oluştur") { onSaveObdLog() }) }) }
                    item { SettingsRow(palette, "Son Log Dosyasını Sil", "Yanlışlıkla oluşturulan son logu kaldır", "Onay", onClick = { openDialog(SettingsDialog.Confirm("Son Logu Sil", "Son kaydedilen LoganOS log dosyası silinsin mi?", "Sil") { onClearLastObdLog() }) }) }
                    item { SettingsRow(palette, "Tüm LoganOS Loglarını Temizle", "Download/LoganOS içindeki loganos_*.txt dosyaları", "Onay", onClick = { openDialog(SettingsDialog.Confirm("Tüm Logları Temizle", "Download/LoganOS klasöründeki LoganOS log dosyaları silinsin mi?", "Temizle") { onClearAllObdLogs() }) }) }
                    item { SettingsRow(palette, "Verileri Dışa Aktar", "SQLite yedeği ve raporlar", "Beta 4", onClick = { openDialog(SettingsDialog.Info("Verileri Dışa Aktar", "Bu özellik veritabanı/Room eklendikten sonra aktif olacak.")) }) }
                    item { SettingsRow(palette, "Tüm Verileri Sil", "Yolculuk, bakım, ayarlar", "Dikkat", onClick = { openDialog(SettingsDialog.Info("Tüm Verileri Sil", "Beta 3'te sadece kurulum sıfırlama Hakkında bölümünden yapılır.")) }) }
                }
                SettingsCategory.DeveloperAbout -> {
                    item { SettingsRow(palette, "Demo Modu", "Canlı sürüş simülasyonu", trailingSwitch = settings.demoMode, onSwitch = { onSettingsChange(settings.copy(demoMode = it)) }) }
                    item { SettingsRow(palette, "Geliştirici Modu", "Ham ECU verileri ve debug", "Teknik sekmede", onClick = { openDialog(SettingsDialog.Info("Geliştirici Modu", "Beta 3'te ham veriler Teknik sekmesinde görünür. CSV/Room logları Beta 4'te genişletilecek.")) }) }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                            Text("LOGANOS", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Version 1.0.0-beta.3.3", color = palette.accent, fontWeight = FontWeight.Bold)
                            Text("OEM Digital Cockpit • Powered by DC UI", color = palette.textSecondary)
                            Text("Fuel Truth Technology • Delphi DCM1.2 • KWP2000 Fast Init", color = palette.textSecondary)
                            Text("Ücretsiz, reklamsız ve açık kaynaklı proje.", color = palette.textSecondary)
                            Button(onClick = onResetSetup, colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) { Text("Kurulumu Sıfırla") }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun OptionDialog(palette: LoganPalette, dialog: SettingsDialog.Options, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                dialog.options.forEach { option ->
                    Text(
                        option,
                        color = palette.textPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { dialog.onSelect(option); onDismiss() }
                            .background(palette.surfaceVariant)
                            .padding(12.dp)
                    )
                }
            }
        }
    )
}

@Composable
private fun TextInputDialog(palette: LoganPalette, dialog: SettingsDialog.TextInput, onDismiss: () -> Unit) {
    var value by remember(dialog.title) { mutableStateOf(dialog.initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(dialog.hint) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { dialog.onSave(value); onDismiss() }) { Text("Kaydet") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@Composable
private fun InfoDialog(palette: LoganPalette, dialog: SettingsDialog.Info, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tamam") } }
    )
}

@Composable
private fun ConfirmDialog(palette: LoganPalette, dialog: SettingsDialog.Confirm, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = { dialog.onConfirm(); onDismiss() }) { Text(dialog.confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}
