package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.cos
import kotlin.math.sin

/**
 * OEM tarzı sade çizgi ikonları. Emoji/resim değil; kartlarda tutarlı, küçük dashboard sembolleri olarak çizilir.
 */
enum class CardIcon {
    FuelAverage,
    FuelInstant,
    Distance,
    Cost,
    Temperature,
    Fan,
    Ac,
    Rpm,
    Time,
    Battery,
    Speed,
    Injection
}

@Composable
fun OemCard(
    palette: LoganPalette,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier = modifier
            .clip(shape)
            .background(palette.surface)
            .border(1.dp, palette.line, shape)
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(14.dp)
    ) {
        content()
    }
}

@Composable
fun MetricIcon(
    palette: LoganPalette,
    icon: CardIcon,
    tint: Color = palette.accent,
    modifier: Modifier = Modifier.size(22.dp)
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w / 2f, h / 2f)
        val s = minOf(w, h)
        val stroke = (s * .095f).coerceAtLeast(2f)
        val thin = (s * .065f).coerceAtLeast(1.4f)
        fun line(a: Offset, b: Offset, sw: Float = stroke) = drawLine(tint, a, b, sw, cap = StrokeCap.Round)
        fun circle(r: Float, center: Offset = c, sw: Float = stroke) = drawCircle(tint, r, center, style = Stroke(sw))

        when (icon) {
            CardIcon.FuelAverage, CardIcon.FuelInstant -> {
                // Yakıt pompası + akış/ortalama çizgisi
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * .24f, h * .20f),
                    size = androidx.compose.ui.geometry.Size(w * .34f, h * .56f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f),
                    style = Stroke(stroke)
                )
                line(Offset(w * .31f, h * .34f), Offset(w * .51f, h * .34f), thin)
                line(Offset(w * .58f, h * .35f), Offset(w * .76f, h * .45f), thin)
                line(Offset(w * .76f, h * .45f), Offset(w * .76f, h * .68f), thin)
                if (icon == CardIcon.FuelInstant) {
                    line(Offset(w * .14f, h * .84f), Offset(w * .86f, h * .84f), thin)
                    line(Offset(w * .66f, h * .74f), Offset(w * .86f, h * .84f), thin)
                } else {
                    circle(w * .09f, Offset(w * .77f, h * .76f), thin)
                }
            }
            CardIcon.Distance -> {
                line(Offset(w * .24f, h * .82f), Offset(w * .44f, h * .18f), thin)
                line(Offset(w * .56f, h * .18f), Offset(w * .76f, h * .82f), thin)
                line(Offset(w * .50f, h * .18f), Offset(w * .50f, h * .82f), thin)
                line(Offset(w * .44f, h * .55f), Offset(w * .56f, h * .55f), thin)
            }
            CardIcon.Cost -> {
                circle(w * .33f, c, stroke)
                line(Offset(w * .35f, h * .34f), Offset(w * .66f, h * .34f), thin)
                line(Offset(w * .50f, h * .30f), Offset(w * .50f, h * .73f), thin)
                line(Offset(w * .35f, h * .54f), Offset(w * .62f, h * .54f), thin)
            }
            CardIcon.Temperature -> {
                drawRoundRect(
                    color = tint,
                    topLeft = Offset(w * .43f, h * .16f),
                    size = androidx.compose.ui.geometry.Size(w * .16f, h * .52f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(8f, 8f),
                    style = Stroke(stroke)
                )
                drawCircle(tint, w * .15f, Offset(w * .51f, h * .75f), style = Stroke(stroke))
                line(Offset(w * .51f, h * .33f), Offset(w * .51f, h * .68f), thin)
            }
            CardIcon.Fan -> {
                circle(w * .10f, c, thin)
                repeat(3) { i ->
                    val angle = Math.toRadians((i * 120f - 90f).toDouble())
                    val p1 = Offset(c.x + cos(angle).toFloat() * w * .12f, c.y + sin(angle).toFloat() * h * .12f)
                    val p2 = Offset(c.x + cos(angle).toFloat() * w * .38f, c.y + sin(angle).toFloat() * h * .38f)
                    line(p1, p2, stroke)
                    drawCircle(tint.copy(alpha = .65f), w * .055f, p2)
                }
            }
            CardIcon.Ac -> {
                // A/C için kar tanesi hissi veren ama emoji olmayan çizgi ikon
                repeat(3) { i ->
                    val a = Math.toRadians((i * 60f).toDouble())
                    val dx = cos(a).toFloat() * w * .34f
                    val dy = sin(a).toFloat() * h * .34f
                    line(Offset(c.x - dx, c.y - dy), Offset(c.x + dx, c.y + dy), thin)
                }
                circle(w * .07f, c, thin)
            }
            CardIcon.Rpm -> {
                drawArc(color = tint, startAngle = 145f, sweepAngle = 250f, useCenter = false, topLeft = Offset(w * .14f, h * .18f), size = androidx.compose.ui.geometry.Size(w * .72f, h * .72f), style = Stroke(stroke, cap = StrokeCap.Round))
                val angle = Math.toRadians(310.0)
                line(c, Offset(c.x + cos(angle).toFloat() * w * .28f, c.y + sin(angle).toFloat() * h * .28f), stroke)
            }
            CardIcon.Time -> {
                circle(w * .35f, c, stroke)
                line(c, Offset(c.x, c.y - h * .20f), thin)
                line(c, Offset(c.x + w * .18f, c.y + h * .10f), thin)
            }
            CardIcon.Battery -> {
                drawRoundRect(tint, Offset(w * .16f, h * .32f), androidx.compose.ui.geometry.Size(w * .62f, h * .36f), androidx.compose.ui.geometry.CornerRadius(4f, 4f), style = Stroke(stroke))
                line(Offset(w * .80f, h * .43f), Offset(w * .88f, h * .43f), stroke)
                line(Offset(w * .80f, h * .57f), Offset(w * .88f, h * .57f), stroke)
                line(Offset(w * .32f, h * .50f), Offset(w * .45f, h * .50f), thin)
                line(Offset(w * .58f, h * .44f), Offset(w * .58f, h * .56f), thin)
                line(Offset(w * .52f, h * .50f), Offset(w * .64f, h * .50f), thin)
            }
            CardIcon.Speed -> {
                drawArc(color = tint, startAngle = 150f, sweepAngle = 240f, useCenter = false, topLeft = Offset(w * .16f, h * .22f), size = androidx.compose.ui.geometry.Size(w * .68f, h * .68f), style = Stroke(stroke, cap = StrokeCap.Round))
                val angle = Math.toRadians(315.0)
                line(c, Offset(c.x + cos(angle).toFloat() * w * .28f, c.y + sin(angle).toFloat() * h * .28f), stroke)
            }
            CardIcon.Injection -> {
                line(Offset(w * .30f, h * .20f), Offset(w * .70f, h * .60f), stroke)
                line(Offset(w * .22f, h * .28f), Offset(w * .42f, h * .08f), thin)
                line(Offset(w * .58f, h * .72f), Offset(w * .76f, h * .54f), thin)
                drawCircle(tint, w * .07f, Offset(w * .76f, h * .77f))
            }
        }
    }
}

@Composable
fun DataCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String? = null,
    accent: Color = palette.accent,
    subtitle: String? = null,
    icon: CardIcon? = null,
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null
) {
    val valueSize = when {
        value.length > 12 -> 18.sp
        value.length > 7 -> 22.sp
        else -> 29.sp
    }
    OemCard(palette = palette, modifier = modifier, onClick = onClick) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                if (icon != null) MetricIcon(palette, icon, accent, Modifier.size(18.dp))
                Text(title.uppercase(), color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = palette.textPrimary, fontSize = valueSize, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (unit != null) {
                    Text(" $unit", color = palette.textSecondary, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp), maxLines = 1)
                }
            }
            if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun SettingsRow(
    palette: LoganPalette,
    title: String,
    subtitle: String? = null,
    value: String? = null,
    onClick: (() -> Unit)? = null,
    trailingSwitch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
        }
        if (trailingSwitch != null && onSwitch != null) {
            Switch(checked = trailingSwitch, onCheckedChange = onSwitch)
        } else if (value != null) {
            Text("$value  ›", color = palette.textSecondary, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
