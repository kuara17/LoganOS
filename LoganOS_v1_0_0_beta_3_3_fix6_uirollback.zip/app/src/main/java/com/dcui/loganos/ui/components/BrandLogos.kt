package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(98.dp, 46.dp)) {
            val bar = size.height * .22f
            val top = size.height * .28f
            val bottom = size.height * .72f
            val left = size.width * .08f
            val right = size.width * .92f
            val midLeft = size.width * .42f
            val midRight = size.width * .58f
            drawLine(c, Offset(left, top), Offset(midLeft, top), strokeWidth = bar)
            drawLine(c, Offset(midRight, top), Offset(right, top), strokeWidth = bar)
            drawLine(c, Offset(left, bottom), Offset(midLeft, bottom), strokeWidth = bar)
            drawLine(c, Offset(midRight, bottom), Offset(right, bottom), strokeWidth = bar)
            val diamond = Path().apply {
                moveTo(size.width * .50f, size.height * .36f)
                lineTo(size.width * .58f, size.height * .50f)
                lineTo(size.width * .50f, size.height * .64f)
                lineTo(size.width * .42f, size.height * .50f)
                close()
            }
            drawPath(diamond, color = c, style = Fill)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "DACIA",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.8.sp
        )
    }
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(48.dp, 58.dp)) {
            val outer = Path().apply {
                moveTo(size.width * .50f, size.height * .04f)
                lineTo(size.width * .86f, size.height * .50f)
                lineTo(size.width * .50f, size.height * .96f)
                lineTo(size.width * .14f, size.height * .50f)
                close()
            }
            val inner = Path().apply {
                moveTo(size.width * .50f, size.height * .23f)
                lineTo(size.width * .66f, size.height * .50f)
                lineTo(size.width * .50f, size.height * .77f)
                lineTo(size.width * .34f, size.height * .50f)
                close()
            }
            drawPath(outer, color = c, style = Stroke(width = size.minDimension * .095f))
            drawPath(inner, color = c, style = Stroke(width = size.minDimension * .080f))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "RENAULT",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.6.sp
        )
    }
}
