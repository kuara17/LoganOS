# LoganOS AI Review Pack — beta.4.19.5

## Amaç
Ghost Single Original ekranındaki yayvan/boş gösterge hissini, mevcut asset tabanlı mimariyi koruyarak düzeltmek.

## Mimari kararlar
- Statik görsel yapı WebP assetlerde kalır.
- Canlı araç verileri ve aktif dolumlar Compose katmanında çizilir.
- Ana hız ölçeği Dacia Logan için **0–200 km/h** sınırındadır.
- Kadran rakamları assete gömülüdür: `0, 20, ... 200`.
- Desteklenmeyen veri eklenmez. Ekranda yalnız hız, RPM, anlık tüketim, ortalama tüketim, motor suyu sıcaklığı ve OBD/Demo durumu bulunur.

## Değişen dosyalar
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt`
- `app/src/main/res/drawable-nodpi/ghost_single_original_gauge_shell.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_base.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_edges.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_sheen.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_preview.webp`
- `tools/render_ghost_single_original_assets.py`
- `tools/validate_ghost_single_original.py`
- `tools/validate_release.py`
- `app/build.gradle.kts`

## Görsel değişiklik özeti
- Önceki yatay yarım elips kadran, 210° yay kullanan daha yuvarlak geometriye dönüştürüldü.
- Kadran üzerinde 101 çizgi/kademe ve 11 ana hız rakamı bulunur.
- Aktif hız yayı `GaugeProgressLayer` ile 0–200 aralığında ilerler.
- Yol, `y=458` ile `y=756` arasında kalan kompakt trapezdir; ufuk ışığını geçmez ve ekran köşelerine ulaşmaz.
- Sol/sağ tüketim kartlarında gerçek tüketim değerlerinden beslenen dikey çubuklar vardır.
- Hararet çubuğu 40–120 °C aralığında gerçek ECU sıcaklığından beslenir.

## Kritik veri kuralları
- Güvenilir yakıt kaynağı yoksa tüketim değerleri `-- / VERİ BEKLENİYOR` olarak kalır ve çubuk dolmaz.
- Hararet verisi yoksa değer `-- °C` olur ve sıcaklık çubuğu çizilmez.
- Yakıt seviyesi, menzil, vites, dış sıcaklık, hız limiti, ADAS ve ECO alanları yoktur.

## Kontrol soruları
1. Compose `drawArc` çağrıları Compose BOM 2024.11.00 ile uyumlu mu?
2. 1846×852 referans sahne farklı yatay oranlarda `FillBounds` ile kabul edilebilir hizayı koruyor mu?
3. Tüketim çubuklarının 0–15 görsel aralığı hem L/h hem L/100 km gösteriminde yeterli mi?
4. Kadran rakamları Double cihaz ekranında yeterince okunaklı mı?

## Bilinen sınırlama
Bu çalışma ortamında Android SDK/Gradle kurulumu bulunmadığı için gerçek APK derlemesi çalıştırılamadı. Kaynak, resource, özel Ghost doğrulaması ve genel LoganOS doğrulama kapıları çalıştırılmıştır.
