package com.dcui.loganos.ui.cockpit

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private val OriginalWhite = Color(0xFFF7F9FF)
private val OriginalMuted = Color(0xFFB7C1D0)
private const val GhostSpeedMaxKmh = 200
private const val ConsumptionVisualMax = 15.0

@Composable
fun GhostSingleOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, GhostSpeedMaxKmh)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, settings.tachometerMaxRpm)
    val accent = ghostOriginalAccentColor(settings.ghostOriginalAccent)
    val motion = remember { Animatable(0f) }

    LaunchedEffect(speed, settings.demoMode) {
        if (speed < 3) {
            motion.snapTo(0f)
        } else {
            while (true) {
                motion.snapTo(0f)
                val duration = (2700 - speed * 18).coerceIn(650, 2500)
                motion.animateTo(1f, animationSpec = tween(duration, easing = LinearEasing))
            }
        }
    }

    val fuelTrusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    val instantValue = snapshot.instantConsumption.takeIf { fuelTrusted }
    val averageValue = snapshot.averageConsumption.takeIf { fuelTrusted }
    val instant = if (fuelTrusted) formatOne(instantValue) else "--"
    val average = if (fuelTrusted) formatOne(averageValue) else "--"
    val instantUnit = if (fuelTrusted) snapshot.instantUnit else "VERİ BEKLENİYOR"
    val averageUnit = if (fuelTrusted) "L/100 km" else "VERİ BEKLENİYOR"
    val temp = snapshot.engineTempC?.toString() ?: "--"
    val tempColor = coolantAccentColor(palette, snapshot.engineTempC)
    val vehicleRes = vehicleVisualDrawableRes(
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor,
        style = VehicleAssetStyle.Detailed
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.ghost_single_original_background),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(ghostOriginalHorizonRes(settings.ghostOriginalAccent)),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .width(maxWidth)
                .height(maxHeight * 0.352f)
                .align(Alignment.Center)
                .offset(y = maxHeight * 0.011f)
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_base),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_edges),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.82f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_sheen),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.20f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        RoadMotionLayer(
            phase = motion.value,
            accent = accent,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_soft),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_contact),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(maxWidth * 0.128f)
                .height(maxHeight * 0.255f)
                .offset(y = maxHeight * -0.126f)
        )

        GaugeProgressLayer(
            speedKmh = speed,
            accent = accent,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_gauge_shell),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_vignette),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        ConsumptionProgressLayer(
            instant = instantValue,
            average = averageValue,
            accent = accent,
            modifier = Modifier.fillMaxSize()
        )
        CoolantProgressLayer(
            temperatureC = snapshot.engineTempC,
            color = tempColor,
            modifier = Modifier.fillMaxSize()
        )

        GhostOriginalText(
            cx = 0.50f,
            cy = 0.216f,
            widthFraction = 0.22f,
            heightFraction = 0.13f,
            text = speed.toString(),
            size = scaledSp(maxHeight.value * 0.092f),
            color = OriginalWhite,
            weight = FontWeight.Light
        )
        GhostOriginalText(
            cx = 0.50f,
            cy = 0.300f,
            widthFraction = 0.14f,
            heightFraction = 0.05f,
            text = "km/h",
            size = scaledSp(maxHeight.value * 0.024f),
            color = OriginalMuted,
            weight = FontWeight.Medium
        )
        GhostOriginalText(
            cx = 0.50f,
            cy = 0.366f,
            widthFraction = 0.26f,
            heightFraction = 0.06f,
            text = "$rpm rpm",
            size = scaledSp(maxHeight.value * 0.031f),
            color = OriginalWhite.copy(alpha = 0.88f),
            weight = FontWeight.Medium
        )

        MetricBlock(
            cx = 0.17f,
            cy = 0.695f,
            label = "ANLIK",
            value = instant,
            unit = instantUnit,
            onClick = onOpenReset,
            maxHeightValue = maxHeight.value
        )
        MetricBlock(
            cx = 0.83f,
            cy = 0.695f,
            label = "ORTALAMA",
            value = average,
            unit = averageUnit,
            onClick = onOpenReset,
            maxHeightValue = maxHeight.value
        )
        TemperatureBlock(
            value = "$temp °C",
            color = tempColor,
            maxHeightValue = maxHeight.value
        )
        GhostOriginalText(
            cx = 0.91f,
            cy = 0.065f,
            widthFraction = 0.16f,
            heightFraction = 0.06f,
            text = when {
                snapshot.demo -> "DEMO"
                snapshot.connected -> "OBD BAĞLI"
                else -> "OBD BEKLENİYOR"
            },
            size = scaledSp(maxHeight.value * 0.021f),
            color = if (snapshot.demo || snapshot.connected) accent else OriginalMuted,
            weight = FontWeight.Bold
        )
    }
}

@Composable
private fun GaugeProgressLayer(
    speedKmh: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val left = size.width * (503f / 1846f)
        val top = size.height * (38f / 852f)
        val right = size.width * (1343f / 1846f)
        val bottom = size.height * (878f / 852f)
        val arcSize = Size(right - left, bottom - top)
        val sweep = 210f * (speedKmh.coerceIn(0, GhostSpeedMaxKmh) / GhostSpeedMaxKmh.toFloat())
        if (sweep <= 0f) return@Canvas

        drawArc(
            color = accent.copy(alpha = 0.22f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = size.height * 0.015f, cap = StrokeCap.Round)
        )
        drawArc(
            color = accent.copy(alpha = 0.95f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = size.height * 0.006f, cap = StrokeCap.Round)
        )

        val endAngle = (165f + sweep) * (PI.toFloat() / 180f)
        val end = Offset(
            x = left + arcSize.width / 2f + arcSize.width / 2f * cos(endAngle.toDouble()).toFloat(),
            y = top + arcSize.height / 2f + arcSize.height / 2f * sin(endAngle.toDouble()).toFloat()
        )
        drawCircle(accent.copy(alpha = 0.28f), radius = size.height * 0.018f, center = end)
        drawCircle(OriginalWhite.copy(alpha = 0.95f), radius = size.height * 0.0045f, center = end)
    }
}

@Composable
private fun RoadMotionLayer(phase: Float, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val leftTop = Offset(size.width * 0.4523f, size.height * 0.5376f)
        val rightTop = Offset(size.width * 0.5477f, size.height * 0.5376f)
        val leftBottom = Offset(size.width * 0.2931f, size.height * 0.8873f)
        val rightBottom = Offset(size.width * 0.7069f, size.height * 0.8873f)
        val length = 0.21f

        fun point(a: Offset, b: Offset, t: Float) = Offset(
            x = a.x + (b.x - a.x) * t,
            y = a.y + (b.y - a.y) * t
        )

        fun drawMovingSegment(top: Offset, bottom: Offset) {
            val startT = phase.coerceIn(0f, 1f)
            val endT = (startT + length).coerceAtMost(1f)
            if (endT <= startT) return
            val start = point(top, bottom, startT)
            val end = point(top, bottom, endT)
            drawLine(accent.copy(alpha = 0.24f), start, end, strokeWidth = size.height * 0.014f, cap = StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.86f), start, end, strokeWidth = size.height * 0.003f, cap = StrokeCap.Round)
        }

        if (phase > 0f) {
            drawMovingSegment(leftTop, leftBottom)
            drawMovingSegment(rightTop, rightBottom)
        }
    }
}

@Composable
private fun ConsumptionProgressLayer(
    instant: Double?,
    average: Double?,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val top = size.height * (534f / 852f)
        val bottom = size.height * (668f / 852f)

        fun drawBar(xFraction: Float, value: Double?) {
            if (value == null || value.isNaN() || value.isInfinite()) return
            val progress = (value / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f)
            val x = size.width * xFraction
            val y = bottom - (bottom - top) * progress
            drawLine(
                accent.copy(alpha = 0.20f),
                Offset(x, bottom),
                Offset(x, y),
                strokeWidth = size.height * 0.016f,
                cap = StrokeCap.Round
            )
            drawLine(
                accent.copy(alpha = 0.96f),
                Offset(x, bottom),
                Offset(x, y),
                strokeWidth = size.height * 0.006f,
                cap = StrokeCap.Round
            )
            drawCircle(OriginalWhite.copy(alpha = 0.92f), radius = size.height * 0.0038f, center = Offset(x, y))
        }

        drawBar(424f / 1846f, instant)
        drawBar(1422f / 1846f, average)
    }
}

@Composable
private fun CoolantProgressLayer(
    temperatureC: Int?,
    color: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val value = temperatureC ?: return@Canvas
        val progress = ((value - 40f) / 80f).coerceIn(0f, 1f)
        val x1 = size.width * (879f / 1846f)
        val x2 = size.width * (1215f / 1846f)
        val y = size.height * (786f / 852f)
        val endX = x1 + (x2 - x1) * progress

        drawLine(
            color.copy(alpha = 0.22f),
            Offset(x1, y),
            Offset(endX, y),
            strokeWidth = size.height * 0.016f,
            cap = StrokeCap.Round
        )
        drawLine(
            color.copy(alpha = 0.96f),
            Offset(x1, y),
            Offset(endX, y),
            strokeWidth = size.height * 0.006f,
            cap = StrokeCap.Round
        )
        drawCircle(OriginalWhite.copy(alpha = 0.92f), radius = size.height * 0.0038f, center = Offset(endX, y))
    }
}

@Composable
private fun BoxWithConstraintsScope.MetricBlock(
    cx: Float,
    cy: Float,
    label: String,
    value: String,
    unit: String,
    onClick: () -> Unit,
    maxHeightValue: Float
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - 0.095f), y = maxHeight * (cy - 0.09f))
            .width(maxWidth * 0.19f)
            .height(maxHeight * 0.18f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.material3.Text(
                label,
                color = OriginalMuted,
                fontSize = scaledSp(maxHeightValue * 0.021f),
                fontWeight = FontWeight.Bold
            )
            androidx.compose.material3.Text(
                value,
                color = OriginalWhite,
                fontSize = scaledSp(maxHeightValue * 0.044f),
                fontWeight = FontWeight.Medium
            )
            androidx.compose.material3.Text(
                unit,
                color = OriginalMuted,
                fontSize = scaledSp(maxHeightValue * 0.017f),
                maxLines = 1
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.TemperatureBlock(
    value: String,
    color: Color,
    maxHeightValue: Float
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * 0.34f, y = maxHeight * 0.88f)
            .width(maxWidth * 0.13f)
            .height(maxHeight * 0.095f),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.material3.Text(
                "HARARET",
                color = OriginalMuted,
                fontSize = scaledSp(maxHeightValue * 0.018f),
                fontWeight = FontWeight.Bold
            )
            androidx.compose.material3.Text(
                value,
                color = color,
                fontSize = scaledSp(maxHeightValue * 0.028f),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.GhostOriginalText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

private fun scaledSp(value: Float): TextUnit = max(9f, value).sp

private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun ghostOriginalAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFF9B5CFF)
    GhostOriginalAccent.Red -> Color(0xFFFF3B30)
    GhostOriginalAccent.Green -> Color(0xFF2EE66B)
    GhostOriginalAccent.White -> Color(0xFFF1F5FF)
    GhostOriginalAccent.Blue -> Color(0xFF3595FF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFC12E)
}

@DrawableRes
private fun ghostOriginalHorizonRes(accent: GhostOriginalAccent): Int = when (accent) {
    GhostOriginalAccent.Purple -> R.drawable.ghost_single_original_horizon_purple
    GhostOriginalAccent.Red -> R.drawable.ghost_single_original_horizon_red
    GhostOriginalAccent.Green -> R.drawable.ghost_single_original_horizon_green
    GhostOriginalAccent.White -> R.drawable.ghost_single_original_horizon_white
    GhostOriginalAccent.Blue -> R.drawable.ghost_single_original_horizon_blue
    GhostOriginalAccent.Yellow -> R.drawable.ghost_single_original_horizon_yellow
}
