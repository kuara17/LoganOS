#!/usr/bin/env python3
"""Render the asset-based Ghost Single Original cockpit layers.

Static visual language lives in WebP assets. Live speed/RPM/consumption/coolant
values remain in Compose. The speed scale is intentionally limited to the
Dacia Logan's 0–200 km/h display range.
"""
from __future__ import annotations

import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res/drawable-nodpi"
W, H = 1846, 852
SCALE = 2
SPEED_LABELS = list(range(0, 201, 20))
GAUGE_CENTER = (923, 458)
GAUGE_RADIUS = 420
GAUGE_START_DEG = 165.0
GAUGE_SWEEP_DEG = 210.0
ROAD_TOP_Y = 458
ROAD_BOTTOM_Y = 756
ROAD_TOP_HALF_WIDTH = 88
ROAD_BOTTOM_HALF_WIDTH = 382

FONT_REGULAR = "/usr/share/fonts/opentype/inter/InterDisplay-Regular.otf"
FONT_MEDIUM = "/usr/share/fonts/opentype/inter/InterDisplay-Medium.otf"
if not Path(FONT_REGULAR).exists():
    FONT_REGULAR = "/usr/share/fonts/truetype/lato/Lato-Regular.ttf"
if not Path(FONT_MEDIUM).exists():
    FONT_MEDIUM = "/usr/share/fonts/truetype/lato/Lato-Medium.ttf"


def sc(v: float) -> int:
    return int(round(v * SCALE))


def rgba() -> Image.Image:
    return Image.new("RGBA", (W * SCALE, H * SCALE), (0, 0, 0, 0))


def font(size: int, medium: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MEDIUM if medium else FONT_REGULAR, sc(size))


def line(draw: ImageDraw.ImageDraw, xy, fill, width=1):
    draw.line(tuple(sc(v) for point in xy for v in point), fill=fill, width=sc(width), joint="curve")


def rounded_rect(draw: ImageDraw.ImageDraw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(tuple(sc(v) for v in box), radius=sc(radius), fill=fill, outline=outline, width=sc(width))


def point_on_gauge(radius: float, angle_deg: float) -> tuple[float, float]:
    a = math.radians(angle_deg)
    return (
        GAUGE_CENTER[0] + radius * math.cos(a),
        GAUGE_CENTER[1] + radius * math.sin(a),
    )


def render_gauge_shell() -> Image.Image:
    base = rgba()

    # Soft OEM-style dashboard shoulders so the empty black sides feel framed.
    trim = rgba()
    td = ImageDraw.Draw(trim)
    td.arc((sc(-240), sc(-420), sc(940), sc(430)), 18, 82, fill=(54, 67, 92, 90), width=sc(2))
    td.arc((sc(906), sc(-420), sc(2086), sc(430)), 98, 162, fill=(54, 67, 92, 90), width=sc(2))
    trim = trim.filter(ImageFilter.GaussianBlur(sc(1.1)))
    base.alpha_composite(trim)

    # Gauge glow, then crisp neutral shell. Accent progress is drawn live.
    glow = rgba()
    gd = ImageDraw.Draw(glow)
    bbox = (
        sc(GAUGE_CENTER[0] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[0] + GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] + GAUGE_RADIUS),
    )
    gd.arc(bbox, int(GAUGE_START_DEG), int(GAUGE_START_DEG + GAUGE_SWEEP_DEG), fill=(130, 155, 205, 105), width=sc(12))
    glow = glow.filter(ImageFilter.GaussianBlur(sc(8)))
    base.alpha_composite(glow)

    d = ImageDraw.Draw(base)
    d.arc(bbox, int(GAUGE_START_DEG), int(GAUGE_START_DEG + GAUGE_SWEEP_DEG), fill=(229, 234, 244, 228), width=sc(3))
    inner_r = GAUGE_RADIUS - 19
    inner_box = (
        sc(GAUGE_CENTER[0] - inner_r), sc(GAUGE_CENTER[1] - inner_r),
        sc(GAUGE_CENTER[0] + inner_r), sc(GAUGE_CENTER[1] + inner_r),
    )
    d.arc(inner_box, int(GAUGE_START_DEG), int(GAUGE_START_DEG + GAUGE_SWEEP_DEG), fill=(114, 126, 151, 150), width=sc(1))

    # 0–200 km/h scale: major 20 km/h, medium 10 km/h, minor 2 km/h.
    subdivisions = 100
    for i in range(subdivisions + 1):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * i / subdivisions
        if i % 10 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 7, GAUGE_RADIUS - 38, 4, 245
        elif i % 5 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 8, GAUGE_RADIUS - 29, 3, 220
        else:
            outer, inner, width, alpha = GAUGE_RADIUS - 9, GAUGE_RADIUS - 20, 2, 165
        p1, p2 = point_on_gauge(inner, angle), point_on_gauge(outer, angle)
        line(d, (p1, p2), (232, 237, 247, alpha), width)

    # Asset-baked speed numerals, as requested.
    number_font = font(27, medium=True)
    label_r = GAUGE_RADIUS - 78
    for idx, value in enumerate(SPEED_LABELS):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * idx / (len(SPEED_LABELS) - 1)
        x, y = point_on_gauge(label_r, angle)
        txt = str(value)
        box = d.textbbox((0, 0), txt, font=number_font)
        tw, th = box[2] - box[0], box[3] - box[1]
        d.text((sc(x) - tw / 2, sc(y) - th / 2), txt, font=number_font, fill=(235, 239, 247, 235))

    # Thin central separator gives the speed/RPM area a finished OEM feel.
    sep_glow = rgba()
    sd = ImageDraw.Draw(sep_glow)
    sd.line((sc(720), sc(374), sc(1126), sc(374)), fill=(104, 132, 188, 110), width=sc(4))
    sep_glow = sep_glow.filter(ImageFilter.GaussianBlur(sc(7)))
    base.alpha_composite(sep_glow)
    d = ImageDraw.Draw(base)
    d.line((sc(742), sc(374), sc(1104), sc(374)), fill=(119, 137, 172, 115), width=sc(1))

    # Side metric modules: neutral asset shells; live accent bars are Compose.
    panel_fill = (7, 11, 20, 185)
    panel_outline = (79, 91, 117, 175)
    panel_inner = (31, 40, 59, 145)
    left_box = (72, 492, 456, 704)
    right_box = (1390, 492, 1774, 704)
    for box in (left_box, right_box):
        rounded_rect(d, box, 32, panel_fill, panel_outline, 2)
        rounded_rect(d, (box[0] + 8, box[1] + 8, box[2] - 8, box[3] - 8), 25, None, panel_inner, 1)

    # Subtle dotted texture in the upper corners of both cards.
    for side in (1, -1):
        x0 = 102 if side == 1 else 1744
        for row in range(5):
            for col in range(8):
                x = x0 + side * col * 9
                y = 515 + row * 8
                d.ellipse((sc(x - 1), sc(y - 1), sc(x + 1), sc(y + 1)), fill=(118, 132, 160, max(22, 75 - row * 9 - col * 3)))

    # Left icon: compact gauge/needle.
    def circle(cx, cy, r, fill=None, outline=(143, 154, 178, 200), width=2):
        d.ellipse((sc(cx - r), sc(cy - r), sc(cx + r), sc(cy + r)), fill=fill, outline=outline, width=sc(width))

    circle(143, 563, 35, fill=(12, 18, 31, 200))
    d.arc((sc(123), sc(543), sc(163), sc(583)), 195, 345, fill=(217, 224, 238, 220), width=sc(2))
    line(d, ((143, 563), (158, 550)), (217, 224, 238, 235), 3)
    circle(143, 563, 3, fill=(217, 224, 238, 235), outline=None, width=1)

    # Right icon: small average/trend bars.
    circle(1703, 563, 35, fill=(12, 18, 31, 200))
    for x, h in ((1688, 19), (1701, 29), (1714, 39)):
        d.rounded_rectangle((sc(x - 4), sc(581 - h), sc(x + 4), sc(581)), radius=sc(2), outline=(217, 224, 238, 225), width=sc(2))

    # Static vertical tracks for live consumption fills.
    for x in (424, 1422):
        d.rounded_rectangle((sc(x - 5), sc(534), sc(x + 5), sc(668)), radius=sc(5), fill=(22, 29, 44, 230), outline=(91, 104, 132, 175), width=sc(1))
        for y in (534, 568, 601, 635, 668):
            if x < W / 2:
                d.line((sc(x - 15), sc(y), sc(x - 8), sc(y)), fill=(174, 184, 204, 180), width=sc(1))
            else:
                d.line((sc(x + 8), sc(y), sc(x + 15), sc(y)), fill=(174, 184, 204, 180), width=sc(1))

    # Coolant module shell and static 40–120 °C scale.
    temp_box = (548, 748, 1298, 830)
    rounded_rect(d, temp_box, 25, (7, 11, 20, 205), (79, 91, 117, 180), 2)
    rounded_rect(d, (556, 756, 1290, 822), 19, None, (31, 40, 59, 140), 1)

    # Coolant icon: thermometer + waves, intentionally non-emoji/OEM-like.
    d.rounded_rectangle((sc(593), sc(770), sc(601), sc(803)), radius=sc(4), outline=(216, 223, 238, 220), width=sc(2))
    circle(597, 806, 8, fill=(216, 223, 238, 220), outline=None, width=1)
    for offset in (0, 11):
        pts = [(572 + offset, 815), (580 + offset, 811), (588 + offset, 815), (596 + offset, 811), (604 + offset, 815)]
        line(d, pts, (216, 223, 238, 210), 2)

    # Temperature track and printed scale numbers are static asset content.
    track_x1, track_x2, track_y = 879, 1215, 786
    d.rounded_rectangle((sc(track_x1), sc(track_y - 5), sc(track_x2), sc(track_y + 5)), radius=sc(5), fill=(22, 29, 44, 235), outline=(91, 104, 132, 175), width=sc(1))
    scale_font = font(14)
    for idx, value in enumerate((40, 60, 80, 100, 120)):
        x = track_x1 + (track_x2 - track_x1) * idx / 4
        d.line((sc(x), sc(track_y + 10), sc(x), sc(track_y + 16)), fill=(174, 184, 204, 170), width=sc(1))
        txt = str(value)
        box = d.textbbox((0, 0), txt, font=scale_font)
        tw = box[2] - box[0]
        d.text((sc(x) - tw / 2, sc(track_y + 19)), txt, font=scale_font, fill=(174, 184, 204, 185))
    d.text((sc(1233), sc(799)), "°C", font=font(15, medium=True), fill=(205, 213, 230, 210))

    return base.resize((W, H), Image.Resampling.LANCZOS)


def render_road_base() -> Image.Image:
    img = rgba()
    # Trapezoid begins below the horizon; no giant triangle crossing the glow.
    mask = Image.new("L", img.size, 0)
    md = ImageDraw.Draw(mask)
    polygon = [
        (sc(W / 2 - ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(W / 2 + ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(W / 2 + ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
        (sc(W / 2 - ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
    ]
    md.polygon(polygon, fill=225)

    gradient = Image.new("RGBA", img.size, (0, 0, 0, 0))
    gd = ImageDraw.Draw(gradient)
    for y in range(sc(ROAD_TOP_Y), sc(ROAD_BOTTOM_Y) + 1):
        t = (y / SCALE - ROAD_TOP_Y) / (ROAD_BOTTOM_Y - ROAD_TOP_Y)
        c = int(22 + 11 * t)
        a = int(150 + 65 * t)
        gd.line((0, y, W * SCALE, y), fill=(c, c + 2, c + 7, a), width=1)
    gradient.putalpha(Image.composite(gradient.getchannel("A"), Image.new("L", img.size, 0), mask))
    img.alpha_composite(gradient)

    # Soft center sheen on the asphalt.
    sheen = rgba()
    sd = ImageDraw.Draw(sheen)
    sd.polygon(polygon, fill=(84, 91, 112, 34))
    sheen = sheen.filter(ImageFilter.GaussianBlur(sc(24)))
    img.alpha_composite(sheen)
    return img.resize((W, H), Image.Resampling.LANCZOS)


def render_road_edges() -> Image.Image:
    img = rgba()
    d = ImageDraw.Draw(img)
    left_top = (W / 2 - ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    right_top = (W / 2 + ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    left_bottom = (W / 2 - ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)
    right_bottom = (W / 2 + ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)

    # Continuous outer edges remain compact and never reach screen corners.
    line(d, (left_top, left_bottom), (255, 255, 255, 235), 3)
    line(d, (right_top, right_bottom), (255, 255, 255, 235), 3)

    # Short lane dashes add depth inside the gauge without inventing vehicle data.
    def interp(a, b, t):
        return (a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t)

    inner_left_top = (W / 2 - 22, ROAD_TOP_Y + 10)
    inner_right_top = (W / 2 + 22, ROAD_TOP_Y + 10)
    inner_left_bottom = (W / 2 - 165, ROAD_BOTTOM_Y - 22)
    inner_right_bottom = (W / 2 + 165, ROAD_BOTTOM_Y - 22)
    for a, b in ((inner_left_top, inner_left_bottom), (inner_right_top, inner_right_bottom)):
        for start, end in ((0.12, 0.20), (0.31, 0.43), (0.58, 0.74)):
            p1, p2 = interp(a, b, start), interp(a, b, end)
            width = max(2, int(2 + 4 * end))
            line(d, (p1, p2), (255, 255, 255, 220), width)
    return img.resize((W, H), Image.Resampling.LANCZOS)


def render_road_sheen() -> Image.Image:
    img = rgba()
    d = ImageDraw.Draw(img)
    # Soft accent-tinted highlight, later color-filtered in Compose.
    d.polygon([
        (sc(W / 2 - 54), sc(ROAD_TOP_Y + 4)),
        (sc(W / 2 + 54), sc(ROAD_TOP_Y + 4)),
        (sc(W / 2 + 270), sc(ROAD_BOTTOM_Y - 5)),
        (sc(W / 2 - 270), sc(ROAD_BOTTOM_Y - 5)),
    ], fill=(255, 255, 255, 115))
    img = img.filter(ImageFilter.GaussianBlur(sc(22)))
    return img.resize((W, H), Image.Resampling.LANCZOS)


def save_webp(image: Image.Image, name: str, *, lossless: bool = True) -> None:
    path = RES / name
    image.save(path, "WEBP", lossless=lossless, quality=94, method=6)
    print(f"wrote {path.relative_to(ROOT)} {image.size} {path.stat().st_size} bytes")


def preview_font(size: int, medium: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MEDIUM if medium else FONT_REGULAR, size)


def build_preview() -> None:
    accent = (155, 92, 255, 255)
    bg = Image.open(RES / "ghost_single_original_background.webp").convert("RGBA")

    horizon = Image.open(RES / "ghost_single_original_horizon_purple.webp").convert("RGBA")
    # Same layout as Compose: 1846x300, centered with +9 px vertical offset.
    bg.alpha_composite(horizon, (0, 285))
    bg.alpha_composite(Image.open(RES / "ghost_single_original_road_base.webp").convert("RGBA"))

    def tint_alpha(path: Path, color, alpha_mul=1.0):
        src = Image.open(path).convert("RGBA")
        a = src.getchannel("A").point(lambda v: int(v * alpha_mul))
        out = Image.new("RGBA", src.size, color)
        out.putalpha(a)
        return out

    bg.alpha_composite(tint_alpha(RES / "ghost_single_original_road_edges.webp", accent, 0.82))
    bg.alpha_composite(tint_alpha(RES / "ghost_single_original_road_sheen.webp", accent, 0.20))
    bg.alpha_composite(Image.open(RES / "ghost_single_original_shadow_soft.webp").convert("RGBA"))
    bg.alpha_composite(Image.open(RES / "ghost_single_original_shadow_contact.webp").convert("RGBA"))

    car = Image.open(RES / "loganos_logan_rear_cherry_red.webp").convert("RGBA")
    car.thumbnail((236, 217), Image.Resampling.LANCZOS)
    bg.alpha_composite(car, ((W - car.width) // 2, 528 + (217 - car.height) // 2))

    # Live accent progress mock at 88 km/h, kept out of the static shell.
    prog = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    pd = ImageDraw.Draw(prog)
    bbox = (GAUGE_CENTER[0] - GAUGE_RADIUS, GAUGE_CENTER[1] - GAUGE_RADIUS,
            GAUGE_CENTER[0] + GAUGE_RADIUS, GAUGE_CENTER[1] + GAUGE_RADIUS)
    sweep = GAUGE_SWEEP_DEG * 88 / 200
    pd.arc(bbox, int(GAUGE_START_DEG), int(GAUGE_START_DEG + sweep), fill=(155, 92, 255, 210), width=9)
    bg.alpha_composite(prog)
    bg.alpha_composite(Image.open(RES / "ghost_single_original_gauge_shell.webp").convert("RGBA"))
    bg.alpha_composite(Image.open(RES / "ghost_single_original_vignette.webp").convert("RGBA"))

    d = ImageDraw.Draw(bg)
    def centered(text, x, y, fnt, fill):
        box = d.textbbox((0, 0), text, font=fnt)
        d.text((x - (box[2] - box[0]) / 2, y - (box[3] - box[1]) / 2), text, font=fnt, fill=fill)

    centered("88", 923, 184, preview_font(78), (247, 249, 255, 255))
    centered("km/h", 923, 260, preview_font(22, True), (183, 193, 208, 255))
    centered("2673 rpm", 923, 316, preview_font(27, True), (237, 241, 250, 225))

    # Side mock values and units.
    centered("ANLIK", 314, 548, preview_font(18, True), (183, 193, 208, 255))
    centered("3.5", 314, 594, preview_font(34, True), (247, 249, 255, 255))
    centered("L/100 km", 314, 638, preview_font(16), (183, 193, 208, 255))
    centered("ORTALAMA", 1532, 548, preview_font(18, True), (183, 193, 208, 255))
    centered("5.1", 1532, 594, preview_font(34, True), (247, 249, 255, 255))
    centered("L/100 km", 1532, 638, preview_font(16), (183, 193, 208, 255))

    # Live consumption bars.
    for x, value in ((424, 3.5), (1422, 5.1)):
        top, bottom = 534, 668
        p = min(1.0, value / 15.0)
        y = bottom - (bottom - top) * p
        d.line((x, bottom, x, y), fill=(155, 92, 255, 255), width=8)

    centered("HARARET", 725, 775, preview_font(16, True), (183, 193, 208, 255))
    centered("82 °C", 795, 804, preview_font(24, True), (247, 249, 255, 255))
    # Temperature live fill, 82 °C across 40–120 range.
    x1, x2, yy = 879, 1215, 786
    temp_p = (82 - 40) / 80
    d.line((x1, yy, x1 + (x2 - x1) * temp_p, yy), fill=(155, 92, 255, 255), width=8)
    centered("DEMO", 1675, 50, preview_font(18, True), accent)

    preview = bg.convert("RGB")
    preview.save(RES / "ghost_single_original_preview.webp", "WEBP", quality=91, method=6)
    preview.save(ROOT / "LoganOS_Ghost_Single_Original_beta_4_19_5_preview.jpg", "JPEG", quality=94, optimize=True)
    print("wrote preview assets")


def main() -> None:
    save_webp(render_gauge_shell(), "ghost_single_original_gauge_shell.webp")
    save_webp(render_road_base(), "ghost_single_original_road_base.webp")
    save_webp(render_road_edges(), "ghost_single_original_road_edges.webp")
    save_webp(render_road_sheen(), "ghost_single_original_road_sheen.webp")
    build_preview()


if __name__ == "__main__":
    main()
