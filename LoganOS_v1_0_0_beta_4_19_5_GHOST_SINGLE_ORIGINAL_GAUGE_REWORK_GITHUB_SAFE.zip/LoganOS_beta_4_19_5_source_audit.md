# LoganOS beta.4.19.5 Source Audit

## Scope
Ghost Single Original gösterge asseti, canlı katmanları ve ilgili doğrulama araçları incelendi. Diğer Ghost göstergeleri ve Digital V2 çalışma alanı kapsam dışı bırakıldı ve hash karşılaştırmasıyla korunmaları kontrol edildi.

## Değişiklik sınırı
Değiştirilen çalışma dosyaları:
- `app/build.gradle.kts`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt`
- `app/src/main/res/drawable-nodpi/ghost_single_original_gauge_shell.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_preview.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_base.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_edges.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_sheen.webp`
- `tools/render_ghost_single_original_assets.py`
- `tools/validate_ghost_single_original.py`
- `tools/validate_release.py`

## Veri güvenliği denetimi
Ghost Single Original kaynak ekranında yalnız şu canlı alanlar bulunur:
- hız
- RPM
- anlık tüketim ve geçerli birimi
- ortalama tüketim
- motor suyu sıcaklığı
- OBD/Demo durumu

Yakıt seviyesi, menzil, vites, dış sıcaklık, hız sınırı, ADAS ve ECO alanlarının kaynakta bulunmadığı özel doğrulama ile kontrol edildi.

## Görsel geometri denetimi
- Hız maksimumu hem veri katmanında hem asset üreticisinde 200 km/h.
- Asset rakamları 0–200 arasında 20 km/h aralıklarla.
- Kadran 210° dairesel geometri kullanır; eski yayvan yarım elips kaldırıldı.
- Yolun üst sınırı `y=458`, alt sınırı `y=756`; yol ufuk ışığının altında başlar ve ekran köşelerine ulaşmaz.
- Tüketim ve hararet statik kabukları assettedir; dolumları gerçek veriden Compose ile çizilir.

## Eski sistem kalıntıları ve regresyon kontrolü
Aşağıdaki eski Ghost dosyalarının beta.4.19.4 ile SHA-256 değerleri aynıdır:
- `GhostHeadUnitCockpit.kt`
- `GhostPhoneWideCockpit.kt`
- `GhostPortraitCockpit.kt`
- `ghost_single_logan_oem_19_5_9.webp`
- `ghost_dual_logan_oem_19_5_9.webp`
- `ghost_single_portrait_logan_oem_19_5_9.webp`

Retired `GhostSingleV2` kimliği yeni kaynakta yoktur. Yeni/deneysel bir veri alanı veya ikinci renderer eklenmemiştir.

## Doğrulama sonuçları
- `tools/validate_ghost_single_original.py`: PASS
- `tools/preflight_source.py`: PASS
- `tools/validate_release.py`: PASS
- Python araçları `py_compile`: PASS
- Paket artığı (`build`, `.gradle`, APK, AAB, keystore, pyc): yok

## APK derleme durumu
Çalışma ortamında Android SDK ve Gradle kurulumu bulunmadığı için `assembleDebug` çalıştırılamadı. Paket içindeki GitHub Actions akışı Gradle 8.10.2 ve JDK 17 ile `testDebugUnitTest assembleDebug` çalıştıracak şekilde korunmuştur.
