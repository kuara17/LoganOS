# LoganOS Changelog

## v1.0.0-beta.3.1 - UI Fix + OBD Connection Test

- Alt menü sadeleştirildi: Kokpit / Sürüş / Teknik / Ayarlar.
- Ayarlar sadeleştirildi: Görünüm & Kokpit, Sürüş & Yakıt, Araç & Bakım, Bağlantı & Veri, Geliştirici & Hakkında.
- Dikey kokpitte tekrar eden büyük OBD uyarı kartı kaldırıldı.
- Sağ üst kompakt OBD/Bluetooth durum alanı korundu.
- Hız göstergesi daha kompakt ve responsive hale getirildi.
- Yatay ekran için ayrı kokpit yerleşimi eklendi.
- Motor Sıcaklığı / Fan / Klima bilgileri tek kartta birleştirildi.
- Demo Modu sabit veri yerine canlı sürüş simülasyonuna dönüştürüldü.
- Splash ekran native Compose düzenine çevrildi; poster/görsel yapıştırma hissi azaltıldı.
- Gösterge stili önizlemeleri birbirinden daha belirgin hale getirildi.
- Ayar satırları sessiz kalmayacak şekilde seçim/diyalog yapısına bağlandı.
- Temel bakım aralıkları ve kilometre/yakıt fiyatı ayarları düzenlenebilir hale getirildi.
- Bluetooth izinleri, eşleşmiş cihaz listeleme, cihaz seçme, bağlan/kes akışı eklendi.
- KWP/ELM init test akışı eklendi: ATZ, ATE0, ATL0, ATS0, ATH0, ATSP5, ATKW0, ATFI.
- 21A0 / 21A2 / 21CC / 21CD ham okuma döngüsü eklendi.
- Fuel Truth Test Panel eklendi: injection mg/st, kaynak, anlık tüketim test değeri.
- OBD bağlantı logu ekranda gösterilir ve dosyaya kaydedilebilir hale getirildi.

## v1.0.0-beta.2 - UI Fix

- Demo veriler varsayılan kapatıldı.
- Alt menü ve ayarlar erişimi eklendi.
- Dacia/Renault logo yerleşimi güncellendi.
