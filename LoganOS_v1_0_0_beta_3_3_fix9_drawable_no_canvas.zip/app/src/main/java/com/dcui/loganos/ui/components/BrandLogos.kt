package com.dcui.loganos.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Icon(
            painter = painterResource(id = R.drawable.logo_dacia),
            contentDescription = "Dacia",
            tint = c,
            modifier = Modifier.size(58.dp)
        )
        Spacer(Modifier.height(5.dp))
        Text("DACIA", color = c, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 2.8.sp)
    }
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Icon(
            painter = painterResource(id = R.drawable.logo_renault),
            contentDescription = "Renault",
            tint = c,
            modifier = Modifier.size(58.dp)
        )
        Spacer(Modifier.height(5.dp))
        Text("RENAULT", color = c, fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.7.sp)
    }
}
