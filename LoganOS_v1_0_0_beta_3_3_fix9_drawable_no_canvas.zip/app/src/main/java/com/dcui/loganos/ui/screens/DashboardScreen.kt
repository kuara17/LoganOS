package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.components.SpeedGauge
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale


private val LoganFuelInstantRed = Color(0xFFE53935)
private val LoganTempColdBlue = Color(0xFF4A78E6)
private val LoganTempWarmAmber = Color(0xFFF39C12)
private val LoganTempNormalGreen = Color(0xFF43A047)
private val LoganFanGreen = Color(0xFF43A047)
private val LoganAcBlue = Color(0xFF2F80ED)

enum class MainTab(val label: String) {
    Cockpit("Kokpit"),
    Trip("Sürüş"),
    Technical("Teknik"),
    Settings("Ayarlar")
}

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Cockpit) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                MainTab.Cockpit -> DashboardContent(palette, settings, snapshot, obdState)
                MainTab.Trip -> TripPage(palette, snapshot)
                MainTab.Technical -> TechnicalPage(palette, snapshot, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onClearLastObdLog, onClearAllObdLogs)
                MainTab.Settings -> SettingsScreen(palette, settings, obdState, onSettingsChange, onResetSetup, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onClearLastObdLog, onClearAllObdLogs)
            }
        }
        BottomNavigationBar(palette, current = tab) { tab = it }
    }
}

@Composable
private fun DashboardContent(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot, obdState: ObdState) {
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        if (maxWidth > maxHeight) {
            DashboardLandscape(palette, settings, snapshot, obdState)
        } else {
            DashboardPortrait(palette, settings, snapshot, obdState)
        }
    }
}

@Composable
private fun DashboardPortrait(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot, obdState: ObdState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        DashboardHeader(palette, snapshot, obdState, settings.demoMode)
        OemCard(palette, modifier = Modifier.fillMaxWidth().heightIn(min = 226.dp, max = 246.dp)) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp), modifier = Modifier.fillMaxWidth()) {
                Text("HIZ", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
                SpeedGauge(
                    palette = palette,
                    speed = snapshot.speedKmh,
                    style = settings.gaugeStyle,
                    modifier = Modifier.fillMaxWidth(.95f).height(188.dp),
                    demoMode = settings.demoMode
                )
                Text("Trip A ${fmt(snapshot.tripDistanceKm, "km")}  •  ODO ${snapshot.odometerKm?.let { "$it km" } ?: "--"}", color = palette.textSecondary, fontSize = 11.sp)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", subtitle = "Sürüş ort.", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(82.dp))
            DataCard(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, subtitle = "Canlı", accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(82.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", subtitle = "Trip", accent = palette.blue, icon = CardIcon.Distance, modifier = Modifier.weight(1f).height(82.dp))
            DataCard(palette, "Sürüş Maliyeti", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, subtitle = settings.fuelPriceText.ifBlank { "Yakıt fiyatı" }, accent = palette.warning, icon = CardIcon.Cost, modifier = Modifier.weight(1f).height(82.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            TemperatureCard(palette, snapshot, Modifier.weight(1f).height(88.dp))
            FanCard(palette, snapshot, Modifier.weight(1f).height(88.dp))
            ClimateCard(palette, snapshot, Modifier.weight(1f).height(88.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", accent = palette.accent, subtitle = "Motor devri", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(82.dp))
            DataCard(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", accent = palette.accent, subtitle = "Trip süresi", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(82.dp))
        }
    }
}

@Composable
private fun DashboardLandscape(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot, obdState: ObdState) {
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column(modifier = Modifier.weight(.95f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DashboardHeader(palette, snapshot, obdState, settings.demoMode)
            OemCard(palette, modifier = Modifier.fillMaxWidth().weight(1f)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center, modifier = Modifier.fillMaxSize()) {
                    Text("HIZ", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 14.sp)
                    SpeedGauge(palette, snapshot.speedKmh, settings.gaugeStyle, modifier = Modifier.fillMaxHeight(.68f).aspectRatio(1f), demoMode = settings.demoMode)
                    Text("Trip A ${fmt(snapshot.tripDistanceKm, "km")}  •  ODO ${snapshot.odometerKm?.let { "$it km" } ?: "--"}", color = palette.textSecondary, fontSize = 11.sp)
                }
            }
        }
        Column(modifier = Modifier.weight(1.15f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).fillMaxHeight())
                DataCard(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).fillMaxHeight())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", accent = palette.blue, icon = CardIcon.Distance, modifier = Modifier.weight(1f).fillMaxHeight())
                DataCard(palette, "Maliyet", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, accent = palette.warning, icon = CardIcon.Cost, modifier = Modifier.weight(1f).fillMaxHeight())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                TemperatureCard(palette, snapshot, Modifier.weight(1f).fillMaxHeight())
                FanCard(palette, snapshot, Modifier.weight(1f).fillMaxHeight())
                ClimateCard(palette, snapshot, Modifier.weight(1f).fillMaxHeight())
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.weight(1f)) {
                DataCard(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).fillMaxHeight())
                DataCard(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", subtitle = "Trip", icon = CardIcon.Time, modifier = Modifier.weight(1f).fillMaxHeight())
            }
        }
    }
}

@Composable
private fun DashboardHeader(palette: LoganPalette, snapshot: DashboardSnapshot, obdState: ObdState, demoMode: Boolean) {
    Row(
        modifier = Modifier.fillMaxWidth().height(42.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        LoganWordmark(palette, compact = true)
        Column(horizontalAlignment = Alignment.End) {
            val status = when {
                demoMode -> "Demo Modu"
                snapshot.connected -> "OBD Bağlı"
                obdState.connecting -> "Bağlanıyor"
                else -> "OBD Bekleniyor"
            }
            val sub = when {
                demoMode -> "Gerçek veri değil"
                snapshot.connected -> obdState.timingText.ifBlank { "KWP aktif" }
                obdState.connecting -> "Bluetooth / KWP"
                else -> "Bluetooth bekleniyor"
            }
            Text(status, color = if (snapshot.connected) palette.accent else if (demoMode) palette.warning else palette.textSecondary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(sub, color = palette.textSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun TemperatureCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp < 50 -> LoganTempColdBlue
        temp < 80 -> LoganTempWarmAmber
        temp <= 96 -> LoganTempNormalGreen
        else -> palette.critical
    }
    DataCard(
        palette = palette,
        title = "Hararet",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = tempColor,
        subtitle = "Soğutma suyu",
        icon = CardIcon.Temperature,
        modifier = modifier
    )
}

@Composable
private fun FanCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    val on = snapshot.radiatorFanOn
    DataCard(
        palette = palette,
        title = "Fan",
        value = on?.let { if (it) "ON" else "OFF" } ?: "--",
        accent = if (on == true) LoganFanGreen else palette.textSecondary,
        subtitle = "Radyatör",
        icon = CardIcon.Fan,
        modifier = modifier
    )
}

@Composable
private fun ClimateCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    val label = snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--"
    DataCard(
        palette = palette,
        title = "Klima",
        value = label,
        accent = if (snapshot.acOn == true) LoganAcBlue else palette.textSecondary,
        subtitle = "A/C durumu",
        icon = CardIcon.Ac,
        modifier = modifier
    )
}

@Composable
private fun BottomNavigationBar(palette: LoganPalette, current: MainTab, onSelect: (MainTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(palette.surface)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        MainTab.entries.forEach { tab ->
            val selected = current == tab
            Text(
                text = tab.label,
                color = if (selected) palette.accent else palette.textSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (selected) palette.accent.copy(alpha = .12f) else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun TripPage(palette: LoganPalette, snapshot: DashboardSnapshot) {
    InfoPage(palette, "Sürüş Merkezi", "Güncel yolculuk ve Smart Trip") {
        DataCard(palette, "Güncel Yolculuk", if (snapshot.connected || snapshot.demo) "Aktif" else "Beklemede", subtitle = "Smart Trip bağlantı gelince başlar", icon = CardIcon.Time, modifier = Modifier.fillMaxWidth().height(118.dp))
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", icon = CardIcon.Distance, modifier = Modifier.weight(1f).height(88.dp))
            DataCard(palette, "Yakıt", fmt(snapshot.fuelUsedL), "L", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
        }
        Spacer(Modifier.height(8.dp))
        DataCard(palette, "Yolculuk Özeti", "Hazır değil", subtitle = "Beta 4 Trip Computer ile aktif olacak", modifier = Modifier.fillMaxWidth().height(118.dp))
    }
}

@Composable
private fun TechnicalPage(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onClearLastLog: () -> Unit,
    onClearAllLogs: () -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Teknik Veriler", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("Canlı ECU / decoder verileri ve ham cevaplar", color = palette.textSecondary, fontSize = 13.sp)
        }
        item { TechnicalConnectionStatus(palette, snapshot, obdState) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "RPM", snapshot.rpm?.toString() ?: "--", "d/dk", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Hız", snapshot.speedKmh?.toString() ?: "--", "km/h", icon = CardIcon.Speed, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Hararet", snapshot.engineTempC?.toString() ?: "--", "°C", icon = CardIcon.Temperature, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Akü", snapshot.batteryV?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item { FuelTruthTestPanel(palette, snapshot) }
        item { RawBlock(palette, "21A0", obdState.raw21A0.ifBlank { snapshot.raw21A0 }) }
        item { RawBlock(palette, "21A2", obdState.raw21A2.ifBlank { snapshot.raw21A2 }) }
        item { RawBlock(palette, "21CC", obdState.raw21CC.ifBlank { snapshot.raw21CC }) }
        item { RawBlock(palette, "21CD", obdState.raw21CD.ifBlank { snapshot.raw21CD }) }
        item { RawBlock(palette, "LOG", obdState.logText.takeLast(5000)) }
    }
}


@Composable
private fun TechnicalConnectionStatus(palette: LoganPalette, snapshot: DashboardSnapshot, obdState: ObdState) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("BAĞLANTI DURUMU", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette = palette,
                    label = "OBD",
                    value = if (snapshot.connected || obdState.connected) "Bağlı" else if (obdState.connecting) "Bağlanıyor" else "Bekliyor",
                    color = if (snapshot.connected || obdState.connected) palette.accent else palette.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette = palette,
                    label = "ECU",
                    value = "DCM1.2",
                    color = palette.warning,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Protokol", "KWP Fast Init", palette.blue, Modifier.weight(1f))
                TechnicalStatusItem(palette, "Loop", obdState.timingText.ifBlank { "--" }, palette.accent, Modifier.weight(1f))
            }
            Text(
                if (obdState.lastError != null) "Son hata: ${obdState.lastError}" else "Bağlantı yönetimi: Ayarlar > Bağlantı & Veri",
                color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                fontSize = 11.sp,
                fontWeight = if (obdState.lastError != null) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TechnicalStatusItem(
    palette: LoganPalette,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceVariant.copy(alpha = .34f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(value, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
fun ObdConnectionPanel(
    palette: LoganPalette,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onClearLastLog: () -> Unit = {},
    onClearAllLogs: () -> Unit = {}
) {
    var confirmTitle by remember { mutableStateOf<String?>(null) }
    var confirmMessage by remember { mutableStateOf("") }
    var confirmLabel by remember { mutableStateOf("Tamam") }
    var confirmAction by remember { mutableStateOf<(() -> Unit)?>(null) }

    fun ask(title: String, message: String, label: String, action: () -> Unit) {
        confirmTitle = title
        confirmMessage = message
        confirmLabel = label
        confirmAction = action
    }

    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("OBD BAĞLANTI", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text(
                obdState.status,
                color = if (obdState.lastError != null) palette.critical else if (obdState.connected) palette.accent else palette.textSecondary,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )

            Text("Adaptör", color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
            if (obdState.pairedDevices.isEmpty()) {
                Text("Eşleşmiş cihaz listesi boş. Önce Android Bluetooth ayarlarından vLinker MC+ ile eşleştir.", color = palette.textSecondary, fontSize = 12.sp, lineHeight = 16.sp)
            } else {
                obdState.pairedDevices.forEach { device ->
                    val selected = obdState.selectedAddress == device.address
                    SettingsRow(
                        palette = palette,
                        title = device.name,
                        subtitle = device.address,
                        value = if (selected) "Seçili" else "Seç",
                        onClick = { onSelect(device) }
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onRefresh, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) { Text("Cihazları Tara") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(onClick = onConnect, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) { Text(if (obdState.connecting) "Tekrar Dene" else if (obdState.connected) "OBD’ye Yeniden Bağlan" else "OBD’ye Bağlan") }
                Button(onClick = onDisconnect, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.critical)) { Text("OBD Bağlantısını Kes") }
            }

            Text("LOG & TEST İŞLEMLERİ", color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { ask("Log Dosyası Oluştur", "Mevcut OBD logu Download/LoganOS klasörüne kaydedilecek. Oluşturulsun mu?", "Oluştur") { onSaveLog() } },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.textPrimary)
                ) { Text("Test Logu Kaydet") }
                Button(onClick = onShareLog, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.textPrimary)) { Text("Logu Paylaş") }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = { ask("Son Logu Sil", "Son oluşturulan LoganOS log dosyası silinsin mi?", "Sil") { onClearLastLog() } },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.textPrimary)
                ) { Text("Son Logu Sil") }
                Button(
                    onClick = { ask("Tüm Logları Temizle", "Download/LoganOS klasöründeki LoganOS log dosyaları silinsin mi?", "Temizle") { onClearAllLogs() } },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.textPrimary)
                ) { Text("Tüm Logları Sil") }
            }
            if (obdState.savedLogPath != null) Text("Log: ${obdState.savedLogPath}", color = palette.textSecondary, fontSize = 11.sp, maxLines = 2)
        }
    }

    confirmTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { confirmTitle = null; confirmAction = null },
            title = { Text(title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(confirmMessage, color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmAction?.invoke()
                    confirmTitle = null
                    confirmAction = null
                }) { Text(confirmLabel) }
            },
            dismissButton = { TextButton(onClick = { confirmTitle = null; confirmAction = null }) { Text("İptal") } }
        )
    }
}

@Composable
private fun FuelTruthTestPanel(palette: LoganPalette, snapshot: DashboardSnapshot) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Fuel Truth Test Panel", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Kaynak: ${snapshot.fuelSource}", color = palette.textSecondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Injection", snapshot.injectionMg?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "mg/st", icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(84.dp))
                DataCard(palette, "Tüketim", fmt(snapshot.instantConsumption), snapshot.instantUnit, accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(84.dp))
            }
            Text("Beta 3 test panelidir. Değerler doğrulanmadan ana yol bilgisayarı kabul edilmeyecek.", color = palette.textSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun RawBlock(palette: LoganPalette, title: String, raw: String) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(raw.ifBlank { "--" }, color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun InfoPage(palette: LoganPalette, title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

private fun fmt(value: Double?, suffix: String? = null): String {
    val base = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"
    return if (suffix == null) base else "$base $suffix"
}
