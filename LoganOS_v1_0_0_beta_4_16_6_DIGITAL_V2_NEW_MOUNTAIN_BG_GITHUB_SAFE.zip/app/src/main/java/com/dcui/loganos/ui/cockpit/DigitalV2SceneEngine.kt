package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import com.dcui.loganos.R
import com.dcui.loganos.ui.components.rememberScenicMotionPhases
import kotlin.math.PI
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Digital V2 uses one fixed stage coordinate space for every scene.
 * New scene assets must be exported at the same aspect ratio and obey the
 * same road contract. This removes device-dependent ContentScale.Crop drift.
 */
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO = 1080f / 1320f

internal data class DigitalV2RoadSlice(
    val y: Float,
    val leftX: Float,
    val rightX: Float
)

internal data class DigitalV2SceneSpec(
    val backgroundRes: Int,
    val stageAspectRatio: Float,
    val roadSlices: List<DigitalV2RoadSlice>,
    val vehicleContactY: Float,
    val vehicleVisibleWidthToRoadWidth: Float,
    val vehicleAssetVisibleWidthRatio: Float = 0.864f,
    val vehicleAssetContactYRatio: Float = 0.906f
) {
    init {
        require(stageAspectRatio > 0f)
        require(roadSlices.size >= 4)
        require(roadSlices.zipWithNext().all { (a, b) -> b.y > a.y })
        require(roadSlices.all { it.leftX < it.rightX })
        require(vehicleContactY in roadSlices.first().y..roadSlices.last().y)
    }

    fun roadAt(y: Float): DigitalV2RoadSlice {
        val clampedY = y.coerceIn(roadSlices.first().y, roadSlices.last().y)
        val segment = roadSlices.indexOfLast { it.y <= clampedY }
            .coerceIn(0, roadSlices.lastIndex - 1)
        val a = roadSlices[segment]
        val b = roadSlices[segment + 1]
        val dy = (b.y - a.y).coerceAtLeast(0.0001f)
        val t = ((clampedY - a.y) / dy).coerceIn(0f, 1f)

        fun valueAt(index: Int, selector: (DigitalV2RoadSlice) -> Float): Float {
            val i0 = (index - 1).coerceAtLeast(0)
            val i1 = index
            val i2 = (index + 1).coerceAtMost(roadSlices.lastIndex)
            val i3 = (index + 2).coerceAtMost(roadSlices.lastIndex)
            val p0 = selector(roadSlices[i0])
            val p1 = selector(roadSlices[i1])
            val p2 = selector(roadSlices[i2])
            val p3 = selector(roadSlices[i3])
            val t2 = t * t
            val t3 = t2 * t
            return 0.5f * (
                (2f * p1) +
                    (-p0 + p2) * t +
                    (2f * p0 - 5f * p1 + 4f * p2 - p3) * t2 +
                    (-p0 + 3f * p1 - 3f * p2 + p3) * t3
                )
        }

        val left = valueAt(segment) { it.leftX }
        val right = valueAt(segment) { it.rightX }
        return DigitalV2RoadSlice(
            y = clampedY,
            leftX = left.coerceIn(-0.08f, 1.08f),
            rightX = right.coerceIn(-0.08f, 1.08f)
        )
    }
}

/**
 * The approved mountain-lake scene. Coordinates are normalized to the fixed
 * 1080x1320 stage and measured from the exported asset, not guessed in dp.
 */
internal val DigitalV2MountainLakeSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_mountain_lake_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    roadSlices = listOf(
        DigitalV2RoadSlice(0.690f, 0.603f, 0.680f),
        DigitalV2RoadSlice(0.720f, 0.581f, 0.712f),
        DigitalV2RoadSlice(0.760f, 0.542f, 0.758f),
        DigitalV2RoadSlice(0.800f, 0.490f, 0.816f),
        DigitalV2RoadSlice(0.840f, 0.401f, 0.888f),
        DigitalV2RoadSlice(0.880f, 0.283f, 0.968f),
        DigitalV2RoadSlice(0.920f, 0.151f, 1.010f),
        DigitalV2RoadSlice(0.960f, 0.038f, 1.040f),
        DigitalV2RoadSlice(1.000f, -0.030f, 1.050f)
    ),
    vehicleContactY = 0.915f,
    vehicleVisibleWidthToRoadWidth = 0.345f
)

internal data class DigitalV2SceneMotion(
    val moving: Boolean,
    val roadPhase: Float,
    val motionStrength: Float,
    val suspensionLift: Float,
    val swayWave: Float,
    val shadowScaleX: Float,
    val shadowScaleY: Float,
    val shadowAlpha: Float
)

@Composable
internal fun rememberDigitalV2SceneMotion(
    speedKmh: Int?,
    enabled: Boolean
): DigitalV2SceneMotion {
    val currentSpeed = speedKmh ?: 0
    val scenic = rememberScenicMotionPhases(speedKmh = speedKmh, enabled = enabled)
    val moving = enabled && currentSpeed >= 5
    val motionStrength = when {
        !moving -> 0f
        currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
        currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
        currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
        else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
    }.coerceIn(0f, 1f)

    val dynamicsAngle = scenic.dynamicsTime * 2f * PI.toFloat()
    val bobWave = if (moving) {
        val primary = sin(dynamicsAngle.toDouble()).toFloat()
        val secondary = 0.30f * sin((dynamicsAngle * 2.70f + 0.62f).toDouble()).toFloat()
        val bodySettle = 0.14f * sin((dynamicsAngle * 0.57f + 1.38f).toDouble()).toFloat()
        (primary + secondary + bodySettle) / 1.44f
    } else {
        0f
    }
    val asphaltMicroWave = if (moving) {
        val coarse = sin((dynamicsAngle * 12f + 0.20f).toDouble()).toFloat()
        val fine = sin((dynamicsAngle * 18.40f + 1.15f).toDouble()).toFloat()
        (coarse * 0.68f + fine * 0.32f) * (0.08f + 0.07f * motionStrength)
    } else {
        0f
    }
    val suspensionLift = (bobWave + asphaltMicroWave).coerceIn(-1.20f, 1.20f)
    val swayWave = if (moving) {
        val slowWeightShift = 0.68f * sin((dynamicsAngle * 0.71f + 0.85f).toDouble()).toFloat()
        val secondaryRoll = 0.22f * sin((dynamicsAngle * 1.93f + 2.10f).toDouble()).toFloat()
        val roadCorrection = 0.10f * sin((dynamicsAngle * 4.40f + 0.22f).toDouble()).toFloat()
        slowWeightShift + secondaryRoll + roadCorrection
    } else {
        0f
    }

    return DigitalV2SceneMotion(
        moving = moving,
        roadPhase = scenic.roadPhase,
        motionStrength = motionStrength,
        suspensionLift = suspensionLift,
        swayWave = swayWave,
        shadowScaleX = (1f + suspensionLift * 0.013f).coerceIn(0.984f, 1.018f),
        shadowScaleY = (1f + suspensionLift * 0.006f).coerceIn(0.992f, 1.009f),
        shadowAlpha = (0.94f - suspensionLift * 0.10f).coerceIn(0.80f, 1f)
    )
}

private data class RoadFrame(
    val point: Offset,
    val tangent: Offset,
    val roadWidthPx: Float,
    val yNorm: Float,
    val cumulativePx: Float
)

private fun buildRoadFrames(
    spec: DigitalV2SceneSpec,
    widthPx: Float,
    heightPx: Float,
    sampleCount: Int = 160
): List<RoadFrame> {
    val yStart = spec.roadSlices.first().y
    val yEnd = spec.roadSlices.last().y
    val raw = ArrayList<RoadFrame>(sampleCount + 1)
    var cumulative = 0f
    var previousPoint: Offset? = null

    repeat(sampleCount + 1) { index ->
        val t = index / sampleCount.toFloat()
        val y = yStart + (yEnd - yStart) * t
        val road = spec.roadAt(y)
        val centerX = (road.leftX + road.rightX) * 0.5f
        val point = Offset(centerX * widthPx, y * heightPx)
        previousPoint?.let { previous ->
            val dx = point.x - previous.x
            val dy = point.y - previous.y
            cumulative += sqrt((dx * dx + dy * dy).toDouble()).toFloat()
        }
        raw += RoadFrame(
            point = point,
            tangent = Offset.Zero,
            roadWidthPx = (road.rightX - road.leftX) * widthPx,
            yNorm = y,
            cumulativePx = cumulative
        )
        previousPoint = point
    }

    return raw.mapIndexed { index, frame ->
        val before = raw[(index - 1).coerceAtLeast(0)].point
        val after = raw[(index + 1).coerceAtMost(raw.lastIndex)].point
        val dx = after.x - before.x
        val dy = after.y - before.y
        val length = sqrt((dx * dx + dy * dy).toDouble()).toFloat().coerceAtLeast(0.001f)
        frame.copy(tangent = Offset(dx / length, dy / length))
    }
}

private fun frameAtArc(frames: List<RoadFrame>, normalizedArc: Float): RoadFrame {
    val total = frames.last().cumulativePx.coerceAtLeast(1f)
    val target = normalizedArc.coerceIn(0f, 1f) * total
    var low = 0
    var high = frames.lastIndex
    while (low < high) {
        val mid = (low + high) ushr 1
        if (frames[mid].cumulativePx < target) low = mid + 1 else high = mid
    }
    val upperIndex = low.coerceIn(1, frames.lastIndex)
    val lower = frames[upperIndex - 1]
    val upper = frames[upperIndex]
    val span = (upper.cumulativePx - lower.cumulativePx).coerceAtLeast(0.001f)
    val t = ((target - lower.cumulativePx) / span).coerceIn(0f, 1f)
    fun lerp(a: Float, b: Float) = a + (b - a) * t
    val tangentX = lerp(lower.tangent.x, upper.tangent.x)
    val tangentY = lerp(lower.tangent.y, upper.tangent.y)
    val tangentLength = sqrt((tangentX * tangentX + tangentY * tangentY).toDouble()).toFloat().coerceAtLeast(0.001f)
    return RoadFrame(
        point = Offset(lerp(lower.point.x, upper.point.x), lerp(lower.point.y, upper.point.y)),
        tangent = Offset(tangentX / tangentLength, tangentY / tangentLength),
        roadWidthPx = lerp(lower.roadWidthPx, upper.roadWidthPx),
        yNorm = lerp(lower.yNorm, upper.yNorm),
        cumulativePx = target
    )
}

@Composable
internal fun DigitalV2RoadLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val frames = buildRoadFrames(spec, size.width, size.height)
        val leftEdge = Path()
        val rightEdgePoints = ArrayList<Offset>(frames.size)
        frames.forEachIndexed { index, frame ->
            val road = spec.roadAt(frame.yNorm)
            val left = Offset(road.leftX * size.width, frame.yNorm * size.height)
            val right = Offset(road.rightX * size.width, frame.yNorm * size.height)
            if (index == 0) leftEdge.moveTo(left.x, left.y) else leftEdge.lineTo(left.x, left.y)
            rightEdgePoints += right
        }
        rightEdgePoints.asReversed().forEach { right -> leftEdge.lineTo(right.x, right.y) }
        leftEdge.close()

        clipPath(leftEdge) {
            val activePhase = if (motion.moving) motion.roadPhase else 0f
            val dashCount = 8
            repeat(dashCount) { index ->
                val arc = ((index / dashCount.toFloat()) + activePhase) % 1f
                val frame = frameAtArc(frames, arc)
                val depth = ((frame.yNorm - spec.roadSlices.first().y) /
                    (spec.roadSlices.last().y - spec.roadSlices.first().y)).coerceIn(0f, 1f)
                val dashArcLength = (0.018f + 0.050f * depth.pow(1.7f)).coerceAtMost(0.085f)
                val endArc = (arc + dashArcLength).coerceAtMost(0.995f)
                if (endArc > arc) {
                    val dash = Path()
                    repeat(6) { step ->
                        val s = arc + (endArc - arc) * (step / 5f)
                        val p = frameAtArc(frames, s).point
                        if (step == 0) dash.moveTo(p.x, p.y) else dash.lineTo(p.x, p.y)
                    }
                    val edgeFade = sin((arc * PI).toDouble()).toFloat().coerceAtLeast(0f).pow(0.55f)
                    val alphaBase = if (motion.moving) 0.34f + 0.54f * depth else 0.46f + 0.22f * depth
                    val alpha = (alphaBase * edgeFade * if (motion.moving) motion.motionStrength.coerceAtLeast(0.48f) else 1f)
                        .coerceIn(0f, 0.92f)
                    val width = (frame.roadWidthPx * (0.0062f + 0.0052f * depth)).coerceAtLeast(1f)
                    drawPath(
                        path = dash,
                        color = Color(0xFFFFD65C).copy(alpha = alpha),
                        style = Stroke(width = width, cap = StrokeCap.Round)
                    )
                    drawPath(
                        path = dash,
                        color = Color(0xFFFFF3B8).copy(alpha = alpha * 0.32f),
                        style = Stroke(width = (width * 0.32f).coerceAtLeast(0.8f), cap = StrokeCap.Round)
                    )
                }
            }

            if (motion.moving) {
                listOf(-0.44f, -0.24f, 0.24f, 0.44f).forEachIndexed { laneIndex, lateral ->
                    repeat(5) { index ->
                        val arc = ((index / 5f) + motion.roadPhase + laneIndex * 0.049f) % 1f
                        val frame = frameAtArc(frames, arc)
                        val depth = ((frame.yNorm - spec.roadSlices.first().y) /
                            (spec.roadSlices.last().y - spec.roadSlices.first().y)).coerceIn(0f, 1f)
                        if (depth > 0.10f) {
                            val endArc = (arc + 0.012f + 0.045f * depth).coerceAtMost(0.995f)
                            if (endArc > arc) {
                                val start = Offset(
                                    frame.point.x + frame.roadWidthPx * lateral * 0.5f,
                                    frame.point.y
                                )
                                val endFrame = frameAtArc(frames, endArc)
                                val end = Offset(
                                    endFrame.point.x + endFrame.roadWidthPx * lateral * 0.5f,
                                    endFrame.point.y
                                )
                                drawLine(
                                    color = Color(0xFFE8EDF1).copy(
                                        alpha = ((0.010f + 0.055f * depth) * motion.motionStrength).coerceAtMost(0.075f)
                                    ),
                                    start = start,
                                    end = end,
                                    strokeWidth = (0.45.dp.toPx() + 1.25.dp.toPx() * depth),
                                    cap = StrokeCap.Round
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
internal fun DigitalV2WindLayer(
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        if (!motion.moving || motion.motionStrength <= 0.02f) return@Canvas

        fun buildSceneryWindClip(left: Boolean): Path = Path().apply {
            val topY = size.height * 0.48f
            val shoulderY = size.height * 0.55f
            val lowerY = size.height * 0.70f
            val bottomY = size.height * 0.80f
            if (left) {
                moveTo(size.width * 0.018f, topY)
                cubicTo(
                    size.width * 0.070f,
                    topY - size.height * 0.016f,
                    size.width * 0.165f,
                    topY - size.height * 0.004f,
                    size.width * 0.205f,
                    shoulderY
                )
                lineTo(size.width * 0.225f, lowerY)
                lineTo(size.width * 0.215f, bottomY)
                lineTo(size.width * 0.018f, bottomY)
            } else {
                moveTo(size.width * 0.982f, topY)
                cubicTo(
                    size.width * 0.930f,
                    topY - size.height * 0.016f,
                    size.width * 0.835f,
                    topY - size.height * 0.004f,
                    size.width * 0.795f,
                    shoulderY
                )
                lineTo(size.width * 0.775f, lowerY)
                lineTo(size.width * 0.785f, bottomY)
                lineTo(size.width * 0.982f, bottomY)
            }
            close()
        }

        fun drawSceneryWind(left: Boolean) {
            val clip = buildSceneryWindClip(left)
            val sideOffset = if (left) 0.04f else 0.12f
            val direction = if (left) -1f else 1f
            val windStrength = (0.56f + 0.44f * motion.motionStrength).coerceIn(0f, 1f)

            clipPath(clip) {
                repeat(6) { index ->
                    val variant = index % 3
                    val phaseJitter = when (variant) {
                        0 -> 0.000f
                        1 -> 0.037f
                        else -> 0.081f
                    }
                    val thicknessVariance = when (variant) {
                        0 -> 0.78f
                        1 -> 1.08f
                        else -> 0.92f
                    }
                    val waveVariance = when (variant) {
                        0 -> 0.68f
                        1 -> 1.18f
                        else -> 0.92f
                    }
                    val lengthVariance = when (variant) {
                        0 -> 0.88f
                        1 -> 1.12f
                        else -> 1.00f
                    }

                    val phase = (
                        motion.roadPhase * (0.88f + 0.05f * variant) +
                            index / 6f + sideOffset + phaseJitter
                        ) % 1f
                    val flow = phase.coerceIn(0f, 1f).pow(1.30f)
                    val fade = sin((phase * PI.toFloat()).toDouble()).toFloat().coerceAtLeast(0f).pow(4.0f)
                    val primaryWave = sin(
                        (motion.roadPhase * (5.60f + variant * 0.73f) + index * 0.94f + sideOffset * 4f).toDouble()
                    ).toFloat()
                    val secondaryWave = sin(
                        (motion.roadPhase * (11.30f + variant * 0.41f) + index * 1.77f + 0.45f).toDouble()
                    ).toFloat()
                    val laneWave = (primaryWave + secondaryWave * 0.28f) * waveVariance
                    val headX = if (left) size.width * (0.225f - 0.190f * flow) else size.width * (0.775f + 0.190f * flow)
                    val length = size.width * (0.052f + 0.082f * flow) * lengthVariance
                    val tailX = headX - direction * length
                    val baseY = size.height * (0.532f + 0.174f * flow + variant * 0.011f)
                    val tailY = baseY - size.height * (0.0025f + 0.0045f * laneWave)
                    val headY = baseY + size.height * (0.005f + 0.008f * flow)
                    val curveLift = size.height * (0.007f + 0.004f * flow + 0.0035f * laneWave)
                    val gust = Path().apply {
                        moveTo(tailX, tailY)
                        cubicTo(
                            tailX + direction * length * 0.31f,
                            tailY - curveLift,
                            tailX + direction * length * 0.74f,
                            headY + curveLift * 0.48f,
                            headX,
                            headY
                        )
                    }

                    val alpha = ((0.34f + 0.08f * thicknessVariance) * fade * windStrength).coerceAtMost(0.45f)
                    val coreWidth = (0.58.dp.toPx() + 0.92.dp.toPx() * flow) * thicknessVariance
                    drawPath(
                        path = gust,
                        color = Color(0xFFDDEEFF).copy(alpha = alpha * 0.04f),
                        style = Stroke(width = coreWidth * 8f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color(0xFFEAF5FF).copy(alpha = alpha * 0.12f),
                        style = Stroke(width = coreWidth * 3f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color.White.copy(alpha = alpha * 0.25f),
                        style = Stroke(width = coreWidth * 0.60f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                }
            }
        }

        drawSceneryWind(left = true)
        drawSceneryWind(left = false)
    }
}

@Composable
internal fun DigitalV2CalibrationOverlay(
    spec: DigitalV2SceneSpec,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    if (!enabled) return
    Canvas(modifier) {
        repeat(11) { index ->
            val x = size.width * index / 10f
            val y = size.height * index / 10f
            drawLine(Color.Red.copy(alpha = 0.38f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(Color.Yellow.copy(alpha = 0.38f), Offset(0f, y), Offset(size.width, y), 1f)
        }
        val left = Path()
        val center = Path()
        val right = Path()
        repeat(100) { index ->
            val y = spec.roadSlices.first().y +
                (spec.roadSlices.last().y - spec.roadSlices.first().y) * index / 99f
            val road = spec.roadAt(y)
            val leftP = Offset(road.leftX * size.width, y * size.height)
            val centerP = Offset((road.leftX + road.rightX) * 0.5f * size.width, y * size.height)
            val rightP = Offset(road.rightX * size.width, y * size.height)
            if (index == 0) {
                left.moveTo(leftP.x, leftP.y)
                center.moveTo(centerP.x, centerP.y)
                right.moveTo(rightP.x, rightP.y)
            } else {
                left.lineTo(leftP.x, leftP.y)
                center.lineTo(centerP.x, centerP.y)
                right.lineTo(rightP.x, rightP.y)
            }
        }
        drawPath(left, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(right, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(center, Color.Cyan, style = Stroke(2.dp.toPx()))
        val contact = spec.roadAt(spec.vehicleContactY)
        val centerX = (contact.leftX + contact.rightX) * 0.5f * size.width
        val contactY = spec.vehicleContactY * size.height
        drawCircle(Color.Magenta, 6.dp.toPx(), Offset(centerX, contactY))
    }
}

