package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.theme.LoganPalette

enum class SettingsCategory(val title: String, val desc: String) {
    Language("Dil", "Türkçe / English"),
    AppearanceCockpit("Görünüm & Kokpit", "Tema, vurgu rengi, gösterge stili"),
    DriveFuel("Sürüş & Yakıt", "Yakıt fiyatı, kalibrasyon, tüketim"),
    VehicleMaintenance("Araç & Bakım", "Profil, kilometre, bakım aralıkları"),
    Connection("Bağlantı", "Bluetooth ve OBD adaptörü"),
    TripRecords("Sürüş ve Kayıtlar", "Smart Trip, geçmiş, dışa aktarma"),
    Developer("Geliştirici", "Testler, ham log, debug"),
    About("Hakkında", "Sürüm, lisans, proje bilgisi")
}

private fun categoryTitle(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.title
    return when (category) {
        SettingsCategory.Language -> "Language"
        SettingsCategory.AppearanceCockpit -> "Appearance & Cockpit"
        SettingsCategory.DriveFuel -> "Trip & Fuel"
        SettingsCategory.VehicleMaintenance -> "Vehicle & Maintenance"
        SettingsCategory.Connection -> "Connection"
        SettingsCategory.TripRecords -> "Trips & Records"
        SettingsCategory.Developer -> "Developer"
        SettingsCategory.About -> "About"
    }
}

private fun categoryDesc(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.desc
    return when (category) {
        SettingsCategory.Language -> "Turkish / English"
        SettingsCategory.AppearanceCockpit -> "Theme, accent color, gauge style"
        SettingsCategory.DriveFuel -> "Fuel price, calibration, consumption"
        SettingsCategory.VehicleMaintenance -> "Profile, odometer, service intervals"
        SettingsCategory.Connection -> "Bluetooth and OBD adapter"
        SettingsCategory.TripRecords -> "Smart Trip, history, export"
        SettingsCategory.Developer -> "Tests, raw log, debug"
        SettingsCategory.About -> "Version, license, project info"
    }
}

private fun tx(language: AppLanguage, tr: String, en: String): String =
    if (language == AppLanguage.English) en else tr

private sealed class SettingsDialog {
    data class Options(val title: String, val options: List<String>, val onSelect: (String) -> Unit) : SettingsDialog()
    data class TextInput(val title: String, val initial: String, val hint: String, val onSave: (String) -> Unit) : SettingsDialog()
    data class Calibration(
        val appLiters: String,
        val pumpLiters: String,
        val currentFactor: Double,
        val enabled: Boolean,
        val onSave: (String, String, Double) -> Unit,
        val onDisable: () -> Unit,
        val onReset: () -> Unit
    ) : SettingsDialog()
    data class Info(val title: String, val message: String) : SettingsDialog()
    data class Confirm(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit) : SettingsDialog()
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onExportAllHistory: () -> Unit
) {
    var selected by remember { mutableStateOf(SettingsCategory.Connection) }
    var portraitPage by remember { mutableStateOf<SettingsCategory?>(null) }
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }

    BackHandler(enabled = portraitPage != null) {
        portraitPage = null
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSideMenu(palette, selected, settings.language, onSelect = { selected = it }, modifier = Modifier.width(220.dp).fillMaxHeight())
                SettingsContent(
                    palette = palette,
                    category = selected,
                    settings = settings,
                    obdState = obdState,
                    onSettingsChange = onSettingsChange,
                    onResetSetup = onResetSetup,
                    onResetMetrics = onResetMetrics,
                    onEndTripNow = onEndTripNow,
                    onRefreshObdDevices = onRefreshObdDevices,
                    onSelectObdDevice = onSelectObdDevice,
                    onConnectObd = onConnectObd,
                    onDisconnectObd = onDisconnectObd,
                    onSaveObdLog = onSaveObdLog,
                    onShareObdLog = onShareObdLog,
                    onCreateSupportPackage = onCreateSupportPackage,
                    onClearLastObdLog = onClearLastObdLog,
                    onClearAllObdLogs = onClearAllObdLogs,
                    onDeveloperTestStart = onDeveloperTestStart,
                    onDeveloperTestEnd = onDeveloperTestEnd,
                    onRefreshHistory = onRefreshHistory,
                    onExportAllHistory = onExportAllHistory,
                    openDialog = { dialog = it },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        } else {
            AnimatedContent(
                targetState = portraitPage,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally(animationSpec = tween(250)) { it } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeOut(animationSpec = tween(180)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { it } + fadeOut(animationSpec = tween(180)))
                    }
                },
                label = "settingsPortraitNav"
            ) { page ->
                if (page == null) {
                    SettingsCategoryList(palette = palette, language = settings.language, onOpen = {
                        selected = it
                        portraitPage = it
                    })
                } else {
                    SettingsDetailPage(
                        palette = palette,
                        category = page,
                        settings = settings,
                        obdState = obdState,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetMetrics = onResetMetrics,
                        onEndTripNow = onEndTripNow,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onCreateSupportPackage = onCreateSupportPackage,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        onRefreshHistory = onRefreshHistory,
                        onExportAllHistory = onExportAllHistory,
                        openDialog = { dialog = it },
                        onBack = { portraitPage = null }
                    )
                }
            }
        }
    }

    dialog?.let { current ->
        when (current) {
            is SettingsDialog.Options -> OptionDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.TextInput -> TextInputDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Calibration -> FuelCalibrationDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Info -> InfoDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Confirm -> ConfirmDialog(palette, current, settings.language) { dialog = null }
        }
    }
}

@Composable
private fun SettingsCategoryList(palette: LoganPalette, language: AppLanguage, onOpen: (SettingsCategory) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
        }
        SettingsCategory.entries.forEach { cat ->
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth(), onClick = { onOpen(cat) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(categoryTitle(cat, language), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text("›", color = palette.textSecondary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSideMenu(palette: LoganPalette, selected: SettingsCategory, language: AppLanguage, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(modifier = modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (active) palette.accent.copy(alpha = .12f) else palette.surface)
                    .clickable { onSelect(cat) }
                    .padding(12.dp)
            ) {
                Text(categoryTitle(cat, language), color = if (active) palette.accent else palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCompactSideMenu(palette: LoganPalette, selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .padding(vertical = 10.dp, horizontal = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("☰", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            val icon = when (cat) {
                SettingsCategory.Language -> CardIcon.Time
                SettingsCategory.AppearanceCockpit -> CardIcon.Speed
                SettingsCategory.DriveFuel -> CardIcon.Cost
                SettingsCategory.VehicleMaintenance -> CardIcon.Temperature
                SettingsCategory.Connection -> CardIcon.ObdConnection
                SettingsCategory.TripRecords -> CardIcon.Time
                SettingsCategory.Developer -> CardIcon.Injection
                SettingsCategory.About -> CardIcon.Time
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) palette.accent else palette.surfaceVariant)
                    .clickable { onSelect(cat) },
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(
                    palette = palette,
                    icon = icon,
                    tint = if (active) palette.background else palette.textSecondary,
                    modifier = Modifier.size(27.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDetailPage(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = if (settings.language == AppLanguage.English) "‹ Settings" else "‹ Ayarlar",
            color = palette.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
        )
        SettingsContent(
            palette = palette,
            category = category,
            settings = settings,
            obdState = obdState,
            onSettingsChange = onSettingsChange,
            onResetSetup = onResetSetup,
            onResetMetrics = onResetMetrics,
            onEndTripNow = onEndTripNow,
            onRefreshObdDevices = onRefreshObdDevices,
            onSelectObdDevice = onSelectObdDevice,
            onConnectObd = onConnectObd,
            onDisconnectObd = onDisconnectObd,
            onSaveObdLog = onSaveObdLog,
            onShareObdLog = onShareObdLog,
            onCreateSupportPackage = onCreateSupportPackage,
            onClearLastObdLog = onClearLastObdLog,
            onClearAllObdLogs = onClearAllObdLogs,
            onDeveloperTestStart = onDeveloperTestStart,
            onDeveloperTestEnd = onDeveloperTestEnd,
            onRefreshHistory = onRefreshHistory,
            onExportAllHistory = onExportAllHistory,
            openDialog = openDialog,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun SettingsContent(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    modifier: Modifier
) {
    fun openFuelCalibrationDialog() {
        openDialog(
            SettingsDialog.Calibration(
                appLiters = settings.fuelCalibrationAppLitersText,
                pumpLiters = settings.fuelCalibrationPumpLitersText,
                currentFactor = settings.fuelCalibrationFactor,
                enabled = settings.fuelCalibrationEnabled,
                onSave = { appLiters, pumpLiters, factor ->
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = true,
                            fuelCalibrationFactor = factor,
                            fuelCalibrationAppLitersText = appLiters,
                            fuelCalibrationPumpLitersText = pumpLiters,
                            fuelCalibrationWarningAccepted = true
                        )
                    )
                },
                onDisable = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) },
                onReset = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = false,
                            fuelCalibrationFactor = 1.0,
                            fuelCalibrationAppLitersText = "",
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                }
            )
        )
    }

    fun openFuelCalibrationFlow() {
        if (settings.fuelCalibrationWarningAccepted) {
            openFuelCalibrationDialog()
        } else {
            openDialog(
                SettingsDialog.Confirm(
                    title = tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                    message = tx(
                        settings.language,
                        "Bu özellik, pompa dolumuna göre yakıt hesabını ince ayarlar.\n\nGirilen litre bilgisi hatalı olursa tüketim ve maliyet hesabı sapabilir. İstediğiniz zaman fabrika hesabına dönebilirsiniz.",
                        "This feature fine-tunes LoganOS fuel consumption based on full-tank refueling.\n\nIncorrect liter values can affect consumption and cost calculations. You can return to the factory calculation at any time."
                    ),
                    confirmLabel = tx(settings.language, "Anladım, devam et", "I understand, continue"),
                    onConfirm = {
                        onSettingsChange(settings.copy(fuelCalibrationWarningAccepted = true))
                        openFuelCalibrationDialog()
                    }
                )
            )
        }
    }

    OemCard(palette, modifier = modifier.fillMaxWidth()) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            item {
                Text(categoryTitle(category, settings.language), color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(categoryDesc(category, settings.language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.sp)
            }
            item { Spacer(Modifier.height(4.dp)) }
            when (category) {
                SettingsCategory.Language -> {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "Türkçe",
                            subtitle = "Uygulamayı Türkçe kullan",
                            value = if (settings.language == AppLanguage.Turkish) "✓ Seçili" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.Turkish)) }
                        )
                    }
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "English",
                            subtitle = "Use LoganOS in English",
                            value = if (settings.language == AppLanguage.English) "✓ Selected" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.English)) }
                        )
                    }
                }
                SettingsCategory.AppearanceCockpit -> {
                    item { SettingsRow(palette, tx(settings.language, "Koyu Tema", "Dark Theme"), tx(settings.language, "OEM Dark görünümü", "OEM dark appearance"), trailingSwitch = settings.darkMode, onSwitch = { onSettingsChange(settings.copy(darkMode = it)) }) }
                    item { SettingsRow(palette, tx(settings.language, "Vurgu Rengi", "Accent Color"), tx(settings.language, "Tüm LOGANOS vurgu rengi", "Main LOGANOS accent color"), settings.accentColor.label, onClick = { openDialog(SettingsDialog.Options(tx(settings.language, "Vurgu Rengi", "Accent Color"), AccentColor.entries.map { it.label }) { label -> AccentColor.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(accentColor = it)) } }) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Cihaz Kullanım Modu", "Device Usage Mode"),
                            tx(settings.language, "Otomatik algıla veya Telefon / Double seçimini zorla", "Auto-detect or force Phone / Head Unit mode"),
                            deviceModeLabel(settings.deviceMode, settings.language),
                            onClick = {
                                val options = DeviceMode.entries.map { deviceModeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Cihaz Kullanım Modu", "Device Usage Mode"), options) { label ->
                                    DeviceMode.entries.firstOrNull { deviceModeLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(deviceMode = it))
                                    }
                                })
                            }
                        )
                    }
                    item { SettingsRow(palette, tx(settings.language, "Gösterge Stili", "Gauge Style"), tx(settings.language, "Bu sürümde tek stabil gösterge aktif", "Only the stable Digital OEM gauge is active in this build"), "Digital OEM") }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yazı Boyutu", "Text Size"),
                            tx(settings.language, "Kart metinleri ve hız göstergesi ölçeği", "Text scale for cards and speed gauge"),
                            cockpitTextSizeLabel(settings.cockpitTextSize, settings.language),
                            onClick = {
                                val options = CockpitTextSize.entries.map { cockpitTextSizeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yazı Boyutu", "Text Size"), options) { label ->
                                    CockpitTextSize.entries.firstOrNull { cockpitTextSizeLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitTextSize = it)) }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"),
                            tx(settings.language, "Kart, boşluk ve gösterge alanı düzeni", "Card, spacing and gauge area layout"),
                            cockpitDensityLabel(settings.cockpitDensity, settings.language),
                            onClick = {
                                val options = CockpitDensity.entries.map { cockpitDensityLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"), options) { label ->
                                    CockpitDensity.entries.firstOrNull { cockpitDensityLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitDensity = it)) }
                                })
                            }
                        )
                    }
                }
                SettingsCategory.DriveFuel -> {
                    item { SettingsRow(palette, tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), tx(settings.language, "Maliyet için yakıt aldığınız litre fiyatı", "Fuel price per liter used for cost calculation"), fuelPriceDisplay(settings.fuelPriceText, settings.language), onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), settings.fuelPriceText, tx(settings.language, "Örn. 45,50", "e.g. 45.50")) { v -> onSettingsChange(settings.copy(fuelPriceText = v)) }) }) }
                    item { SettingsRow(
                        palette,
                        tx(settings.language, "Ortalama + maliyeti sıfırla", "Reset Average + Cost"),
                        tx(settings.language, "Mesafe, toplam yakıt ve sürüş süresi korunur", "Distance, total fuel and trip time are preserved"),
                        onClick = {
                            openDialog(SettingsDialog.Confirm(
                                tx(settings.language, "Hesaplar sıfırlansın mı?", "Reset calculations?"),
                                tx(settings.language, "Ortalama tüketim ve sürüş maliyeti bu noktadan yeniden başlayacak. Yolculuk toplamları silinmez.", "Average consumption and trip cost will restart from this point. Trip totals will not be deleted."),
                                tx(settings.language, "Sıfırla", "Reset")
                            ) { onResetMetrics(TripMetricReset.AverageAndCost) })
                        }
                    ) }
                    item { SettingsRow(palette, tx(settings.language, "Sürüş sırasında ekranı açık tut", "Keep Screen On While Driving"), tx(settings.language, "Sürüşte telefon ekranının kapanmasını engeller", "Prevents the phone screen from turning off while driving"), trailingSwitch = settings.keepScreenOn, onSwitch = { onSettingsChange(settings.copy(keepScreenOn = it)) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                            tx(settings.language, "Depo dolumu ile ince ayar", "Fine-tune with full-tank refueling"),
                            if (settings.fuelCalibrationEnabled) "x${String.format(java.util.Locale.US, "%.3f", settings.fuelCalibrationFactor)}" else tx(settings.language, "Kapalı", "Off"),
                            onClick = { openFuelCalibrationFlow() }
                        )
                    }
                    if (settings.fuelCalibrationEnabled) {
                        item { SettingsRow(palette, tx(settings.language, "Kalibrasyonu kapat", "Disable Calibration"), tx(settings.language, "Katsayı saklanır; gösterim fabrika hesabına döner", "Coefficient is kept; display returns to factory calculation"), tx(settings.language, "Kapat", "Disable"), onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) }) }
                        item { SettingsRow(palette, tx(settings.language, "Fabrika hesabına dön", "Return to Factory Calculation"), tx(settings.language, "FuelAlgorithmV3 ana hesabını katsayısız göster", "Show FuelAlgorithmV3 without the calibration coefficient"), tx(settings.language, "Dön", "Return"), onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false, fuelCalibrationFactor = 1.0)) }) }
                        item { SettingsRow(palette, tx(settings.language, "Kalibrasyon katsayısını sıfırla", "Reset Calibration Coefficient"), tx(settings.language, "Pompa ve uygulama litre girişlerini temizler", "Clears pump and app liter entries"), tx(settings.language, "Sıfırla", "Reset"), onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false, fuelCalibrationFactor = 1.0, fuelCalibrationAppLitersText = "", fuelCalibrationPumpLitersText = "")) }) }
                    }
                }
                SettingsCategory.VehicleMaintenance -> {
                    item { SettingsRow(palette, tx(settings.language, "Araç", "Vehicle"), "2005-2012 Sedan/MCV • ${settings.engine}", settings.vehicleModel, onClick = { openDialog(SettingsDialog.Info(tx(settings.language, "Araç Profili", "Vehicle Profile"), tx(settings.language, "Tam destek 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. Sandero I deneysel, 2013+ Logan/MCV ve benzinli motorlar desteklenmez.", "Full support is for 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 hp. Sandero I is experimental; 2013+ Logan/MCV and petrol engines are not supported."))) }) }
                    item { SettingsRow(palette, tx(settings.language, "Kurulum Sihirbazını Yeniden Başlat", "Restart Setup Wizard"), tx(settings.language, "Araç, tema ve gösterge tercihlerini yeniden seç", "Choose vehicle, theme and gauge preferences again"), tx(settings.language, "Onay", "Confirm"), onClick = { openDialog(SettingsDialog.Confirm(tx(settings.language, "Kurulum yeniden başlatılsın mı?", "Restart setup?"), tx(settings.language, "İlk kurulum ekranı yeniden açılacak. Log dosyaları ve test kayıtları silinmez.", "The initial setup screen will open again. Log files and test records will not be deleted."), tx(settings.language, "Yeniden Başlat", "Restart")) { onResetSetup() }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), tx(settings.language, "Gösterge kilometresini kalibre et", "Calibrate the dashboard odometer"), settings.odometerText, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), settings.odometerText, tx(settings.language, "Örn. 335420", "e.g. 335420")) { v -> onSettingsChange(settings.copy(odometerText = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Motor Yağı", "Engine Oil"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.oilServiceKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Yağı Aralığı", "Engine Oil Interval"), settings.oilServiceKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(oilServiceKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Mazot Filtresi", "Fuel Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.fuelFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Mazot Filtresi Aralığı", "Fuel Filter Interval"), settings.fuelFilterKm, tx(settings.language, "Örn. 20000", "e.g. 20000")) { v -> onSettingsChange(settings.copy(fuelFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Hava Filtresi", "Air Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.airFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Hava Filtresi Aralığı", "Air Filter Interval"), settings.airFilterKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(airFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Triger Seti", "Timing Belt Kit"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.timingBeltKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Triger Seti Aralığı", "Timing Belt Interval"), settings.timingBeltKm, tx(settings.language, "Örn. 60000", "e.g. 60000")) { v -> onSettingsChange(settings.copy(timingBeltKm = v)) }) }) }
                }
                SettingsCategory.Connection -> {
                    item {
                        ObdConnectionPanel(
                            palette = palette,
                            obdState = obdState,
                            onRefresh = onRefreshObdDevices,
                            onSelect = onSelectObdDevice,
                            onConnect = onConnectObd,
                            onDisconnect = onDisconnectObd,
                            language = settings.language
                        )
                    }
                }
                SettingsCategory.TripRecords -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yeni Sürüş Ayırma Süresi", "New Trip Break Time"),
                            tx(settings.language, "Kısa molalarda aynı sürüşü kaldığı yerden sürdürür", "Keeps the same trip after short stops"),
                            smartTripLabel(settings.smartTripMinutes, settings.language),
                            onClick = {
                                val options = listOf(0, 30, 60, 90).map { smartTripLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yeni Sürüş Ayırma Süresi", "New Trip Break Time"), options) { label ->
                                    listOf(0, 30, 60, 90).firstOrNull { smartTripLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(smartTripMinutes = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşü Şimdi Bitir", "End Trip Now"),
                            tx(settings.language, "Mevcut yolculuk toplamlarını kapatır ve yeni sürüş bekler", "Closes current trip totals and waits for a new trip"),
                            tx(settings.language, "Bitir", "End"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Sürüş şimdi bitirilsin mi?", "End trip now?"),
                                    tx(settings.language, "Mevcut mesafe, yakıt, süre, ortalama ve maliyet kapatılacak. Sonraki hareket yeni sürüş olarak başlayacak.", "Current distance, fuel, time, average and cost will be closed. The next movement will start a new trip."),
                                    tx(settings.language, "Sürüşü Bitir", "End Trip")
                                ) { onEndTripNow() })
                            }
                        )
                    }
                    item {
                        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column(Modifier.weight(1f)) {
                                        Text(tx(settings.language, "Kayıt Geçmişi", "Record History"), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                                        Text(
                                            tx(
                                                settings.language,
                                                "${obdState.historyStorage.driveRecordCount} sürüş • ${obdState.historyStorage.testRecordCount} test",
                                                "${obdState.historyStorage.driveRecordCount} drives • ${obdState.historyStorage.testRecordCount} tests"
                                            ),
                                            color = palette.textSecondary,
                                            fontSize = 12.sp
                                        )
                                    }
                                    TextButton(onClick = onRefreshHistory) { Text(tx(settings.language, "Yenile", "Refresh")) }
                                }
                                Text(
                                    tx(
                                        settings.language,
                                        "Yaklaşık kullanım: ${formatHistoryBytes(obdState.historyStorage.databaseBytes)} • Sabitlenen: ${obdState.historyStorage.pinnedDriveCount + obdState.historyStorage.pinnedTestCount}",
                                        "Approx. usage: ${formatHistoryBytes(obdState.historyStorage.databaseBytes)} • Pinned: ${obdState.historyStorage.pinnedDriveCount + obdState.historyStorage.pinnedTestCount}"
                                    ),
                                    color = palette.textSecondary,
                                    fontSize = 12.sp
                                )
                                TextButton(
                                    onClick = onExportAllHistory,
                                    enabled = obdState.historyStorage.driveRecordCount + obdState.historyStorage.testRecordCount > 0
                                ) { Text(tx(settings.language, "Tüm geçmişi dışa aktar", "Export all history")) }
                            }
                        }
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşleri otomatik kaydet", "Save drives automatically"),
                            tx(settings.language, "Tamamlanan sürüşleri Sürüş Geçmişi'nde tutar", "Keeps completed drives in Drive History"),
                            trailingSwitch = settings.driveHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik sürüş kaydı kapatılsın mı?", "Disable automatic drive history?"),
                                            tx(settings.language, "Yeni sürüşler geçmişe eklenmeyecek. Mevcut kayıtlar silinmez; canlı kokpit ve yol bilgisayarı çalışmaya devam eder.", "New drives will not be added to history. Existing records will remain; the live cockpit and trip computer will continue to work."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(driveHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(driveHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"),
                            tx(settings.language, "Sabitlenen kayıtlar bu sınıra dahil değildir", "Pinned records do not count toward this limit"),
                            historyLimitLabel(settings.driveHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.driveHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.driveHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Sürüşler siz silene kadar saklanır ve zamanla depolama alanı kullanabilir. Ayarlarda kullanım miktarını takip edebilirsiniz.", "Drives will remain until you delete them and may use more storage over time. You can monitor usage in Settings."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski sürüşler silinsin mi?", "Delete older drives?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan sürüş kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned drives."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(driveHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Testleri otomatik kaydet", "Save tests automatically"),
                            tx(settings.language, "Başlatılan manuel ve geliştirici testlerini arşivler", "Archives started manual and developer tests"),
                            trailingSwitch = settings.testHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik test kaydı kapatılsın mı?", "Disable automatic test history?"),
                                            tx(settings.language, "Yeni manuel ve geliştirici testleri Test Geçmişi'ne eklenmeyecek. Mevcut test kayıtları silinmez.", "New manual and developer tests will not be added to Test History. Existing test records will remain."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(testHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(testHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Test geçmişi sınırı", "Test history limit"),
                            tx(settings.language, "Sabitlenen testler otomatik silinmez", "Pinned tests are never auto-deleted"),
                            historyLimitLabel(settings.testHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Test geçmişi sınırı", "Test history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.testHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.testHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Test kayıtları siz silene kadar saklanır ve zamanla depolama alanı kullanabilir. Ayarlarda kullanım miktarını takip edebilirsiniz.", "Test records will remain until you delete them and may use more storage over time. You can monitor usage in Settings."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski testler silinsin mi?", "Delete older tests?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan test kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned tests."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(testHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Tüm geçmişi ve logları temizle", "Clear all history and logs"),
                            tx(settings.language, "Sürüş/test geçmişini, ilişkili örnekleri ve LoganOS loglarını siler", "Deletes drive/test history, related samples and LoganOS logs"),
                            tx(settings.language, "Temizle", "Clear"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Tüm kayıtlar temizlensin mi?", "Clear all records?"),
                                    tx(settings.language, "Tüm sürüş ve test geçmişi, ilişkili SQL örnekleri ve LoganOS logları kalıcı olarak silinecek. Bu işlem geri alınamaz.", "All drive and test history, related SQL samples and LoganOS logs will be permanently deleted. This cannot be undone."),
                                    tx(settings.language, "Tümünü Sil", "Delete All")
                                ) { onClearAllObdLogs() })
                            }
                        )
                    }
                }
                SettingsCategory.Developer -> {
                    item { SettingsRow(palette, tx(settings.language, "Geliştirici Modu", "Developer Mode"), tx(settings.language, "Testler ve teknik debug seçeneklerini açar", "Enables tests and technical debug options"), trailingSwitch = settings.developerModeEnabled, onSwitch = { enabled -> onSettingsChange(settings.copy(developerModeEnabled = enabled, rawEcuLogEnabled = if (enabled) settings.rawEcuLogEnabled else false)) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Demo Modu", "Demo Mode"),
                            tx(settings.language, "Ekranları simülasyon verisiyle dene", "Try screens with simulated data"),
                            trailingSwitch = settings.demoMode,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Demo Modu", "Demo Mode"),
                                            tx(settings.language, "Bu mod gerçek araç verisi göstermez.\n\nEkranları ve göstergeleri denemek için simülasyon verisi üretir.", "This mode does not show real vehicle data.\n\nIt generates simulated data to test screens and gauges."),
                                            tx(settings.language, "Demo Modunu Aç", "Enable Demo Mode")
                                        ) { onSettingsChange(settings.copy(demoMode = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(demoMode = false))
                                }
                            }
                        )
                    }
                    if (settings.developerModeEnabled) {
                        item { SettingsRow(palette, tx(settings.language, "Geliştirici Ham Log", "Developer Raw Log"), tx(settings.language, "Ham ECU paketlerini ayrıca kaydeder; normalde kapalı kalmalı", "Stores raw ECU packets separately; normally keep this off"), trailingSwitch = settings.rawEcuLogEnabled, onSwitch = { onSettingsChange(settings.copy(rawEcuLogEnabled = it)) }) }
                        item { DeveloperTestRows(palette, obdState.activeDeveloperTest, settings.language, onDeveloperTestStart, onDeveloperTestEnd) }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Son teknik kaydı dışa aktar", "Export last technical log"),
                                tx(settings.language, "Son OBD/test kaydını Download/LoganOS klasörüne aktarır", "Exports the last OBD/test log to Download/LoganOS"),
                                tx(settings.language, "Dışa Aktar", "Export"),
                                onClick = {
                                    openDialog(SettingsDialog.Confirm(
                                        tx(settings.language, "Teknik kayıt dışa aktarılsın mı?", "Export technical log?"),
                                        tx(settings.language, "Son teknik OBD/test kaydı Download/LoganOS klasörüne aktarılacak.", "The last technical OBD/test log will be exported to Download/LoganOS."),
                                        tx(settings.language, "Dışa Aktar", "Export")
                                    ) { onSaveObdLog() })
                                }
                            )
                        }
                        item { SettingsRow(palette, tx(settings.language, "Son teknik kaydı paylaş", "Share last technical log"), tx(settings.language, "Son oluşturulan teknik kaydı paylaşır", "Shares the latest technical log"), tx(settings.language, "Paylaş", "Share"), onClick = onShareObdLog) }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Destek Paketi Oluştur", "Create Support Package"),
                                tx(settings.language, "Sorun analizi için özet, teknik log ve durum bilgisini ZIP olarak hazırlar", "Creates a ZIP with summary, technical logs and status information"),
                                tx(settings.language, "Oluştur", "Create"),
                                onClick = {
                                    openDialog(SettingsDialog.Confirm(
                                        tx(settings.language, "Destek paketi oluşturulsun mu?", "Create support package?"),
                                        tx(settings.language, "Özet log, teknik OBD logu ve durum bilgisi tek ZIP içinde hazırlanacak.", "A summary log, technical OBD log and status information will be prepared in one ZIP."),
                                        tx(settings.language, "Oluştur", "Create")
                                    ) { onCreateSupportPackage() })
                                }
                            )
                        }
                        obdState.savedLogPath?.let { path ->
                            item { Text(tx(settings.language, "Son teknik dosya", "Last technical file") + ": $path", color = palette.textSecondary, fontSize = 11.sp, maxLines = 2) }
                        }
                    }
                }
                SettingsCategory.About -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
                            Text("LOGANOS", color = palette.textPrimary, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text(
                                tx(settings.language, "Sürüm ${BuildConfig.VERSION_NAME}", "Version ${BuildConfig.VERSION_NAME}"),
                                color = palette.accent,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                tx(settings.language, "Dacia Logan 1.5 dCi için geliştirilen bağımsız OBD ve dijital kokpit uygulaması.", "An independent OBD and digital cockpit application developed for the Dacia Logan 1.5 dCi."),
                                color = palette.textSecondary,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Teknik altyapı", "Technical foundation"))
                            AboutBody(palette, "Fuel Truth • Smart Trip")
                            AboutBody(palette, "Delphi DCM1.2 • KWP2000 Fast Init")

                            AboutSectionTitle(palette, tx(settings.language, "Proje", "Project"))
                            AboutBody(palette, tx(settings.language, "Ücretsiz, reklamsız ve GPLv3 açık kaynaklıdır.", "Free, ad-free and open source under GPLv3."))

                            AboutSectionTitle(palette, tx(settings.language, "Gizlilik", "Privacy"))
                            AboutBody(palette, tx(settings.language, "Veriler cihazda saklanır. Kayıtlar yalnızca kullanıcı dışa aktardığında cihaz dışına çıkar.", "Data is stored on the device. Records leave the device only when the user exports them."))

                            AboutSectionTitle(palette, tx(settings.language, "Bağımsızlık bildirimi", "Independence notice"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "LoganOS bağımsız olarak geliştirilmiştir. Renault Group veya Dacia ile resmî bağlantısı bulunmamaktadır.",
                                    "LoganOS is independently developed and is not officially affiliated with Renault Group or Dacia."
                                )
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Geliştirme araçları", "Development tools"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "Geliştirme sürecinde ChatGPT, Gemini ve Claude yapay zekâ araçlarından yararlanılmıştır.",
                                    "ChatGPT, Gemini and Claude AI tools were used during development."
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun AboutSectionTitle(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.accent,
        fontSize = 14.sp,
        fontWeight = FontWeight.Black
    )
}

@Composable
private fun AboutBody(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.textSecondary,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
}

private fun historyLimitOptions(language: AppLanguage): List<String> = listOf(
    "10", "25", "50", if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
)

private fun historyLimitFromLabel(label: String): Int = when {
    label.equals("Unlimited", true) || label.equals("Sınırsız", true) -> -1
    else -> label.toIntOrNull() ?: 10
}

private fun historyLimitLabel(limit: Int, language: AppLanguage): String =
    if (limit < 0) {
        if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
    } else limit.toString()

private fun formatHistoryBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(java.util.Locale.US, "%.1f KB", kb)
    return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
}


@Composable
private fun DeveloperTestRows(
    palette: LoganPalette,
    activeTest: String?,
    language: AppLanguage,
    onStart: (String) -> Unit,
    onEnd: () -> Unit
) {
    val tests = listOf(
        "Sıcak rölanti testi" to tx(language, "Klima kapalı 60 sn → açık 60 sn → kapalı 30 sn", "A/C off 60s → on 60s → off 30s"),
        "Klima testi" to tx(language, "Klima kapalı 30 sn → açık 30 sn → kapalı 30 sn", "A/C off 30s → on 30s → off 30s"),
        "Elektrik/yük testi" to tx(language, "Klima kapalı; far, rezistans ve kalorifer fanını sırayla aç", "A/C off; enable lights, rear defrost and cabin fan one by one"),
        "Tam yük testi" to tx(language, "Far, sis, rezistans, kalorifer fanı ve klimayı birlikte aç", "Turn on lights, fog, rear defrost, cabin fan and A/C together"),
        "Yakıt kesme (CUTOFF) testi" to tx(language, "20-30 km/h üstünde gazı bırak; yakıt kesme beklenir", "Release throttle above 20-30 km/h; fuel cut-off is expected"),
        "Serbest sürüş testi" to tx(language, "5 dk yönlendirmeli şehir içi kayıt", "5-minute guided city drive recording")
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tx(language, "Geliştirici Testleri", "Developer Tests"), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
        if (activeTest != null) {
            SettingsRow(
                palette = palette,
                title = tx(language, "Aktif test: $activeTest", "Active test: $activeTest"),
                subtitle = tx(language, "Bitirince test kaydı kapatılır", "Ending closes the test record"),
                value = tx(language, "Bitir", "End"),
                onClick = onEnd
            )
        }
        tests.forEach { (name, desc) ->
            val running = activeTest == name
            SettingsRow(
                palette = palette,
                title = name,
                subtitle = desc,
                value = if (running) tx(language, "Bitir", "End") else tx(language, "Başlat", "Start"),
                onClick = { if (running) onEnd() else onStart(name) }
            )
        }
    }
}


private fun deviceModeLabel(mode: DeviceMode, language: AppLanguage): String = when (mode) {
    DeviceMode.Auto -> tx(language, "Otomatik", "Automatic")
    DeviceMode.Phone -> tx(language, "Telefon", "Phone")
    DeviceMode.HeadUnit -> tx(language, "Android Multimedya / Double", "Android Multimedia / Head Unit")
}

private fun smartTripLabel(minutes: Int, language: AppLanguage): String = when (minutes) {
    0 -> tx(language, "Her kontakta yeni sürüş", "New trip at every ignition")
    30 -> tx(language, "30 dakika", "30 minutes")
    60 -> tx(language, "60 dakika • Varsayılan", "60 minutes • Default")
    90 -> tx(language, "90 dakika", "90 minutes")
    else -> "$minutes ${tx(language, "dakika", "minutes")}"
}

private fun cockpitTextSizeLabel(size: CockpitTextSize, language: AppLanguage): String =
    if (language == AppLanguage.English) size.enLabel else size.trLabel

private fun cockpitDensityLabel(density: CockpitDensity, language: AppLanguage): String =
    if (language == AppLanguage.English) density.enLabel else density.trLabel

private fun fuelPriceDisplay(raw: String, language: AppLanguage): String {
    val value = raw.replace(',', '.').toDoubleOrNull() ?: return tx(language, "Girilmedi", "Not set")
    return String.format(java.util.Locale("tr", "TR"), "%.2f TL/L", value)
}

private fun parseCalibrationNumber(raw: String): Double? {
    return raw.trim().replace(',', '.').toDoubleOrNull()
}

@Composable
private fun OptionDialog(palette: LoganPalette, dialog: SettingsDialog.Options, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                dialog.options.forEach { option ->
                    Text(
                        option,
                        color = palette.textPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onDismiss(); dialog.onSelect(option) }
                            .background(palette.surfaceVariant)
                            .padding(12.dp)
                    )
                }
            }
        }
    )
}

@Composable
private fun TextInputDialog(palette: LoganPalette, dialog: SettingsDialog.TextInput, language: AppLanguage, onDismiss: () -> Unit) {
    var value by remember(dialog.title) { mutableStateOf(dialog.initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(dialog.hint) }, singleLine = true)
                if (dialog.title == "Yakıt Fiyatı" || dialog.title == "Fuel Price") {
                    Text(
                        tx(language, "Daha doğru maliyet hesabı için, yakıt aldığınız zamanki litre fiyatını girin.", "For a more accurate cost calculation, enter the fuel price per liter at the time of refueling."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { dialog.onSave(value); onDismiss() }) { Text(tx(language, "Kaydet", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}

@Composable
private fun FuelCalibrationDialog(palette: LoganPalette, dialog: SettingsDialog.Calibration, language: AppLanguage, onDismiss: () -> Unit) {
    var appLiters by remember { mutableStateOf(dialog.appLiters) }
    var pumpLiters by remember { mutableStateOf(dialog.pumpLiters) }
    val appValue = parseCalibrationNumber(appLiters)
    val pumpValue = parseCalibrationNumber(pumpLiters)
    val factor = if (appValue != null && pumpValue != null && appValue > 0.0 && pumpValue > 0.0) {
        (pumpValue / appValue)
    } else null
    val factorValid = factor != null && factor in 0.50..1.50

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(tx(language, "Yakıt Kalibrasyonu", "Fuel Calibration"), color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                Text(tx(language, "Depo dolumu ile ince ayar", "Fine-tune with full-tank refueling"), color = palette.textPrimary, fontWeight = FontWeight.Bold)
                Text(fuelCalibrationHelpText(language), color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
                OutlinedTextField(
                    value = appLiters,
                    onValueChange = { appLiters = it },
                    label = { Text(tx(language, "LoganOS’un hesapladığı litre", "Liters calculated by LoganOS")) },
                    singleLine = true
                )
                OutlinedTextField(
                    value = pumpLiters,
                    onValueChange = { pumpLiters = it },
                    label = { Text(tx(language, "Pompadan alınan litre", "Liters from the pump")) },
                    singleLine = true
                )
                Text(
                    text = when {
                        factorValid -> tx(language, "Yeni katsayı", "New coefficient") + ": x${String.format(java.util.Locale.US, "%.3f", factor)}"
                        factor != null -> tx(language, "Katsayı 0,50 ile 1,50 arasında olmalı. Litre girişlerini kontrol edin.", "Coefficient must be between 0.50 and 1.50. Check the liter entries.")
                        else -> tx(language, "Devam etmek için iki litre değerini de girin. Örnek: uygulama 42,3 L / pompa 43,8 L = x1,035", "Enter both liter values to continue. Example: app 42.3 L / pump 43.8 L = x1.035")
                    },
                    color = if (factorValid) palette.accent else if (factor != null) palette.critical else palette.textSecondary,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    lineHeight = 17.sp
                )
                Text(
                    text = tx(language, "Mevcut durum", "Current status") + ": " + (if (dialog.enabled) tx(language, "Açık", "On") else tx(language, "Kapalı", "Off")) + " • " + tx(language, "mevcut katsayı", "current coefficient") + " x${String.format(java.util.Locale.US, "%.3f", dialog.currentFactor)}",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            }
        },
        confirmButton = {
            TextButton(
                enabled = factorValid,
                onClick = {
                    dialog.onSave(appLiters, pumpLiters, factor ?: 1.0)
                    onDismiss()
                }
            ) { Text(tx(language, "Kaydet ve Aç", "Save and Enable")) }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { dialog.onDisable(); onDismiss() }) { Text(tx(language, "Kapat", "Disable")) }
                TextButton(onClick = { dialog.onReset(); onDismiss() }) { Text(tx(language, "Sıfırla", "Reset")) }
                TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) }
            }
        }
    )
}

private fun fuelCalibrationHelpText(language: AppLanguage): String = if (language == AppLanguage.English) """
This feature fine-tunes the fuel consumption calculated by LoganOS based on full-tank refueling.

For the best result:
1. Fill the tank completely.
2. Drive at least 100 km normally.
3. Fill the tank completely again.
4. Enter the number of liters taken from the pump.
5. Enter the liters calculated by LoganOS for the same trip.

For better accuracy, 200-300 km or more is recommended. Using the same pump/station helps reduce deviation.

The fuel amount from the pump and the value calculated by LoganOS may not always be exactly the same.

A/C use, city/highway driving, idling, traffic, driving style, vehicle load and refueling differences can affect the result.
""".trimIndent() else """
Bu özellik, LoganOS’un hesapladığı yakıt tüketimini depo dolumuna göre ince ayarlar.

En doğru sonuç için:
1. Depoyu fulleyin.
2. En az 100 km normal kullanın.
3. Tekrar depoyu fulleyin.
4. Pompadan kaç litre aldığınızı girin.
5. LoganOS’un aynı sürüş için hesapladığı litreyi girin.

Daha doğru sonuç için 200-300 km veya daha uzun kullanım önerilir. Aynı pompa/istasyonla fulleme yapmak sapmayı azaltır.

Pompadan alınan yakıt ile LoganOS’un hesapladığı değer her zaman birebir aynı olmayabilir.

Klima kullanımı, şehir içi/şehir dışı sürüş, rölantide bekleme, trafik yoğunluğu, sürüş tarzı, araç yükü ve depo dolum farkları sonucu etkileyebilir.
""".trimIndent()


@Composable
private fun InfoDialog(palette: LoganPalette, dialog: SettingsDialog.Info, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tx(language, "Tamam", "OK")) } }
    )
}

@Composable
private fun ConfirmDialog(palette: LoganPalette, dialog: SettingsDialog.Confirm, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = { onDismiss(); dialog.onConfirm() }) { Text(dialog.confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}
