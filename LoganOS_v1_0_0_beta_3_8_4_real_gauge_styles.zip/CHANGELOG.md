# LoganOS v1.0.0-beta.3.8.4

## v1.0.0-beta.3.8.4 - Real Gauge Styles

- Fixed gauge style wiring so the selected style is no longer just a small arc/color variation.
- Added distinct SpeedGauge implementations for:
  - Digital C
  - Sport C
  - Classic OEM A
  - Minimal C
  - RS Performance D
- Setup gauge preview and the live cockpit now use the same style-specific SpeedGauge rendering.
- Enlarged cockpit icon assets by removing excess transparent padding inside the PNG files.
- Enlarged and recentered Dacia/Renault setup brand logo assets; brand cards now show emblem-only logos without duplicate brand wordmarks inside the logo area.
- Increased cockpit metric row/icon proportions while keeping titles readable.
- Preserved the approved bitmap/Image asset approach for visual fidelity.

Unchanged critical systems:
- FuelAlgorithmV3
- TripComputer
- CUTOFF
- AC_FAST
- Delphi DCM1.2 byte positions
- OBD connection loop
- Cranking Analysis core logic
- Fuel calibration coefficient logic
- Fan UNKNOWN / test pending behavior
