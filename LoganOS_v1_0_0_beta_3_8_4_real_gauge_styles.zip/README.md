# LoganOS v1.0.0-beta.3.8.4

This package focuses on visual fidelity and cockpit styling after v3.8.2.

Main changes:
- Replaces degraded auto-vector cockpit/brand visuals with approved transparent PNG assets.
- Renders metric assets with `Image(...)` to prevent unwanted Material icon tinting.
- Improves cockpit icon size and readability.
- Lets long cockpit labels wrap instead of clipping.
- Cleans Dacia/Renault setup brand assets.
- Keeps selected gauge styles wired to the cockpit and preview system.

Commit message:

```text
Fix assets and cockpit styles
```

Critical OBD/fuel systems were intentionally left untouched.
