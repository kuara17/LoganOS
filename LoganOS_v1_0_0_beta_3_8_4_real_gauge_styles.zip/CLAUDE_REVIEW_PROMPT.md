# LoganOS v1.0.0-beta.3.8.4 review prompt

Please review this Android/Kotlin/Jetpack Compose project after the v3.8.4 gauge-style and asset fix.

Main areas to verify:

1. Build / compile
- Check for Kotlin/Compose compile errors.
- Check imports and function signatures in `Gauges.kt`, `DashboardScreen.kt`, and `SetupWizard.kt`.
- Confirm versionName is `1.0.0-beta.3.8.4` and versionCode is `100000384`.

2. Gauge style wiring
- Verify that Setup > Gauge Style and Settings > Gauge Style persist the selected `GaugeStyle`.
- Verify Dashboard reads `settings.gaugeStyle` and routes to a truly distinct gauge renderer.
- Each style should look visibly different:
  - Digital: clean green semi-arc and ticks.
  - Sport: dynamic frame/side accents and thicker green active arc.
  - Classic OEM: analog-style ticks, labels, needle, and fuel-scale detail.
  - Minimal: sparse, quiet arc with minimal detail.
  - RS Performance: red segmented performance arc and aggressive accent lines.

3. Assets
- Verify cockpit PNG assets are not tiny due to excess transparent padding.
- Verify Dacia/Renault logo assets are large enough, centered, and emblem-only in setup brand cards.
- Verify app uses Image/painterResource for custom bitmap assets rather than Material Icon tinting.

4. UI readability
- Check S23 FE portrait cockpit readability.
- Check no title truncation for Sürüş Maliyeti, Hararet / Fan, Sürüş Süresi.
- Check bottom navigation does not cover content.

5. Do not refactor unless a clear bug is found
- FuelAlgorithmV3
- TripComputer
- CUTOFF
- AC_FAST
- Delphi parser byte positions
- OBD polling loop
- Cranking Analysis logic
- Fuel calibration
- Fan UNKNOWN behavior

Please provide file/function-level patches only for definite bugs.
