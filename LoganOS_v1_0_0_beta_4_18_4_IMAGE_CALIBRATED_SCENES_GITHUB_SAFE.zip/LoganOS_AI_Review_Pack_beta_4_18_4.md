# LoganOS beta.4.18.4 — Claude / Gemini Kod İnceleme Paketi

## İnceleme amacı

Bu paket Digital V2'nin `Compose UI + OpenGL ES 2.0` mimarisinde görüntüye özel yol kalibrasyonu ve araç-sahne bütünleştirmesini uygular. İnceleme; dört arka planın gerçek yol geometrisine uyumu, shader matematiği, araç temas noktaları, düşük seviye Android GPU uyumluluğu, yaşam döngüsü ve kaynak kaybı senaryolarına odaklanmalıdır.

## Önceki sorunun kökü

beta.4.18.3, yol çizgilerini GPU VBO/shader sisteminde üretiyor fakat dört fotoğrafın üzerine ortak bir yol/kamera şablonu bindiriyordu. Özellikle Dağ-Göl ve Karlı Yol'da çizgiler fotoğraftaki virajı izlemiyor, araç ise ayrı bir PNG katmanı gibi görünüyordu.

## beta.4.18.4 mimarisi

### 1. Görüntüye özel yol kalibrasyonu

Dosyalar:

- `DigitalV2SceneModel.kt`
- `DigitalV2SceneProfiles.kt`
- `DigitalV2RoadMeshBuilder.kt`

Her sahne şu üç bağımsız eğriye sahiptir:

- `centerLine`
- `leftRoadEdge`
- `rightRoadEdge`

Her eğri, 0–120 metre arasında sekiz ölçülmüş `CalibrationPoint` içerir. Noktalar non-uniform cubic Hermite ile C1-sürekli örneklenir. Eski `RoadProjectiveCameraProfile`, `RoadCurveProfile`, `clipMatrix` ve `buildRoadRibbonMesh` runtime'dan kaldırılmıştır.

### 2. GPU yol sistemi

Mesh vertex yapısı:

`[ndcX, ndcY, roadDistanceMeters, across]`

- Merkez ve kenar çizgileri `buildCalibratedLineMesh()` ile oluşturulur.
- Asfalt alanı iki gerçek yol sınırı arasından `buildCalibratedRoadSurfaceMesh()` ile oluşturulur.
- Rüzgâr bölgeleri asfaltın geometrik orta noktası ile gerçek kenar vektöründen dışarı kurulur.
- 3 m çizgi + 6 m boşluk deseni fragment shader'da dünya mesafesiyle hesaplanır.
- Uzak çizgi genişliği 1,8 px altında kalmaz; shader ufukta alfa ile söndürür.

### 3. Araç ve zemin teması

Her sahne ayrı `VehicleScenePose`, `VehicleShadowProfile` ve `VehicleColorGrade` kullanır.

- Araç ekran merkezinde.
- Görünür genişlik %32–32,5.
- Lastik temas yüksekliği %85,8–86,2.
- Araç asset profilinde gerçek sol/sağ lastik X anchor'ları saklanır.
- Gölge; geniş gövde gölgesi, iki lastik teması ve ground-blend katmanından oluşur.
- Lastik konumları önceden döndürülmez; araç ve gölgeler temas anchor'ı etrafında yalnız bir kez döndürülür.
- Araç her sahneye özel exposure, contrast, saturation ve RGB ortam derecelendirmesi alır.

### 4. Ayrılmış texture shader'ları

`DigitalV2Shaders.kt` ve `DigitalV2Renderer.kt`:

- Arka plan ve gölge varlıkları tek texture örnekli `SIMPLE_TEXTURED_FRAGMENT_SHADER` ile çizilir.
- Yalnız araç, beş örnekli kenar yumuşatma ve renk derecelendirme yapan `VEHICLE_FRAGMENT_SHADER` kullanır.
- Android premultiplied araç texture'ı geçici olarak unpremultiply edilir, grade uygulanır ve `GL_ONE, GL_ONE_MINUS_SRC_ALPHA` için yalnız bir kez yeniden premultiply edilir.
- Böylece tam ekran arka planda gereksiz beş texture fetch maliyeti oluşmaz.

### 5. GPU kaynak güvenliği

- Texture yüklemesi başarısızsa önceki geçerli texture korunur ve bir saniye sonra yeniden denenir.
- Yol VBO seti önce aday olarak eksiksiz kurulur; yalnız başarıdan sonra eski set serbest bırakılır.
- Kısmi VBO oluşturma hatasında oluşturulmuş buffer'lar transaction benzeri biçimde temizlenir.
- EGL context yeniden oluştuğunda program, VBO ve texture kimlikleri yeniden kurulur.

### 6. Ayarlar önizlemesi

İkinci `GLSurfaceView` açılmaz. Önizleme aynı `DigitalV2SceneModels`, `CalibratedCurve`, araç asset anchor'ları ve gölge profillerini kullanır. GPU shader çıktısının birebir framebuffer yakalaması değildir; ortak geometri ve yerleşim modelinin statik karşılığıdır.

## Özellikle incelenecek sorular

1. Non-uniform cubic Hermite implementasyonunda overshoot, tangent sıçraması veya yol kenarı kesişmesi mümkün mü?
2. NDC ribbon mesh ve metre-distance varying ES 2.0 `mediump` için güvenli mi?
3. Premultiplied-alpha araç grade shader'ında halo veya tekrar alfa çarpımı riski var mı?
4. Dört sahnenin eğrileri yeterince ayrışıyor mu, herhangi bir ortak şablon kalmış mı?
5. Lastik gölgeleri heading dönüşünü yalnız bir kez mi alıyor?
6. Wind VBO gerçek asfaltın dışına kesin olarak çıkıyor mu?
7. Context loss sonrası VBO, shader ve texture'lar eksiksiz yeniden kuruluyor mu?
8. `RoadMeshSet.create()` hata yolunda kısmi VBO sızıntısı veya geçerli eski mesh kaybı mümkün mü?
9. 2 GB RAM'li Android head unit için texture/VBO/draw-call maliyeti uygun mu?
10. Compose settings preview ile gerçek shader çıktısı arasında kullanıcıyı yanıltacak fark var mı?
11. İlk cihaz testinden önce eklenmesi gereken unit/instrumentation testleri neler?

## Çalıştırılmış kontroller

- `tools/preflight_source.py`
- `tools/audit_digital_v2_release.py`
- `tools/validate_digital_v2_geometry.kt` gerçek `kotlinc` + JVM
- OpenGL renderer/host kaynakları Android/Compose API stublarıyla `kotlinc`
- `tools/validate_release.py`
- ZIP çıkarıldıktan sonra aynı kontrollerin yeniden çalıştırılması

Geometri testi ayrıca şunları doğrular:

- Kalibre eğriler bütün kontrol noktalarından geçiyor.
- Yol kenarları kesişmiyor ve genişlik ufka doğru monoton azalıyor.
- 3 metrelik kesikler uzaklaştıkça tekrar büyümüyor.
- Araç gövdesi ve iki gerçek lastik anchor'ı asfalt içinde kalıyor.
- Sol ve sağ rüzgâr mesh'inin bütün noktaları yol kenarının dış tarafında kalıyor.
- Şehir gündüz/gece kalibrasyonları ayrı.
- Gece aracı gündüze göre karartılıyor, kar sahnesi soğuk ortam grade'i kullanıyor.

## Bilinen doğrulama sınırı

Bu çalışma ortamında Android SDK, Gradle Wrapper ve gerçek EGL/GPU sürücüsü yoktur. `assembleDebug`, gerçek shader compile/link ve cihaz frame timing burada çalıştırılamaz. Kaynak denetimleri başarılı olsa bile ilk APK şu konularda doğrulanmalıdır:

- S23 FE portre görüntüsü
- 2 GB RAM'li Double yatay görüntüsü
- EGL context loss sonrası geri dönüş
- 40/80/110 km/s çizgi akışı
- Araç gölge ve renk uyumunun gerçek ekrandaki görünümü
- Settings statik önizlemesi ile gerçek kokpit arasındaki görsel fark

## İnceleme istemi

Bu paketi kıdemli Android/OpenGL ES ve Jetpack Compose geliştiricisi gibi incele. Özetleme ile yetinme. Dosya/sınıf/fonksiyon düzeyinde mimari hata, shader matematik problemi, premultiplied-alpha kusuru, thread/lifecycle riski, farklı ekran uyumsuzluğu, performans sorunu, eksik test ve gereksiz karmaşıklıkları belirt. Her bulgu için önem seviyesi, somut kanıt ve önerilen düzeltmeyi yaz. Pakette bulunmayan kod hakkında varsayım yapıyorsan bunu açıkça belirt.
