package com.dcui.loganos.ui.cockpit

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DigitalV2GaugeMode
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_STAGE_ASPECT_RATIO
import com.dcui.loganos.ui.cockpit.opengl.DigitalV2SceneModels
import com.dcui.loganos.ui.cockpit.opengl.GlColor
import com.dcui.loganos.ui.cockpit.opengl.OpenGLSceneHost
import com.dcui.loganos.ui.cockpit.opengl.digitalV2BackgroundRes
import com.dcui.loganos.ui.cockpit.opengl.digitalV2ShadowRes
import com.dcui.loganos.ui.cockpit.opengl.digitalV2VehicleAssetProfile
import com.dcui.loganos.ui.cockpit.opengl.digitalV2RenderState
import com.dcui.loganos.ui.cockpit.opengl.toOpenGlKey
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val DigitalV2Blue = Color(0xFF1479FF)
private val DigitalV2Red = Color(0xFFFF3B30)
private val DigitalV2Glass = Color(0xEAF7F9FC)
private const val DigitalV2CalibrationVisible = false

@Composable
fun DigitalV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    portrait: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        // Keep the OpenGL host at one stable Compose call site. Orientation
        // changes only resize the existing SurfaceView; they do not dispose one
        // portrait branch and create a second landscape EGL context.
        val portraitStageMaxHeight = maxHeight * 0.62f
        val landscapePanelWidth = if (portrait) 0.dp else maxWidth * (1f / 2.55f)
        val landscapeSceneAreaWidth = maxWidth - landscapePanelWidth
        val stageWidth = if (portrait) {
            minOf(maxWidth, portraitStageMaxHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
        } else {
            minOf(landscapeSceneAreaWidth, maxHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
        }
        val stageHeight = stageWidth / DIGITAL_V2_STAGE_ASPECT_RATIO
        val stageOffsetX = if (portrait) 0.dp else (landscapeSceneAreaWidth - stageWidth) / 2f

        DigitalV2SceneStage(
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            tr = tr,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick,
            modifier = Modifier
                .then(
                    if (portrait) {
                        Modifier.align(Alignment.TopCenter)
                    } else {
                        Modifier.align(Alignment.CenterStart).offset(x = stageOffsetX)
                    }
                )
                .width(stageWidth)
                .height(stageHeight)
        )

        if (portrait) {
            DigitalV2DataPanel(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                tr = tr,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(maxHeight - stageHeight)
            )
        } else {
            DigitalV2CompactDataPanel(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                tr = tr,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(landscapePanelWidth)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun DigitalV2SceneStage(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    tr: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier.clipToBounds()
    ) {
        OpenGLSceneHost(
            renderState = digitalV2RenderState(
                settings = settings,
                snapshot = snapshot,
                calibrationVisible = DigitalV2CalibrationVisible
            ),
            modifier = Modifier.fillMaxSize()
        )

        // HUD contrast only. Road, vehicle, shadow and motion all remain in one
        // OpenGL coordinate system below this Compose overlay.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x2606244A),
                            Color.Transparent,
                            Color(0x10071324),
                            Color(0x30081420)
                        )
                    )
                )
        )

        DigitalV2Header(
            tr = tr,
            connected = snapshot.connected || obdState.connected,
            demo = settings.demoMode || snapshot.demo,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )

        DigitalV2Gauge(
            mode = settings.digitalV2GaugeMode,
            speedKmh = snapshot.speedKmh,
            rpm = snapshot.rpm,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 6.dp)
                .fillMaxWidth(0.985f)
                .fillMaxHeight(0.78f)
        )
    }
}

@Composable
private fun DigitalV2Header(
    tr: Boolean,
    connected: Boolean,
    demo: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White.copy(alpha = .16f))
                .border(1.dp, Color.White.copy(alpha = .30f), RoundedCornerShape(13.dp))
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xB2123657))
                .border(1.dp, Color.White.copy(alpha = .27f), RoundedCornerShape(14.dp))
                .clickable(onClick = onObdClick)
                .padding(horizontal = 11.dp, vertical = 9.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    demo -> "DEMO"
                    connected -> if (tr) "OBD BAĞLI" else "OBD ON"
                    else -> if (tr) "OBD BEKLENİYOR" else "OBD WAITING"
                },
                color = if (connected || demo) Color(0xFF9BE8B5) else Color.White,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DigitalV2Gauge(
    mode: DigitalV2GaugeMode,
    speedKmh: Int?,
    rpm: Int?,
    modifier: Modifier = Modifier,
    preview: Boolean = false
) {
    val rawProgress = when (mode) {
        DigitalV2GaugeMode.Speed -> ((speedKmh ?: 0) / 200f).coerceIn(0f, 1f)
        DigitalV2GaugeMode.Rpm -> ((rpm ?: 0) / 7000f).coerceIn(0f, 1f)
    }

    val progress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(if (preview) 0 else 380),
        label = "digitalV2GaugeProgress"
    )

    val labels = if (mode == DigitalV2GaugeMode.Speed) (0..200 step 20).toList() else (0..70 step 10).toList()
    val majorCount = labels.lastIndex.coerceAtLeast(1)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * 0.485f
            val center = Offset(size.width / 2f, size.height * 0.60f)
            val startAngle = 145f
            val sweep = 250f
            val arcTopLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = Size(radius * 2f, radius * 2f)

            drawArc(
                color = Color.White.copy(alpha = .92f),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.014f, cap = StrokeCap.Round)
            )

            drawArc(
                brush = Brush.sweepGradient(listOf(DigitalV2Blue, Color.White, Color.White, DigitalV2Red), center),
                startAngle = startAngle,
                sweepAngle = sweep * progress,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.021f, cap = StrokeCap.Round)
            )

            val minorTicks = majorCount * 5
            repeat(minorTicks + 1) { index ->
                val fraction = index / minorTicks.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val major = index % 5 == 0
                val outer = radius * 0.99f
                val inner = radius * if (major) 0.865f else 0.925f

                val p1 = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner)
                val p2 = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer)

                drawLine(
                    color = Color.White.copy(alpha = if (major) .98f else .67f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (major) radius * .014f else radius * .0055f,
                    cap = StrokeCap.Round
                )
            }

            labels.forEachIndexed { index, value ->
                val fraction = index / majorCount.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val labelRadius = radius * .735f
                val x = center.x + cos(angle).toFloat() * labelRadius
                val y = center.y + sin(angle).toFloat() * labelRadius + radius * .038f

                drawContext.canvas.nativeCanvas.drawText(
                    value.toString(),
                    x,
                    y,
                    Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.WHITE
                        textAlign = Paint.Align.CENTER
                        textSize = radius * if (preview) .112f else .124f
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        setShadowLayer(radius * .020f, 0f, radius * .009f, android.graphics.Color.argb(175, 0, 0, 0))
                    }
                )
            }

            val needleAngle = Math.toRadians((startAngle + sweep * progress).toDouble())
            val needleStart = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .14f,
                center.y + sin(needleAngle).toFloat() * radius * .14f
            )
            val needleEnd = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .80f,
                center.y + sin(needleAngle).toFloat() * radius * .80f
            )

            // Keep the centre clear so the needle never cuts through the digital value.
            drawLine(Color.White.copy(alpha = .98f), needleStart, needleEnd, radius * .018f, StrokeCap.Round)
        }

        // The ring and needle show the selected gauge; the centre shows the other live value.
        val centerValue = when (mode) {
            DigitalV2GaugeMode.Speed -> rpm?.let { (it / 100).toString() } ?: "--"
            DigitalV2GaugeMode.Rpm -> speedKmh?.toString() ?: "--"
        }
        val centerUnit = if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h"
        val textShadow = Shadow(
            Color.Black.copy(alpha = .70f),
            Offset(0f, if (preview) 1f else 2f),
            if (preview) 3f else 7f
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = maxHeight * 0.075f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                centerValue,
                color = Color.White,
                fontSize = if (preview) 34.sp else 72.sp,
                fontWeight = FontWeight.Black,
                lineHeight = if (preview) 34.sp else 72.sp,
                style = TextStyle(shadow = textShadow)
            )
            Text(
                centerUnit,
                color = Color.White.copy(alpha = .96f),
                fontSize = if (preview) 9.5.sp else 16.sp,
                fontWeight = FontWeight.Black,
                style = TextStyle(shadow = textShadow)
            )
        }
    }
}

@Composable
private fun DigitalV2DataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(DigitalV2Glass, Color(0xFFF0F3F7), Color(0xFFE3E8EF))
                )
            )
            .border(1.dp, Color.White.copy(alpha = .82f), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1.12f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Hararet", "Coolant"), snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.Temperature, Modifier.weight(1f), compact = true, accent = if ((snapshot.engineTempC ?: 0) >= 100) palette.critical else DigitalV2Red)
            DigitalV2MetricCard(palette, trLabel(tr, "Klima", "A/C"), snapshot.acOn?.let { if (it) "A/C" else trLabel(tr, "Kapalı", "Off") } ?: "--", snapshot.acOn?.let { if (it) "ON" else null }, CardIcon.Ac, Modifier.weight(1f), compact = true, accent = DigitalV2Blue)
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Süresi", "Trip Time"), snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, Modifier.weight(1f), compact = true)
            DigitalV2MetricCard(palette, trLabel(tr, "Kullanılan Yakıt", "Fuel Used"), format1(snapshot.fuelUsedL), "L", CardIcon.FuelCalculation, Modifier.weight(1f), compact = true)
        }
    }
}

@Composable
private fun DigitalV2CompactDataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFFE7ECF2))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
    }
}

@Composable
private fun DigitalV2MetricCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    accent: Color = DigitalV2Blue
) {
    if (compact) {
        Column(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(16.dp))
                .padding(horizontal = 5.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title.uppercase(),
                color = Color(0xFF596778),
                fontSize = 8.8.sp,
                lineHeight = 9.4.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Box(
                modifier = Modifier
                    .size(29.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                value,
                color = Color(0xFF172235),
                fontSize = 19.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!unit.isNullOrBlank()) {
                Text(unit, color = Color(0xFF596778), fontSize = 9.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(20.dp))
                .padding(horizontal = 11.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title.uppercase(), color = Color(0xFF596778), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, color = Color(0xFF172235), fontSize = 26.sp, lineHeight = 27.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!unit.isNullOrBlank()) {
                        Spacer(Modifier.width(4.dp))
                        Text(unit, color = Color(0xFF596778), fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 3.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalV2SettingsPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    onSettingsChange: (LoganSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dijital V2", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(
            trLabel(tr, "Sahne seçimi aktiftir. Araç, şeritler ve yol dışı rüzgâr her arka planın gerçek yol sınırlarına göre ayrı kalibre edilir.", "Scene selection is active. The car, markings and off-road wind are calibrated separately to each background's photographed road boundaries."),
            color = palette.textSecondary,
            fontSize = 12.5.sp
        )
        DigitalV2MiniPreview(
            settings = settings,
            mode = settings.digitalV2GaugeMode,
            modifier = Modifier.fillMaxWidth().height(184.dp)
        )
        Text(trLabel(tr, "Kadran Türü", "Gauge Type"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Speed,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Speed,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Speed)) }
            )
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Rpm,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Rpm,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Rpm)) }
            )
        }
        Text(trLabel(tr, "Arka Plan Sahnesi", "Background Scene"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.take(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.drop(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceVariant.copy(alpha = .72f))
                .border(1.dp, palette.line, RoundedCornerShape(16.dp))
                .clickable { onSettingsChange(settings.copy(digitalV2MotionEnabled = !settings.digitalV2MotionEnabled)) }
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(trLabel(tr, "Hareket efektleri", "Motion effects"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text(trLabel(tr, "OpenGL şerit akışı ve yol dışı rüzgâr", "OpenGL lane flow and off-road wind"), color = palette.textSecondary, fontSize = 10.sp)
            }
            Switch(
                checked = settings.digitalV2MotionEnabled,
                onCheckedChange = { onSettingsChange(settings.copy(digitalV2MotionEnabled = it)) }
            )
        }
    }
}

@Composable
private fun DigitalV2MiniPreview(
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    val previewSnapshot = DashboardSnapshot(
        speedKmh = 78,
        rpm = 2400,
        demo = true
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF0A111B))
            .border(2.dp, DigitalV2Blue.copy(alpha = .70f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Settings lives in a LazyColumn. A static preview avoids embedding a
        // second SurfaceView/EGL context there and guarantees rounded clipping.
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxHeight()
                .aspectRatio(DIGITAL_V2_STAGE_ASPECT_RATIO)
                .clipToBounds()
        ) {
            Image(
                painter = painterResource(digitalV2BackgroundRes(settings.digitalV2Scene)),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillBounds
            )

            DigitalV2StaticRoadPreview(
                settings = settings,
                modifier = Modifier.fillMaxSize()
            )

            DigitalV2StaticVehiclePreview(
                settings = settings,
                modifier = Modifier.fillMaxSize()
            )

            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x30062A51), Color.Transparent, Color(0x42061018))
                        )
                    )
            )
            DigitalV2Gauge(
                mode = mode,
                speedKmh = previewSnapshot.speedKmh,
                rpm = previewSnapshot.rpm,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(.88f)
                    .fillMaxHeight(.90f),
                preview = true
            )
            Text(
                (if (tr) settings.digitalV2Scene.trLabel else settings.digitalV2Scene.enLabel).uppercase(),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            )
        }
    }
}

@Composable
private fun DigitalV2StaticRoadPreview(
    settings: LoganSettings,
    modifier: Modifier = Modifier
) {
    val scene = DigitalV2SceneModels.forKey(settings.digitalV2Scene.toOpenGlKey())
    Canvas(modifier = modifier) {
        val road = scene.road
        val pattern = road.markings

        fun point(curve: com.dcui.loganos.ui.cockpit.opengl.CalibratedCurve, distance: Float): Offset {
            val p = curve.sample(distance)
            return Offset(p.x * size.width, p.y * size.height)
        }

        fun normal(curve: com.dcui.loganos.ui.cockpit.opengl.CalibratedCurve, distance: Float): Offset {
            val tangent = curve.tangent(distance)
            val tx = tangent.x * size.width
            val ty = tangent.y * size.height
            val length = kotlin.math.sqrt(tx * tx + ty * ty).coerceAtLeast(0.001f)
            return Offset(-ty / length, tx / length)
        }

        fun widthPx(distance: Float, physicalWidthMeters: Float): Float {
            val roadWidth = road.roadWidthPixels(distance) / DIGITAL_V2_LOGICAL_WIDTH * size.width
            return (roadWidth * (physicalWidthMeters / road.roadWidthMeters))
                .coerceIn(1.2f, 6f)
        }

        fun drawCurveSection(
            curve: com.dcui.loganos.ui.cockpit.opengl.CalibratedCurve,
            startDistance: Float,
            endDistance: Float,
            physicalWidthMeters: Float,
            color: Color,
            subdivisions: Int = 5
        ) {
            val left = ArrayList<Offset>(subdivisions + 1)
            val right = ArrayList<Offset>(subdivisions + 1)
            for (index in 0..subdivisions) {
                val f = index.toFloat() / subdivisions.toFloat()
                val distance = startDistance + (endDistance - startDistance) * f
                val centre = point(curve, distance)
                val n = normal(curve, distance)
                val half = widthPx(distance, physicalWidthMeters) * 0.5f
                left += centre + n * half
                right += centre - n * half
            }
            val path = Path().apply {
                moveTo(left.first().x, left.first().y)
                left.drop(1).forEach { lineTo(it.x, it.y) }
                right.asReversed().forEach { lineTo(it.x, it.y) }
                close()
            }
            drawPath(path, color)
        }

        var dashStart = 0f
        while (dashStart + pattern.dashLengthMeters <= road.maxDistanceMeters) {
            drawCurveSection(
                curve = road.centerLine,
                startDistance = dashStart,
                endDistance = dashStart + pattern.dashLengthMeters,
                physicalWidthMeters = pattern.centerLineWidthMeters,
                color = Color(
                    road.centerLineColor.red,
                    road.centerLineColor.green,
                    road.centerLineColor.blue,
                    road.centerLineColor.alpha
                )
            )
            dashStart += pattern.repeatLengthMeters
        }

        fun drawContinuousEdge(
            curve: com.dcui.loganos.ui.cockpit.opengl.CalibratedCurve,
            color: GlColor
        ) {
            var distance = 0f
            while (distance < road.maxDistanceMeters) {
                val endDistance = (distance + 4f).coerceAtMost(road.maxDistanceMeters)
                drawCurveSection(
                    curve = curve,
                    startDistance = distance,
                    endDistance = endDistance,
                    physicalWidthMeters = pattern.edgeLineWidthMeters,
                    color = Color(color.red, color.green, color.blue, color.alpha),
                    subdivisions = 3
                )
                distance = endDistance
            }
        }

        if (road.showLeftEdgeLine) {
            drawContinuousEdge(road.leftRoadEdge, road.leftEdgeLineColor)
        }
        if (road.showRightEdgeLine) {
            drawContinuousEdge(road.rightRoadEdge, road.rightEdgeLineColor)
        }
    }
}

@Composable
private fun DigitalV2StaticVehiclePreview(
    settings: LoganSettings,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier) {
        val scene = DigitalV2SceneModels.forKey(settings.digitalV2Scene.toOpenGlKey())
        val pose = scene.vehiclePose
        val asset = digitalV2VehicleAssetProfile(settings.vehicleVisualModel)
        val shadow = pose.shadow

        val anchorX = maxWidth * pose.centerXRatio
        val anchorY = maxHeight * pose.tireContactYRatio
        val vehicleWidth = maxWidth *
            (pose.visibleWidthRatio / asset.visibleWidthRatioInTexture)
        val vehicleHeight = vehicleWidth * asset.textureAspectHeightOverWidth
        val vehicleLeft = anchorX - vehicleWidth / 2f
        val vehicleTop = anchorY - vehicleHeight * asset.contactYRatioInTexture

        @Composable
        fun shadowImage(
            x: Dp,
            y: Dp,
            width: Dp,
            height: Dp,
            alpha: Float
        ) {
            Image(
                painter = painterResource(digitalV2ShadowRes(settings.vehicleVisualModel)),
                contentDescription = null,
                modifier = Modifier
                    .offset(x = x - width / 2f, y = y - height / 2f)
                    .width(width)
                    .height(height)
                    .graphicsLayer {
                        this.alpha = alpha
                        rotationZ = pose.headingDegrees
                    },
                contentScale = ContentScale.FillBounds
            )
        }

        shadowImage(
            x = anchorX + maxWidth * shadow.offsetXRatio,
            y = anchorY + maxHeight * shadow.offsetYRatio,
            width = maxWidth * shadow.bodyWidthRatio,
            height = maxWidth * shadow.bodyHeightRatio,
            alpha = shadow.bodyAlpha
        )

        val fullWidthPxRatio = pose.visibleWidthRatio / asset.visibleWidthRatioInTexture
        val leftTireX = anchorX + maxWidth *
            ((asset.leftTireContactXRatioInTexture - 0.5f) * fullWidthPxRatio)
        val rightTireX = anchorX + maxWidth *
            ((asset.rightTireContactXRatioInTexture - 0.5f) * fullWidthPxRatio)
        listOf(leftTireX, rightTireX).forEach { tireX ->
            shadowImage(
                x = tireX,
                y = anchorY,
                width = maxWidth * shadow.tireWidthRatio,
                height = maxWidth * shadow.tireHeightRatio,
                alpha = shadow.tireAlpha
            )
        }

        shadowImage(
            x = anchorX,
            y = anchorY,
            width = maxWidth * shadow.groundBlendWidthRatio,
            height = maxWidth * shadow.groundBlendHeightRatio,
            alpha = shadow.groundBlendAlpha
        )

        Image(
            painter = painterResource(
                vehicleVisualDrawableRes(
                    model = settings.vehicleVisualModel,
                    color = settings.vehicleColor,
                    style = VehicleAssetStyle.Detailed
                )
            ),
            contentDescription = null,
            modifier = Modifier
                .offset(x = vehicleLeft, y = vehicleTop)
                .width(vehicleWidth)
                .height(vehicleHeight)
                .graphicsLayer {
                    rotationZ = pose.headingDegrees
                    transformOrigin = TransformOrigin(0.5f, asset.contactYRatioInTexture)
                    alpha = 0.98f
                },
            contentScale = ContentScale.Fit
        )
    }
}

@Composable
private fun DigitalV2GaugeThumbnail(
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * .47f
            val center = Offset(size.width / 2f, size.height * .68f)
            val start = 150f
            val sweep = 240f
            drawArc(
                color = Color.White.copy(alpha = .90f),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(radius * .022f, cap = StrokeCap.Round)
            )
            repeat(9) { i ->
                val f = i / 8f
                val a = Math.toRadians((start + sweep * f).toDouble())
                val p1 = Offset(center.x + cos(a).toFloat() * radius * .84f, center.y + sin(a).toFloat() * radius * .84f)
                val p2 = Offset(center.x + cos(a).toFloat() * radius, center.y + sin(a).toFloat() * radius)
                drawLine(Color.White.copy(alpha = .90f), p1, p2, radius * .016f, StrokeCap.Round)
            }
            val progress = if (mode == DigitalV2GaugeMode.Speed) 78f / 200f else 2400f / 7000f
            val needleAngle = Math.toRadians((start + sweep * progress).toDouble())
            val needleStart = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .13f,
                center.y + sin(needleAngle).toFloat() * radius * .13f
            )
            drawLine(
                Color.White,
                needleStart,
                Offset(center.x + cos(needleAngle).toFloat() * radius * .76f, center.y + sin(needleAngle).toFloat() * radius * .76f),
                radius * .020f,
                StrokeCap.Round
            )
        }
        Column(
            modifier = Modifier.align(Alignment.Center).offset(y = maxHeight * .14f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // The thumbnail follows the same rule as the cockpit: the centre shows the other value.
            Text(
                if (mode == DigitalV2GaugeMode.Speed) "24" else "78",
                color = Color.White,
                fontSize = 31.sp,
                lineHeight = 31.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h",
                color = Color.White.copy(alpha = .94f),
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DigitalV2ModeTile(
    palette: LoganPalette,
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) DigitalV2Blue.copy(alpha = .10f) else palette.surfaceVariant.copy(alpha = .62f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1B5D91))
        ) {
            DigitalV2GaugeThumbnail(mode, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(6.dp))
        Text(if (tr) mode.trLabel else mode.enLabel, color = if (selected) DigitalV2Blue else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(
            if (mode == DigitalV2GaugeMode.Speed) trLabel(tr, "Ortada devir", "RPM in center") else trLabel(tr, "Ortada hız", "Speed in center"),
            color = palette.textSecondary,
            fontSize = 10.5.sp
        )
    }
}

@Composable
private fun DigitalV2SceneTile(
    palette: LoganPalette,
    settings: LoganSettings,
    scene: DigitalV2Scene,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val selected = settings.digitalV2Scene == scene && scene.available
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (scene.available) Color(0xFF4C86AD) else palette.surfaceVariant.copy(alpha = .80f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(15.dp))
            .clickable(enabled = scene.available, onClick = onClick)
    ) {
        Image(
            painter = painterResource(digitalV2BackgroundRes(scene)),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .20f)))
        Text(if (tr) scene.trLabel else scene.enLabel, color = if (scene.available) Color.White else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
        Text(
            if (selected) trLabel(tr, "Seçili", "Selected") else trLabel(tr, "Hazır", "Ready"),
            color = if (scene.available) Color.White else palette.textSecondary,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = if (scene.available) .35f else .08f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

private fun trLabel(tr: Boolean, trValue: String, enValue: String): String = if (tr) trValue else enValue

private fun format1(value: Double?): String = value?.takeIf { it.isFinite() }?.let {
    String.format(Locale.US, "%.1f", it)
} ?: "--"
