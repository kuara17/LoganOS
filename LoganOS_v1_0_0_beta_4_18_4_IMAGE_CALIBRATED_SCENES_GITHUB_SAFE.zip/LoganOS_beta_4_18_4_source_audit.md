# LoganOS beta.4.18.4 — İki Aşamalı Kaynak Denetimi

## Amaç

Paket oluşturulduktan sonra eski Digital V2 sisteminin kalıp kalmadığını, yeni kalibrasyonların gerçekten runtime'a bağlanıp bağlanmadığını, shader/VBO kaynak hatalarını ve yanlış görsel davranış üretebilecek mantık kusurlarını aramak.

## Birinci ayrıntılı denetimde bulunan ve düzeltilenler

1. **Rüzgâr referans merkezi:** İlk uygulamada rüzgâr dışa açılımı lane divider eğrisinden türetiliyordu. Gerçek asfalt geometrik merkezi `(leftEdge + rightEdge) / 2` kullanılacak şekilde düzeltildi.
2. **Çift heading dönüşü riski:** Lastik temas noktaları önceden döndürülüp gölge quad'ı tekrar dönebiliyordu. Lastik anchor'ları artık unrotated saklanıyor ve ortak temas pivotu etrafında yalnız bir kez döndürülüyor.
3. **Tam ekran shader maliyeti:** Arka plan ve gölgeler araç için yazılmış beş texture örnekli grade shader'ını kullanıyordu. Tek örnekli basit shader ayrıldı; pahalı grade shader'ı yalnız araçta çalışıyor.
4. **VBO geçiş güvenliği:** Yeni sahne mesh'i oluşturulmadan eski mesh serbest bırakılabiliyordu. Aday `RoadMeshSet` artık transaction biçiminde tam kuruluyor, başarıdan sonra eski set değiştiriliyor; kısmi yüklemede oluşturulan VBO'lar temizleniyor ve yeniden deneme uygulanıyor.
5. **Render döngüsü tahsisleri:** Lastik gölgeleri için kare başına `listOf/Pair` üretimi kaldırıldı; araç yerleşimi yeniden kullanılan scratch nesnesine taşındı.
6. **Doğrulama montajı:** Tanı görselindeki kenar çizgisi opaklığı runtime profillerine daha yakın olacak şekilde azaltıldı.

## Eski runtime taraması

Aşağıdaki eski yapılar Digital V2 runtime yolunda bulunmuyor:

- `RoadProjectionSample`
- `RoadProjectionProfile`
- `RoadProjectiveCameraProfile`
- `RoadCurveProfile`
- `buildRoadRibbonMesh`
- `clipMatrix`
- `frameAtArc`
- `RoadFrame`
- `DigitalV2RoadLayer`
- `DigitalV2WindLayer`
- eski baked road/wind animasyon kareleri

Dijital V1 ve Premium Drive'a ait scenic/road assetleri projede bilinçli olarak korunuyor; Digital V2 tarafından referans edilmiyor.

## İkinci ayrıntılı denetim sonucu

Final ZIP yeniden açılarak aşağıdakiler tekrar çalıştırıldı:

- Android XML/resource preflight
- Digital V2 kaynak denetimi
- Tam release doğrulaması
- Gerçek JVM üzerinde geometri kontratları
- Android/Compose/OpenGL API stublarıyla renderer-host Kotlin derlemesi
- Eski runtime token ve asset taraması
- ZIP CRC/bütünlük testi

Kaynak seviyesinde yeni engelleyici hata, yanlış eski runtime yönlendirmesi veya eksik yeni dosya bulunmadı.

## Çözülemeyen / cihaz gerektiren doğrulamalar

Bu ortamda Android SDK, Gradle Wrapper ve gerçek EGL sürücüsü olmadığı için aşağıdakiler kaynak denetimiyle kesinleştirilemez:

- Gerçek `assembleDebug`
- GPU sürücüsünde shader compile/link
- SurfaceView/Compose gerçek cihaz katmanlaması
- EGL context loss sonrası görsel geri dönüş
- 2 GB RAM'li Double cihazda frame timing
- Araç gölgesi, renk grade'i ve yol çizgilerinin gerçek paneldeki nihai optik sonucu

Bu maddeler gizlenmemiştir; ilk APK cihaz testinin kabul kriterleridir.
