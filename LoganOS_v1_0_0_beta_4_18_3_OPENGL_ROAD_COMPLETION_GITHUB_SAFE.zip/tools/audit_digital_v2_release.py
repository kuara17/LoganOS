#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
base = root / 'app/src/main/java/com/dcui/loganos/ui/cockpit'
gl = base / 'opengl'
renderer = (gl / 'DigitalV2Renderer.kt').read_text(encoding='utf-8')
model = (gl / 'DigitalV2SceneModel.kt').read_text(encoding='utf-8')
cockpit = (base / 'DigitalV2Cockpit.kt').read_text(encoding='utf-8')
surface = (gl / 'LoganGLSurfaceView.kt').read_text(encoding='utf-8')
errors=[]
def need(cond,msg):
    if not cond: errors.append(msg)

for token in ('RoadProjectionSample','RoadProjectionProfile','DigitalV2SceneEngine','drawWindParticle(','frameAtArc','RoadFrame'):
    need(token not in renderer + model + cockpit, f'retired token remains: {token}')
need(cockpit.count('OpenGLSceneHost(')==1, 'live OpenGL host count is not exactly one')
need('DigitalV2StaticRoadPreview(' in cockpit, 'settings preview does not include road geometry')
need('sabit koordinatlarla hesaplanır' not in cockpit, 'retired settings description remains')
need(model.count('drawEdgeLines = true') >= 4, 'continuous edge lines are not enabled in all scene profiles')
need('cityDayRoad' in model and 'cityNightRoad' in model and 'cityRoad.copy' not in model, 'city scenes still share one camera profile')
for token in ('RoadSurfaceProgram','WindProgram','roadSurface: RoadMeshBuffer','leftWind: RoadMeshBuffer?','rightWind: RoadMeshBuffer?'):
    need(token in renderer, f'new GPU subsystem missing: {token}')
need('scene.road.project(distance' not in renderer[renderer.find('private fun drawWind'):renderer.find('private fun drawVehicleGroundShadow')], 'wind still projects screen-space particles on CPU')
need('precision highp float' not in renderer and 'varying highp float' not in renderer, 'shader requires fragment highp and may fail on ES2 devices')
need(renderer.count('aRoadDistance * 0.125') >= 3, 'mediump distance scaling is missing from one or more road shaders')
need('nextDigitalV2SmoothedSpeedKmh' in renderer, 'stopped-state speed reset helper is not used')
need('TEXTURE_RETRY_DELAY_NANOS' in renderer, 'texture retry policy is missing')
need('MAX_TEXTURE_PIXELS' in renderer and 'OutOfMemoryError' in renderer, 'texture decode size/OOM guard is missing')
need(renderer.count('widthExpansion = 1f') >= 3, 'road surface or wind ribbons incorrectly inherit line AA width expansion')
need('uStreakLengthMeters - 0.32' not in renderer, 'wind shader mixes unscaled metre constants with scaled mediump distance')
for name in ('Background','Vehicle','Shadow'):
    need(f'loaded{name}Res = state.' in renderer, f'{name.lower()} success assignment missing')
need('candidate != null' in renderer, 'texture IDs can advance without successful upload')
need('DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH' in surface, 'surface and renderer motion thresholds are not shared')
assets = root / 'app/src/main/res/drawable-nodpi'
retired = [p.name for p in assets.glob('digital_v2_*.webp') if re.search(r'_(road|wind)_(static|blur|\d{2})\.webp$',p.name)]
need(not retired, 'retired baked road/wind assets remain: '+','.join(retired[:5]))
if errors:
    print('[FAIL] Digital V2 source audit')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print('[PASS] Digital V2 source audit: no retired runtime, GPU road/shoulder systems complete, retry and idle-state guards present')
