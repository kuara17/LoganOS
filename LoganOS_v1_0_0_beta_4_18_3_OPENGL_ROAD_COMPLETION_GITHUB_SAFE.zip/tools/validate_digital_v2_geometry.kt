package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.abs

private fun requireGeometry(condition: Boolean, message: String) {
    check(condition) { message }
}

private fun projectWithClipMatrix(
    road: RoadProjectiveCameraProfile,
    distance: Float,
    lateral: Float
): Pair<Float, Float> {
    val matrix = road.clipMatrix
    val worldX = road.centerXMeters(distance) + lateral
    val worldZ = distance
    val clipX = matrix[0] * worldX + matrix[8] * worldZ + matrix[12]
    val clipY = matrix[1] * worldX + matrix[9] * worldZ + matrix[13]
    val clipW = matrix[3] * worldX + matrix[11] * worldZ + matrix[15]
    val ndcX = clipX / clipW
    val ndcY = clipY / clipW
    return ((ndcX + 1f) * 0.5f) to ((1f - ndcY) * 0.5f)
}

fun main() {
    listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
        val viewport = calculateDigitalV2Viewport(width, height)
        val aspect = viewport.width.toFloat() / viewport.height.toFloat()
        requireGeometry(
            abs(aspect - DIGITAL_V2_STAGE_ASPECT_RATIO) < 0.005f,
            "Viewport $width x $height stretches the logical stage"
        )
        requireGeometry(viewport.x >= 0 && viewport.y >= 0, "Viewport offset is negative")
        requireGeometry(viewport.x + viewport.width <= width, "Viewport exceeds surface width")
        requireGeometry(viewport.y + viewport.height <= height, "Viewport exceeds surface height")
    }
    println("[PASS] viewport: fixed 1080x1320 stage fits phone, Double and preview surfaces")

    val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    scenes.forEach { scene ->
        val road = scene.road
        var previousY = Float.POSITIVE_INFINITY
        var previousHalfWidth = Float.POSITIVE_INFINITY
        for (distance in 0..road.maxDistanceMeters.toInt()) {
            val projected = road.project(distance.toFloat())
            requireGeometry(
                projected.yRatio < previousY || distance == 0,
                "${scene.key}: farther road point does not move monotonically toward horizon at ${distance}m"
            )
            requireGeometry(
                projected.halfWidthRatio < previousHalfWidth || distance == 0,
                "${scene.key}: farther road point does not narrow monotonically at ${distance}m"
            )
            previousY = projected.yRatio
            previousHalfWidth = projected.halfWidthRatio
        }

        listOf(0f, 4f, 18f, 45f, 95f, road.maxDistanceMeters).forEach { distance ->
            listOf(-road.roadHalfWidthMeters, 0f, road.roadHalfWidthMeters).forEach { lateral ->
                val cpu = road.project(distance, lateral)
                val gpu = projectWithClipMatrix(road, distance, lateral)
                requireGeometry(abs(cpu.xRatio - gpu.first) < 0.00001f, "${scene.key}: CPU/GPU X projection mismatch")
                requireGeometry(abs(cpu.yRatio - gpu.second) < 0.00001f, "${scene.key}: CPU/GPU Y projection mismatch")
            }
        }

        val pose = scene.vehiclePose
        val vehicleAnchor = road.project(pose.anchorDistanceMeters, pose.worldLateralMeters)
        val roadCenterAtVehicle = road.project(pose.anchorDistanceMeters)
        val roadLeft = road.project(pose.anchorDistanceMeters, -road.roadHalfWidthMeters)
        val roadRight = road.project(pose.anchorDistanceMeters, road.roadHalfWidthMeters)
        requireGeometry(vehicleAnchor.xRatio in roadLeft.xRatio..roadRight.xRatio, "${scene.key}: vehicle anchor outside road")
        requireGeometry(abs(vehicleAnchor.xRatio - 0.5f) < 0.015f, "${scene.key}: follow camera does not centre vehicle")
        requireGeometry(vehicleAnchor.xRatio - roadCenterAtVehicle.xRatio > 0.12f, "${scene.key}: centre line is not visibly left of vehicle")
        requireGeometry(vehicleAnchor.yRatio in 0.82f..0.90f, "${scene.key}: vehicle contact Y is not grounded")
        requireGeometry(pose.visibleWidthRatio in 0.29f..0.31f, "${scene.key}: vehicle does not fill the accepted follow-camera area")

        val pattern = road.markings
        requireGeometry(road.drawEdgeLines, "${scene.key}: continuous edge lines are disabled")
        val wind = scene.wind
        val windCenter = road.roadHalfWidthMeters +
            wind.shoulderOffsetMeters + wind.zoneWidthMeters * 0.5f
        requireGeometry(
            windCenter - wind.zoneWidthMeters * 0.5f > road.roadHalfWidthMeters,
            "${scene.key}: wind ribbon overlaps the road surface"
        )
        requireGeometry(scene.roadMotion.enabled, "${scene.key}: road surface motion is disabled")
        requireGeometry(abs(pattern.dashLengthMeters - 3f) < 0.001f, "${scene.key}: dash length changed")
        requireGeometry(abs(pattern.gapLengthMeters - 6f) < 0.001f, "${scene.key}: gap length changed")
        requireGeometry(abs(pattern.repeatLengthMeters - 9f) < 0.001f, "${scene.key}: repeat length must be 9m")

        var previousDashPixels = Float.POSITIVE_INFINITY
        var dashStart = 0f
        while (dashStart + pattern.dashLengthMeters <= 96f) {
            val near = road.project(dashStart)
            val far = road.project(dashStart + pattern.dashLengthMeters)
            val lengthPixels = abs(near.yRatio - far.yRatio) * DIGITAL_V2_LOGICAL_HEIGHT
            requireGeometry(
                lengthPixels < previousDashPixels,
                "${scene.key}: projected 3m dash grows again at ${dashStart}m"
            )
            requireGeometry(lengthPixels >= 2.5f, "${scene.key}: far dash becomes sub-pixel and unstable")
            previousDashPixels = lengthPixels
            dashStart += pattern.repeatLengthMeters
        }

        val farDistance = 95f
        val farLeftLine = road.project(farDistance, -pattern.centerLineWidthMeters * 0.5f)
        val farRightLine = road.project(farDistance, pattern.centerLineWidthMeters * 0.5f)
        val farLinePixels = abs(farRightLine.xRatio - farLeftLine.xRatio) * DIGITAL_V2_LOGICAL_WIDTH
        requireGeometry(farLinePixels >= 2f, "${scene.key}: far centre line width aliases below 2px")

        val mesh = buildRoadRibbonMesh(
            road = road,
            lateralCenterMeters = 0f,
            visibleWidthMeters = pattern.centerLineWidthMeters
        )
        requireGeometry(mesh.vertexCount == 386, "${scene.key}: unexpected ribbon vertex count")
        requireGeometry(mesh.vertices.all { it.isFinite() }, "${scene.key}: ribbon contains non-finite values")
        var lastDistance = -1f
        for (index in 0 until mesh.vertexCount step 2) {
            val leftBase = index * 4
            val rightBase = (index + 1) * 4
            val leftDistance = mesh.vertices[leftBase + 2]
            val rightDistance = mesh.vertices[rightBase + 2]
            requireGeometry(abs(leftDistance - rightDistance) < 0.0001f, "${scene.key}: ribbon pair distances differ")
            requireGeometry(leftDistance >= lastDistance, "${scene.key}: ribbon distance goes backwards")
            requireGeometry(mesh.vertices[leftBase + 3] == 0f, "${scene.key}: left across value invalid")
            requireGeometry(mesh.vertices[rightBase + 3] == 1f, "${scene.key}: right across value invalid")
            lastDistance = leftDistance
        }

        println("[PASS] ${scene.key}: projective camera, centred 30% vehicle and shader-ribbon marking contract")
    }

    requireGeometry(
        DigitalV2SceneModels.CityDay.road !== DigitalV2SceneModels.CityNight.road,
        "City day/night still share one camera profile"
    )
    requireGeometry(
        DigitalV2SceneModels.CityDay.road.horizonYRatio !=
            DigitalV2SceneModels.CityNight.road.horizonYRatio,
        "City day/night calibration values are still identical"
    )

    val stoppedSpeed = nextDigitalV2SmoothedSpeedKmh(108f, 0f, 0.016f)
    requireGeometry(stoppedSpeed == 0f, "Stopped WHEN_DIRTY state preserves stale smoothed speed")
    val restartSpeed = nextDigitalV2SmoothedSpeedKmh(stoppedSpeed, 8f, 0.016f)
    requireGeometry(restartSpeed in 0f..2f, "Low-speed restart begins with an excessive visual speed")
    println("[PASS] animation: stopped state clears visual speed before WHEN_DIRTY")

    val formerBoundaryBefore = roadPatternPhaseMeters(9_999.99, 9f)
    val formerBoundaryAfter = roadPatternPhaseMeters(10_000.01, 9f)
    val roadForwardDelta = positiveModulo((formerBoundaryAfter - formerBoundaryBefore).toDouble(), 9.0)
    requireGeometry(abs(roadForwardDelta - 0.02) < 0.0005, "Road phase jumps at former 10,000m boundary")

    val windCycle = 51f
    val windBefore = windTravelPhaseMeters(9_999.99, windCycle)
    val windAfter = windTravelPhaseMeters(10_000.01, windCycle)
    val windForwardDelta = positiveModulo((windAfter - windBefore).toDouble(), windCycle.toDouble())
    val expectedWindDelta = 0.02 * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER
    requireGeometry(abs(windForwardDelta - expectedWindDelta) < 0.0005, "Wind phase jumps at former 10,000m boundary")
    println("[PASS] animation: road and wind phases remain continuous")
}
