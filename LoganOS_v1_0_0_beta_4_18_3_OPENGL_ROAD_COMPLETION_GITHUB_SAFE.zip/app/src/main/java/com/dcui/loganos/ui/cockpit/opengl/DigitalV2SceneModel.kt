package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Renderer-independent geometry for Digital V2.
 *
 * The background remains a fixed 1080x1320 logical stage. Dynamic road
 * markings are defined in road-space metres, uploaded as continuous ribbon
 * meshes, and projected by one calibrated projective camera matrix on the GPU.
 */
internal const val DIGITAL_V2_LOGICAL_WIDTH = 1080f
internal const val DIGITAL_V2_LOGICAL_HEIGHT = 1320f
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO =
    DIGITAL_V2_LOGICAL_WIDTH / DIGITAL_V2_LOGICAL_HEIGHT

internal data class DigitalV2PixelViewport(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

/** Fits the fixed logical stage into any Surface without X/Y distortion. */
internal fun calculateDigitalV2Viewport(surfaceWidth: Int, surfaceHeight: Int): DigitalV2PixelViewport {
    require(surfaceWidth > 0 && surfaceHeight > 0)
    val surfaceAspect = surfaceWidth.toFloat() / surfaceHeight.toFloat()
    return if (surfaceAspect > DIGITAL_V2_STAGE_ASPECT_RATIO) {
        val viewportHeight = surfaceHeight
        val viewportWidth = (viewportHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
            .toInt()
            .coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = (surfaceWidth - viewportWidth) / 2,
            y = 0,
            width = viewportWidth,
            height = viewportHeight
        )
    } else {
        val viewportWidth = surfaceWidth
        val viewportHeight = (viewportWidth / DIGITAL_V2_STAGE_ASPECT_RATIO)
            .toInt()
            .coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = 0,
            y = (surfaceHeight - viewportHeight) / 2,
            width = viewportWidth,
            height = viewportHeight
        )
    }
}

internal enum class DigitalV2SceneKey {
    MountainLake,
    CityDay,
    CityNight,
    SnowRoad
}

internal data class GlColor(
    val red: Float,
    val green: Float,
    val blue: Float,
    val alpha: Float
) {
    init {
        require(red in 0f..1f)
        require(green in 0f..1f)
        require(blue in 0f..1f)
        require(alpha in 0f..1f)
    }
}

internal data class ProjectedRoadPoint(
    val xRatio: Float,
    val yRatio: Float,
    val halfWidthRatio: Float
)

internal data class RoadMarkingPattern(
    val dashLengthMeters: Float = 3f,
    val gapLengthMeters: Float = 6f,
    val centerLineWidthMeters: Float = 0.20f,
    val edgeLineWidthMeters: Float = 0.16f,
    /** Extra ribbon width used by the fragment shader for soft line edges. */
    val antialiasExpansion: Float = 1.55f,
    /** Fade distance at the beginning/end of each dash in world metres. */
    val dashEdgeSoftnessMeters: Float = 0.12f,
    /** Normalized fade region on both sides of the ribbon. */
    val sideEdgeSoftness: Float = 0.20f
) {
    val repeatLengthMeters: Float
        get() = dashLengthMeters + gapLengthMeters

    init {
        require(dashLengthMeters > 0f)
        require(gapLengthMeters > 0f)
        require(centerLineWidthMeters > 0f)
        require(edgeLineWidthMeters > 0f)
        require(antialiasExpansion in 1f..2.5f)
        require(dashEdgeSoftnessMeters in 0.01f..0.5f)
        require(sideEdgeSoftness in 0.05f..0.45f)
    }
}

/**
 * Smooth road centre in world space. Four X control points form a cubic Bezier
 * over [0, maxDistance]. Unlike the retired screen-space knot table, this has
 * one continuous first derivative and does not repeatedly slow at sample knots.
 */
internal data class RoadCurveProfile(
    val startXMeters: Float,
    val control1XMeters: Float,
    val control2XMeters: Float,
    val endXMeters: Float
) {
    fun centerXMeters(distanceMeters: Float, maxDistanceMeters: Float): Float {
        val t = (distanceMeters / maxDistanceMeters).coerceIn(0f, 1f)
        val u = 1f - t
        return u * u * u * startXMeters +
            3f * u * u * t * control1XMeters +
            3f * u * t * t * control2XMeters +
            t * t * t * endXMeters
    }

    fun derivativeDxDz(distanceMeters: Float, maxDistanceMeters: Float): Float {
        val t = (distanceMeters / maxDistanceMeters).coerceIn(0f, 1f)
        val u = 1f - t
        val derivativeByT =
            3f * u * u * (control1XMeters - startXMeters) +
                6f * u * t * (control2XMeters - control1XMeters) +
                3f * t * t * (endXMeters - control2XMeters)
        return derivativeByT / max(0.001f, maxDistanceMeters)
    }
}

/**
 * Calibrated pinhole projection for the road plane.
 *
 * For a world-space road point (x,z):
 *   halfWidthRatio = horizontalScale / (z + depthOffset)
 *   screenYRatio   = horizonY + verticalScale / (z + depthOffset)
 *
 * The same equations are encoded in [clipMatrix] and executed in the OpenGL
 * vertex shader, so CPU previews/tests and GPU rendering share one projection.
 */
internal data class RoadProjectiveCameraProfile(
    val principalXRatio: Float,
    val horizonYRatio: Float,
    val horizontalScale: Float,
    val verticalScale: Float,
    val depthOffsetMeters: Float,
    /** Camera follows the selected lane; equal vehicle lateral => screen centre. */
    val cameraLateralMeters: Float,
    val roadHalfWidthMeters: Float,
    val maxDistanceMeters: Float,
    val curve: RoadCurveProfile,
    val markings: RoadMarkingPattern = RoadMarkingPattern(),
    val centerLineColor: GlColor = GlColor(0.98f, 0.98f, 0.96f, 0.98f),
    val edgeLineColor: GlColor = GlColor(0.96f, 0.98f, 1f, 0.72f),
    val drawEdgeLines: Boolean = true
) {
    init {
        require(principalXRatio in 0.35f..0.65f)
        require(horizonYRatio in 0.20f..0.60f)
        require(horizontalScale > 0f)
        require(verticalScale > 0f)
        require(depthOffsetMeters > 0f)
        require(roadHalfWidthMeters > 0f)
        require(maxDistanceMeters >= 60f)
    }

    fun centerXMeters(distanceMeters: Float): Float =
        curve.centerXMeters(distanceMeters.coerceIn(0f, maxDistanceMeters), maxDistanceMeters)

    fun centerDerivative(distanceMeters: Float): Float =
        curve.derivativeDxDz(distanceMeters.coerceIn(0f, maxDistanceMeters), maxDistanceMeters)

    /** Projects a point whose lateral value is measured from the road centre. */
    fun project(distanceMeters: Float, lateralFromRoadCenterMeters: Float = 0f): ProjectedRoadPoint {
        val distance = distanceMeters.coerceIn(0f, maxDistanceMeters)
        val denominator = distance + depthOffsetMeters
        val halfWidth = horizontalScale / denominator
        val worldX = centerXMeters(distance) + lateralFromRoadCenterMeters
        return ProjectedRoadPoint(
            xRatio = principalXRatio +
                ((worldX - cameraLateralMeters) / roadHalfWidthMeters) * halfWidth,
            yRatio = horizonYRatio + verticalScale / denominator,
            halfWidthRatio = halfWidth
        )
    }

    /**
     * Column-major homogeneous projective matrix consumed by GLES.
     * It maps vec4(worldX, 0, worldZ, 1) directly to clip coordinates.
     */
    val clipMatrix: FloatArray = run {
        val principalNdc = principalXRatio * 2f - 1f
        val horizonNdc = 1f - horizonYRatio * 2f
        val xScaleNdc = 2f * horizontalScale / roadHalfWidthMeters
        floatArrayOf(
            xScaleNdc, 0f, 0f, 0f,
            0f, 0f, 0f, 0f,
            principalNdc, horizonNdc, 0f, 1f,
            principalNdc * depthOffsetMeters - xScaleNdc * cameraLateralMeters,
            horizonNdc * depthOffsetMeters - 2f * verticalScale,
            0f,
            depthOffsetMeters
        )
    }
}

/** One continuous triangle-strip ribbon in road world space. */
internal data class RoadRibbonMeshData(
    /** Interleaved [worldX, worldZ, roadDistance, across] values. */
    val vertices: FloatArray,
    val vertexCount: Int
) {
    init {
        require(vertexCount >= 4)
        require(vertices.size == vertexCount * 4)
    }
}

/**
 * Builds a curvature-following ribbon once per scene. Runtime animation changes
 * only shader uniforms; no dash quads or per-frame geometry are allocated.
 */
internal fun buildRoadRibbonMesh(
    road: RoadProjectiveCameraProfile,
    lateralCenterMeters: Float,
    visibleWidthMeters: Float,
    widthExpansion: Float = road.markings.antialiasExpansion,
    segmentCount: Int = 192
): RoadRibbonMeshData {
    require(visibleWidthMeters > 0f)
    require(widthExpansion in 1f..2.5f)
    require(segmentCount >= 32)
    val expandedWidth = visibleWidthMeters * widthExpansion
    val vertices = FloatArray((segmentCount + 1) * 2 * 4)
    var cursor = 0

    for (index in 0..segmentCount) {
        val linearT = index.toFloat() / segmentCount.toFloat()
        // More geometry near the camera where perspective/curvature changes fastest.
        val distance = road.maxDistanceMeters * linearT * linearT
        val centerX = road.centerXMeters(distance)
        val dxDz = road.centerDerivative(distance)
        val inverseLength = 1f / sqrt(1f + dxDz * dxDz)
        val normalX = inverseLength
        val normalZ = -dxDz * inverseLength

        for (side in 0..1) {
            val across = side.toFloat()
            val offset = lateralCenterMeters +
                (across - 0.5f) * expandedWidth
            val worldX = centerX + normalX * offset
            val worldZ = distance + normalZ * offset

            vertices[cursor++] = worldX
            vertices[cursor++] = worldZ
            vertices[cursor++] = distance
            vertices[cursor++] = across
        }
    }

    return RoadRibbonMeshData(
        vertices = vertices,
        vertexCount = (segmentCount + 1) * 2
    )
}

internal data class VehicleAssetProfile(
    val textureAspectHeightOverWidth: Float,
    val visibleWidthRatioInTexture: Float,
    val contactYRatioInTexture: Float
) {
    init {
        require(textureAspectHeightOverWidth > 0f)
        require(visibleWidthRatioInTexture in 0.5f..1f)
        require(contactYRatioInTexture in 0.5f..1f)
    }
}

internal data class VehicleScenePose(
    val anchorDistanceMeters: Float,
    /** World-space lane position. The camera uses the same value to centre it. */
    val worldLateralMeters: Float,
    /** Visible non-transparent body width relative to the logical stage. */
    val visibleWidthRatio: Float,
    val headingDegrees: Float,
    val shadowWidthRatio: Float,
    val shadowAlpha: Float,
    val colorMultiplier: GlColor = GlColor(1f, 1f, 1f, 1f)
) {
    init {
        require(anchorDistanceMeters >= 0f)
        require(visibleWidthRatio in 0.18f..0.38f)
        require(shadowWidthRatio in 0.15f..0.38f)
        require(shadowAlpha in 0f..1f)
    }
}

internal data class RoadSurfaceMotionProfile(
    val enabled: Boolean = true,
    /** Maximum premultiplied overlay alpha at high speed. */
    val maxAlpha: Float = 0.035f,
    val cycleLengthMeters: Float = 4.8f,
    val nearFadeDistanceMeters: Float = 55f
) {
    init {
        require(maxAlpha in 0f..0.12f)
        require(cycleLengthMeters > 0f)
        require(nearFadeDistanceMeters > 5f)
    }
}

/**
 * Wind is a pair of road-following shoulder ribbons rendered by one shader.
 * It never uses screen-space quads and therefore cannot drift onto the road
 * when the viewport changes.
 */
internal data class WindProfile(
    val enabled: Boolean = true,
    val shoulderOffsetMeters: Float = 1.05f,
    val zoneWidthMeters: Float = 1.20f,
    val spacingMeters: Float = 8.5f,
    val streakLengthMeters: Float = 1.9f,
    val maxAlpha: Float = 0.11f
) {
    init {
        require(shoulderOffsetMeters >= 0f)
        require(zoneWidthMeters in 0.4f..3f)
        require(spacingMeters > streakLengthMeters)
        require(streakLengthMeters > 0f)
        require(maxAlpha in 0f..0.35f)
    }
}

internal data class DigitalV2SceneModel(
    val key: DigitalV2SceneKey,
    val road: RoadProjectiveCameraProfile,
    val vehiclePose: VehicleScenePose,
    val wind: WindProfile,
    val roadMotion: RoadSurfaceMotionProfile = RoadSurfaceMotionProfile()
)

internal object DigitalV2SceneModels {
    private val mountainRoad = RoadProjectiveCameraProfile(
        principalXRatio = 0.500f,
        horizonYRatio = 0.3514f,
        horizontalScale = 7.7972f,
        verticalScale = 8.7317f,
        depthOffsetMeters = 12.8776f,
        cameraLateralMeters = 2.20f,
        roadHalfWidthMeters = 5.50f,
        maxDistanceMeters = 120f,
        curve = RoadCurveProfile(
            startXMeters = -0.10f,
            control1XMeters = -0.05f,
            control2XMeters = 0.75f,
            endXMeters = 1.25f
        ),
        centerLineColor = GlColor(0.98f, 0.98f, 0.96f, 0.98f),
        edgeLineColor = GlColor(0.96f, 0.98f, 1f, 0.82f),
        drawEdgeLines = true
    )

    val MountainLake = DigitalV2SceneModel(
        key = DigitalV2SceneKey.MountainLake,
        road = mountainRoad,
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.0f,
            worldLateralMeters = mountainRoad.cameraLateralMeters,
            visibleWidthRatio = 0.300f,
            headingDegrees = 0.25f,
            shadowWidthRatio = 0.285f,
            shadowAlpha = 0.62f,
            colorMultiplier = GlColor(0.97f, 0.99f, 1f, 1f)
        ),
        wind = WindProfile(maxAlpha = 0.085f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.030f)
    )

    /* City Day and City Night deliberately use separate camera profiles. */
    private val cityDayRoad = RoadProjectiveCameraProfile(
        principalXRatio = 0.500f,
        horizonYRatio = 0.396f,
        horizontalScale = 7.30f,
        verticalScale = 7.90f,
        depthOffsetMeters = 13.20f,
        cameraLateralMeters = 2.15f,
        roadHalfWidthMeters = 5.60f,
        maxDistanceMeters = 120f,
        curve = RoadCurveProfile(0f, 0f, 0f, 0f),
        centerLineColor = GlColor(0.98f, 0.98f, 0.96f, 0.98f),
        edgeLineColor = GlColor(0.98f, 0.99f, 1f, 0.78f),
        drawEdgeLines = true
    )

    val CityDay = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityDay,
        road = cityDayRoad,
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.0f,
            worldLateralMeters = cityDayRoad.cameraLateralMeters,
            visibleWidthRatio = 0.300f,
            headingDegrees = 0f,
            shadowWidthRatio = 0.285f,
            shadowAlpha = 0.58f
        ),
        wind = WindProfile(shoulderOffsetMeters = 1.15f, maxAlpha = 0.075f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.026f)
    )

    private val cityNightRoad = RoadProjectiveCameraProfile(
        principalXRatio = 0.500f,
        horizonYRatio = 0.405f,
        horizontalScale = 7.15f,
        verticalScale = 7.75f,
        depthOffsetMeters = 13.00f,
        cameraLateralMeters = 2.15f,
        roadHalfWidthMeters = 5.60f,
        maxDistanceMeters = 120f,
        curve = RoadCurveProfile(0f, 0f, 0f, 0f),
        centerLineColor = GlColor(0.98f, 0.97f, 0.91f, 0.98f),
        edgeLineColor = GlColor(0.90f, 0.93f, 1f, 0.66f),
        drawEdgeLines = true
    )

    val CityNight = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityNight,
        road = cityNightRoad,
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.0f,
            worldLateralMeters = cityNightRoad.cameraLateralMeters,
            visibleWidthRatio = 0.300f,
            headingDegrees = 0f,
            shadowWidthRatio = 0.285f,
            shadowAlpha = 0.52f,
            colorMultiplier = GlColor(0.84f, 0.80f, 0.76f, 1f)
        ),
        wind = WindProfile(shoulderOffsetMeters = 1.15f, maxAlpha = 0.080f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.022f)
    )

    private val snowRoad = RoadProjectiveCameraProfile(
        principalXRatio = 0.500f,
        horizonYRatio = 0.3568f,
        horizontalScale = 7.6897f,
        verticalScale = 8.6953f,
        depthOffsetMeters = 12.9843f,
        cameraLateralMeters = 2.20f,
        roadHalfWidthMeters = 5.50f,
        maxDistanceMeters = 120f,
        curve = RoadCurveProfile(
            startXMeters = 0f,
            control1XMeters = 0.15f,
            control2XMeters = 0.45f,
            endXMeters = -0.75f
        ),
        centerLineColor = GlColor(0.98f, 0.98f, 0.96f, 0.98f),
        edgeLineColor = GlColor(0.98f, 0.99f, 1f, 0.86f),
        drawEdgeLines = true
    )

    val SnowRoad = DigitalV2SceneModel(
        key = DigitalV2SceneKey.SnowRoad,
        road = snowRoad,
        vehiclePose = VehicleScenePose(
            anchorDistanceMeters = 4.0f,
            worldLateralMeters = snowRoad.cameraLateralMeters,
            visibleWidthRatio = 0.300f,
            headingDegrees = -0.20f,
            shadowWidthRatio = 0.285f,
            shadowAlpha = 0.54f,
            colorMultiplier = GlColor(0.93f, 0.98f, 1f, 1f)
        ),
        wind = WindProfile(maxAlpha = 0.075f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.028f)
    )

    fun forKey(key: DigitalV2SceneKey): DigitalV2SceneModel = when (key) {
        DigitalV2SceneKey.MountainLake -> MountainLake
        DigitalV2SceneKey.CityDay -> CityDay
        DigitalV2SceneKey.CityNight -> CityNight
        DigitalV2SceneKey.SnowRoad -> SnowRoad
    }
}

internal fun lerp(start: Float, end: Float, t: Float): Float =
    start + (end - start) * min(1f, max(0f, t))
