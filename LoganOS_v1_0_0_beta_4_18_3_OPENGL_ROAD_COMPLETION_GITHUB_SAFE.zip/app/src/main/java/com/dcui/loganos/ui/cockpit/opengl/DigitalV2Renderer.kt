package com.dcui.loganos.ui.cockpit.opengl

import android.content.Context
import android.graphics.BitmapFactory
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.GLUtils
import android.util.Log
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.atomic.AtomicReference
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * OpenGL ES 2.0 renderer for the Digital V2 visual scene.
 *
 * Compose owns HUD/controls. OpenGL owns the background, a projective road
 * ribbon, shader-generated 3m/6m markings, wind, road contact shadow and car.
 * The GL thread consumes immutable snapshots through [pendingState].
 */
internal class DigitalV2Renderer(
    private val context: Context
) : GLSurfaceView.Renderer {

    private val pendingState = AtomicReference(DigitalV2RenderState.Empty)
    private var activeState = DigitalV2RenderState.Empty

    private var texturedProgram: TexturedProgram? = null
    private var solidProgram: SolidProgram? = null
    private var roadMarkingProgram: RoadMarkingProgram? = null
    private var roadSurfaceProgram: RoadSurfaceProgram? = null
    private var windProgram: WindProgram? = null

    private var backgroundTexture: GlTexture? = null
    private var vehicleTexture: GlTexture? = null
    private var shadowTexture: GlTexture? = null
    private var loadedBackgroundRes = 0
    private var loadedVehicleRes = 0
    private var loadedShadowRes = 0
    private var nextBackgroundTextureRetryNanos = 0L
    private var nextVehicleTextureRetryNanos = 0L
    private var nextShadowTextureRetryNanos = 0L

    private var roadMeshes: RoadMeshSet? = null
    private var loadedRoadSceneKey: DigitalV2SceneKey? = null

    private var lastFrameNanos = 0L
    private var smoothedSpeedKmh = 0f
    private var totalTravelledMeters = 0.0

    /** Reused GL vertex scratch arrays; no per-draw direct buffers are allocated. */
    private val texturedVertexScratch = FloatArray(16)
    private val solidVertexScratch = FloatArray(12)

    fun submitState(state: DigitalV2RenderState) {
        pendingState.set(state)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // A new EGL context invalidates every old GL object name.
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0
        nextBackgroundTextureRetryNanos = 0L
        nextVehicleTextureRetryNanos = 0L
        nextShadowTextureRetryNanos = 0L
        roadMeshes = null
        loadedRoadSceneKey = null

        GLES20.glClearColor(0.03f, 0.05f, 0.08f, 1f)
        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glEnable(GLES20.GL_BLEND)
        // Android bitmaps uploaded through GLUtils are premultiplied-alpha.
        GLES20.glBlendFunc(GLES20.GL_ONE, GLES20.GL_ONE_MINUS_SRC_ALPHA)

        texturedProgram = TexturedProgram()
        solidProgram = SolidProgram()
        roadMarkingProgram = RoadMarkingProgram()
        roadSurfaceProgram = RoadSurfaceProgram()
        windProgram = WindProgram()
        lastFrameNanos = 0L
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        val viewport = calculateDigitalV2Viewport(width, height)
        GLES20.glViewport(viewport.x, viewport.y, viewport.width, viewport.height)
    }

    override fun onDrawFrame(gl: GL10?) {
        activeState = pendingState.get()
        ensureTextures(activeState)
        ensureRoadMeshes(activeState.sceneModel)
        updateClock(activeState)

        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        drawBackground()
        drawRoadSurfaceMotion(activeState.sceneModel)
        drawRoadMarkings(activeState.sceneModel)
        drawWind(activeState.sceneModel)
        drawVehicleGroundShadow(activeState)
        drawVehicle(activeState)

        if (activeState.calibrationVisible) {
            drawCalibration(activeState.sceneModel)
        }
    }

    fun releaseGlResources() {
        releaseTexture(backgroundTexture)
        releaseTexture(vehicleTexture)
        releaseTexture(shadowTexture)
        backgroundTexture = null
        vehicleTexture = null
        shadowTexture = null
        loadedBackgroundRes = 0
        loadedVehicleRes = 0
        loadedShadowRes = 0

        roadMeshes?.release()
        roadMeshes = null
        loadedRoadSceneKey = null

        texturedProgram?.release()
        solidProgram?.release()
        roadMarkingProgram?.release()
        roadSurfaceProgram?.release()
        windProgram?.release()
        texturedProgram = null
        solidProgram = null
        roadMarkingProgram = null
        roadSurfaceProgram = null
        windProgram = null
    }

    private fun updateClock(state: DigitalV2RenderState) {
        val now = System.nanoTime()
        if (lastFrameNanos == 0L) {
            lastFrameNanos = now
            smoothedSpeedKmh = if (state.motionEnabled) {
                state.speedKmh.coerceAtLeast(0f)
            } else {
                0f
            }
            return
        }
        val dtSeconds = ((now - lastFrameNanos) / 1_000_000_000.0)
            .toFloat()
            .coerceIn(0f, 0.05f)
        lastFrameNanos = now

        val targetSpeed = if (state.motionEnabled) {
            state.speedKmh.coerceIn(0f, 180f)
        } else {
            0f
        }
        smoothedSpeedKmh = nextDigitalV2SmoothedSpeedKmh(
            currentSpeedKmh = smoothedSpeedKmh,
            targetSpeedKmh = targetSpeed,
            deltaSeconds = dtSeconds
        )

        if (smoothedSpeedKmh >= DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH) {
            totalTravelledMeters +=
                (smoothedSpeedKmh.toDouble() / 3.6) * dtSeconds.toDouble()
        }
    }

    private fun ensureTextures(state: DigitalV2RenderState) {
        val now = System.nanoTime()

        if (state.backgroundResId == 0) {
            releaseTexture(backgroundTexture)
            backgroundTexture = null
            loadedBackgroundRes = 0
        } else if ((state.backgroundResId != loadedBackgroundRes || backgroundTexture == null) &&
            now >= nextBackgroundTextureRetryNanos
        ) {
            val candidate = loadTexture(state.backgroundResId)
            if (candidate != null) {
                releaseTexture(backgroundTexture)
                backgroundTexture = candidate
                loadedBackgroundRes = state.backgroundResId
                nextBackgroundTextureRetryNanos = 0L
            } else {
                nextBackgroundTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }

        if (state.vehicleResId == 0) {
            releaseTexture(vehicleTexture)
            vehicleTexture = null
            loadedVehicleRes = 0
        } else if ((state.vehicleResId != loadedVehicleRes || vehicleTexture == null) &&
            now >= nextVehicleTextureRetryNanos
        ) {
            val candidate = loadTexture(state.vehicleResId)
            if (candidate != null) {
                releaseTexture(vehicleTexture)
                vehicleTexture = candidate
                loadedVehicleRes = state.vehicleResId
                nextVehicleTextureRetryNanos = 0L
            } else {
                nextVehicleTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }

        if (state.shadowResId == 0) {
            releaseTexture(shadowTexture)
            shadowTexture = null
            loadedShadowRes = 0
        } else if ((state.shadowResId != loadedShadowRes || shadowTexture == null) &&
            now >= nextShadowTextureRetryNanos
        ) {
            val candidate = loadTexture(state.shadowResId)
            if (candidate != null) {
                releaseTexture(shadowTexture)
                shadowTexture = candidate
                loadedShadowRes = state.shadowResId
                nextShadowTextureRetryNanos = 0L
            } else {
                nextShadowTextureRetryNanos = now + TEXTURE_RETRY_DELAY_NANOS
            }
        }
    }

    private fun ensureRoadMeshes(scene: DigitalV2SceneModel) {
        if (loadedRoadSceneKey == scene.key && roadMeshes != null) return
        roadMeshes?.release()
        roadMeshes = RoadMeshSet.create(scene)
        loadedRoadSceneKey = scene.key
    }

    private fun drawBackground() {
        val texture = backgroundTexture ?: return
        drawTexturedQuad(
            texture = texture,
            centerX = DIGITAL_V2_LOGICAL_WIDTH * 0.5f,
            centerY = DIGITAL_V2_LOGICAL_HEIGHT * 0.5f,
            width = DIGITAL_V2_LOGICAL_WIDTH,
            height = DIGITAL_V2_LOGICAL_HEIGHT,
            rotationDegrees = 0f,
            alpha = 1f,
            colorMultiplier = WHITE
        )
    }

    private fun drawRoadSurfaceMotion(scene: DigitalV2SceneModel) {
        val profile = scene.roadMotion
        if (!profile.enabled || !activeState.motionEnabled ||
            smoothedSpeedKmh < ROAD_SURFACE_MIN_SPEED_KMH
        ) return
        val mesh = roadMeshes?.roadSurface ?: return
        val strength = ((smoothedSpeedKmh - ROAD_SURFACE_MIN_SPEED_KMH) / 90f)
            .coerceIn(0f, 1f)
        roadSurfaceProgram?.draw(
            mesh = mesh,
            clipMatrix = scene.road.clipMatrix,
            phaseMeters = roadSurfacePhaseMeters(
                totalTravelledMeters,
                profile.cycleLengthMeters
            ),
            cycleLengthMeters = profile.cycleLengthMeters,
            nearFadeDistanceMeters = profile.nearFadeDistanceMeters,
            alpha = profile.maxAlpha * strength,
            tint = ROAD_SURFACE_TINT
        )
    }

    /**
     * One continuous VBO is rendered for the centre line. The 3m dash / 6m gap
     * pattern is generated in the fragment shader from world distance, so dash
     * shape never stretches independently or stalls at calibration knots.
     */
    private fun drawRoadMarkings(scene: DigitalV2SceneModel) {
        val program = roadMarkingProgram ?: return
        val meshes = roadMeshes ?: return
        val road = scene.road
        val pattern = road.markings
        val phase = roadPatternPhaseMeters(totalTravelledMeters, pattern.repeatLengthMeters)

        program.draw(
            mesh = meshes.center,
            clipMatrix = road.clipMatrix,
            color = road.centerLineColor,
            dashed = true,
            phaseMeters = phase,
            pattern = pattern
        )

        if (road.drawEdgeLines) {
            meshes.leftEdge?.let {
                program.draw(
                    mesh = it,
                    clipMatrix = road.clipMatrix,
                    color = road.edgeLineColor,
                    dashed = false,
                    phaseMeters = 0f,
                    pattern = pattern
                )
            }
            meshes.rightEdge?.let {
                program.draw(
                    mesh = it,
                    clipMatrix = road.clipMatrix,
                    color = road.edgeLineColor,
                    dashed = false,
                    phaseMeters = 0f,
                    pattern = pattern
                )
            }
        }
    }

    private fun drawWind(scene: DigitalV2SceneModel) {
        val wind = scene.wind
        if (!wind.enabled || !activeState.motionEnabled || smoothedSpeedKmh < 8f) return
        val meshes = roadMeshes ?: return
        val strength = ((smoothedSpeedKmh - 8f) / 92f).coerceIn(0f, 1f)
        val phase = windTravelPhaseMeters(totalTravelledMeters, wind.spacingMeters)
        val pulse = windPulsePhaseRadians(totalTravelledMeters)
        meshes.leftWind?.let { mesh ->
            windProgram?.draw(
                mesh = mesh,
                clipMatrix = scene.road.clipMatrix,
                phaseMeters = phase,
                spacingMeters = wind.spacingMeters,
                streakLengthMeters = wind.streakLengthMeters,
                pulseRadians = pulse,
                alpha = wind.maxAlpha * strength,
                sideSign = -1f
            )
        }
        meshes.rightWind?.let { mesh ->
            windProgram?.draw(
                mesh = mesh,
                clipMatrix = scene.road.clipMatrix,
                phaseMeters = phase,
                spacingMeters = wind.spacingMeters,
                streakLengthMeters = wind.streakLengthMeters,
                pulseRadians = pulse,
                alpha = wind.maxAlpha * strength,
                sideSign = 1f
            )
        }
    }

    private fun drawVehicleGroundShadow(state: DigitalV2RenderState) {
        val texture = shadowTexture ?: return
        val scene = state.sceneModel
        val pose = scene.vehiclePose
        val anchor = scene.road
            .project(pose.anchorDistanceMeters, pose.worldLateralMeters)
            .toLogicalPoint()
        val width = DIGITAL_V2_LOGICAL_WIDTH * pose.shadowWidthRatio
        val height = width * (texture.height.toFloat() / max(1, texture.width).toFloat())
        drawTexturedQuad(
            texture = texture,
            centerX = anchor.x,
            centerY = anchor.y - height * 0.05f,
            width = width,
            height = height,
            rotationDegrees = pose.headingDegrees,
            alpha = pose.shadowAlpha,
            colorMultiplier = WHITE,
            rotationPivotX = anchor.x,
            rotationPivotY = anchor.y
        )
    }

    private fun drawVehicle(state: DigitalV2RenderState) {
        val texture = vehicleTexture ?: return
        val scene = state.sceneModel
        val pose = scene.vehiclePose
        val anchor = scene.road
            .project(pose.anchorDistanceMeters, pose.worldLateralMeters)
            .toLogicalPoint()
        val fullTextureWidth = DIGITAL_V2_LOGICAL_WIDTH *
            (pose.visibleWidthRatio / state.vehicleAsset.visibleWidthRatioInTexture)
        val fullTextureHeight = fullTextureWidth * state.vehicleAsset.textureAspectHeightOverWidth
        val top = anchor.y - fullTextureHeight * state.vehicleAsset.contactYRatioInTexture

        // The road moves beneath a fixed tyre-contact anchor. The camera follows
        // the same lane, therefore the vehicle stays centred without sitting on
        // the centre line.
        drawTexturedQuad(
            texture = texture,
            centerX = anchor.x,
            centerY = top + fullTextureHeight * 0.5f,
            width = fullTextureWidth,
            height = fullTextureHeight,
            rotationDegrees = pose.headingDegrees,
            alpha = 1f,
            colorMultiplier = pose.colorMultiplier,
            rotationPivotX = anchor.x,
            rotationPivotY = anchor.y
        )
    }

    private fun drawCalibration(scene: DigitalV2SceneModel) {
        var distance = 0f
        while (distance <= scene.road.maxDistanceMeters) {
            val center = scene.road.project(distance).toLogicalPoint()
            drawSolidQuad(
                LogicalPoint(center.x - 3f, center.y - 3f),
                LogicalPoint(center.x + 3f, center.y - 3f),
                LogicalPoint(center.x + 3f, center.y + 3f),
                LogicalPoint(center.x - 3f, center.y + 3f),
                MAGENTA
            )
            distance += 10f
        }

        val anchor = scene.road
            .project(scene.vehiclePose.anchorDistanceMeters, scene.vehiclePose.worldLateralMeters)
            .toLogicalPoint()
        drawSegmentQuad(
            start = LogicalPoint(anchor.x - 26f, anchor.y),
            end = LogicalPoint(anchor.x + 26f, anchor.y),
            widthPixels = 3f,
            color = GREEN
        )
    }

    private fun drawTexturedQuad(
        texture: GlTexture,
        centerX: Float,
        centerY: Float,
        width: Float,
        height: Float,
        rotationDegrees: Float,
        alpha: Float,
        colorMultiplier: GlColor,
        rotationPivotX: Float = centerX,
        rotationPivotY: Float = centerY
    ) {
        val program = texturedProgram ?: return
        val halfW = width * 0.5f
        val halfH = height * 0.5f
        val radians = rotationDegrees * PI.toFloat() / 180f
        val cosAngle = cos(radians)
        val sinAngle = sin(radians)

        fun writeCorner(outputIndex: Int, localX: Float, localY: Float, u: Float, v: Float) {
            val unrotatedX = centerX + localX
            val unrotatedY = centerY + localY
            val relativeX = unrotatedX - rotationPivotX
            val relativeY = unrotatedY - rotationPivotY
            val x = rotationPivotX + relativeX * cosAngle - relativeY * sinAngle
            val y = rotationPivotY + relativeX * sinAngle + relativeY * cosAngle
            texturedVertexScratch[outputIndex] = x / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
            texturedVertexScratch[outputIndex + 1] = 1f - y / DIGITAL_V2_LOGICAL_HEIGHT * 2f
            texturedVertexScratch[outputIndex + 2] = u
            texturedVertexScratch[outputIndex + 3] = v
        }

        writeCorner(0, -halfW, -halfH, 0f, 0f)
        writeCorner(4, -halfW, halfH, 0f, 1f)
        writeCorner(8, halfW, -halfH, 1f, 0f)
        writeCorner(12, halfW, halfH, 1f, 1f)
        program.draw(texture.id, texturedVertexScratch, alpha, colorMultiplier)
    }

    private fun drawSolidQuad(
        p1: LogicalPoint,
        p2: LogicalPoint,
        p3: LogicalPoint,
        p4: LogicalPoint,
        color: GlColor
    ) {
        writeNdc(solidVertexScratch, 0, p1)
        writeNdc(solidVertexScratch, 2, p2)
        writeNdc(solidVertexScratch, 4, p3)
        writeNdc(solidVertexScratch, 6, p1)
        writeNdc(solidVertexScratch, 8, p3)
        writeNdc(solidVertexScratch, 10, p4)
        solidProgram?.draw(solidVertexScratch, color)
    }

    private fun writeNdc(array: FloatArray, index: Int, point: LogicalPoint) {
        array[index] = point.x / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
        array[index + 1] = 1f - point.y / DIGITAL_V2_LOGICAL_HEIGHT * 2f
    }

    private fun drawSegmentQuad(
        start: LogicalPoint,
        end: LogicalPoint,
        widthPixels: Float,
        color: GlColor
    ) {
        val dx = end.x - start.x
        val dy = end.y - start.y
        val length = sqrt(dx * dx + dy * dy)
        if (length < 0.01f) return
        val normalX = -dy / length * widthPixels * 0.5f
        val normalY = dx / length * widthPixels * 0.5f
        drawSolidQuad(
            LogicalPoint(start.x + normalX, start.y + normalY),
            LogicalPoint(start.x - normalX, start.y - normalY),
            LogicalPoint(end.x - normalX, end.y - normalY),
            LogicalPoint(end.x + normalX, end.y + normalY),
            color
        )
    }

    private fun ProjectedRoadPoint.toLogicalPoint(): LogicalPoint = LogicalPoint(
        x = xRatio * DIGITAL_V2_LOGICAL_WIDTH,
        y = yRatio * DIGITAL_V2_LOGICAL_HEIGHT
    )

    private fun loadTexture(resourceId: Int): GlTexture? {
        val options = BitmapFactory.Options().apply {
            inScaled = false
            inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
        }
        var bitmap: android.graphics.Bitmap? = null
        var textureId = 0
        return try {
            bitmap = BitmapFactory.decodeResource(context.resources, resourceId, options) ?: return null
            val pixelCount = bitmap.width.toLong() * bitmap.height.toLong()
            if (pixelCount > MAX_TEXTURE_PIXELS) {
                Log.e(
                    TAG,
                    "Texture rejected for resource $resourceId: ${bitmap.width}x${bitmap.height}",
                    IllegalArgumentException("Texture exceeds $MAX_TEXTURE_PIXELS pixels")
                )
                return null
            }

            val names = IntArray(1)
            GLES20.glGenTextures(1, names, 0)
            textureId = names[0]
            if (textureId == 0) return null

            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
            GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bitmap, 0)
            GlTexture(textureId, bitmap.width, bitmap.height)
        } catch (error: RuntimeException) {
            if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            Log.e(TAG, "Texture load failed for resource $resourceId", error)
            null
        } catch (error: OutOfMemoryError) {
            if (textureId != 0) GLES20.glDeleteTextures(1, intArrayOf(textureId), 0)
            Log.e(TAG, "Texture allocation failed for resource $resourceId", error)
            null
        } finally {
            bitmap?.recycle()
        }
    }

    private fun releaseTexture(texture: GlTexture?) {
        texture ?: return
        GLES20.glDeleteTextures(1, intArrayOf(texture.id), 0)
    }

    private data class LogicalPoint(val x: Float, val y: Float)
    private data class GlTexture(val id: Int, val width: Int, val height: Int)

    private data class RoadMeshBuffer(
        val bufferId: Int,
        val vertexCount: Int
    ) {
        fun release() {
            GLES20.glDeleteBuffers(1, intArrayOf(bufferId), 0)
        }

    companion object {
            fun upload(data: RoadRibbonMeshData): RoadMeshBuffer {
                val names = IntArray(1)
                GLES20.glGenBuffers(1, names, 0)
                check(names[0] != 0) { "Unable to create road VBO" }
                val buffer = allocateFloatBuffer(data.vertices.size)
                buffer.put(data.vertices)
                buffer.position(0)
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, names[0])
                GLES20.glBufferData(
                    GLES20.GL_ARRAY_BUFFER,
                    data.vertices.size * 4,
                    buffer,
                    GLES20.GL_STATIC_DRAW
                )
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
                return RoadMeshBuffer(names[0], data.vertexCount)
            }
        }
    }

    private data class RoadMeshSet(
        val center: RoadMeshBuffer,
        val leftEdge: RoadMeshBuffer?,
        val rightEdge: RoadMeshBuffer?,
        val roadSurface: RoadMeshBuffer,
        val leftWind: RoadMeshBuffer?,
        val rightWind: RoadMeshBuffer?
    ) {
        fun release() {
            center.release()
            leftEdge?.release()
            rightEdge?.release()
            roadSurface.release()
            leftWind?.release()
            rightWind?.release()
        }

        companion object {
            fun create(scene: DigitalV2SceneModel): RoadMeshSet {
                val road = scene.road
                val pattern = road.markings
                val center = RoadMeshBuffer.upload(
                    buildRoadRibbonMesh(
                        road = road,
                        lateralCenterMeters = 0f,
                        visibleWidthMeters = pattern.centerLineWidthMeters
                    )
                )
                val inset = pattern.edgeLineWidthMeters * 0.65f
                val left = if (road.drawEdgeLines) {
                    RoadMeshBuffer.upload(
                        buildRoadRibbonMesh(
                            road = road,
                            lateralCenterMeters = -(road.roadHalfWidthMeters - inset),
                            visibleWidthMeters = pattern.edgeLineWidthMeters
                        )
                    )
                } else null
                val right = if (road.drawEdgeLines) {
                    RoadMeshBuffer.upload(
                        buildRoadRibbonMesh(
                            road = road,
                            lateralCenterMeters = road.roadHalfWidthMeters - inset,
                            visibleWidthMeters = pattern.edgeLineWidthMeters
                        )
                    )
                } else null
                val roadSurface = RoadMeshBuffer.upload(
                    buildRoadRibbonMesh(
                        road = road,
                        lateralCenterMeters = 0f,
                        visibleWidthMeters = road.roadHalfWidthMeters * 1.94f,
                        widthExpansion = 1f
                    )
                )
                val wind = scene.wind
                val windCenterOffset = road.roadHalfWidthMeters +
                    wind.shoulderOffsetMeters + wind.zoneWidthMeters * 0.5f
                val leftWind = if (wind.enabled) {
                    RoadMeshBuffer.upload(
                        buildRoadRibbonMesh(
                            road = road,
                            lateralCenterMeters = -windCenterOffset,
                            visibleWidthMeters = wind.zoneWidthMeters,
                            widthExpansion = 1f
                        )
                    )
                } else null
                val rightWind = if (wind.enabled) {
                    RoadMeshBuffer.upload(
                        buildRoadRibbonMesh(
                            road = road,
                            lateralCenterMeters = windCenterOffset,
                            visibleWidthMeters = wind.zoneWidthMeters,
                            widthExpansion = 1f
                        )
                    )
                } else null
                return RoadMeshSet(center, left, right, roadSurface, leftWind, rightWind)
            }
        }
    }

    private class TexturedProgram {
        private val programId = createProgram(TEXTURED_VERTEX_SHADER, TEXTURED_FRAGMENT_SHADER)
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val textureCoordinateHandle = GLES20.glGetAttribLocation(programId, "aTexCoord")
        private val textureHandle = GLES20.glGetUniformLocation(programId, "uTexture")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val colorMultiplierHandle = GLES20.glGetUniformLocation(programId, "uColorMultiplier")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(16)

        fun draw(
            textureId: Int,
            vertices: FloatArray,
            alpha: Float,
            colorMultiplier: GlColor
        ) {
            vertexBuffer.clear()
            vertexBuffer.put(vertices, 0, 16)
            vertexBuffer.position(0)

            GLES20.glUseProgram(programId)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                16,
                vertexBuffer
            )
            vertexBuffer.position(2)
            GLES20.glEnableVertexAttribArray(textureCoordinateHandle)
            GLES20.glVertexAttribPointer(
                textureCoordinateHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                16,
                vertexBuffer
            )
            GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
            GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, textureId)
            GLES20.glUniform1i(textureHandle, 0)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 1f))
            GLES20.glUniform4f(
                colorMultiplierHandle,
                colorMultiplier.red,
                colorMultiplier.green,
                colorMultiplier.blue,
                colorMultiplier.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(positionHandle)
            GLES20.glDisableVertexAttribArray(textureCoordinateHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    private class SolidProgram {
        private val programId = createProgram(SOLID_VERTEX_SHADER, SOLID_FRAGMENT_SHADER)
        private val positionHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        private val colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        private val vertexBuffer: FloatBuffer = allocateFloatBuffer(12)

        fun draw(vertices: FloatArray, color: GlColor) {
            vertexBuffer.clear()
            vertexBuffer.put(vertices, 0, 12)
            vertexBuffer.position(0)

            GLES20.glUseProgram(programId)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(
                positionHandle,
                2,
                GLES20.GL_FLOAT,
                false,
                8,
                vertexBuffer
            )
            GLES20.glUniform4f(
                colorHandle,
                color.red,
                color.green,
                color.blue,
                color.alpha
            )
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6)
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    private class RoadSurfaceProgram {
        private val programId = createProgram(ROAD_SURFACE_VERTEX_SHADER, ROAD_SURFACE_FRAGMENT_SHADER)
        private val worldPositionHandle = GLES20.glGetAttribLocation(programId, "aWorldPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val clipMatrixHandle = GLES20.glGetUniformLocation(programId, "uClipMatrix")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val cycleHandle = GLES20.glGetUniformLocation(programId, "uCycleMeters")
        private val nearFadeHandle = GLES20.glGetUniformLocation(programId, "uNearFadeMeters")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val tintHandle = GLES20.glGetUniformLocation(programId, "uTint")

        fun draw(
            mesh: RoadMeshBuffer,
            clipMatrix: FloatArray,
            phaseMeters: Float,
            cycleLengthMeters: Float,
            nearFadeDistanceMeters: Float,
            alpha: Float,
            tint: GlColor
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, worldPositionHandle, distanceHandle, acrossHandle)
            GLES20.glUniformMatrix4fv(clipMatrixHandle, 1, false, clipMatrix, 0)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(cycleHandle, cycleLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(nearFadeHandle, nearFadeDistanceMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 0.12f))
            GLES20.glUniform3f(tintHandle, tint.red, tint.green, tint.blue)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)
            unbindRoadMesh(worldPositionHandle, distanceHandle, acrossHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class WindProgram {
        private val programId = createProgram(WIND_VERTEX_SHADER, WIND_FRAGMENT_SHADER)
        private val worldPositionHandle = GLES20.glGetAttribLocation(programId, "aWorldPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val clipMatrixHandle = GLES20.glGetUniformLocation(programId, "uClipMatrix")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val spacingHandle = GLES20.glGetUniformLocation(programId, "uSpacingMeters")
        private val lengthHandle = GLES20.glGetUniformLocation(programId, "uStreakLengthMeters")
        private val pulseHandle = GLES20.glGetUniformLocation(programId, "uPulseRadians")
        private val alphaHandle = GLES20.glGetUniformLocation(programId, "uAlpha")
        private val sideHandle = GLES20.glGetUniformLocation(programId, "uSideSign")

        fun draw(
            mesh: RoadMeshBuffer,
            clipMatrix: FloatArray,
            phaseMeters: Float,
            spacingMeters: Float,
            streakLengthMeters: Float,
            pulseRadians: Float,
            alpha: Float,
            sideSign: Float
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, worldPositionHandle, distanceHandle, acrossHandle)
            GLES20.glUniformMatrix4fv(clipMatrixHandle, 1, false, clipMatrix, 0)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(spacingHandle, spacingMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(lengthHandle, streakLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(pulseHandle, pulseRadians)
            GLES20.glUniform1f(alphaHandle, alpha.coerceIn(0f, 0.35f))
            GLES20.glUniform1f(sideHandle, sideSign)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)
            unbindRoadMesh(worldPositionHandle, distanceHandle, acrossHandle)
        }

        fun release() = GLES20.glDeleteProgram(programId)
    }

    private class RoadMarkingProgram {
        private val programId = createProgram(ROAD_VERTEX_SHADER, ROAD_FRAGMENT_SHADER)
        private val worldPositionHandle = GLES20.glGetAttribLocation(programId, "aWorldPosition")
        private val distanceHandle = GLES20.glGetAttribLocation(programId, "aRoadDistance")
        private val acrossHandle = GLES20.glGetAttribLocation(programId, "aAcross")
        private val clipMatrixHandle = GLES20.glGetUniformLocation(programId, "uClipMatrix")
        private val colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        private val phaseHandle = GLES20.glGetUniformLocation(programId, "uPhaseMeters")
        private val repeatHandle = GLES20.glGetUniformLocation(programId, "uRepeatMeters")
        private val dashLengthHandle = GLES20.glGetUniformLocation(programId, "uDashLengthMeters")
        private val dashSoftnessHandle = GLES20.glGetUniformLocation(programId, "uDashSoftnessMeters")
        private val sideSoftnessHandle = GLES20.glGetUniformLocation(programId, "uSideSoftness")
        private val dashedHandle = GLES20.glGetUniformLocation(programId, "uDashed")

        fun draw(
            mesh: RoadMeshBuffer,
            clipMatrix: FloatArray,
            color: GlColor,
            dashed: Boolean,
            phaseMeters: Float,
            pattern: RoadMarkingPattern
        ) {
            GLES20.glUseProgram(programId)
            bindRoadMesh(mesh, worldPositionHandle, distanceHandle, acrossHandle)

            GLES20.glUniformMatrix4fv(clipMatrixHandle, 1, false, clipMatrix, 0)
            GLES20.glUniform4f(colorHandle, color.red, color.green, color.blue, color.alpha)
            GLES20.glUniform1f(phaseHandle, phaseMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(repeatHandle, pattern.repeatLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(dashLengthHandle, pattern.dashLengthMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(dashSoftnessHandle, pattern.dashEdgeSoftnessMeters * ROAD_SHADER_DISTANCE_SCALE)
            GLES20.glUniform1f(sideSoftnessHandle, pattern.sideEdgeSoftness)
            GLES20.glUniform1f(dashedHandle, if (dashed) 1f else 0f)

            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, mesh.vertexCount)

            unbindRoadMesh(worldPositionHandle, distanceHandle, acrossHandle)
        }

        fun release() {
            GLES20.glDeleteProgram(programId)
        }
    }

    companion object {
        private const val TAG = "DigitalV2Renderer"
        private const val ROAD_VERTEX_STRIDE_BYTES = 16
        private const val ROAD_SHADER_DISTANCE_SCALE = 0.125f
        private const val TEXTURE_RETRY_DELAY_NANOS = 1_000_000_000L
        private const val MAX_TEXTURE_PIXELS = 3_000_000L
        private const val ROAD_SURFACE_MIN_SPEED_KMH = 12f
        private val ROAD_SURFACE_TINT = GlColor(0.70f, 0.76f, 0.82f, 1f)
        private val WHITE = GlColor(1f, 1f, 1f, 1f)
        private val MAGENTA = GlColor(1f, 0f, 0.75f, 0.95f)
        private val GREEN = GlColor(0.1f, 1f, 0.3f, 0.95f)

        private fun bindRoadMesh(
            mesh: RoadMeshBuffer,
            worldPositionHandle: Int,
            distanceHandle: Int,
            acrossHandle: Int
        ) {
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, mesh.bufferId)
            GLES20.glEnableVertexAttribArray(worldPositionHandle)
            GLES20.glVertexAttribPointer(worldPositionHandle, 2, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 0)
            GLES20.glEnableVertexAttribArray(distanceHandle)
            GLES20.glVertexAttribPointer(distanceHandle, 1, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 8)
            GLES20.glEnableVertexAttribArray(acrossHandle)
            GLES20.glVertexAttribPointer(acrossHandle, 1, GLES20.GL_FLOAT, false, ROAD_VERTEX_STRIDE_BYTES, 12)
        }

        private fun unbindRoadMesh(worldPositionHandle: Int, distanceHandle: Int, acrossHandle: Int) {
            GLES20.glDisableVertexAttribArray(worldPositionHandle)
            GLES20.glDisableVertexAttribArray(distanceHandle)
            GLES20.glDisableVertexAttribArray(acrossHandle)
            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0)
        }

        private const val TEXTURED_VERTEX_SHADER = """
            attribute vec2 aPosition;
            attribute vec2 aTexCoord;
            varying vec2 vTexCoord;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
                vTexCoord = aTexCoord;
            }
        """

        private const val TEXTURED_FRAGMENT_SHADER = """
            precision mediump float;
            uniform sampler2D uTexture;
            uniform float uAlpha;
            uniform vec4 uColorMultiplier;
            varying vec2 vTexCoord;
            void main() {
                vec4 sampled = texture2D(uTexture, vTexCoord);
                float extraAlpha = uAlpha * uColorMultiplier.a;
                gl_FragColor = vec4(
                    sampled.rgb * uColorMultiplier.rgb * extraAlpha,
                    sampled.a * extraAlpha
                );
            }
        """

        private const val SOLID_VERTEX_SHADER = """
            attribute vec2 aPosition;
            void main() {
                gl_Position = vec4(aPosition, 0.0, 1.0);
            }
        """

        private const val SOLID_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            void main() {
                gl_FragColor = vec4(uColor.rgb * uColor.a, uColor.a);
            }
        """

        private const val ROAD_SURFACE_VERTEX_SHADER = """
            attribute vec2 aWorldPosition;
            attribute float aRoadDistance;
            attribute float aAcross;
            uniform mat4 uClipMatrix;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                gl_Position = uClipMatrix * vec4(aWorldPosition.x, 0.0, aWorldPosition.y, 1.0);
                vRoadDistance = aRoadDistance * 0.125;
                vAcross = aAcross;
            }
        """

        private const val ROAD_SURFACE_FRAGMENT_SHADER = """
            precision mediump float;
            uniform float uPhaseMeters;
            uniform float uCycleMeters;
            uniform float uNearFadeMeters;
            uniform float uAlpha;
            uniform vec3 uTint;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                float sideMask = smoothstep(0.02, 0.12, vAcross) *
                    (1.0 - smoothstep(0.88, 0.98, vAcross));
                float nearMask = 1.0 - smoothstep(uNearFadeMeters * 0.55, uNearFadeMeters, vRoadDistance);
                float local = mod(vRoadDistance + uPhaseMeters, uCycleMeters);
                float broad = smoothstep(0.0, uCycleMeters * 0.07, local) *
                    (1.0 - smoothstep(uCycleMeters * 0.30, uCycleMeters * 0.49, local));
                float fineCycle = uCycleMeters * 0.24;
                float fineLocal = mod(vRoadDistance + uPhaseMeters * 1.7, fineCycle);
                float fine = smoothstep(0.0, fineCycle * 0.09, fineLocal) *
                    (1.0 - smoothstep(fineCycle * 0.30, fineCycle * 0.48, fineLocal));
                float alpha = uAlpha * sideMask * nearMask * (0.58 * broad + 0.22 * fine);
                if (alpha <= 0.001) discard;
                gl_FragColor = vec4(uTint * alpha, alpha);
            }
        """

        private const val WIND_VERTEX_SHADER = """
            attribute vec2 aWorldPosition;
            attribute float aRoadDistance;
            attribute float aAcross;
            uniform mat4 uClipMatrix;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                gl_Position = uClipMatrix * vec4(aWorldPosition.x, 0.0, aWorldPosition.y, 1.0);
                vRoadDistance = aRoadDistance * 0.125;
                vAcross = aAcross;
            }
        """

        private const val WIND_FRAGMENT_SHADER = """
            precision mediump float;
            uniform float uPhaseMeters;
            uniform float uSpacingMeters;
            uniform float uStreakLengthMeters;
            uniform float uPulseRadians;
            uniform float uAlpha;
            uniform float uSideSign;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                float sideMask = smoothstep(0.08, 0.28, vAcross) *
                    (1.0 - smoothstep(0.72, 0.92, vAcross));
                float skewedDistance = vRoadDistance + uPhaseMeters +
                    (vAcross - 0.5) * uSideSign * 1.25;
                float local = mod(skewedDistance, uSpacingMeters);
                float streak = smoothstep(0.0, uStreakLengthMeters * 0.10, local) *
                    (1.0 - smoothstep(
                        uStreakLengthMeters * 0.82,
                        uStreakLengthMeters,
                        local
                    ));
                float pulse = 0.62 + 0.38 * sin(uPulseRadians + vRoadDistance * 2.48);
                float distanceFade = 1.0 - smoothstep(6.5, 9.25, vRoadDistance);
                float alpha = uAlpha * sideMask * streak * pulse * distanceFade;
                if (alpha <= 0.001) discard;
                vec3 tint = vec3(0.88, 0.95, 1.0);
                gl_FragColor = vec4(tint * alpha, alpha);
            }
        """

        private const val ROAD_VERTEX_SHADER = """
            attribute vec2 aWorldPosition;
            attribute float aRoadDistance;
            attribute float aAcross;
            uniform mat4 uClipMatrix;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                gl_Position = uClipMatrix * vec4(
                    aWorldPosition.x,
                    0.0,
                    aWorldPosition.y,
                    1.0
                );
                vRoadDistance = aRoadDistance * 0.125;
                vAcross = aAcross;
            }
        """

        private const val ROAD_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            uniform float uPhaseMeters;
            uniform float uRepeatMeters;
            uniform float uDashLengthMeters;
            uniform float uDashSoftnessMeters;
            uniform float uSideSoftness;
            uniform float uDashed;
            varying mediump float vRoadDistance;
            varying mediump float vAcross;
            void main() {
                float sideIn = smoothstep(0.0, uSideSoftness, vAcross);
                float sideOut = 1.0 - smoothstep(1.0 - uSideSoftness, 1.0, vAcross);
                float mask = sideIn * sideOut;

                if (uDashed > 0.5) {
                    float localDistance = mod(vRoadDistance + uPhaseMeters, uRepeatMeters);
                    float dashStart = smoothstep(
                        0.0,
                        uDashSoftnessMeters,
                        localDistance
                    );
                    float dashEnd = 1.0 - smoothstep(
                        uDashLengthMeters - uDashSoftnessMeters,
                        uDashLengthMeters,
                        localDistance
                    );
                    mask *= dashStart * dashEnd;
                }

                float alpha = uColor.a * mask;
                if (alpha <= 0.002) discard;
                gl_FragColor = vec4(uColor.rgb * alpha, alpha);
            }
        """

        private fun createProgram(vertexSource: String, fragmentSource: String): Int {
            val vertexShader = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
            val fragmentShader = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
            val program = GLES20.glCreateProgram()
            check(program != 0) { "Unable to create OpenGL program" }
            GLES20.glAttachShader(program, vertexShader)
            GLES20.glAttachShader(program, fragmentShader)
            GLES20.glLinkProgram(program)
            val linkStatus = IntArray(1)
            GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0)
            if (linkStatus[0] == 0) {
                val log = GLES20.glGetProgramInfoLog(program)
                GLES20.glDeleteProgram(program)
                error("OpenGL program link failed: $log")
            }
            GLES20.glDeleteShader(vertexShader)
            GLES20.glDeleteShader(fragmentShader)
            return program
        }

        private fun compileShader(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            check(shader != 0) { "Unable to create OpenGL shader" }
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val compileStatus = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compileStatus, 0)
            if (compileStatus[0] == 0) {
                val log = GLES20.glGetShaderInfoLog(shader)
                GLES20.glDeleteShader(shader)
                error("OpenGL shader compile failed: $log")
            }
            return shader
        }

        private fun allocateFloatBuffer(floatCount: Int): FloatBuffer =
            ByteBuffer.allocateDirect(floatCount * 4)
                .order(ByteOrder.nativeOrder())
                .asFloatBuffer()
    }
}
