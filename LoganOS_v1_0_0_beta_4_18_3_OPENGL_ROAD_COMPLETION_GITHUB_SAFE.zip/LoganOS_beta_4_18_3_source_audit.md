# LoganOS beta.4.18.3 — Paket Sonrası Kaynak Denetimi

## Hüküm

Paket iki kez yeniden açılarak denetlendi. Emekliye ayrılan Digital V2 Compose/screen-space yol motorunun runtime'a geri dönmesini sağlayacak bir sınıf, çağrı veya baked road/wind frame asseti bulunmadı.

Yeni kokpit çalışma yolu:

`DigitalV2Cockpit -> OpenGLSceneHost -> LoganGLSurfaceView -> DigitalV2Renderer`

Kokpitte yalnız bir canlı `OpenGLSceneHost` bulunuyor. Ayarlar önizlemesi ikinci EGL context açmıyor.

## Doğrulanan yeni sistem

- Projektif 4x4 clip matrix
- Dünya uzayında sürekli centre/edge road ribbon VBO'ları
- Shader tabanlı 3 m çizgi + 6 m boşluk
- Dört sahnede sürekli beyaz kenar çizgileri
- Yol genişliğiyle sınırlı road-motion VBO ve shader
- Yol dışında ayrı sol/sağ shoulder wind VBO'ları
- Merkezlenmiş %30 görünür araç
- Ayrı vehicle/shadow texture katmanları
- Double tabanlı sürekli mesafe ve alt sistemlere özel fazlar
- ES 2.0 mediump için 0.125 mesafe ölçeği

## İlk paket denetiminde bulunan ve düzeltilenler

### 1. Ribbon genişlik çarpanı

`buildRoadRibbonMesh()` varsayılan işaretleme AA genişletmesini bütün ribbon'lara uyguluyordu. Bu, road-motion yüzeyini matematiksel asfalt dışına, rüzgâr zonunu ise yol sınırına doğru genişletebilirdi.

Düzeltme: `widthExpansion` parametresi eklendi. Çizgiler varsayılan AA genişletmesini korurken road-surface ve iki wind ribbon `widthExpansion = 1f` kullanıyor.

### 2. Wind shader birim karışıklığı

Dünya mesafesi mediump için 0.125 ile ölçeklenmişken rüzgâr uç yumuşatma sabitleri doğrudan `0.18` ve `0.32` kullanıyordu. Bu değerler artık streak uzunluğunun oranlarıyla hesaplanıyor; metre/ölçek karışıklığı kalmadı.

### 3. Texture decode güvenliği

Decode işlemi try/catch dışındaydı. Ayrıca beklenmedik büyük asset ve OOM koruması yoktu.

Düzeltme:
- Decode korumalı bloğa alındı.
- `MAX_TEXTURE_PIXELS = 3_000_000` sınırı eklendi.
- `OutOfMemoryError` yerel olarak yakalanıp texture temizleniyor.
- Eski geçerli texture, yeni upload başarılı olmadan silinmiyor.

## İkinci paket denetimi

İkinci denetimde şu sınıflarda eski yol/rüzgâr yolu bulunmadı:

- `DigitalV2SceneEngine`
- `RoadProjectionSample`
- `RoadProjectionProfile`
- `frameAtArc`
- `RoadFrame`
- `DigitalV2RoadLayer`
- `DigitalV2WindLayer`
- `drawWindParticle`

Ayrıca eski road/wind animation WebP serileri paketlenmemiştir.

## Kalan doğrulama sınırı

Kaynak seviyesinde yeni bir engelleyici sorun bulunmadı. Bununla birlikte gerçek EGL/GPU çalıştırılamadığı için aşağıdakiler cihaz testine bağlıdır:

- Shader'ların gerçek sürücüde compile/link sonucu
- Hareket şiddetinin görsel yeterliliği
- Kenar çizgilerinin dört arka planın gerçek asfalt sınırına optik uyumu
- Araç/gölge renk ve temas kalibrasyonu
- 2 GB head unit frame timing

Bunlar gizlenen kaynak hataları değil; gerçek render çıktısı olmadan kesinleştirilemeyen görsel ve sürücü doğrulamalarıdır.
