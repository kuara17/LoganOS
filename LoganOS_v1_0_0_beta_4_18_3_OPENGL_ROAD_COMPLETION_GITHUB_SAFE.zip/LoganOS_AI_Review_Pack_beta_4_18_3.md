# LoganOS beta.4.18.3 — Claude / Gemini Kod İnceleme Paketi

## İnceleme amacı

Bu sürüm, beta.4.18.2 projektif OpenGL yol motorunun eksik kalan parçalarını tamamlar. Lütfen kıdemli Android, Jetpack Compose ve OpenGL ES 2.0 geliştiricisi gibi inceleyin. Yalnız özet çıkarmayın; somut dosya, sınıf ve kod düzeyinde sorun gösterin.

Özellikle şunları arayın:

1. EGL/GL yaşam döngüsü veya context-loss hatası
2. UI thread ile GL thread arasında yarış durumu
3. VBO, texture veya shader kaynak sızıntısı
4. ES 2.0 / düşük seviye GPU uyumsuzluğu
5. Yol çizgilerinde titreme, yanlış faz veya perspektif hatası
6. Rüzgârın asfalt içine taşmasına yol açabilecek geometri
7. Dur-kalk sırasında eski hızın korunması
8. Texture yükleme başarısızlığında kalıcı siyah/boş katman
9. Compose ayarlar önizlemesi ile gerçek renderer arasında yanıltıcı fark
10. 2 GB RAM'li Android head unit için gereksiz allocation veya GPU yükü

## Mimari sınır

- Compose: HUD, kartlar, navigasyon, ayarlar, metinler ve dokunmatik kontroller
- OpenGL ES 2.0: arka plan, projektif yol, kesikli merkez çizgisi, sürekli kenar çizgileri, road-only hareket katmanı, yol dışı rüzgâr, araç ve gölge
- UI -> GL state aktarımı: `AtomicReference<DigitalV2RenderState>`
- Tek canlı kokpit GL yüzeyi: `OpenGLSceneHost`
- Ayarlar önizlemesi: ikinci EGL context açmayan statik Compose önizlemesi

## beta.4.18.3 değişiklikleri

### Animasyon

- `nextDigitalV2SmoothedSpeedKmh()` eklendi.
- Ham hız 2 km/h altına düştüğünde yumuşatılmış görsel hız son `WHEN_DIRTY` karesinde sıfırlanıyor.
- Kalkışta eski yüksek hızdan devam etme riski kaldırıldı.
- Yol, yol yüzeyi ve rüzgâr kendi kesin faz döngülerini kullanıyor.

### Texture güvenliği

- Başarısız yeni texture yüklemesi eski geçerli texture'ı silmiyor.
- Başarısız yükleme bir saniye sonra yeniden deneniyor.
- Resource ID yalnız başarılı GL upload sonrasında güncelleniyor.
- Decode ve GL upload `RuntimeException` ile `OutOfMemoryError` için korunuyor.
- 3 milyon pikseli aşan beklenmedik texture runtime'da reddediliyor.

### Yol ve çizgiler

- Dört sahnede sürekli sol/sağ beyaz kenar çizgileri açıldı.
- Merkez çizgi 3 m çizgi + 6 m boşluk olarak shader'da kalıyor.
- Merkez çizgi 0.20 m, kenar çizgileri 0.16 m.
- Yol dokusu hareketi, tam yol genişliğiyle sınırlı ayrı projektif VBO ve shader üzerinde çalışıyor.
- Yol yüzeyi ve rüzgâr ribbon'larında işaretleme için kullanılan AA genişletmesi uygulanmıyor.

### Rüzgâr

- Eski CPU/screen-space `drawWindParticle()` sistemi kaldırıldı.
- Sol ve sağ yol omuzları için ayrı projektif VBO'lar eklendi.
- Rüzgâr deseni fragment shader'da dünya mesafesine göre üretiliyor.
- Rüzgâr ribbon'larının en yakın kenarı matematiksel yol sınırının dışında.

### ES 2.0 hassasiyeti

- Fragment shader'da `highp` zorunluluğu yok.
- 0–120 m dünya mesafesi vertex shader'da `0.125` ile ölçeklenip 0–15 aralığında `mediump` olarak enterpole ediliyor.
- Bütün desen uzunlukları ve faz uniform'ları aynı ölçeğe çevriliyor.

### Sahne kalibrasyonu

- City Day ve City Night artık aynı `cityRoad` nesnesini paylaşmıyor.
- Ayrı horizon, horizontal/vertical scale ve depth offset profilleri var.
- Dört sahnede araç görünür genişliği %30 ve kamera takip şeridinde merkezlenmiş durumda.

### Ayarlar önizlemesi

- `DigitalV2StaticRoadPreview` eklendi.
- Statik önizleme, aynı projektif scene modelinden merkez ve kenar çizgilerini çiziyor.
- Eski “sabit koordinatlar” açıklaması kaldırıldı.

## Kritik dosyalar

- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2Renderer.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneModel.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2AnimationMath.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/LoganGLSurfaceView.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt`
- `app/src/test/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneModelTest.kt`
- `tools/validate_digital_v2_geometry.kt`
- `tools/audit_digital_v2_release.py`

## Otomatik kontroller

- Android resource/source preflight
- Statik release güvenlik kapıları
- CPU/GPU projektif matris eşleşmesi
- Yolun ufka doğru monoton daralması
- 3 m / 6 m yol deseni
- Araç merkezleme ve zemin temas Y aralığı
- Uzak çizgi minimum görünürlük testi
- Dur-kalk stale-speed testi
- Yol/rüzgâr faz sürekliliği
- Rüzgâr ribbon'ının yol dışında kalması
- City Day / City Night profil ayrılığı
- Renderer + GLSurfaceView kaynaklarının Android/OpenGL API stub'larıyla Kotlin derlemesi
- Paket sonrası iki aşamalı kaynak denetimi

## Bilinen doğrulama sınırı

Bu çalışma ortamında Android SDK, Gradle Wrapper ve gerçek EGL/GPU bulunmadığı için gerçek `assembleDebug`, gerçek shader compile/link ve cihaz ekran görüntüsü alınamadı. Kaynak testleri başarılı olsa da ilk cihaz testinde özellikle shader görünümü, yol çizgisi kalibrasyonu, gölge ve hareket şiddeti görsel olarak doğrulanmalıdır.

## İnceleme çıktısı formatı

Lütfen sonuçları şu başlıklarla verin:

1. Engelleyici sorunlar
2. Yüksek öncelikli sorunlar
3. Orta/düşük öncelikli iyileştirmeler
4. Doğru uygulanmış kararlar
5. Eksik testler
6. APK/gerçek cihaz testine hazır mı?
7. Önerilen düzeltme sırası
