# LoganOS beta.3.8.6 Claude Review Prompt

Please review this build focusing on the gauge compact-threshold fix.

Expected fixes:
- `SpeedGauge` should no longer use a threshold that forces every real cockpit density into compact mode.
- `ClassicOemAGauge` should always show 0/50/100/150/200 scale labels, shrinking labels in compact mode instead of removing them.
- Digital/RS styles should retain static identity cues when speed is null/progress is zero.
- Setup wizard and dashboard should still call the same SpeedGauge style dispatch.

Please confirm there are no compile blockers and no regressions in OBD/fuel/trip logic.
