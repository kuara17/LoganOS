# LoganOS v1.0.0-beta.3.8.6

Gauge compact threshold and disconnected style identity fixes.
