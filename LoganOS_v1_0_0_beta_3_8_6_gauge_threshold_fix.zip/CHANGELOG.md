# LoganOS v1.0.0-beta.3.8.6

## v1.0.0-beta.3.8.6 - Gauge Threshold Fix

- Fixed the gauge compact threshold bug identified in review.
- Real cockpit balanced/wide gauge heights now clear the non-compact render path.
- Classic OEM scale numbers are no longer removed in compact mode; they shrink instead.
- Digital gauge now keeps a small static green anchor in disconnected state.
- RS Performance keeps red identity accents even when speed/progress is zero.
- Preview and real cockpit continue to use the same SpeedGauge dispatch system.
- No changes were made to FuelAlgorithmV3, TripComputer, parser byte positions, AC_FAST, CUTOFF, or OBD loop logic.
