# LoganOS AI Review Pack — beta.4.20.13

## Review target
New baked Ghost Dual cockpit replacing the legacy Ghost Dual asset stack.

## Architecture
- Compose remains responsible for live values, both needles, coolant status, Double tabs, media and navigation cards.
- The static visual scene is a 1846×852 baked WebP.
- All five colour choices share identical geometry; only the accent-light family changes.

## Expected layout
- Left dial: speed needle + large speed value + `km/h`; average consumption lower in the same dial.
- Right dial: RPM needle + large actual RPM value + `rpm`; instant consumption lower in the same dial.
- Center gap: existing coolant icon + label + live °C.
- Double only: centered Music | Vehicle | Navigation controls, Vehicle in the middle.
- Music/navigation: baked scene remains visible but dimmed.

## Files to review
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostOriginalBakedCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostPhoneWideCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostHeadUnitCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostDualOriginalCockpit.kt`
- `app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt`
- `app/src/main/java/com/dcui/loganos/ui/components/Gauges.kt`
- `app/src/main/res/drawable-nodpi/ghost_dual_original_*.webp`

## Questions
1. On a real 19.5:9 phone, do both needles terminate close to the baked tick ring across the full sweep?
2. On the Double screen, do the centered tabs remain comfortably above the two dial faces?
3. Are the consumption values low enough in the dials without crossing the bright horizon line?
4. Does the central coolant group remain readable for all five accent colours?
