# LoganOS beta.4.20.13 — Changed Files

## Ghost Dual renderer
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostOriginalBakedCockpit.kt`
  - Added baked Ghost Dual branch for both `GhostDual` and backward-compatible `GhostDualOriginal`.
  - Added live speed/RPM needles.
  - Added large numeric speed/RPM readouts.
  - Added average and instant consumption inside their respective dials, lower than the primary readouts.
  - Added centered coolant icon/status/value.
  - Added Double-only centered `Music | Vehicle | Navigation` tab row.
  - Music/navigation continue to dim the Ghost scene instead of leaving LoganOS.

## Routing
- `GhostPhoneWideCockpit.kt` — legacy Ghost Dual phone route delegates to the new baked renderer.
- `GhostHeadUnitCockpit.kt` — legacy Ghost Dual Double route delegates to the new baked renderer.
- `GhostDualOriginalCockpit.kt` — backup-compatible alias now respects phone-vs-Double tab visibility.
- `DashboardScreen.kt` — passes resolved Double mode to the legacy alias.

## Settings / previews
- `SettingsScreen.kt` — Ghost Dual uses the same 5-colour Gauge Light Color selector and no longer exposes the obsolete left/right dial-swap setting.
- `Gauges.kt` — Ghost Dual preview points to the new baked asset.

## Assets
Added five 1846×852 WebP assets:
- `ghost_dual_original_blue.webp`
- `ghost_dual_original_purple.webp`
- `ghost_dual_original_yellow.webp`
- `ghost_dual_original_red.webp`
- `ghost_dual_original_green.webp`

Removed old Ghost Dual assets:
- `ghost_dual_logan_oem_19_5_9.webp`
- `ghost_dual_oem_rpm_shell_4203.webp`
