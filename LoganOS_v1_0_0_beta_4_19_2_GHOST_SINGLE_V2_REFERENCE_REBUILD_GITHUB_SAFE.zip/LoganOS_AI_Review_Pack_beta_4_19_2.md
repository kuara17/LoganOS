# LoganOS AI Review Pack — beta.4.19.2

## Amaç
Ghost Single V2'yi kullanıcının verdiği OEM dijital gösterge referansına yaklaştırmak; önceki tam ekran neon-yay kompozisyonunu kaldırmak.

## Mimari karar
- Ghost Single V2, Compose Canvas + Compose veri katmanı olarak kalır.
- Digital V2 OpenGL renderer, sahne profilleri ve shader dosyaları değiştirilmez.
- Yol fotoğraf tabanlı değildir; stilize ve düz iki kenar çizgisidir.
- Yol kenarı çizgileri kesintisizdir. Hareket için her çizgide yalnız tek bir yumuşak highlight dolaşır.

## Değişen dosyalar
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleV2Cockpit.kt`
- `app/build.gradle.kts`
- `LOGANOS_BETA_4_19_2_GHOST_SINGLE_V2_REFERENCE_REBUILD.txt`

## Görsel değişiklikler
- Büyük yarım yay kaldırıldı; kompakt merkez dairesel kadran eklendi.
- Hız ana değer, RPM ikincil değer oldu.
- Geniş neon elips yerine dar ufuk glow kullanıldı.
- Yol daraltıldı ve çizgiler kesintisiz hale getirildi.
- Çoklu kesik neon streak yerine tek yumuşak hareket vurgusu kullanıldı.
- Araç alt merkeze küçültülerek alındı; temas ve yumuşak kütle gölgeleri ayrıldı.
- Anlık tüketim, ortalama tüketim ve hararet merkez kadranın dışına taşındı.

## Doğrulamalar
- `tools/preflight_source.py`: PASS
- `tools/validate_release.py`: PASS
- ZIP CRC testi: final paketle birlikte çalıştırılacak.

## Bilinen sınır
Bu ortamda Android SDK/Gradle wrapper olmadığı için gerçek `assembleRelease` çalıştırılmadı. Kotlin/Compose tam derleme sonucu GitHub Actions ile doğrulanmalıdır.

## İnceleme soruları
1. Orta kadran oranı 9 inç Double ekranda OEM referansa yeterince yakın mı?
2. Sürekli yol kenarı çizgilerindeki tek hareket vurgusu, kesik çizgi algısı oluşturmadan hareket hissi veriyor mu?
3. Yan metrikler araç ve kadranla çakışmadan okunuyor mu?
