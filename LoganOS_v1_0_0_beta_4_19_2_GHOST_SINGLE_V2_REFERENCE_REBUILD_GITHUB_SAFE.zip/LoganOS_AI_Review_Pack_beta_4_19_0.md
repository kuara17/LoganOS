# LoganOS AI Review Pack — beta.4.19.0

## Scope
Adds a new, separate `GhostSingleV2` cockpit without replacing the approved legacy Ghost Single/Dual renderers.

## Architecture decision
Ghost Single V2 is intentionally Compose/Canvas based. It does not use the Digital V2 OpenGL renderer. The horizon, road, vehicle and cluster are deterministic 2D layers. Only luminous streaks constrained to the two straight road-edge paths animate.

## Changed files
- `Models.kt`: `GaugeStyle.GhostSingleV2`; `AccentColor.IceWhite`
- `MainActivity.kt`: Ghost Single V2 forced to landscape on phones
- `DashboardScreen.kt`: dedicated routing and immersive dark surface
- `GhostSingleV2Cockpit.kt`: new cockpit implementation
- `SettingsScreen.kt`, `SetupWizard.kt`, `Gauges.kt`: selection, labels and preview path
- `AppPrefs.kt`: persistence support
- `validate_release.py`: release gates updated for the new style
- `app/build.gradle.kts`: beta.4.19.0 / versionCode 100000700

## Data policy
Only RPM, speed, trusted fuel consumption, coolant temperature and connection/demo state are rendered. No unsupported vehicle data is introduced.

## Review questions
1. Does `GhostSingleV2Cockpit.kt` use any Compose API requiring an import or dependency absent from the project?
2. Are landscape orientation and immersive routing isolated from legacy Ghost Single?
3. Does the road-edge streak loop remain visually continuous across speed changes?
4. Are the vehicle size and contact shadow likely to overlap bottom metrics on 19.5:9 and 16:9 screens?
5. Is the new Ice White accent readable against the white gauge typography?
