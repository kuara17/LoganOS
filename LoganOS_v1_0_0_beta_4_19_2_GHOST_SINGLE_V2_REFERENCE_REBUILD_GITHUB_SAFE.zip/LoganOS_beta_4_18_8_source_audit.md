# LoganOS beta.4.18.8 source audit

## Scope
Only Digital V2 City Day was changed. The purpose is to stop estimating road geometry at runtime and validate one scene with a hand-matched static road composition before touching the other scenes.

## Verified changes
- `digital_v2_city_day_bg.webp` contains the hand-matched left/right continuous lane lines and centre dashed line.
- `DigitalV2SceneModel` exposes `usesBakedRoadPresentation`.
- `DigitalV2Renderer` skips dynamic road surface, generic road markings and wind when this flag is active.
- `DigitalV2SceneProfiles.CityDay` is the only scene with this flag enabled.
- City Day vehicle visible width is 0.405 and tyre contact Y is 0.928.
- Other three scene profiles remain on the previous OpenGL pipeline.
- Version is 1.0.0-beta.4.18.8 / 100000688.

## Remaining limitation
This is deliberately a static first-stage validation. City Day centre-line animation is disabled until the baked static placement is approved on the real device. No claim is made that the other scenes are fixed.
