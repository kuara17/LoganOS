# LoganOS beta.4.18.7 — Claude / Gemini inceleme paketi

## Amaç

Bu sürüm, beta.4.18.6 gerçek cihaz görüntülerinde görülen iki ana soruna odaklanır:

1. Yol çizgilerinin fotoğraftaki asfalt dışına veya virajın görünmeyen bölümüne taşması.
2. Aracın sahneye sonradan yapıştırılmış gibi görünmesi ve merkez kesik çizgisinin araç altından görünmesi.

## Uygulanan değişiklikler

- Dört sahne için ayrı `256x256` RGBA yol haritası eklendi:
  - R: görünür asfalt alanı
  - G: merkez kesik çizgisi görünürlük alanı
  - B: sağ/sol kenar çizgisi görünürlük alanı
- Yol, asfalt hareketi ve rüzgâr shader’ları ekran UV’siyle bu haritaları örnekliyor.
- Kenar çizgilerinin asfalt dışındaki yarısı maskeyle kırpılıyor.
- Merkez çizgisi 12–20 metre yakın aralığında açılıyor; araç altından veya arkasından görünmüyor.
- Dağ-Göl merkez çizgisi 31–45 metrede, Karlı Yol 32–47 metrede kayboluyor.
- Araç shader’ına yukarıdan gelen ortam ışığı ile aşağıdan gelen yol/kar yansıması için ayrı renk çarpanları eklendi.
- Geniş siyah gövde gölgesi azaltıldı; iki lastik temas gölgesi ve ground-blend güçlendirildi.
- `totalTravelledMeters` hâlâ `Double`; yol/rüzgâr/yüzey fazları ayrı periyotlarda sarılıyor.
- `requestRender()` ve mevcut premultiplied-alpha matematiği korunuyor.
- `setZOrderOnTop/MediaOverlay` eklenmedi; gerçek cihazda Compose HUD zaten GL yüzeyinin üzerinde çalışıyor.

## Özellikle incelenmesi gereken dosyalar

- `DigitalV2SceneModel.kt`
- `DigitalV2SceneProfiles.kt`
- `DigitalV2SceneAssets.kt`
- `DigitalV2RenderState.kt`
- `DigitalV2Shaders.kt`
- `DigitalV2Renderer.kt`
- `DigitalV2RoadMeshBuilder.kt`
- `tools/validate_digital_v2_geometry.kt`
- `tools/audit_digital_v2_release.py`
- `drawable-nodpi/digital_v2_*_road_map.png`

## İnceleme soruları

1. Yol haritası texture koordinatları Android `GLUtils.texImage2D` yönüyle doğru eşleşiyor mu?
2. R/G/B kanal kullanımı merkez ve kenar çizgilerini doğru kırpıyor mu?
3. `uNearFadeStartMeters/uNearFadeEndMeters` çizgiyi araç altından kaldırırken kalkışta görünür sıçrama oluşturur mu?
4. Dört maskenin 256x256 çözünürlüğü 2 GB RAM hedefinde yeterli ve güvenli mi?
5. Araç üst/alt ortam tonu premultiplied-alpha akışını bozmadan uygulanıyor mu?
6. İki lastik temas gölgesinin ölçü ve konumu araç asset anchor’larıyla tutarlı mı?
7. EGL context kaybında road-map texture yeniden yükleniyor mu?
8. Shader sampler unit 1 kullanımı ES 2.0 cihazlarında doğru yönetiliyor mu?
9. Kodda eski Digital V2 runtime yoluna döndürebilecek bir sınıf, referans veya asset kalmış mı?
10. Kaynak seviyesinde başka crash, siyah ekran, texture kaybı, bellek veya frame-time riski var mı?

## Beklenen cevap biçimi

Dosyaları değiştirmeyin, ZIP/APK oluşturmayın. Yalnız yazılı inceleme verin. Her bulgu için:

- önem seviyesi,
- dosya/sınıf/fonksiyon,
- somut neden,
- önerilen düzeltme,
- gerekiyorsa küçük örnek kod veya diff

yazın. Genel Android tavsiyelerini mevcut kodda gerçekten bulunmayan hata gibi sunmayın.
