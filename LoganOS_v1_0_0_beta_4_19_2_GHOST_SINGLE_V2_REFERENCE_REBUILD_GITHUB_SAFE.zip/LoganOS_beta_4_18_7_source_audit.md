# LoganOS beta.4.18.7 — Kaynak Denetimi

## İncelenen hedef

`Jetpack Compose UI + OpenGL ES 2.0 Digital V2 renderer` geçişinin beta.4.18.7 yol maskesi ve araç zemin teması revizyonu.

## Uygulanan düzeltmeler

- Dört sahne için ayrı `256x256` RGBA yol görünürlük haritası eklendi.
- Road shader: merkez çizgisi G kanalından, kenar çizgileri B kanalından kırpılır.
- Road-surface shader: yalnız R kanalındaki asfalt alanında çalışır.
- Wind shader: R kanalındaki asfaltın içinde kalan parçaları bastırır.
- Merkez çizgisi 12–20 metre yakın aralığında görünür hâle gelir; araç altından çıkmaz.
- Dağ-Göl merkez çizgisi 31–45 m, Karlı Yol 32–47 m aralığında kaybolur.
- Araç shader’ına üst ortam ışığı ve alt yol/kar yansıması için ayrı RGB çarpanları eklendi.
- Geniş gövde gölgesi hafifletildi; lastik temas gölgeleri ve ground-blend güçlendirildi.
- Road-map texture da background/vehicle/shadow gibi context-loss sonrasında yeniden yüklenir ve başarısız yüklemede tekrar denenir.

## Eski sistem taraması

Aşağıdaki eski Digital V2 runtime parçaları bulunmadı:

- `DigitalV2SceneEngine`
- `RoadProjectionSample`
- `RoadProjectionProfile`
- `RoadProjectiveCameraProfile`
- `frameAtArc`
- `RoadFrame`
- `DigitalV2RoadLayer`
- `DigitalV2WindLayer`
- baked road/wind frame assetleri

Dijital V1 ve Premium Drive dosyaları korunmuştur; Digital V2 tarafından referans edilmez.

## Çalıştırılan kontroller

- `tools/preflight_source.py`: PASS
- `tools/audit_digital_v2_release.py`: PASS
- `tools/validate_release.py`: PASS
- `tools/validate_digital_v2_geometry.kt`: kotlinc/JVM COMPILE + PASS
- Renderer, shader, gerçek RenderState/SceneAssets ve GL host: Android/Compose API stub kotlinc COMPILE + PASS
- Candidate ZIP CRC: PASS
- Candidate ZIP temiz klasörde yeniden açılarak aynı kontroller: PASS

## Kaynak seviyesinde açık engel

Aday paket denetiminde yeni bir kaynak-seviyesi crash, eksik resource, eski runtime yönlendirmesi veya Kotlin sözdizimi hatası bulunmadı.

## Gerçek cihazda doğrulanması gerekenler

- 256x256 maskelerin hedef GPU’daki texture yönü ve kenar yumuşaklığı
- Dağ-Göl/Karlı Yol viraj görünürlüğü
- Lastik temas gölgesinin gerçek ekran görüntüsündeki konumu
- EGL context-loss sonrası road-map texture reload
- S23 FE ve 2 GB Double frame timing

Bu ortamda Android SDK/Gradle Wrapper bulunmadığı için gerçek `compileReleaseKotlin` ve `assembleRelease` çalıştırılmadı.
