#!/usr/bin/env python3
from pathlib import Path
import re, sys

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
base = root / 'app/src/main/java/com/dcui/loganos/ui/cockpit'
gl = base / 'opengl'
renderer = (gl / 'DigitalV2Renderer.kt').read_text(encoding='utf-8')
model = (gl / 'DigitalV2SceneModel.kt').read_text(encoding='utf-8')
profiles = (gl / 'DigitalV2SceneProfiles.kt').read_text(encoding='utf-8')
mesh = (gl / 'DigitalV2RoadMeshBuilder.kt').read_text(encoding='utf-8')
shaders = (gl / 'DigitalV2Shaders.kt').read_text(encoding='utf-8')
cockpit = (base / 'DigitalV2Cockpit.kt').read_text(encoding='utf-8')
surface = (gl / 'LoganGLSurfaceView.kt').read_text(encoding='utf-8')
errors=[]
def need(cond,msg):
    if not cond: errors.append(msg)

blob = renderer + model + profiles + mesh + cockpit
for token in (
    'RoadProjectionSample','RoadProjectionProfile','RoadProjectiveCameraProfile',
    'RoadCurveProfile','buildRoadRibbonMesh','val clipMatrix: FloatArray',
    'worldLateralMeters','anchorDistanceMeters','DigitalV2SceneEngine',
    'drawWindParticle(','frameAtArc','RoadFrame','rawT * rawT * (3f - 2f * rawT)'
):
    need(token not in blob, f'retired token remains: {token}')

need('DIGITAL_V2_LOGICAL_WIDTH' not in cockpit or 'import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_LOGICAL_WIDTH' in cockpit, 'DigitalV2Cockpit uses DIGITAL_V2_LOGICAL_WIDTH without importing it')
need('DIGITAL_V2_LOGICAL_HEIGHT' not in cockpit or 'import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_LOGICAL_HEIGHT' in cockpit, 'DigitalV2Cockpit uses DIGITAL_V2_LOGICAL_HEIGHT without importing it')
need(cockpit.count('OpenGLSceneHost(')==1, 'live OpenGL host count is not exactly one')
need('DigitalV2StaticRoadPreview(' in cockpit, 'settings preview does not use calibrated road geometry')
need('DigitalV2StaticVehiclePreview(' in cockpit, 'settings preview does not use calibrated vehicle pose')
need('projective OpenGL road mesh' not in cockpit, 'settings copy still claims generic projective mesh')
need(profiles.count('CalibrationPoint(') >= 90, 'scene calibration point count is too low')
need(profiles.count('centerLine = curve(') == 4, 'every scene needs an independent centre curve')
need(profiles.count('leftRoadEdge = curve(') == 4, 'every scene needs an independent left edge')
need(profiles.count('rightRoadEdge = curve(') == 4, 'every scene needs an independent right edge')
need(profiles.count('showLeftEdgeLine = true') == 4, 'left edge line is disabled in a scene')
need(profiles.count('showRightEdgeLine = true') == 4, 'right edge line is disabled in a scene')
need(profiles.count('RoadMarkingVisibility(') >= 4, 'scene-specific marking visibility/fade profiles are missing')
need('centerFadeEndMeters = 45f' in profiles and 'centerFadeEndMeters = 47f' in profiles, 'curved-scene divider occlusion fade is missing')
need('Compact cards keep value and unit on one baseline' in cockpit, 'compact used-fuel card can still clip its value')
need('CityDay = DigitalV2SceneModel' in profiles and 'CityNight = DigitalV2SceneModel' in profiles, 'city profiles missing')
need('cityDayRoad' in profiles and 'cityNightRoad' in profiles, 'city day/night do not have separate calibrations')

need('(leftEdge.x + rightEdge.x) * 0.5f' in mesh, 'wind zones are not derived from the geometric road midpoint')
for token in (
    'buildCalibratedLineMesh','buildCalibratedRoadSurfaceMesh',
    'buildCalibratedWindZoneMesh','RoadCurveRole.CenterLine','RoadSide.Left'
):
    need(token in mesh or token in renderer, f'new calibrated GPU subsystem missing: {token}')
need('scene.road.project(' not in renderer, 'renderer still projects road points with retired CPU camera model')
need('GLES20.glUniformMatrix4fv' not in renderer, 'renderer still uploads retired generic road matrix')
need('leftTireX' in renderer and 'rightTireX' in renderer, 'two tyre contact shadows are missing')
need('Store unrotated tyre contacts' in renderer and 'fun rotatedTire(' not in renderer, 'tyre contact positions may be rotated twice')
need('groundBlendWidthRatio' in renderer, 'ground blend contact layer is missing')
need('SimpleTexturedProgram' in renderer and 'VehicleTexturedProgram' in renderer, 'background/shadow and vehicle shaders are not split')
need('SIMPLE_TEXTURED_FRAGMENT_SHADER' in shaders and 'VEHICLE_FRAGMENT_SHADER' in shaders, 'lightweight and graded texture shaders are missing')
need('nextRoadMeshRetryNanos' in renderer and 'RoadMeshSet.create(scene)' in renderer, 'road mesh upload retry/transaction guard is missing')
need('listOf(\n            layout.leftTireX' not in renderer, 'per-frame tyre-contact list allocation remains')
need('grade = pose.colorGrade' in renderer, 'vehicle scene colour grade is not applied')
need('sampled.rgb / max(sampled.a' in shaders, 'premultiplied texture is not safely unpremultiplied for grading')
need('uFadeStartMeters' in shaders and 'uFadeEndMeters' in shaders, 'road marking visibility uniforms are missing')
need('uNearFadeStartMeters' in shaders and 'uNearFadeEndMeters' in shaders, 'vehicle-area divider suppression is missing')
need('uRoadMap' in shaders and 'roadMapResId' in renderer + (gl / 'DigitalV2RenderState.kt').read_text(encoding='utf-8'), 'scene road visibility map is not wired into the renderer')
need('uAmbientTop' in shaders and 'uAmbientBottom' in shaders, 'directional vehicle ambient grading is missing')
need('road.visibility.centerFadeStartMeters' in renderer and 'road.visibility.edgeFadeStartMeters' in renderer, 'runtime does not apply scene marking visibility')
need('uGradeRgb' in shaders and 'uTextureInfo' in shaders, 'vehicle colour/edge matching shader uniforms missing')
need('gl_Position = vec4(aPosition' in shaders, 'calibrated preprojected mesh is not consumed directly')
need('precision highp float' not in shaders, 'shader requires fragment highp and may fail on ES2 devices')
need(shaders.count('aRoadDistance * 0.125') >= 3, 'mediump distance scaling missing')
need('nextDigitalV2SmoothedSpeedKmh' in renderer, 'idle-state speed reset helper missing')
need('TEXTURE_RETRY_DELAY_NANOS' in renderer, 'texture retry policy missing')
need('MAX_TEXTURE_PIXELS' in renderer and 'OutOfMemoryError' in renderer, 'texture decode size/OOM guard missing')
need('candidate != null' in renderer, 'texture resource IDs can advance after failed upload')
need('DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH' in surface, 'surface and renderer motion threshold are not shared')

assets = root / 'app/src/main/res/drawable-nodpi'
for name in ('mountain_lake','city_day','city_night','snow_road'):
    road_map = assets / f'digital_v2_{name}_road_map.png'
    need(road_map.exists() and road_map.stat().st_size > 1000, f'missing/empty road visibility map: {road_map.name}')
retired = [p.name for p in assets.glob('digital_v2_*.webp') if re.search(r'_(road|wind)_(static|blur|\d{2})\.webp$',p.name)]
need(not retired, 'retired baked road/wind assets remain: '+','.join(retired[:5]))

if errors:
    print('[FAIL] Digital V2 source audit')
    for e in errors: print(' -',e)
    raise SystemExit(1)
print('[PASS] Digital V2 source audit: scene road maps, near-vehicle divider suppression, directional vehicle grading, calibrated GPU meshes and retired-runtime cleanup are active')
