package com.dcui.loganos.media

import android.service.notification.NotificationListenerService

/**
 * Permission bridge for reading active third-party MediaSession controllers.
 * The user must explicitly enable notification access in Android settings.
 */
class LoganMediaNotificationListener : NotificationListenerService()
