package com.dcui.loganos.obd

import com.dcui.loganos.data.DriveHistoryItem
import com.dcui.loganos.data.DriveHistoryDetail
import com.dcui.loganos.data.HistoryStorageInfo
import com.dcui.loganos.data.TestHistoryItem
import com.dcui.loganos.data.TechnicalSessionItem
import com.dcui.loganos.data.VehicleHealthEvidence
import com.dcui.loganos.model.DashboardSnapshot


const val FUEL_LEVEL_DISCOVERY_TEST_NAME = "Depo seviyesi hazırlık taraması"

const val FUEL_REFILL_TEST_NAME = "Gerçek Yakıt Dolum Doğrulaması"
const val FUEL_REFILL_BEFORE_ENGINE_TEST_NAME = "Yakıt • Önce motor çalışır"
const val FUEL_REFILL_BEFORE_KOEO_TEST_NAME = "Yakıt • Önce kontak açık"
const val FUEL_REFILL_AFTER_KOEO_TEST_NAME = "Yakıt • Sonra kontak açık"
const val FUEL_REFILL_AFTER_ENGINE_TEST_NAME = "Yakıt • Sonra motor çalışır"
const val FUEL_REFILL_DRIVE_TEST_NAME = "Yakıt • Kısa sürüş doğrulaması"
const val FUEL_REFILL_FINAL_KOEO_TEST_NAME = "Yakıt • Son kontak açık"

const val CONTROL_DISCOVERY_TEST_NAME = "Pedal, El Freni ve Vites Keşfi"
const val CONTROL_HANDBRAKE_TEST_NAME = "Kontrol • El freni"
const val CONTROL_CLUTCH_TEST_NAME = "Kontrol • Debriyaj"
const val CONTROL_BRAKE_TEST_NAME = "Kontrol • Fren pedalı"
const val CONTROL_GEAR_STATIC_TEST_NAME = "Kontrol • Sabit araçta vitesler"
const val CONTROL_GEAR_DRIVE_TEST_NAME = "Kontrol • Sürüşte vites oranları"

const val TRIP_CONTEXT_IDLE_TEST_NAME = "Trip bağlamı • Rölanti canlılık"
const val TRIP_CONTEXT_DRIVE_TEST_NAME = "Trip bağlamı • Kısa sürüş canlılık"
val TRIP_CONTEXT_TEST_NAMES: Set<String> = setOf(
    TRIP_CONTEXT_IDLE_TEST_NAME,
    TRIP_CONTEXT_DRIVE_TEST_NAME
)
fun isTripContextDeveloperTest(name: String?): Boolean = name != null && name in TRIP_CONTEXT_TEST_NAMES

const val KWP_026_DYNAMIC_TEST_NAME = "0x26 Dinamik Veri Doğrulama"
const val KWP_026_KOEO_TEST_NAME = "0x26 • Kontak açık – motor kapalı"
const val KWP_026_ENGINE_STATIC_TEST_NAME = "0x26 • Motor çalışıyor – sabit araç"
const val KWP_026_DRIVE_TEST_NAME = "0x26 • Kısa sürüş"
const val KWP_026_POST_KOEO_TEST_NAME = "0x26 • Sürüş sonrası kontak açık"
const val KWP_026_WIDE_KOEO_TEST_NAME = "0x26 Geniş • Kontak açık başlangıç"
const val KWP_026_WIDE_IDLE_TEST_NAME = "0x26 Geniş • Rölanti taraması"
const val KWP_026_WIDE_RPM_TEST_NAME = "0x26 Geniş • 2000 rpm doğrulaması"
const val KWP_026_WIDE_DRIVE_TEST_NAME = "0x26 Geniş • Kısa sürüş taraması"
const val KWP_026_WIDE_POST_TEST_NAME = "0x26 Geniş • Sürüş sonrası kontak"
const val KWP_026_COMBINE_RESULTS_NAME = "0x26 • Birleşik sonuç paketi oluştur"

val KWP_026_TEST_NAMES: Set<String> = setOf(
    FUEL_REFILL_BEFORE_ENGINE_TEST_NAME,
    FUEL_REFILL_BEFORE_KOEO_TEST_NAME,
    FUEL_REFILL_AFTER_KOEO_TEST_NAME,
    FUEL_REFILL_AFTER_ENGINE_TEST_NAME,
    FUEL_REFILL_DRIVE_TEST_NAME,
    FUEL_REFILL_FINAL_KOEO_TEST_NAME,
    CONTROL_HANDBRAKE_TEST_NAME,
    CONTROL_CLUTCH_TEST_NAME,
    CONTROL_BRAKE_TEST_NAME,
    CONTROL_GEAR_STATIC_TEST_NAME,
    CONTROL_GEAR_DRIVE_TEST_NAME,
    KWP_026_KOEO_TEST_NAME,
    KWP_026_ENGINE_STATIC_TEST_NAME,
    KWP_026_DRIVE_TEST_NAME,
    KWP_026_POST_KOEO_TEST_NAME,
    KWP_026_WIDE_KOEO_TEST_NAME,
    KWP_026_WIDE_IDLE_TEST_NAME,
    KWP_026_WIDE_RPM_TEST_NAME,
    KWP_026_WIDE_DRIVE_TEST_NAME,
    KWP_026_WIDE_POST_TEST_NAME
)

fun isKwp026DeveloperTest(name: String?): Boolean = name != null && name in KWP_026_TEST_NAMES

enum class ObdConnectionHealth {
    DISCONNECTED,
    CONNECTING,
    STABLE,
    UNSTABLE,
    RECONNECTING
}

data class PairedObdDevice(
    val name: String,
    val address: String
) {
    val displayName: String get() = if (name.isBlank()) address else "$name • $address"
}



data class CrankAnalysisResult(
    val timestampMs: Long,
    val manual: Boolean,
    val durationSec: Double,
    val startVoltage: Double?,
    val minVoltage: Double?,
    val engineTempC: Int?,
    val rpmAtFinish: Int?,
    val obdGapDetected: Boolean,
    val status: String,
    val batteryStatus: String,
    val comment: String
)

data class ObdState(
    val pairedDevices: List<PairedObdDevice> = emptyList(),
    val selectedAddress: String? = null,
    val selectedName: String? = null,
    val status: String = "Bluetooth cihazı bekleniyor",
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val connectionHealth: ObdConnectionHealth = ObdConnectionHealth.DISCONNECTED,
    val connectionHealthReason: String? = null,
    val signalHoldActive: Boolean = false,
    val connectionUnstableCount: Int = 0,
    val lastError: String? = null,
    val logText: String = "",
    val snapshot: DashboardSnapshot = DashboardSnapshot.empty(),
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val rawStandardObd: String = "",
    val supportedStandardPids: Set<Int> = emptySet(),
    val activeProfile: String = "DELPHI_DCM1_2",
    val timingText: String = "",
    val savedLogPath: String? = null,
    val savedLogFileName: String? = null,
    val sharedLogReady: Boolean = false,
    val activeDeveloperTest: String? = null,
    val developerTestPhaseText: String? = null,
    val developerTestRemainingSec: Int? = null,
    val developerTestProgressText: String? = null,
    val developerTestProgressPercent: Int? = null,
    val developerTestElapsedSec: Long? = null,
    val developerTestEstimatedRemainingSec: Long? = null,
    val developerTestCurrentTarget: String? = null,
    val developerTestStepLabel: String? = null,
    val developerTestStepIndex: Int? = null,
    val developerTestStepTotal: Int? = null,
    val developerTestStageLabel: String? = null,
    val developerTestDoneMessage: String? = null,
    val fuelRefillLitersText: String = "",
    val pendingDeveloperTestName: String? = null,
    val sqlSessionId: Long? = null,
    val sqlDbPath: String? = null,
    val loopCount: Int = 0,
    val noDataCount: Int = 0,
    val stoppedCount: Int = 0,
    val busInitCount: Int = 0,
    val slowLoopCount: Int = 0,
    val timeTrusted: Boolean = true,
    val rawEcuLogEnabled: Boolean = false,
    val longTripLogEnabled: Boolean = false,
    val manualCrankArmed: Boolean = false,
    val crankingInProgress: Boolean = false,
    val lastAutoCrankResult: CrankAnalysisResult? = null,
    val recentAutoCrankResults: List<CrankAnalysisResult> = emptyList(),
    val savedManualCrankTests: List<CrankAnalysisResult> = emptyList(),
    val startEvents: List<StartEvent> = emptyList(),
    val startAnalysisSummary: StartAnalysisSummary = StartAnalysisSummary(),
    val driveHistory: List<DriveHistoryItem> = emptyList(),
    val driveHistoryDetail: DriveHistoryDetail? = null,
    val driveHistoryDetailLoading: Boolean = false,
    val testHistory: List<TestHistoryItem> = emptyList(),
    val technicalHistory: List<TechnicalSessionItem> = emptyList(),
    val historyStorage: HistoryStorageInfo = HistoryStorageInfo(),
    val vehicleHealthEvidence: VehicleHealthEvidence = VehicleHealthEvidence(),
    val gpsRouteEnabled: Boolean = false,
    val gpsRouteEligible: Boolean = false,
    val gpsRouteRecording: Boolean = false,
    val gpsRouteStatus: String = "Kapalı",
    val gpsRoutePointCount: Int = 0,
    val gpsLastAccuracyM: Float? = null,
    val exportInProgress: Boolean = false,
    val exportFeedbackMessage: String? = null,
    val exportFeedbackNonce: Long = 0L
)
