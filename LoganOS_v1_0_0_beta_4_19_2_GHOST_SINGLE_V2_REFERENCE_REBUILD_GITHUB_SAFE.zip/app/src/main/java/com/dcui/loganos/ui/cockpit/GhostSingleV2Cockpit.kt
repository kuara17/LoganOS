package com.dcui.loganos.ui.cockpit

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Ghost Single V2 landscape cluster.
 *
 * Visual hierarchy follows the supplied OEM references: one compact central
 * dial, a restrained horizon glow, a small vehicle on a straight road and
 * secondary information at the sides. The road-edge lines remain continuous;
 * only one soft highlight travels along each edge to create motion.
 */
@Composable
fun GhostSingleV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = palette.accent
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val maxRpm = settings.tachometerMaxRpm.coerceAtLeast(1)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, maxRpm)
    val rpmRatio = rpm.toFloat() / maxRpm.toFloat()

    val transition = rememberInfiniteTransition(label = "ghostSingleV2Road")
    val rawPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1250, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ghostSingleV2RoadPhase"
    )
    val phase = if (speed <= 2) 0f else (rawPhase * (speed / 90f).coerceIn(.18f, 1.35f)) % 1f

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val vehicleRes = vehicleVisualDrawableRes(
            settings.vehicleVisualModel,
            settings.vehicleColor,
            VehicleAssetStyle.Detailed
        )

        Canvas(Modifier.fillMaxSize()) {
            drawRect(
                brush = Brush.verticalGradient(
                    listOf(Color(0xFF090C13), Color(0xFF03050A), Color.Black)
                )
            )

            // Narrow, restrained sunrise glow behind the vehicle and road.
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accent.copy(alpha = .34f),
                        accent.copy(alpha = .12f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * .50f, size.height * .565f),
                    radius = size.width * .25f
                ),
                topLeft = Offset(size.width * .25f, size.height * .47f),
                size = Size(size.width * .50f, size.height * .19f)
            )
            drawLine(
                color = accent.copy(alpha = .42f),
                start = Offset(size.width * .31f, size.height * .565f),
                end = Offset(size.width * .69f, size.height * .565f),
                strokeWidth = size.minDimension * .0025f,
                cap = StrokeCap.Round
            )

            // Straight road, intentionally narrow so the main dial remains dominant.
            val road = Path().apply {
                moveTo(size.width * .475f, size.height * .565f)
                lineTo(size.width * .315f, size.height)
                lineTo(size.width * .685f, size.height)
                lineTo(size.width * .525f, size.height * .565f)
                close()
            }
            drawPath(
                road,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF151821), Color(0xFF080A10), Color(0xFF020307)),
                    startY = size.height * .565f,
                    endY = size.height
                )
            )

            // Permanent continuous road-edge lines.
            drawRoadEdge(accent, left = true)
            drawRoadEdge(accent, left = false)

            // A single soft travelling highlight per edge. The base line never breaks.
            if (speed > 2) {
                drawRoadHighlight(accent, left = true, phase = phase)
                drawRoadHighlight(accent, left = false, phase = phase)
            }

            // Grounding: soft mass shadow plus tight tyre contact shadow.
            drawOval(
                brush = Brush.radialGradient(
                    listOf(Color(0xA8000000), Color(0x50000000), Color.Transparent),
                    center = Offset(size.width * .50f, size.height * .895f),
                    radius = size.width * .105f
                ),
                topLeft = Offset(size.width * .395f, size.height * .845f),
                size = Size(size.width * .21f, size.height * .10f)
            )
            drawOval(
                color = Color(0xA6000000),
                topLeft = Offset(size.width * .438f, size.height * .884f),
                size = Size(size.width * .124f, size.height * .022f)
            )

            // Compact central dial based on the OEM reference rather than a full-screen arc.
            val dialDiameter = size.height * .73f
            val dialRect = Rect(
                left = size.width * .50f - dialDiameter / 2f,
                top = size.height * .035f,
                right = size.width * .50f + dialDiameter / 2f,
                bottom = size.height * .035f + dialDiameter
            )
            drawCircle(
                brush = Brush.radialGradient(
                    listOf(Color(0xFF111622), Color(0xFF070A11), Color(0xFF020307)),
                    center = dialRect.center,
                    radius = dialDiameter * .50f
                ),
                radius = dialDiameter * .49f,
                center = dialRect.center
            )
            drawArc(
                color = Color.White.copy(alpha = .16f),
                startAngle = 135f,
                sweepAngle = 270f,
                useCenter = false,
                topLeft = dialRect.topLeft,
                size = dialRect.size,
                style = Stroke(size.minDimension * .010f, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(accent.copy(alpha = .35f), accent, Color.White, accent.copy(alpha = .55f))
                ),
                startAngle = 135f,
                sweepAngle = 270f * rpmRatio,
                useCenter = false,
                topLeft = dialRect.topLeft,
                size = dialRect.size,
                style = Stroke(size.minDimension * .013f, cap = StrokeCap.Round)
            )
            drawDialTicks(dialRect, accent, rpmRatio)

            // Subtle accent wedge behind the vehicle, matching the reference's red flare.
            val flare = Path().apply {
                moveTo(size.width * .44f, size.height * .49f)
                quadraticBezierTo(size.width * .50f, size.height * .43f, size.width * .56f, size.height * .49f)
                quadraticBezierTo(size.width * .50f, size.height * .55f, size.width * .44f, size.height * .49f)
                close()
            }
            drawPath(
                flare,
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, accent.copy(alpha = .55f), Color.Transparent)
                )
            )
        }

        // Central live values.
        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = h * .17f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = speed.toString(),
                color = Color(0xFFF7F9FF),
                fontSize = (h.value * .135f).sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center
            )
            Text(
                text = "km/h",
                color = Color(0xFF9DA6B8),
                fontSize = (h.value * .025f).sp,
                fontWeight = FontWeight.Medium
            )
            Text(
                text = "$rpm rpm",
                color = accent,
                fontSize = (h.value * .031f).sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-h * .055f))
                .width(w * .15f)
        )

        // Left-side data, kept outside the dial like the supplied instrument reference.
        GhostV2SideMetric(
            label = "ANLIK",
            value = formatConsumption(snapshot.instantConsumption, snapshot.instantUnit),
            accent = accent,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = w * .055f, y = h * .19f)
                .clickable(onClick = onOpenReset)
        )
        GhostV2SideMetric(
            label = "HARARET",
            value = snapshot.engineTempC?.let { "$it °C" } ?: "--",
            accent = accent,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .offset(x = w * .055f, y = -h * .08f)
        )

        // Right-side data.
        GhostV2SideMetric(
            label = "ORTALAMA",
            value = snapshot.averageConsumption?.let {
                String.format(Locale.US, "%.1f L/100 km", it)
            } ?: "--",
            accent = accent,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = -w * .055f, y = h * .19f)
                .clickable(onClick = onOpenReset)
        )

        Text(
            text = when {
                snapshot.demo -> "DEMO"
                obdState.connected -> "OBD BAĞLI"
                obdState.connecting -> "BAĞLANIYOR"
                else -> "OBD BEKLENİYOR"
            },
            color = if (obdState.connected || snapshot.demo) accent else Color(0xFFAAB2C2),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(14.dp)
                .clickable(onClick = onObdClick)
        )
    }
}

@Composable
private fun GhostV2SideMetric(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.width(150.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = accent.copy(alpha = .72f), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            value,
            color = Color(0xFFF2F5FB),
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )
    }
}

private fun formatConsumption(value: Double?, unit: String): String =
    value?.let { String.format(Locale.US, "%.1f %s", it, unit) } ?: "--"

private fun DrawScope.drawRoadEdge(color: Color, left: Boolean) {
    val start = Offset(
        x = size.width * if (left) .475f else .525f,
        y = size.height * .565f
    )
    val end = Offset(
        x = size.width * if (left) .315f else .685f,
        y = size.height
    )
    drawLine(
        color = Color.Black.copy(alpha = .72f),
        start = start,
        end = end,
        strokeWidth = size.minDimension * .014f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = color.copy(alpha = .72f),
        start = start,
        end = end,
        strokeWidth = size.minDimension * .006f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = Color.White.copy(alpha = .20f),
        start = start,
        end = end,
        strokeWidth = size.minDimension * .0018f,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawRoadHighlight(color: Color, left: Boolean, phase: Float) {
    fun point(t: Float): Offset {
        val perspective = t * t
        val x0 = size.width * if (left) .475f else .525f
        val x1 = size.width * if (left) .315f else .685f
        return Offset(
            x = x0 + (x1 - x0) * perspective,
            y = size.height * .565f + size.height * .435f * perspective
        )
    }

    val startT = (phase - .10f).coerceAtLeast(0f)
    val endT = (phase + .12f).coerceAtMost(1f)
    if (endT <= startT) return
    val start = point(startT)
    val end = point(endT)
    drawLine(
        color = color.copy(alpha = .25f),
        start = start,
        end = end,
        strokeWidth = size.minDimension * .020f,
        cap = StrokeCap.Round
    )
    drawLine(
        color = Color.White.copy(alpha = .90f),
        start = start,
        end = end,
        strokeWidth = size.minDimension * .0048f,
        cap = StrokeCap.Round
    )
}

private fun DrawScope.drawDialTicks(rect: Rect, accent: Color, activeRatio: Float) {
    val center = rect.center
    val radius = rect.width / 2f
    repeat(41) { index ->
        val ratio = index / 40f
        val angle = (135f + 270f * ratio) * (PI / 180f).toFloat()
        val major = index % 5 == 0
        val outerRadius = radius * .94f
        val innerRadius = radius * if (major) .83f else .88f
        val start = Offset(
            center.x + cos(angle) * innerRadius,
            center.y + sin(angle) * innerRadius
        )
        val end = Offset(
            center.x + cos(angle) * outerRadius,
            center.y + sin(angle) * outerRadius
        )
        val color = when {
            ratio > .78f -> Color(0xFFFF4D5B).copy(alpha = if (ratio <= activeRatio) .95f else .52f)
            ratio <= activeRatio -> accent.copy(alpha = .92f)
            else -> Color.White.copy(alpha = .34f)
        }
        drawLine(
            color = color,
            start = start,
            end = end,
            strokeWidth = size.minDimension * if (major) .0046f else .0022f,
            cap = StrokeCap.Round
        )
    }
}
