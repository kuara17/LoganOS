package com.dcui.loganos.health

import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdConnectionHealth
import com.dcui.loganos.obd.ObdState
import java.util.Locale

/**
 * Conservative, non-diagnostic interpretation of LoganOS live and stored data.
 * It never invents unavailable values and deliberately returns insufficient data
 * rather than a false "healthy" result.
 */
enum class VehicleHealthLevel {
    NORMAL,
    WATCH,
    CHECK_RECOMMENDED,
    INSUFFICIENT_DATA
}

data class VehicleHealthFinding(
    val id: String,
    val title: String,
    val level: VehicleHealthLevel,
    val summary: String,
    val evidence: String
)

data class VehicleHealthReport(
    val overallLevel: VehicleHealthLevel,
    val summary: String,
    val findings: List<VehicleHealthFinding>,
    val completedDriveCount: Int
)

object VehicleHealthAnalyzer {
    fun analyze(
        settings: LoganSettings,
        snapshot: DashboardSnapshot,
        obdState: ObdState
    ): VehicleHealthReport {
        val english = settings.language == AppLanguage.English
        val evidence = obdState.vehicleHealthEvidence
        val findings = listOf(
            coolantFinding(english, snapshot, evidence.qualifiedWarmDriveCount, evidence.medianEndTempC),
            warmupFinding(english, evidence.warmupObservationCount, evidence.medianWarmupMs),
            idleFinding(english, evidence.warmIdleSampleCount, evidence.idleMeanRpm, evidence.idleSpreadRpm),
            consumptionFinding(
                english,
                settings.fuelCalculationSupported,
                evidence.consumptionComparisonDriveCount,
                evidence.recentConsumptionL100,
                evidence.previousConsumptionL100
            ),
            dataQualityFinding(english, obdState)
        )

        val coreFindings = findings.filterNot { it.id == "data_quality" }
        val coreOverall = when {
            coreFindings.any { it.level == VehicleHealthLevel.CHECK_RECOMMENDED } -> VehicleHealthLevel.CHECK_RECOMMENDED
            coreFindings.any { it.level == VehicleHealthLevel.WATCH } -> VehicleHealthLevel.WATCH
            coreFindings.any { it.level == VehicleHealthLevel.NORMAL } -> VehicleHealthLevel.NORMAL
            else -> VehicleHealthLevel.INSUFFICIENT_DATA
        }
        val dataQualityLevel = findings.first { it.id == "data_quality" }.level
        val overall = when {
            coreOverall == VehicleHealthLevel.INSUFFICIENT_DATA -> VehicleHealthLevel.INSUFFICIENT_DATA
            coreOverall == VehicleHealthLevel.NORMAL && dataQualityLevel == VehicleHealthLevel.WATCH -> VehicleHealthLevel.WATCH
            else -> coreOverall
        }
        val summary = when (overall) {
            VehicleHealthLevel.NORMAL -> if (english) {
                "Available LoganOS data shows no clear abnormal trend."
            } else {
                "Mevcut LoganOS verilerinde belirgin bir anormal eğilim görünmüyor."
            }
            VehicleHealthLevel.WATCH -> if (english) {
                "One or more trends should be watched over the next drives."
            } else {
                "Bir veya daha fazla eğilimin sonraki sürüşlerde takip edilmesi önerilir."
            }
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) {
                "A repeated or stronger deviation was detected; a mechanical check may be appropriate."
            } else {
                "Tekrarlayan veya daha belirgin bir sapma görüldü; mekanik kontrol uygun olabilir."
            }
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) {
                "More real driving data is required for a meaningful assessment."
            } else {
                "Anlamlı değerlendirme için daha fazla gerçek sürüş verisi gerekiyor."
            }
        }
        return VehicleHealthReport(overall, summary, findings, evidence.completedDriveCount)
    }

    private fun coolantFinding(
        english: Boolean,
        snapshot: DashboardSnapshot,
        qualifiedDriveCount: Int,
        medianEndTempC: Double?
    ): VehicleHealthFinding {
        val live = snapshot.engineTempC
        val level = when {
            live != null && live >= 105 -> VehicleHealthLevel.CHECK_RECOMMENDED
            live != null && live in 101..104 -> VehicleHealthLevel.WATCH
            qualifiedDriveCount >= 3 && medianEndTempC != null && medianEndTempC >= 103.0 -> VehicleHealthLevel.CHECK_RECOMMENDED
            qualifiedDriveCount >= 3 && medianEndTempC != null && medianEndTempC >= 100.0 -> VehicleHealthLevel.WATCH
            qualifiedDriveCount >= 3 && medianEndTempC != null && medianEndTempC in 75.0..99.9 -> VehicleHealthLevel.NORMAL
            qualifiedDriveCount >= 3 && medianEndTempC != null && medianEndTempC < 75.0 -> VehicleHealthLevel.WATCH
            else -> VehicleHealthLevel.INSUFFICIENT_DATA
        }
        val summary = when (level) {
            VehicleHealthLevel.NORMAL -> if (english) "Coolant behavior is in the expected range in recent longer drives." else "Son uzun sürüşlerde hararet davranışı beklenen aralıkta."
            VehicleHealthLevel.WATCH -> if (english) "Coolant trend is outside the usual band and should be observed again." else "Hararet eğilimi alışılmış bandın dışında; birkaç sürüş daha takip edilmeli."
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "A high coolant temperature pattern was detected." else "Yüksek hararet yönünde belirgin bir örüntü görüldü."
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "Not enough comparable longer-drive temperature data yet." else "Karşılaştırılabilir uzun sürüş sıcaklık verisi henüz yeterli değil."
        }
        val evidenceText = buildString {
            if (live != null) append(if (english) "Live: ${live}°C" else "Canlı: ${live}°C")
            if (qualifiedDriveCount > 0 && medianEndTempC != null) {
                if (isNotEmpty()) append(" • ")
                append(
                    if (english) "Median end temperature: ${format1(medianEndTempC)}°C ($qualifiedDriveCount drives)"
                    else "Medyan bitiş sıcaklığı: ${format1(medianEndTempC)}°C ($qualifiedDriveCount sürüş)"
                )
            }
            if (isEmpty()) append(if (english) "No qualified data" else "Yeterli veri yok")
        }
        return VehicleHealthFinding("coolant", if (english) "Cooling behavior" else "Hararet davranışı", level, summary, evidenceText)
    }

    private fun warmupFinding(english: Boolean, count: Int, medianWarmupMs: Long?): VehicleHealthFinding {
        val minutes = medianWarmupMs?.div(60_000.0)
        val level = when {
            count < 3 || minutes == null -> VehicleHealthLevel.INSUFFICIENT_DATA
            minutes <= 15.0 -> VehicleHealthLevel.NORMAL
            minutes <= 22.0 -> VehicleHealthLevel.WATCH
            else -> VehicleHealthLevel.CHECK_RECOMMENDED
        }
        val summary = when (level) {
            VehicleHealthLevel.NORMAL -> if (english) "Warm-up time is consistent with the recent driving data." else "Isınma süresi son sürüş verileriyle uyumlu görünüyor."
            VehicleHealthLevel.WATCH -> if (english) "Warm-up appears slower; route and weather can affect this, so monitor it." else "Isınma daha yavaş görünüyor; rota ve hava sıcaklığı etkileyebileceği için takip edilmeli."
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "Repeatedly slow warm-up was detected in comparable observations." else "Karşılaştırılabilir ölçümlerde tekrarlayan yavaş ısınma görüldü."
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "At least three complete cold-to-warm observations are needed." else "En az üç tam soğuktan-ısınmaya gözlem gerekiyor."
        }
        val evidence = if (minutes != null) {
            if (english) "Median 60→75°C warm-up: ${format1(minutes)} min • $count observations" else "Medyan 60→75°C ısınma: ${format1(minutes)} dk • $count gözlem"
        } else {
            if (english) "$count complete observations" else "$count tam gözlem"
        }
        return VehicleHealthFinding("warmup", if (english) "Warm-up time" else "Isınma süresi", level, summary, evidence)
    }

    private fun idleFinding(
        english: Boolean,
        sampleCount: Int,
        meanRpm: Double?,
        spreadRpm: Int?
    ): VehicleHealthFinding {
        val level = when {
            sampleCount < 120 || meanRpm == null || spreadRpm == null -> VehicleHealthLevel.INSUFFICIENT_DATA
            spreadRpm <= 120 -> VehicleHealthLevel.NORMAL
            spreadRpm <= 220 -> VehicleHealthLevel.WATCH
            else -> VehicleHealthLevel.CHECK_RECOMMENDED
        }
        val summary = when (level) {
            VehicleHealthLevel.NORMAL -> if (english) "Warm idle RPM is reasonably stable in stored samples." else "Kayıtlı örneklerde sıcak rölanti devri makul derecede kararlı."
            VehicleHealthLevel.WATCH -> if (english) "Warm idle variation is higher than usual; A/C and electrical load can influence it." else "Sıcak rölanti değişimi normalden yüksek; klima ve elektrik yükü de etkileyebilir."
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "Repeated wide warm-idle RPM variation was detected." else "Sıcak rölantide tekrarlayan geniş devir dalgalanması görüldü."
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "More warm stationary samples are needed." else "Daha fazla sıcak ve hareketsiz rölanti örneği gerekiyor."
        }
        val evidence = if (meanRpm != null && spreadRpm != null) {
            if (english) "Mean ${meanRpm.toInt()} rpm • robust spread $spreadRpm rpm • $sampleCount samples" else "Ortalama ${meanRpm.toInt()} rpm • sağlam yayılım $spreadRpm rpm • $sampleCount örnek"
        } else {
            if (english) "$sampleCount qualified samples" else "$sampleCount uygun örnek"
        }
        return VehicleHealthFinding("idle", if (english) "Idle stability" else "Rölanti kararlılığı", level, summary, evidence)
    }

    private fun consumptionFinding(
        english: Boolean,
        fuelSupported: Boolean,
        driveCount: Int,
        recent: Double?,
        previous: Double?
    ): VehicleHealthFinding {
        if (!fuelSupported) {
            return VehicleHealthFinding(
                "consumption",
                if (english) "Consumption trend" else "Tüketim eğilimi",
                VehicleHealthLevel.INSUFFICIENT_DATA,
                if (english) "Fuel calculation is not validated for this vehicle profile." else "Bu araç profilinde yakıt hesabı doğrulanmış değil.",
                if (english) "No synthetic MAF-based estimate is used" else "MAF tabanlı yapay tahmin kullanılmıyor"
            )
        }
        val change = if (recent != null && previous != null && previous > 0.0) (recent - previous) / previous else null
        val absoluteRise = if (recent != null && previous != null) recent - previous else null
        val level = when {
            driveCount < 6 || change == null || absoluteRise == null -> VehicleHealthLevel.INSUFFICIENT_DATA
            change > 0.25 && absoluteRise > 1.0 -> VehicleHealthLevel.WATCH
            else -> VehicleHealthLevel.NORMAL
        }
        val summary = when (level) {
            VehicleHealthLevel.NORMAL -> if (english) "No strong upward consumption trend is visible in comparable recent drives." else "Karşılaştırılabilir son sürüşlerde güçlü bir tüketim artışı eğilimi görünmüyor."
            VehicleHealthLevel.WATCH -> if (english) "Recent weighted consumption is noticeably higher; route, traffic and A/C should be considered." else "Son ağırlıklı tüketim belirgin yükselmiş; rota, trafik ve klima etkisi birlikte değerlendirilmeli."
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "Consumption trend needs attention." else "Tüketim eğilimi kontrol edilmeli."
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "Six comparable drives are required for a trend comparison." else "Eğilim karşılaştırması için altı karşılaştırılabilir sürüş gerekiyor."
        }
        val evidence = if (recent != null && previous != null) {
            val pct = ((recent - previous) / previous * 100.0)
            if (english) "Recent 3: ${format1(recent)} • previous 3: ${format1(previous)} L/100 km • ${formatSigned1(pct)}%" else "Son 3: ${format1(recent)} • önceki 3: ${format1(previous)} L/100 km • %${formatSigned1(pct)}"
        } else {
            if (english) "$driveCount comparable drives" else "$driveCount karşılaştırılabilir sürüş"
        }
        return VehicleHealthFinding("consumption", if (english) "Consumption trend" else "Tüketim eğilimi", level, summary, evidence)
    }

    private fun dataQualityFinding(english: Boolean, obdState: ObdState): VehicleHealthFinding {
        val noDataRate = if (obdState.loopCount >= 100) obdState.noDataCount.toDouble() / obdState.loopCount.toDouble() else null
        val level = when {
            obdState.connectionHealth == ObdConnectionHealth.UNSTABLE || obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> VehicleHealthLevel.WATCH
            noDataRate != null && noDataRate > 0.05 -> VehicleHealthLevel.WATCH
            obdState.connectionHealth == ObdConnectionHealth.STABLE -> VehicleHealthLevel.NORMAL
            else -> VehicleHealthLevel.INSUFFICIENT_DATA
        }
        val summary = when (level) {
            VehicleHealthLevel.NORMAL -> if (english) "Current OBD data quality is suitable for interpretation." else "Mevcut OBD veri kalitesi yorumlama için uygun."
            VehicleHealthLevel.WATCH -> if (english) "Connection quality is unstable; health conclusions may be less reliable until it recovers." else "Bağlantı kalitesi kararsız; düzelene kadar sağlık yorumlarının güveni daha düşük olabilir."
            VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "Connection quality needs attention." else "Bağlantı kalitesi kontrol edilmeli."
            VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "Connect to the vehicle to evaluate live data quality." else "Canlı veri kalitesini değerlendirmek için araca bağlanmak gerekiyor."
        }
        val evidence = buildString {
            append(if (english) "Health: ${obdState.connectionHealth.name}" else "Bağlantı: ${obdState.connectionHealth.name}")
            if (noDataRate != null) {
                append(" • NO DATA ")
                append(String.format(Locale.US, "%.1f%%", noDataRate * 100.0))
            }
            if (obdState.connectionUnstableCount > 0) append(" • ${obdState.connectionUnstableCount} guard")
        }
        return VehicleHealthFinding("data_quality", if (english) "Data quality" else "Veri kalitesi", level, summary, evidence)
    }

    private fun format1(value: Double): String = String.format(Locale.US, "%.1f", value)
    private fun formatSigned1(value: Double): String = String.format(Locale.US, "%+.1f", value)
}
