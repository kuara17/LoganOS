package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale

private val PlateWhite = Color(0xFFF7F9FF)
private val PlateMuted = Color(0xFFD3DBE8)
private val InstantTrendColor = Color(0xFF8EDCFF)
private val AverageTrendColor = Color(0xFFA8E87E)
private val TabularStyle = TextStyle(
    fontFeatureSettings = "tnum",
    shadow = Shadow(color = Color(0x99000000), offset = Offset.Zero, blurRadius = 7f)
)

// Asset coordinates are measured from the final 852x1846 Logan-OEM portrait WebP.
// They remain in normalized stage space after the full-bleed viewport fill.
private object GhostPortraitSlots {
    // Measured from ghost_single_portrait_logan_oem_19_5_9.webp (852x1846).
    const val LEFT_CX = 0.1730f
    const val LEFT_CY = 0.7015f
    const val LEFT_WIDTH = 0.2750f
    const val LEFT_HEIGHT = 0.1710f

    const val RIGHT_CX = 0.8270f
    const val RIGHT_CY = 0.7015f
    const val RIGHT_WIDTH = 0.2750f
    const val RIGHT_HEIGHT = 0.1710f

    const val TEMP_CX = 0.5000f
    const val TEMP_CY = 0.8550f
    const val TEMP_WIDTH = 0.6750f
    const val TEMP_HEIGHT = 0.0880f
}

private val PortraitNeedleGeometry = GhostNeedleGeometry(
    centerX = 0.500f,
    centerY = 0.487f,
    radiusX = 0.425f,
    radiusY = 0.1962f,
    startAngle = 180f,
    endAngle = 360f
)

@Composable
fun GhostSinglePortraitCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val rpmMaximum = 7000
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, rpmMaximum).toFloat()
    val live = ghostLiveValues(palette, settings, snapshot)
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    )
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = live.fuelTrusted,
        tripToken = snapshot.tripToken,
        unitKey = "ghost-average"
    )

    GhostPortraitStage(modifier = modifier) {
        Image(
            painter = painterResource(R.drawable.ghost_single_portrait_logan_oem_19_5_9),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.matchParentSize()
        )
        PortraitNeedleLayer(
            rpm = rpm,
            rpmMaximum = rpmMaximum,
            modifier = Modifier.matchParentSize()
        )
        GhostPortraitOverlay(speed, live, instantTrend, averageTrend, onOpenReset)
    }
}

@Composable
private fun GhostPortraitStage(
    modifier: Modifier = Modifier,
    content: @Composable BoxWithConstraintsScope.() -> Unit
) {
    // Fill the entire cockpit viewport. The asset and overlay intentionally use
    // the same stretched coordinate system, eliminating the old contain-mode
    // letterbox bands on phones whose usable viewport is not exactly 6:13.
    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        content()
    }
}

private data class GhostLiveValues(
    val fuelTrusted: Boolean,
    val instant: String,
    val average: String,
    val instantUnit: String,
    val averageUnit: String,
    val tempValue: String,
    val tempColor: Color
)

@Composable
private fun ghostLiveValues(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot
): GhostLiveValues {
    val fuelTrusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    return GhostLiveValues(
        fuelTrusted = fuelTrusted,
        instant = if (fuelTrusted) plateOne(snapshot.instantConsumption) else "--",
        average = if (fuelTrusted) plateOne(snapshot.averageConsumption) else "--",
        instantUnit = if (fuelTrusted) plateFuelUnit(snapshot.instantUnit) else "VERİ BEKLENİYOR",
        averageUnit = if (fuelTrusted) "L/100 km" else "VERİ BEKLENİYOR",
        tempValue = snapshot.engineTempC?.toString() ?: "--",
        tempColor = coolantAccentColor(palette, snapshot.engineTempC)
    )
}

@Composable
private fun BoxWithConstraintsScope.GhostPortraitOverlay(
    speed: Int,
    live: GhostLiveValues,
    instantTrend: List<Float>,
    averageTrend: List<Float>,
    onOpenReset: () -> Unit
) {
    val fs = LocalDensity.current.fontScale
    val gaugeTitleSize = maxHeight.value * 0.034f
    val gaugeSubtitleSize = maxHeight.value * 0.017f
    val speedSize = maxHeight.value * 0.096f
    val speedUnitSize = maxHeight.value * 0.024f
    val cardLabelSize = maxHeight.value * 0.0158f
    val metricValueSize = maxHeight.value * 0.027f
    val metricUnitSize = maxHeight.value * 0.012f
    val tempLabelSize = cardLabelSize
    val temperatureSize = maxHeight.value * 0.029f

    LabelText(0.500f, 0.292f, "DEVİR", fixedSp(gaugeTitleSize, fs), widthFraction = 0.30f)
    SubLabelText(0.500f, 0.325f, "x100 rpm", fixedSp(gaugeSubtitleSize, fs), widthFraction = 0.24f)
    CenteredAbsoluteText(
        cx = 0.500f,
        cy = 0.410f,
        text = speed.toString(),
        size = fixedSp(speedSize, fs),
        color = PlateWhite,
        weight = FontWeight.Bold,
        widthFraction = 0.38f,
        heightFraction = 0.14f
    )
    SubLabelText(0.500f, 0.472f, "km/h", fixedSp(speedUnitSize, fs), widthFraction = 0.16f)

    MetricCard(
        cx = GhostPortraitSlots.LEFT_CX,
        cy = GhostPortraitSlots.LEFT_CY,
        label = "ANLIK TÜKETİM",
        value = live.instant,
        unit = live.instantUnit,
        onClick = onOpenReset,
        fs = fs,
        labelSize = cardLabelSize,
        valueSize = metricValueSize,
        unitSize = metricUnitSize,
        widthFraction = GhostPortraitSlots.LEFT_WIDTH,
        heightFraction = GhostPortraitSlots.LEFT_HEIGHT,
        trend = instantTrend,
        trendColor = InstantTrendColor,
        labelY = 0.195f,
        valueY = 0.420f,
        unitY = 0.575f,
        sparkTop = 0.720f,
        sparkHeight = 0.065f
    )
    MetricCard(
        cx = GhostPortraitSlots.RIGHT_CX,
        cy = GhostPortraitSlots.RIGHT_CY,
        label = "ORTALAMA TÜKETİM",
        value = live.average,
        unit = live.averageUnit,
        onClick = onOpenReset,
        fs = fs,
        labelSize = cardLabelSize,
        valueSize = metricValueSize,
        unitSize = metricUnitSize,
        widthFraction = GhostPortraitSlots.RIGHT_WIDTH,
        heightFraction = GhostPortraitSlots.RIGHT_HEIGHT,
        trend = averageTrend,
        trendColor = AverageTrendColor,
        labelY = 0.195f,
        valueY = 0.420f,
        unitY = 0.575f,
        sparkTop = 0.720f,
        sparkHeight = 0.065f
    )
    TemperatureCard(
        cx = GhostPortraitSlots.TEMP_CX,
        cy = GhostPortraitSlots.TEMP_CY,
        label = "HARARET",
        value = live.tempValue,
        unit = "°C",
        color = live.tempColor,
        fs = fs,
        labelSize = tempLabelSize,
        valueSize = temperatureSize,
        widthFraction = GhostPortraitSlots.TEMP_WIDTH,
        heightFraction = GhostPortraitSlots.TEMP_HEIGHT,
        labelY = 0.375f,
        valueY = 0.705f,
        valueWidthFraction = 0.56f,
        valueHeightFraction = 0.38f
    )
}

@Composable
private fun BoxWithConstraintsScope.CenteredAbsoluteText(
    cx: Float,
    cy: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight = FontWeight.Light,
    widthFraction: Float = 0.30f,
    heightFraction: Float = 0.11f
) {
    BoxWithConstraints(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .offset(maxWidth * (cx - widthFraction / 2f), maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction)
    ) {
        val density = LocalDensity.current
        val measurer = rememberTextMeasurer()
        val maxWidthPx = with(density) { this@BoxWithConstraints.maxWidth.toPx() } * 0.96f
        val maxHeightPx = with(density) { this@BoxWithConstraints.maxHeight.toPx() } * 0.90f
        val fittedSize = remember(text, size, maxWidthPx, maxHeightPx, weight) {
            fitTextSize(
                measurer = measurer,
                text = AnnotatedString(text),
                baseStyle = TabularStyle.copy(fontWeight = weight),
                maxFontSizeSp = size.value,
                minFontSizeSp = maxOf(8f, size.value * 0.45f),
                maxWidthPx = maxWidthPx,
                maxHeightPx = maxHeightPx
            )
        }
        Text(
            text = text,
            color = color,
            fontSize = fittedSize,
            fontWeight = weight,
            maxLines = 1,
            softWrap = false,
            textAlign = TextAlign.Center,
            style = TabularStyle
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.LabelText(
    cx: Float,
    cy: Float,
    text: String,
    size: TextUnit,
    widthFraction: Float,
    heightFraction: Float = 0.06f
) {
    CenteredAbsoluteText(
        cx = cx,
        cy = cy,
        text = text,
        size = size,
        color = PlateWhite,
        weight = FontWeight.SemiBold,
        widthFraction = widthFraction,
        heightFraction = heightFraction
    )
}

@Composable
private fun BoxWithConstraintsScope.SubLabelText(
    cx: Float,
    cy: Float,
    text: String,
    size: TextUnit,
    widthFraction: Float,
    heightFraction: Float = 0.04f
) {
    CenteredAbsoluteText(
        cx = cx,
        cy = cy,
        text = text,
        size = size,
        color = PlateMuted,
        weight = FontWeight.Medium,
        widthFraction = widthFraction,
        heightFraction = heightFraction
    )
}

@Composable
private fun BoxWithConstraintsScope.MetricCard(
    cx: Float,
    cy: Float,
    label: String,
    value: String,
    unit: String,
    onClick: () -> Unit,
    fs: Float,
    labelSize: Float,
    valueSize: Float,
    unitSize: Float,
    widthFraction: Float,
    heightFraction: Float,
    trend: List<Float> = emptyList(),
    trendColor: Color = PlateMuted,
    labelY: Float,
    valueY: Float,
    unitY: Float,
    sparkTop: Float,
    sparkHeight: Float
) {
    BoxWithConstraints(
        Modifier
            .offset(maxWidth * (cx - widthFraction / 2f), maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction)
            .clickable(onClick = onClick)
    ) {
        LabelText(0.50f, labelY, label, fixedSp(labelSize, fs), widthFraction = 0.92f, heightFraction = 0.17f)
        CenteredAbsoluteText(
            cx = 0.50f,
            cy = valueY,
            text = value,
            size = fixedSp(valueSize, fs),
            color = PlateWhite,
            weight = FontWeight.Bold,
            widthFraction = 0.94f,
            heightFraction = 0.28f
        )
        SubLabelText(0.50f, unitY, unit, fixedSp(unitSize, fs), widthFraction = 0.94f, heightFraction = 0.13f)
        if (trend.isNotEmpty() && sparkHeight > 0f) {
            ConsumptionSparkline(
                values = trend,
                lineColor = trendColor,
                guideColor = trendColor.copy(alpha = 0.28f),
                modifier = Modifier
                    .offset(maxWidth * 0.10f, maxHeight * sparkTop)
                    .width(maxWidth * 0.80f)
                    .height(maxHeight * sparkHeight)
            )
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.TemperatureCard(
    cx: Float,
    cy: Float,
    label: String,
    value: String,
    unit: String,
    color: Color,
    fs: Float,
    labelSize: Float,
    valueSize: Float,
    widthFraction: Float,
    heightFraction: Float,
    labelY: Float,
    valueY: Float,
    valueWidthFraction: Float,
    valueHeightFraction: Float,
    labelHeightFraction: Float = 0.18f
) {
    BoxWithConstraints(
        Modifier
            .offset(maxWidth * (cx - widthFraction / 2f), maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction)
    ) {
        LabelText(0.50f, labelY, label, fixedSp(labelSize, fs), widthFraction = 0.82f, heightFraction = labelHeightFraction)
        val temperatureText = if (value == "--") "--" else "$value$unit"
        CenteredAbsoluteText(
            cx = 0.50f,
            cy = valueY,
            text = temperatureText,
            size = fixedSp(valueSize, fs),
            color = color,
            weight = FontWeight.Bold,
            widthFraction = valueWidthFraction,
            heightFraction = valueHeightFraction
        )
    }
}

@Composable
private fun PortraitNeedleLayer(
    rpm: Float,
    rpmMaximum: Int,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        drawGhostNeedle(
            geometry = PortraitNeedleGeometry,
            ratio = (rpm / rpmMaximum.toFloat()).coerceIn(0f, 1f)
        )
    }
}

private fun fitTextSize(
    measurer: androidx.compose.ui.text.TextMeasurer,
    text: AnnotatedString,
    baseStyle: TextStyle,
    maxFontSizeSp: Float,
    minFontSizeSp: Float,
    maxWidthPx: Float,
    maxHeightPx: Float
): TextUnit {
    fun fits(fontSizeSp: Float): Boolean {
        val result = measurer.measure(
            text = text,
            style = baseStyle.copy(fontSize = fontSizeSp.sp),
            maxLines = 1,
            softWrap = false
        )
        return result.size.width <= maxWidthPx && result.size.height <= maxHeightPx
    }

    val absoluteFloor = 1f
    val requestedFloor = minFontSizeSp.coerceAtLeast(absoluteFloor)
    val highLimit = maxFontSizeSp.coerceAtLeast(requestedFloor)
    var low = when {
        fits(requestedFloor) -> requestedFloor
        fits(absoluteFloor) -> absoluteFloor
        else -> return absoluteFloor.sp
    }
    var high = highLimit

    repeat(12) {
        val mid = (low + high) / 2f
        if (fits(mid)) {
            low = mid
        } else {
            high = mid
        }
    }
    return low.sp
}

private fun plateFuelUnitCompact(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100km"
    unit.contains("L/h", true) -> "L/h"
    unit.contains("VERİ", true) -> "VERİ"
    else -> unit.replace(" ", "")
}

private fun fixedSp(value: Float, fontScale: Float): TextUnit =
    (value / fontScale.coerceAtLeast(0.75f)).sp

private fun plateOne(value: Double?): String =
    value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun plateFuelUnit(unit: String): String = when {
    unit.contains("L/100", true) -> "L/100 km"
    unit.contains("L/h", true) -> "L/h"
    else -> unit
}
