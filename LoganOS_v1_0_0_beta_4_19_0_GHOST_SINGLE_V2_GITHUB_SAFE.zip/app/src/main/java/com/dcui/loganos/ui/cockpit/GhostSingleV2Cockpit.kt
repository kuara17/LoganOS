package com.dcui.loganos.ui.cockpit

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Landscape-only Ghost Single V2 proof-of-design.
 *
 * The scene intentionally stays 2D and deterministic: the instrument cluster,
 * horizon glow, straight road and vehicle are Compose layers. Only the bright
 * streaks on the two road-edge lines move. This avoids reintroducing the
 * photo-calibration/OpenGL road geometry problems from Digital V2.
 */
@Composable
fun GhostSingleV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val accent = palette.accent
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, settings.tachometerMaxRpm)
    val rpmRatio = rpm.toFloat() / settings.tachometerMaxRpm.toFloat()
    val motionSpeed = if (speed <= 2) 0f else (speed / 110f).coerceIn(.12f, 1f)
    val transition = rememberInfiniteTransition(label = "ghostSingleV2Road")
    val rawPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1150, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ghostSingleV2RoadPhase"
    )
    val phase = if (motionSpeed == 0f) 0f else (rawPhase * motionSpeed) % 1f

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val w = maxWidth
        val h = maxHeight
        val vehicleRes = vehicleVisualDrawableRes(
            settings.vehicleVisualModel,
            settings.vehicleColor,
            VehicleAssetStyle.Detailed
        )

        Canvas(Modifier.fillMaxSize()) {
            drawRect(Color(0xFF020307))
            drawRect(
                brush = Brush.verticalGradient(
                    0f to Color(0xFF070A12),
                    .48f to Color(0xFF03050A),
                    1f to Color.Black
                )
            )

            // Broad sunrise-like glow on the horizon. It inherits the selected accent.
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(
                        accent.copy(alpha = .58f),
                        accent.copy(alpha = .22f),
                        Color.Transparent
                    ),
                    center = Offset(size.width * .50f, size.height * .54f),
                    radius = size.width * .42f
                ),
                topLeft = Offset(size.width * .10f, size.height * .40f),
                size = androidx.compose.ui.geometry.Size(size.width * .80f, size.height * .30f)
            )
            drawLine(
                color = accent.copy(alpha = .54f),
                start = Offset(size.width * .15f, size.height * .555f),
                end = Offset(size.width * .85f, size.height * .555f),
                strokeWidth = 1.5f
            )

            // Straight road plane, broad at the bottom and narrow at the horizon.
            val road = Path().apply {
                moveTo(size.width * .44f, size.height * .555f)
                lineTo(size.width * .12f, size.height)
                lineTo(size.width * .88f, size.height)
                lineTo(size.width * .56f, size.height * .555f)
                close()
            }
            drawPath(
                path = road,
                brush = Brush.verticalGradient(
                    colors = listOf(Color(0xFF171A20), Color(0xFF07090D), Color(0xFF020306)),
                    startY = size.height * .55f,
                    endY = size.height
                )
            )

            // Faint permanent edge lines.
            drawPerspectiveEdge(accent.copy(alpha = .30f), left = true)
            drawPerspectiveEdge(accent.copy(alpha = .30f), left = false)

            // Moving luminous streaks constrained to the same two straight edge paths.
            repeat(5) { index ->
                val t0 = ((index / 5f) + phase) % 1f
                val t1 = (t0 + .13f).coerceAtMost(1f)
                drawRoadStreak(accent, true, t0, t1)
                drawRoadStreak(accent, false, t0, t1)
            }

            // Compact contact shadow and soft directional shadow beneath the vehicle.
            drawOval(
                brush = Brush.radialGradient(
                    listOf(Color(0xB8000000), Color(0x55000000), Color.Transparent),
                    center = Offset(size.width * .50f, size.height * .865f),
                    radius = size.width * .16f
                ),
                topLeft = Offset(size.width * .34f, size.height * .81f),
                size = androidx.compose.ui.geometry.Size(size.width * .32f, size.height * .12f)
            )
            drawOval(
                brush = Brush.radialGradient(
                    listOf(accent.copy(alpha = .12f), Color.Transparent),
                    center = Offset(size.width * .44f, size.height * .86f),
                    radius = size.width * .20f
                ),
                topLeft = Offset(size.width * .24f, size.height * .79f),
                size = androidx.compose.ui.geometry.Size(size.width * .38f, size.height * .12f)
            )

            // Main tachometer arc, deliberately open at the bottom like the reference.
            val gaugeRect = Rect(
                left = size.width * .245f,
                top = size.height * .045f,
                right = size.width * .755f,
                bottom = size.height * .925f
            )
            drawArc(
                color = Color.White.copy(alpha = .16f),
                startAngle = 145f,
                sweepAngle = 250f,
                useCenter = false,
                topLeft = gaugeRect.topLeft,
                size = gaugeRect.size,
                style = Stroke(width = size.minDimension * .012f, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(
                    listOf(accent.copy(alpha = .25f), accent, Color.White, accent)
                ),
                startAngle = 145f,
                sweepAngle = 250f * rpmRatio,
                useCenter = false,
                topLeft = gaugeRect.topLeft,
                size = gaugeRect.size,
                style = Stroke(width = size.minDimension * .015f, cap = StrokeCap.Round)
            )
            drawGaugeTicks(gaugeRect, accent, settings.tachometerMaxRpm)
        }

        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = (-h * .02f))
                .width(w * .22f)
                .height(h * .27f)
        )

        Column(
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = h * .23f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = rpm.toString(),
                color = Color(0xFFF6F8FF),
                fontSize = (h.value * .095f).sp,
                fontWeight = FontWeight.Light,
                textAlign = TextAlign.Center
            )
            Text("rpm", color = Color(0xFFAAB2C2), fontSize = (h.value * .025f).sp)
            Text(
                text = speed.toString(),
                color = Color.White,
                fontSize = (h.value * .063f).sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
            Text("km/h", color = accent, fontSize = (h.value * .025f).sp, fontWeight = FontWeight.Bold)
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(.82f)
                .padding(bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            GhostV2Metric(
                label = "ANLIK",
                value = formatConsumption(snapshot.instantConsumption, snapshot.instantUnit),
                modifier = Modifier.weight(1f).clickable(onClick = onOpenReset)
            )
            GhostV2Metric(
                label = "HARARET",
                value = snapshot.engineTempC?.let { "$it °C" } ?: "--",
                modifier = Modifier.weight(1f)
            )
            GhostV2Metric(
                label = "ORTALAMA",
                value = snapshot.averageConsumption?.let { String.format(Locale.US, "%.1f L/100", it) } ?: "--",
                modifier = Modifier.weight(1f).clickable(onClick = onOpenReset)
            )
        }

        Text(
            text = when {
                snapshot.demo -> "DEMO"
                obdState.connected -> "OBD BAĞLI"
                obdState.connecting -> "BAĞLANIYOR"
                else -> "OBD BEKLENİYOR"
            },
            color = if (obdState.connected || snapshot.demo) accent else Color(0xFFAAB2C2),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(14.dp)
                .clickable(onClick = onObdClick)
        )
    }
}

@Composable
private fun GhostV2Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Color(0xFF858EA0), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(value, color = Color(0xFFF2F5FB), fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

private fun formatConsumption(value: Double?, unit: String): String =
    value?.let { String.format(Locale.US, "%.1f %s", it, unit) } ?: "--"

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawPerspectiveEdge(color: Color, left: Boolean) {
    val xHorizon = if (left) size.width * .44f else size.width * .56f
    val xBottom = if (left) size.width * .12f else size.width * .88f
    drawLine(
        color = color,
        start = Offset(xHorizon, size.height * .555f),
        end = Offset(xBottom, size.height),
        strokeWidth = size.minDimension * .006f,
        cap = StrokeCap.Round
    )
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawRoadStreak(
    color: Color,
    left: Boolean,
    startT: Float,
    endT: Float
) {
    fun point(t: Float): Offset {
        val eased = t * t
        val x0 = if (left) size.width * .44f else size.width * .56f
        val x1 = if (left) size.width * .12f else size.width * .88f
        return Offset(
            x = x0 + (x1 - x0) * eased,
            y = size.height * .555f + (size.height * .445f) * eased
        )
    }
    val a = point(startT)
    val b = point(endT)
    drawLine(color.copy(alpha = .18f), a, b, size.minDimension * .018f, StrokeCap.Round)
    drawLine(color.copy(alpha = .92f), a, b, size.minDimension * .006f, StrokeCap.Round)
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawGaugeTicks(
    rect: Rect,
    accent: Color,
    maxRpm: Int
) {
    val center = rect.center
    val rx = rect.width / 2f
    val ry = rect.height / 2f
    repeat(31) { index ->
        val ratio = index / 30f
        val angle = Math.toRadians((145f + 250f * ratio).toDouble())
        val major = index % 5 == 0
        val outer = Offset(
            center.x + cos(angle).toFloat() * rx,
            center.y + sin(angle).toFloat() * ry
        )
        val scale = if (major) .88f else .925f
        val inner = Offset(
            center.x + cos(angle).toFloat() * rx * scale,
            center.y + sin(angle).toFloat() * ry * scale
        )
        drawLine(
            color = if (ratio >= .75f) Color(0xFFFF4C58) else if (ratio <= maxRpm / 10000f) accent.copy(alpha = .82f) else Color.White.copy(alpha = .45f),
            start = inner,
            end = outer,
            strokeWidth = if (major) size.minDimension * .0045f else size.minDimension * .0023f,
            cap = StrokeCap.Round
        )
    }
}
