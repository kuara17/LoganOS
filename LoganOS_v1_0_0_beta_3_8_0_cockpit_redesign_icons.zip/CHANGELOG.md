## v1.0.0-beta.3.8.0 - Cockpit Redesign & Custom Icons

### Cockpit redesign
- Applied the approved **Konsept 4** cockpit direction.
- Reworked the portrait cockpit into a clean white/OEM layout with centered LoganOS branding, large digital speed focus, thin arc/tick speed indicator, separator-based two-column metric area and modern spacing.
- Added a separate landscape adaptation instead of simply shrinking the portrait layout.
- Kept cockpit text size and cockpit density settings compatible with the redesigned layout.

### Custom LoganOS icons
- Integrated the approved `LoganOS_custom_vector_icons_xml.zip` vector icons into `app/src/main/res/drawable/`.
- Replaced generic/hand-drawn in-code metric icons with project-owned XML vector drawable assets.
- Preserved per-icon approved colors using `tint = Color.Unspecified`.
- Added icon coverage for cockpit metrics and technical screen values.

### Technical fixes from road log
- Added a COAST_GUARD layer to block MAF/MAP fallback from inventing high consumption when fuel=0 and pedal=0 during closed-throttle coasting.
- Added a simple coolant temperature smoothing guard for implausible one-frame ECT drops.
- Added the latest automatic cranking analysis summary to saved/shared log exports without persisting auto results permanently to SQL.

### Preserved systems
- FuelAlgorithmV3 core injection calculation remains unchanged except for the fallback guard.
- TripComputer core logic unchanged.
- CUTOFF and AC_FAST logic unchanged.
- Delphi DCM1.2 parser byte positions unchanged.
- Fan UNKNOWN / test pending policy unchanged.
- Fuel calibration coefficient remains optional.

### Version
- Updated version metadata to 1.0.0-beta.3.8.0.
