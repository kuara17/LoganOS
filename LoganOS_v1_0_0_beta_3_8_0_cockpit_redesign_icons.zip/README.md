# LoganOS

OEM-style Android cockpit for Dacia/Renault Delphi DCM1.2 KWP2000 testing.

## Beta 3.8.0 Cockpit Redesign & Custom Icons

This package applies the approved Konsept 4 cockpit redesign and integrates the approved LoganOS custom vector icon set.

Highlights:
- White/OEM-style cockpit redesign with large speed focus.
- Responsive portrait and landscape cockpit layouts.
- Custom XML vector icons under `app/src/main/res/drawable/`.
- Per-icon colors preserved with `Color.Unspecified` tint usage.
- MAF fallback guard for closed-throttle/coasting frames.
- Coolant temperature one-frame drop smoothing.
- Last automatic cranking analysis summary in saved/shared exports.

Version: `1.0.0-beta.3.8.0`
