package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        // Kurulum ekranında uygulamanın mevcut DC/LoganOS amblemi kullanılır.
        LoganMark(palette = palette, modifier = Modifier.size(58.dp))
        Spacer(Modifier.height(5.dp))
        Text(
            "DACIA",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 2.8.sp
        )
    }
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(58.dp)) {
            val w = size.width
            val h = size.height
            val metal = Brush.linearGradient(
                colors = if (selected) {
                    listOf(palette.accent.copy(alpha = .98f), palette.accent.copy(alpha = .68f), palette.accent.copy(alpha = .98f))
                } else {
                    listOf(Color(0xFF111820), Color(0xFF56606A), Color(0xFF111820))
                },
                start = Offset(0f, 0f),
                end = Offset(w, h)
            )

            // LoganOS'a özel Renault kart logosu: baklava formunu çağrıştıran özgün çift şerit.
            val outer = Path().apply {
                moveTo(w * .50f, h * .04f)
                lineTo(w * .88f, h * .50f)
                lineTo(w * .50f, h * .96f)
                lineTo(w * .12f, h * .50f)
                close()
            }
            val middle = Path().apply {
                moveTo(w * .50f, h * .18f)
                lineTo(w * .76f, h * .50f)
                lineTo(w * .50f, h * .82f)
                lineTo(w * .24f, h * .50f)
                close()
            }
            val inner = Path().apply {
                moveTo(w * .50f, h * .34f)
                lineTo(w * .62f, h * .50f)
                lineTo(w * .50f, h * .66f)
                lineTo(w * .38f, h * .50f)
                close()
            }

            drawPath(outer, brush = metal, style = Stroke(width = w * .075f))
            drawPath(middle, color = c.copy(alpha = .84f), style = Stroke(width = w * .060f))
            drawPath(inner, brush = metal, style = Fill)
        }
        Spacer(Modifier.height(5.dp))
        Text(
            "RENAULT",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.7.sp
        )
    }
}
