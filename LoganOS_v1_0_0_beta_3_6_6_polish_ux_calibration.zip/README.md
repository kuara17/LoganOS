# LoganOS

Version: **1.0.0-beta.3.6.6**

## Beta 3.6.6 UX Polish and Calibration

This build applies the selected LoganOS identity assets, fixes setup-reset navigation, and turns Yakıt Kalibrasyonu into a working optional correction layer while keeping the validated FuelAlgorithmV3 / TripComputer foundation intact.

Highlights:

- New LoganOS splash/setup logo applied.
- New LoganOS launcher icon applied.
- Setup reset now commits `setupCompleted=false` and opens the setup wizard directly instead of hanging on splash.
- Yakıt Kalibrasyonu now calculates a pump-fill correction factor.
- Factory FuelAlgorithmV3 remains unchanged; calibration is optional and reversible.
- Demo mode now asks for confirmation before enabling.
- Setup model/motor texts cleaned up.
- Cockpit/trip card typography and spacing adjusted to reduce text/value clipping.
- Developer-only rows remain hidden until Developer Mode is enabled.



Previous 3.6.5 notes:

SQLite migration/lifecycle hotfix, Android 8/9 storage permission fix, and version-label cleanup on top of the beta 3.6.3 test/log/setup/technical-screen work.


This build keeps the validated Fuel Truth, Smart Trip and SQL trip logging foundation, then cleans up test logging, setup selections and the technical screen.

Highlights:

- FuelAlgorithmV3 retained.
- Smart Trip / TripComputer retained.
- SQL trip logging retained and export format improved.
- Normal logs export readable summary values instead of raw ECU hex packets.
- Optional Long Trip Log for lighter long-distance recording.
- Optional Developer Raw Log for 21A0 / 21A2 / 21CC / 21CD packets.
- Technical screen now shows useful advanced live data and OBD quality counters.
- Setup requires explicit user selections.
- Supported vehicle profile is simplified to Dacia Logan 2005-2012 Sedan/MCV 1.5 dCi 68 bg.



### Beta 3.6.5 UX notes
Developer tools are separated from About. Normal users see automatic smart logging; raw ECU logs remain developer-only. Fan remains unverified and is shown with coolant temperature as “test pending”.
