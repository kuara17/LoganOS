package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.Brand
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.DaciaBrandLogo
import com.dcui.loganos.ui.components.GaugePreview
import com.dcui.loganos.ui.components.LoganSetupLogo
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.RenaultBrandLogo
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun SetupWizard(
    palette: LoganPalette,
    initial: LoganSettings,
    onComplete: (LoganSettings) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(initial) }
    var brandSelected by remember { mutableStateOf(false) }
    var vehicleSelected by remember { mutableStateOf(false) }
    var engineSelected by remember { mutableStateOf(false) }
    var deviceSelected by remember { mutableStateOf(false) }
    var gaugeSelected by remember { mutableStateOf(false) }
    var accentSelected by remember { mutableStateOf(false) }
    val total = 8
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        WizardHeader(palette, step, total)
        Spacer(Modifier.height(12.dp))
        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                item {
                    when (step) {
                        0 -> WelcomeStep(palette)
                        1 -> BrandStep(palette, if (brandSelected) settings.brand else null) {
                            brandSelected = true
                            vehicleSelected = false
                            engineSelected = false
                            settings = settings.copy(brand = it, vehicleModel = "", engine = "")
                        }
                        2 -> VehicleStep(palette, settings.brand, if (vehicleSelected) settings.vehicleModel else null) {
                            vehicleSelected = true
                            engineSelected = false
                            settings = settings.copy(vehicleModel = it, engine = "")
                        }
                        3 -> EngineStep(palette, if (engineSelected) settings.engine else null, settings.vehicleModel) {
                            engineSelected = true
                            settings = settings.copy(engine = it)
                        }
                        4 -> DeviceStep(palette, if (deviceSelected) settings.deviceMode else null) {
                            deviceSelected = true
                            settings = settings.copy(deviceMode = it)
                        }
                        5 -> GaugeStep(palette, if (gaugeSelected) settings.gaugeStyle else null) {
                            gaugeSelected = true
                            settings = settings.copy(gaugeStyle = it)
                        }
                        6 -> AccentStep(palette, if (accentSelected) settings.accentColor else null) {
                            accentSelected = true
                            settings = settings.copy(accentColor = it)
                        }
                        7 -> DataNoticeStep(palette, settings.disclaimerAccepted) { settings = settings.copy(disclaimerAccepted = it) }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val canProceed = when (step) {
            0 -> true
            1 -> brandSelected
            2 -> vehicleSelected
            3 -> engineSelected
            4 -> deviceSelected
            5 -> gaugeSelected
            6 -> accentSelected
            7 -> settings.disclaimerAccepted
            else -> false
        }
        WizardButtons(
            palette = palette,
            canBack = step > 0,
            canNext = canProceed,
            nextText = if (step == 7) "Kurulumu Tamamla" else "Devam",
            onBack = { if (step > 0) step-- },
            onNext = { if (step < 7) step++ else onComplete(settings.copy(setupCompleted = true)) }
        )
    }
}

@Composable
private fun WizardHeader(palette: LoganPalette, step: Int, total: Int) {
    Column {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            LoganSetupLogo(modifier = Modifier.height(54.dp).fillMaxWidth(.48f))
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text("Kurulum", color = palette.textSecondary, fontSize = 13.sp)
            Text("${step + 1} / $total", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(7.dp))
        LinearProgressIndicator(
            progress = { (step + 1) / total.toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(6.dp)),
            color = palette.accent,
            trackColor = palette.line
        )
    }
}

@Composable
private fun WelcomeStep(palette: LoganPalette) {
    CenterStep(
        palette,
        title = "LoganOS'a Hoş Geldiniz",
        subtitle = "Renault ve Dacia araçlar için OEM Digital Cockpit deneyimini birkaç adımda hazırlayacağız."
    )
}

@Composable
private fun BrandStep(palette: LoganPalette, selected: Brand?, onSelect: (Brand) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, "Araç Markası", "Marka seçimine göre model listesi ayrılır.")
        BrandCard(palette, Brand.Dacia, selected == Brand.Dacia, enabled = true) { onSelect(Brand.Dacia) }
        BrandCard(palette, Brand.Renault, selected == Brand.Renault, enabled = false) { }
        Text("Dacia profilleri aktif; Renault profilleri henüz doğrulanmadığı için kilitli.", color = palette.textSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun BrandCard(palette: LoganPalette, brand: Brand, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected && enabled) palette.accent.copy(alpha = .08f) else palette.surface)
            .border(1.dp, if (selected && enabled) palette.accent else palette.line, shape)
            .then(if (enabled) Modifier.clickable { onClick() } else Modifier)
            .alpha(if (enabled) 1f else .48f)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Box(modifier = Modifier.size(width = 118.dp, height = 82.dp), contentAlignment = Alignment.Center) {
            if (brand == Brand.Dacia) {
                DaciaBrandLogo(palette, Modifier.size(110.dp, 68.dp), selected)
            } else {
                RenaultBrandLogo(palette, Modifier.size(110.dp, 68.dp), selected)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(brand.label, color = if (selected) palette.accent else palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(
                if (brand == Brand.Dacia) "Modern, dayanıklı ve akıllı sürüş deneyimi." else "İleri teknoloji ve konforlu sürüş deneyimi.",
                color = palette.textSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
        Box(modifier = Modifier.size(width = 24.dp, height = 70.dp), contentAlignment = Alignment.Center) {
            Text(if (selected && enabled) "✓" else if (!enabled) "Kilitli" else "", color = if (enabled) palette.accent else palette.textSecondary, fontSize = if (enabled) 28.sp else 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class VehicleOption(
    val title: String,
    val subtitle: String,
    val enabled: Boolean = true
)

private val daciaVehicleOptions = listOf(
    VehicleOption(
        title = "Dacia Logan",
        subtitle = "2005-2012 Sedan / MCV • 1.5 dCi 68 bg • tam destek"
    ),
    VehicleOption(
        title = "Dacia Sandero I",
        subtitle = "2008-2012 • 1.5 dCi 70 bg • deneysel/doğrulama gerekli"
    ),
    VehicleOption(
        title = "Dacia Logan / MCV II",
        subtitle = "2013 ve üzeri • şu anda desteklenmiyor",
        enabled = false
    ),
    VehicleOption(
        title = "Dacia Duster I",
        subtitle = "2010-2017 • şu anda desteklenmiyor",
        enabled = false
    )
)

private val renaultVehicleOptions = listOf(
    VehicleOption(
        title = "Renault Symbol / Thalia II",
        subtitle = "2008-2013 • Renault profili henüz doğrulanmadı",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Clio II",
        subtitle = "1998-2012 • Renault profili henüz doğrulanmadı",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Clio III",
        subtitle = "2005-2014 • çoğu donanım yol bilgisayarlı; destek yok",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Kangoo I",
        subtitle = "1997-2008 • Renault profili henüz doğrulanmadı",
        enabled = false
    )
)

@Composable
private fun VehicleStep(palette: LoganPalette, brand: Brand, selected: String?, onSelect: (String) -> Unit) {
    val models = if (brand == Brand.Dacia) daciaVehicleOptions else renaultVehicleOptions
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(
            palette,
            "Araç Modeli",
            "Logan Sedan/MCV tek profil altında; Sandero deneysel, Duster kilitli."
        )
        models.forEach { item ->
            SelectRow(
                palette = palette,
                title = item.title,
                subtitle = item.subtitle,
                selected = selected == item.title,
                enabled = item.enabled
            ) { onSelect(item.title) }
        }
    }
}

private data class EngineOption(
    val title: String,
    val subtitle: String,
    val enabled: Boolean = true,
    val experimental: Boolean = false
)

@Composable
private fun EngineStep(palette: LoganPalette, selected: String?, vehicleModel: String, onSelect: (String) -> Unit) {
    var pendingExperimental by remember { mutableStateOf<EngineOption?>(null) }
    val engines = when (vehicleModel) {
        "Dacia Logan" -> listOf(
            EngineOption(
                title = "1.5 dCi 68 bg",
                subtitle = "Tam destek • 2005-2012 Logan Sedan/MCV doğrulanmış profil"
            ),
            EngineOption(
                title = "Diğer 1.5 dCi",
                subtitle = "Deneysel • log ile doğrulanmalı",
                experimental = true
            ),
            EngineOption(
                title = "Benzinli motorlar",
                subtitle = "Şimdilik desteklenmiyor",
                enabled = false
            )
        )
        "Dacia Sandero I" -> listOf(
            EngineOption(
                title = "1.5 dCi 70 bg",
                subtitle = "Deneysel • Sandero I için log ile doğrulama gerekli",
                experimental = true
            ),
            EngineOption(
                title = "Benzinli motorlar",
                subtitle = "Şimdilik desteklenmiyor",
                enabled = false
            )
        )
        else -> listOf(
            EngineOption(
                title = "Bu model desteklenmiyor",
                subtitle = "Şimdilik LoganOS profili yok",
                enabled = false
            )
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(
            palette,
            "Motor",
            "Seçenekler seçilen model yılına göre sadeleştirildi."
        )
        engines.forEach { item ->
            SelectRow(
                palette = palette,
                title = item.title,
                subtitle = item.subtitle,
                selected = selected == item.title,
                enabled = item.enabled
            ) {
                if (item.experimental) pendingExperimental = item else onSelect(item.title)
            }
        }
    }

    pendingExperimental?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingExperimental = null },
            title = { Text("Deneysel motor profili", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "LoganOS tam doğrulanmış profili 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. ${item.title} seçerseniz uygulama çalışabilir; ancak yakıt, tüketim ve bazı ECU değerleri sapmalı görünebilir.",
                    color = palette.textSecondary,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSelect(item.title)
                    pendingExperimental = null
                }) { Text("Anladım, seç") }
            },
            dismissButton = {
                TextButton(onClick = { pendingExperimental = null }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
private fun DeviceStep(palette: LoganPalette, selected: DeviceMode?, onSelect: (DeviceMode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, "Cihaz Kullanım Modu", "Telefon dikey/yatay kullanımı destekler. Android multimedya cihazlarda yatay mod varsayılandır.")
        DeviceMode.entries.forEach { mode ->
            SelectRow(palette, mode.label, if (mode == DeviceMode.Phone) "Dikey/Yatay kullanım" else "Yatay dashboard, hızlı açılış", selected == mode) { onSelect(mode) }
        }
    }
}

@Composable
private fun GaugeStep(palette: LoganPalette, selected: GaugeStyle?, onSelect: (GaugeStyle) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        StepTitle(palette, "Gösterge Stili", "İlk tercihinizi seçin. Sonradan Ayarlar bölümünden değiştirilebilir.")
        GaugeStyle.entries.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { style ->
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.dp, if (selected == style) palette.accent else palette.line, RoundedCornerShape(16.dp))
                            .clickable { onSelect(style) }
                            .padding(6.dp)
                    ) { GaugePreview(palette, style, selected == style) }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun AccentStep(palette: LoganPalette, selected: AccentColor?, onSelect: (AccentColor) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(palette, "Vurgu Rengi", "Varsayılan LoganOS rengi OEM Green'dir.")
        AccentColor.entries.forEach { accent ->
            SelectRow(palette, accent.label, "Logo, göstergeler, aktif menüler ve switch renkleri", selected == accent, color = accent.color) { onSelect(accent) }
        }
    }
}

@Composable
private fun DataNoticeStep(palette: LoganPalette, accepted: Boolean, onAccepted: (Boolean) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, "Veri Kullanımı", "LoganOS teşhis koymaz; ECU verilerini yorumlayarak bilgilendirme sağlar.")
        OemCard(palette) {
            Text(
                "Yakıt tüketimi, maliyet, performans ve araç sağlığı değerlendirmeleri ECU verileri ile LoganOS algoritmalarına dayanır. Araç, ECU ve OBD adaptörüne bağlı olarak sapmalar oluşabilir. Bu bilgiler resmi ölçüm veya garanti niteliğinde değildir.",
                color = palette.textSecondary,
                fontSize = 15.sp,
                lineHeight = 24.sp
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (accepted) palette.accent.copy(alpha = .08f) else palette.surface)
                .border(1.dp, if (accepted) palette.accent else palette.line, RoundedCornerShape(16.dp))
                .clickable { onAccepted(!accepted) }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = accepted,
                onCheckedChange = onAccepted,
                colors = CheckboxDefaults.colors(
                    checkedColor = palette.accent,
                    uncheckedColor = palette.textSecondary,
                    checkmarkColor = palette.background
                )
            )
            Column {
                Text("Okudum ve kabul ediyorum", color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text("Kurulumu tamamlamak için kutucuğu işaretle.", color = palette.textSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SelectListStep(palette: LoganPalette, title: String, itemsList: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(palette, title, "Sonradan ayarlardan değiştirilebilir.")
        itemsList.forEach { item ->
            SelectRow(palette, item, null, selected == item) { onSelect(item) }
        }
    }
}

@Composable
private fun SelectRow(
    palette: LoganPalette,
    title: String,
    subtitle: String?,
    selected: Boolean,
    color: Color = palette.accent,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val effectiveColor = if (enabled) color else palette.textSecondary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected && enabled) color.copy(alpha = .10f) else palette.surface)
            .border(1.dp, if (selected && enabled) color else palette.line, shape)
            .then(if (enabled) Modifier.clickable { onClick() } else Modifier)
            .alpha(if (enabled) 1f else .48f)
            .padding(15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = if (selected && enabled) color else effectiveColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Text(if (selected && enabled) "✓" else if (!enabled) "Kilitli" else "", color = effectiveColor, fontSize = if (enabled) 24.sp else 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun CenterStep(palette: LoganPalette, title: String, subtitle: String) {
    Column(modifier = Modifier.fillMaxWidth().padding(top = 42.dp, bottom = 24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        LoganSetupLogo(modifier = Modifier.height(132.dp).fillMaxWidth(.82f))
        Spacer(Modifier.height(18.dp))
        Text(title, color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(subtitle, color = palette.textSecondary, fontSize = 16.sp, textAlign = TextAlign.Center, lineHeight = 24.sp)
    }
}

@Composable
private fun StepTitle(palette: LoganPalette, title: String, subtitle: String) {
    Column {
        Text(title, color = palette.textPrimary, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun WizardButtons(palette: LoganPalette, canBack: Boolean, canNext: Boolean, nextText: String, onBack: () -> Unit, onNext: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = onBack, enabled = canBack, modifier = Modifier.weight(1f).height(48.dp)) { Text("Geri") }
        Button(
            onClick = onNext,
            enabled = canNext,
            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
            modifier = Modifier.weight(1.4f).height(48.dp)
        ) { Text(nextText) }
    }
}
