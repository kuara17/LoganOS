package com.dcui.loganos.obd

import com.dcui.loganos.model.DashboardSnapshot

data class PairedObdDevice(
    val name: String,
    val address: String
) {
    val displayName: String get() = if (name.isBlank()) address else "$name • $address"
}

data class ObdState(
    val pairedDevices: List<PairedObdDevice> = emptyList(),
    val selectedAddress: String? = null,
    val selectedName: String? = null,
    val status: String = "Bluetooth cihazı bekleniyor",
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val lastError: String? = null,
    val logText: String = "",
    val snapshot: DashboardSnapshot = DashboardSnapshot.empty(),
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val timingText: String = "",
    val savedLogPath: String? = null,
    val savedLogFileName: String? = null,
    val sharedLogReady: Boolean = false,
    val activeDeveloperTest: String? = null,
    val sqlSessionId: Long? = null,
    val sqlDbPath: String? = null
)
