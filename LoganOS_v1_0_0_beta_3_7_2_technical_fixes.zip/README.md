# LoganOS

Version: **1.0.0-beta.3.7.2**

## Beta 3.7.2 Technical Fixes

This build is a focused technical/UX fix package on top of 3.7.1.

Highlights:

- Launcher icon packaging corrected with adaptive icon resources and a transparent foreground mark.
- Setup flow cleaned: unused welcome step removed, 8 real setup steps retained, and the brand step carries a short welcome line.
- Automatic passive cranking detections remain temporary and are no longer permanently inserted into SQL.
- Manual cranking tests remain saved until the user deletes them.
- Cranking analysis now records OBD response gaps even when RPM becomes unavailable during cranking.
- A mid-crank disconnect now produces an incomplete cranking result instead of silently dropping the test.
- Android 12+ Bluetooth permission checks now include both BLUETOOTH_CONNECT and BLUETOOTH_SCAN.
- Unexpected OBD/socket failure can trigger one controlled auto-reconnect attempt after 2 seconds.
- English coverage has been expanded across Settings, Connection & Data, dialogs, and Fuel Calibration.
- Fuel price and Fuel Calibration help text remain based on the approved wording.

Protected core systems:

- FuelAlgorithmV3 retained.
- TripComputer retained.
- CUTOFF logic retained.
- AC_FAST bit retained.
- Delphi parser byte positions retained.
- Fuel calibration factor layer retained and remains optional.
- Fan UNKNOWN behavior retained.

## Previous 3.7.0 notes

Beta 3.7.0 added Marş Analizi / Cranking Analysis, passive automatic cranking detection, manual cranking tests, first-run Dil Seçimi / Language Selection, Settings > Dil, and English UI option with AI-assisted translation notice.
