# Claude review prompt for LoganOS

Aşağıdaki ZIP dosyası LoganOS Android/Kotlin/Jetpack Compose projesinin **v1.0.0-beta.3.7.2** sürümüdür. Lütfen projeyi genel olarak kontrol et; özellikle build almayı engelleyen hataları, Bluetooth/OBD bağlantı risklerini ve 3.7.x ile eklenen Marş Analizi + Dil desteği tarafındaki olası sorunları ara.

## Öncelik sırası

1. **Build kontrolü**
   - Gradle/Kotlin derleme hatası var mı?
   - Eksik import, fazla/eksik parametre, yanlış fonksiyon imzası, bozuk resource, versionCode/versionName uyumsuzluğu var mı?
   - GitHub Actions workflow dosyaları APK üretmeye uygun mu?

2. **Bluetooth / OBD bağlantı kodu**
   - Özellikle `ObdController.kt`, Bluetooth socket açma/kapatma, reconnect, timeout, Broken pipe/read failed durumları, Android 12+ izinleri ve lifecycle davranışını incele.
   - Uygulama ana thread’i bloke ediyor mu?
   - Bağlantı kopunca tekrar bağlanma veya state temizleme tarafında risk var mı?
   - Kontak açıkken bağlanma, motor çalışırken bağlanma, marş sırasında kısa OBD kopması gibi senaryolarda mantık sorunları var mı?
   - Daha önce çalışan `AC_FAST`, `CUTOFF`, Delphi DCM1.2 parser byte konumları ve ana OBD döngüsü bozulmuş mu?

3. **Marş Analizi / Cranking Analysis**
   - Otomatik pasif marş algılama yanlış pozitif üretebilir mi?
   - Manuel marş testi akışı doğru state’e geçiyor mu?
   - Marş sırasında OBD cevap boşluğu/kopma testi iptal etmeden yorumlanıyor mu?
   - Otomatik testlerin son 5 / 24 saat geçici saklanması ve manuel testlerin kullanıcı silene kadar kalması doğru uygulanmış mı?

4. **UI / Compose**
   - Portre kokpit kartlarında yazı kesilmesi çözülmüş mü?
   - `LazyColumn`, card height, bottom navigation ve safeDrawingPadding çakışması var mı?
   - Ayarlar > Dil ekranındaki tekrarlar kaldırılmış mı?
   - Yakıt Kalibrasyonu açıklaması kullanıcı için anlaşılır mı, dialog taşma/scroll sorunu var mı?
   - Launcher icon ve setup logo resource kullanımı doğru mu?

5. **Dil desteği**
   - İlk kurulum dil seçimi doğru çalışıyor mu?
   - English seçilince AI-assisted translation uyarısı görünüyor mu?
   - Türkçe seçiliyken gereksiz İngilizce uyarısı çıkıyor mu?
   - Settings > Language / Ayarlar > Dil değişikliği persist ediliyor mu?

## Dokunulmaması gereken kritik sistemler

Lütfen kesin bir bug yoksa şu sistemleri değiştirmeyi önermeden önce özellikle belirt:

- `FuelAlgorithmV3`
- `TripComputer`
- `CUTOFF` koşulları
- `AC_FAST` biti
- Delphi DCM1.2 parser byte konumları
- SQL ana kayıt mantığı
- Fan `UNKNOWN / test bekliyor` kararı
- Yakıt kalibrasyon katsayısının opsiyonel kalması

## İstenen çıktı formatı

Lütfen cevabını şu formatta ver:

1. **Build blocker var mı?**
2. **Bluetooth/OBD açısından riskler**
3. **Marş Analizi riskleri**
4. **UI/dil/yakıt kalibrasyonu sorunları**
5. **Kesin uygulanması gereken küçük patchler**
6. **Dokunmayın / sağlam görünen bölümler**

Gereksiz büyük refactor önermeden, mümkünse dosya adı + satır/fonksiyon bazında net öneriler ver.
