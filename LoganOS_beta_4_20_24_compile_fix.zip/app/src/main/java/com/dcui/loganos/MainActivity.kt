package com.dcui.loganos

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.toArgb
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.data.DataBackupManager
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.MenuTheme
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.runtime.LoganRuntime
import com.dcui.loganos.ui.screens.LoganAppShell
import com.dcui.loganos.ui.screens.SetupWizard
import com.dcui.loganos.ui.screens.SplashScreen
import com.dcui.loganos.ui.theme.LoganOSTheme
import com.dcui.loganos.update.SecureUpdateManager
import com.dcui.loganos.update.UpdateUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = AppPrefs(this)
        requestBluetoothPermissions()

        setContent {
            var settings by remember {
                val loaded = prefs.load()
                var normalized = if (loaded.gpsRouteEnabled && !loaded.driveHistoryEnabled) {
                    loaded.copy(gpsRouteEnabled = false)
                } else loaded
                // Demo mode is a workshop/test session, never a persistent vehicle mode.
                // Older builds could leave it enabled across a head-unit restart.
                if (normalized.demoMode) normalized = normalized.copy(demoMode = false)
                if (normalized != loaded) prefs.save(normalized)
                mutableStateOf(normalized)
            }
            var showSplash by remember { mutableStateOf(true) }
            var demoTick by remember { mutableIntStateOf(0) }
            val obdController = remember { LoganRuntime.obdController(applicationContext) }
            val updateManager = remember { SecureUpdateManager(applicationContext) }
            val dataBackupManager = remember { DataBackupManager(applicationContext) }
            val uiScope = rememberCoroutineScope()

            val bluetoothPermissions = remember {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                } else {
                    emptyArray()
                }
            }
            val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                if (obdController.hasBluetoothPermission()) {
                    obdController.refreshPairedDevices()
                    Toast.makeText(this@MainActivity, "Eşleşmiş Bluetooth cihazları yenilendi", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Bluetooth / Yakındaki cihazlar izni verilmeden OBD cihaz listesi açılamaz",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            fun refreshObdDevicesWithPermission() {
                if (obdController.hasBluetoothPermission()) {
                    obdController.refreshPairedDevices()
                } else if (bluetoothPermissions.isNotEmpty()) {
                    bluetoothPermissionLauncher.launch(bluetoothPermissions)
                } else {
                    obdController.refreshPairedDevices()
                }
            }

            val gpsPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { result ->
                val fineGranted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    ActivityCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (fineGranted) {
                    val updated = settings.copy(
                        gpsRouteEnabled = true,
                        driveHistoryEnabled = true
                    )
                    settings = updated
                    prefs.save(updated)
                    Toast.makeText(
                        this@MainActivity,
                        "GPS rota kaydı açıldı. Konum izni yalnız rota özelliği için kullanılır.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val updated = settings.copy(gpsRouteEnabled = false)
                    settings = updated
                    prefs.save(updated)
                    Toast.makeText(
                        this@MainActivity,
                        "Konum izni verilmedi. LoganOS normal çalışmaya devam edecek; yalnız GPS rota kaydı kapalı kalacak.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            val createBackupLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/zip")
            ) { uri ->
                if (uri != null) {
                    uiScope.launch {
                        val result = withContext(Dispatchers.IO) {
                            val databaseFile = obdController.createDatabaseBackupSnapshot()
                                ?: return@withContext DataBackupManager.Result(false, "Önce OBD bağlantısını kesin ve aktif işlemlerin bitmesini bekleyin")
                            try {
                                dataBackupManager.writeBackup(uri, prefs.exportBackupJson(), databaseFile)
                            } finally {
                                databaseFile.delete()
                                java.io.File(databaseFile.absolutePath + "-wal").delete()
                                java.io.File(databaseFile.absolutePath + "-shm").delete()
                                java.io.File(databaseFile.absolutePath + "-journal").delete()
                            }
                        }
                        Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
                    }
                }
            }

            val restoreBackupLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    uiScope.launch {
                        if (!obdController.canCreateOrRestoreDataBackup()) {
                            Toast.makeText(this@MainActivity, "Önce OBD bağlantısını kesin ve aktif işlemlerin bitmesini bekleyin", Toast.LENGTH_LONG).show()
                            return@launch
                        }
                        // Restore replaces the SQLite file, therefore the open helper must
                        // be fully released first. The activity is recreated afterwards on
                        // both success and failure so a fresh controller/database handle is used.
                        LoganRuntime.releaseObdController()
                        val result = withContext(Dispatchers.IO) { dataBackupManager.restoreBackup(uri, prefs) }
                        Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
                        delay(500L)
                        this@MainActivity.recreate()
                    }
                }
            }
            val obdState = obdController.state
            val systemDark = isSystemInDarkTheme()
            val dark = when (settings.menuTheme) {
                MenuTheme.Dark -> true
                MenuTheme.System -> systemDark
                else -> false
            }

            LaunchedEffect(obdState.exportFeedbackNonce) {
                if (obdState.exportFeedbackNonce > 0L) {
                    obdState.exportFeedbackMessage?.let { message ->
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                    }
                }
            }
            val configuration = LocalConfiguration.current

            fun persist(requested: LoganSettings) {
                var updated = requested
                val enablingGps = !settings.gpsRouteEnabled && updated.gpsRouteEnabled
                if (enablingGps && !updated.driveHistoryEnabled) {
                    // GPS routes belong to completed drive-history records. Enabling
                    // route recording therefore also enables automatic drive history.
                    updated = updated.copy(driveHistoryEnabled = true)
                }
                if (!updated.driveHistoryEnabled && updated.gpsRouteEnabled) {
                    // Prevent route points from being recorded into sessions that can
                    // never become a completed drive-history record.
                    updated = updated.copy(gpsRouteEnabled = false)
                }
                if (enablingGps) {
                    val config = resources.configuration
                    val uiModeType = config.uiMode and Configuration.UI_MODE_TYPE_MASK
                    val resolvedHeadUnit = when (updated.deviceMode) {
                        DeviceMode.HeadUnit -> true
                        DeviceMode.Phone -> false
                        DeviceMode.Auto -> uiModeType == Configuration.UI_MODE_TYPE_CAR || config.smallestScreenWidthDp >= 600
                    }
                    if (resolvedHeadUnit) {
                        Toast.makeText(
                            this@MainActivity,
                            "GPS rota kaydı beta.4.9.2 sürümünde yalnız Telefon modunda desteklenir.",
                            Toast.LENGTH_LONG
                        ).show()
                        return
                    }

                    val fineGranted = ActivityCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!fineGranted) {
                        gpsPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            )
                        )
                        return
                    }
                }
                settings = updated
                prefs.save(updated)
            }


            LaunchedEffect(Unit) {
                // Yeni sürüm ilk kez açıldığında önceki OTA kurulum dosyalarını
                // cache'ten temizle. Aynı sürüm yeniden açılırsa bekleyen APK korunur.
                withContext(Dispatchers.IO) {
                    updateManager.cleanupStaleUpdateFilesAfterVersionChange()
                }

                // Açılışta en fazla günde bir kez sessiz sürüm kontrolü. Güncelleme
                // varsa yalnızca bilgi verilir; indirme/kurulum kullanıcı eylemi ister.
                delay(5000L)
                if (updateManager.shouldAutoCheck()) {
                    when (val result = updateManager.checkForUpdate()) {
                        is UpdateUiState.Available -> Toast.makeText(
                            this@MainActivity,
                            "Yeni LoganOS sürümü mevcut: ${result.release.versionName} • Ayarlar > Güncellemeler",
                            Toast.LENGTH_LONG
                        ).show()
                        else -> Unit
                    }
                }
            }

            LaunchedEffect(Unit) {
                // Double head units may receive the real date/time from GPS a
                // few seconds after boot. Keep the UI state in sync even before
                // an OBD polling loop starts.
                while (true) {
                    obdController.refreshTrustedTimeState()
                    delay(1000L)
                }
            }

            LaunchedEffect(settings.rawEcuLogEnabled, settings.developerModeEnabled) {
                // Normal kullanımda kayıt sistemi otomatik/akıllı özet modundadır.
                // Geliştirici modu açıldığında testler için tam frekanslı özet kayıt tutulur.
                val rawLogEnabled = settings.developerModeEnabled && settings.rawEcuLogEnabled
                val smartSummaryLog = !settings.developerModeEnabled
                obdController.setLoggingOptions(rawLogEnabled, smartSummaryLog)
            }

            LaunchedEffect(settings) {
                // Smart Trip kararı ve export metadata'sı güncel ayarlardan beslensin.
                obdController.setRuntimeSettings(settings)
            }

            LaunchedEffect(settings.backgroundTripEnabled, settings.gpsRouteEnabled, obdState.connected) {
                if ((settings.backgroundTripEnabled || settings.gpsRouteEnabled) && obdState.connected) {
                    requestNotificationPermissionIfNeeded()
                }
            }

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(
                settings.deviceMode,
                settings.gaugeStyle,
                settings.setupCompleted,
                configuration.smallestScreenWidthDp,
                configuration.uiMode
            ) {
                val uiModeType = configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
                val autoHeadUnit = uiModeType == Configuration.UI_MODE_TYPE_CAR || configuration.smallestScreenWidthDp >= 600
                val resolvedMode = when (settings.deviceMode) {
                    DeviceMode.Auto -> if (autoHeadUnit) DeviceMode.HeadUnit else DeviceMode.Phone
                    else -> settings.deviceMode
                }
                // Ghost Single now IS the baked former Ghost Single Original design.
                // Both Ghost Single and Ghost Dual are landscape-only on phones.
                val phoneGhostLandscapeOnly = settings.setupCompleted &&
                    resolvedMode == DeviceMode.Phone &&
                    (settings.gaugeStyle == GaugeStyle.GhostSingle || settings.gaugeStyle == GaugeStyle.GhostDual || settings.gaugeStyle == GaugeStyle.GhostSingleOriginal || settings.gaugeStyle == GaugeStyle.GhostDualOriginal)
                requestedOrientation = when {
                    settings.setupCompleted && resolvedMode == DeviceMode.HeadUnit ->
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    phoneGhostLandscapeOnly ->
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            LaunchedEffect(showSplash) {
                if (showSplash) {
                    // Splash için maksimum bekleme/fallback. Reset akışında showSplash false'a alınır.
                    delay(1700)
                    showSplash = false
                }
            }

            LaunchedEffect(settings.demoMode) {
                while (settings.demoMode) {
                    delay(800)
                    demoTick++
                }
            }

            fun enrichTrip(snapshot: DashboardSnapshot): DashboardSnapshot {
                // Deneysel benzinli profilde temel OBD verileri gösterilir; doğrulanmış
                // enjeksiyon/fuel-rate kaynağı bulunana kadar tüketim ve maliyet üretilmez.
                if (!settings.fuelCalculationSupported) {
                    val distance = snapshot.tripDistanceKm
                    val baseOdo = settings.odometerText.toIntOrNull()
                    val odo = if (baseOdo != null && distance != null) {
                        baseOdo + distance.toInt()
                    } else snapshot.odometerKm
                    return snapshot.copy(
                        averageConsumption = null,
                        instantConsumption = null,
                        instantUnit = "",
                        fuelUsedL = null,
                        tripCostText = null,
                        odometerKm = odo,
                        fuelSource = if (settings.fuelType == FuelType.Petrol) "PETROL_UNVERIFIED" else "PROFILE_UNVERIFIED"
                    )
                }

                val calibrationFactor = if (settings.fuelCalibrationEnabled) {
                    settings.fuelCalibrationFactor.coerceIn(0.50, 1.50)
                } else {
                    1.0
                }
                val calibrated = if (calibrationFactor != 1.0) {
                    snapshot.copy(
                        averageConsumption = snapshot.averageConsumption?.times(calibrationFactor),
                        instantConsumption = snapshot.instantConsumption?.times(calibrationFactor),
                        fuelUsedL = snapshot.fuelUsedL?.times(calibrationFactor)
                    )
                } else snapshot

                val distance = calibrated.tripDistanceKm
                val fuel = calibrated.fuelUsedL
                val cockpitTotals = obdController.cockpitTripSnapshot()

                // Average consumption is the one cockpit metric that intentionally
                // survives ignition/history boundaries. Its reset baseline is stored
                // against the persistent fuel/distance accumulator, not the active
                // TripComputer segment. Distance, duration and cost remain active-trip
                // values and therefore start from zero on a new drive.
                val hasAverageBaseline = settings.avgResetDistanceKm > 0.0 || settings.avgResetFuelLiters > 0.0
                val averageBaselineValid = cockpitTotals.totalDistanceKm >= settings.avgResetDistanceKm &&
                    cockpitTotals.totalFuelLiters + 0.000001 >= settings.avgResetFuelLiters
                val avgBaseDistance = if (hasAverageBaseline && averageBaselineValid) settings.avgResetDistanceKm else 0.0
                val avgBaseFuel = if (hasAverageBaseline && averageBaselineValid) settings.avgResetFuelLiters else 0.0
                val avgDistance = (cockpitTotals.totalDistanceKm - avgBaseDistance).coerceAtLeast(0.0)
                val avgFuel = (cockpitTotals.totalFuelLiters - avgBaseFuel).coerceAtLeast(0.0)
                val resetAverage = if (avgDistance >= 1.0) {
                    (avgFuel / avgDistance.coerceAtLeast(0.0001)) * 100.0
                } else {
                    calibrated.averageConsumption ?: cockpitTotals.averageL100
                }

                val price = settings.fuelPriceText.replace(',', '.').toDoubleOrNull()
                val hasCostBaseline = settings.costResetFuelLiters > 0.0
                val costBaselineValid = fuel != null && settings.costResetFuelLiters in 0.0..fuel
                val costBaseFuel = if (hasCostBaseline && costBaselineValid) settings.costResetFuelLiters else 0.0
                val costFuel = fuel?.minus(costBaseFuel)?.coerceAtLeast(0.0)
                val cost = if (price != null && price > 0.0 && costFuel != null) {
                    String.format(java.util.Locale.US, "%.2f ₺", costFuel * price)
                } else calibrated.tripCostText
                val baseOdo = settings.odometerText.toIntOrNull()
                val odo = if (baseOdo != null && distance != null) {
                    baseOdo + distance.toInt()
                } else calibrated.odometerKm
                return calibrated.copy(
                    averageConsumption = resetAverage,
                    tripCostText = cost,
                    odometerKm = odo
                )
            }

            val liveSnapshot = when {
                settings.demoMode -> enrichTrip(DashboardSnapshot.demoLive(demoTick))
                obdState.connected -> enrichTrip(obdState.snapshot)
                else -> DashboardSnapshot.empty()
            }

            LoganOSTheme(accentColor = settings.accentColor, darkTheme = dark, menuTheme = settings.menuTheme) { palette ->
                SideEffect {
                    // Keep the Android status/navigation bars in the same theme as LoganOS.
                    // This prevents a light system bar around a dark cockpit (and vice versa).
                    window.statusBarColor = palette.background.toArgb()
                    window.navigationBarColor = palette.surface.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !dark
                        isAppearanceLightNavigationBars = !dark
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        window.isStatusBarContrastEnforced = false
                        window.isNavigationBarContrastEnforced = false
                    }
                }
                when {
                    showSplash -> SplashScreen(palette)
                    !settings.setupCompleted -> SetupWizard(
                        palette = palette,
                        initial = settings,
                        onComplete = { updated -> persist(updated) }
                    )
                    else -> LoganAppShell(
                        palette = palette,
                        settings = settings,
                        snapshot = liveSnapshot,
                        obdState = obdState,
                        onSettingsChange = { updated -> persist(updated) },
                        onResetSetup = {
                            prefs.resetSetup()
                            settings = settings.copy(setupCompleted = false)
                            // Kurulumu sıfırla sonrası splash'a dönmeden doğrudan sihirbaz açılır.
                            showSplash = false
                        },
                        onResetMetrics = { action ->
                            if (settings.demoMode || liveSnapshot.demo) {
                                Toast.makeText(this, "Demo Modu verileri gerçek yol bilgisayarı sıfırlamalarında kullanılamaz", Toast.LENGTH_SHORT).show()
                            } else if (!settings.fuelCalculationSupported) {
                                Toast.makeText(this, "Benzinli profilde yakıt hesabı henüz doğrulanmadı", Toast.LENGTH_SHORT).show()
                            } else if (liveSnapshot.tripToken == 0L) {
                                Toast.makeText(this, "Aktif yolculuk verisi yok", Toast.LENGTH_SHORT).show()
                            } else {
                                val activeFuel = liveSnapshot.fuelUsedL ?: 0.0
                                val cockpitTotals = obdController.cockpitTripSnapshot()
                                val historicalDistance = cockpitTotals.totalDistanceKm
                                val historicalFuel = cockpitTotals.totalFuelLiters
                                val updated = when (action) {
                                    TripMetricReset.Average -> settings.copy(
                                        avgResetDistanceKm = historicalDistance,
                                        avgResetFuelLiters = historicalFuel,
                                        avgResetTripToken = 0L
                                    )
                                    TripMetricReset.Cost -> settings.copy(
                                        costResetFuelLiters = activeFuel,
                                        costResetTripToken = 0L
                                    )
                                    TripMetricReset.AverageAndCost -> settings.copy(
                                        avgResetDistanceKm = historicalDistance,
                                        avgResetFuelLiters = historicalFuel,
                                        costResetFuelLiters = activeFuel,
                                        avgResetTripToken = 0L,
                                        costResetTripToken = 0L
                                    )
                                }
                                persist(updated)
                                obdController.logMetricReset(
                                    action,
                                    liveSnapshot.tripDistanceKm ?: 0.0,
                                    activeFuel,
                                    settings.fuelPriceText
                                )
                                val message = when (action) {
                                    TripMetricReset.Average -> "Ortalama tüketimi sıfırlandı"
                                    TripMetricReset.Cost -> "Sürüş maliyeti sıfırlandı"
                                    TripMetricReset.AverageAndCost -> "Ortalama ve maliyet sıfırlandı"
                                }
                                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onEndTripNow = {
                            if (settings.demoMode || liveSnapshot.demo) {
                                Toast.makeText(this@MainActivity, "Demo Modu sırasında gerçek sürüş kaydı sonlandırılamaz", Toast.LENGTH_SHORT).show()
                            } else uiScope.launch {
                                val ended = obdController.finishTripNow()
                                Toast.makeText(
                                    this@MainActivity,
                                    if (ended) "Sürüş tamamlandı; yeni sürüş bekleniyor" else "Tamamlanacak aktif sürüş yok",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        onRefreshObdDevices = { refreshObdDevicesWithPermission() },
                        onSelectObdDevice = { obdController.selectDevice(it) },
                        onConnectObd = { obdController.connectSelected() },
                        onDisconnectObd = { obdController.disconnect() },
                        onSaveObdLog = {
                            obdController.saveLogFile()
                            Toast.makeText(this, "Kayıt dışa aktarıldı", Toast.LENGTH_SHORT).show()
                        },
                        onShareObdLog = { obdController.shareLogText() },
                        onExportTechnicalSession = { id -> obdController.exportTechnicalSession(id) },
                        onCreateSupportPackage = {
                            val attachmentUri = obdController.createSupportPackage()
                            Toast.makeText(
                                this,
                                if (attachmentUri != null) "Destek paketi e-postaya hazırlandı" else "Destek paketi oluşturulamadı",
                                Toast.LENGTH_SHORT
                            ).show()
                            attachmentUri
                        },
                        onClearLastObdLog = {
                            obdController.clearLastLogFile()
                            Toast.makeText(this, "Son log işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        },
                        onClearAllObdLogs = {
                            val cleared = obdController.clearAllLogFiles()
                            Toast.makeText(
                                this,
                                if (cleared) "Log temizleme işlemi tamamlandı" else "Önce OBD bağlantısını kesin",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onDeveloperTestStart = { name ->
                            obdController.startDeveloperTest(name)
                            val current = obdController.state
                            val started = current.activeDeveloperTest == name
                            Toast.makeText(
                                this,
                                if (started) "Test başlatıldı: $name" else current.status,
                                if (started) Toast.LENGTH_SHORT else Toast.LENGTH_LONG
                            ).show()
                        },
                        onDeveloperTestEnd = {
                            obdController.finishDeveloperTest()
                            Toast.makeText(this, "Test bitti", Toast.LENGTH_SHORT).show()
                        },
                        onStartCrankAnalysis = { obdController.armManualCrankAnalysis() },
                        onClearManualCrankTests = {
                            obdController.clearManualCrankTests()
                            Toast.makeText(this, "Marş testleri silindi", Toast.LENGTH_SHORT).show()
                        },
                        onRefreshHistory = { obdController.refreshHistory() },
                        onLoadDriveHistoryDetail = { id -> obdController.loadDriveHistoryDetail(id) },
                        onClearDriveHistoryDetail = { obdController.clearDriveHistoryDetail() },
                        onPinDriveHistory = { id, pinned ->
                            val ok = obdController.setDriveHistoryPinned(id, pinned)
                            Toast.makeText(this, if (ok) (if (pinned) "Sürüş korumaya alındı" else "Sürüş koruması kaldırıldı") else "Sürüş güncellenemedi", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteDriveHistory = { id ->
                            val ok = obdController.deleteDriveHistory(id)
                            Toast.makeText(this, if (ok) "Sürüş kaydı silindi" else "Aktif veya bekleyen sürüş silinemez", Toast.LENGTH_SHORT).show()
                        },
                        onExportDriveHistory = { id ->
                            obdController.exportDriveHistory(id)
                        },
                        onExportGpsRoute = { id ->
                            obdController.exportGpsRoute(id)
                        },
                        onPinTestHistory = { id, pinned ->
                            val ok = obdController.setTestHistoryPinned(id, pinned)
                            Toast.makeText(this, if (ok) (if (pinned) "Test korumaya alındı" else "Test koruması kaldırıldı") else "Test güncellenemedi", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteTestHistory = { id ->
                            val ok = obdController.deleteTestHistory(id)
                            Toast.makeText(this, if (ok) "Test kaydı silindi" else "Aktif test silinemez", Toast.LENGTH_SHORT).show()
                        },
                        onExportTestHistory = { id ->
                            obdController.exportTestHistory(id)
                        },
                        onExportAllHistory = {
                            obdController.exportAllHistory()
                        },
                        onCreateDataBackup = {
                            if (!obdController.canCreateOrRestoreDataBackup()) {
                                Toast.makeText(this, "Yedekleme için önce OBD bağlantısını kesin", Toast.LENGTH_LONG).show()
                            } else {
                                createBackupLauncher.launch(dataBackupManager.defaultBackupFileName())
                            }
                        },
                        onRestoreDataBackup = {
                            if (!obdController.canCreateOrRestoreDataBackup()) {
                                Toast.makeText(this, "Geri yükleme için önce OBD bağlantısını kesin", Toast.LENGTH_LONG).show()
                            } else {
                                restoreBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed"))
                            }
                        },
                        onFuelRefillLitersSave = { text -> obdController.setFuelRefillLiters(text) }
                    )
                }
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1204
            )
        }
    }

    private fun requestBluetoothPermissions() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions, 1203)
    }
}
