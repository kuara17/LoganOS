# LoganOS

**OEM Digital Cockpit • Powered by DC UI**

Version: **1.0.0-beta.3.6.2**

## Beta 3.6.2 Focus

This patch adds guided developer test screens for real OBD testing.

### Highlights

- Full-screen developer test countdown panel.
- Klima / sıcak rölanti / elektrik-yük / CUTOFF / serbest sürüş test phases.
- TEST_START, TEST_PHASE and TEST_END markers are written to the log.
- SQL session logging from beta 3.6.x is preserved.
- Manual ZIP build workflow keeps Gradle root detection for GitHub Actions.

## Status

Bluetooth, ELM init, KWP Fast Init and raw ECU response are working in Beta testing.
Trip Computer / Smart Trip and SQL session logging are active in the beta test track.


### fix5
- AC fast loop and 21CC priority.
- 21A2/21CD slower technical cycle.
- Portrait settings polish.
