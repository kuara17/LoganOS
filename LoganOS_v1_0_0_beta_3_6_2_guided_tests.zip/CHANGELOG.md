## v1.0.0-beta.3.6.2 - Guided Developer Tests

- Developer tests now open a full-screen guided countdown panel.
- Test phases show practical instructions such as klima kapalı / klimayı aç / klimayı kapat.
- Test phase changes are written to the log as TEST_PHASE markers.
- Tests end automatically when the countdown completes and show a short “Test bitti” message.
- Manual “Testi Bitir” remains available during the countdown.
- Manual ZIP build workflow keeps the fixed Gradle root detection.

## v1.0.0-beta.3.5.2 - Drive Text Cleanup

- Sürüş & Yakıt satır açıklamaları daha anlaşılır hale getirildi.
- Ortalama tüketimi sıfırla satırındaki kafa karıştıran "Onay" etiketi kaldırıldı.
- Fuel Truth test panelindeki küçük kart yüksekliği artırıldı; unit/metin kırpılması azaltıldı.
- Version label, APK adı ve artifact adı beta.3.5.2 olarak güncellendi.

## v1.0.0-beta.3.5.2 - Supported Vehicle Gate

- Setup now enables only Dacia Logan I with 1.5 dCi 48 kW, the currently validated LoganOS/DC UI profile.
- Other engines are visible but disabled with clear "pasif" labels.
- Dacia Jogger was removed from setup because it is not relevant to the current supported profile.
- Vehicle rows now include model year ranges and more realistic engine/support notes.
- Duster and newer/original-trip-computer vehicles are marked as unsupported/priority-out.
- Version labels and APK artifact name updated to beta.3.5.2.

## v1.0.0-beta.3.5 - Connect Select Flow

- Version labels, APK artifact name, and log filenames updated to beta.3.5.
- Device selection list now collapses after choosing an adapter.
- Selecting a paired OBD adapter now immediately starts connection.
- Hararet card title sizing adjusted so HARARET is not clipped on compact cards.
- Fuel Truth Core from beta.3.4 / beta.3.4.1 is preserved.

## v1.0.0-beta.3.4.1 - Log Row Cleanup

- Removed action words like Onay/Paylaş/Oluştur from Log & Destek rows.
- Log rows are cleaner clickable rows with only a subtle chevron.
- Fuel Truth Core from beta.3.4 is preserved.

## v1.0.0-beta.3.4 - Fuel Truth Core

- DC UI Alpha ve Pydroid loglarıyla doğrulanan Delphi DCM1.2 alanları Kotlin parser'a eklendi: pedal %, MAP, requested MAP, air charge, emme/yakıt sıcaklığı, rail/rail hedef, sensor supply V ve ECU akü voltajı.
- FuelAlgorithmV3 Kotlin çekirdeği eklendi: CUTOFF, CRANK_GUARD, INJECTION, HOLD, MAF_FALLBACK, MAP_FALLBACK ve NONE kaynak seçimi.
- BASIC_INJECTION sabit kaynak yazısı yerine gerçek fuelSource seçimi kullanılmaya başlandı.
- Pedal/MAP/Air/Rail gibi değerler Teknik sekmeye ve Fuel Truth paneline eklendi.
- ATRV adaptör voltajı ECU akü voltajından ayrı tutuldu.
- Fan durumu kanıtlanmadığı için UNKNOWN kalmaya devam eder; fan decode geri getirilmedi.
- TripComputer ve SQLite/Room kayıt sistemi bu sürüme eklenmedi; sonraki aşamaya bırakıldı.

## v1.0.0-beta.3.3-fix11 - Settings Cleanup + Data Trust

- Ayarlar kartları daha belirgin hale getirildi.
- Bağlantı & Veri ekranı sadeleştirildi; OBD kartı ve Log & Destek grubu düzenlendi.
- Kanıtlanmamış fan biti kaldırıldı; Fan kartı Bilinmiyor/-- gösterir.
