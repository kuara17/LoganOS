package com.dcui.loganos.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.components.HeaderLine
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.Slogan
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun SplashScreen(palette: LoganPalette) {
    val visible = remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { visible.value = true }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        AnimatedVisibility(visible = visible.value, enter = fadeIn(animationSpec = tween(450))) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                LoganWordmark(palette = palette)
                Spacer(Modifier.height(8.dp))
                Text("OEM Digital Cockpit", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(20.dp))
                HeaderLine(palette, modifier = Modifier.fillMaxWidth(.56f))
                Spacer(Modifier.height(22.dp))
                Text("Powered by DC UI", color = palette.textSecondary, fontSize = 15.sp)
                Spacer(Modifier.height(14.dp))
                Text("Fuel Truth Technology", color = palette.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text("Delphi DCM1.2 Optimized", color = palette.textSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(34.dp))
                Slogan(palette)
            }
        }
    }
}
