package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.theme.LoganPalette

enum class SettingsCategory(val title: String) {
    Appearance("Görünüm"), Dashboard("Dashboard"), Drive("Sürüş"), Obd("Bluetooth / OBD"), Fuel("Yakıt"), Vehicle("Araç"), Maintenance("Bakım"), Data("Veri & Destek"), Developer("Geliştirici"), About("Hakkında")
}

@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    onOpenSettings: () -> Unit,
    onResetSetup: () -> Unit
) {
    var selected by remember { mutableStateOf(SettingsCategory.Appearance) }
    Row(
        modifier = Modifier.fillMaxSize().background(palette.background).padding(14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        LazyColumn(modifier = Modifier.width(170.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item { Text("Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(bottom = 10.dp)) }
            SettingsCategory.entries.forEach { cat ->
                item {
                    val active = selected == cat
                    Text(
                        text = cat.title,
                        color = if (active) palette.accent else palette.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(if (active) palette.accent.copy(alpha = .10f) else palette.surface).clickable { selected = cat }.padding(14.dp)
                    )
                }
            }
        }
        OemCard(palette, modifier = Modifier.weight(1f).fillMaxSize()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                item { Text(selected.title, color = palette.accent, fontSize = 30.sp, fontWeight = FontWeight.Black) }
                item { Spacer(Modifier.height(8.dp)) }
                when (selected) {
                    SettingsCategory.Appearance -> appearanceRows(palette, settings)
                    SettingsCategory.Dashboard -> dashboardRows(palette)
                    SettingsCategory.Drive -> driveRows(palette)
                    SettingsCategory.Obd -> obdRows(palette)
                    SettingsCategory.Fuel -> fuelRows(palette)
                    SettingsCategory.Vehicle -> vehicleRows(palette, settings)
                    SettingsCategory.Maintenance -> maintenanceRows(palette)
                    SettingsCategory.Data -> dataRows(palette)
                    SettingsCategory.Developer -> developerRows(palette)
                    SettingsCategory.About -> aboutRows(palette, onResetSetup)
                }
            }
        }
    }
}

private fun androidx.compose.foundation.lazy.LazyListScope.appearanceRows(palette: LoganPalette, settings: LoganSettings) {
    item { SettingsRow(palette, "Tema", "Açık / Koyu / Otomatik", if (settings.darkMode) "Koyu" else "OEM Light") }
    item { SettingsRow(palette, "Vurgu Rengi", "Varsayılan OEM Green", settings.accentColor.label) }
    item { SettingsRow(palette, "Gösterge Stili", "Digital, Sport, Classic OEM, Minimal, RS", settings.gaugeStyle.label) }
    item { SettingsRow(palette, "Yazı Boyutu", "Sürüş ve ayar ekranı yazıları", "Normal") }
    item { SettingsRow(palette, "Animasyonlar", "OEM Motion Design", "Açık") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.dashboardRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Dashboard Düzenle", "Kartları göster/gizle ve sırala", "Aç") }
    item { SettingsRow(palette, "Ortalama Tüketim", "Uzun basınca sıfırlama menüsü", "Aktif") }
    item { SettingsRow(palette, "Sürüş Maliyeti", "Yakıt fiyatı girilmezse bilgilendirme gösterir", "Aktif") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.driveRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Akıllı Yolculuk", "Motor stop sonrası aynı yolculuğu sürdürme", "1 saat") }
    item { SettingsRow(palette, "Yolculuk Özeti", "İstenildiği anda görüntülenebilir", "Manuel + Otomatik") }
    item { SettingsRow(palette, "Sürüş sırasında ekranı açık tut", "Screen timeout engellenir", trailingSwitch = true, onSwitch = {}) }
    item { SettingsRow(palette, "Arka planda yolculuğu sürdür", "OBD servisi UI'dan bağımsız çalışır", trailingSwitch = true, onSwitch = {}) }
    item { SettingsRow(palette, "GPS Rota Kaydı", "İsteğe bağlı", "Kapalı") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.obdRows(palette: LoganPalette) {
    item { SettingsRow(palette, "OBD Cihazı Seç", "Eşleşmiş Bluetooth cihazları", "Seçilmedi") }
    item { SettingsRow(palette, "Otomatik Bağlan", "Son seçili adaptöre bağlan", "Açık") }
    item { SettingsRow(palette, "Bağlantı Sağlığı", "Yeniden bağlanma ve gecikme", "Aç") }
    item { SettingsRow(palette, "ECU Bilgisi", "VDIAG / protokol bilgileri", "Bekleniyor") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.fuelRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Güncel Yakıt Fiyatı", "Sürüş maliyeti için gerekli", "Girilmedi") }
    item { SettingsRow(palette, "Yakıt Kalibrasyonu", "Mesafe + pompada alınan litre", "Ayarla") }
    item { SettingsRow(palette, "Yakıt Fiyatı Geçmişi", "Her sürüş kendi fiyatıyla mühürlenir", "Aktif") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.vehicleRows(palette: LoganPalette, settings: LoganSettings) {
    item { SettingsRow(palette, "Marka", null, settings.brand.label) }
    item { SettingsRow(palette, "Model", null, settings.vehicleModel) }
    item { SettingsRow(palette, "Motor", null, settings.engine) }
    item { SettingsRow(palette, "Kilometre Eşitleme", "Gösterge kilometresini ayda bir kalibre et", "Ayarla") }
    item { SettingsRow(palette, "Cihaz Modu", "Telefon / Android multimedya", settings.deviceMode.label) }
}

private fun androidx.compose.foundation.lazy.LazyListScope.maintenanceRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Motor Yağı", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Yağ Filtresi", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Mazot Filtresi", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Hava Filtresi", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Polen Filtresi", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Triger Seti", "Km + gün takibi", "Ayarla") }
    item { SettingsRow(palette, "Muayene / Sigorta / Kasko", "Tarih bazlı hatırlatma", "Ayarla") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.dataRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Destek Paketi Oluştur", "Loglar, cihaz bilgisi ve hata kayıtları", "Oluştur") }
    item { SettingsRow(palette, "Geri Bildirim Gönder", "Öneri veya hata bildirimi", "Aç") }
    item { SettingsRow(palette, "Verileri Dışa Aktar", "SQLite yedeği ve raporlar", "Dışa aktar") }
    item { SettingsRow(palette, "Verileri İçe Aktar", "Yedekten geri yükleme", "İçe aktar") }
    item { SettingsRow(palette, "Tüm Verileri Sil", "Yolculuk, bakım, ayarlar", "Sil") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.developerRows(palette: LoganPalette) {
    item { SettingsRow(palette, "Geliştirici Modu", "Ham ECU verileri ve debug", trailingSwitch = false, onSwitch = {}) }
    item { SettingsRow(palette, "Teknik Ekran", "Motor, sensör, OBD ve canlı izleme", "Aç") }
    item { SettingsRow(palette, "Ham ECU Verileri", "Sadece geliştirici modunda", "Kilitli") }
    item { SettingsRow(palette, "CSV Log Kaydı", "Sadece geliştirici modu", "Kapalı") }
}

private fun androidx.compose.foundation.lazy.LazyListScope.aboutRows(palette: LoganPalette, onResetSetup: () -> Unit) {
    item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("LOGANOS", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("Version 1.0.0 Beta", color = palette.accent, fontWeight = FontWeight.Bold)
            Text("OEM Digital Cockpit", color = palette.textSecondary)
            Text("Powered by DC UI", color = palette.textSecondary)
            Text("Fuel Truth Technology", color = palette.textPrimary, fontWeight = FontWeight.SemiBold)
            Text("Delphi DCM1.2 Optimized • KWP2000 Fast Init", color = palette.textSecondary)
            Text("Ücretsiz, reklamsız ve açık kaynaklı proje.", color = palette.textSecondary)
            Spacer(Modifier.height(12.dp))
            Button(onClick = onResetSetup, colors = ButtonDefaults.buttonColors(containerColor = palette.accent)) { Text("Kurulumu Sıfırla") }
        }
    }
}
