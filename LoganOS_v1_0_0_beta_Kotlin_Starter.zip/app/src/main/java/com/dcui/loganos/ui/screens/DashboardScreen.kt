package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SpeedGauge
import com.dcui.loganos.ui.theme.LoganPalette

enum class MainTab(val label: String) { Dashboard("Dashboard"), Trip("Yol Bilgisayarı"), Health("Araç Sağlığı"), History("Geçmiş"), Settings("Ayarlar") }

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenSettings: () -> Unit,
    onResetSetup: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Dashboard) }
    Column(
        modifier = Modifier.fillMaxSize().background(palette.background)
    ) {
        when (tab) {
            MainTab.Dashboard -> DashboardContent(palette, settings, snapshot)
            MainTab.Trip -> PlaceholderPage(palette, "Yol Bilgisayarı", "Güncel sürüş, son sürüş, uzun dönem ve Smart Trip verileri burada yer alacak.")
            MainTab.Health -> PlaceholderPage(palette, "Araç Sağlığı", "Motor, akü, marş, soğutma ve yakıt sistemi değerlendirmeleri burada gösterilecek.")
            MainTab.History -> PlaceholderPage(palette, "Geçmiş", "SQLite tabanlı sürüş geçmişi ve raporlar burada listelenecek.")
            MainTab.Settings -> SettingsScreen(palette, settings, onOpenSettings, onResetSetup)
        }
        BottomNavigationBar(palette, current = tab) { tab = it }
    }
}

@Composable
private fun DashboardContent(palette: LoganPalette, settings: LoganSettings, snapshot: DashboardSnapshot) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        DashboardHeader(palette, snapshot)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1.55f)) {
            OemCard(palette, modifier = Modifier.weight(1.45f).fillMaxSize()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxSize()) {
                    Text("HIZ", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    SpeedGauge(palette, snapshot.speedKmh, settings.gaugeStyle, Modifier.weight(1f).fillMaxWidth())
                    Text("Trip A  ${snapshot.tripDistanceKm} km     ODO ${snapshot.odometerKm} km", color = palette.textSecondary, fontSize = 12.sp)
                }
            }
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(.95f)) {
                DataCard(
                    palette = palette,
                    title = "Ortalama Tüketim",
                    value = snapshot.averageConsumption.toString(),
                    unit = "L/100 km",
                    subtitle = "Sürüş ortalaması",
                    modifier = Modifier.weight(1f).fillMaxWidth()
                )
                DataCard(
                    palette = palette,
                    title = "Sürüş Maliyeti",
                    value = snapshot.tripCostText,
                    subtitle = if (snapshot.tripCostText.contains("Fiyat")) "Yakıt fiyatı girilmedi" else "${snapshot.fuelUsedL} L",
                    accent = Color(0xFFFF8A00),
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    onClick = { }
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(.9f)) {
            DataCard(palette, "Anlık Tüketim", snapshot.instantConsumption.toString(), snapshot.instantUnit, subtitle = "Canlı tüketim", modifier = Modifier.weight(1f).fillMaxSize())
            DataCard(palette, "Mesafe", snapshot.tripDistanceKm.toString(), "km", subtitle = "Toplam mesafe", accent = palette.blue, modifier = Modifier.weight(1f).fillMaxSize())
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(.8f)) {
            EngineTempCard(palette, snapshot, Modifier.weight(1f).fillMaxSize())
            DataCard(palette, "Devir", snapshot.rpm.toString(), "d/dk", accent = palette.accent, modifier = Modifier.weight(1f).fillMaxSize())
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(.75f)) {
            DataCard(palette, "Klima", if (snapshot.acOn) "Açık" else "Kapalı", accent = palette.blue, modifier = Modifier.weight(1f).fillMaxSize())
            DataCard(palette, "Akü", "${snapshot.batteryV}", "V", accent = palette.accent, subtitle = "Araç Sağlığı detayında", modifier = Modifier.weight(1f).fillMaxSize())
        }
        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth().height(48.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2F343A)),
            shape = RoundedCornerShape(14.dp)
        ) { Text("Yolculuk Özeti", fontWeight = FontWeight.Bold) }
    }
}

@Composable
private fun DashboardHeader(palette: LoganPalette, snapshot: DashboardSnapshot) {
    Row(
        modifier = Modifier.fillMaxWidth().height(52.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        LoganWordmark(palette, compact = true)
        Column(horizontalAlignment = Alignment.End) {
            Text(if (snapshot.connected) "OBD Bağlı" else "OBD Bağlantısı Bekleniyor", color = if (snapshot.connected) palette.accent else palette.textSecondary, fontWeight = FontWeight.Bold)
            Text("BT • 13.7 V", color = palette.textSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun EngineTempCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    val tempColor = when {
        snapshot.engineTempC >= 105 -> palette.critical
        snapshot.engineTempC >= 90 -> palette.warning
        else -> palette.accent
    }
    DataCard(
        palette = palette,
        title = "Motor Sıcaklığı",
        value = snapshot.engineTempC.toString(),
        unit = "°C",
        subtitle = "Radyatör fanı: ${if (snapshot.radiatorFanOn) "Açık" else "Kapalı"}",
        accent = tempColor,
        modifier = modifier
    )
}

@Composable
private fun BottomNavigationBar(palette: LoganPalette, current: MainTab, onSelect: (MainTab) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().height(74.dp).background(palette.surface),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        MainTab.entries.forEach { tab ->
            val selected = current == tab
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).clickable { onSelect(tab) }.padding(vertical = 8.dp)
            ) {
                Text(tabIcon(tab), color = if (selected) palette.accent else palette.textSecondary, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(tab.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, textAlign = TextAlign.Center)
            }
        }
    }
}

private fun tabIcon(tab: MainTab): String = when (tab) {
    MainTab.Dashboard -> "⌁"
    MainTab.Trip -> "◎"
    MainTab.Health -> "＋"
    MainTab.History -> "◷"
    MainTab.Settings -> "⚙"
}

@Composable
private fun PlaceholderPage(palette: LoganPalette, title: String, subtitle: String) {
    Column(
        modifier = Modifier.fillMaxSize().background(palette.background).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(10.dp))
        Text(subtitle, color = palette.textSecondary, textAlign = TextAlign.Center, fontSize = 16.sp)
    }
}
