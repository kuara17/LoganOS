package com.dcui.loganos.model

import androidx.compose.ui.graphics.Color

enum class DeviceMode(val label: String) {
    Phone("Telefon"),
    HeadUnit("Android Multimedya / Double")
}

enum class Brand(val label: String) {
    Dacia("Dacia"),
    Renault("Renault")
}

enum class GaugeStyle(val label: String) {
    Digital("Digital"),
    Sport("Sport"),
    ClassicOem("Classic OEM"),
    Minimal("Minimal"),
    RsPerformance("RS Performance")
}

enum class AccentColor(val label: String, val color: Color) {
    OemGreen("OEM Green", Color(0xFF34C759)),
    TechBlue("Tech Blue", Color(0xFF207DFF)),
    SportOrange("Sport Orange", Color(0xFFFF8A00)),
    RsRed("RS Red", Color(0xFFFF3B30)),
    NeoPurple("Neo Purple", Color(0xFF9B5CFF)),
    GoldEdition("Gold Edition", Color(0xFFFFC107))
}

data class LoganSettings(
    val setupCompleted: Boolean = false,
    val brand: Brand = Brand.Dacia,
    val vehicleModel: String = "Dacia Logan",
    val engine: String = "1.5 dCi 48 kW",
    val deviceMode: DeviceMode = DeviceMode.Phone,
    val gaugeStyle: GaugeStyle = GaugeStyle.Digital,
    val accentColor: AccentColor = AccentColor.OemGreen,
    val darkMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val backgroundTripEnabled: Boolean = true,
    val smartTripMinutes: Int = 60,
    val disclaimerAccepted: Boolean = false
)

data class DashboardSnapshot(
    val speedKmh: Int = 92,
    val averageConsumption: Double = 4.6,
    val instantConsumption: Double = 1.2,
    val instantUnit: String = "L/h",
    val tripDistanceKm: Double = 235.4,
    val odometerKm: Int = 123456,
    val engineTempC: Int = 82,
    val radiatorFanOn: Boolean = true,
    val rpm: Int = 2180,
    val acOn: Boolean = true,
    val fuelUsedL: Double = 1.88,
    val tripCostText: String = "Fiyat girilmedi",
    val batteryV: Double = 13.7,
    val connected: Boolean = false
)
