package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedGauge(
    palette: LoganPalette,
    speed: Int,
    style: GaugeStyle,
    modifier: Modifier = Modifier
) {
    when (style) {
        GaugeStyle.Digital -> DigitalGauge(palette, speed, modifier)
        GaugeStyle.Sport -> SportGauge(palette, speed, modifier)
        GaugeStyle.ClassicOem -> ClassicGauge(palette, speed, modifier)
        GaugeStyle.Minimal -> MinimalGauge(palette, speed, modifier)
        GaugeStyle.RsPerformance -> RsGauge(palette, speed, modifier)
    }
}

@Composable
private fun DigitalGauge(palette: LoganPalette, speed: Int, modifier: Modifier) {
    val progress by animateFloatAsState(targetValue = (speed / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "speed")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 12.dp.toPx()
            val pad = stroke / 2 + 6.dp.toPx()
            val sizeArc = Size(size.width - pad * 2, size.height - pad * 2)
            drawArc(
                color = palette.line,
                startAngle = 145f,
                sweepAngle = 250f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = sizeArc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(palette.accent, Color(0xFF47D8FF), palette.accent)),
                startAngle = 145f,
                sweepAngle = 250f * progress,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = sizeArc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }
        SpeedCenter(palette, speed, label = "ECO", labelColor = palette.accent)
    }
}

@Composable
private fun SportGauge(palette: LoganPalette, speed: Int, modifier: Modifier) {
    val progress by animateFloatAsState(targetValue = (speed / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "speedSport")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val pad = stroke / 2 + 4.dp.toPx()
            val sizeArc = Size(size.width - pad * 2, size.height - pad * 2)
            drawArc(
                color = palette.line,
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = sizeArc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(Color(0xFF207DFF), Color(0xFFFF3B30))),
                startAngle = 150f,
                sweepAngle = 240f * progress,
                useCenter = false,
                topLeft = Offset(pad, pad),
                size = sizeArc,
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
            repeat(36) { i ->
                val angle = Math.toRadians((150 + i * 240 / 35.0).toDouble())
                val r1 = size.minDimension / 2 - 24.dp.toPx()
                val r2 = size.minDimension / 2 - 12.dp.toPx()
                val c = Offset(size.width / 2, size.height / 2)
                drawLine(
                    color = palette.muted.copy(alpha = .65f),
                    start = Offset(c.x + cos(angle).toFloat() * r1, c.y + sin(angle).toFloat() * r1),
                    end = Offset(c.x + cos(angle).toFloat() * r2, c.y + sin(angle).toFloat() * r2),
                    strokeWidth = 2f
                )
            }
        }
        SpeedCenter(palette, speed, label = "SPORT", labelColor = Color(0xFFFF3B30))
    }
}

@Composable
private fun ClassicGauge(palette: LoganPalette, speed: Int, modifier: Modifier) {
    val progress by animateFloatAsState(targetValue = (speed / 220f).coerceIn(0f, 1f), animationSpec = tween(450), label = "classic")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 9.dp.toPx()
            val pad = stroke / 2 + 10.dp.toPx()
            val sizeArc = Size(size.width - pad * 2, size.height - pad * 2)
            drawArc(color = palette.line, startAngle = 145f, sweepAngle = 250f, useCenter = false, topLeft = Offset(pad, pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(color = palette.accent, startAngle = 145f, sweepAngle = 250f * progress, useCenter = false, topLeft = Offset(pad, pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        SpeedCenter(palette, speed, label = "CLASSIC", labelColor = palette.accent)
    }
}

@Composable
private fun MinimalGauge(palette: LoganPalette, speed: Int, modifier: Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        SpeedCenter(palette, speed, label = "MINIMAL", labelColor = palette.accent)
    }
}

@Composable
private fun RsGauge(palette: LoganPalette, speed: Int, modifier: Modifier) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val stroke = 14.dp.toPx()
            val pad = stroke / 2 + 6.dp.toPx()
            val sizeArc = Size(size.width - pad * 2, size.height - pad * 2)
            drawArc(color = Color(0xFF2D333B), startAngle = 145f, sweepAngle = 250f, useCenter = false, topLeft = Offset(pad, pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(color = Color(0xFFFF3B30), startAngle = 145f, sweepAngle = 120f, useCenter = false, topLeft = Offset(pad, pad), size = sizeArc, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        SpeedCenter(palette, speed, label = "RS", labelColor = Color(0xFFFF3B30))
    }
}

@Composable
private fun SpeedCenter(palette: LoganPalette, speed: Int, label: String, labelColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(speed.toString(), color = palette.textPrimary, fontSize = 76.sp, fontWeight = FontWeight.Black)
        Text("km/h", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Text(label, color = labelColor, fontSize = 15.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier.height(130.dp)) {
        SpeedGauge(palette, 92, style, modifier = Modifier.weight(1f).fillMaxWidth())
        Text(style.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
