# Changelog

## 1.0.0-beta-starter

- Initial Kotlin/Jetpack Compose project structure
- Added LOGANOS splash screen
- Added first setup wizard
- Added dashboard shell
- Added gauge style models: Digital, Sport, Classic OEM, Minimal, RS Performance
- Added accent color system with OEM Green default
- Added settings shell
- Added GitHub Actions APK workflow
