package com.dcui.loganos.ui.cockpit

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private val OriginalWhite = Color(0xFFF7F9FF)
private val OriginalMuted = Color(0xFFB7C1D0)
private const val GhostSpeedMaxKmh = 200
private const val ConsumptionVisualMax = 15.0

@Composable
fun GhostSingleOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, GhostSpeedMaxKmh)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, settings.tachometerMaxRpm)
    val accent = ghostOriginalAccentColor(settings.ghostOriginalAccent)
    val fuelTrusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    val instantValue = snapshot.instantConsumption.takeIf { fuelTrusted }
    val averageValue = snapshot.averageConsumption.takeIf { fuelTrusted }
    val instant = if (fuelTrusted) formatOne(instantValue) else "--"
    val average = if (fuelTrusted) formatOne(averageValue) else "--"
    val instantUnit = if (fuelTrusted) snapshot.instantUnit else "VERİ BEKLENİYOR"
    val averageUnit = if (fuelTrusted) "L/100 km" else "VERİ BEKLENİYOR"
    val temperature = snapshot.engineTempC
    val tempText = temperature?.let { "$it °C" } ?: "-- °C"
    val tempColor = coolantAccentColor(palette, temperature)
    val vehicleRes = vehicleVisualDrawableRes(
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor,
        style = VehicleAssetStyle.Detailed
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val stageWidth = maxWidth
        val stageHeight = maxHeight
        val clusterWidth = minOf(stageWidth * 0.57f, stageHeight * 1.32f)
        val clusterHeight = clusterWidth * 0.76f
        val panelWidth = minOf(stageWidth * 0.215f, stageHeight * 0.56f)
        val panelHeight = stageHeight * 0.70f

        Image(
            painter = painterResource(R.drawable.ghost_single_original_background),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        CentralReferenceCluster(
            speed = speed,
            rpm = rpm,
            accent = accent,
            horizonRes = ghostOriginalHorizonRes(settings.ghostOriginalAccent),
            vehicleRes = vehicleRes,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = stageHeight * -0.01f)
                .width(clusterWidth)
                .height(clusterHeight)
        )

        // Keep the vignette behind live information so edge labels and icons remain legible.
        Image(
            painter = painterResource(R.drawable.ghost_single_original_vignette),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        LeftInformationPanel(
            temperatureC = temperature,
            temperatureText = tempText,
            temperatureColor = tempColor,
            instantValue = instantValue,
            instantText = instant,
            instantUnit = instantUnit,
            accent = accent,
            onClick = onOpenReset,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = stageWidth * 0.034f, y = stageHeight * 0.018f)
                .width(panelWidth)
                .height(panelHeight)
        )

        RightInformationPanel(
            averageValue = averageValue,
            averageText = average,
            averageUnit = averageUnit,
            accent = accent,
            onClick = onOpenReset,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = stageWidth * -0.034f, y = stageHeight * 0.018f)
                .width(panelWidth)
                .height(panelHeight)
        )

        GhostOriginalText(
            cx = 0.91f,
            cy = 0.065f,
            widthFraction = 0.16f,
            heightFraction = 0.06f,
            text = when {
                snapshot.demo -> "DEMO"
                snapshot.connected -> "OBD BAĞLI"
                else -> "OBD BEKLENİYOR"
            },
            size = scaledSp(stageHeight.value * 0.021f),
            color = if (snapshot.demo || snapshot.connected) accent else OriginalMuted,
            weight = FontWeight.Bold
        )
    }
}

@Composable
private fun CentralReferenceCluster(
    speed: Int,
    rpm: Int,
    accent: Color,
    @DrawableRes horizonRes: Int,
    @DrawableRes vehicleRes: Int,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier) {
        val horizonWidth = maxWidth * 1.25f
        val horizonHeight = horizonWidth * (180f / 1846f)

        // Preserve the horizon asset aspect ratio and anchor it to the road's vanishing area.
        Image(
            painter = painterResource(horizonRes),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = maxHeight * 0.505f)
                .width(horizonWidth)
                .height(horizonHeight)
        )

        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_base),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_sheen),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        // Road boundaries stay asset-white in every accent colour.
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_edges),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        // Both calibrated shadows are behind the vehicle; no post-vehicle black oval is drawn.
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_soft),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_contact),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(maxWidth * 0.165f)
                .height(maxHeight * 0.265f)
                .offset(y = maxHeight * -0.055f)
        )

        GaugeProgressLayer(speedKmh = speed, accent = accent, modifier = Modifier.fillMaxSize())
        Image(
            painter = painterResource(R.drawable.ghost_single_original_gauge_shell),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        GaugeNeedleLayer(speedKmh = speed, accent = accent, modifier = Modifier.fillMaxSize())
        CenterReadoutShield(modifier = Modifier.fillMaxSize())

        ClusterText(
            cx = 0.50f,
            cy = 0.315f,
            widthFraction = 0.26f,
            heightFraction = 0.12f,
            text = speed.toString(),
            size = scaledSp(maxHeight.value * 0.098f),
            color = OriginalWhite,
            weight = FontWeight.Light
        )
        ClusterText(
            cx = 0.50f,
            cy = 0.382f,
            widthFraction = 0.18f,
            heightFraction = 0.05f,
            text = "km/h",
            size = scaledSp(maxHeight.value * 0.026f),
            color = OriginalMuted,
            weight = FontWeight.Medium
        )
        ClusterText(
            cx = 0.50f,
            cy = 0.478f,
            widthFraction = 0.30f,
            heightFraction = 0.06f,
            text = "$rpm rpm",
            size = scaledSp(maxHeight.value * 0.033f),
            color = OriginalWhite.copy(alpha = 0.88f),
            weight = FontWeight.Medium
        )
    }
}

@Composable
private fun GaugeProgressLayer(speedKmh: Int, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val scaleX = size.width / 1000f
        val scaleY = size.height / 760f
        val left = (500f - 350f) * scaleX
        val top = (390f - 350f) * scaleY
        val arcSize = Size(700f * scaleX, 700f * scaleY)
        val sweep = 210f * (speedKmh.coerceIn(0, GhostSpeedMaxKmh) / GhostSpeedMaxKmh.toFloat())
        if (sweep <= 0f) return@Canvas
        drawArc(
            color = accent.copy(alpha = 0.12f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = 6f * scaleX, cap = StrokeCap.Butt)
        )
        drawArc(
            color = accent.copy(alpha = 0.72f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = 2.4f * scaleX, cap = StrokeCap.Butt)
        )
    }
}

@Composable
private fun GaugeNeedleLayer(speedKmh: Int, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val ratio = speedKmh.coerceIn(0, GhostSpeedMaxKmh) / GhostSpeedMaxKmh.toFloat()
        val angle = Math.toRadians((165f + 210f * ratio).toDouble())
        val center = Offset(size.width * 0.50f, size.height * 0.513f)
        val direction = Offset(cos(angle).toFloat(), sin(angle).toFloat())
        val tip = Offset(
            center.x + direction.x * size.width * 0.285f,
            center.y + direction.y * size.width * 0.285f
        )
        val tail = Offset(
            center.x - direction.x * size.width * 0.014f,
            center.y - direction.y * size.width * 0.014f
        )
        drawLine(
            color = OriginalWhite.copy(alpha = 0.86f),
            start = tail,
            end = tip,
            strokeWidth = size.width * 0.0034f,
            cap = StrokeCap.Round
        )
        drawLine(
            color = accent.copy(alpha = 0.72f),
            start = center,
            end = tip,
            strokeWidth = size.width * 0.0017f,
            cap = StrokeCap.Round
        )
        drawCircle(Color.Black.copy(alpha = 0.82f), size.width * 0.012f, center)
        drawCircle(OriginalWhite.copy(alpha = 0.94f), size.width * 0.0048f, center)
    }
}

@Composable
private fun CenterReadoutShield(modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        drawOval(
            color = Color.Black.copy(alpha = 0.09f),
            topLeft = Offset(size.width * 0.375f, size.height * 0.185f),
            size = Size(size.width * 0.25f, size.height * 0.345f)
        )
        drawOval(
            color = Color.Black.copy(alpha = 0.22f),
            topLeft = Offset(size.width * 0.405f, size.height * 0.215f),
            size = Size(size.width * 0.19f, size.height * 0.285f)
        )
    }
}

@Composable
private fun LeftInformationPanel(
    temperatureC: Int?,
    temperatureText: String,
    temperatureColor: Color,
    instantValue: Double?,
    instantText: String,
    instantUnit: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.clickable(onClick = onClick)) {
        val temperatureProgress = temperatureC?.let { ((it - 40f) / 80f).coerceIn(0f, 1f) } ?: 0f
        val instantProgress = instantValue
            ?.takeIf { !it.isNaN() && !it.isInfinite() }
            ?.let { (it / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f) }
            ?: 0f

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawLine(
                color = OriginalMuted.copy(alpha = 0.16f),
                start = Offset(size.width * 0.08f, size.height * 0.49f),
                end = Offset(size.width * 0.92f, size.height * 0.49f),
                strokeWidth = size.height * 0.002f
            )
            val tempX = size.width * 0.17f
            val tempTop = size.height * 0.10f
            val tempBottom = size.height * 0.41f
            val tempEnd = tempBottom - (tempBottom - tempTop) * temperatureProgress
            drawLine(
                OriginalMuted.copy(alpha = 0.22f),
                Offset(tempX, tempTop),
                Offset(tempX, tempBottom),
                size.width * 0.035f,
                StrokeCap.Round
            )
            drawLine(
                temperatureColor.copy(alpha = 0.96f),
                Offset(tempX, tempBottom),
                Offset(tempX, tempEnd),
                size.width * 0.017f,
                StrokeCap.Round
            )
            for (i in 0..4) {
                val y = tempTop + (tempBottom - tempTop) * i / 4f
                drawLine(
                    OriginalMuted.copy(alpha = 0.38f),
                    Offset(tempX + size.width * 0.035f, y),
                    Offset(tempX + size.width * 0.070f, y),
                    size.height * 0.002f
                )
            }
            val barX1 = size.width * 0.18f
            val barX2 = size.width * 0.82f
            val barY = size.height * 0.91f
            val barEnd = barX1 + (barX2 - barX1) * instantProgress
            drawLine(
                OriginalMuted.copy(alpha = 0.20f),
                Offset(barX1, barY),
                Offset(barX2, barY),
                size.height * 0.018f,
                StrokeCap.Round
            )
            if (instantValue != null) {
                drawLine(
                    accent.copy(alpha = 0.94f),
                    Offset(barX1, barY),
                    Offset(barEnd, barY),
                    size.height * 0.008f,
                    StrokeCap.Round
                )
            }
        }

        PanelIcon(R.drawable.cockpit_coolant, cx = 0.32f, cy = 0.16f, widthFraction = 0.16f, heightFraction = 0.16f)
        PanelText(0.63f, 0.16f, 0.44f, 0.08f, "HARARET", scaledSp(maxHeight.value * 0.040f), OriginalMuted, FontWeight.Bold)
        PanelText(0.65f, 0.285f, 0.56f, 0.14f, temperatureText, scaledSp(maxHeight.value * 0.075f), temperatureColor, FontWeight.SemiBold)
        PanelText(0.105f, 0.10f, 0.14f, 0.05f, "120", scaledSp(maxHeight.value * 0.025f), OriginalMuted.copy(alpha = 0.72f), FontWeight.Medium)
        PanelText(0.105f, 0.41f, 0.14f, 0.05f, "40", scaledSp(maxHeight.value * 0.025f), OriginalMuted.copy(alpha = 0.72f), FontWeight.Medium)

        PanelIcon(R.drawable.cockpit_fuel_instant, cx = 0.27f, cy = 0.60f, widthFraction = 0.17f, heightFraction = 0.17f)
        PanelText(0.56f, 0.60f, 0.38f, 0.08f, "ANLIK", scaledSp(maxHeight.value * 0.042f), OriginalMuted, FontWeight.Bold)
        PanelText(0.50f, 0.735f, 0.76f, 0.16f, instantText, scaledSp(maxHeight.value * 0.092f), OriginalWhite, FontWeight.Medium)
        PanelText(0.50f, 0.835f, 0.84f, 0.08f, instantUnit, scaledSp(maxHeight.value * 0.034f), OriginalMuted, FontWeight.Medium)
    }
}

@Composable
private fun RightInformationPanel(
    averageValue: Double?,
    averageText: String,
    averageUnit: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.clickable(onClick = onClick)) {
        val progress = averageValue
            ?.takeIf { !it.isNaN() && !it.isInfinite() }
            ?.let { (it / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f) }
            ?: 0f

        Canvas(modifier = Modifier.fillMaxSize()) {
            drawLine(
                OriginalMuted.copy(alpha = 0.16f),
                Offset(size.width * 0.08f, size.height * 0.69f),
                Offset(size.width * 0.92f, size.height * 0.69f),
                size.height * 0.002f
            )
            val gaugeX = size.width * 0.86f
            val gaugeTop = size.height * 0.16f
            val gaugeBottom = size.height * 0.82f
            val gaugeEnd = gaugeBottom - (gaugeBottom - gaugeTop) * progress
            drawLine(
                OriginalMuted.copy(alpha = 0.22f),
                Offset(gaugeX, gaugeTop),
                Offset(gaugeX, gaugeBottom),
                size.width * 0.035f,
                StrokeCap.Round
            )
            if (averageValue != null) {
                drawLine(
                    accent.copy(alpha = 0.96f),
                    Offset(gaugeX, gaugeBottom),
                    Offset(gaugeX, gaugeEnd),
                    size.width * 0.017f,
                    StrokeCap.Round
                )
            }
            for (i in 0..5) {
                val y = gaugeTop + (gaugeBottom - gaugeTop) * i / 5f
                drawLine(
                    OriginalMuted.copy(alpha = 0.38f),
                    Offset(gaugeX - size.width * 0.070f, y),
                    Offset(gaugeX - size.width * 0.035f, y),
                    size.height * 0.002f
                )
            }
        }

        PanelIcon(R.drawable.cockpit_fuel_average, cx = 0.22f, cy = 0.25f, widthFraction = 0.17f, heightFraction = 0.17f)
        PanelText(0.58f, 0.25f, 0.44f, 0.08f, "ORTALAMA", scaledSp(maxHeight.value * 0.043f), OriginalMuted, FontWeight.Bold)
        PanelText(0.47f, 0.47f, 0.72f, 0.22f, averageText, scaledSp(maxHeight.value * 0.116f), OriginalWhite, FontWeight.Medium)
        PanelText(0.47f, 0.61f, 0.78f, 0.08f, averageUnit, scaledSp(maxHeight.value * 0.036f), OriginalMuted, FontWeight.Medium)
        PanelText(0.73f, 0.16f, 0.12f, 0.05f, "15", scaledSp(maxHeight.value * 0.025f), OriginalMuted.copy(alpha = 0.72f), FontWeight.Medium)
        PanelText(0.73f, 0.82f, 0.12f, 0.05f, "0", scaledSp(maxHeight.value * 0.025f), OriginalMuted.copy(alpha = 0.72f), FontWeight.Medium)
    }
}

@Composable
private fun BoxWithConstraintsScope.PanelIcon(
    @DrawableRes iconRes: Int,
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float
) {
    Image(
        painter = painterResource(iconRes),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction)
    )
}

@Composable
private fun BoxWithConstraintsScope.ClusterText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) = PositionedText(cx, cy, widthFraction, heightFraction, text, size, color, weight)

@Composable
private fun BoxWithConstraintsScope.PanelText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) = PositionedText(cx, cy, widthFraction, heightFraction, text, size, color, weight)

@Composable
private fun BoxWithConstraintsScope.GhostOriginalText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) = PositionedText(cx, cy, widthFraction, heightFraction, text, size, color, weight)

@Composable
private fun BoxWithConstraintsScope.PositionedText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

private fun scaledSp(value: Float): TextUnit = max(9f, value).sp
private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun ghostOriginalAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFF9B5CFF)
    GhostOriginalAccent.Red -> Color(0xFFFF3B30)
    GhostOriginalAccent.Green -> Color(0xFF2EE66B)
    GhostOriginalAccent.White -> Color(0xFFF1F5FF)
    GhostOriginalAccent.Blue -> Color(0xFF3595FF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFC12E)
}

@DrawableRes
private fun ghostOriginalHorizonRes(accent: GhostOriginalAccent): Int = when (accent) {
    GhostOriginalAccent.Purple -> R.drawable.ghost_single_original_horizon_purple
    GhostOriginalAccent.Red -> R.drawable.ghost_single_original_horizon_red
    GhostOriginalAccent.Green -> R.drawable.ghost_single_original_horizon_green
    GhostOriginalAccent.White -> R.drawable.ghost_single_original_horizon_white
    GhostOriginalAccent.Blue -> R.drawable.ghost_single_original_horizon_blue
    GhostOriginalAccent.Yellow -> R.drawable.ghost_single_original_horizon_yellow
}
