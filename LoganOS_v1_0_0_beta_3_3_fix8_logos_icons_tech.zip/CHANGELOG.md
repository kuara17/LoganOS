## v1.0.0-beta.3.3-fix8 - Logos, Tech Tab, Gauge Balance

- Kurulum marka ekranında Dacia ve Renault logo çizimleri marka formuna göre yeniden düzenlendi.
- Teknik sekmeden tekrar eden OBD bağlantı paneli kaldırıldı.
- OBD bağlantı yönetimi sadece Ayarlar > Bağlantı & Veri altında toplandı.
- Teknik sekme canlı ECU/decoder verileri, protokol, loop ve ham cevap ekranı olarak sadeleştirildi.
- Hız kadranı açık temada daha okunur olacak şekilde yeniden oranlandı.
- Kokpit ikonları kart içinde daha büyük ve okunur çizilecek şekilde büyütüldü.

## v1.0.0-beta.3.3-fix8 - Brand Logos

- Kurulum marka ekranında Dacia kartı için uygulamanın mevcut DC/LoganOS amblemi kullanıldı.
- Renault için LoganOS tasarım diline uygun özgün çift şeritli baklava logo eklendi.
- Marka kartı logo/yazı hizası güncel düzen üzerinde korundu.

## v1.0.0-beta.3.3-fix8 - AC Fast Loop + Settings Polish

- 21CC_FAST klima/fan için ana kaynak yapıldı.
- Klima kapatmada gecikme azaltıldı: false durumu 21CC_FAST ile hemen UI snapshotına yazılır.
- 21A2 ve 21CD ağır teknik paketleri seyrekleştirildi.
- Döngü beklemeleri kısaltıldı; loga AC_FAST / FAN_FAST olay satırları eklendi.
- Dikey Ayarlar ekranında dar sol menü biraz genişletildi, ikonlar büyütüldü.
- Ayarlar içerik kartında başlık/alt açıklama düzeni ve satır görünümü daha premium hale getirildi.
- Önceki fix4 ikon renk paketi korunur.
