# Contributing to LoganOS

Thank you for considering a contribution.

Please keep the project principles in mind:

- Free and open source
- No ads or tracking
- Privacy-first
- OEM-style, driver-safe UI
- No definitive fault diagnosis language

Recommended wording for health checks:

- Normal görünüyor
- Takip edilmesi önerilir
- Kontrol önerilir
- Beklenenden farklı davranış gözlendi

Avoid definitive statements such as "this part is broken" unless backed by a verified diagnostic code and still phrased carefully.
