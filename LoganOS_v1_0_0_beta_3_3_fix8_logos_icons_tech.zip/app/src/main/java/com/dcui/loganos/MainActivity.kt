package com.dcui.loganos

import android.Manifest
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdController
import com.dcui.loganos.ui.screens.LoganAppShell
import com.dcui.loganos.ui.screens.SetupWizard
import com.dcui.loganos.ui.screens.SplashScreen
import com.dcui.loganos.ui.theme.LoganOSTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = AppPrefs(this)
        requestBluetoothPermissions()

        setContent {
            var settings by remember { mutableStateOf(prefs.load()) }
            var showSplash by remember { mutableStateOf(true) }
            var demoTick by remember { mutableIntStateOf(0) }
            val obdController = remember { ObdController(this) }
            val obdState = obdController.state
            val dark = settings.darkMode

            fun persist(updated: LoganSettings) {
                settings = updated
                prefs.save(updated)
            }

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(settings.deviceMode, settings.setupCompleted) {
                requestedOrientation = if (settings.setupCompleted && settings.deviceMode == DeviceMode.HeadUnit) {
                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            LaunchedEffect(Unit) {
                delay(1700)
                showSplash = false
            }

            LaunchedEffect(settings.demoMode) {
                while (settings.demoMode) {
                    delay(800)
                    demoTick++
                }
            }

            val liveSnapshot = when {
                settings.demoMode -> DashboardSnapshot.demoLive(demoTick)
                obdState.connected -> obdState.snapshot
                else -> DashboardSnapshot.empty()
            }

            LoganOSTheme(accentColor = settings.accentColor, darkTheme = dark) { palette ->
                when {
                    showSplash -> SplashScreen(palette)
                    !settings.setupCompleted -> SetupWizard(
                        palette = palette,
                        initial = settings,
                        onComplete = { updated -> persist(updated) }
                    )
                    else -> LoganAppShell(
                        palette = palette,
                        settings = settings,
                        snapshot = liveSnapshot,
                        obdState = obdState,
                        onSettingsChange = { updated -> persist(updated) },
                        onResetSetup = {
                            prefs.resetSetup()
                            settings = LoganSettings()
                            showSplash = true
                        },
                        onRefreshObdDevices = { obdController.refreshPairedDevices() },
                        onSelectObdDevice = { obdController.selectDevice(it) },
                        onConnectObd = { obdController.connectSelected() },
                        onDisconnectObd = { obdController.disconnect() },
                        onSaveObdLog = {
                            obdController.saveLogFile()
                            Toast.makeText(this, "Log oluşturuldu", Toast.LENGTH_SHORT).show()
                        },
                        onShareObdLog = { obdController.shareLogText() },
                        onClearLastObdLog = {
                            obdController.clearLastLogFile()
                            Toast.makeText(this, "Son log işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        },
                        onClearAllObdLogs = {
                            obdController.clearAllLogFiles()
                            Toast.makeText(this, "Log temizleme işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    private fun requestBluetoothPermissions() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions, 1203)
    }
}
