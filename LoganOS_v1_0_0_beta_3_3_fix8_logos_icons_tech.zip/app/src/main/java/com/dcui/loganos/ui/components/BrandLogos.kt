package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(108.dp, 48.dp)) {
            val w = size.width
            val h = size.height
            val stroke = h * .18f
            val top = h * .32f
            val bottom = h * .68f
            val left = w * .10f
            val right = w * .90f
            val gapL = w * .43f
            val gapR = w * .57f

            // Dacia 2021 resmi amblem formu: yatay DC monogram + merkez kilit.
            drawLine(c, Offset(left, top), Offset(gapL, top), strokeWidth = stroke)
            drawLine(c, Offset(gapR, top), Offset(right, top), strokeWidth = stroke)
            drawLine(c, Offset(left, bottom), Offset(gapL, bottom), strokeWidth = stroke)
            drawLine(c, Offset(gapR, bottom), Offset(right, bottom), strokeWidth = stroke)

            val center = Path().apply {
                moveTo(w * .50f, h * .35f)
                lineTo(w * .59f, h * .50f)
                lineTo(w * .50f, h * .65f)
                lineTo(w * .41f, h * .50f)
                close()
            }
            drawPath(center, color = c, style = Fill)
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "DACIA",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 3.0.sp
        )
    }
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(52.dp, 62.dp)) {
            val w = size.width
            val h = size.height
            val outer = Path().apply {
                moveTo(w * .50f, h * .04f)
                lineTo(w * .86f, h * .50f)
                lineTo(w * .50f, h * .96f)
                lineTo(w * .14f, h * .50f)
                close()
            }
            val inner = Path().apply {
                moveTo(w * .50f, h * .24f)
                lineTo(w * .68f, h * .50f)
                lineTo(w * .50f, h * .76f)
                lineTo(w * .32f, h * .50f)
                close()
            }
            // Renault 2021 baklava formuna yakın, tek renk clean vector.
            drawPath(outer, color = c, style = Stroke(width = w * .095f))
            drawPath(inner, color = c, style = Stroke(width = w * .075f))
        }
        Spacer(Modifier.height(4.dp))
        Text(
            "RENAULT",
            color = c,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.7.sp
        )
    }
}
