package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun LoganWordmark(palette: LoganPalette, modifier: Modifier = Modifier, compact: Boolean = false) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        LoganMark(palette = palette, modifier = Modifier.size(if (compact) 28.dp else 44.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = palette.textPrimary)) { append("LOGAN") }
                withStyle(SpanStyle(color = palette.accent)) { append("OS") }
            },
            fontSize = if (compact) 20.sp else 34.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.5.sp
        )
    }
}

@Composable
fun LoganMark(palette: LoganPalette, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val metal = Brush.linearGradient(
            colors = listOf(Color(0xFFFFFFFF), Color(0xFFAEB4BA), Color(0xFFECEFF2)),
            start = Offset(0f, 0f),
            end = Offset(w, h)
        )
        val top = Path().apply {
            moveTo(w * .08f, h * .34f)
            lineTo(w * .42f, h * .34f)
            lineTo(w * .50f, h * .43f)
            lineTo(w * .58f, h * .34f)
            lineTo(w * .92f, h * .34f)
            lineTo(w * .75f, h * .53f)
            lineTo(w * .58f, h * .53f)
            lineTo(w * .50f, h * .44f)
            lineTo(w * .42f, h * .53f)
            lineTo(w * .25f, h * .53f)
            close()
        }
        val bottom = Path().apply {
            moveTo(w * .10f, h * .62f)
            lineTo(w * .42f, h * .62f)
            lineTo(w * .50f, h * .53f)
            lineTo(w * .58f, h * .62f)
            lineTo(w * .90f, h * .62f)
            lineTo(w * .74f, h * .76f)
            lineTo(w * .58f, h * .76f)
            lineTo(w * .50f, h * .67f)
            lineTo(w * .42f, h * .76f)
            lineTo(w * .26f, h * .76f)
            close()
        }
        drawPath(top, brush = metal)
        drawPath(bottom, brush = metal)
        val tri = Path().apply {
            moveTo(w * .50f, h * .57f)
            lineTo(w * .61f, h * .74f)
            lineTo(w * .39f, h * .74f)
            close()
        }
        drawPath(tri, color = palette.accent)
    }
}

@Composable
fun Slogan(palette: LoganPalette, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Know Your Car.", color = palette.textSecondary, fontSize = 16.sp)
        Text("Drive Smarter.", color = palette.accent, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
fun HeaderLine(palette: LoganPalette, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier.height(1.dp)) {
        drawLine(
            brush = Brush.horizontalGradient(listOf(Color.Transparent, palette.accent, Color.Transparent)),
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            strokeWidth = 2f,
            cap = StrokeCap.Round
        )
    }
}
