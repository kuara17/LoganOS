# LoganOS beta starter - no custom proguard rules yet.
