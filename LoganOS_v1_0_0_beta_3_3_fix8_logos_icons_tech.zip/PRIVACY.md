# LoganOS Privacy Policy

LoganOS is designed as a privacy-first, offline-capable open-source project.

## Data storage

LoganOS stores driving history, maintenance records, settings, and diagnostics locally on the device.

## Network usage

LoganOS does not require an internet connection for core functionality.

## Ads and tracking

LoganOS does not include ads, analytics tracking, or user profiling.

## GPS

GPS route recording is optional. If disabled, LoganOS does not record location routes.

## Support package

A support package may include application logs, device model, Android version, LoganOS version, OBD connection status, and recent error logs. GPS routes and raw OBD logs are not included by default.

## Disclaimer

LoganOS is an independent project and is not an official Renault, Dacia, or vehicle manufacturer application.
