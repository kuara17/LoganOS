# LoganOS Beta 1.0.0 Implementation Notes

This starter is the first Kotlin/Compose foundation. It intentionally avoids implementing live OBD communication until the UI foundation is confirmed.

## Module order

1. Compose UI foundation
2. Room/SQLite database
3. Foreground OBD service
4. Bluetooth adapter selection
5. KWP Fast Init
6. Fuel Truth Kotlin port
7. Smart Trip persistence
8. Technical screen and developer mode

## Core engineering rules

- OBD connection must be independent from UI state.
- Foreground Service will keep OBD alive while app is in background.
- Trip state must be persisted frequently.
- Fuel price at trip start must be stored with each trip.
- Odometer sync must be user-adjustable.
- Fan/AC events must be logged to trip events.
- Dashboard must avoid distracting full-screen popups while driving.
