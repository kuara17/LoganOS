package com.dcui.loganos.ui.cockpit.opengl

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs
import kotlin.math.hypot

class DigitalV2SceneModelTest {
    private val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    @Test
    fun calibratedRoadsNarrowMonotonicallyAndKeepOrdering() {
        scenes.forEach { scene ->
            var previousY = Float.POSITIVE_INFINITY
            var previousWidth = Float.POSITIVE_INFINITY
            var distance = 0f
            while (distance <= scene.road.maxDistanceMeters) {
                val left = scene.road.leftRoadEdge.sample(distance)
                val center = scene.road.centerLine.sample(distance)
                val right = scene.road.rightRoadEdge.sample(distance)
                val width = hypot(
                    (right.x - left.x) * DIGITAL_V2_LOGICAL_WIDTH,
                    (right.y - left.y) * DIGITAL_V2_LOGICAL_HEIGHT
                )
                assertTrue("${scene.key}: y reversed at ${distance}m", distance == 0f || center.y < previousY)
                assertTrue("${scene.key}: left/center order", left.x < center.x)
                assertTrue("${scene.key}: center/right order", center.x < right.x)
                assertTrue("${scene.key}: width regrew at ${distance}m", distance == 0f || width <= previousWidth + 1.5f)
                previousY = center.y
                previousWidth = width
                distance += 0.5f
            }
        }
    }

    @Test
    fun mountainLakeMatchesMeasuredPhotoReferences() {
        val road = DigitalV2SceneModels.MountainLake.road
        val refs = listOf(
            Triple(14f, 0.015f, 0.990f),
            Triple(24f, 0.105f, 0.965f),
            Triple(38f, 0.245f, 0.900f),
            Triple(56f, 0.365f, 0.820f),
            Triple(78f, 0.475f, 0.755f),
            Triple(100f, 0.565f, 0.710f)
        )
        refs.forEach { (distance, expectedLeft, expectedRight) ->
            assertEquals(expectedLeft, road.leftRoadEdge.sample(distance).x, 0.012f)
            assertEquals(expectedRight, road.rightRoadEdge.sample(distance).x, 0.012f)
        }
        val widthAt56 = road.rightRoadEdge.sample(56f).x - road.leftRoadEdge.sample(56f).x
        assertTrue("middle-distance road must not use old narrow corridor", widthAt56 >= 0.43f)
    }

    @Test
    fun calibratedMeshesAreFiniteAndForwardMonotonic() {
        scenes.forEach { scene ->
            val meshes = listOf(
                buildCalibratedLineMesh(scene.road, RoadCurveRole.CenterLine, scene.road.markings.centerLineWidthMeters),
                buildCalibratedLineMesh(scene.road, RoadCurveRole.LeftEdge, scene.road.markings.edgeLineWidthMeters),
                buildCalibratedLineMesh(scene.road, RoadCurveRole.RightEdge, scene.road.markings.edgeLineWidthMeters),
                buildCalibratedRoadSurfaceMesh(scene.road)
            )
            meshes.forEach { mesh ->
                assertTrue(mesh.vertices.all { it.isFinite() })
                var previousDistance = -1f
                for (index in 0 until mesh.vertexCount step 2) {
                    val left = index * 4
                    val right = (index + 1) * 4
                    assertEquals(mesh.vertices[left + 2], mesh.vertices[right + 2], 0.0001f)
                    assertTrue(mesh.vertices[left + 2] >= previousDistance)
                    previousDistance = mesh.vertices[left + 2]
                }
            }
        }
    }

    @Test
    fun viewportPreservesLogicalAspectWithoutStretching() {
        listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
            val viewport = calculateDigitalV2Viewport(width, height)
            val aspect = viewport.width.toFloat() / viewport.height.toFloat()
            assertEquals(DIGITAL_V2_STAGE_ASPECT_RATIO, aspect, 0.005f)
            assertTrue(viewport.x >= 0 && viewport.y >= 0)
            assertTrue(viewport.x + viewport.width <= width)
            assertTrue(viewport.y + viewport.height <= height)
        }
    }

    @Test
    fun roadPatternAndPhaseRemainStable() {
        scenes.forEach { scene ->
            assertEquals(3f, scene.road.markings.dashLengthMeters, 0.0001f)
            assertEquals(6f, scene.road.markings.gapLengthMeters, 0.0001f)
            assertEquals(9f, scene.road.markings.repeatLengthMeters, 0.0001f)
        }
        val before = roadPatternPhaseMeters(9_999.99, 9f)
        val after = roadPatternPhaseMeters(10_000.01, 9f)
        val delta = positiveModulo((after - before).toDouble(), 9.0)
        assertEquals(0.02, delta, 0.0005)
    }

    @Test
    fun stoppedStateClearsSmoothedSpeed() {
        val stopped = nextDigitalV2SmoothedSpeedKmh(108f, 0f, 0.016f)
        assertEquals(0f, stopped, 0f)
        val restart = nextDigitalV2SmoothedSpeedKmh(stopped, 8f, 0.016f)
        assertTrue(restart in 0f..2f)
    }
}
