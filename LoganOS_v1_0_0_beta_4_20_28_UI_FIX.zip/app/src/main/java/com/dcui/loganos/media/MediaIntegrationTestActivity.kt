package com.dcui.loganos.media

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.dcui.loganos.BuildConfig
import kotlinx.coroutines.delay

private const val JANCAR_MUSIC = "com.jancar.music"
private const val JANCAR_RADIO = "com.jancar.radio"
private const val AIMP = "com.aimp.player"

private data class MediaSnapshot(
    val notificationAccess: Boolean,
    val installedJancarMusic: Boolean,
    val installedJancarRadio: Boolean,
    val installedAimp: Boolean,
    val sessionCount: Int,
    val packageName: String?,
    val title: String?,
    val artist: String?,
    val album: String?,
    val durationMs: Long,
    val positionMs: Long,
    val playbackState: Int?,
    val controller: MediaController?,
    val error: String?
)

class MediaIntegrationTestActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    MediaIntegrationTestScreen(this)
                }
            }
        }
    }
}

@Composable
private fun MediaIntegrationTestScreen(context: Context) {
    var snapshot by remember { mutableStateOf(readSnapshot(context)) }

    LaunchedEffect(Unit) {
        while (true) {
            snapshot = readSnapshot(context)
            delay(1_000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("LoganOS Medya Entegrasyon Testi", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("${BuildConfig.VERSION_NAME} — AIMP / Premium Drive altyapısı")

        StatusCard("Bildirim erişimi", if (snapshot.notificationAccess) "AÇIK" else "KAPALI")
        StatusCard("Jancar Music", if (snapshot.installedJancarMusic) "YÜKLÜ" else "BULUNAMADI")
        StatusCard("Jancar Radio", if (snapshot.installedJancarRadio) "YÜKLÜ" else "BULUNAMADI")
        StatusCard("AIMP", if (snapshot.installedAimp) "YÜKLÜ" else "BULUNAMADI")
        StatusCard("Görülen aktif MediaSession", snapshot.sessionCount.toString())

        if (!snapshot.notificationAccess) {
            Button(onClick = {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) {
                Text("Bildirim erişimini aç")
            }
        }

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Aktif medya", fontWeight = FontWeight.Bold)
                Text("Paket: ${snapshot.packageName ?: "—"}")
                Text("Şarkı: ${snapshot.title ?: "—"}")
                Text("Sanatçı: ${snapshot.artist ?: "—"}")
                Text("Albüm: ${snapshot.album ?: "—"}")
                Text("Durum: ${playbackStateLabel(snapshot.playbackState)}")
                Text("Konum: ${formatDuration(snapshot.positionMs)} / ${formatDuration(snapshot.durationMs)}")
                snapshot.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)?.let { bitmap ->
                    Spacer(Modifier.height(4.dp))
                    Image(bitmap.asImageBitmap(), contentDescription = "Albüm kapağı", modifier = Modifier.size(140.dp))
                }
                snapshot.error?.let { Text("Teknik not: $it") }
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(modifier = Modifier.weight(1f), onClick = { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS) }) { Text("Önceki") }
            Button(modifier = Modifier.weight(1f), onClick = { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }) { Text("Oynat / Duraklat") }
            OutlinedButton(modifier = Modifier.weight(1f), onClick = { sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT) }) { Text("Sonraki") }
        }

        Button(modifier = Modifier.fillMaxWidth(), onClick = {
            context.startActivity(Intent(context, PremiumDriveActivity::class.java))
        }) {
            Text("Premium Drive önizlemesini aç")
        }

        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = snapshot.installedJancarMusic, onClick = { launchPackage(context, JANCAR_MUSIC) }) {
            Text("Jancar Music'i aç")
        }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = snapshot.installedAimp, onClick = { launchPackage(context, AIMP) }) {
            Text("AIMP'i aç")
        }
        OutlinedButton(modifier = Modifier.fillMaxWidth(), enabled = snapshot.installedJancarRadio, onClick = { launchPackage(context, JANCAR_RADIO) }) {
            Text("Radyoyu aç")
        }

        Text(
            "Not: Bu sürüm firmware'i değiştirmez. Radyo düğmesi yalnız mevcut uygulamayı güvenli biçimde açar. " +
                "Canlı frekans kontrolü sonraki aşamada ele alınacaktır.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun StatusCard(label: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label)
            Text(value, fontWeight = FontWeight.Bold)
        }
    }
}

private fun readSnapshot(context: Context): MediaSnapshot {
    val listener = ComponentName(context, LoganMediaNotificationListener::class.java)
    val notificationManager = context.getSystemService(NotificationManager::class.java)
    val access = notificationManager?.isNotificationListenerAccessGranted(listener) == true
    val manager = context.getSystemService(MediaSessionManager::class.java)
    var error: String? = null
    val controllers = if (access) {
        runCatching { manager?.getActiveSessions(listener).orEmpty() }
            .onFailure { error = "MediaSession okunamadı: ${it.javaClass.simpleName}" }
            .getOrDefault(emptyList())
    } else emptyList()

    val preferred = controllers.sortedBy { controller ->
        when {
            controller.packageName == AIMP -> 0
            !controller.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).isNullOrBlank() -> 1
            controller.packageName == JANCAR_MUSIC -> 2
            else -> 3
        }
    }.firstOrNull()

    val metadata = preferred?.metadata
    val playback = preferred?.playbackState
    return MediaSnapshot(
        notificationAccess = access,
        installedJancarMusic = isInstalled(context, JANCAR_MUSIC),
        installedJancarRadio = isInstalled(context, JANCAR_RADIO),
        installedAimp = isInstalled(context, AIMP),
        sessionCount = controllers.size,
        packageName = preferred?.packageName,
        title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE),
        artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST),
        album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM),
        durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
        positionMs = playback?.position ?: 0L,
        playbackState = playback?.state,
        controller = preferred,
        error = error
    )
}

private fun isInstalled(context: Context, packageName: String): Boolean =
    runCatching { context.packageManager.getPackageInfo(packageName, 0); true }.getOrDefault(false)

private fun launchPackage(context: Context, packageName: String) {
    context.packageManager.getLaunchIntentForPackage(packageName)?.let {
        context.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}

private fun sendMediaKey(context: Context, keyCode: Int) {
    val audioManager = context.getSystemService(AudioManager::class.java) ?: return
    audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
    audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
}

private fun playbackStateLabel(state: Int?): String = when (state) {
    android.media.session.PlaybackState.STATE_PLAYING -> "Oynatılıyor"
    android.media.session.PlaybackState.STATE_PAUSED -> "Duraklatıldı"
    android.media.session.PlaybackState.STATE_BUFFERING -> "Yükleniyor"
    android.media.session.PlaybackState.STATE_STOPPED -> "Durduruldu"
    null -> "Session yok"
    else -> "Kod $state"
}

private fun formatDuration(valueMs: Long): String {
    val safe = valueMs.coerceAtLeast(0L) / 1_000L
    return "%d:%02d".format(safe / 60, safe % 60)
}
