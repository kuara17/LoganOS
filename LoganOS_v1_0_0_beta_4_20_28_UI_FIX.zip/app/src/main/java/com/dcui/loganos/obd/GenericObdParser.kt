package com.dcui.loganos.obd

import java.util.Locale

/**
 * Read-only SAE-style Mode 01 parser used by the experimental petrol profile.
 * It intentionally does not derive fuel consumption from MAF. The values below
 * are captured only as diagnostic candidates until a direct injection/fuel-rate
 * source is verified for a concrete engine/ECU profile.
 */
data class GenericObdReading(
    val rpm: Int? = null,
    val speedKmh: Int? = null,
    val coolantC: Int? = null,
    val mapMbar: Int? = null,
    val intakeTempC: Double? = null,
    val throttlePercent: Double? = null,
    val calculatedLoadPercent: Double? = null,
    val mafGramsPerSec: Double? = null,
    val shortFuelTrimPercent: Double? = null,
    val longFuelTrimPercent: Double? = null,
    val commandedEquivalenceRatio: Double? = null,
    val engineFuelRateLh: Double? = null,
    val fuelSystemStatus: String? = null,
    val rawJoined: String = ""
)

object GenericObdParser {
    fun parse(responses: Map<String, String>): GenericObdReading {
        fun payload(pid: Int): List<Int>? = responses["01%02X".format(Locale.US, pid)]?.let { extractPayload(it, pid) }

        val rpm = payload(0x0C)?.takeIf { it.size >= 2 }?.let { ((it[0] shl 8) or it[1]) / 4 }
        val speed = payload(0x0D)?.firstOrNull()
        val coolant = payload(0x05)?.firstOrNull()?.minus(40)
        val map = payload(0x0B)?.firstOrNull()?.times(10)
        val intake = payload(0x0F)?.firstOrNull()?.minus(40)?.toDouble()
        val throttle = payload(0x11)?.firstOrNull()?.let { it * 100.0 / 255.0 }
        val load = payload(0x04)?.firstOrNull()?.let { it * 100.0 / 255.0 }
        val maf = payload(0x10)?.takeIf { it.size >= 2 }?.let { ((it[0] shl 8) or it[1]) / 100.0 }
        val stft = payload(0x06)?.firstOrNull()?.let { (it - 128) * 100.0 / 128.0 }
        val ltft = payload(0x07)?.firstOrNull()?.let { (it - 128) * 100.0 / 128.0 }
        val ratio = payload(0x44)?.takeIf { it.size >= 2 }?.let { ((it[0] shl 8) or it[1]) / 32768.0 }
        val fuelRate = payload(0x5E)?.takeIf { it.size >= 2 }?.let { ((it[0] shl 8) or it[1]) / 20.0 }
        val fuelStatus = payload(0x03)?.let(::decodeFuelSystemStatus)

        return GenericObdReading(
            rpm = rpm,
            speedKmh = speed,
            coolantC = coolant,
            mapMbar = map,
            intakeTempC = intake,
            throttlePercent = throttle,
            calculatedLoadPercent = load,
            mafGramsPerSec = maf,
            shortFuelTrimPercent = stft,
            longFuelTrimPercent = ltft,
            commandedEquivalenceRatio = ratio,
            engineFuelRateLh = fuelRate,
            fuelSystemStatus = fuelStatus,
            rawJoined = responses.entries.joinToString(" | ") { (cmd, raw) -> "$cmd=${raw.replace('\n', ' ').trim()}" }
        )
    }

    fun supportedPidCommands(response: String, basePid: Int): Set<Int> {
        val data = extractPayload(response, basePid) ?: return emptySet()
        if (data.size < 4) return emptySet()
        val result = linkedSetOf<Int>()
        for (offset in 1..32) {
            val byteIndex = (offset - 1) / 8
            val bitIndex = 7 - ((offset - 1) % 8)
            if ((data[byteIndex] and (1 shl bitIndex)) != 0) result += basePid + offset
        }
        return result
    }

    private fun extractPayload(raw: String, pid: Int): List<Int>? {
        val bytes = Regex("(?i)\\b[0-9a-f]{2}\\b")
            .findAll(raw)
            .map { it.value.toInt(16) }
            .toList()
        val index = bytes.indices.firstOrNull { i ->
            i + 1 < bytes.size && bytes[i] == 0x41 && bytes[i + 1] == pid
        } ?: return null
        return bytes.drop(index + 2)
    }

    private fun decodeFuelSystemStatus(data: List<Int>): String? {
        if (data.isEmpty()) return null
        val labels = data.take(2).mapNotNull { code ->
            when (code) {
                0x01 -> "OPEN_LOOP_COLD"
                0x02 -> "CLOSED_LOOP"
                0x04 -> "OPEN_LOOP_LOAD"
                0x08 -> "OPEN_LOOP_FAULT"
                0x10 -> "CLOSED_LOOP_FAULT"
                0x00 -> null
                else -> "0x%02X".format(Locale.US, code)
            }
        }
        return labels.joinToString("+").ifBlank { null }
    }
}
