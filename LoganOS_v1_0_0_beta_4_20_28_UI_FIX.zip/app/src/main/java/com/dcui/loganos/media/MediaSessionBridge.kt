package com.dcui.loganos.media

import android.app.NotificationManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.os.SystemClock
import android.view.KeyEvent

const val PACKAGE_AIMP = "com.aimp.player"
const val PACKAGE_JANCAR_MUSIC = "com.jancar.music"
const val PACKAGE_JANCAR_RADIO = "com.jancar.radio"

/** Reusable media state consumed by the test screen and Premium Drive. */
data class LoganMediaState(
    val notificationAccess: Boolean = false,
    val sessionCount: Int = 0,
    val packageName: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val durationMs: Long = 0L,
    val positionMs: Long = 0L,
    val playbackState: Int? = null,
    val controller: MediaController? = null,
    val error: String? = null
) {
    val isAimp: Boolean get() = packageName == PACKAGE_AIMP
    val isJancarMusic: Boolean get() = packageName == PACKAGE_JANCAR_MUSIC
    val hasUsableMetadata: Boolean get() = !title.isNullOrBlank() || !artist.isNullOrBlank()
}

object MediaSessionBridge {
    fun read(context: Context, preferredPackageName: String = PACKAGE_AIMP): LoganMediaState {
        val listener = ComponentName(context, LoganMediaNotificationListener::class.java)
        val notificationManager = context.getSystemService(NotificationManager::class.java)
        val hasAccess = notificationManager?.isNotificationListenerAccessGranted(listener) == true
        if (!hasAccess) return LoganMediaState(notificationAccess = false)

        val manager = context.getSystemService(MediaSessionManager::class.java)
        var error: String? = null
        val controllers = runCatching { manager?.getActiveSessions(listener).orEmpty() }
            .onFailure { error = "MediaSession okunamadı: ${it.javaClass.simpleName}" }
            .getOrDefault(emptyList())

        // Premium Drive must respect the app selected in LoganOS settings.
        // We intentionally do not let another active player hijack the card.
        val selected = controllers
            .filter { it.packageName == preferredPackageName }
            .sortedWith(
                compareByDescending<MediaController> { hasUsefulMetadata(it) }
                    .thenByDescending { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING }
            )
            .firstOrNull()

        val metadata = selected?.metadata
        val playback = selected?.playbackState
        return LoganMediaState(
            notificationAccess = true,
            sessionCount = controllers.size,
            packageName = selected?.packageName,
            title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE),
            artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST),
            album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM),
            durationMs = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L,
            positionMs = estimatedPosition(playback),
            playbackState = playback?.state,
            controller = selected,
            error = error
        )
    }

    fun playPause(context: Context, state: LoganMediaState) {
        val controls = state.controller?.transportControls
        if (controls != null) {
            if (state.playbackState == android.media.session.PlaybackState.STATE_PLAYING) controls.pause() else controls.play()
        } else {
            sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
        }
    }

    fun previous(context: Context, state: LoganMediaState) {
        state.controller?.transportControls?.skipToPrevious() ?: sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
    }

    fun next(context: Context, state: LoganMediaState) {
        state.controller?.transportControls?.skipToNext() ?: sendMediaKey(context, KeyEvent.KEYCODE_MEDIA_NEXT)
    }

    fun launchPackage(context: Context, packageName: String): Boolean {
        val packageManager = context.packageManager
        val fallback = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setPackage(packageName)
            .takeIf { packageManager.resolveActivity(it, 0) != null }
        val intent = packageManager.getLaunchIntentForPackage(packageName)
            ?: packageManager.getLeanbackLaunchIntentForPackage(packageName)
            ?: fallback
            ?: return false
        return runCatching {
            context.startActivity(
                intent.addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED or
                        Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            )
            true
        }.getOrDefault(false)
    }

    fun isInstalled(context: Context, packageName: String): Boolean =
        runCatching { context.packageManager.getPackageInfo(packageName, 0); true }.getOrDefault(false)

    private fun hasUsefulMetadata(controller: MediaController): Boolean {
        val metadata = controller.metadata ?: return false
        return !metadata.getString(MediaMetadata.METADATA_KEY_TITLE).isNullOrBlank() ||
            !metadata.getString(MediaMetadata.METADATA_KEY_ARTIST).isNullOrBlank()
    }

    private fun estimatedPosition(playback: android.media.session.PlaybackState?): Long {
        if (playback == null) return 0L
        var position = playback.position.coerceAtLeast(0L)
        if (playback.state == android.media.session.PlaybackState.STATE_PLAYING && playback.lastPositionUpdateTime > 0L) {
            val elapsed = (SystemClock.elapsedRealtime() - playback.lastPositionUpdateTime).coerceAtLeast(0L)
            position += (elapsed * playback.playbackSpeed).toLong()
        }
        return position.coerceAtLeast(0L)
    }

    private fun sendMediaKey(context: Context, keyCode: Int) {
        val audioManager = context.getSystemService(AudioManager::class.java) ?: return
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, keyCode))
        audioManager.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, keyCode))
    }
}
