package com.dcui.loganos.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.MenuTheme

data class LoganPalette(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val muted: Color,
    val line: Color,
    val accent: Color,
    val warning: Color = Color(0xFFFF8A00),
    val critical: Color = Color(0xFFFF3B30),
    val blue: Color = Color(0xFF207DFF)
)

fun loganPalette(accentColor: AccentColor, dark: Boolean, menuTheme: MenuTheme = MenuTheme.Light): LoganPalette {
    if (dark) {
        return LoganPalette(
            background = Color(0xFF0D1117),
            surface = Color(0xFF161B22),
            surfaceVariant = Color(0xFF1F2630),
            textPrimary = Color(0xFFE6E9EF),
            textSecondary = Color(0xFFB8C0CC),
            muted = Color(0xFF7D8794),
            line = Color(0xFF2D333B),
            accent = accentColor.color
        )
    }
    return when (menuTheme) {
        MenuTheme.SoftGray -> LoganPalette(
            background = Color(0xFFEFF1F4),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFF8F9FB),
            textPrimary = Color(0xFF111318),
            textSecondary = Color(0xFF626873),
            muted = Color(0xFF7B8491),
            line = Color(0xFFE0E3E8),
            accent = accentColor.color
        )
        MenuTheme.BlueGray -> LoganPalette(
            background = Color(0xFFEEF3F7),
            surface = Color(0xFFFCFDFE),
            surfaceVariant = Color(0xFFF5F8FB),
            textPrimary = Color(0xFF111820),
            textSecondary = Color(0xFF5D6975),
            muted = Color(0xFF778493),
            line = Color(0xFFDDE6EE),
            accent = accentColor.color
        )
        else -> LoganPalette(
            background = Color(0xFFF5F6F8),
            surface = Color(0xFFFFFFFF),
            surfaceVariant = Color(0xFFFAFAFC),
            textPrimary = Color(0xFF111318),
            textSecondary = Color(0xFF626873),
            muted = Color(0xFF7B8491),
            line = Color(0xFFE5E7EB),
            accent = accentColor.color
        )
    }
}

@Composable
fun LoganOSTheme(
    accentColor: AccentColor,
    darkTheme: Boolean = isSystemInDarkTheme(),
    menuTheme: MenuTheme = MenuTheme.Light,
    content: @Composable (LoganPalette) -> Unit
) {
    val palette = loganPalette(accentColor, darkTheme, menuTheme)
    val scheme: ColorScheme = if (darkTheme) {
        darkColorScheme(
            primary = palette.accent,
            background = palette.background,
            surface = palette.surface,
            onPrimary = Color.White,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    } else {
        lightColorScheme(
            primary = palette.accent,
            background = palette.background,
            surface = palette.surface,
            onPrimary = Color.White,
            onBackground = palette.textPrimary,
            onSurface = palette.textPrimary
        )
    }
    MaterialTheme(colorScheme = scheme) {
        content(palette)
    }
}
