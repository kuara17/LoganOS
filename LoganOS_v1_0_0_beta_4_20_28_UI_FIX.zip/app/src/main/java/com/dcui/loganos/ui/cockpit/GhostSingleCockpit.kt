package com.dcui.loganos.ui.cockpit

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.theme.LoganPalette

/**
 * Final Ghost Single cockpit.
 * This is the baked design that was previously exposed as "Ghost Single Original".
 */
@Composable
fun GhostSingleCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    showHeadUnitTabs: Boolean,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostOriginalBakedCockpit(
        palette = palette,
        settings = settings,
        snapshot = snapshot,
        showHeadUnitTabs = showHeadUnitTabs,
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}
