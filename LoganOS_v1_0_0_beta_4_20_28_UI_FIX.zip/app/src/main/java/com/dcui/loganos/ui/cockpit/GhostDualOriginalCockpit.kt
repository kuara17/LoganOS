package com.dcui.loganos.ui.cockpit

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.theme.LoganPalette

/**
 * Backward-compatible alias for backups that still contain GhostDualOriginal.
 * Both GhostDual and GhostDualOriginal use the new 19.5:9 baked Dual scene set.
 */
@Composable
fun GhostDualOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    showHeadUnitTabs: Boolean,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostOriginalBakedCockpit(
        palette = palette,
        settings = settings,
        snapshot = snapshot,
        showHeadUnitTabs = showHeadUnitTabs,
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}
