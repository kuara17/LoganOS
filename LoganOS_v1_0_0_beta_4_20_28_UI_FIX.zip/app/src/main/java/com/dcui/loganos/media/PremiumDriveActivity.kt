package com.dcui.loganos.media

import android.content.Context
import android.content.Intent
import android.media.MediaMetadata
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.BuildConfig
import kotlinx.coroutines.delay

class PremiumDriveActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFF07101E)) {
                    PremiumDriveFoundationScreen(this)
                }
            }
        }
    }
}

@Composable
private fun PremiumDriveFoundationScreen(context: Context) {
    var media by remember { mutableStateOf(MediaSessionBridge.read(context)) }
    LaunchedEffect(Unit) {
        while (true) {
            media = MediaSessionBridge.read(context)
            delay(750)
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Premium Drive", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 26.sp)
                Text("Medya altyapısı önizlemesi • ${BuildConfig.VERSION_NAME}", color = Color(0xFFA8B7CC))
            }
            Text(if (media.isAimp) "AIMP BAĞLI" else "MEDYA BEKLENİYOR", color = if (media.isAimp) Color(0xFF77E383) else Color(0xFFFFC66D), fontWeight = FontWeight.Bold)
        }

        Box(
            modifier = Modifier.fillMaxWidth().weight(1f).background(Color(0xFF0B1A2E), RoundedCornerShape(22.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("0", color = Color.White, fontSize = 74.sp, fontWeight = FontWeight.Light)
                Text("km/h", color = Color(0xFFCAD6E5), fontSize = 20.sp)
                Spacer(Modifier.height(8.dp))
                Text("Tam Premium Drive kokpiti Ayarlar > Görünüm & Kokpit bölümünden etkinleştirin", color = Color(0xFF6F86A5), fontSize = 13.sp)
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color(0xFF111F32))
        ) {
            Row(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                val artwork = media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: media.controller?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                if (artwork != null) {
                    Image(artwork.asImageBitmap(), contentDescription = "Albüm kapağı", modifier = Modifier.size(92.dp))
                } else {
                    Box(modifier = Modifier.size(92.dp).background(Color(0xFF263A55), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) {
                        Text("♪", color = Color.White, fontSize = 34.sp)
                    }
                }

                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(media.title ?: "AIMP'de bir parça başlatın", color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(media.artist ?: "Medya bilgisi bekleniyor", color = Color(0xFFB7C5D8), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${formatMediaTime(media.positionMs)} / ${formatMediaTime(media.durationMs)}", color = Color(0xFF8295AE), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { MediaSessionBridge.previous(context, media) }) { Text("Önceki") }
                        Button(onClick = { MediaSessionBridge.playPause(context, media) }) { Text(if (media.playbackState == android.media.session.PlaybackState.STATE_PLAYING) "Duraklat" else "Oynat") }
                        OutlinedButton(onClick = { MediaSessionBridge.next(context, media) }) { Text("Sonraki") }
                    }
                }

                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { MediaSessionBridge.launchPackage(context, PACKAGE_AIMP) }) { Text("AIMP") }
                    OutlinedButton(onClick = { MediaSessionBridge.launchPackage(context, PACKAGE_JANCAR_RADIO) }) { Text("Radyo") }
                }
            }
        }

        if (!media.notificationAccess) {
            Button(modifier = Modifier.fillMaxWidth(), onClick = {
                context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }) { Text("Medya erişimini aç") }
        }
    }
}

private fun formatMediaTime(valueMs: Long): String {
    val seconds = valueMs.coerceAtLeast(0L) / 1_000L
    return "%d:%02d".format(seconds / 60, seconds % 60)
}
