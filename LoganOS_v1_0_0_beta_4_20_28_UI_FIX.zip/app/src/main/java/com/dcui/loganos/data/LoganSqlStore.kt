package com.dcui.loganos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.obd.StartConfidence
import com.dcui.loganos.obd.StartEvent
import com.dcui.loganos.obd.StartThermalClass
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

class LoganSqlStore(
    context: Context,
    private val timeSource: TrustedTimeSource = TrustedTimeSource(context)
) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val appContext = context.applicationContext
    private var anchoredBootId: String? = null
    private var anchoredOffsetMs: Long? = null

    init {
        // Better concurrent read/write behavior and safer short transactions on
        // head units that may lose power abruptly.
        setWriteAheadLoggingEnabled(true)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE drive_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                boot_session_id TEXT NOT NULL,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                session_state TEXT NOT NULL DEFAULT 'ACTIVE',
                version_name TEXT NOT NULL,
                adapter_name TEXT,
                adapter_address TEXT,
                note TEXT,
                trip_record_id INTEGER
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE obd_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                loop_index INTEGER,
                loop_ms INTEGER,
                rpm INTEGER,
                speed_kmh INTEGER,
                coolant_c INTEGER,
                fuel_mg REAL,
                fuel_lh REAL,
                instant_value REAL,
                instant_unit TEXT,
                pedal_percent REAL,
                map_mbar INTEGER,
                air_charge REAL,
                ac_on INTEGER,
                fan_state TEXT,
                fuel_source TEXT,
                trip_state TEXT,
                trip_distance_km REAL,
                fuel_used_l REAL,
                avg_l100 REAL,
                raw21cc TEXT,
                raw21a0 TEXT,
                raw21a2 TEXT,
                raw21cd TEXT,
                raw_obd TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE test_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                event_type TEXT NOT NULL,
                name TEXT NOT NULL,
                note TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        createHistoryTables(db)
        createGpsTable(db)
        createStartEventsTable(db)
        createIndexes(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        var version = oldVersion
        if (version < 2) {
            // Non-destructive v1 -> v2 migration. Existing beta.3.9.x sessions
            // remain available instead of being dropped.
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN started_elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN ended_elapsed_ms INTEGER")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN start_time_trusted INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN end_time_trusted INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN session_state TEXT NOT NULL DEFAULT 'ACTIVE'")

            db.execSQL("ALTER TABLE obd_samples ADD COLUMN elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE obd_samples ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE obd_samples ADD COLUMN time_trusted INTEGER NOT NULL DEFAULT 1")

            db.execSQL("ALTER TABLE test_events ADD COLUMN elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE test_events ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE test_events ADD COLUMN time_trusted INTEGER NOT NULL DEFAULT 1")

            db.execSQL("UPDATE drive_sessions SET session_state=CASE WHEN ended_at_ms IS NULL THEN 'ACTIVE' ELSE 'ENDED' END")
            createCoreIndexes(db)
            version = 2
        }
        if (version < 3) {
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN trip_record_id INTEGER")
            createHistoryTables(db)
            createIndexes(db)
            version = 3
        }
        if (version < 4) {
            db.execSQL("ALTER TABLE obd_samples ADD COLUMN raw_obd TEXT")
            db.execSQL("ALTER TABLE test_samples ADD COLUMN raw_obd TEXT")
            version = 4
        }
        if (version < 5) {
            createGpsTable(db)
            createIndexes(db)
            version = 5
        }
        if (version < 6) {
            createStartEventsTable(db)
            createIndexes(db)
            version = 6
        }
        check(version == newVersion) {
            "Unsupported LoganOS database migration: $oldVersion -> $newVersion"
        }
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        throw IllegalStateException("LoganOS database downgrade is not supported: $oldVersion -> $newVersion")
    }

    fun databaseFile(): File = appContext.getDatabasePath(DB_NAME)

    @Synchronized
    fun snapshotDatabaseFile(): File {
        val db = writableDatabase
        // Fold committed WAL pages into the main file before creating the portable copy.
        runCatching {
            db.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { cursor -> cursor.moveToFirst() }
        }

        // GPS routes are sensitive location data and are intentionally excluded
        // from the default LoganOS backup. The caller owns and deletes the returned
        // temporary file after it has been streamed into the backup archive.
        val source = databaseFile()
        val temp = File(appContext.cacheDir, "loganos_backup_sanitized_${System.nanoTime()}.db")
        try {
            source.copyTo(temp, overwrite = true)
            val backupDb = SQLiteDatabase.openDatabase(temp.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
            try {
                if (tableExists(backupDb, "gps_points")) backupDb.delete("gps_points", null, null)
                runCatching {
                    backupDb.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { cursor -> cursor.moveToFirst() }
                }
            } finally {
                backupDb.close()
            }
            File(temp.absolutePath + "-wal").delete()
            File(temp.absolutePath + "-shm").delete()
            File(temp.absolutePath + "-journal").delete()
            require(temp.isFile && temp.length() > 0L) { "Yedek veritabanı oluşturulamadı" }
            return temp
        } catch (error: Throwable) {
            temp.delete()
            File(temp.absolutePath + "-wal").delete()
            File(temp.absolutePath + "-shm").delete()
            File(temp.absolutePath + "-journal").delete()
            throw error
        }
    }

    fun isTimeTrusted(): Boolean = timeSource.isTrusted()

    /** Close sessions left ACTIVE by an abrupt ignition/power cut. */
    fun recoverOpenSessions(): Int {
        val db = writableDatabase
        val openSessions = mutableListOf<RecoverableSession>()
        db.rawQuery(
            "SELECT id, started_at_ms, started_elapsed_ms, start_time_trusted FROM drive_sessions WHERE ended_at_ms IS NULL OR session_state='ACTIVE' ORDER BY id ASC",
            emptyArray()
        ).use { sessions ->
            while (sessions.moveToNext()) {
                openSessions += RecoverableSession(
                    id = sessions.getLong(0),
                    startedAtMs = sessions.getLong(1),
                    startedElapsedMs = sessions.getLong(2),
                    startTrusted = sessions.getInt(3) == 1
                )
            }
        }
        if (openSessions.isEmpty()) return 0

        db.beginTransaction()
        try {
            openSessions.forEach { session ->
                val last = latestStoredMark(db, session.id)
                val endEpoch = last?.epochMs ?: if (session.startTrusted) session.startedAtMs else 0L
                val endElapsed = last?.elapsedMs ?: session.startedElapsedMs
                val endTrusted = last?.trusted ?: session.startTrusted
                val values = ContentValues().apply {
                    put("ended_at_ms", endEpoch)
                    put("ended_elapsed_ms", endElapsed)
                    put("end_time_trusted", if (endTrusted) 1 else 0)
                    put("session_state", "RECOVERED")
                }
                db.update("drive_sessions", values, "id=?", arrayOf(session.id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return openSessions.size
    }

    fun startSession(versionName: String, adapterName: String?, adapterAddress: String?, tripRecordId: Long? = null): Long {
        val mark = currentMark()
        val values = ContentValues().apply {
            put("started_at_ms", mark.epochMs ?: 0L)
            put("started_elapsed_ms", mark.elapsedMs)
            put("boot_session_id", mark.bootSessionId)
            put("start_time_trusted", if (mark.trusted) 1 else 0)
            put("end_time_trusted", 0)
            put("session_state", "ACTIVE")
            put("version_name", versionName)
            put("adapter_name", adapterName)
            put("adapter_address", adapterAddress)
            put("note", "LoganOS SQL session")
            if (tripRecordId != null) put("trip_record_id", tripRecordId)
        }
        return writableDatabase.insertOrThrow("drive_sessions", null, values)
    }

    fun endSession(sessionId: Long?, state: String = "ENDED", endMark: TimeMark? = null) {
        if (sessionId == null) return
        val mark = endMark ?: currentMark()
        val values = ContentValues().apply {
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("session_state", state)
        }
        writableDatabase.update("drive_sessions", values, "id=?", arrayOf(sessionId.toString()))
    }

    fun insertEvent(sessionId: Long?, eventType: String, name: String, note: String? = null) {
        val mark = currentMark()
        val values = ContentValues().apply {
            if (sessionId != null) put("session_id", sessionId)
            putTime(mark)
            put("event_type", eventType)
            put("name", name)
            put("note", note)
        }
        writableDatabase.insertOrThrow("test_events", null, values)
    }

    fun insertSample(
        sessionId: Long?,
        loopIndex: Int,
        loopMs: Long,
        snapshot: DashboardSnapshot,
        raw21cc: String,
        raw21a0: String,
        raw21a2: String,
        raw21cd: String,
        rawObd: String = ""
    ) {
        if (sessionId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("session_id", sessionId)
            putTime(mark)
            put("loop_index", loopIndex)
            put("loop_ms", loopMs)
            putNullable("rpm", snapshot.rpm)
            putNullable("speed_kmh", snapshot.speedKmh)
            putNullable("coolant_c", snapshot.engineTempC)
            putNullable("fuel_mg", snapshot.injectionMg)
            putNullable("fuel_lh", if (snapshot.instantUnit == "L/h") snapshot.instantConsumption else null)
            putNullable("instant_value", snapshot.instantConsumption)
            put("instant_unit", snapshot.instantUnit)
            putNullable("pedal_percent", snapshot.pedalPercent)
            putNullable("map_mbar", snapshot.mapMbar)
            putNullable("air_charge", snapshot.airCharge)
            putNullable("ac_on", snapshot.acOn?.let { if (it) 1 else 0 })
            putNull("fan_state")
            put("fuel_source", snapshot.fuelSource)
            put("trip_state", snapshot.tripStateText)
            putNullable("trip_distance_km", snapshot.tripDistanceKm)
            putNullable("fuel_used_l", snapshot.fuelUsedL)
            putNullable("avg_l100", snapshot.averageConsumption)
            put("raw21cc", raw21cc)
            put("raw21a0", raw21a0)
            put("raw21a2", raw21a2)
            put("raw21cd", raw21cd)
            put("raw_obd", rawObd)
        }
        writableDatabase.insertOrThrow("obd_samples", null, values)
    }

    fun insertGpsPoint(
        sessionId: Long?,
        latitude: Double,
        longitude: Double,
        accuracyM: Float
    ): Boolean {
        if (sessionId == null) return false
        if (!latitude.isFinite() || !longitude.isFinite() || !accuracyM.isFinite()) return false
        if (latitude !in -90.0..90.0 || longitude !in -180.0..180.0 || accuracyM <= 0f) return false
        val mark = currentMark()
        val values = ContentValues().apply {
            put("drive_session_id", sessionId)
            put("time_ms", mark.epochMs ?: 0L)
            put("elapsed_ms", mark.elapsedMs)
            put("boot_session_id", mark.bootSessionId)
            put("time_trusted", if (mark.trusted) 1 else 0)
            put("latitude", latitude)
            put("longitude", longitude)
            put("accuracy_m", accuracyM.toDouble())
        }
        return writableDatabase.insert("gps_points", null, values) > 0L
    }

    fun loadGpsRoute(recordId: Long): GpsRouteDetail {
        data class StoredGpsPoint(val sessionId: Long, val point: GpsRoutePoint)
        val rows = mutableListOf<StoredGpsPoint>()
        readableDatabase.rawQuery(
            """
            SELECT g.drive_session_id,g.time_ms,g.elapsed_ms,g.time_trusted,g.latitude,g.longitude,g.accuracy_m
            FROM gps_points g
            JOIN drive_sessions d ON d.id=g.drive_session_id
            WHERE d.trip_record_id=?
            ORDER BY d.id ASC,g.elapsed_ms ASC,g.id ASC
            """.trimIndent(),
            arrayOf(recordId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val trusted = c.getInt(3) == 1
                rows += StoredGpsPoint(
                    sessionId = c.getLong(0),
                    point = GpsRoutePoint(
                        latitude = c.getDouble(4),
                        longitude = c.getDouble(5),
                        accuracyM = c.getFloat(6),
                        epochMs = c.getLong(1).takeIf { trusted && it > 0L },
                        elapsedMs = c.getLong(2),
                        timeTrusted = trusted
                    )
                )
            }
        }
        if (rows.isEmpty()) return GpsRouteDetail()

        val segments = mutableListOf<GpsRouteSegment>()
        var currentSession = rows.first().sessionId
        var current = mutableListOf<GpsRoutePoint>()
        var previous: GpsRoutePoint? = null
        fun flush() {
            if (current.isNotEmpty()) segments += GpsRouteSegment(currentSession, current.toList())
            current = mutableListOf()
            previous = null
        }

        rows.forEach { stored ->
            if (stored.sessionId != currentSession) {
                flush()
                currentSession = stored.sessionId
            }
            val prev = previous
            val gapMs = if (prev == null) 0L else (stored.point.elapsedMs - prev.elapsedMs).coerceAtLeast(0L)
            val gapMeters = if (prev == null) 0.0 else haversineMeters(
                prev.latitude, prev.longitude, stored.point.latitude, stored.point.longitude
            )
            // Never draw a confident straight line across a long unknown GPS window.
            if (current.isNotEmpty() && (gapMs > GPS_SEGMENT_GAP_MS || (gapMs > 20_000L && gapMeters > 2_000.0))) {
                flush()
                currentSession = stored.sessionId
            }
            current += stored.point
            previous = stored.point
        }
        flush()
        val validSegments = segments.filter { it.points.isNotEmpty() }
        val trustedTimes = validSegments.flatMap { it.points }.mapNotNull { it.epochMs }
        return GpsRouteDetail(
            segments = validSegments,
            pointCount = validSegments.sumOf { it.points.size },
            firstEpochMs = trustedTimes.minOrNull(),
            lastEpochMs = trustedTimes.maxOrNull()
        )
    }

    fun exportTripGpx(recordId: Long, maskEdges: Boolean = true, maskMeters: Double = 200.0): String? {
        val route = loadGpsRoute(recordId)
        if (!route.hasRoute) return null
        val segments = if (maskEdges) maskRouteEdges(route.segments, maskMeters.coerceAtLeast(0.0)) else route.segments
        val usable = segments.filter { it.points.size >= 2 }
        if (usable.isEmpty()) return null
        return buildString {
            appendLine("<?xml version=\"1.0\" encoding=\"UTF-8\"?>")
            appendLine("<gpx version=\"1.1\" creator=\"LoganOS ${com.dcui.loganos.BuildConfig.VERSION_NAME}\" xmlns=\"http://www.topografix.com/GPX/1/1\">")
            appendLine("  <metadata><name>LoganOS sürüş $recordId</name></metadata>")
            appendLine("  <trk>")
            appendLine("    <name>LoganOS sürüş $recordId</name>")
            usable.forEach { segment ->
                appendLine("    <trkseg>")
                segment.points.forEach { point ->
                    val lat = String.format(Locale.US, "%.7f", point.latitude)
                    val lon = String.format(Locale.US, "%.7f", point.longitude)
                    val time = point.epochMs?.let { java.time.Instant.ofEpochMilli(it).toString() }
                    if (time != null) {
                        appendLine("      <trkpt lat=\"$lat\" lon=\"$lon\"><time>$time</time></trkpt>")
                    } else {
                        appendLine("      <trkpt lat=\"$lat\" lon=\"$lon\" />")
                    }
                }
                appendLine("    </trkseg>")
            }
            appendLine("  </trk>")
            appendLine("</gpx>")
        }
    }

    private fun maskRouteEdges(segments: List<GpsRouteSegment>, maskMeters: Double): List<GpsRouteSegment> {
        if (maskMeters <= 0.0) return segments
        val mutable = segments.map { it.copy(points = it.points.toMutableList()) }.toMutableList()
        var remainingStart = maskMeters
        for (index in mutable.indices) {
            val pts = mutable[index].points.toMutableList()
            if (pts.size < 2) {
                mutable[index] = mutable[index].copy(points = emptyList())
                continue
            }
            var keepFrom = 0
            while (keepFrom + 1 < pts.size && remainingStart > 0.0) {
                remainingStart -= haversineMeters(pts[keepFrom].latitude, pts[keepFrom].longitude, pts[keepFrom + 1].latitude, pts[keepFrom + 1].longitude)
                keepFrom++
            }
            mutable[index] = mutable[index].copy(points = if (remainingStart > 0.0) emptyList() else pts.drop(keepFrom))
            if (remainingStart <= 0.0) break
        }

        var remainingEnd = maskMeters
        for (index in mutable.indices.reversed()) {
            val pts = mutable[index].points.toMutableList()
            if (pts.size < 2) continue
            var keepUntil = pts.lastIndex
            while (keepUntil - 1 >= 0 && remainingEnd > 0.0) {
                remainingEnd -= haversineMeters(pts[keepUntil].latitude, pts[keepUntil].longitude, pts[keepUntil - 1].latitude, pts[keepUntil - 1].longitude)
                keepUntil--
            }
            mutable[index] = mutable[index].copy(points = if (remainingEnd > 0.0) emptyList() else pts.take(keepUntil + 1))
            if (remainingEnd <= 0.0) break
        }
        return mutable.filter { it.points.isNotEmpty() }
    }

    private fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val earthRadiusM = 6_371_000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2.0) * sin(dLat / 2.0) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2.0) * sin(dLon / 2.0)
        return 2.0 * earthRadiusM * atan2(sqrt(a), sqrt(1.0 - a))
    }

    fun clearAll(): Int {
        val db = writableDatabase
        var count = 0
        db.beginTransaction()
        try {
            count += db.delete("test_samples", null, null)
            count += db.delete("test_sessions", null, null)
            count += db.delete("obd_samples", null, null)
            count += db.delete("test_events", null, null)
            count += db.delete("start_events", null, null)
            count += db.delete("drive_sessions", null, null)
            count += db.delete("trip_records", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return count
    }

    fun listTechnicalSessions(maxItems: Int = 20): List<TechnicalSessionItem> {
        val result = mutableListOf<TechnicalSessionItem>()
        val sql = """
            SELECT
                d.id,
                d.started_at_ms,
                d.ended_at_ms,
                d.start_time_trusted,
                d.end_time_trusted,
                d.session_state,
                d.started_elapsed_ms,
                d.ended_elapsed_ms,
                d.adapter_name,
                d.trip_record_id,
                d.boot_session_id,
                (SELECT COUNT(*) FROM obd_samples s WHERE s.session_id=d.id) AS sample_count,
                (SELECT COUNT(*) FROM test_events e WHERE e.session_id=d.id) AS event_count
            FROM drive_sessions d
            ORDER BY CASE WHEN d.session_state='ACTIVE' THEN 0 ELSE 1 END, d.id DESC
            LIMIT ?
        """.trimIndent()
        val nowMark = currentMark()
        readableDatabase.rawQuery(sql, arrayOf(maxItems.coerceIn(1, 100).toString())).use { c ->
            while (c.moveToNext()) {
                val endedAt = if (c.isNull(2)) null else c.getLong(2)
                val startTrusted = c.getInt(3) == 1
                val endTrusted = c.getInt(4) == 1
                val startedElapsed = c.getLong(6)
                val endedElapsed = if (c.isNull(7)) null else c.getLong(7)
                val durationMs = when {
                    startedElapsed > 0L && endedElapsed != null && endedElapsed >= startedElapsed -> endedElapsed - startedElapsed
                    startedElapsed > 0L && c.getString(10) == nowMark.bootSessionId && nowMark.elapsedMs >= startedElapsed -> nowMark.elapsedMs - startedElapsed
                    else -> ((endedAt ?: nowMark.epochMs ?: c.getLong(1)) - c.getLong(1)).coerceAtLeast(0L)
                }
                result += TechnicalSessionItem(
                    id = c.getLong(0),
                    startedAtMs = c.getLong(1),
                    endedAtMs = endedAt,
                    timeTrusted = startTrusted && (endedAt == null || endTrusted),
                    status = c.getString(5),
                    durationMs = durationMs,
                    adapterName = if (c.isNull(8)) null else c.getString(8),
                    tripRecordId = if (c.isNull(9)) null else c.getLong(9),
                    sampleCount = c.getInt(11),
                    eventCount = c.getInt(12)
                )
            }
        }
        return result
    }

    fun latestValidTechnicalSessionId(preferredSessionId: Long? = null): Long? {
        if (preferredSessionId != null) {
            val preferredHasSamples = readableDatabase.rawQuery(
                "SELECT EXISTS(SELECT 1 FROM obd_samples WHERE session_id=? LIMIT 1)",
                arrayOf(preferredSessionId.toString())
            ).use { c -> c.moveToFirst() && c.getInt(0) == 1 }
            if (preferredHasSamples) return preferredSessionId
        }
        return readableDatabase.rawQuery(
            "SELECT d.id FROM drive_sessions d WHERE EXISTS(SELECT 1 FROM obd_samples s WHERE s.session_id=d.id) ORDER BY d.id DESC LIMIT 1",
            emptyArray()
        ).use { c -> if (c.moveToFirst()) c.getLong(0) else null }
    }

    fun exportSessionText(sessionId: Long?, includeRaw: Boolean = true, maxElapsedMs: Long? = null): String? {
        val id = sessionId ?: latestValidTechnicalSessionId() ?: return null
        val db = readableDatabase
        val session = db.rawQuery("SELECT * FROM drive_sessions WHERE id=?", arrayOf(id.toString()))
        if (!session.moveToFirst()) {
            session.close()
            return null
        }
        val startedAt = session.long("started_at_ms")
        val storedEndedAt = session.optLong("ended_at_ms")
        val startedElapsed = session.optLong("started_elapsed_ms") ?: 0L
        val endedElapsed = session.optLong("ended_elapsed_ms")
        val startTrusted = session.optInt("start_time_trusted") == 1
        val endTrusted = session.optInt("end_time_trusted") == 1
        val sessionState = session.str("session_state") ?: if (storedEndedAt == null) "ACTIVE" else "ENDED"
        val nowMark = timeSource.now()
        val effectiveEndedElapsed = endedElapsed ?: nowMark.elapsedMs
        val effectiveEndedEpoch = storedEndedAt ?: nowMark.epochMs
        val durationMs = if (startedElapsed > 0L && effectiveEndedElapsed >= startedElapsed) {
            effectiveEndedElapsed - startedElapsed
        } else {
            ((effectiveEndedEpoch ?: startedAt) - startedAt).coerceAtLeast(0L)
        }
        val header = buildString {
            appendLine("LOGANOS SQL EXPORT")
            appendLine("session_id=$id")
            appendLine("version=${session.str("version_name")}")
            appendLine("adapter=${session.str("adapter_name") ?: "--"} / ${maskBluetoothAddress(session.str("adapter_address"))}")
            appendLine("started=${formatTimestamp(startedAt, startTrusted)}")
            appendLine("ended=${formatTimestamp(effectiveEndedEpoch ?: 0L, endTrusted || (storedEndedAt == null && nowMark.trusted))}")
            appendLine("duration=${formatDuration(durationMs)}")
            appendLine("session_state=$sessionState")
            appendLine("time_source=${if (startTrusted && (storedEndedAt == null || endTrusted)) "TRUSTED" else "MONOTONIC_PENDING"}")
            appendLine()
        }
        session.close()

        val builder = StringBuilder(header)
        val testStartCounts = mutableMapOf<String, Int>()
        val activeTestStarts = mutableMapOf<String, Long>()
        val eventSql = if (maxElapsedMs != null) {
            "SELECT * FROM test_events WHERE session_id=? AND elapsed_ms<=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC"
        } else {
            "SELECT * FROM test_events WHERE session_id=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC"
        }
        val eventArgs = if (maxElapsedMs != null) arrayOf(id.toString(), maxElapsedMs.toString()) else arrayOf(id.toString())
        db.rawQuery(eventSql, eventArgs).use { c ->
            if (c.count > 0) {
                builder.appendLine("[TEST_EVENTS]")
                while (c.moveToNext()) {
                    val type = c.str("event_type") ?: "EVENT"
                    val name = c.str("name") ?: "--"
                    val note = c.str("note") ?: ""
                    val timeMs = c.long("time_ms")
                    val elapsedMs = c.optLong("elapsed_ms") ?: 0L
                    val trusted = c.optInt("time_trusted") == 1
                    val suffix = if (type == "TEST_START") {
                        val next = (testStartCounts[name] ?: 0) + 1
                        testStartCounts[name] = next
                        activeTestStarts[name] = elapsedMs
                        " #$next"
                    } else ""
                    val shortNote = if (type == "TEST_END") {
                        val started = activeTestStarts[name]
                        if (started != null && elapsedMs - started < 5000L) " kısa/geçersiz deneme" else ""
                    } else ""
                    builder.appendLine("[$type$suffix] ${formatTimestamp(timeMs, trusted)} name=$name note=$note$shortNote")
                }
                builder.appendLine()
            }
        }
        val sampleSql = if (maxElapsedMs != null) {
            "SELECT * FROM obd_samples WHERE session_id=? AND elapsed_ms<=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC"
        } else {
            "SELECT * FROM obd_samples WHERE session_id=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC"
        }
        val sampleArgs = if (maxElapsedMs != null) arrayOf(id.toString(), maxElapsedMs.toString()) else arrayOf(id.toString())
        db.rawQuery(sampleSql, sampleArgs).use { c ->
            builder.appendLine("[SAMPLES] count=${c.count}")
            builder.appendLine(if (includeRaw) "format=summary+raw; raw ECU packets included when available" else "format=summary; raw ECU packets omitted")
            while (c.moveToNext()) {
                val trusted = c.optInt("time_trusted") == 1
                val at = if (trusted) formatTime(c.long("time_ms")) else "TIME_PENDING+${c.optLong("elapsed_ms") ?: 0L}ms"
                val line = "[LOOP #${c.str("loop_index") ?: "--"} at=$at ${c.long("loop_ms")}ms] " +
                    "speed=${c.str("speed_kmh") ?: "--"} rpm=${c.str("rpm") ?: "--"} temp=${c.str("coolant_c") ?: "--"} " +
                    "fuel=${c.str("fuel_mg") ?: "--"} instant=${c.str("instant_value") ?: "--"} ${c.str("instant_unit") ?: ""} " +
                    "pedal=${c.str("pedal_percent") ?: "--"} map=${c.str("map_mbar") ?: "--"} air=${c.str("air_charge") ?: "--"} " +
                    "ac=${c.str("ac_on") ?: "--"} src=${c.str("fuel_source") ?: "--"} " +
                    "trip=${c.str("trip_state") ?: "--"} dist=${c.str("trip_distance_km") ?: "--"} fuelUsed=${c.str("fuel_used_l") ?: "--"} avg=${c.str("avg_l100") ?: "--"}"
                builder.appendLine(line)
                val raw21cc = c.str("raw21cc")
                val raw21a0 = c.str("raw21a0")
                val raw21a2 = c.str("raw21a2")
                val raw21cd = c.str("raw21cd")
                val rawObd = c.str("raw_obd")
                if (includeRaw && (!raw21cc.isNullOrBlank() || !raw21a0.isNullOrBlank() || !raw21a2.isNullOrBlank() || !raw21cd.isNullOrBlank() || !rawObd.isNullOrBlank())) {
                    if (!rawObd.isNullOrBlank()) builder.appendLine("RAW OBD=$rawObd")
                    if (!raw21cc.isNullOrBlank()) builder.appendLine("RAW 21CC=$raw21cc")
                    if (!raw21a0.isNullOrBlank()) builder.appendLine("RAW 21A0=$raw21a0")
                    if (!raw21a2.isNullOrBlank()) builder.appendLine("RAW 21A2=$raw21a2")
                    if (!raw21cd.isNullOrBlank()) builder.appendLine("RAW 21CD=$raw21cd")
                }
            }
        }
        return builder.toString()
    }


    fun recoverOpenHistory(): Pair<Int, Int> {
        val mark = currentMark()
        val db = writableDatabase
        var tripCount: Int
        var testCount = 0
        db.beginTransaction()
        try {
            // A head unit can lose power without lifecycle callbacks. The trip
            // row is updated on every stored OBD sample, so its existing end mark
            // is the best estimate of the real ignition-off moment. Only change
            // the state here; do not stretch the trip until the next app launch.
            tripCount = db.update(
                "trip_records",
                ContentValues().apply { put("status", "PARKED") },
                "status='ACTIVE'",
                emptyArray()
            )

            val activeTests = mutableListOf<Long>()
            db.rawQuery("SELECT id FROM test_sessions WHERE status='ACTIVE'", emptyArray()).use { c ->
                while (c.moveToNext()) activeTests += c.getLong(0)
            }
            activeTests.forEach { id ->
                val last = latestTestStoredMark(db, id)
                val values = ContentValues().apply {
                    put("status", "INTERRUPTED")
                    put("ended_at_ms", last?.epochMs ?: (mark.epochMs ?: 0L))
                    put("ended_elapsed_ms", last?.elapsedMs ?: mark.elapsedMs)
                    put("end_boot_session_id", last?.bootSessionId ?: mark.bootSessionId)
                    put("end_time_trusted", if (last?.trusted ?: mark.trusted) 1 else 0)
                    put("summary", "Kontak veya uygulama kapanışı nedeniyle yarım kaldı")
                }
                db.update("test_sessions", values, "id=?", arrayOf(id.toString()))
                testCount++
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return tripCount to testCount
    }

    fun upsertTripRecord(
        sessionId: Long?,
        tripToken: Long,
        snapshot: DashboardSnapshot,
        durationMs: Long,
        versionName: String
    ): Long? {
        if (tripToken == 0L) return null
        val distance = snapshot.tripDistanceKm ?: 0.0
        val meaningful = distance > 0.00001 || (snapshot.tripStateText != null && snapshot.tripStateText != "Sürüş bekleniyor")
        if (!meaningful) return findTripRecordId(tripToken)
        val mark = currentMark()
        val db = writableDatabase
        var recordId = findTripRecordId(db, tripToken)
        db.beginTransaction()
        try {
            if (recordId == null) {
                val values = ContentValues().apply {
                    put("trip_token", tripToken)
                    put("started_at_ms", mark.epochMs ?: 0L)
                    put("started_elapsed_ms", mark.elapsedMs)
                    put("start_boot_session_id", mark.bootSessionId)
                    put("start_time_trusted", if (mark.trusted) 1 else 0)
                    put("ended_at_ms", mark.epochMs ?: 0L)
                    put("ended_elapsed_ms", mark.elapsedMs)
                    put("end_boot_session_id", mark.bootSessionId)
                    put("end_time_trusted", if (mark.trusted) 1 else 0)
                    put("status", "ACTIVE")
                    put("distance_km", distance)
                    put("fuel_used_l", snapshot.fuelUsedL ?: 0.0)
                    put("duration_ms", durationMs.coerceAtLeast(0L))
                    putNullable("average_l100", snapshot.averageConsumption)
                    putNullable("max_speed_kmh", snapshot.speedKmh)
                    putNullable("max_rpm", snapshot.rpm)
                    putNullable("start_temp_c", snapshot.engineTempC)
                    putNullable("end_temp_c", snapshot.engineTempC)
                    put("sample_count", 1)
                    if (sessionId != null) {
                        put("first_session_id", sessionId)
                        put("last_session_id", sessionId)
                    }
                    put("created_version", versionName)
                }
                recordId = db.insertOrThrow("trip_records", null, values)
            } else {
                val values = ContentValues().apply {
                    put("ended_at_ms", mark.epochMs ?: 0L)
                    put("ended_elapsed_ms", mark.elapsedMs)
                    put("end_boot_session_id", mark.bootSessionId)
                    put("end_time_trusted", if (mark.trusted) 1 else 0)
                    put("status", "ACTIVE")
                    put("distance_km", distance)
                    put("fuel_used_l", snapshot.fuelUsedL ?: 0.0)
                    put("duration_ms", durationMs.coerceAtLeast(0L))
                    putNullable("average_l100", snapshot.averageConsumption)
                    snapshot.engineTempC?.let { put("end_temp_c", it) }
                    if (sessionId != null) put("last_session_id", sessionId)
                }
                val updated = db.update(
                    "trip_records",
                    values,
                    "id=? AND status IN ('ACTIVE','PARKED','TIME_PENDING')",
                    arrayOf(recordId.toString())
                )
                if (updated == 0) {
                    // A completed trip is immutable. A stale polling iteration with
                    // the old trip token must never resurrect it as ACTIVE.
                    recordId = null
                } else {
                    snapshot.speedKmh?.let {
                        db.execSQL("UPDATE trip_records SET max_speed_kmh=MAX(COALESCE(max_speed_kmh,0),?), sample_count=sample_count+1 WHERE id=?", arrayOf(it, recordId))
                    } ?: db.execSQL("UPDATE trip_records SET sample_count=sample_count+1 WHERE id=?", arrayOf(recordId))
                    snapshot.rpm?.let {
                        db.execSQL("UPDATE trip_records SET max_rpm=MAX(COALESCE(max_rpm,0),?) WHERE id=?", arrayOf(it, recordId))
                    }
                    if (snapshot.engineTempC != null) {
                        db.execSQL("UPDATE trip_records SET start_temp_c=COALESCE(start_temp_c,?) WHERE id=?", arrayOf(snapshot.engineTempC, recordId))
                    }
                }
            }
            val linkedRecordId = recordId
            if (sessionId != null && linkedRecordId != null) {
                val sessionValues = ContentValues().apply { put("trip_record_id", linkedRecordId) }
                db.update("drive_sessions", sessionValues, "id=?", arrayOf(sessionId.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return recordId
    }

    fun findTripRecordId(tripToken: Long): Long? = findTripRecordId(readableDatabase, tripToken)

    fun assignSessionToTrip(sessionId: Long?, tripRecordId: Long?) {
        if (sessionId == null || tripRecordId == null) return
        val values = ContentValues().apply { put("trip_record_id", tripRecordId) }
        writableDatabase.update("drive_sessions", values, "id=?", arrayOf(sessionId.toString()))
    }

    fun parkTripRecord(
        recordId: Long?,
        endMark: TimeMark? = null,
        distanceKm: Double? = null,
        fuelUsedL: Double? = null,
        durationMs: Long? = null,
        averageL100: Double? = null,
        endTempC: Int? = null
    ) {
        if (recordId == null) return
        val mark = endMark ?: currentMark()
        val values = ContentValues().apply {
            put("status", "PARKED")
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            distanceKm?.let { put("distance_km", it.coerceAtLeast(0.0)) }
            fuelUsedL?.let { put("fuel_used_l", it.coerceAtLeast(0.0)) }
            durationMs?.let { put("duration_ms", it.coerceAtLeast(0L)) }
            averageL100?.let { put("average_l100", it) }
            endTempC?.let { put("end_temp_c", it) }
        }
        writableDatabase.update(
            "trip_records",
            values,
            "id=? AND status IN ('ACTIVE','PARKED','TIME_PENDING')",
            arrayOf(recordId.toString())
        )
    }

    fun finalizeTripRecord(
        tripToken: Long,
        distanceKm: Double,
        fuelUsedL: Double,
        durationMs: Long,
        averageL100: Double?,
        state: String = "ENDED",
        endMark: TimeMark? = null
    ): Long? {
        val recordId = findTripRecordId(tripToken) ?: return null
        val mark = endMark ?: currentMark()
        val values = ContentValues().apply {
            put("status", state)
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("distance_km", distanceKm.coerceAtLeast(0.0))
            put("fuel_used_l", fuelUsedL.coerceAtLeast(0.0))
            put("duration_ms", durationMs.coerceAtLeast(0L))
            putNullable("average_l100", averageL100)
        }
        val updated = writableDatabase.update(
            "trip_records",
            values,
            "id=? AND status IN ('ACTIVE','PARKED','TIME_PENDING')",
            arrayOf(recordId.toString())
        )
        return recordId.takeIf { updated > 0 }
    }

    fun listDriveHistory(maxItems: Int = 200): List<DriveHistoryItem> {
        val result = mutableListOf<DriveHistoryItem>()
        val sql = """
            SELECT r.id,r.trip_token,r.started_at_ms,r.ended_at_ms,r.start_time_trusted,r.end_time_trusted,
                   r.status,r.pinned,r.exported_at_ms,r.distance_km,r.fuel_used_l,r.duration_ms,r.average_l100,
                   r.max_speed_kmh,r.max_rpm,r.start_temp_c,r.end_temp_c,
                   (SELECT COUNT(*) FROM drive_sessions s
                    WHERE s.trip_record_id=r.id
                      AND EXISTS(SELECT 1 FROM obd_samples os WHERE os.session_id=s.id)
                      AND (
                          r.ended_elapsed_ms IS NULL OR
                          r.end_boot_session_id IS NULL OR
                          s.boot_session_id != r.end_boot_session_id OR
                          s.started_elapsed_ms <= r.ended_elapsed_ms
                      )) AS session_count
            FROM trip_records r
            WHERE r.distance_km>0.00001 OR r.sample_count>0
            ORDER BY CASE WHEN r.status='ACTIVE' THEN 0 WHEN r.status='PARKED' THEN 1 ELSE 2 END,
                     COALESCE(r.ended_at_ms,r.started_at_ms) DESC, r.id DESC
            LIMIT ?
        """.trimIndent()
        readableDatabase.rawQuery(sql, arrayOf(maxItems.toString())).use { c ->
            while (c.moveToNext()) {
                val end = if (c.isNull(3)) null else c.getLong(3)
                result += DriveHistoryItem(
                    id = c.getLong(0),
                    tripToken = c.getLong(1),
                    startedAtMs = c.getLong(2),
                    endedAtMs = end,
                    timeTrusted = c.getInt(4) == 1 && (end == null || c.getInt(5) == 1),
                    status = c.getString(6),
                    pinned = c.getInt(7) == 1,
                    exported = !c.isNull(8),
                    distanceKm = c.getDouble(9),
                    fuelUsedL = c.getDouble(10),
                    durationMs = c.getLong(11),
                    averageL100 = if (c.isNull(12)) null else c.getDouble(12),
                    maxSpeedKmh = if (c.isNull(13)) null else c.getInt(13),
                    maxRpm = if (c.isNull(14)) null else c.getInt(14),
                    startTempC = if (c.isNull(15)) null else c.getInt(15),
                    endTempC = if (c.isNull(16)) null else c.getInt(16),
                    sessionCount = c.getInt(17)
                )
            }
        }
        return result
    }


    /**
     * Builds conservative vehicle-health evidence from persisted drive evidence.
     * PARKED records are already stopped snapshots of real driving and must not
     * be discarded merely because Smart Trip keeps them provisional until the
     * next ignition. ACTIVE is still excluded so a live trip can never become a
     * moving health baseline. This remains read-only: no schema change and no
     * synthetic samples are created.
     */
    fun loadVehicleHealthEvidence(maxTrips: Int = 10): VehicleHealthEvidence {
        val eligibleDrives = listDriveHistory(maxItems = 100)
            .filter { it.healthEligible }
            .take(maxTrips.coerceIn(3, 20))

        val warmDriveEndTemps = eligibleDrives
            .filter { it.durationMs >= 20L * 60L * 1000L }
            .mapNotNull { it.endTempC }
            .filter { it in -20..130 }

        val warmupDurations = mutableListOf<Long>()
        val warmIdleRpms = mutableListOf<Int>()

        eligibleDrives.forEach { drive ->
            var activeSessionId: Long? = null
            var warmupStartElapsed: Long? = null
            var warmupCapturedForSession = false

            readableDatabase.rawQuery(
                """
                SELECT d.id,s.elapsed_ms,s.rpm,s.speed_kmh,s.coolant_c,s.loop_ms
                FROM obd_samples s
                JOIN drive_sessions d ON d.id=s.session_id
                WHERE d.trip_record_id=?
                ORDER BY d.id ASC,s.elapsed_ms ASC,s.id ASC
                """.trimIndent(),
                arrayOf(drive.id.toString())
            ).use { c ->
                while (c.moveToNext()) {
                    val sessionId = c.getLong(0)
                    if (activeSessionId != sessionId) {
                        activeSessionId = sessionId
                        warmupStartElapsed = null
                        warmupCapturedForSession = false
                    }
                    val elapsed = c.getLong(1)
                    val rpm = if (c.isNull(2)) null else c.getInt(2)
                    val speed = if (c.isNull(3)) null else c.getInt(3)
                    val coolant = if (c.isNull(4)) null else c.getInt(4)
                    val loopMs = if (c.isNull(5)) 0L else c.getLong(5)

                    val engineRunning = (rpm ?: 0) >= 500
                    if (!warmupCapturedForSession && engineRunning && coolant != null) {
                        if (warmupStartElapsed == null && coolant <= 60) {
                            warmupStartElapsed = elapsed
                        }
                        val start = warmupStartElapsed
                        if (start != null && coolant >= 75) {
                            val duration = elapsed - start
                            if (duration in 2L * 60L * 1000L..35L * 60L * 1000L) {
                                warmupDurations += duration
                            }
                            warmupCapturedForSession = true
                        }
                    }

                    val trustworthyLoop = loopMs in 1L..3_000L
                    val warmIdle = trustworthyLoop && coolant != null && coolant >= 75 &&
                        (speed ?: Int.MAX_VALUE) <= 2 && rpm != null && rpm in 600..1_200
                    if (warmIdle) warmIdleRpms += rpm!!
                }
            }
        }

        val consumptionDrives = eligibleDrives
            .filter {
                it.distanceKm >= 5.0 &&
                    it.durationMs >= 10L * 60L * 1000L &&
                    it.averageL100 != null &&
                    it.averageL100 in 2.0..20.0
            }
            .take(6)
        val recentConsumption = weightedConsumption(consumptionDrives.take(3))
        val previousConsumption = weightedConsumption(consumptionDrives.drop(3).take(3))

        return VehicleHealthEvidence(
            // Kept for UI/API compatibility; semantically this is the number
            // of persisted non-ACTIVE drives currently eligible for health evidence.
            completedDriveCount = eligibleDrives.size,
            qualifiedWarmDriveCount = warmDriveEndTemps.size,
            medianEndTempC = medianDouble(warmDriveEndTemps.map { it.toDouble() }),
            warmupObservationCount = warmupDurations.size,
            medianWarmupMs = medianLong(warmupDurations),
            warmIdleSampleCount = warmIdleRpms.size,
            idleMeanRpm = warmIdleRpms.takeIf { it.isNotEmpty() }?.average(),
            idleSpreadRpm = robustSpread(warmIdleRpms),
            consumptionComparisonDriveCount = consumptionDrives.size,
            recentConsumptionL100 = recentConsumption,
            previousConsumptionL100 = previousConsumption
        )
    }

    private fun weightedConsumption(items: List<DriveHistoryItem>): Double? {
        val valid = items.filter { it.averageL100 != null && it.distanceKm > 0.0 }
        if (valid.isEmpty()) return null
        val distance = valid.sumOf { it.distanceKm }
        if (distance <= 0.0) return null
        return valid.sumOf { (it.averageL100 ?: 0.0) * it.distanceKm } / distance
    }

    private fun medianDouble(values: List<Double>): Double? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2.0 else sorted[mid]
    }

    private fun medianLong(values: List<Long>): Long? {
        if (values.isEmpty()) return null
        val sorted = values.sorted()
        val mid = sorted.size / 2
        return if (sorted.size % 2 == 0) (sorted[mid - 1] + sorted[mid]) / 2L else sorted[mid]
    }

    private fun robustSpread(values: List<Int>): Int? {
        if (values.size < 20) return null
        val sorted = values.sorted()
        val p10 = sorted[((sorted.lastIndex) * 0.10).toInt()]
        val p90 = sorted[((sorted.lastIndex) * 0.90).toInt()]
        return (p90 - p10).coerceAtLeast(0)
    }

    fun loadDriveHistoryDetail(recordId: Long, maxPoints: Int = 180): DriveHistoryDetail? {
        val tripTotals = readableDatabase.rawQuery(
            "SELECT distance_km,fuel_used_l FROM trip_records WHERE id=? LIMIT 1",
            arrayOf(recordId.toString())
        ).use { c ->
            if (!c.moveToFirst()) return null
            c.getDouble(0).coerceAtLeast(0.0) to c.getDouble(1).coerceAtLeast(0.0)
        }

        data class RawPoint(
            val speed: Float?,
            val rpm: Float?,
            val coolant: Float?,
            val consumption: Float?,
            val loopMs: Long,
            val fuelUsedL: Double?,
            val acOn: Boolean?,
            val fuelSource: String?
        )

        val raw = mutableListOf<RawPoint>()
        readableDatabase.rawQuery(
            """
            SELECT s.speed_kmh,s.rpm,s.coolant_c,s.instant_value,s.instant_unit,s.loop_ms,s.fuel_used_l,s.ac_on,s.fuel_source
            FROM obd_samples s
            JOIN drive_sessions d ON d.id=s.session_id
            WHERE d.trip_record_id=?
            ORDER BY d.id ASC,s.elapsed_ms ASC,s.id ASC
            """.trimIndent(),
            arrayOf(recordId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val unit = if (c.isNull(4)) null else c.getString(4)
                raw += RawPoint(
                    speed = if (c.isNull(0)) null else c.getInt(0).toFloat(),
                    rpm = if (c.isNull(1)) null else c.getInt(1).toFloat(),
                    coolant = if (c.isNull(2)) null else c.getInt(2).toFloat(),
                    consumption = if (!c.isNull(3) && unit.equals("L/100 km", ignoreCase = true)) c.getDouble(3).toFloat() else null,
                    loopMs = if (c.isNull(5)) 0L else c.getLong(5).coerceIn(0L, 3_000L),
                    fuelUsedL = if (c.isNull(6)) null else c.getDouble(6),
                    acOn = if (c.isNull(7)) null else c.getInt(7) == 1,
                    fuelSource = if (c.isNull(8)) null else c.getString(8)
                )
            }
        }

        var analyzedDurationMs = 0L
        var engineRunningDurationMs = 0L
        var movingDurationMs = 0L
        var stationaryDurationMs = 0L
        var stationaryFuelUsedL = 0.0
        var previousFuel: Double? = null
        var acKnownDurationMs = 0L
        var acOnDurationMs = 0L
        var fuelSourceKnownDurationMs = 0L
        var cutoffDurationMs = 0L

        val trustworthyFuelSources = setOf("INJECTION", "HOLD", "CUTOFF", "COAST_GUARD", "CRANK_GUARD")

        raw.forEach { point ->
            val duration = point.loopMs
            if (duration > 0L) analyzedDurationMs += duration

            val engineRunning = (point.rpm ?: 0f) >= 500f
            val moving = (point.speed ?: 0f) >= 5f && engineRunning
            val stationary = (point.speed ?: 0f) < 5f && engineRunning

            if (engineRunning) {
                engineRunningDurationMs += duration
                if (moving) movingDurationMs += duration
                if (stationary) stationaryDurationMs += duration

                point.acOn?.let { acOn ->
                    acKnownDurationMs += duration
                    if (acOn) acOnDurationMs += duration
                }

                val normalizedSource = point.fuelSource?.uppercase(Locale.US)
                if (moving && normalizedSource in trustworthyFuelSources) {
                    fuelSourceKnownDurationMs += duration
                    if (normalizedSource == "CUTOFF") cutoffDurationMs += duration
                }
            }

            val currentFuel = point.fuelUsedL
            val deltaFuel = if (currentFuel != null && previousFuel != null) {
                (currentFuel - previousFuel!!).coerceAtLeast(0.0)
            } else {
                0.0
            }
            if (stationary && deltaFuel <= 0.05) stationaryFuelUsedL += deltaFuel
            if (currentFuel != null) previousFuel = currentFuel
        }

        val totalDistanceKm = tripTotals.first
        val totalFuelUsedL = tripTotals.second
        val movingFuelUsedL = (totalFuelUsedL - stationaryFuelUsedL)
            .takeIf { totalFuelUsedL > 0.0 && it >= 0.0 }
            ?.coerceAtMost(totalFuelUsedL)
        val movingAverageL100 = movingFuelUsedL
            ?.takeIf { totalDistanceKm >= 0.1 }
            ?.let { it / totalDistanceKm * 100.0 }
        val averageMovingSpeedKmh = if (totalDistanceKm >= 0.1 && movingDurationMs >= 60_000L) {
            totalDistanceKm / (movingDurationMs / 3_600_000.0)
        } else {
            null
        }

        val target = maxPoints.coerceIn(24, 360)
        val sampled = if (raw.size <= target) raw else {
            val result = ArrayList<RawPoint>(target)
            for (i in 0 until target) {
                val index = ((i.toLong() * (raw.size - 1)) / (target - 1)).toInt()
                result += raw[index]
            }
            result
        }
        val lastIndex = (sampled.size - 1).coerceAtLeast(1)
        val points = sampled.mapIndexed { index, point ->
            DriveHistoryChartPoint(
                progress = index.toFloat() / lastIndex.toFloat(),
                speedKmh = point.speed,
                rpm = point.rpm,
                coolantC = point.coolant,
                consumption = point.consumption
            )
        }
        val gpsRoute = loadGpsRoute(recordId)
        return DriveHistoryDetail(
            recordId = recordId,
            points = points,
            sampleCount = raw.size,
            analyzedDurationMs = analyzedDurationMs,
            engineRunningDurationMs = engineRunningDurationMs,
            movingDurationMs = movingDurationMs,
            stationaryDurationMs = stationaryDurationMs,
            stationaryFuelUsedL = stationaryFuelUsedL,
            movingFuelUsedL = movingFuelUsedL,
            movingAverageL100 = movingAverageL100,
            averageMovingSpeedKmh = averageMovingSpeedKmh,
            acKnownDurationMs = acKnownDurationMs,
            acOnDurationMs = acOnDurationMs,
            fuelSourceKnownDurationMs = fuelSourceKnownDurationMs,
            cutoffDurationMs = cutoffDurationMs,
            gpsRoute = gpsRoute
        )
    }

    fun setTripPinned(id: Long, pinned: Boolean): Boolean {
        val values = ContentValues().apply { put("pinned", if (pinned) 1 else 0) }
        return writableDatabase.update("trip_records", values, "id=?", arrayOf(id.toString())) > 0
    }

    fun deleteTripRecord(id: Long): Boolean {
        val db = writableDatabase
        val status = db.rawQuery("SELECT status FROM trip_records WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: return false
        if (status == "ACTIVE" || status == "PARKED" || status == "TIME_PENDING") return false
        db.beginTransaction()
        return try {
            db.delete("drive_sessions", "trip_record_id=?", arrayOf(id.toString()))
            val deleted = db.delete("trip_records", "id=?", arrayOf(id.toString())) > 0
            db.setTransactionSuccessful()
            deleted
        } finally {
            db.endTransaction()
        }
    }

    fun startTestSession(
        driveSessionId: Long?,
        testType: String,
        name: String,
        versionName: String,
        note: String? = null
    ): Long {
        val mark = currentMark()
        val values = ContentValues().apply {
            if (driveSessionId != null) put("drive_session_id", driveSessionId)
            put("test_type", testType)
            put("name", name)
            put("started_at_ms", mark.epochMs ?: 0L)
            put("started_elapsed_ms", mark.elapsedMs)
            put("start_boot_session_id", mark.bootSessionId)
            put("start_time_trusted", if (mark.trusted) 1 else 0)
            put("status", "ACTIVE")
            put("created_version", versionName)
            put("summary", note)
        }
        return writableDatabase.insertOrThrow("test_sessions", null, values)
    }

    fun insertTestSample(
        testSessionId: Long?,
        loopIndex: Int,
        loopMs: Long,
        snapshot: DashboardSnapshot,
        raw21cc: String,
        raw21a0: String,
        raw21a2: String,
        raw21cd: String,
        rawObd: String = ""
    ) {
        if (testSessionId == null) return
        val mark = currentMark()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val values = ContentValues().apply {
                put("test_session_id", testSessionId)
                putTime(mark)
                put("loop_index", loopIndex)
                put("loop_ms", loopMs)
                putNullable("rpm", snapshot.rpm)
                putNullable("speed_kmh", snapshot.speedKmh)
                putNullable("coolant_c", snapshot.engineTempC)
                putNullable("fuel_mg", snapshot.injectionMg)
                putNullable("instant_value", snapshot.instantConsumption)
                put("instant_unit", snapshot.instantUnit)
                putNullable("pedal_percent", snapshot.pedalPercent)
                putNullable("map_mbar", snapshot.mapMbar)
                putNullable("air_charge", snapshot.airCharge)
                putNullable("ac_on", snapshot.acOn?.let { if (it) 1 else 0 })
                putNull("fan_state")
                put("fuel_source", snapshot.fuelSource)
                put("trip_state", snapshot.tripStateText)
                putNullable("trip_distance_km", snapshot.tripDistanceKm)
                putNullable("fuel_used_l", snapshot.fuelUsedL)
                putNullable("avg_l100", snapshot.averageConsumption)
                put("raw21cc", raw21cc)
                put("raw21a0", raw21a0)
                put("raw21a2", raw21a2)
                put("raw21cd", raw21cd)
                put("raw_obd", rawObd)
            }
            db.insertOrThrow("test_samples", null, values)
            val sessionValues = ContentValues().apply {
                put("ended_at_ms", mark.epochMs ?: 0L)
                put("ended_elapsed_ms", mark.elapsedMs)
                put("end_boot_session_id", mark.bootSessionId)
                put("end_time_trusted", if (mark.trusted) 1 else 0)
            }
            db.update("test_sessions", sessionValues, "id=? AND status='ACTIVE'", arrayOf(testSessionId.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun endTestSession(testSessionId: Long?, status: String = "COMPLETED", summary: String? = null) {
        if (testSessionId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("status", status)
            if (summary != null) put("summary", summary)
        }
        writableDatabase.update("test_sessions", values, "id=?", arrayOf(testSessionId.toString()))
    }

    fun listTestHistory(maxItems: Int = 200): List<TestHistoryItem> {
        val result = mutableListOf<TestHistoryItem>()
        val sql = """
            SELECT t.id,t.name,t.test_type,t.started_at_ms,t.ended_at_ms,t.start_time_trusted,t.end_time_trusted,
                   t.status,t.pinned,t.exported_at_ms,
                   CASE WHEN t.ended_elapsed_ms IS NOT NULL THEN MAX(0,t.ended_elapsed_ms-t.started_elapsed_ms) ELSE 0 END AS duration_ms,
                   (SELECT COUNT(*) FROM test_samples s WHERE s.test_session_id=t.id) AS sample_count,t.summary
            FROM test_sessions t
            ORDER BY CASE WHEN t.status='ACTIVE' THEN 0 ELSE 1 END, COALESCE(t.ended_at_ms,t.started_at_ms) DESC,t.id DESC
            LIMIT ?
        """.trimIndent()
        readableDatabase.rawQuery(sql, arrayOf(maxItems.toString())).use { c ->
            while (c.moveToNext()) {
                val end = if (c.isNull(4)) null else c.getLong(4)
                result += TestHistoryItem(
                    id = c.getLong(0),
                    name = c.getString(1),
                    testType = c.getString(2),
                    startedAtMs = c.getLong(3),
                    endedAtMs = end,
                    timeTrusted = c.getInt(5) == 1 && (end == null || c.getInt(6) == 1),
                    status = c.getString(7),
                    pinned = c.getInt(8) == 1,
                    exported = !c.isNull(9),
                    durationMs = c.getLong(10),
                    sampleCount = c.getInt(11),
                    summary = if (c.isNull(12)) null else c.getString(12)
                )
            }
        }
        return result
    }

    fun setTestPinned(id: Long, pinned: Boolean): Boolean {
        val values = ContentValues().apply { put("pinned", if (pinned) 1 else 0) }
        return writableDatabase.update("test_sessions", values, "id=?", arrayOf(id.toString())) > 0
    }

    fun deleteTestRecord(id: Long): Boolean {
        val db = writableDatabase
        val status = db.rawQuery("SELECT status FROM test_sessions WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: return false
        if (status == "ACTIVE") return false
        return db.delete("test_sessions", "id=?", arrayOf(id.toString())) > 0
    }

    fun applyHistoryRetention(driveLimit: Int, testLimit: Int): Pair<Int, Int> {
        val db = writableDatabase
        var driveDeleted = 0
        var testDeleted = 0
        db.beginTransaction()
        try {
            if (driveLimit >= 0) {
                val ids = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT id FROM trip_records WHERE pinned=0 AND status NOT IN ('ACTIVE','PARKED','TIME_PENDING') ORDER BY COALESCE(ended_at_ms,started_at_ms) DESC,id DESC LIMIT -1 OFFSET ?",
                    arrayOf(driveLimit.toString())
                ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
                ids.forEach { id ->
                    db.delete("drive_sessions", "trip_record_id=?", arrayOf(id.toString()))
                    driveDeleted += db.delete("trip_records", "id=?", arrayOf(id.toString()))
                }
            }
            if (testLimit >= 0) {
                val ids = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT id FROM test_sessions WHERE pinned=0 AND status<>'ACTIVE' ORDER BY COALESCE(ended_at_ms,started_at_ms) DESC,id DESC LIMIT -1 OFFSET ?",
                    arrayOf(testLimit.toString())
                ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
                ids.forEach { id -> testDeleted += db.delete("test_sessions", "id=?", arrayOf(id.toString())) }
            }
            // Legacy/technical sessions without a trip_record_id are never pruned
            // automatically. They may contain beta logs the user has not exported.
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return driveDeleted to testDeleted
    }

    fun historyStorageInfo(): HistoryStorageInfo {
        val db = readableDatabase
        fun count(sql: String): Int = db.rawQuery(sql, emptyArray()).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        val driveCount = count("SELECT COUNT(*) FROM trip_records")
        val testCount = count("SELECT COUNT(*) FROM test_sessions")
        val pinnedDrive = count("SELECT COUNT(*) FROM trip_records WHERE pinned=1")
        val pinnedTest = count("SELECT COUNT(*) FROM test_sessions WHERE pinned=1")
        val driveSamples = count("SELECT COUNT(*) FROM obd_samples s JOIN drive_sessions d ON d.id=s.session_id WHERE d.trip_record_id IS NOT NULL")
        val testSamples = count("SELECT COUNT(*) FROM test_samples")
        val gpsPoints = count("SELECT COUNT(*) FROM gps_points")
        val dbFile = databaseFile()
        val total = listOf(dbFile, File(dbFile.absolutePath + "-wal"), File(dbFile.absolutePath + "-shm")).sumOf { if (it.exists()) it.length() else 0L }
        val driveApprox = driveSamples * 240L + gpsPoints * 96L + driveCount * 1024L
        val testApprox = testSamples * 240L + testCount * 768L
        return HistoryStorageInfo(driveCount, testCount, pinnedDrive, pinnedTest, driveApprox, testApprox, total)
    }

    fun exportTripRecordText(recordId: Long, includeRaw: Boolean = false): String? {
        val item = listDriveHistory(500).firstOrNull { it.id == recordId } ?: return null
        val finalAverageL100 = if (item.distanceKm > 0.001 && item.fuelUsedL >= 0.0) {
            item.fuelUsedL / item.distanceKm * 100.0
        } else null
        val builder = StringBuilder().apply {
            appendLine("LOGANOS DRIVE HISTORY EXPORT")
            appendLine("record_id=${item.id}")
            appendLine("status=${item.status}")
            appendLine("pinned=${item.pinned}")
            appendLine("started=${formatTimestamp(item.startedAtMs, item.timeTrusted)}")
            appendLine("ended=${formatTimestamp(item.endedAtMs ?: 0L, item.timeTrusted)}")
            appendLine("duration=${formatDuration(item.durationMs)}")
            appendLine("distance_km=${String.format(Locale.US, "%.3f", item.distanceKm)}")
            appendLine("fuel_used_l=${String.format(Locale.US, "%.4f", item.fuelUsedL)}")
            appendLine("average_l100=${finalAverageL100?.let { String.format(Locale.US, "%.3f", it) } ?: "--"}")
            appendLine("average_source=final_fuel_used_l/final_distance_km")
            appendLine("max_speed_kmh=${item.maxSpeedKmh ?: "--"}")
            appendLine("max_rpm=${item.maxRpm ?: "--"}")
            appendLine("start_temp_c=${item.startTempC ?: "--"}")
            appendLine("end_temp_c=${item.endTempC ?: "--"}")
            appendLine("obd_sessions=${item.sessionCount}")
            appendLine(if (includeRaw) "format=summary+raw; raw ECU packets included when available" else "format=summary; raw ECU packets omitted")
            appendLine()
        }
        val logicalEnd = readableDatabase.rawQuery(
            "SELECT ended_elapsed_ms,end_boot_session_id FROM trip_records WHERE id=?",
            arrayOf(recordId.toString())
        ).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) {
                c.getLong(0) to (if (c.isNull(1)) null else c.getString(1))
            } else null
        }
        data class ExportSession(val id: Long, val bootId: String, val startedElapsedMs: Long)
        val sessions = mutableListOf<ExportSession>()
        readableDatabase.rawQuery(
            """
            SELECT d.id,d.boot_session_id,d.started_elapsed_ms
            FROM drive_sessions d
            WHERE d.trip_record_id=?
              AND EXISTS(SELECT 1 FROM obd_samples os WHERE os.session_id=d.id)
            ORDER BY d.id ASC
            """.trimIndent(),
            arrayOf(recordId.toString())
        ).use { c ->
            while (c.moveToNext()) {
                val candidate = ExportSession(c.getLong(0), c.getString(1), c.getLong(2))
                val keep = logicalEnd == null || candidate.bootId != logicalEnd.second || candidate.startedElapsedMs <= logicalEnd.first
                if (keep) sessions += candidate
            }
        }
        sessions.forEachIndexed { index, session ->
            builder.appendLine("===== OBD SESSION ${index + 1}/${sessions.size} =====")
            val cutoff = logicalEnd?.takeIf { session.bootId == it.second }?.first
            builder.append(exportSessionText(session.id, includeRaw, maxElapsedMs = cutoff) ?: "")
            builder.appendLine()
        }
        val mark = currentMark()
        val values = ContentValues().apply { put("exported_at_ms", mark.epochMs ?: 0L) }
        writableDatabase.update("trip_records", values, "id=?", arrayOf(recordId.toString()))
        return builder.toString()
    }

    fun exportTestRecordText(recordId: Long, includeRaw: Boolean = true): String? {
        val item = listTestHistory(500).firstOrNull { it.id == recordId } ?: return null
        val builder = StringBuilder().apply {
            appendLine("LOGANOS TEST HISTORY EXPORT")
            appendLine("record_id=${item.id}")
            appendLine("test_type=${item.testType}")
            appendLine("name=${item.name}")
            appendLine("status=${item.status}")
            appendLine("pinned=${item.pinned}")
            appendLine("started=${formatTimestamp(item.startedAtMs, item.timeTrusted)}")
            appendLine("ended=${formatTimestamp(item.endedAtMs ?: 0L, item.timeTrusted)}")
            appendLine("duration=${formatDuration(item.durationMs)}")
            appendLine("samples=${item.sampleCount}")
            appendLine("summary=${item.summary ?: "--"}")
            appendLine()
            appendLine("[SAMPLES]")
        }
        readableDatabase.rawQuery("SELECT * FROM test_samples WHERE test_session_id=? ORDER BY elapsed_ms ASC,id ASC", arrayOf(recordId.toString())).use { c ->
            while (c.moveToNext()) {
                val trusted = c.optInt("time_trusted") == 1
                val at = if (trusted) formatTime(c.long("time_ms")) else "TIME_PENDING+${c.optLong("elapsed_ms") ?: 0L}ms"
                builder.appendLine(
                    "[LOOP #${c.str("loop_index") ?: "--"} at=$at ${c.long("loop_ms")}ms] speed=${c.str("speed_kmh") ?: "--"} rpm=${c.str("rpm") ?: "--"} temp=${c.str("coolant_c") ?: "--"} fuel=${c.str("fuel_mg") ?: "--"} instant=${c.str("instant_value") ?: "--"} ${c.str("instant_unit") ?: ""} pedal=${c.str("pedal_percent") ?: "--"} map=${c.str("map_mbar") ?: "--"} air=${c.str("air_charge") ?: "--"} ac=${c.str("ac_on") ?: "--"} src=${c.str("fuel_source") ?: "--"} trip=${c.str("trip_state") ?: "--"} dist=${c.str("trip_distance_km") ?: "--"} fuelUsed=${c.str("fuel_used_l") ?: "--"} avg=${c.str("avg_l100") ?: "--"}"
                )
                if (includeRaw) {
                    val rawObd = c.str("raw_obd")
                    if (!rawObd.isNullOrBlank()) builder.appendLine("RAW OBD=$rawObd")
                    val rawValues = listOf("21CC" to c.str("raw21cc"), "21A0" to c.str("raw21a0"), "21A2" to c.str("raw21a2"), "21CD" to c.str("raw21cd"))
                    rawValues.filter { !it.second.isNullOrBlank() }.forEach { builder.appendLine("RAW ${it.first}=${it.second}") }
                }
            }
        }
        val mark = currentMark()
        val values = ContentValues().apply { put("exported_at_ms", mark.epochMs ?: 0L) }
        writableDatabase.update("test_sessions", values, "id=?", arrayOf(recordId.toString()))
        return builder.toString()
    }

    private fun findTripRecordId(db: SQLiteDatabase, tripToken: Long): Long? {
        return db.rawQuery("SELECT id FROM trip_records WHERE trip_token=? LIMIT 1", arrayOf(tripToken.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }
    }

    private fun latestTestStoredMark(db: SQLiteDatabase, testSessionId: Long): TestStoredMark? {
        return db.rawQuery(
            "SELECT time_ms,elapsed_ms,boot_session_id,time_trusted FROM test_samples WHERE test_session_id=? ORDER BY elapsed_ms DESC,id DESC LIMIT 1",
            arrayOf(testSessionId.toString())
        ).use { c ->
            if (c.moveToFirst()) TestStoredMark(c.getLong(0), c.getLong(1), c.getString(2), c.getInt(3) == 1) else null
        }
    }

    private fun pruneOrphanSessions(db: SQLiteDatabase, keep: Int) {
        val ids = mutableListOf<Long>()
        db.rawQuery(
            "SELECT id FROM drive_sessions WHERE trip_record_id IS NULL AND session_state<>'ACTIVE' ORDER BY id DESC LIMIT -1 OFFSET ?",
            arrayOf(keep.coerceAtLeast(0).toString())
        ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
        ids.forEach { db.delete("drive_sessions", "id=?", arrayOf(it.toString())) }
    }

    private fun currentMark(): TimeMark {
        val mark = timeSource.now()
        val epoch = mark.epochMs
        if (mark.trusted && epoch != null) {
            val offset = epoch - mark.elapsedMs
            val anchorChanged = anchoredBootId != mark.bootSessionId ||
                anchoredOffsetMs == null ||
                abs(offset - (anchoredOffsetMs ?: offset)) >= ANCHOR_REWRITE_TOLERANCE_MS
            if (anchorChanged) {
                applyTrustedAnchor(mark)
                anchoredBootId = mark.bootSessionId
                anchoredOffsetMs = offset
            }
        }
        return mark
    }

    /**
     * Rewrites every timestamp from the current boot from monotonic elapsed
     * time. This deliberately includes rows previously marked trusted: some
     * head units first expose a plausible but wrong clock and correct it after
     * GPS lock. Durations/order remain unchanged while wall time is repaired.
     */
    private fun applyTrustedAnchor(anchor: TimeMark) {
        val epoch = anchor.epochMs ?: return
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL(
                "UPDATE drive_sessions SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE drive_sessions SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE obd_samples SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_events SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE trip_records SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE start_boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE trip_records SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE end_boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_sessions SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE start_boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_sessions SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE end_boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_samples SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE gps_points SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE start_events SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun latestStoredMark(db: SQLiteDatabase, sessionId: Long): StoredMark? {
        val sql = """
            SELECT time_ms, elapsed_ms, time_trusted FROM (
                SELECT time_ms, elapsed_ms, time_trusted, id FROM obd_samples WHERE session_id=?
                UNION ALL
                SELECT time_ms, elapsed_ms, time_trusted, id FROM test_events WHERE session_id=?
            ) ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END DESC, time_ms DESC, id DESC LIMIT 1
        """.trimIndent()
        var result: StoredMark? = null
        db.rawQuery(sql, arrayOf(sessionId.toString(), sessionId.toString())).use { c ->
            if (c.moveToFirst()) {
                result = StoredMark(c.getLong(0), c.getLong(1), c.getInt(2) == 1)
            }
        }
        return result
    }

    private fun latestSessionId(): Long? {
        var result: Long? = null
        readableDatabase.rawQuery("SELECT id FROM drive_sessions ORDER BY id DESC LIMIT 1", emptyArray()).use { c ->
            if (c.moveToFirst()) result = c.getLong(0)
        }
        return result
    }

    private fun createHistoryTables(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS trip_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_token INTEGER NOT NULL UNIQUE,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                start_boot_session_id TEXT NOT NULL,
                end_boot_session_id TEXT,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                pinned INTEGER NOT NULL DEFAULT 0,
                exported_at_ms INTEGER,
                distance_km REAL NOT NULL DEFAULT 0,
                fuel_used_l REAL NOT NULL DEFAULT 0,
                duration_ms INTEGER NOT NULL DEFAULT 0,
                average_l100 REAL,
                max_speed_kmh INTEGER,
                max_rpm INTEGER,
                start_temp_c INTEGER,
                end_temp_c INTEGER,
                sample_count INTEGER NOT NULL DEFAULT 0,
                first_session_id INTEGER,
                last_session_id INTEGER,
                created_version TEXT NOT NULL,
                note TEXT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS test_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                drive_session_id INTEGER,
                test_type TEXT NOT NULL,
                name TEXT NOT NULL,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                start_boot_session_id TEXT NOT NULL,
                end_boot_session_id TEXT,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                pinned INTEGER NOT NULL DEFAULT 0,
                exported_at_ms INTEGER,
                created_version TEXT NOT NULL,
                summary TEXT,
                FOREIGN KEY(drive_session_id) REFERENCES drive_sessions(id) ON DELETE SET NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS test_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                loop_index INTEGER,
                loop_ms INTEGER,
                rpm INTEGER,
                speed_kmh INTEGER,
                coolant_c INTEGER,
                fuel_mg REAL,
                instant_value REAL,
                instant_unit TEXT,
                pedal_percent REAL,
                map_mbar INTEGER,
                air_charge REAL,
                ac_on INTEGER,
                fan_state TEXT,
                fuel_source TEXT,
                trip_state TEXT,
                trip_distance_km REAL,
                fuel_used_l REAL,
                avg_l100 REAL,
                raw21cc TEXT,
                raw21a0 TEXT,
                raw21a2 TEXT,
                raw21cd TEXT,
                raw_obd TEXT,
                FOREIGN KEY(test_session_id) REFERENCES test_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
    }


    @Synchronized
    fun insertStartEvent(event: StartEvent): Long {
        val values = ContentValues().apply {
            event.driveSessionId?.let { put("drive_session_id", it) }
            put("time_ms", event.timestampMs)
            put("elapsed_ms", event.elapsedMs)
            put("boot_session_id", timeSource.now().bootSessionId)
            put("time_trusted", if (event.timeTrusted) 1 else 0)
            event.engineTempC?.let { put("engine_temp_c", it) }
            put("thermal_class", event.thermalClass.name)
            event.crankDurationMs?.let { put("crank_duration_ms", it) }
            event.stabilizationDurationMs?.let { put("stabilization_duration_ms", it) }
            put("attempt_count", event.attemptCount.coerceAtLeast(1))
            put("successful", if (event.successful) 1 else 0)
            event.initialCrankRpm?.let { put("initial_crank_rpm", it) }
            event.initialRunningRpm?.let { put("initial_running_rpm", it) }
            event.peakStartRpm?.let { put("peak_start_rpm", it) }
            event.stableIdleRpm?.let { put("stable_idle_rpm", it) }
            put("confidence", event.confidence.name)
            put("obd_gap_detected", if (event.obdGapDetected) 1 else 0)
            put("manual_trigger", if (event.manualTrigger) 1 else 0)
            event.note?.let { put("note", it) }
        }
        val id = writableDatabase.insertOrThrow("start_events", null, values)
        trimStartEvents(200)
        return id
    }

    @Synchronized
    fun listStartEvents(limit: Int = 100): List<StartEvent> {
        val safeLimit = limit.coerceIn(1, 500)
        val result = mutableListOf<StartEvent>()
        readableDatabase.rawQuery(
            """
            SELECT id,drive_session_id,time_ms,elapsed_ms,time_trusted,engine_temp_c,thermal_class,
                   crank_duration_ms,stabilization_duration_ms,attempt_count,successful,
                   initial_crank_rpm,initial_running_rpm,peak_start_rpm,stable_idle_rpm,
                   confidence,obd_gap_detected,manual_trigger,note
            FROM start_events ORDER BY id DESC LIMIT ?
            """.trimIndent(),
            arrayOf(safeLimit.toString())
        ).use { c ->
            while (c.moveToNext()) {
                result += StartEvent(
                    id = c.getLong(0),
                    driveSessionId = if (c.isNull(1)) null else c.getLong(1),
                    timestampMs = c.getLong(2),
                    elapsedMs = c.getLong(3),
                    timeTrusted = c.getInt(4) == 1,
                    engineTempC = if (c.isNull(5)) null else c.getInt(5),
                    thermalClass = runCatching { StartThermalClass.valueOf(c.getString(6)) }.getOrDefault(StartThermalClass.UNKNOWN),
                    crankDurationMs = if (c.isNull(7)) null else c.getLong(7),
                    stabilizationDurationMs = if (c.isNull(8)) null else c.getLong(8),
                    attemptCount = c.getInt(9),
                    successful = c.getInt(10) == 1,
                    initialCrankRpm = if (c.isNull(11)) null else c.getInt(11),
                    initialRunningRpm = if (c.isNull(12)) null else c.getInt(12),
                    peakStartRpm = if (c.isNull(13)) null else c.getInt(13),
                    stableIdleRpm = if (c.isNull(14)) null else c.getInt(14),
                    confidence = runCatching { StartConfidence.valueOf(c.getString(15)) }.getOrDefault(StartConfidence.LOW),
                    obdGapDetected = c.getInt(16) == 1,
                    manualTrigger = c.getInt(17) == 1,
                    note = if (c.isNull(18)) null else c.getString(18)
                )
            }
        }
        return result
    }

    @Synchronized
    fun clearStartEvents(): Int = writableDatabase.delete("start_events", null, null)

    private fun trimStartEvents(keep: Int) {
        // Retain all start events attached to pinned drives. The rolling limit
        // applies only to unprotected events, so pinning an important drive also
        // preserves its associated long-term start-analysis evidence.
        writableDatabase.execSQL(
            """
            DELETE FROM start_events
            WHERE id IN (
                SELECT se.id
                FROM start_events se
                LEFT JOIN drive_sessions ds ON ds.id=se.drive_session_id
                LEFT JOIN trip_records tr ON tr.id=ds.trip_record_id
                WHERE COALESCE(tr.pinned,0)=0
                ORDER BY se.id DESC
                LIMIT -1 OFFSET ?
            )
            """.trimIndent(),
            arrayOf(keep.coerceAtLeast(1))
        )
    }

    private fun createStartEventsTable(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS start_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                drive_session_id INTEGER,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                engine_temp_c INTEGER,
                thermal_class TEXT NOT NULL,
                crank_duration_ms INTEGER,
                stabilization_duration_ms INTEGER,
                attempt_count INTEGER NOT NULL DEFAULT 1,
                successful INTEGER NOT NULL,
                initial_crank_rpm INTEGER,
                initial_running_rpm INTEGER,
                peak_start_rpm INTEGER,
                stable_idle_rpm INTEGER,
                confidence TEXT NOT NULL,
                obd_gap_detected INTEGER NOT NULL DEFAULT 0,
                manual_trigger INTEGER NOT NULL DEFAULT 0,
                note TEXT,
                FOREIGN KEY(drive_session_id) REFERENCES drive_sessions(id) ON DELETE SET NULL
            )
            """.trimIndent()
        )
    }

    private fun createGpsTable(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS gps_points (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                drive_session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                latitude REAL NOT NULL,
                longitude REAL NOT NULL,
                accuracy_m REAL NOT NULL,
                FOREIGN KEY(drive_session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
    }

    private fun tableExists(db: SQLiteDatabase, table: String): Boolean =
        db.rawQuery(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=? LIMIT 1",
            arrayOf(table)
        ).use { it.moveToFirst() }

    private fun createCoreIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_samples_session_elapsed ON obd_samples(session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_events_session_elapsed ON test_events(session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sessions_state ON drive_sessions(session_state, id)")
    }

    private fun createIndexes(db: SQLiteDatabase) {
        createCoreIndexes(db)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sessions_trip ON drive_sessions(trip_record_id, id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_trip_records_status ON trip_records(status, pinned, ended_at_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_sessions_status ON test_sessions(status, pinned, ended_at_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_samples_session_elapsed ON test_samples(test_session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_gps_points_session_elapsed ON gps_points(drive_session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_start_events_time ON start_events(time_ms, id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_start_events_thermal ON start_events(thermal_class, successful, id)")
    }

    private fun maskBluetoothAddress(address: String?): String {
        val parts = address?.trim()?.split(':').orEmpty()
        return if (parts.size == 6) "${parts[0]}:${parts[1]}:…:${parts[5]}" else "--"
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun formatTimestamp(ms: Long, trusted: Boolean): String =
        if (trusted && ms > 0L) SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(ms)) else "TIME_PENDING"

    private fun formatTime(ms: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(ms))

    private fun ContentValues.putTime(mark: TimeMark) {
        put("time_ms", mark.epochMs ?: 0L)
        put("elapsed_ms", mark.elapsedMs)
        put("boot_session_id", mark.bootSessionId)
        put("time_trusted", if (mark.trusted) 1 else 0)
    }

    private fun ContentValues.putNullable(key: String, value: Int?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun ContentValues.putNullable(key: String, value: Double?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun Cursor.str(column: String): String? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getString(index) else null
    }

    private fun Cursor.long(column: String): Long = getLong(getColumnIndexOrThrow(column))

    private fun Cursor.optLong(column: String): Long? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getLong(index) else null
    }

    private fun Cursor.optInt(column: String): Int? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getInt(index) else null
    }

    private data class StoredMark(val epochMs: Long, val elapsedMs: Long, val trusted: Boolean)
    private data class TestStoredMark(val epochMs: Long, val elapsedMs: Long, val bootSessionId: String, val trusted: Boolean)
    private data class RecoverableSession(
        val id: Long,
        val startedAtMs: Long,
        val startedElapsedMs: Long,
        val startTrusted: Boolean
    )

    companion object {
        internal const val DATABASE_NAME = "loganos_records.db"
        internal const val CURRENT_DB_VERSION = 6
        private const val DB_NAME = DATABASE_NAME
        private const val DB_VERSION = CURRENT_DB_VERSION
        private const val ANCHOR_REWRITE_TOLERANCE_MS = 1_500L
        private const val GPS_SEGMENT_GAP_MS = 60_000L
    }
}
