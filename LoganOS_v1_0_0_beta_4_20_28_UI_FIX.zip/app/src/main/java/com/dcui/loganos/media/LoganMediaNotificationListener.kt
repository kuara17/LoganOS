package com.dcui.loganos.media

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Permission bridge for reading active third-party MediaSession controllers and
 * read-only navigation notifications. The user must explicitly enable Android
 * notification access; LoganOS never fabricates navigation instructions.
 */
class LoganMediaNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var instance: LoganMediaNotificationListener? = null

        fun activeNotificationsSnapshot(): List<StatusBarNotification> = runCatching {
            instance?.activeNotifications?.toList().orEmpty()
        }.getOrDefault(emptyList())
    }
}
