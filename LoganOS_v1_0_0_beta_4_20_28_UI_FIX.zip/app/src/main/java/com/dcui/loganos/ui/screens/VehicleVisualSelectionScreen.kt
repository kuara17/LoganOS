package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun VehicleVisualSelectionScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    onSave: (VehicleVisualModel, VehicleColor) -> Unit,
    onCancel: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedModel by remember(settings.vehicleVisualModel) { mutableStateOf(settings.vehicleVisualModel) }
    var selectedColor by remember(settings.vehicleColor) { mutableStateOf(settings.vehicleColor) }
    val language = settings.language

    BackHandler(onBack = onCancel)

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 12.dp, vertical = 10.dp)
    ) {
        val landscape = maxWidth > maxHeight
        val previewHeight = if (landscape) 184.dp else 220.dp
        val modelImageHeight = if (landscape) 104.dp else 122.dp

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "‹",
                    color = palette.textPrimary,
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Light,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable(onClick = onCancel)
                        .padding(horizontal = 10.dp, vertical = 2.dp)
                )
                Column(Modifier.weight(1f)) {
                    Text(
                        text = if (language == AppLanguage.English) "Vehicle Appearance" else "Araç Görünümü",
                        color = palette.textPrimary,
                        fontSize = if (landscape) 25.sp else 28.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = if (language == AppLanguage.English) "Choose the Logan generation and colour used in cockpits" else "Kokpitlerde kullanılacak Logan kasasını ve rengini seçin",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            SectionCard(palette = palette, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (language == AppLanguage.English) "MODEL" else "MODEL",
                    color = palette.accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
                Spacer(Modifier.height(7.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    VehicleModelCard(
                        palette = palette,
                        model = VehicleVisualModel.LoganI,
                        selected = selectedModel == VehicleVisualModel.LoganI,
                        language = language,
                        imageHeight = modelImageHeight,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedModel = VehicleVisualModel.LoganI }
                    )
                    VehicleModelCard(
                        palette = palette,
                        model = VehicleVisualModel.LoganIII,
                        selected = selectedModel == VehicleVisualModel.LoganIII,
                        language = language,
                        imageHeight = modelImageHeight,
                        modifier = Modifier.weight(1f),
                        onClick = { selectedModel = VehicleVisualModel.LoganIII }
                    )
                }
            }

            SectionCard(palette = palette, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (language == AppLanguage.English) "COLOUR" else "RENK",
                    color = palette.accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black
                )
                Image(
                    painter = painterResource(
                        vehicleVisualDrawableRes(
                            model = selectedModel,
                            color = selectedColor,
                            style = VehicleAssetStyle.Detailed
                        )
                    ),
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(previewHeight)
                        .padding(horizontal = 16.dp, vertical = 2.dp)
                )
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(VehicleColor.entries) { color ->
                        VehicleColorChoice(
                            palette = palette,
                            color = color,
                            selected = selectedColor == color,
                            language = language,
                            onClick = { selectedColor = color }
                        )
                    }
                }
            }

            SectionCard(palette = palette, modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (language == AppLanguage.English) "Visual selection only" else "Yalnızca kokpit görseli",
                    color = palette.textPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = if (language == AppLanguage.English) {
                        "This does not change the verified vehicle/ECU profile. The selected image is used by Digital, Digital V2, Classic, Ghost and Premium Drive cockpits."
                    } else {
                        "Bu seçim doğrulanmış araç/ECU profilini değiştirmez. Seçilen görsel Digital, Dijital V2, Classic, Ghost ve Premium Drive kokpitlerinde kullanılır."
                    },
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }

            Spacer(Modifier.height(2.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ActionButton(
                    text = if (language == AppLanguage.English) "Cancel" else "Vazgeç",
                    background = palette.surfaceVariant,
                    foreground = palette.textPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = onCancel
                )
                ActionButton(
                    text = if (language == AppLanguage.English) "Save" else "Kaydet",
                    background = palette.accent,
                    foreground = palette.background,
                    modifier = Modifier.weight(1.35f),
                    onClick = { onSave(selectedModel, selectedColor) }
                )
            }
        }
    }
}

@Composable
private fun VehicleModelCard(
    palette: LoganPalette,
    model: VehicleVisualModel,
    selected: Boolean,
    language: AppLanguage,
    imageHeight: androidx.compose.ui.unit.Dp,
    modifier: Modifier,
    onClick: () -> Unit
) {
    val title = when (model) {
        VehicleVisualModel.LoganI -> "Logan I (2005–2012)"
        VehicleVisualModel.LoganIII -> "Logan III (2021+)"
    }
    val subtitle = when (model) {
        VehicleVisualModel.LoganI -> if (language == AppLanguage.English) "Classic generation" else "Klasik kasa"
        VehicleVisualModel.LoganIII -> if (language == AppLanguage.English) "New generation" else "Yeni nesil"
    }
    val previewColor = VehicleColor.Gray

    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(if (selected) palette.accent.copy(alpha = .08f) else palette.surfaceVariant)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) palette.accent else palette.line,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 9.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
        Image(
            painter = painterResource(vehicleVisualDrawableRes(model, previewColor, VehicleAssetStyle.Detailed)),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .height(imageHeight)
                .padding(top = 4.dp)
        )
        Text(
            text = if (selected) {
                if (language == AppLanguage.English) "✓ Selected" else "✓ Seçili"
            } else {
                if (language == AppLanguage.English) "Select" else "Seç"
            },
            color = if (selected) palette.accent else palette.textSecondary,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun VehicleColorChoice(
    palette: LoganPalette,
    color: VehicleColor,
    selected: Boolean,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val chipColor = when (color) {
        VehicleColor.CherryRed -> Color(0xFFA80F24)
        VehicleColor.White -> Color(0xFFF4F4F4)
        VehicleColor.Gray -> Color(0xFF7D838A)
        VehicleColor.Blue -> Color(0xFF1765B5)
        VehicleColor.Green -> Color(0xFF4E8157)
        VehicleColor.Yellow -> Color(0xFFF6C52C)
    }
    val label = if (language == AppLanguage.English) color.enLabel else color.trLabel

    Column(
        modifier = Modifier
            .size(width = 92.dp, height = 82.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (selected) palette.accent.copy(alpha = .10f) else palette.surfaceVariant)
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) palette.accent else palette.line,
                shape = RoundedCornerShape(15.dp)
            )
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(chipColor)
                .border(1.dp, if (color == VehicleColor.White) palette.line else chipColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            if (selected) Text("✓", color = if (color == VehicleColor.White || color == VehicleColor.Yellow) Color.Black else Color.White, fontWeight = FontWeight.Black)
        }
        Text(label, color = palette.textPrimary, fontSize = 10.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun SectionCard(
    palette: LoganPalette,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(palette.surface)
            .border(1.dp, palette.line.copy(alpha = .75f), RoundedCornerShape(20.dp))
            .padding(12.dp),
        content = content
    )
}

@Composable
private fun ActionButton(
    text: String,
    background: Color,
    foreground: Color,
    modifier: Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .height(50.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = foreground, fontSize = 16.sp, fontWeight = FontWeight.Black)
    }
}
