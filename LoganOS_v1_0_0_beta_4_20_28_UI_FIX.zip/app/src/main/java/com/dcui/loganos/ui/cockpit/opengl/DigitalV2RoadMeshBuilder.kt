package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.max
import kotlin.math.sqrt

/** One continuous triangle-strip ribbon already projected to OpenGL NDC. */
internal data class RoadRibbonMeshData(
    /** Interleaved [ndcX, ndcY, roadDistanceMeters, across] values. */
    val vertices: FloatArray,
    val vertexCount: Int
) {
    init {
        require(vertexCount >= 4)
        require(vertices.size == vertexCount * 4)
        require(vertices.all { it.isFinite() })
    }
}

internal enum class RoadCurveRole {
    CenterLine,
    LeftEdge,
    RightEdge
}

/**
 * Builds a calibrated line ribbon around a photographed road curve.
 *
 * Line width is derived from the measured road width at the same distance, so
 * the 15 cm marking naturally shrinks toward the horizon while retaining a
 * small anti-aliased minimum to prevent temporal shimmer.
 */
internal fun buildCalibratedLineMesh(
    road: DigitalV2RoadCalibration,
    role: RoadCurveRole,
    physicalWidthMeters: Float,
    widthExpansion: Float = road.markings.antialiasExpansion,
    segmentCount: Int = 256
): RoadRibbonMeshData {
    require(physicalWidthMeters > 0f)
    require(widthExpansion in 1f..2.5f)
    require(segmentCount >= 64)

    val curve = when (role) {
        RoadCurveRole.CenterLine -> road.centerLine
        RoadCurveRole.LeftEdge -> road.leftRoadEdge
        RoadCurveRole.RightEdge -> road.rightRoadEdge
    }
    val vertices = FloatArray((segmentCount + 1) * 2 * 4)
    var cursor = 0

    for (index in 0..segmentCount) {
        val linearT = index.toFloat() / segmentCount.toFloat()
        // Dense geometry near the camera where curvature/width changes fastest.
        val distance = road.maxDistanceMeters * linearT * linearT
        val point = curve.sample(distance)
        val tangent = curve.tangent(distance)
        val tangentX = tangent.x * DIGITAL_V2_LOGICAL_WIDTH
        val tangentY = tangent.y * DIGITAL_V2_LOGICAL_HEIGHT
        val length = sqrt(tangentX * tangentX + tangentY * tangentY).coerceAtLeast(0.0001f)
        val normalX = -tangentY / length
        val normalY = tangentX / length

        val roadWidthPixels = road.roadWidthPixels(distance)
        val visibleWidthPixels = (
            roadWidthPixels * (physicalWidthMeters / road.roadWidthMeters)
        ).coerceIn(
            road.markings.minimumVisibleWidthPixels,
            road.markings.maximumVisibleWidthPixels
        ) * widthExpansion

        val centerX = point.x * DIGITAL_V2_LOGICAL_WIDTH
        val centerY = point.y * DIGITAL_V2_LOGICAL_HEIGHT
        for (side in 0..1) {
            val across = side.toFloat()
            val signedHalfWidth = (across - 0.5f) * visibleWidthPixels
            val logicalX = centerX + normalX * signedHalfWidth
            val logicalY = centerY + normalY * signedHalfWidth
            vertices[cursor++] = logicalX / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
            vertices[cursor++] = 1f - logicalY / DIGITAL_V2_LOGICAL_HEIGHT * 2f
            vertices[cursor++] = distance
            vertices[cursor++] = across
        }
    }

    return RoadRibbonMeshData(vertices, (segmentCount + 1) * 2)
}

/** Exact road polygon between the independently calibrated left/right edges. */
internal fun buildCalibratedRoadSurfaceMesh(
    road: DigitalV2RoadCalibration,
    segmentCount: Int = 256
): RoadRibbonMeshData {
    require(segmentCount >= 64)
    val vertices = FloatArray((segmentCount + 1) * 2 * 4)
    var cursor = 0
    for (index in 0..segmentCount) {
        val linearT = index.toFloat() / segmentCount.toFloat()
        val distance = road.maxDistanceMeters * linearT * linearT
        val left = road.leftRoadEdge.sample(distance)
        val right = road.rightRoadEdge.sample(distance)
        listOf(left to 0f, right to 1f).forEach { (point, across) ->
            vertices[cursor++] = point.x * 2f - 1f
            vertices[cursor++] = 1f - point.y * 2f
            vertices[cursor++] = distance
            vertices[cursor++] = across
        }
    }
    return RoadRibbonMeshData(vertices, (segmentCount + 1) * 2)
}

internal enum class RoadSide { Left, Right }

/**
 * Builds wind polygons outside the photographed road edge. The zone is derived
 * from the exact edge-to-centre vector at each distance and therefore cannot
 * cross onto the asphalt even on curved scenes.
 */
internal fun buildCalibratedWindZoneMesh(
    road: DigitalV2RoadCalibration,
    wind: WindZoneProfile,
    side: RoadSide,
    segmentCount: Int = 192
): RoadRibbonMeshData {
    require(segmentCount >= 64)
    val vertices = FloatArray((segmentCount + 1) * 2 * 4)
    var cursor = 0

    for (index in 0..segmentCount) {
        val linearT = index.toFloat() / segmentCount.toFloat()
        val distance = road.maxDistanceMeters * linearT * linearT
        val leftEdge = road.leftRoadEdge.sample(distance)
        val rightEdge = road.rightRoadEdge.sample(distance)
        val edge = when (side) {
            RoadSide.Left -> leftEdge
            RoadSide.Right -> rightEdge
        }
        val centerX = (leftEdge.x + rightEdge.x) * 0.5f * DIGITAL_V2_LOGICAL_WIDTH
        val centerY = (leftEdge.y + rightEdge.y) * 0.5f * DIGITAL_V2_LOGICAL_HEIGHT
        val edgeX = edge.x * DIGITAL_V2_LOGICAL_WIDTH
        val edgeY = edge.y * DIGITAL_V2_LOGICAL_HEIGHT
        val outwardXRaw = edgeX - centerX
        val outwardYRaw = edgeY - centerY
        val outwardLength = sqrt(outwardXRaw * outwardXRaw + outwardYRaw * outwardYRaw)
            .coerceAtLeast(0.0001f)
        val outwardX = outwardXRaw / outwardLength
        val outwardY = outwardYRaw / outwardLength
        val roadWidthPixels = road.roadWidthPixels(distance)
        val innerOffset = roadWidthPixels * wind.edgeOffsetRoadWidthRatio
        val zoneWidth = max(2f, roadWidthPixels * wind.zoneWidthRoadWidthRatio)

        for (zoneSide in 0..1) {
            val across = zoneSide.toFloat()
            val offset = innerOffset + zoneWidth * across
            val logicalX = edgeX + outwardX * offset
            val logicalY = edgeY + outwardY * offset
            vertices[cursor++] = logicalX / DIGITAL_V2_LOGICAL_WIDTH * 2f - 1f
            vertices[cursor++] = 1f - logicalY / DIGITAL_V2_LOGICAL_HEIGHT * 2f
            vertices[cursor++] = distance
            vertices[cursor++] = across
        }
    }

    return RoadRibbonMeshData(vertices, (segmentCount + 1) * 2)
}
