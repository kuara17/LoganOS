package com.dcui.loganos.update

import android.content.Context
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.FileProvider
import com.dcui.loganos.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import javax.net.ssl.SSLException
import java.util.Locale

/**
 * GitHub Releases tabanlı güvenli güncelleme yöneticisi.
 *
 * Güven zinciri:
 * 1) Yalnızca derleme sırasında GITHUB_REPOSITORY ile sabitlenen repoya gider.
 * 2) Yalnızca HTTPS ve GitHub alan adlarına izin verir.
 * 3) APK ile birlikte yayımlanan SHA-256 değerini doğrular.
 * 4) En önemlisi: indirilen APK'nın paket adını ve Android imza sertifikasını
 *    çalışan uygulama ile karşılaştırır. İmza eşleşmeden kurucu açılmaz.
 * 5) Sürüm düşürme ve aynı sürümü yeniden kurma engellenir.
 *
 * Uygulamada GitHub tokenı veya özel anahtar tutulmaz.
 */
class SecureUpdateManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("loganos_secure_updates", Context.MODE_PRIVATE)
    private val packageManager = context.packageManager

    fun initialState(): UpdateUiState {
        val cached = loadCachedAvailableRelease()
        return if (cached != null && compareVersions(cached.versionName, BuildConfig.VERSION_NAME) > 0) {
            UpdateUiState.Available(cached)
        } else {
            UpdateUiState.Idle(lastCheckedAtMs())
        }
    }

    fun isRepositoryConfigured(): Boolean = repositoryOrNull() != null

    fun repositoryLabel(): String = repositoryOrNull() ?: "Yapılandırılmadı"

    fun lastCheckedAtMs(): Long? = prefs.getLong(KEY_LAST_CHECK_MS, 0L).takeIf { it > 0L }

    fun shouldAutoCheck(nowMs: Long = System.currentTimeMillis()): Boolean {
        if (!isRepositoryConfigured()) return false
        val last = lastCheckedAtMs() ?: return true
        return nowMs - last >= AUTO_CHECK_INTERVAL_MS
    }

    /**
     * Removes installers left by the previous app version only after a version
     * change is observed. Reopening the same version therefore does not delete a
     * freshly downloaded APK that the user has not installed yet.
     */
    fun cleanupStaleUpdateFilesAfterVersionChange(): Int {
        val previousVersion = prefs.getString(KEY_LAST_LAUNCHED_VERSION, null)
        if (previousVersion == BuildConfig.VERSION_NAME) return 0

        var deleted = 0
        val updatesDir = File(context.cacheDir, "updates")
        updatesDir.listFiles()?.forEach { file ->
            if (file.isFile && (file.name.endsWith(".apk", ignoreCase = true) || file.name.endsWith(".part", ignoreCase = true))) {
                if (file.delete()) deleted++
            }
        }
        prefs.edit().putString(KEY_LAST_LAUNCHED_VERSION, BuildConfig.VERSION_NAME).apply()
        return deleted
    }

    suspend fun checkForUpdate(): UpdateUiState = withContext(Dispatchers.IO) {
        try {
            val repo = repositoryOrNull()
                ?: return@withContext UpdateUiState.Error(
                    "Güncelleme deposu bu derlemeye gömülmemiş. APK'yı GitHub Actions üzerinden derleyin."
                )

            val endpoint = "https://api.github.com/repos/$repo/releases?per_page=20"
            val body = fetchText(endpoint, MAX_RELEASE_JSON_BYTES)
            val releases = JSONArray(body)
            val currentVersion = BuildConfig.VERSION_NAME
            var best: UpdateRelease? = null

            for (index in 0 until releases.length()) {
                val releaseJson = releases.optJSONObject(index) ?: continue
                if (releaseJson.optBoolean("draft", false)) continue

                val tagName = releaseJson.optString("tag_name").trim()
                val versionName = tagName.removePrefix("v").removePrefix("V").trim()
                if (!isSafeVersionName(versionName)) continue
                if (compareVersions(versionName, currentVersion) <= 0) continue

                val expectedApkName = "LoganOS-v$versionName-release.apk"
                val expectedChecksumName = "$expectedApkName.sha256"
                val assets = releaseJson.optJSONArray("assets") ?: continue
                var apkUrl: String? = null
                var checksumUrl: String? = null

                for (assetIndex in 0 until assets.length()) {
                    val asset = assets.optJSONObject(assetIndex) ?: continue
                    val name = asset.optString("name")
                    val url = asset.optString("browser_download_url")
                    if (name == expectedApkName && isAllowedReleaseAssetUrl(url, repo)) apkUrl = url
                    if (name == expectedChecksumName && isAllowedReleaseAssetUrl(url, repo)) checksumUrl = url
                }

                val resolvedApkUrl = apkUrl ?: continue
                val resolvedChecksumUrl = checksumUrl ?: continue

                val candidate = UpdateRelease(
                    versionName = versionName,
                    tagName = tagName,
                    releaseName = releaseJson.optString("name").ifBlank { tagName },
                    releaseNotes = releaseJson.optString("body").take(MAX_RELEASE_NOTES_CHARS),
                    publishedAt = releaseJson.optString("published_at"),
                    prerelease = releaseJson.optBoolean("prerelease", false),
                    apkName = expectedApkName,
                    apkUrl = resolvedApkUrl,
                    checksumUrl = resolvedChecksumUrl
                )

                if (best == null || compareVersions(candidate.versionName, best!!.versionName) > 0) {
                    best = candidate
                }
            }

            val checkedAt = System.currentTimeMillis()
            prefs.edit().putLong(KEY_LAST_CHECK_MS, checkedAt).apply()
            if (best != null) {
                cacheAvailableRelease(best)
                UpdateUiState.Available(best)
            } else {
                clearCachedAvailableRelease()
                UpdateUiState.UpToDate(checkedAt)
            }
        } catch (error: Exception) {
            UpdateUiState.Error(error.userFacingMessage("Güncelleme kontrolü başarısız"))
        }
    }

    suspend fun downloadAndVerify(
        release: UpdateRelease,
        onProgress: (Int) -> Unit
    ): UpdateUiState = withContext(Dispatchers.IO) {
        val updatesDir = File(context.cacheDir, "updates").apply { mkdirs() }
        val partialFile = File(updatesDir, "${release.apkName}.part")
        val finalFile = File(updatesDir, release.apkName)

        try {
            val repo = repositoryOrNull() ?: throw SecurityException("Güncelleme deposu yapılandırılmadı")
            if (!isAllowedReleaseAssetUrl(release.apkUrl, repo) || !isAllowedReleaseAssetUrl(release.checksumUrl, repo)) {
                throw SecurityException("Güncelleme adresi sabit LoganOS GitHub deposuyla eşleşmiyor")
            }

            updatesDir.listFiles()?.forEach { file ->
                if (file != partialFile && file != finalFile) file.delete()
            }
            partialFile.delete()
            finalFile.delete()

            val checksumText = fetchText(release.checksumUrl, MAX_CHECKSUM_BYTES)
            val expectedSha256 = parseSha256(checksumText)
                ?: throw SecurityException("Yayın SHA-256 dosyası geçersiz")

            downloadFile(
                url = release.apkUrl,
                destination = partialFile,
                maxBytes = MAX_APK_BYTES,
                onProgress = onProgress
            )

            val actualSha256 = sha256Hex(partialFile)
            if (!actualSha256.equals(expectedSha256, ignoreCase = true)) {
                throw SecurityException("APK SHA-256 doğrulaması başarısız")
            }

            val verification = verifyApkIdentityAndSignature(partialFile, release)
            if (!partialFile.renameTo(finalFile)) {
                partialFile.copyTo(finalFile, overwrite = true)
                partialFile.delete()
            }

            UpdateUiState.ReadyToInstall(
                release = release,
                apkPath = finalFile.absolutePath,
                signerSha256 = verification.signerSha256
            )
        } catch (error: Exception) {
            partialFile.delete()
            finalFile.delete()
            UpdateUiState.Error(error.userFacingMessage("Güncelleme indirilemedi veya doğrulanamadı"))
        }
    }

    fun requestInstall(apkPath: String): InstallLaunchResult {
        val apkFile = File(apkPath)
        val expectedUpdatesDir = File(context.cacheDir, "updates").canonicalFile
        require(apkFile.isFile && apkFile.canonicalFile.parentFile == expectedUpdatesDir) {
            "Geçersiz güncelleme dosyası"
        }

        // Kurucu açılmadan hemen önce tekrar doğrula. Dosya indirme ile kurulum
        // arasındaki sürede değiştirilmişse burada reddedilir.
        val releaseVersion = extractVersionFromApkName(apkFile.name)
            ?: throw SecurityException("APK dosya adı beklenen sürüm biçiminde değil")
        verifyApkIdentityAndSignature(
            apkFile,
            UpdateRelease(
                versionName = releaseVersion,
                tagName = "v$releaseVersion",
                releaseName = releaseVersion,
                releaseNotes = "",
                publishedAt = "",
                prerelease = true,
                apkName = apkFile.name,
                apkUrl = "https://github.com",
                checksumUrl = "https://github.com"
            )
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            val permissionIntent = Intent(
                Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:${context.packageName}")
            ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(permissionIntent)
            return InstallLaunchResult.UNKNOWN_SOURCES_SETTINGS_OPENED
        }

        val uri = FileProvider.getUriForFile(
            context,
            "${context.packageName}.fileprovider",
            apkFile
        )
        val installIntent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, APK_MIME_TYPE)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(installIntent)
        return InstallLaunchResult.INSTALLER_OPENED
    }


    private fun cacheAvailableRelease(release: UpdateRelease) {
        val json = JSONObject()
            .put("versionName", release.versionName)
            .put("tagName", release.tagName)
            .put("releaseName", release.releaseName)
            .put("releaseNotes", release.releaseNotes)
            .put("publishedAt", release.publishedAt)
            .put("prerelease", release.prerelease)
            .put("apkName", release.apkName)
            .put("apkUrl", release.apkUrl)
            .put("checksumUrl", release.checksumUrl)
        prefs.edit().putString(KEY_CACHED_RELEASE_JSON, json.toString()).apply()
    }

    private fun loadCachedAvailableRelease(): UpdateRelease? {
        val raw = prefs.getString(KEY_CACHED_RELEASE_JSON, null) ?: return null
        return try {
            val json = JSONObject(raw)
            val apkUrl = json.getString("apkUrl")
            val checksumUrl = json.getString("checksumUrl")
            val repo = repositoryOrNull() ?: return null
            if (!isAllowedReleaseAssetUrl(apkUrl, repo) || !isAllowedReleaseAssetUrl(checksumUrl, repo)) return null
            UpdateRelease(
                versionName = json.getString("versionName"),
                tagName = json.getString("tagName"),
                releaseName = json.optString("releaseName"),
                releaseNotes = json.optString("releaseNotes").take(MAX_RELEASE_NOTES_CHARS),
                publishedAt = json.optString("publishedAt"),
                prerelease = json.optBoolean("prerelease", false),
                apkName = json.getString("apkName"),
                apkUrl = apkUrl,
                checksumUrl = checksumUrl
            ).takeIf {
                isSafeVersionName(it.versionName) &&
                    it.apkName == "LoganOS-v${it.versionName}-release.apk"
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun clearCachedAvailableRelease() {
        prefs.edit().remove(KEY_CACHED_RELEASE_JSON).apply()
    }

    private fun repositoryOrNull(): String? {
        val value = BuildConfig.UPDATE_REPOSITORY.trim()
        return value.takeIf { REPOSITORY_PATTERN.matches(it) }
    }

    private fun verifyApkIdentityAndSignature(apkFile: File, release: UpdateRelease): ApkVerification {
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            PackageManager.GET_SIGNING_CERTIFICATES
        } else {
            @Suppress("DEPRECATION")
            PackageManager.GET_SIGNATURES
        }

        @Suppress("DEPRECATION")
        val currentInfo = packageManager.getPackageInfo(context.packageName, flags)
        @Suppress("DEPRECATION")
        val archiveInfo = packageManager.getPackageArchiveInfo(apkFile.absolutePath, flags)
            ?: throw SecurityException("İndirilen dosya geçerli bir Android APK değil")

        if (archiveInfo.packageName != context.packageName) {
            val detail = if (context.packageName.endsWith(".debug")) {
                "Kurulu LoganOS bir debug/test paketi; OTA yalnız release paketini güncelleyebilir. Verinizi yedekleyip Secure Release APK'sına geçin."
            } else {
                "İndirilen APK farklı bir uygulama paketine ait; kurulum güvenlik nedeniyle durduruldu."
            }
            throw SecurityException(detail)
        }
        if (archiveInfo.versionName != release.versionName) {
            throw SecurityException("APK iç sürümü yayın sürümüyle eşleşmiyor")
        }

        val currentVersionCode = currentInfo.longVersionCodeCompat()
        val updateVersionCode = archiveInfo.longVersionCodeCompat()
        if (updateVersionCode <= currentVersionCode) {
            throw SecurityException("Aynı veya daha eski sürüm kurulamaz")
        }

        val currentSigners = currentApkSignerDigests(currentInfo)
        val updateCurrentSigners = currentApkSignerDigests(archiveInfo)
        val updateSigningLineage = signingLineageDigests(archiveInfo)
        val signatureMatches = if (currentSigners.size > 1 || updateCurrentSigners.size > 1) {
            currentSigners == updateCurrentSigners
        } else {
            currentSigners.isNotEmpty() && currentSigners.intersect(updateSigningLineage).isNotEmpty()
        }
        if (!signatureMatches) {
            throw SecurityException("APK imzası mevcut LoganOS kurulumu ile eşleşmiyor. Farklı imzalı test APK'sı kurulmuş olabilir; verinizi yedeklemeden mevcut uygulamayı kaldırmayın.")
        }

        return ApkVerification(updateCurrentSigners.sorted().first())
    }

    private fun currentApkSignerDigests(info: PackageInfo): Set<String> {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            info.signingInfo?.apkContentsSigners?.toList().orEmpty()
        } else {
            @Suppress("DEPRECATION")
            info.signatures?.toList().orEmpty()
        }
        return digestSignatures(signatures)
    }

    private fun signingLineageDigests(info: PackageInfo): Set<String> {
        val signatures = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val signingInfo = info.signingInfo ?: return emptySet()
            if (signingInfo.hasMultipleSigners()) {
                signingInfo.apkContentsSigners?.toList().orEmpty()
            } else {
                signingInfo.signingCertificateHistory?.toList().orEmpty()
            }
        } else {
            @Suppress("DEPRECATION")
            info.signatures?.toList().orEmpty()
        }
        return digestSignatures(signatures)
    }

    private fun digestSignatures(signatures: List<android.content.pm.Signature>): Set<String> {
        return signatures.map { signature ->
            MessageDigest.getInstance("SHA-256")
                .digest(signature.toByteArray())
                .joinToString("") { byte -> "%02x".format(byte) }
        }.toSet()
    }

    private fun PackageInfo.longVersionCodeCompat(): Long =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) longVersionCode
        else {
            @Suppress("DEPRECATION")
            versionCode.toLong()
        }

    private fun fetchText(url: String, maxBytes: Long): String {
        val accept = if (url.startsWith("https://api.github.com/")) {
            "application/vnd.github+json"
        } else {
            "text/plain,*/*"
        }
        val bytes = readUrl(url, maxBytes, accept)
        return bytes.toString(Charsets.UTF_8)
    }

    private fun downloadFile(
        url: String,
        destination: File,
        maxBytes: Long,
        onProgress: (Int) -> Unit
    ) {
        val connection = openAllowedConnection(url, "application/octet-stream")
        try {
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) throw IOException("HTTP $responseCode")
            val declaredLength = connection.contentLengthLong
            if (declaredLength > maxBytes) throw SecurityException("APK izin verilen boyut sınırını aşıyor")

            BufferedInputStream(connection.inputStream).use { input ->
                BufferedOutputStream(FileOutputStream(destination)).use { output ->
                    val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                    var total = 0L
                    var lastProgress = -1
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        if (total > maxBytes) throw SecurityException("APK izin verilen boyut sınırını aşıyor")
                        output.write(buffer, 0, read)
                        if (declaredLength > 0) {
                            val progress = ((total * 100L) / declaredLength).toInt().coerceIn(0, 100)
                            if (progress != lastProgress) {
                                lastProgress = progress
                                onProgress(progress)
                            }
                        }
                    }
                    output.flush()
                    if (total <= 0L) throw IOException("Boş APK indirildi")
                    if (declaredLength >= 0L && total != declaredLength) {
                        throw IOException("APK indirmesi yarım kaldı ($total/$declaredLength bayt)")
                    }
                }
            }
            onProgress(100)
        } finally {
            connection.disconnect()
        }
    }

    private fun readUrl(url: String, maxBytes: Long, accept: String?): ByteArray {
        val connection = openAllowedConnection(url, accept)
        try {
            val responseCode = connection.responseCode
            if (responseCode !in 200..299) throw IOException("HTTP $responseCode")
            val declaredLength = connection.contentLengthLong
            if (declaredLength > maxBytes) throw SecurityException("Yanıt boyutu sınırı aşıyor")
            BufferedInputStream(connection.inputStream).use { input ->
                val output = java.io.ByteArrayOutputStream()
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var total = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > maxBytes) throw SecurityException("Yanıt boyutu sınırı aşıyor")
                    output.write(buffer, 0, read)
                }
                if (declaredLength >= 0L && total != declaredLength) {
                    throw IOException("Güncelleme yanıtı yarım kaldı ($total/$declaredLength bayt)")
                }
                return output.toByteArray()
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun openAllowedConnection(initialUrl: String, accept: String? = null): HttpURLConnection {
        var current = initialUrl
        repeat(MAX_REDIRECTS + 1) { redirectCount ->
            if (!isAllowedHttpsUrl(current)) throw SecurityException("İzin verilmeyen güncelleme adresi")
            val connection = URL(current).openConnection() as HttpURLConnection
            connection.instanceFollowRedirects = false
            connection.connectTimeout = CONNECT_TIMEOUT_MS
            connection.readTimeout = READ_TIMEOUT_MS
            connection.useCaches = false
            connection.setRequestProperty("User-Agent", "LoganOS/${BuildConfig.VERSION_NAME}")
            connection.setRequestProperty("Accept", accept ?: "application/vnd.github+json")
            if (current.startsWith("https://api.github.com/")) {
                connection.setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
            }

            val code = connection.responseCode
            if (code in REDIRECT_CODES) {
                if (redirectCount >= MAX_REDIRECTS) {
                    connection.disconnect()
                    throw SecurityException("Çok fazla yönlendirme")
                }
                val location = connection.getHeaderField("Location")
                    ?: run {
                        connection.disconnect()
                        throw IOException("Yönlendirme adresi eksik")
                    }
                val resolved = URI(current).resolve(location).toString()
                connection.disconnect()
                current = resolved
            } else {
                return connection
            }
        }
        throw SecurityException("Güncelleme bağlantısı açılamadı")
    }

    private fun isAllowedReleaseAssetUrl(value: String, repository: String): Boolean {
        if (!isAllowedHttpsUrl(value)) return false
        return try {
            val uri = URI(value)
            val host = uri.host?.lowercase(Locale.US) ?: return false
            val expectedPrefix = "/$repository/releases/download/"
            host == "github.com" && uri.path.startsWith(expectedPrefix, ignoreCase = true)
        } catch (_: Exception) {
            false
        }
    }

    private fun isAllowedHttpsUrl(value: String): Boolean {
        return try {
            val uri = URI(value)
            val host = uri.host?.lowercase(Locale.US) ?: return false
            uri.scheme.equals("https", ignoreCase = true) &&
                uri.userInfo == null &&
                uri.port == -1 &&
                (host == "api.github.com" || host == "github.com" || host.endsWith(".githubusercontent.com"))
        } catch (_: Exception) {
            false
        }
    }

    private fun parseSha256(text: String): String? =
        SHA256_PATTERN.find(text)?.value?.lowercase(Locale.US)

    private fun sha256Hex(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
            while (true) {
                val read = input.read(buffer)
                if (read < 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { byte -> "%02x".format(byte) }
    }

    private fun compareVersions(left: String, right: String): Int {
        val l = parseVersionKey(left)
        val r = parseVersionKey(right)
        if (l != null && r != null) return l.compareTo(r)

        // Bilinmeyen ama güvenli bir sürüm biçiminde geriye dönük karşılaştırma.
        val leftParts = VERSION_NUMBER_PATTERN.findAll(left).map { it.value.toIntOrNull() ?: 0 }.toList()
        val rightParts = VERSION_NUMBER_PATTERN.findAll(right).map { it.value.toIntOrNull() ?: 0 }.toList()
        val length = maxOf(leftParts.size, rightParts.size)
        for (index in 0 until length) {
            val lv = leftParts.getOrElse(index) { 0 }
            val rv = rightParts.getOrElse(index) { 0 }
            if (lv != rv) return lv.compareTo(rv)
        }
        return left.compareTo(right, ignoreCase = true)
    }

    private fun parseVersionKey(version: String): VersionKey? {
        val match = SEMVER_PATTERN.matchEntire(version) ?: return null
        val major = match.groupValues[1].toIntOrNull() ?: return null
        val minor = match.groupValues[2].toIntOrNull() ?: return null
        val patch = match.groupValues[3].toIntOrNull() ?: return null
        val channel = match.groupValues[4].lowercase(Locale.US)
        val channelRank = when (channel) {
            "alpha" -> 1
            "beta" -> 2
            "rc" -> 3
            "" -> 4 // stable > rc > beta > alpha
            else -> 0
        }
        val tail = match.groupValues[5]
            .split('.')
            .filter { it.isNotBlank() }
            .map { it.toIntOrNull() ?: 0 }
        return VersionKey(major, minor, patch, channelRank, tail)
    }

    private fun isSafeVersionName(version: String): Boolean =
        version.length in 1..64 && VERSION_NAME_PATTERN.matches(version)

    private fun extractVersionFromApkName(name: String): String? {
        val prefix = "LoganOS-v"
        val suffix = "-release.apk"
        if (!name.startsWith(prefix) || !name.endsWith(suffix)) return null
        return name.removePrefix(prefix).removeSuffix(suffix).takeIf(::isSafeVersionName)
    }

    private fun Exception.userFacingMessage(prefix: String): String {
        val raw = message.orEmpty()
        return when {
            this is UnknownHostException -> "$prefix: İnternet bağlantısı veya DNS erişimi yok. Bağlantınızı kontrol edip tekrar deneyin."
            this is SocketTimeoutException -> "$prefix: Bağlantı zaman aşımına uğradı. İnternet bağlantınızı kontrol edip tekrar deneyin."
            this is SSLException -> "$prefix: Güvenli HTTPS bağlantısı kurulamadı. Tarih/saat ve ağ bağlantısını kontrol edin."
            raw == "HTTP 403" || raw == "HTTP 429" -> "$prefix: GitHub sorgu limiti aşıldı. Bir süre sonra tekrar deneyin."
            raw == "HTTP 404" -> "$prefix: Yayın dosyası bulunamadı. Sürüm yayını eksik veya kaldırılmış olabilir."
            else -> {
                val detail = raw.take(220).takeIf { it.isNotBlank() }
                if (detail == null) prefix else "$prefix: $detail"
            }
        }
    }

    private data class VersionKey(
        val major: Int,
        val minor: Int,
        val patch: Int,
        val channelRank: Int,
        val tail: List<Int>
    ) : Comparable<VersionKey> {
        override fun compareTo(other: VersionKey): Int {
            compareValues(major, other.major).takeIf { it != 0 }?.let { return it }
            compareValues(minor, other.minor).takeIf { it != 0 }?.let { return it }
            compareValues(patch, other.patch).takeIf { it != 0 }?.let { return it }
            compareValues(channelRank, other.channelRank).takeIf { it != 0 }?.let { return it }
            val length = maxOf(tail.size, other.tail.size)
            for (index in 0 until length) {
                val left = tail.getOrElse(index) { 0 }
                val right = other.tail.getOrElse(index) { 0 }
                if (left != right) return left.compareTo(right)
            }
            return 0
        }
    }

    private data class ApkVerification(val signerSha256: String)

    companion object {
        private const val KEY_LAST_CHECK_MS = "last_check_ms"
        private const val KEY_LAST_LAUNCHED_VERSION = "last_launched_version"
        private const val KEY_CACHED_RELEASE_JSON = "cached_release_json"
        private const val AUTO_CHECK_INTERVAL_MS = 24L * 60L * 60L * 1000L
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 45_000
        private const val MAX_REDIRECTS = 5
        private const val MAX_RELEASE_JSON_BYTES = 2L * 1024L * 1024L
        private const val MAX_CHECKSUM_BYTES = 8L * 1024L
        private const val MAX_APK_BYTES = 250L * 1024L * 1024L
        private const val MAX_RELEASE_NOTES_CHARS = 4_000
        private const val APK_MIME_TYPE = "application/vnd.android.package-archive"
        private val REPOSITORY_PATTERN = Regex("^[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+$")
        private val VERSION_NAME_PATTERN = Regex("^[A-Za-z0-9._-]+$")
        private val VERSION_NUMBER_PATTERN = Regex("\\d+")
        private val SEMVER_PATTERN = Regex("^(\\d+)\\.(\\d+)\\.(\\d+)(?:-(alpha|beta|rc)(?:\\.([0-9.]+))?)?$", RegexOption.IGNORE_CASE)
        private val SHA256_PATTERN = Regex("(?i)\\b[a-f0-9]{64}\\b")
        private val REDIRECT_CODES = setOf(301, 302, 303, 307, 308)
    }
}
