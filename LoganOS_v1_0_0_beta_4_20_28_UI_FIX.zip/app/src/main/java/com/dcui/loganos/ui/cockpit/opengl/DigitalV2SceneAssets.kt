package com.dcui.loganos.ui.cockpit.opengl

import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel

internal fun DigitalV2Scene.toOpenGlKey(): DigitalV2SceneKey = when (this) {
    DigitalV2Scene.MountainLake -> DigitalV2SceneKey.MountainLake
    DigitalV2Scene.CityDay -> DigitalV2SceneKey.CityDay
    DigitalV2Scene.CityNight -> DigitalV2SceneKey.CityNight
    DigitalV2Scene.SnowRoad -> DigitalV2SceneKey.SnowRoad
}

/**
 * Digital V2 uses one baked scene per scene/model/color combination.
 * Vehicle placement, road, lighting and shadow are already part of the bitmap.
 */
internal fun digitalV2CompositeRes(
    scene: DigitalV2Scene,
    model: VehicleVisualModel,
    color: VehicleColor
): Int = when (scene) {
    DigitalV2Scene.MountainLake -> when (model) {
        VehicleVisualModel.LoganI -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_mountain_lake_logan1_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_mountain_lake_logan1_white
            VehicleColor.Gray -> R.drawable.digital_v2_mountain_lake_logan1_gray
            VehicleColor.Blue -> R.drawable.digital_v2_mountain_lake_logan1_blue
            VehicleColor.Green -> R.drawable.digital_v2_mountain_lake_logan1_green
            VehicleColor.Yellow -> R.drawable.digital_v2_mountain_lake_logan1_yellow
        }
        VehicleVisualModel.LoganIII -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_mountain_lake_logan3_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_mountain_lake_logan3_white
            VehicleColor.Gray -> R.drawable.digital_v2_mountain_lake_logan3_gray
            VehicleColor.Blue -> R.drawable.digital_v2_mountain_lake_logan3_blue
            VehicleColor.Green -> R.drawable.digital_v2_mountain_lake_logan3_green
            VehicleColor.Yellow -> R.drawable.digital_v2_mountain_lake_logan3_yellow
        }
    }
    DigitalV2Scene.CityDay -> when (model) {
        VehicleVisualModel.LoganI -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_city_day_logan1_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_city_day_logan1_white
            VehicleColor.Gray -> R.drawable.digital_v2_city_day_logan1_gray
            VehicleColor.Blue -> R.drawable.digital_v2_city_day_logan1_blue
            VehicleColor.Green -> R.drawable.digital_v2_city_day_logan1_green
            VehicleColor.Yellow -> R.drawable.digital_v2_city_day_logan1_yellow
        }
        VehicleVisualModel.LoganIII -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_city_day_logan3_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_city_day_logan3_white
            VehicleColor.Gray -> R.drawable.digital_v2_city_day_logan3_gray
            VehicleColor.Blue -> R.drawable.digital_v2_city_day_logan3_blue
            VehicleColor.Green -> R.drawable.digital_v2_city_day_logan3_green
            VehicleColor.Yellow -> R.drawable.digital_v2_city_day_logan3_yellow
        }
    }
    DigitalV2Scene.CityNight -> when (model) {
        VehicleVisualModel.LoganI -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_city_night_logan1_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_city_night_logan1_white
            VehicleColor.Gray -> R.drawable.digital_v2_city_night_logan1_gray
            VehicleColor.Blue -> R.drawable.digital_v2_city_night_logan1_blue
            VehicleColor.Green -> R.drawable.digital_v2_city_night_logan1_green
            VehicleColor.Yellow -> R.drawable.digital_v2_city_night_logan1_yellow
        }
        VehicleVisualModel.LoganIII -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_city_night_logan3_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_city_night_logan3_white
            VehicleColor.Gray -> R.drawable.digital_v2_city_night_logan3_gray
            VehicleColor.Blue -> R.drawable.digital_v2_city_night_logan3_blue
            VehicleColor.Green -> R.drawable.digital_v2_city_night_logan3_green
            VehicleColor.Yellow -> R.drawable.digital_v2_city_night_logan3_yellow
        }
    }
    DigitalV2Scene.SnowRoad -> when (model) {
        VehicleVisualModel.LoganI -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_snow_road_logan1_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_snow_road_logan1_white
            VehicleColor.Gray -> R.drawable.digital_v2_snow_road_logan1_gray
            VehicleColor.Blue -> R.drawable.digital_v2_snow_road_logan1_blue
            VehicleColor.Green -> R.drawable.digital_v2_snow_road_logan1_green
            VehicleColor.Yellow -> R.drawable.digital_v2_snow_road_logan1_yellow
        }
        VehicleVisualModel.LoganIII -> when (color) {
            VehicleColor.CherryRed -> R.drawable.digital_v2_snow_road_logan3_cherry_red
            VehicleColor.White -> R.drawable.digital_v2_snow_road_logan3_white
            VehicleColor.Gray -> R.drawable.digital_v2_snow_road_logan3_gray
            VehicleColor.Blue -> R.drawable.digital_v2_snow_road_logan3_blue
            VehicleColor.Green -> R.drawable.digital_v2_snow_road_logan3_green
            VehicleColor.Yellow -> R.drawable.digital_v2_snow_road_logan3_yellow
        }
    }
}

internal fun digitalV2VehicleAssetProfile(model: VehicleVisualModel): VehicleAssetProfile = when (model) {
    VehicleVisualModel.LoganI -> VehicleAssetProfile(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleLeftRatioInTexture = 69f / 1014f,
        visibleRightRatioInTexture = 946f / 1014f,
        leftTireContactXRatioInTexture = 0.178f,
        rightTireContactXRatioInTexture = 0.822f,
        contactYRatioInTexture = 828f / 914f,
        visibleBottomRatioInTexture = 0.928f
    )
    VehicleVisualModel.LoganIII -> VehicleAssetProfile(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleLeftRatioInTexture = 57f / 1014f,
        visibleRightRatioInTexture = 958f / 1014f,
        leftTireContactXRatioInTexture = 0.164f,
        rightTireContactXRatioInTexture = 0.836f,
        contactYRatioInTexture = 828f / 914f,
        visibleBottomRatioInTexture = 0.928f
    )
}

internal fun digitalV2RenderState(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    calibrationVisible: Boolean = false
): DigitalV2RenderState = DigitalV2RenderState(
    sceneKey = settings.digitalV2Scene.toOpenGlKey(),
    backgroundResId = digitalV2CompositeRes(
        scene = settings.digitalV2Scene,
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor
    ),
    vehicleResId = 0,
    castShadowResId = 0,
    contactShadowResId = 0,
    roadMapResId = 0,
    vehicleAsset = digitalV2VehicleAssetProfile(settings.vehicleVisualModel),
    speedKmh = (snapshot.speedKmh ?: 0).toFloat().coerceAtLeast(0f),
    rpm = (snapshot.rpm ?: 0).toFloat().coerceAtLeast(0f),
    motionEnabled = false,
    calibrationVisible = calibrationVisible
)
