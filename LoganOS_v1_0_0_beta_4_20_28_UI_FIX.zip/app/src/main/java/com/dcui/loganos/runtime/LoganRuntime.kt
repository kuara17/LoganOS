package com.dcui.loganos.runtime

import android.content.Context
import com.dcui.loganos.obd.ObdController

/**
 * Process-wide owner for the live OBD controller.
 *
 * The controller must outlive MainActivity while a foreground driving service is
 * active. Keeping one application-scoped instance prevents an Activity recreate
 * or Home-button transition from tearing down the Bluetooth/KWP poll loop.
 */
object LoganRuntime {
    @Volatile
    private var controller: ObdController? = null

    fun obdController(context: Context): ObdController {
        controller?.let { return it }
        return synchronized(this) {
            controller ?: ObdController(context.applicationContext).also { controller = it }
        }
    }

    fun releaseObdController() {
        synchronized(this) {
            controller?.release()
            controller = null
        }
    }
}
