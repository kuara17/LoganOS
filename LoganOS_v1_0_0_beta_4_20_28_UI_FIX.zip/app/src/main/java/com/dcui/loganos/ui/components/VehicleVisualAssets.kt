package com.dcui.loganos.ui.components

import com.dcui.loganos.R
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel

enum class VehicleAssetStyle {
    Detailed,
    OemSimplified
}

fun vehicleVisualDrawableRes(
    model: VehicleVisualModel,
    color: VehicleColor,
    style: VehicleAssetStyle = VehicleAssetStyle.Detailed
): Int = when (model) {
    VehicleVisualModel.LoganI -> when (style) {
        VehicleAssetStyle.Detailed -> when (color) {
            VehicleColor.CherryRed -> R.drawable.loganos_logan_rear_cherry_red
            VehicleColor.White -> R.drawable.loganos_logan_rear_white
            VehicleColor.Gray -> R.drawable.loganos_logan_rear_gray
            VehicleColor.Blue -> R.drawable.loganos_logan_rear_blue
            VehicleColor.Green -> R.drawable.loganos_logan_rear_green
            VehicleColor.Yellow -> R.drawable.loganos_logan_rear_yellow
        }
        VehicleAssetStyle.OemSimplified -> when (color) {
            VehicleColor.CherryRed -> R.drawable.loganos_logan_rear_oem_cherry_red
            VehicleColor.White -> R.drawable.loganos_logan_rear_oem_white
            VehicleColor.Gray -> R.drawable.loganos_logan_rear_oem_gray
            VehicleColor.Blue -> R.drawable.loganos_logan_rear_oem_blue
            VehicleColor.Green -> R.drawable.loganos_logan_rear_oem_green
            VehicleColor.Yellow -> R.drawable.loganos_logan_rear_oem_yellow
        }
    }
    VehicleVisualModel.LoganIII -> when (color) {
        VehicleColor.CherryRed -> R.drawable.loganos_logan3_rear_cherry_red
        VehicleColor.White -> R.drawable.loganos_logan3_rear_white
        VehicleColor.Gray -> R.drawable.loganos_logan3_rear_gray
        VehicleColor.Blue -> R.drawable.loganos_logan3_rear_blue
        VehicleColor.Green -> R.drawable.loganos_logan3_rear_green
        VehicleColor.Yellow -> R.drawable.loganos_logan3_rear_yellow
    }
}
