package com.dcui.loganos.obd

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Looper
import android.os.SystemClock
import androidx.core.content.ContextCompat
import com.dcui.loganos.data.LoganSqlStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Optional, privacy-first GPS route recorder.
 *
 * It never replaces OBD speed or TripComputer data. OBD speed only gates whether
 * high-accuracy GNSS updates are worth requesting. Accepted points are linked to
 * the currently active drive_session so Smart Trip can preserve real segment gaps.
 */
class GpsRouteRecorder(
    context: Context,
    private val sqlStore: LoganSqlStore,
    private val onStateChanged: (GpsRouteRuntimeState) -> Unit
) {
    private val appContext = context.applicationContext
    private val locationManager = appContext.getSystemService(LocationManager::class.java)
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()

    @Volatile private var enabledByUser = false
    @Volatile private var allowedForDeviceMode = false
    @Volatile private var connected = false
    @Volatile private var activeSessionId: Long? = null
    @Volatile private var requestingLocation = false

    private var stoppedSinceElapsedMs: Long? = null
    private var lastAcceptedLocation: Location? = null
    private var lastAcceptedElapsedMs: Long = 0L
    private var acceptedPointCount: Int = 0

    private val listener = LocationListener { location ->
        handleLocation(location)
    }

    fun configure(enabled: Boolean, allowForDeviceMode: Boolean) {
        enabledByUser = enabled
        allowedForDeviceMode = allowForDeviceMode
        if (!shouldBeAvailable()) {
            stopLocationUpdates()
            publishState("Kapalı")
        } else {
            publishState(if (requestingLocation) "Rota kaydediliyor" else "Hareket bekleniyor")
        }
    }

    fun onObdFrame(sessionId: Long?, speedKmh: Int?, isConnected: Boolean) {
        connected = isConnected
        activeSessionId = sessionId
        if (!shouldBeAvailable() || !isConnected || sessionId == null) {
            stopLocationUpdates()
            return
        }

        val now = SystemClock.elapsedRealtime()
        when {
            speedKmh != null && speedKmh > START_SPEED_KMH -> {
                stoppedSinceElapsedMs = null
                startLocationUpdatesIfNeeded()
            }
            speedKmh != null && speedKmh <= STOP_SPEED_KMH -> {
                val stoppedSince = stoppedSinceElapsedMs ?: now.also { stoppedSinceElapsedMs = it }
                if (now - stoppedSince >= STOP_AFTER_MS) stopLocationUpdates()
            }
            else -> {
                // Unknown/held speed must not instantly tear down a valid route
                // recorder during a brief OBD transport gap.
            }
        }
    }

    fun onObdDisconnected() {
        connected = false
        activeSessionId = null
        stoppedSinceElapsedMs = null
        stopLocationUpdates()
    }

    fun hasFineLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(appContext, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isForegroundLocationEligible(): Boolean =
        enabledByUser && allowedForDeviceMode && hasFineLocationPermission()

    fun release() {
        stopLocationUpdates()
        ioScope.cancel()
    }

    private fun shouldBeAvailable(): Boolean =
        enabledByUser && allowedForDeviceMode && hasFineLocationPermission()

    @Suppress("MissingPermission")
    private fun startLocationUpdatesIfNeeded() {
        if (requestingLocation || !shouldBeAvailable() || !connected || activeSessionId == null) return
        val gpsEnabled = runCatching { locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)
        if (!gpsEnabled) {
            publishState("GPS kapalı")
            return
        }
        runCatching {
            locationManager.requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                REQUEST_INTERVAL_MS,
                0f,
                listener,
                Looper.getMainLooper()
            )
            requestingLocation = true
            publishState("GPS sinyali bekleniyor")
        }.onFailure {
            requestingLocation = false
            publishState("GPS başlatılamadı")
        }
    }

    private fun stopLocationUpdates() {
        if (requestingLocation) {
            runCatching { locationManager.removeUpdates(listener) }
        }
        requestingLocation = false
        if (shouldBeAvailable() && connected) publishState("Hareket bekleniyor")
    }

    private fun handleLocation(location: Location) {
        if (!requestingLocation || !shouldBeAvailable() || !connected) return
        val sessionId = activeSessionId ?: return
        if (!location.hasAccuracy() || !location.accuracy.isFinite() || location.accuracy <= 0f || location.accuracy > MAX_ACCURACY_M) {
            publishState("GPS doğruluğu bekleniyor", location.accuracy.takeIf { it.isFinite() })
            return
        }
        val lat = location.latitude
        val lon = location.longitude
        if (!lat.isFinite() || !lon.isFinite() || lat !in -90.0..90.0 || lon !in -180.0..180.0) return

        val now = SystemClock.elapsedRealtime()
        val accepted = synchronized(lock) {
            val previous = lastAcceptedLocation
            val distance = previous?.distanceTo(location) ?: Float.MAX_VALUE
            val elapsedSinceAccepted = now - lastAcceptedElapsedMs
            if (previous != null && distance < MIN_ACCEPT_DISTANCE_M && elapsedSinceAccepted < MAX_SILENT_INTERVAL_MS) {
                false
            } else {
                lastAcceptedLocation = Location(location)
                lastAcceptedElapsedMs = now
                true
            }
        }
        if (!accepted) return

        ioScope.launch {
            val inserted = runCatching {
                sqlStore.insertGpsPoint(sessionId, lat, lon, location.accuracy)
            }.getOrDefault(false)
            if (inserted) {
                synchronized(lock) { acceptedPointCount++ }
                publishState("Rota kaydediliyor", location.accuracy)
            }
        }
    }

    private fun publishState(label: String, accuracyM: Float? = null) {
        val count = synchronized(lock) { acceptedPointCount }
        onStateChanged(
            GpsRouteRuntimeState(
                enabled = enabledByUser,
                eligible = isForegroundLocationEligible(),
                recording = requestingLocation,
                status = label,
                acceptedPointCount = count,
                lastAccuracyM = accuracyM
            )
        )
    }

    companion object {
        private const val START_SPEED_KMH = 3
        private const val STOP_SPEED_KMH = 1
        private const val STOP_AFTER_MS = 25_000L
        private const val REQUEST_INTERVAL_MS = 2_500L
        private const val MAX_ACCURACY_M = 35f
        private const val MIN_ACCEPT_DISTANCE_M = 8f
        private const val MAX_SILENT_INTERVAL_MS = 12_000L
    }
}

data class GpsRouteRuntimeState(
    val enabled: Boolean = false,
    val eligible: Boolean = false,
    val recording: Boolean = false,
    val status: String = "Kapalı",
    val acceptedPointCount: Int = 0,
    val lastAccuracyM: Float? = null
)
