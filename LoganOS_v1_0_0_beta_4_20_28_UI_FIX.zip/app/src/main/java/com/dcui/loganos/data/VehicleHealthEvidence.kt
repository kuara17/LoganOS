package com.dcui.loganos.data

/**
 * Read-only evidence derived from already stored LoganOS drive/sample data.
 * No diagnosis is stored here; the health layer interprets these conservative
 * aggregates at render time so existing history remains the source of truth.
 */
data class VehicleHealthEvidence(
    val completedDriveCount: Int = 0,
    val qualifiedWarmDriveCount: Int = 0,
    val medianEndTempC: Double? = null,
    val warmupObservationCount: Int = 0,
    val medianWarmupMs: Long? = null,
    val warmIdleSampleCount: Int = 0,
    val idleMeanRpm: Double? = null,
    val idleSpreadRpm: Int? = null,
    val consumptionComparisonDriveCount: Int = 0,
    val recentConsumptionL100: Double? = null,
    val previousConsumptionL100: Double? = null
)
