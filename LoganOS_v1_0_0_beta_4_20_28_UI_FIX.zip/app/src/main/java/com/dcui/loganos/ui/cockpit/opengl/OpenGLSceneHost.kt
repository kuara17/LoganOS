package com.dcui.loganos.ui.cockpit.opengl

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

/**
 * Compose/OpenGL interoperability boundary. The renderer receives immutable
 * snapshots only; it never reads or writes Compose state from the GL thread.
 */
@Composable
internal fun OpenGLSceneHost(
    renderState: DigitalV2RenderState,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val glView = remember(context, lifecycleOwner) { LoganGLSurfaceView(context) }

    DisposableEffect(lifecycleOwner, glView) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_RESUME -> glView.resumeRenderer()
                Lifecycle.Event.ON_PAUSE -> glView.pauseRenderer()
                Lifecycle.Event.ON_DESTROY -> glView.releaseRenderer()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            glView.resumeRenderer()
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            glView.releaseRenderer()
        }
    }

    AndroidView(
        factory = { glView },
        update = { it.submitState(renderState) },
        modifier = modifier
    )
}
