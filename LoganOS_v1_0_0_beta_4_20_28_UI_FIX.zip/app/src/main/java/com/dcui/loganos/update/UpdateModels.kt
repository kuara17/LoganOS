package com.dcui.loganos.update

data class UpdateRelease(
    val versionName: String,
    val tagName: String,
    val releaseName: String,
    val releaseNotes: String,
    val publishedAt: String,
    val prerelease: Boolean,
    val apkName: String,
    val apkUrl: String,
    val checksumUrl: String
)

sealed interface UpdateUiState {
    data class Idle(val lastCheckedAtMs: Long?) : UpdateUiState
    data object Checking : UpdateUiState
    data class UpToDate(val checkedAtMs: Long) : UpdateUiState
    data class Available(val release: UpdateRelease) : UpdateUiState
    data class Downloading(val release: UpdateRelease, val progressPercent: Int) : UpdateUiState
    data class ReadyToInstall(
        val release: UpdateRelease,
        val apkPath: String,
        val signerSha256: String
    ) : UpdateUiState
    data class Error(val message: String) : UpdateUiState
}

enum class InstallLaunchResult {
    INSTALLER_OPENED,
    UNKNOWN_SOURCES_SETTINGS_OPENED
}
