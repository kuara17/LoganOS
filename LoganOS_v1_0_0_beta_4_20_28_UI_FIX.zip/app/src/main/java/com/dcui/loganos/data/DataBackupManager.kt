package com.dcui.loganos.data

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import com.dcui.loganos.BuildConfig
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FilterInputStream
import java.io.FilterOutputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.security.DigestInputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Creates and restores a portable LoganOS data backup.
 *
 * Security invariants:
 * - Archives are streamed; the database and the complete ZIP are never held in RAM.
 * - Entry names, entry counts and compressed/expanded sizes are bounded.
 * - SQLite integrity, version-specific exact columns, indexes and foreign keys are checked.
 * - An older valid backup is migrated and smoke-tested before the rollback copy is deleted.
 */
class DataBackupManager(private val context: Context) {

    data class Result(val success: Boolean, val message: String)

    private data class ExtractedArchive(
        val manifestBytes: ByteArray,
        val settingsBytes: ByteArray,
        val databaseSha256: String
    )

    private data class ColumnSpec(
        val type: String,
        val notNull: Boolean = false,
        val primaryKey: Int = 0
    )

    private data class ForeignKeySpec(
        val from: String,
        val targetTable: String,
        val targetColumn: String,
        val onDelete: String
    )

    fun defaultBackupFileName(): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss", Locale.US).format(Date())
        return "LoganOS_Backup_${BuildConfig.VERSION_NAME}_$stamp.zip"
    }

    fun writeBackup(uri: Uri, settingsJson: String, databaseFile: File): Result {
        return runCatching {
            require(databaseFile.isFile && databaseFile.length() in 1L..MAX_DATABASE_BYTES) {
                "Veritabanı yedeği boş veya izin verilen sınırı aşıyor"
            }
            val settingsBytes = settingsJson.toByteArray(Charsets.UTF_8)
            require(settingsBytes.size <= MAX_SETTINGS_BYTES) { "Ayar yedeği beklenenden büyük" }

            val dbUserVersion = validateDatabaseFile(databaseFile)
            require(dbUserVersion == LoganSqlStore.CURRENT_DB_VERSION) {
                "Yedek anlık LoganOS veritabanı sürümünde değil"
            }
            val databaseSha = sha256(databaseFile)
            val manifest = JSONObject()
                .put("formatVersion", BACKUP_FORMAT_VERSION)
                .put("applicationId", context.packageName)
                .put("createdAtMs", System.currentTimeMillis())
                .put("appVersionName", BuildConfig.VERSION_NAME)
                .put("appVersionCode", BuildConfig.VERSION_CODE.toLong())
                .put("databaseUserVersion", dbUserVersion)
                .put("settingsSha256", sha256(settingsBytes))
                .put("databaseSha256", databaseSha)
                .toString(2)
                .toByteArray(Charsets.UTF_8)

            val rawOutput = context.contentResolver.openOutputStream(uri, "rwt")
                ?: error("Yedek dosyası açılamadı")
            BoundedOutputStream(BufferedOutputStream(rawOutput), MAX_ARCHIVE_BYTES).use { bounded ->
                ZipOutputStream(bounded).use { zip ->
                    putBytes(zip, ENTRY_MANIFEST, manifest)
                    putBytes(zip, ENTRY_SETTINGS, settingsBytes)
                    zip.putNextEntry(ZipEntry(ENTRY_DATABASE))
                    databaseFile.inputStream().buffered().use { input ->
                        copyLimited(input, zip, MAX_DATABASE_BYTES, "Veritabanı yedek sınırını aşıyor")
                    }
                    zip.closeEntry()
                }
            }
            Result(true, "Yedek oluşturuldu")
        }.getOrElse { error ->
            runCatching { context.contentResolver.delete(uri, null, null) }
            Result(false, "Yedek oluşturulamadı: ${error.message ?: "bilinmeyen hata"}")
        }
    }

    /**
     * Must be called only after the OBD controller has released/closed the
     * SQLiteOpenHelper. The caller recreates the activity afterwards.
     */
    fun restoreBackup(uri: Uri, prefs: AppPrefs): Result = runCatching {
        val dbFile = context.getDatabasePath(LoganSqlStore.DATABASE_NAME)
        dbFile.parentFile?.mkdirs()
        val incoming = File(dbFile.parentFile, "${dbFile.name}.restore-incoming")
        val rollback = File(dbFile.parentFile, "${dbFile.name}.restore-rollback")
        incoming.delete()
        rollback.delete()

        val extracted = try {
            context.contentResolver.openInputStream(uri)?.use { rawInput ->
                val bounded = BoundedInputStream(BufferedInputStream(rawInput), MAX_ARCHIVE_BYTES)
                ZipInputStream(bounded).use { zip -> extractAllowedEntries(zip, incoming) }
            } ?: error("Yedek dosyası açılamadı")
        } catch (error: Throwable) {
            incoming.delete()
            throw error
        }

        val manifest = JSONObject(extracted.manifestBytes.toString(Charsets.UTF_8))
        require(manifest.optInt("formatVersion", -1) == BACKUP_FORMAT_VERSION) { "Desteklenmeyen yedek biçimi" }
        require(manifest.optString("applicationId") == context.packageName) { "Yedek başka bir uygulama paketine ait" }
        require(
            manifest.optString("settingsSha256").equals(sha256(extracted.settingsBytes), ignoreCase = true)
        ) { "Ayar dosyası bütünlük kontrolünü geçemedi" }
        require(
            manifest.optString("databaseSha256").equals(extracted.databaseSha256, ignoreCase = true)
        ) { "Veritabanı bütünlük kontrolünü geçemedi" }

        val settingsJson = extracted.settingsBytes.toString(Charsets.UTF_8)
        prefs.validateBackupJson(settingsJson)

        val backupUserVersion = validateDatabaseFile(incoming)
        val declaredUserVersion = manifest.optInt("databaseUserVersion", -1)
        require(declaredUserVersion == backupUserVersion) { "Yedek veritabanı sürüm bilgisi uyuşmuyor" }
        require(backupUserVersion in 1..LoganSqlStore.CURRENT_DB_VERSION) {
            "Bu yedek desteklenmeyen bir LoganOS veritabanı sürümü içeriyor"
        }

        val previousSettings = prefs.exportBackupJson()
        var dbSwapped = false
        var restoreSucceeded = false
        try {
            deleteSidecars(dbFile)
            if (dbFile.exists()) {
                require(dbFile.renameTo(rollback)) { "Mevcut veritabanı güvenli geri alma alanına taşınamadı" }
            }
            require(incoming.renameTo(dbFile)) { "Yeni veritabanı etkinleştirilemedi" }
            dbSwapped = true

            // Open through the actual helper so valid v1-v5 backups are migrated by
            // the same production migration chain. Keep rollback until all checks pass.
            val migrationStore = LoganSqlStore(context)
            try {
                val migratedDb = migrationStore.writableDatabase
                migratedDb.rawQuery("SELECT 1", null).use { cursor ->
                    require(cursor.moveToFirst()) { "Geri yüklenen veritabanı açılamadı" }
                }
                migratedDb.rawQuery("PRAGMA wal_checkpoint(FULL)", null).use { cursor -> cursor.moveToFirst() }
            } finally {
                migrationStore.close()
            }
            deleteSidecars(dbFile)
            val migratedVersion = validateDatabaseFile(dbFile)
            require(migratedVersion == LoganSqlStore.CURRENT_DB_VERSION) { "Veritabanı güncel sürüme taşınamadı" }
            smokeTestDatabase(dbFile)

            require(prefs.importBackupJson(settingsJson)) { "Ayarlar geri yüklenemedi" }
            restoreSucceeded = true
            rollback.delete()
            Result(true, "Yedek doğrulandı ve güvenli biçimde geri yüklendi")
        } catch (error: Throwable) {
            runCatching { prefs.importBackupJson(previousSettings) }
            deleteSidecars(dbFile)
            if (dbSwapped) dbFile.delete()
            if (rollback.exists()) {
                require(rollback.renameTo(dbFile)) { "Geri yükleme başarısız oldu ve önceki veritabanı geri alınamadı" }
            }
            throw error
        } finally {
            incoming.delete()
            if (!restoreSucceeded && rollback.exists() && !dbFile.exists()) {
                rollback.renameTo(dbFile)
            }
        }
    }.getOrElse { Result(false, "Geri yükleme başarısız: ${it.message ?: "bilinmeyen hata"}") }

    private fun extractAllowedEntries(zip: ZipInputStream, incomingDatabase: File): ExtractedArchive {
        val allowed = setOf(ENTRY_MANIFEST, ENTRY_SETTINGS, ENTRY_DATABASE)
        val seen = linkedSetOf<String>()
        var manifestBytes: ByteArray? = null
        var settingsBytes: ByteArray? = null
        var databaseSha: String? = null
        var expandedTotal = 0L
        val buffer = ByteArray(STREAM_BUFFER_BYTES)

        while (true) {
            val entry = zip.nextEntry ?: break
            require(!entry.isDirectory) { "Beklenmeyen klasör girdisi" }
            require(entry.name in allowed) { "Beklenmeyen yedek girdisi: ${entry.name}" }
            require(seen.add(entry.name)) { "Yinelenen yedek girdisi: ${entry.name}" }
            require(!entry.name.contains("..") && !entry.name.startsWith("/") && !entry.name.contains('\\')) {
                "Geçersiz yedek yolu"
            }
            val maxEntry = when (entry.name) {
                ENTRY_DATABASE -> MAX_DATABASE_BYTES
                ENTRY_SETTINGS -> MAX_SETTINGS_BYTES.toLong()
                else -> MAX_MANIFEST_BYTES.toLong()
            }
            if (entry.size >= 0L) require(entry.size <= maxEntry) { "Yedek girdisi izin verilen sınırı aşıyor" }

            when (entry.name) {
                ENTRY_DATABASE -> {
                    incomingDatabase.parentFile?.mkdirs()
                    val digest = MessageDigest.getInstance("SHA-256")
                    incomingDatabase.outputStream().buffered().use { output ->
                        var entryTotal = 0L
                        while (true) {
                            val read = zip.read(buffer)
                            if (read < 0) break
                            entryTotal += read
                            expandedTotal += read
                            require(entryTotal <= maxEntry) { "Veritabanı yedek sınırını aşıyor" }
                            require(expandedTotal <= MAX_EXPANDED_BYTES) { "Yedek açıldığında izin verilen sınırı aşıyor" }
                            digest.update(buffer, 0, read)
                            output.write(buffer, 0, read)
                        }
                    }
                    require(incomingDatabase.length() > 0L) { "Yedek veritabanı boş" }
                    databaseSha = digest.digest().toHex()
                }
                ENTRY_SETTINGS -> {
                    settingsBytes = readSmallEntry(zip, maxEntry, buffer) { count ->
                        expandedTotal += count
                        require(expandedTotal <= MAX_EXPANDED_BYTES) { "Yedek açıldığında izin verilen sınırı aşıyor" }
                    }
                }
                ENTRY_MANIFEST -> {
                    manifestBytes = readSmallEntry(zip, maxEntry, buffer) { count ->
                        expandedTotal += count
                        require(expandedTotal <= MAX_EXPANDED_BYTES) { "Yedek açıldığında izin verilen sınırı aşıyor" }
                    }
                }
            }
            zip.closeEntry()
        }

        require(seen == allowed) { "Yedek gerekli dosyaları içermiyor" }
        return ExtractedArchive(
            manifestBytes = requireNotNull(manifestBytes) { "Yedek manifesti eksik" },
            settingsBytes = requireNotNull(settingsBytes) { "Yedek ayarları eksik" },
            databaseSha256 = requireNotNull(databaseSha) { "Yedek veritabanı eksik" }
        )
    }

    private fun readSmallEntry(
        input: InputStream,
        maxBytes: Long,
        buffer: ByteArray,
        onRead: (Long) -> Unit
    ): ByteArray {
        val output = ByteArrayOutputStream(minOf(maxBytes, 16L * 1024L).toInt())
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { "Yedek girdisi izin verilen sınırı aşıyor" }
            onRead(read.toLong())
            output.write(buffer, 0, read)
        }
        return output.toByteArray()
    }

    private fun validateDatabaseFile(file: File): Int {
        require(file.exists() && file.length() in 1L..MAX_DATABASE_BYTES) { "Geçersiz veritabanı dosyası" }
        val header = file.inputStream().use { input ->
            ByteArray(16).also { require(input.read(it) == it.size) { "SQLite başlığı okunamadı" } }
        }
        require(header.toString(Charsets.US_ASCII) == "SQLite format 3\u0000") {
            "Dosya geçerli bir SQLite veritabanı değil"
        }
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        return try {
            val quickCheck = db.rawQuery("PRAGMA quick_check(1)", null).use { cursor ->
                require(cursor.moveToFirst()) { "SQLite bütünlük sonucu alınamadı" }
                cursor.getString(0)
            }
            require(quickCheck.equals("ok", ignoreCase = true)) { "SQLite bütünlük kontrolü başarısız: $quickCheck" }
            val userVersion = db.rawQuery("PRAGMA user_version", null).use { cursor ->
                require(cursor.moveToFirst()) { "SQLite sürümü okunamadı" }
                cursor.getInt(0)
            }
            require(userVersion in 1..LoganSqlStore.CURRENT_DB_VERSION) { "Desteklenmeyen SQLite sürümü: $userVersion" }
            validateDatabaseSchema(db, userVersion)
            userVersion
        } finally {
            db.close()
        }
    }

    private fun validateDatabaseSchema(db: SQLiteDatabase, userVersion: Int) {
        val expectedTables = expectedColumns(userVersion)
        val expectedIndexes = expectedIndexes(userVersion)
        val foundTables = linkedSetOf<String>()
        val foundIndexes = linkedSetOf<String>()

        db.rawQuery(
            "SELECT type,name,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name",
            null
        ).use { cursor ->
            while (cursor.moveToNext()) {
                val type = cursor.getString(0)?.lowercase(Locale.US) ?: error("SQLite nesne türü okunamadı")
                val name = cursor.getString(1) ?: error("SQLite nesne adı okunamadı")
                val sql = if (cursor.isNull(2)) "" else cursor.getString(2)
                when (type) {
                    "table" -> {
                        require(name in expectedTables) { "Beklenmeyen SQLite tablosu: $name" }
                        require(!sql.contains("CREATE VIRTUAL TABLE", ignoreCase = true)) {
                            "Sanal SQLite tabloları geri yüklemede kabul edilmez: $name"
                        }
                        foundTables += name
                    }
                    "index" -> {
                        require(name in expectedIndexes) { "Beklenmeyen SQLite indeksi: $name" }
                        foundIndexes += name
                    }
                    "trigger", "view" -> error("SQLite $type nesneleri geri yüklemede kabul edilmez: $name")
                    else -> error("Desteklenmeyen SQLite şema nesnesi: $type/$name")
                }
            }
        }
        require(foundTables == expectedTables.keys) { "SQLite tablo listesi LoganOS şemasıyla eşleşmiyor" }
        require(foundIndexes == expectedIndexes.keys) { "SQLite indeks listesi LoganOS şemasıyla eşleşmiyor" }

        expectedTables.forEach { (table, expected) ->
            val actual = linkedMapOf<String, ColumnSpec>()
            db.rawQuery("PRAGMA table_info(${quoteIdentifier(table)})", null).use { cursor ->
                while (cursor.moveToNext()) {
                    val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                    val type = cursor.getString(cursor.getColumnIndexOrThrow("type")).uppercase(Locale.US)
                    val notNull = cursor.getInt(cursor.getColumnIndexOrThrow("notnull")) == 1
                    val pk = cursor.getInt(cursor.getColumnIndexOrThrow("pk"))
                    actual[name] = ColumnSpec(type, notNull, pk)
                }
            }
            require(actual.keys == expected.keys) { "SQLite $table kolonları LoganOS şemasıyla eşleşmiyor" }
            expected.forEach { (column, spec) ->
                val actualSpec = actual.getValue(column)
                require(actualSpec.type == spec.type && actualSpec.notNull == spec.notNull && actualSpec.primaryKey == spec.primaryKey) {
                    "SQLite $table.$column tanımı beklenen şemayla eşleşmiyor"
                }
            }

            val actualForeignKeys = linkedSetOf<ForeignKeySpec>()
            db.rawQuery("PRAGMA foreign_key_list(${quoteIdentifier(table)})", null).use { cursor ->
                while (cursor.moveToNext()) {
                    actualForeignKeys += ForeignKeySpec(
                        from = cursor.getString(cursor.getColumnIndexOrThrow("from")),
                        targetTable = cursor.getString(cursor.getColumnIndexOrThrow("table")),
                        targetColumn = cursor.getString(cursor.getColumnIndexOrThrow("to")),
                        onDelete = cursor.getString(cursor.getColumnIndexOrThrow("on_delete")).uppercase(Locale.US)
                    )
                }
            }
            require(actualForeignKeys == expectedForeignKeys(userVersion)[table].orEmpty()) {
                "SQLite $table foreign-key tanımı LoganOS şemasıyla eşleşmiyor"
            }
        }

        expectedIndexes.forEach { (index, expectedColumns) ->
            val actualColumns = mutableListOf<String>()
            db.rawQuery("PRAGMA index_info(${quoteIdentifier(index)})", null).use { cursor ->
                while (cursor.moveToNext()) {
                    actualColumns += cursor.getString(cursor.getColumnIndexOrThrow("name"))
                }
            }
            require(actualColumns == expectedColumns) { "SQLite $index kolonları LoganOS şemasıyla eşleşmiyor" }
        }
    }

    private fun smokeTestDatabase(file: File) {
        val db = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            val queries = listOf(
                "SELECT id,started_at_ms,session_state,version_name FROM drive_sessions LIMIT 1",
                "SELECT id,session_id,time_ms,rpm,raw_obd FROM obd_samples LIMIT 1",
                "SELECT id,event_type,name FROM test_events LIMIT 1",
                "SELECT id,trip_token,status,pinned FROM trip_records LIMIT 1",
                "SELECT id,test_type,status,pinned FROM test_sessions LIMIT 1",
                "SELECT id,test_session_id,time_ms,raw_obd FROM test_samples LIMIT 1",
                "SELECT id,drive_session_id,latitude,longitude FROM gps_points LIMIT 1",
                "SELECT id,thermal_class,successful,confidence FROM start_events LIMIT 1"
            )
            queries.forEach { query -> db.rawQuery(query, null).use { it.moveToFirst() } }
            db.rawQuery("PRAGMA foreign_key_check", null).use { cursor ->
                require(!cursor.moveToFirst()) { "Geri yüklenen veritabanında foreign-key ihlali bulundu" }
            }
        } finally {
            db.close()
        }
    }

    private fun expectedColumns(version: Int): Map<String, LinkedHashMap<String, ColumnSpec>> {
        val schemas = linkedMapOf(
            "android_metadata" to columns("locale" to col("TEXT")),
            "drive_sessions" to columns(
                "id" to col("INTEGER", pk = 1),
                "started_at_ms" to col("INTEGER", nn = true),
                "ended_at_ms" to col("INTEGER"),
                "started_elapsed_ms" to col("INTEGER", nn = true),
                "ended_elapsed_ms" to col("INTEGER"),
                "boot_session_id" to col("TEXT", nn = true),
                "start_time_trusted" to col("INTEGER", nn = true),
                "end_time_trusted" to col("INTEGER", nn = true),
                "session_state" to col("TEXT", nn = true),
                "version_name" to col("TEXT", nn = true),
                "adapter_name" to col("TEXT"),
                "adapter_address" to col("TEXT"),
                "note" to col("TEXT"),
                "trip_record_id" to col("INTEGER")
            ),
            "obd_samples" to columns(
                "id" to col("INTEGER", pk = 1), "session_id" to col("INTEGER", nn = true),
                "time_ms" to col("INTEGER", nn = true), "elapsed_ms" to col("INTEGER", nn = true),
                "boot_session_id" to col("TEXT", nn = true), "time_trusted" to col("INTEGER", nn = true),
                "loop_index" to col("INTEGER"), "loop_ms" to col("INTEGER"), "rpm" to col("INTEGER"),
                "speed_kmh" to col("INTEGER"), "coolant_c" to col("INTEGER"), "fuel_mg" to col("REAL"),
                "fuel_lh" to col("REAL"), "instant_value" to col("REAL"), "instant_unit" to col("TEXT"),
                "pedal_percent" to col("REAL"), "map_mbar" to col("INTEGER"), "air_charge" to col("REAL"),
                "ac_on" to col("INTEGER"), "fan_state" to col("TEXT"), "fuel_source" to col("TEXT"),
                "trip_state" to col("TEXT"), "trip_distance_km" to col("REAL"), "fuel_used_l" to col("REAL"),
                "avg_l100" to col("REAL"), "raw21cc" to col("TEXT"), "raw21a0" to col("TEXT"),
                "raw21a2" to col("TEXT"), "raw21cd" to col("TEXT"), "raw_obd" to col("TEXT")
            ),
            "test_events" to columns(
                "id" to col("INTEGER", pk = 1), "session_id" to col("INTEGER"),
                "time_ms" to col("INTEGER", nn = true), "elapsed_ms" to col("INTEGER", nn = true),
                "boot_session_id" to col("TEXT", nn = true), "time_trusted" to col("INTEGER", nn = true),
                "event_type" to col("TEXT", nn = true), "name" to col("TEXT", nn = true), "note" to col("TEXT")
            ),
            "trip_records" to columns(
                "id" to col("INTEGER", pk = 1), "trip_token" to col("INTEGER", nn = true),
                "started_at_ms" to col("INTEGER", nn = true), "ended_at_ms" to col("INTEGER"),
                "started_elapsed_ms" to col("INTEGER", nn = true), "ended_elapsed_ms" to col("INTEGER"),
                "start_boot_session_id" to col("TEXT", nn = true), "end_boot_session_id" to col("TEXT"),
                "start_time_trusted" to col("INTEGER", nn = true), "end_time_trusted" to col("INTEGER", nn = true),
                "status" to col("TEXT", nn = true), "pinned" to col("INTEGER", nn = true),
                "exported_at_ms" to col("INTEGER"), "distance_km" to col("REAL", nn = true),
                "fuel_used_l" to col("REAL", nn = true), "duration_ms" to col("INTEGER", nn = true),
                "average_l100" to col("REAL"), "max_speed_kmh" to col("INTEGER"), "max_rpm" to col("INTEGER"),
                "start_temp_c" to col("INTEGER"), "end_temp_c" to col("INTEGER"),
                "sample_count" to col("INTEGER", nn = true), "first_session_id" to col("INTEGER"),
                "last_session_id" to col("INTEGER"), "created_version" to col("TEXT", nn = true), "note" to col("TEXT")
            ),
            "test_sessions" to columns(
                "id" to col("INTEGER", pk = 1), "drive_session_id" to col("INTEGER"),
                "test_type" to col("TEXT", nn = true), "name" to col("TEXT", nn = true),
                "started_at_ms" to col("INTEGER", nn = true), "ended_at_ms" to col("INTEGER"),
                "started_elapsed_ms" to col("INTEGER", nn = true), "ended_elapsed_ms" to col("INTEGER"),
                "start_boot_session_id" to col("TEXT", nn = true), "end_boot_session_id" to col("TEXT"),
                "start_time_trusted" to col("INTEGER", nn = true), "end_time_trusted" to col("INTEGER", nn = true),
                "status" to col("TEXT", nn = true), "pinned" to col("INTEGER", nn = true),
                "exported_at_ms" to col("INTEGER"), "created_version" to col("TEXT", nn = true), "summary" to col("TEXT")
            ),
            "test_samples" to columns(
                "id" to col("INTEGER", pk = 1), "test_session_id" to col("INTEGER", nn = true),
                "time_ms" to col("INTEGER", nn = true), "elapsed_ms" to col("INTEGER", nn = true),
                "boot_session_id" to col("TEXT", nn = true), "time_trusted" to col("INTEGER", nn = true),
                "loop_index" to col("INTEGER"), "loop_ms" to col("INTEGER"), "rpm" to col("INTEGER"),
                "speed_kmh" to col("INTEGER"), "coolant_c" to col("INTEGER"), "fuel_mg" to col("REAL"),
                "instant_value" to col("REAL"), "instant_unit" to col("TEXT"), "pedal_percent" to col("REAL"),
                "map_mbar" to col("INTEGER"), "air_charge" to col("REAL"), "ac_on" to col("INTEGER"),
                "fan_state" to col("TEXT"), "fuel_source" to col("TEXT"), "trip_state" to col("TEXT"),
                "trip_distance_km" to col("REAL"), "fuel_used_l" to col("REAL"), "avg_l100" to col("REAL"),
                "raw21cc" to col("TEXT"), "raw21a0" to col("TEXT"), "raw21a2" to col("TEXT"),
                "raw21cd" to col("TEXT"), "raw_obd" to col("TEXT")
            ),
            "gps_points" to columns(
                "id" to col("INTEGER", pk = 1), "drive_session_id" to col("INTEGER", nn = true),
                "time_ms" to col("INTEGER", nn = true), "elapsed_ms" to col("INTEGER", nn = true),
                "boot_session_id" to col("TEXT", nn = true), "time_trusted" to col("INTEGER", nn = true),
                "latitude" to col("REAL", nn = true), "longitude" to col("REAL", nn = true),
                "accuracy_m" to col("REAL", nn = true)
            ),
            "start_events" to columns(
                "id" to col("INTEGER", pk = 1), "drive_session_id" to col("INTEGER"),
                "time_ms" to col("INTEGER", nn = true), "elapsed_ms" to col("INTEGER", nn = true),
                "boot_session_id" to col("TEXT", nn = true), "time_trusted" to col("INTEGER", nn = true),
                "engine_temp_c" to col("INTEGER"), "thermal_class" to col("TEXT", nn = true),
                "crank_duration_ms" to col("INTEGER"), "stabilization_duration_ms" to col("INTEGER"),
                "attempt_count" to col("INTEGER", nn = true), "successful" to col("INTEGER", nn = true),
                "initial_crank_rpm" to col("INTEGER"), "initial_running_rpm" to col("INTEGER"),
                "peak_start_rpm" to col("INTEGER"), "stable_idle_rpm" to col("INTEGER"),
                "confidence" to col("TEXT", nn = true), "obd_gap_detected" to col("INTEGER", nn = true),
                "manual_trigger" to col("INTEGER", nn = true), "note" to col("TEXT")
            )
        )

        if (version < 2) {
            listOf("started_elapsed_ms", "ended_elapsed_ms", "boot_session_id", "start_time_trusted", "end_time_trusted", "session_state")
                .forEach { schemas.getValue("drive_sessions").remove(it) }
            listOf("elapsed_ms", "boot_session_id", "time_trusted").forEach {
                schemas.getValue("obd_samples").remove(it)
                schemas.getValue("test_events").remove(it)
            }
        }
        if (version < 3) {
            schemas.getValue("drive_sessions").remove("trip_record_id")
            schemas.remove("trip_records")
            schemas.remove("test_sessions")
            schemas.remove("test_samples")
        }
        if (version < 4) {
            schemas["obd_samples"]?.remove("raw_obd")
            schemas["test_samples"]?.remove("raw_obd")
        }
        if (version < 5) schemas.remove("gps_points")
        if (version < 6) schemas.remove("start_events")
        return schemas
    }

    private fun expectedIndexes(version: Int): Map<String, List<String>> {
        val indexes = linkedMapOf<String, List<String>>()
        if (version >= 2) {
            indexes["idx_samples_session_elapsed"] = listOf("session_id", "elapsed_ms")
            indexes["idx_events_session_elapsed"] = listOf("session_id", "elapsed_ms")
            indexes["idx_sessions_state"] = listOf("session_state", "id")
        }
        if (version >= 3) {
            indexes["idx_sessions_trip"] = listOf("trip_record_id", "id")
            indexes["idx_trip_records_status"] = listOf("status", "pinned", "ended_at_ms")
            indexes["idx_test_sessions_status"] = listOf("status", "pinned", "ended_at_ms")
            indexes["idx_test_samples_session_elapsed"] = listOf("test_session_id", "elapsed_ms")
        }
        if (version >= 5) indexes["idx_gps_points_session_elapsed"] = listOf("drive_session_id", "elapsed_ms")
        if (version >= 6) {
            indexes["idx_start_events_time"] = listOf("time_ms", "id")
            indexes["idx_start_events_thermal"] = listOf("thermal_class", "successful", "id")
        }
        return indexes
    }

    private fun expectedForeignKeys(version: Int): Map<String, Set<ForeignKeySpec>> {
        val result = linkedMapOf<String, Set<ForeignKeySpec>>()
        result["obd_samples"] = setOf(ForeignKeySpec("session_id", "drive_sessions", "id", "CASCADE"))
        result["test_events"] = setOf(ForeignKeySpec("session_id", "drive_sessions", "id", "CASCADE"))
        if (version >= 3) {
            result["test_sessions"] = setOf(ForeignKeySpec("drive_session_id", "drive_sessions", "id", "SET NULL"))
            result["test_samples"] = setOf(ForeignKeySpec("test_session_id", "test_sessions", "id", "CASCADE"))
        }
        if (version >= 5) result["gps_points"] = setOf(ForeignKeySpec("drive_session_id", "drive_sessions", "id", "CASCADE"))
        if (version >= 6) result["start_events"] = setOf(ForeignKeySpec("drive_session_id", "drive_sessions", "id", "SET NULL"))
        return result
    }

    private fun putBytes(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(bytes)
        zip.closeEntry()
    }

    private fun copyLimited(input: InputStream, output: OutputStream, maxBytes: Long, message: String): Long {
        val buffer = ByteArray(STREAM_BUFFER_BYTES)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { message }
            output.write(buffer, 0, read)
        }
        return total
    }

    private fun sha256(file: File): String {
        val digest = MessageDigest.getInstance("SHA-256")
        file.inputStream().buffered().use { input ->
            DigestInputStream(input, digest).use { digestInput ->
                val buffer = ByteArray(STREAM_BUFFER_BYTES)
                while (digestInput.read(buffer) >= 0) Unit
            }
        }
        return digest.digest().toHex()
    }

    private fun sha256(bytes: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(bytes).toHex()

    private fun ByteArray.toHex(): String = joinToString("") { "%02x".format(it) }

    private fun deleteSidecars(dbFile: File) {
        listOf("-wal", "-shm", "-journal").forEach { suffix -> File(dbFile.absolutePath + suffix).delete() }
    }

    private fun quoteIdentifier(value: String): String = "\"${value.replace("\"", "\"\"")}\""

    private fun col(type: String, nn: Boolean = false, pk: Int = 0): ColumnSpec = ColumnSpec(type, nn, pk)

    private fun columns(vararg pairs: Pair<String, ColumnSpec>): LinkedHashMap<String, ColumnSpec> = linkedMapOf(*pairs)

    private class BoundedInputStream(input: InputStream, private val maxBytes: Long) : FilterInputStream(input) {
        private var total = 0L

        override fun read(): Int {
            val value = super.read()
            if (value >= 0) account(1)
            return value
        }

        override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
            val read = super.read(buffer, offset, length)
            if (read > 0) account(read.toLong())
            return read
        }

        private fun account(count: Long) {
            total += count
            if (total > maxBytes) throw IOException("Yedek dosyası izin verilen sınırı aşıyor")
        }
    }

    private class BoundedOutputStream(output: OutputStream, private val maxBytes: Long) : FilterOutputStream(output) {
        private var total = 0L

        override fun write(value: Int) {
            account(1)
            out.write(value)
        }

        override fun write(buffer: ByteArray, offset: Int, length: Int) {
            account(length.toLong())
            out.write(buffer, offset, length)
        }

        private fun account(count: Long) {
            total += count
            if (total > maxBytes) throw IOException("Yedek dosyası izin verilen sınırı aşıyor")
        }
    }

    companion object {
        private const val BACKUP_FORMAT_VERSION = 1
        private const val ENTRY_MANIFEST = "manifest.json"
        private const val ENTRY_SETTINGS = "settings/settings.json"
        private const val ENTRY_DATABASE = "database/loganos_records.db"
        private const val STREAM_BUFFER_BYTES = 32 * 1024
        private const val MAX_MANIFEST_BYTES = 256 * 1024
        private const val MAX_SETTINGS_BYTES = 2 * 1024 * 1024
        private const val MAX_DATABASE_BYTES = 64L * 1024L * 1024L
        private const val MAX_ARCHIVE_BYTES = 72L * 1024L * 1024L
        private const val MAX_EXPANDED_BYTES = 67L * 1024L * 1024L
    }
}
