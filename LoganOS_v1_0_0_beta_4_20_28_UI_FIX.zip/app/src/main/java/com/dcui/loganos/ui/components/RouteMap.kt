package com.dcui.loganos.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.LruCache
import android.os.SystemClock
import android.view.View
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.data.GpsRouteDetail
import com.dcui.loganos.data.GpsRoutePoint
import com.dcui.loganos.ui.theme.LoganPalette
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.floor
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.tan

/**
 * Lightweight, dependency-free route map for completed drives.
 *
 * Only tiles visible in the current viewport are requested. They are cached on
 * disk for repeat views; there is no prefetch/offline-area download feature.
 * The GPS polyline always stays local and is drawn by LoganOS over the basemap.
 */
@Composable
fun RouteMapCard(
    palette: LoganPalette,
    route: GpsRouteDetail,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        AndroidView(
            factory = { context -> RouteTileMapView(context) },
            update = { view ->
                view.setColors(
                    background = palette.surfaceVariant.toArgb(),
                    grid = palette.line.copy(alpha = 0.55f).toArgb(),
                    route = palette.accent.toArgb(),
                    text = palette.textSecondary.toArgb()
                )
                view.setRoute(route)
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .clip(RoundedCornerShape(16.dp))
        )
        Text(
            text = "© OpenStreetMap contributors • Harita zemini internetten yüklenir; önbellekteki karolar çevrimdışı tekrar gösterilebilir. GPS rotası cihazda kalır.",
            color = palette.textSecondary,
            fontSize = 9.sp,
            lineHeight = 12.sp,
            modifier = Modifier.padding(top = 5.dp)
        )
    }
}

private class RouteTileMapView(context: Context) : View(context) {
    private data class TileKey(val z: Int, val x: Int, val y: Int)
    private data class WorldPoint(val x: Double, val y: Double)

    private val tileSize = 256.0
    private val cacheDir = File(context.cacheDir, "route_map_tiles").apply { mkdirs() }
    private val loading = Collections.synchronizedSet(mutableSetOf<TileKey>())
    private val failedUntilElapsedMs = ConcurrentHashMap<TileKey, Long>()
    private val memoryCache = object : LruCache<String, Bitmap>(12 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    private var routeDetail = GpsRouteDetail()
    private var transformDirty = true
    private var zoom = 13
    private var centerWorld = WorldPoint(0.0, 0.0)

    private var backgroundColorValue: Int = 0xFFF4F6F8.toInt()
    private var gridColorValue: Int = 0x22000000
    private var routeColorValue: Int = 0xFF207DFF.toInt()
    private var textColorValue: Int = 0xFF5D6470.toInt()

    private val backgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeWidth = 1f }
    private val routeHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 9f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = 0xCCFFFFFF.toInt()
    }
    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val markerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val markerHaloPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt() }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 22f }

    init {
        // Keep the OSM tile cache bounded even on head units used for years.
        TILE_EXECUTOR.execute { pruneDiskCache() }
    }

    fun setRoute(route: GpsRouteDetail) {
        if (route == routeDetail) return
        routeDetail = route
        transformDirty = true
        invalidate()
    }

    fun setColors(background: Int, grid: Int, route: Int, text: Int) {
        backgroundColorValue = background
        gridColorValue = grid
        routeColorValue = route
        textColorValue = text
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        transformDirty = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        backgroundPaint.color = backgroundColorValue
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), backgroundPaint)
        drawFallbackGrid(canvas)

        val points = routeDetail.segments.flatMap { it.points }
        if (points.isEmpty()) {
            textPaint.color = textColorValue
            textPaint.textAlign = Paint.Align.CENTER
            textPaint.textSize = 24f
            canvas.drawText("Bu sürüşte GPS rota kaydı yok", width / 2f, height / 2f, textPaint)
            return
        }

        if (transformDirty) calculateTransform(points)
        drawVisibleTiles(canvas)
        drawRoute(canvas)
        drawAttribution(canvas)
    }

    private fun drawFallbackGrid(canvas: Canvas) {
        gridPaint.color = gridColorValue
        var x = 0f
        while (x < width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += 48f
        }
        var y = 0f
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += 48f
        }
    }

    private fun calculateTransform(points: List<GpsRoutePoint>) {
        if (width <= 0 || height <= 0) return
        val padX = 36.0
        val padY = 36.0
        var chosenZoom = 3
        var chosenCenter = WorldPoint(0.0, 0.0)
        for (candidate in 17 downTo 3) {
            val projected = points.map { project(it.latitude, it.longitude, candidate) }
            val minX = projected.minOf { it.x }
            val maxX = projected.maxOf { it.x }
            val minY = projected.minOf { it.y }
            val maxY = projected.maxOf { it.y }
            val spanX = max(40.0, maxX - minX)
            val spanY = max(40.0, maxY - minY)
            if (spanX <= width - padX * 2.0 && spanY <= height - padY * 2.0) {
                chosenZoom = candidate
                chosenCenter = WorldPoint((minX + maxX) / 2.0, (minY + maxY) / 2.0)
                break
            }
            if (candidate == 3) chosenCenter = WorldPoint((minX + maxX) / 2.0, (minY + maxY) / 2.0)
        }
        zoom = chosenZoom
        centerWorld = chosenCenter
        transformDirty = false
    }

    private fun drawVisibleTiles(canvas: Canvas) {
        if (width <= 0 || height <= 0) return
        val leftWorld = centerWorld.x - width / 2.0
        val topWorld = centerWorld.y - height / 2.0
        val rightWorld = centerWorld.x + width / 2.0
        val bottomWorld = centerWorld.y + height / 2.0
        val minTileX = floor(leftWorld / tileSize).toInt() - 1
        val maxTileX = floor(rightWorld / tileSize).toInt() + 1
        val minTileY = floor(topWorld / tileSize).toInt() - 1
        val maxTileY = floor(bottomWorld / tileSize).toInt() + 1
        val worldTiles = 1 shl zoom

        for (rawX in minTileX..maxTileX) {
            val tileX = ((rawX % worldTiles) + worldTiles) % worldTiles
            for (tileY in minTileY..maxTileY) {
                if (tileY !in 0 until worldTiles) continue
                val key = TileKey(zoom, tileX, tileY)
                val bitmap = memoryCache.get(cacheKey(key))
                val drawX = (rawX * tileSize - leftWorld).toFloat()
                val drawY = (tileY * tileSize - topWorld).toFloat()
                if (bitmap != null && !bitmap.isRecycled) {
                    canvas.drawBitmap(bitmap, null, RectF(drawX, drawY, drawX + 256f, drawY + 256f), null)
                } else {
                    requestTile(key)
                }
            }
        }
    }

    private fun drawRoute(canvas: Canvas) {
        val leftWorld = centerWorld.x - width / 2.0
        val topWorld = centerWorld.y - height / 2.0
        routeHaloPaint.color = 0xDFFFFFFF.toInt()
        routePaint.color = routeColorValue

        routeDetail.segments.forEach { segment ->
            if (segment.points.size < 2) return@forEach
            val path = Path()
            segment.points.forEachIndexed { index, point ->
                val world = project(point.latitude, point.longitude, zoom)
                val x = (world.x - leftWorld).toFloat()
                val y = (world.y - topWorld).toFloat()
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, routeHaloPaint)
            canvas.drawPath(path, routePaint)
        }

        val first = routeDetail.segments.firstOrNull { it.points.isNotEmpty() }?.points?.firstOrNull()
        val last = routeDetail.segments.lastOrNull { it.points.isNotEmpty() }?.points?.lastOrNull()
        first?.let { drawMarker(canvas, it, leftWorld, topWorld, 0xFF1FAD55.toInt()) }
        last?.let { drawMarker(canvas, it, leftWorld, topWorld, 0xFFE53935.toInt()) }
    }

    private fun drawMarker(canvas: Canvas, point: GpsRoutePoint, leftWorld: Double, topWorld: Double, color: Int) {
        val world = project(point.latitude, point.longitude, zoom)
        val x = (world.x - leftWorld).toFloat()
        val y = (world.y - topWorld).toFloat()
        canvas.drawCircle(x, y, 11f, markerHaloPaint)
        markerPaint.color = color
        canvas.drawCircle(x, y, 7f, markerPaint)
    }

    private fun drawAttribution(canvas: Canvas) {
        textPaint.color = 0xCC30343B.toInt()
        textPaint.textSize = 18f
        textPaint.textAlign = Paint.Align.RIGHT
        canvas.drawText("© OpenStreetMap contributors", width - 10f, height - 10f, textPaint)
    }

    private fun requestTile(key: TileKey) {
        val now = SystemClock.elapsedRealtime()
        if ((failedUntilElapsedMs[key] ?: 0L) > now) return
        val cacheKey = cacheKey(key)
        if (!loading.add(key)) return
        TILE_EXECUTOR.execute {
            try {
                val file = tileFile(key)
                val bitmap = if (file.isFile && file.length() > 0L) {
                    BitmapFactory.decodeFile(file.absolutePath)?.also {
                        // lastModified acts as a lightweight disk-LRU access mark.
                        file.setLastModified(System.currentTimeMillis())
                    }
                } else {
                    downloadTile(key, file)
                }
                if (bitmap != null) {
                    failedUntilElapsedMs.remove(key)
                    memoryCache.put(cacheKey, bitmap)
                } else {
                    // Avoid a tight retry loop while offline or when the public
                    // tile server is temporarily unavailable.
                    failedUntilElapsedMs[key] = SystemClock.elapsedRealtime() + TILE_FAILURE_BACKOFF_MS
                }
            } finally {
                loading.remove(key)
                postInvalidateOnAnimation()
            }
        }
    }

    private fun downloadTile(key: TileKey, file: File): Bitmap? {
        val url = URL("https://tile.openstreetmap.org/${key.z}/${key.x}/${key.y}.png")
        if (url.protocol != "https" || url.host != OSM_TILE_HOST) return null
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8_000
            readTimeout = 8_000
            instanceFollowRedirects = false
            setRequestProperty("User-Agent", "LoganOS/${BuildConfig.VERSION_NAME} (Android; com.dcui.loganos)")
            setRequestProperty("Accept", "image/png")
        }
        return try {
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            val contentType = connection.contentType?.substringBefore(';')?.trim()?.lowercase()
            if (contentType != "image/png") return null
            val declaredLength = connection.contentLengthLong
            if (declaredLength > MAX_TILE_RESPONSE_BYTES) return null

            val bytes = connection.inputStream.use { input ->
                val output = ByteArrayOutputStream()
                val buffer = ByteArray(16 * 1024)
                var total = 0
                while (true) {
                    val read = input.read(buffer)
                    if (read < 0) break
                    total += read
                    if (total > MAX_TILE_RESPONSE_BYTES) return null
                    output.write(buffer, 0, read)
                }
                output.toByteArray()
            }
            if (!hasPngSignature(bytes)) return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth !in ALLOWED_TILE_DIMENSIONS || bounds.outHeight !in ALLOWED_TILE_DIMENSIONS) return null

            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
            file.parentFile?.mkdirs()
            file.writeBytes(bytes)
            file.setLastModified(System.currentTimeMillis())
            pruneDiskCache()
            bitmap
        } catch (_: Throwable) {
            null
        } finally {
            connection.disconnect()
        }
    }

    private fun hasPngSignature(bytes: ByteArray): Boolean {
        if (bytes.size < PNG_SIGNATURE.size) return false
        return PNG_SIGNATURE.indices.all { index -> bytes[index] == PNG_SIGNATURE[index] }
    }

    private fun tileFile(key: TileKey): File = File(cacheDir, "${key.z}/${key.x}/${key.y}.png")
    private fun cacheKey(key: TileKey): String = "${key.z}/${key.x}/${key.y}"

    private fun pruneDiskCache() {
        synchronized(TILE_CACHE_LOCK) {
            val files = cacheDir.walkTopDown().filter { it.isFile }.toList()
            var totalBytes = files.sumOf { it.length().coerceAtLeast(0L) }
            if (totalBytes <= MAX_TILE_CACHE_BYTES) return

            for (file in files.sortedBy { it.lastModified() }) {
                if (totalBytes <= TARGET_TILE_CACHE_BYTES) break
                val length = file.length().coerceAtLeast(0L)
                if (file.delete()) totalBytes = (totalBytes - length).coerceAtLeast(0L)
            }
            cacheDir.walkBottomUp()
                .filter { it.isDirectory && it != cacheDir }
                .forEach { directory ->
                    if (directory.listFiles().isNullOrEmpty()) directory.delete()
                }
        }
    }

    private fun project(latitude: Double, longitude: Double, zoom: Int): WorldPoint {
        val safeLat = latitude.coerceIn(-85.05112878, 85.05112878)
        val n = 2.0.pow(zoom.toDouble()) * tileSize
        val x = (longitude + 180.0) / 360.0 * n
        val latRad = Math.toRadians(safeLat)
        val y = (1.0 - ln(tan(latRad) + 1.0 / kotlin.math.cos(latRad)) / PI) / 2.0 * n
        return WorldPoint(x, y)
    }

    companion object {
        private const val TILE_FAILURE_BACKOFF_MS = 120_000L
        private const val OSM_TILE_HOST = "tile.openstreetmap.org"
        private const val MAX_TILE_RESPONSE_BYTES = 1024 * 1024
        private val ALLOWED_TILE_DIMENSIONS = setOf(256, 512)
        private val PNG_SIGNATURE = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        private const val MAX_TILE_CACHE_BYTES = 75L * 1024L * 1024L
        private const val TARGET_TILE_CACHE_BYTES = 68L * 1024L * 1024L
        private val TILE_CACHE_LOCK = Any()
        private val TILE_EXECUTOR = Executors.newFixedThreadPool(2)
    }
}
