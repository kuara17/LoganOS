package com.dcui.loganos.obd

enum class StartThermalClass { COLD, WARM, HOT, UNKNOWN }
enum class StartConfidence { HIGH, MEDIUM, LOW }

data class StartEvent(
    val id: Long = 0L,
    val driveSessionId: Long? = null,
    val timestampMs: Long,
    val elapsedMs: Long,
    val timeTrusted: Boolean,
    val engineTempC: Int?,
    val thermalClass: StartThermalClass,
    val crankDurationMs: Long?,
    val stabilizationDurationMs: Long?,
    val attemptCount: Int,
    val successful: Boolean,
    val initialCrankRpm: Int?,
    val initialRunningRpm: Int?,
    val peakStartRpm: Int?,
    val stableIdleRpm: Int?,
    val confidence: StartConfidence,
    val obdGapDetected: Boolean,
    val manualTrigger: Boolean,
    val note: String? = null
)

data class StartAnalysisSummary(
    val totalRecorded: Int = 0,
    val successfulRecorded: Int = 0,
    val failedRecorded: Int = 0,
    val coldCount: Int = 0,
    val hotCount: Int = 0,
    val coldAverageMs: Long? = null,
    val hotAverageMs: Long? = null,
    val recentAverageMs: Long? = null,
    val previousAverageMs: Long? = null,
    val recentTrendPercent: Double? = null,
    val trendStatus: String = "INSUFFICIENT_DATA",
    val trendMessageTr: String = "Karşılaştırma için yeterli güvenilir marş kaydı yok.",
    val trendMessageEn: String = "There are not enough reliable start records for comparison."
)

object StartAnalyzer {
    fun thermalClass(engineTempC: Int?): StartThermalClass = when {
        engineTempC == null -> StartThermalClass.UNKNOWN
        engineTempC <= 35 -> StartThermalClass.COLD
        engineTempC >= 70 -> StartThermalClass.HOT
        else -> StartThermalClass.WARM
    }

    fun summarize(events: List<StartEvent>): StartAnalysisSummary {
        val ordered = events.sortedWith(
            compareByDescending<StartEvent> { it.id }
                .thenByDescending { it.timestampMs }
                .thenByDescending { it.elapsedMs }
        )
        val reliable = ordered.filter {
            it.successful && it.crankDurationMs != null && it.confidence != StartConfidence.LOW && !it.obdGapDetected
        }
        val cold = reliable.filter { it.thermalClass == StartThermalClass.COLD }.take(10)
        val hot = reliable.filter { it.thermalClass == StartThermalClass.HOT }.take(10)

        data class TrendCandidate(
            val thermalClass: StartThermalClass,
            val recent: List<StartEvent>,
            val previous: List<StartEvent>,
            val recentAvg: Long,
            val previousAvg: Long,
            val percent: Double,
            val absoluteDelta: Long
        )

        fun candidate(items: List<StartEvent>, thermalClass: StartThermalClass): TrendCandidate? {
            val recent = items.take(5)
            val previous = items.drop(5).take(5)
            if (recent.size < 3 || previous.size < 3) return null
            val recentAvg = recent.mapNotNull { it.crankDurationMs }.average().toLong()
            val previousAvg = previous.mapNotNull { it.crankDurationMs }.average().toLong()
            if (previousAvg <= 0L) return null
            return TrendCandidate(
                thermalClass = thermalClass,
                recent = recent,
                previous = previous,
                recentAvg = recentAvg,
                previousAvg = previousAvg,
                percent = ((recentAvg - previousAvg).toDouble() / previousAvg.toDouble()) * 100.0,
                absoluteDelta = recentAvg - previousAvg
            )
        }

        val trendCandidate = listOfNotNull(
            candidate(cold, StartThermalClass.COLD),
            candidate(hot, StartThermalClass.HOT)
        ).maxByOrNull { it.recent.size + it.previous.size }

        val recentFailures = ordered.take(5).count { !it.successful }
        val status: String
        val tr: String
        val en: String
        when {
            recentFailures >= 2 -> {
                status = "WATCH"
                tr = "Son kayıtlarda birden fazla başarısız marş denemesi görüldü; tekrar ederse takip edin."
                en = "Multiple unsuccessful start attempts were recorded recently; monitor if this repeats."
            }
            trendCandidate != null && trendCandidate.percent >= 30.0 && trendCandidate.absoluteDelta >= 400L -> {
                status = "WATCH"
                val labelTr = if (trendCandidate.thermalClass == StartThermalClass.COLD) "soğuk" else "sıcak"
                val labelEn = if (trendCandidate.thermalClass == StartThermalClass.COLD) "cold" else "hot"
                tr = "Son güvenilir $labelTr marşlar önceki kişisel ortalamanızdan belirgin şekilde daha uzun görünüyor."
                en = "Recent reliable $labelEn starts appear noticeably longer than your previous personal baseline."
            }
            trendCandidate != null && trendCandidate.percent <= -20.0 && trendCandidate.absoluteDelta <= -300L -> {
                status = "IMPROVING"
                val labelTr = if (trendCandidate.thermalClass == StartThermalClass.COLD) "soğuk" else "sıcak"
                val labelEn = if (trendCandidate.thermalClass == StartThermalClass.COLD) "cold" else "hot"
                tr = "Son güvenilir $labelTr marşlar önceki kişisel ortalamanıza göre daha kısa görünüyor."
                en = "Recent reliable $labelEn starts appear shorter than your previous personal baseline."
            }
            trendCandidate != null -> {
                status = "STABLE"
                val labelTr = if (trendCandidate.thermalClass == StartThermalClass.COLD) "soğuk" else "sıcak"
                val labelEn = if (trendCandidate.thermalClass == StartThermalClass.COLD) "cold" else "hot"
                tr = "Son güvenilir $labelTr marşlar kişisel geçmiş ortalamanızla benzer seyrediyor."
                en = "Recent reliable $labelEn starts are broadly consistent with your personal history."
            }
            else -> {
                status = "INSUFFICIENT_DATA"
                tr = "Soğuk veya sıcak karşılaştırması için aynı sıcaklık grubunda en az birkaç güvenilir marş kaydı daha gerekli."
                en = "A few more reliable starts in the same temperature group are needed for cold or hot comparison."
            }
        }
        fun avg(items: List<StartEvent>): Long? = items.mapNotNull { it.crankDurationMs }.takeIf { it.isNotEmpty() }?.average()?.toLong()
        return StartAnalysisSummary(
            totalRecorded = ordered.size,
            successfulRecorded = ordered.count { it.successful },
            failedRecorded = ordered.count { !it.successful },
            coldCount = cold.size,
            hotCount = hot.size,
            coldAverageMs = avg(cold),
            hotAverageMs = avg(hot),
            recentAverageMs = trendCandidate?.recentAvg,
            previousAverageMs = trendCandidate?.previousAvg,
            recentTrendPercent = trendCandidate?.percent,
            trendStatus = status,
            trendMessageTr = tr,
            trendMessageEn = en
        )
    }
}
