package com.dcui.loganos.ui.cockpit

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DigitalV2GaugeMode
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.model.VehicleVisualModel
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.theme.LoganPalette
import com.dcui.loganos.ui.cockpit.opengl.DIGITAL_V2_STAGE_ASPECT_RATIO
import com.dcui.loganos.ui.cockpit.opengl.OpenGLSceneHost
import com.dcui.loganos.ui.cockpit.opengl.digitalV2CompositeRes
import com.dcui.loganos.ui.cockpit.opengl.digitalV2RenderState
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

private val DigitalV2Blue = Color(0xFF1479FF)
private val DigitalV2Red = Color(0xFFFF3B30)
private val DigitalV2Glass = Color(0xEAF7F9FC)
private const val DigitalV2CalibrationVisible = false

@Composable
fun DigitalV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    portrait: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        // Keep the OpenGL host at one stable Compose call site. Orientation
        // changes only resize the existing SurfaceView; they do not dispose one
        // portrait branch and create a second landscape EGL context.
        val portraitStageMaxHeight = maxHeight * 0.62f
        val landscapePanelWidth = if (portrait) 0.dp else maxWidth * (1f / 2.55f)
        val landscapeSceneAreaWidth = maxWidth - landscapePanelWidth
        val stageWidth = if (portrait) {
            minOf(maxWidth, portraitStageMaxHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
        } else {
            minOf(landscapeSceneAreaWidth, maxHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
        }
        val stageHeight = stageWidth / DIGITAL_V2_STAGE_ASPECT_RATIO
        val stageOffsetX = if (portrait) 0.dp else (landscapeSceneAreaWidth - stageWidth) / 2f

        DigitalV2SceneStage(
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            tr = tr,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick,
            modifier = Modifier
                .then(
                    if (portrait) {
                        Modifier.align(Alignment.TopCenter)
                    } else {
                        Modifier.align(Alignment.CenterStart).offset(x = stageOffsetX)
                    }
                )
                .width(stageWidth)
                .height(stageHeight)
        )

        if (portrait) {
            DigitalV2DataPanel(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                tr = tr,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(maxHeight - stageHeight)
            )
        } else {
            DigitalV2CompactDataPanel(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                tr = tr,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .width(landscapePanelWidth)
                    .fillMaxHeight()
            )
        }
    }
}

@Composable
private fun DigitalV2SceneStage(
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    tr: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val gaugePlacement = digitalV2GaugePlacement(settings)

    Box(
        modifier = modifier.clipToBounds()
    ) {
        OpenGLSceneHost(
            renderState = digitalV2RenderState(
                settings = settings,
                snapshot = snapshot,
                calibrationVisible = DigitalV2CalibrationVisible
            ),
            modifier = Modifier.fillMaxSize()
        )

        // HUD contrast only. The baked scene already contains road, vehicle, lighting and shadow.
        // Compose remains responsible only for HUD/data overlays above the scene.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x2606244A),
                            Color.Transparent,
                            Color(0x10071324),
                            Color(0x30081420)
                        )
                    )
                )
        )

        DigitalV2Header(
            tr = tr,
            connected = snapshot.connected,
            ignitionOff = obdState.status.contains("Kontak kapalı", ignoreCase = true) ||
                (obdState.connectionHealthReason?.contains("Kontak kapalı", ignoreCase = true) == true),
            demo = settings.demoMode || snapshot.demo,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )

        DigitalV2Gauge(
            mode = settings.digitalV2GaugeMode,
            speedKmh = snapshot.speedKmh,
            rpm = snapshot.rpm,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = gaugePlacement.topOffset)
                .padding(top = 6.dp)
                .fillMaxWidth(gaugePlacement.widthFraction)
                .fillMaxHeight(gaugePlacement.heightFraction)
        )
    }
}

private data class DigitalV2GaugePlacement(
    val topOffset: Dp = 0.dp,
    val widthFraction: Float = 0.985f,
    val heightFraction: Float = 0.78f
)

private fun digitalV2GaugePlacement(settings: LoganSettings): DigitalV2GaugePlacement = when (
    Triple(settings.digitalV2Scene, settings.vehicleVisualModel, settings.vehicleColor)
) {
    Triple(DigitalV2Scene.CityDay, VehicleVisualModel.LoganI, VehicleColor.CherryRed),
    Triple(DigitalV2Scene.CityNight, VehicleVisualModel.LoganI, VehicleColor.Yellow),
    Triple(DigitalV2Scene.CityNight, VehicleVisualModel.LoganIII, VehicleColor.CherryRed),
    Triple(DigitalV2Scene.CityDay, VehicleVisualModel.LoganIII, VehicleColor.CherryRed),
    Triple(DigitalV2Scene.CityDay, VehicleVisualModel.LoganIII, VehicleColor.Yellow),
    Triple(DigitalV2Scene.MountainLake, VehicleVisualModel.LoganIII, VehicleColor.CherryRed),
    Triple(DigitalV2Scene.MountainLake, VehicleVisualModel.LoganIII, VehicleColor.Gray),
    Triple(DigitalV2Scene.SnowRoad, VehicleVisualModel.LoganIII, VehicleColor.CherryRed),
    Triple(DigitalV2Scene.SnowRoad, VehicleVisualModel.LoganIII, VehicleColor.Yellow) ->
        DigitalV2GaugePlacement(topOffset = (-14).dp, widthFraction = 0.965f, heightFraction = 0.735f)

    else -> DigitalV2GaugePlacement()
}

@Composable
private fun DigitalV2Header(
    tr: Boolean,
    connected: Boolean,
    ignitionOff: Boolean,
    demo: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White.copy(alpha = .16f))
                .border(1.dp, Color.White.copy(alpha = .30f), RoundedCornerShape(13.dp))
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xB2123657))
                .border(1.dp, Color.White.copy(alpha = .27f), RoundedCornerShape(14.dp))
                .clickable(onClick = onObdClick)
                .padding(horizontal = 11.dp, vertical = 9.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    demo -> "DEMO"
                    ignitionOff -> if (tr) "KONTAK KAPALI" else "IGNITION OFF"
                    connected -> if (tr) "OBD BAĞLI" else "OBD ON"
                    else -> if (tr) "OBD BEKLENİYOR" else "OBD WAITING"
                },
                color = when {
                    demo || ignitionOff -> Color(0xFFFFC857)
                    connected -> Color(0xFF9BE8B5)
                    else -> Color.White
                },
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DigitalV2Gauge(
    mode: DigitalV2GaugeMode,
    speedKmh: Int?,
    rpm: Int?,
    modifier: Modifier = Modifier,
    preview: Boolean = false
) {
    val rawProgress = when (mode) {
        DigitalV2GaugeMode.Speed -> ((speedKmh ?: 0) / 200f).coerceIn(0f, 1f)
        DigitalV2GaugeMode.Rpm -> ((rpm ?: 0) / 7000f).coerceIn(0f, 1f)
    }

    val progress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(if (preview) 0 else 380),
        label = "digitalV2GaugeProgress"
    )

    val labels = if (mode == DigitalV2GaugeMode.Speed) (0..200 step 20).toList() else (0..70 step 10).toList()
    val majorCount = labels.lastIndex.coerceAtLeast(1)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * 0.485f
            val center = Offset(size.width / 2f, size.height * 0.60f)
            val startAngle = 145f
            val sweep = 250f
            val arcTopLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = Size(radius * 2f, radius * 2f)

            drawArc(
                color = Color.White.copy(alpha = .92f),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.014f, cap = StrokeCap.Round)
            )

            drawArc(
                brush = Brush.sweepGradient(listOf(DigitalV2Blue, Color.White, Color.White, DigitalV2Red), center),
                startAngle = startAngle,
                sweepAngle = sweep * progress,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.021f, cap = StrokeCap.Round)
            )

            val minorTicks = majorCount * 5
            repeat(minorTicks + 1) { index ->
                val fraction = index / minorTicks.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val major = index % 5 == 0
                val outer = radius * 0.99f
                val inner = radius * if (major) 0.865f else 0.925f

                val p1 = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner)
                val p2 = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer)

                drawLine(
                    color = Color.White.copy(alpha = if (major) .98f else .67f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (major) radius * .014f else radius * .0055f,
                    cap = StrokeCap.Round
                )
            }

            labels.forEachIndexed { index, value ->
                val fraction = index / majorCount.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val labelRadius = radius * .735f
                val x = center.x + cos(angle).toFloat() * labelRadius
                val y = center.y + sin(angle).toFloat() * labelRadius + radius * .038f

                drawContext.canvas.nativeCanvas.drawText(
                    value.toString(),
                    x,
                    y,
                    Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.WHITE
                        textAlign = Paint.Align.CENTER
                        textSize = radius * if (preview) .112f else .124f
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        setShadowLayer(radius * .020f, 0f, radius * .009f, android.graphics.Color.argb(175, 0, 0, 0))
                    }
                )
            }

            val needleAngle = Math.toRadians((startAngle + sweep * progress).toDouble())
            val needleStart = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .14f,
                center.y + sin(needleAngle).toFloat() * radius * .14f
            )
            val needleEnd = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .80f,
                center.y + sin(needleAngle).toFloat() * radius * .80f
            )

            // Keep the centre clear so the needle never cuts through the digital value.
            drawLine(Color.White.copy(alpha = .98f), needleStart, needleEnd, radius * .018f, StrokeCap.Round)
        }

        // The centre value must have the same physical meaning as the selected
        // gauge scale. Speed gauge shows speed; RPM gauge shows RPM. The previous
        // cross-display (speed ring + RPM centre and vice versa) was confusing.
        val centerValue = when (mode) {
            DigitalV2GaugeMode.Speed -> speedKmh?.toString() ?: "--"
            DigitalV2GaugeMode.Rpm -> rpm?.let { (it / 100).toString() } ?: "--"
        }
        val centerUnit = when (mode) {
            DigitalV2GaugeMode.Speed -> "km/h"
            DigitalV2GaugeMode.Rpm -> "x100 rpm"
        }
        val textShadow = Shadow(
            Color.Black.copy(alpha = .70f),
            Offset(0f, if (preview) 1f else 2f),
            if (preview) 3f else 7f
        )

        Column(
            modifier = Modifier
                .align(Alignment.Center)
                .offset(y = maxHeight * 0.075f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                centerValue,
                color = Color.White,
                fontSize = if (preview) 34.sp else 72.sp,
                fontWeight = FontWeight.Black,
                lineHeight = if (preview) 34.sp else 72.sp,
                style = TextStyle(shadow = textShadow)
            )
            Text(
                centerUnit,
                color = Color.White.copy(alpha = .96f),
                fontSize = if (preview) 9.5.sp else 16.sp,
                fontWeight = FontWeight.Black,
                style = TextStyle(shadow = textShadow)
            )
        }
    }
}

@Composable
private fun DigitalV2DataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(DigitalV2Glass, Color(0xFFF0F3F7), Color(0xFFE3E8EF))
                )
            )
            .border(1.dp, Color.White.copy(alpha = .82f), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1.12f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Hararet", "Coolant"), snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.Temperature, Modifier.weight(1f), compact = true, accent = if ((snapshot.engineTempC ?: 0) >= 100) palette.critical else DigitalV2Red)
            DigitalV2MetricCard(palette, trLabel(tr, "Klima", "A/C"), snapshot.acOn?.let { if (it) "A/C" else trLabel(tr, "Kapalı", "Off") } ?: "--", snapshot.acOn?.let { if (it) "ON" else null }, CardIcon.Ac, Modifier.weight(1f), compact = true, accent = DigitalV2Blue)
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Süresi", "Trip Time"), snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, Modifier.weight(1f), compact = true)
            DigitalV2MetricCard(palette, trLabel(tr, "Kullanılan Yakıt", "Fuel Used"), format1(snapshot.fuelUsedL), "L", CardIcon.FuelCalculation, Modifier.weight(1f), compact = true)
        }
    }
}

@Composable
private fun DigitalV2CompactDataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFFE7ECF2))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
    }
}

@Composable
private fun DigitalV2MetricCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    accent: Color = DigitalV2Blue
) {
    if (compact) {
        Column(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(16.dp))
                .padding(horizontal = 5.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title.uppercase(),
                color = Color(0xFF596778),
                fontSize = 8.3.sp,
                lineHeight = 8.7.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(1.dp))
            Box(
                modifier = Modifier
                    .size(25.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(3.5.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Spacer(Modifier.height(1.dp))
            // Compact cards keep value and unit on one baseline so the two-line
            // "Kullanılan Yakıt" title cannot push the numeric value below the card.
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
                Text(
                    value,
                    color = Color(0xFF172235),
                    fontSize = 18.5.sp,
                    lineHeight = 19.sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!unit.isNullOrBlank()) {
                    Spacer(Modifier.width(2.dp))
                    Text(
                        unit,
                        color = Color(0xFF596778),
                        fontSize = 8.5.sp,
                        lineHeight = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 1.5.dp),
                        maxLines = 1
                    )
                }
            }
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(20.dp))
                .padding(horizontal = 11.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title.uppercase(), color = Color(0xFF596778), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, color = Color(0xFF172235), fontSize = 26.sp, lineHeight = 27.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!unit.isNullOrBlank()) {
                        Spacer(Modifier.width(4.dp))
                        Text(unit, color = Color(0xFF596778), fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 3.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalV2SettingsPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    onSettingsChange: (LoganSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dijital V2", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(
            trLabel(tr, "Sahne, araç modeli ve renk tek bir hazır görsel olarak yüklenir; eski ayrı yol/araç katmanları kullanılmaz.", "Scene, vehicle model and color are loaded as one baked image; the old separate road/vehicle layers are not used."),
            color = palette.textSecondary,
            fontSize = 12.5.sp
        )
        DigitalV2MiniPreview(
            settings = settings,
            mode = settings.digitalV2GaugeMode,
            modifier = Modifier.fillMaxWidth().height(184.dp)
        )
        Text(trLabel(tr, "Kadran Türü", "Gauge Type"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Speed,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Speed,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Speed)) }
            )
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Rpm,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Rpm,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Rpm)) }
            )
        }
        Text(trLabel(tr, "Arka Plan Sahnesi", "Background Scene"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.take(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.drop(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
    }
}

@Composable
private fun DigitalV2MiniPreview(
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    val previewSnapshot = DashboardSnapshot(
        speedKmh = 78,
        rpm = 2400,
        demo = true
    )
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xFF0A111B))
            .border(2.dp, DigitalV2Blue.copy(alpha = .70f), RoundedCornerShape(20.dp)),
        contentAlignment = Alignment.Center
    ) {
        // Settings lives in a LazyColumn. A static preview avoids embedding a
        // second SurfaceView/EGL context there and guarantees rounded clipping.
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .clipToBounds()
        ) {
            Image(
                painter = painterResource(
                    digitalV2CompositeRes(
                        scene = settings.digitalV2Scene,
                        model = settings.vehicleVisualModel,
                        color = settings.vehicleColor
                    )
                ),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )


            Box(
                Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color(0x30062A51), Color.Transparent, Color(0x42061018))
                        )
                    )
            )
            DigitalV2Gauge(
                mode = mode,
                speedKmh = previewSnapshot.speedKmh,
                rpm = previewSnapshot.rpm,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth(.88f)
                    .fillMaxHeight(.90f),
                preview = true
            )
            Text(
                (if (tr) settings.digitalV2Scene.trLabel else settings.digitalV2Scene.enLabel).uppercase(),
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.align(Alignment.TopStart).padding(8.dp)
            )
        }
    }
}

@Composable
private fun DigitalV2GaugeThumbnail(
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        DigitalV2Gauge(
            mode = mode,
            speedKmh = 78,
            rpm = 2400,
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .fillMaxHeight(0.98f),
            preview = true
        )
    }
}

@Composable
private fun DigitalV2ModeTile(
    palette: LoganPalette,
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) DigitalV2Blue.copy(alpha = .10f) else palette.surfaceVariant.copy(alpha = .62f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(92.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1B5D91))
        ) {
            DigitalV2GaugeThumbnail(mode, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(6.dp))
        Text(if (tr) mode.trLabel else mode.enLabel, color = if (selected) DigitalV2Blue else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(
            if (mode == DigitalV2GaugeMode.Speed) trLabel(tr, "Ortada hız", "Speed in center") else trLabel(tr, "Ortada devir", "RPM in center"),
            color = palette.textSecondary,
            fontSize = 10.5.sp
        )
    }
}

@Composable
private fun DigitalV2SceneTile(
    palette: LoganPalette,
    settings: LoganSettings,
    scene: DigitalV2Scene,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val selected = settings.digitalV2Scene == scene && scene.available
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (scene.available) Color(0xFF4C86AD) else palette.surfaceVariant.copy(alpha = .80f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(15.dp))
            .clickable(enabled = scene.available, onClick = onClick)
    ) {
        Image(
            painter = painterResource(
                digitalV2CompositeRes(
                    scene = scene,
                    model = settings.vehicleVisualModel,
                    color = settings.vehicleColor
                )
            ),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .20f)))
        Text(if (tr) scene.trLabel else scene.enLabel, color = if (scene.available) Color.White else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
        Text(
            if (selected) trLabel(tr, "Seçili", "Selected") else trLabel(tr, "Hazır", "Ready"),
            color = if (scene.available) Color.White else palette.textSecondary,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = if (scene.available) .35f else .08f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

private fun trLabel(tr: Boolean, trValue: String, enValue: String): String = if (tr) trValue else enValue

private fun format1(value: Double?): String = value?.takeIf { it.isFinite() }?.let {
    String.format(Locale.US, "%.1f", it)
} ?: "--"
