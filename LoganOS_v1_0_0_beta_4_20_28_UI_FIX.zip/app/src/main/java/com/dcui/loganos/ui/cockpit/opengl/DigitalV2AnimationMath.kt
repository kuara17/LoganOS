package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.PI
import kotlin.math.exp

/**
 * Stable animation phases derived from an unbounded Double-precision distance.
 * Each visual subsystem wraps only at its own exact repeat length.
 */
internal fun positiveModulo(value: Double, modulus: Double): Double {
    if (modulus <= 0.0 || !value.isFinite() || !modulus.isFinite()) return 0.0
    val result = value % modulus
    return if (result < 0.0) result + modulus else result
}

internal fun roadPatternPhaseMeters(
    totalDistanceMeters: Double,
    repeatLengthMeters: Float
): Float = positiveModulo(
    totalDistanceMeters,
    repeatLengthMeters.toDouble()
).toFloat()

internal fun roadSurfacePhaseMeters(
    totalDistanceMeters: Double,
    cycleLengthMeters: Float
): Float = positiveModulo(
    totalDistanceMeters * DIGITAL_V2_ROAD_SURFACE_TRAVEL_MULTIPLIER,
    cycleLengthMeters.toDouble()
).toFloat()

internal fun windTravelPhaseMeters(
    totalDistanceMeters: Double,
    cycleLengthMeters: Float
): Float = positiveModulo(
    totalDistanceMeters * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER,
    cycleLengthMeters.toDouble()
).toFloat()

internal fun windPulsePhaseRadians(totalDistanceMeters: Double): Float = positiveModulo(
    totalDistanceMeters * DIGITAL_V2_WIND_TRAVEL_MULTIPLIER * DIGITAL_V2_WIND_PULSE_RADIANS_PER_METER,
    PI * 2.0
).toFloat()

/**
 * Prevents the stopped/WHEN_DIRTY state from preserving a stale high speed.
 * Below the motion threshold the visual speed snaps to zero in the final frame.
 */
internal fun nextDigitalV2SmoothedSpeedKmh(
    currentSpeedKmh: Float,
    targetSpeedKmh: Float,
    deltaSeconds: Float,
    smoothingSeconds: Float = 0.32f
): Float {
    val target = targetSpeedKmh.coerceIn(0f, 180f)
    if (target < DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH) return 0f
    if (deltaSeconds <= 0f || !deltaSeconds.isFinite()) return currentSpeedKmh.coerceAtLeast(0f)
    val blend = (1f - exp((-deltaSeconds / smoothingSeconds).toDouble()).toFloat())
        .coerceIn(0f, 1f)
    return (currentSpeedKmh + (target - currentSpeedKmh) * blend).coerceIn(0f, 180f)
}

internal const val DIGITAL_V2_MOTION_SPEED_THRESHOLD_KMH = 2f
internal const val DIGITAL_V2_ROAD_SURFACE_TRAVEL_MULTIPLIER = 0.72
internal const val DIGITAL_V2_WIND_TRAVEL_MULTIPLIER = 1.35
internal const val DIGITAL_V2_WIND_PULSE_RADIANS_PER_METER = 0.08
