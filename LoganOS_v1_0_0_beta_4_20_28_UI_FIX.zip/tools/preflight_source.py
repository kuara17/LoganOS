#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
MAIN = ROOT / 'app/src/main'
JAVA = MAIN / 'java'
RES = MAIN / 'res'


def fail(message: str) -> None:
    print(f'[FAIL] {message}')
    raise SystemExit(1)


def ok(message: str) -> None:
    print(f'[OK] {message}')

# Collect drawable resource names from all drawable* directories.
drawable_names: set[str] = set()
for directory in RES.glob('drawable*'):
    if directory.is_dir():
        drawable_names.update(p.stem for p in directory.iterdir() if p.is_file())

missing: list[tuple[Path, str]] = []
for source in JAVA.rglob('*.kt'):
    text = source.read_text(encoding='utf-8', errors='ignore')
    for match in re.finditer(r'R\.drawable\.([A-Za-z0-9_]+)', text):
        name = match.group(1)
        if name not in drawable_names:
            missing.append((source.relative_to(ROOT), name))
if missing:
    preview = '; '.join(f'{path}: {name}' for path, name in missing[:12])
    fail('missing drawable references: ' + preview)
ok('all Kotlin R.drawable references resolve')

scene_source = ROOT / 'app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneAssets.kt'
text = scene_source.read_text(encoding='utf-8')
refs = re.findall(r'R\.drawable\.(digital_v2_[a-z0-9_]+)', text)
if len(refs) != 48 or len(set(refs)) != 48:
    fail(f'DigitalV2SceneAssets must map exactly 48 unique baked resources; got {len(refs)}/{len(set(refs))}')
ok('Digital V2 mapping contains 48 unique resources')

legacy_tokens = (
    'digitalV2BackgroundRes(', 'digitalV2RoadMapRes(',
    'digitalV2CastShadowRes(', 'digitalV2ContactShadowRes('
)
all_kotlin = '\n'.join(p.read_text(encoding='utf-8', errors='ignore') for p in JAVA.rglob('*.kt'))
for token in legacy_tokens:
    if token in all_kotlin:
        fail(f'legacy Digital V2 API reference remains: {token}')
ok('no legacy Digital V2 background/road/shadow API references')

# Keep individual source assets comfortably below GitHub's file-size ceiling.
large = [p for p in ROOT.rglob('*') if p.is_file() and p.stat().st_size > 20 * 1024 * 1024]
if large:
    fail('source file exceeds 20 MiB: ' + str(large[0].relative_to(ROOT)))
ok('no individual source file exceeds 20 MiB')
