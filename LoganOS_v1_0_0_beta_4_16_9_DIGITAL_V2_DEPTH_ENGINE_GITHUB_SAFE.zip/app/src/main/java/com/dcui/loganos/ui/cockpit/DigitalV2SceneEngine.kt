package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.unit.dp
import com.dcui.loganos.R
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.ui.components.rememberScenicMotionPhases
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Every Digital V2 scene is rendered in the same fixed 1080 x 1320 stage.
 * All coordinates below are normalized against that stage, so phone and
 * head-unit size changes cannot move the road, vehicle or effects.
 */
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO = 1080f / 1320f

/**
 * A world-depth sample projected onto the 2D scene.
 * depth: 0 = vanishing point, 1 = nearest visible road point.
 */
internal data class DigitalV2DepthSample(
    val depth: Float,
    val screenY: Float,
    val centerX: Float,
    val halfWidth: Float
)

internal data class DigitalV2RoadProjection(
    val depth: Float,
    val screenY: Float,
    val centerX: Float,
    val halfWidth: Float
) {
    val leftX: Float get() = centerX - halfWidth
    val rightX: Float get() = centerX + halfWidth

    fun laneX(lanePosition: Float): Float =
        leftX + (rightX - leftX) * lanePosition.coerceIn(0f, 1f)
}

internal data class DigitalV2SceneSpec(
    val backgroundRes: Int,
    val stageAspectRatio: Float,
    val depthSamples: List<DigitalV2DepthSample>,
    /** Vehicle is attached to a world-depth point, not a dp offset. */
    val vehicleDepth: Float,
    /** Visible vehicle body width as a fixed fraction of stage width. */
    val vehicleVisibleWidthRatio: Float,
    /** Position across the road: 0 = left edge, 0.5 = divider, 1 = right edge. */
    val vehicleLanePosition: Float,
    val shadowWidthRatio: Float,
    val shadowAlpha: Float,
    val windStartDepth: Float,
    val windEndDepth: Float,
    val roadLineIntensity: Float = 1f,
    val windIntensity: Float = 1f,
    val vehicleAssetVisibleWidthRatio: Float = 0.864f,
    val vehicleAssetContactYRatio: Float = 0.906f
) {
    init {
        require(stageAspectRatio > 0f)
        require(depthSamples.size >= 5)
        require(depthSamples.first().depth == 0f)
        require(depthSamples.last().depth == 1f)
        require(depthSamples.zipWithNext().all { (a, b) -> b.depth > a.depth })
        require(depthSamples.zipWithNext().all { (a, b) -> b.screenY > a.screenY })
        require(depthSamples.all { it.halfWidth > 0f })
        require(vehicleDepth in 0f..1f)
        require(vehicleVisibleWidthRatio in 0.20f..0.50f)
        require(vehicleLanePosition in 0f..1f)
        require(shadowWidthRatio in 0.15f..0.50f)
        require(windStartDepth in 0f..1f)
        require(windEndDepth in 0f..1f)
        require(windStartDepth < windEndDepth)
    }

    fun roadAtDepth(depth: Float): DigitalV2RoadProjection {
        val d = depth.coerceIn(0f, 1f)
        val segment = depthSamples.indexOfLast { it.depth <= d }
            .coerceIn(0, depthSamples.lastIndex - 1)
        val a = depthSamples[segment]
        val b = depthSamples[segment + 1]
        val span = (b.depth - a.depth).coerceAtLeast(0.0001f)
        val rawT = ((d - a.depth) / span).coerceIn(0f, 1f)
        // Smooth interpolation prevents visible corners in curved scenes.
        val t = rawT * rawT * (3f - 2f * rawT)
        fun lerp(x: Float, y: Float): Float = x + (y - x) * t
        return DigitalV2RoadProjection(
            depth = d,
            screenY = lerp(a.screenY, b.screenY),
            centerX = lerp(a.centerX, b.centerX),
            halfWidth = lerp(a.halfWidth, b.halfWidth)
        )
    }

    fun vehicleHeadingDegrees(stageWidth: Float, stageHeight: Float): Float {
        val before = roadAtDepth((vehicleDepth - 0.018f).coerceAtLeast(0f))
        val after = roadAtDepth((vehicleDepth + 0.018f).coerceAtMost(1f))
        val beforeX = before.laneX(vehicleLanePosition) * stageWidth
        val afterX = after.laneX(vehicleLanePosition) * stageWidth
        val dx = afterX - beforeX
        val dy = (after.screenY - before.screenY) * stageHeight
        // Vehicle points towards the horizon, opposite the downward path tangent.
        return (-atan2(dx, dy) * 180f / PI.toFloat()).coerceIn(-3.2f, 3.2f)
    }
}

/*
 * Samples were measured on the exported 1080 x 1320 assets. The explicit
 * depth dimension is the key difference from the retired screen-arc model:
 * equal depth movement produces slow distant motion and accelerating nearby
 * motion automatically through the projected screenY/halfWidth values.
 */
internal val DigitalV2MountainLakeSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_mountain_lake_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    depthSamples = listOf(
        DigitalV2DepthSample(0.00f, 0.425f, 0.640f, 0.020f),
        DigitalV2DepthSample(0.10f, 0.455f, 0.635f, 0.065f),
        DigitalV2DepthSample(0.22f, 0.490f, 0.623f, 0.138f),
        DigitalV2DepthSample(0.36f, 0.530f, 0.610f, 0.205f),
        DigitalV2DepthSample(0.52f, 0.580f, 0.598f, 0.288f),
        DigitalV2DepthSample(0.68f, 0.640f, 0.575f, 0.390f),
        DigitalV2DepthSample(0.81f, 0.700f, 0.545f, 0.475f),
        DigitalV2DepthSample(0.92f, 0.840f, 0.520f, 0.550f),
        DigitalV2DepthSample(1.00f, 1.000f, 0.510f, 0.570f)
    ),
    vehicleDepth = 0.955f,
    vehicleVisibleWidthRatio = 0.380f,
    vehicleLanePosition = 0.710f,
    shadowWidthRatio = 0.330f,
    shadowAlpha = 0.88f,
    windStartDepth = 0.20f,
    windEndDepth = 0.84f,
    roadLineIntensity = 1.05f,
    windIntensity = 1.10f
)

internal val DigitalV2CityDaySceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_day_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    depthSamples = listOf(
        DigitalV2DepthSample(0.00f, 0.435f, 0.500f, 0.010f),
        DigitalV2DepthSample(0.10f, 0.465f, 0.500f, 0.050f),
        DigitalV2DepthSample(0.22f, 0.500f, 0.500f, 0.170f),
        DigitalV2DepthSample(0.36f, 0.535f, 0.500f, 0.370f),
        DigitalV2DepthSample(0.50f, 0.570f, 0.500f, 0.480f),
        DigitalV2DepthSample(0.70f, 0.650f, 0.500f, 0.530f),
        DigitalV2DepthSample(0.85f, 0.820f, 0.500f, 0.540f),
        DigitalV2DepthSample(1.00f, 1.000f, 0.500f, 0.550f)
    ),
    vehicleDepth = 0.930f,
    vehicleVisibleWidthRatio = 0.370f,
    vehicleLanePosition = 0.700f,
    shadowWidthRatio = 0.320f,
    shadowAlpha = 0.84f,
    windStartDepth = 0.18f,
    windEndDepth = 0.82f,
    roadLineIntensity = 1.00f,
    windIntensity = 1.06f
)

internal val DigitalV2CityNightSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_night_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    depthSamples = listOf(
        DigitalV2DepthSample(0.00f, 0.435f, 0.500f, 0.010f),
        DigitalV2DepthSample(0.10f, 0.470f, 0.500f, 0.060f),
        DigitalV2DepthSample(0.22f, 0.500f, 0.500f, 0.200f),
        DigitalV2DepthSample(0.36f, 0.535f, 0.500f, 0.420f),
        DigitalV2DepthSample(0.50f, 0.570f, 0.500f, 0.510f),
        DigitalV2DepthSample(0.70f, 0.650f, 0.500f, 0.530f),
        DigitalV2DepthSample(0.85f, 0.820f, 0.500f, 0.540f),
        DigitalV2DepthSample(1.00f, 1.000f, 0.500f, 0.550f)
    ),
    vehicleDepth = 0.930f,
    vehicleVisibleWidthRatio = 0.370f,
    vehicleLanePosition = 0.700f,
    shadowWidthRatio = 0.320f,
    shadowAlpha = 0.68f,
    windStartDepth = 0.18f,
    windEndDepth = 0.82f,
    roadLineIntensity = 1.08f,
    windIntensity = 1.16f
)

internal val DigitalV2SnowRoadSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_snow_road_bg,
    stageAspectRatio = DIGITAL_V2_STAGE_ASPECT_RATIO,
    depthSamples = listOf(
        DigitalV2DepthSample(0.00f, 0.470f, 0.500f, 0.030f),
        DigitalV2DepthSample(0.10f, 0.500f, 0.505f, 0.065f),
        DigitalV2DepthSample(0.23f, 0.540f, 0.515f, 0.115f),
        DigitalV2DepthSample(0.38f, 0.580f, 0.515f, 0.175f),
        DigitalV2DepthSample(0.54f, 0.630f, 0.515f, 0.245f),
        DigitalV2DepthSample(0.69f, 0.680f, 0.510f, 0.330f),
        DigitalV2DepthSample(0.81f, 0.740f, 0.510f, 0.430f),
        DigitalV2DepthSample(0.92f, 0.840f, 0.510f, 0.520f),
        DigitalV2DepthSample(1.00f, 1.000f, 0.505f, 0.555f)
    ),
    vehicleDepth = 0.955f,
    vehicleVisibleWidthRatio = 0.380f,
    vehicleLanePosition = 0.710f,
    shadowWidthRatio = 0.330f,
    shadowAlpha = 0.82f,
    windStartDepth = 0.20f,
    windEndDepth = 0.84f,
    roadLineIntensity = 1.06f,
    windIntensity = 1.12f
)

internal fun digitalV2SceneSpec(scene: DigitalV2Scene): DigitalV2SceneSpec = when (scene) {
    DigitalV2Scene.MountainLake -> DigitalV2MountainLakeSceneSpec
    DigitalV2Scene.CityDay -> DigitalV2CityDaySceneSpec
    DigitalV2Scene.CityNight -> DigitalV2CityNightSceneSpec
    DigitalV2Scene.SnowRoad -> DigitalV2SnowRoadSceneSpec
}

internal data class DigitalV2SceneMotion(
    val moving: Boolean,
    val roadPhase: Float,
    val motionStrength: Float,
    val suspensionLift: Float,
    val swayWave: Float
)

@Composable
internal fun rememberDigitalV2SceneMotion(
    speedKmh: Int?,
    enabled: Boolean
): DigitalV2SceneMotion {
    val currentSpeed = speedKmh ?: 0
    val scenic = rememberScenicMotionPhases(speedKmh = speedKmh, enabled = enabled)
    val moving = enabled && currentSpeed >= 5
    val motionStrength = when {
        !moving -> 0f
        currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
        currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
        currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
        else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
    }.coerceIn(0f, 1f)

    val angle = scenic.dynamicsTime * 2f * PI.toFloat()
    val bodyWave = if (moving) {
        val primary = sin(angle.toDouble()).toFloat()
        val secondary = 0.30f * sin((angle * 2.70f + 0.62f).toDouble()).toFloat()
        val settle = 0.14f * sin((angle * 0.57f + 1.38f).toDouble()).toFloat()
        (primary + secondary + settle) / 1.44f
    } else 0f
    val microRoad = if (moving) {
        val coarse = sin((angle * 12f + 0.20f).toDouble()).toFloat()
        val fine = sin((angle * 18.40f + 1.15f).toDouble()).toFloat()
        (coarse * 0.68f + fine * 0.32f) * (0.06f + 0.05f * motionStrength)
    } else 0f
    val sway = if (moving) {
        0.68f * sin((angle * 0.71f + 0.85f).toDouble()).toFloat() +
            0.22f * sin((angle * 1.93f + 2.10f).toDouble()).toFloat() +
            0.10f * sin((angle * 4.40f + 0.22f).toDouble()).toFloat()
    } else 0f

    return DigitalV2SceneMotion(
        moving = moving,
        roadPhase = scenic.roadPhase,
        motionStrength = motionStrength,
        suspensionLift = (bodyWave + microRoad).coerceIn(-1.10f, 1.10f),
        swayWave = sway
    )
}

private data class ScreenRoadPoint(
    val projection: DigitalV2RoadProjection,
    val point: Offset,
    val roadWidthPx: Float
)

private fun screenRoadPoint(
    spec: DigitalV2SceneSpec,
    depth: Float,
    widthPx: Float,
    heightPx: Float,
    lanePosition: Float = 0.5f
): ScreenRoadPoint {
    val p = spec.roadAtDepth(depth)
    return ScreenRoadPoint(
        projection = p,
        point = Offset(p.laneX(lanePosition) * widthPx, p.screenY * heightPx),
        roadWidthPx = p.halfWidth * 2f * widthPx
    )
}

private fun buildRoadMask(spec: DigitalV2SceneSpec, widthPx: Float, heightPx: Float): Path {
    val left = ArrayList<Offset>(81)
    val right = ArrayList<Offset>(81)
    repeat(81) { index ->
        val p = spec.roadAtDepth(index / 80f)
        left += Offset(p.leftX * widthPx, p.screenY * heightPx)
        right += Offset(p.rightX * widthPx, p.screenY * heightPx)
    }
    return Path().apply {
        moveTo(left.first().x, left.first().y)
        left.drop(1).forEach { lineTo(it.x, it.y) }
        right.asReversed().forEach { lineTo(it.x, it.y) }
        close()
    }
}

private fun buildSideWindMask(
    spec: DigitalV2SceneSpec,
    widthPx: Float,
    heightPx: Float,
    leftSide: Boolean
): Path {
    val edge = ArrayList<Offset>(49)
    repeat(49) { index ->
        val depth = spec.windStartDepth +
            (spec.windEndDepth - spec.windStartDepth) * index / 48f
        val p = spec.roadAtDepth(depth)
        edge += Offset((if (leftSide) p.leftX else p.rightX) * widthPx, p.screenY * heightPx)
    }
    return Path().apply {
        val outerX = if (leftSide) 0f else widthPx
        moveTo(outerX, edge.first().y)
        lineTo(edge.first().x, edge.first().y)
        edge.drop(1).forEach { lineTo(it.x, it.y) }
        lineTo(outerX, edge.last().y)
        close()
    }
}

@Composable
internal fun DigitalV2RoadLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        val roadMask = buildRoadMask(spec, size.width, size.height)
        clipPath(roadMask) {
            val dashCount = 15
            val phase = if (motion.moving) motion.roadPhase else 0f
            val dashDepthLength = 0.030f

            repeat(dashCount) { index ->
                val startDepth = ((index / dashCount.toFloat()) + phase) % 1f
                val endDepth = startDepth + dashDepthLength
                if (endDepth >= 0.995f) return@repeat

                val path = Path()
                var averageRoadWidth = 0f
                repeat(8) { step ->
                    val d = startDepth + (endDepth - startDepth) * step / 7f
                    val p = screenRoadPoint(spec, d, size.width, size.height)
                    averageRoadWidth += p.roadWidthPx
                    if (step == 0) path.moveTo(p.point.x, p.point.y) else path.lineTo(p.point.x, p.point.y)
                }
                averageRoadWidth /= 8f

                val depthMid = (startDepth + endDepth) * 0.5f
                val horizonFade = (depthMid / 0.12f).coerceIn(0f, 1f)
                val foregroundFade = ((1f - depthMid) / 0.045f).coerceIn(0f, 1f)
                val motionBoost = if (motion.moving) 0.92f + 0.08f * motion.motionStrength else 0.82f
                val alpha = (0.86f * horizonFade * foregroundFade * motionBoost * spec.roadLineIntensity)
                    .coerceIn(0f, 0.96f)
                val width = (averageRoadWidth * 0.0062f)
                    .coerceIn(1.0.dp.toPx(), 6.2.dp.toPx())

                // A dark edge preserves visibility on snow and bright asphalt without neon glow.
                drawPath(
                    path = path,
                    color = Color.Black.copy(alpha = alpha * 0.22f),
                    style = Stroke(width = width * 1.55f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = path,
                    color = Color(0xFFFFD451).copy(alpha = alpha),
                    style = Stroke(width = width, cap = StrokeCap.Round)
                )
                drawPath(
                    path = path,
                    color = Color(0xFFFFF0B0).copy(alpha = alpha * 0.34f),
                    style = Stroke(width = (width * 0.28f).coerceAtLeast(0.7f), cap = StrokeCap.Round)
                )
            }
        }
    }
}

@Composable
internal fun DigitalV2WindLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    Canvas(modifier) {
        if (!motion.moving || motion.motionStrength <= 0.02f) return@Canvas

        fun drawSide(leftSide: Boolean) {
            val clip = buildSideWindMask(spec, size.width, size.height, leftSide)
            val sideOffset = if (leftSide) 0.07f else 0.15f
            val sideSign = if (leftSide) -1f else 1f

            clipPath(clip) {
                repeat(10) { index ->
                    val local = (index / 10f + motion.roadPhase * 0.92f + sideOffset) % 1f
                    val depth = spec.windStartDepth +
                        (spec.windEndDepth - spec.windStartDepth) * local
                    val headDepth = (depth + 0.035f + 0.035f * depth).coerceAtMost(0.97f)
                    val base = spec.roadAtDepth(depth)
                    val head = spec.roadAtDepth(headDepth)
                    val edgeX = if (leftSide) base.leftX else base.rightX
                    val headEdgeX = if (leftSide) head.leftX else head.rightX
                    val roadWidthPx = base.halfWidth * 2f * size.width
                    val outward = roadWidthPx * (0.055f + 0.055f * depth)
                    val start = Offset(edgeX * size.width, base.screenY * size.height)
                    val end = Offset(
                        headEdgeX * size.width + sideSign * outward,
                        head.screenY * size.height
                    )
                    val lengthX = end.x - start.x
                    val lengthY = end.y - start.y
                    val wave = sin((motion.roadPhase * 8.4f + index * 1.17f).toDouble()).toFloat()
                    val gust = Path().apply {
                        moveTo(start.x, start.y)
                        cubicTo(
                            start.x + lengthX * 0.30f,
                            start.y + lengthY * 0.22f - wave * size.height * 0.005f,
                            start.x + lengthX * 0.72f,
                            start.y + lengthY * 0.76f + wave * size.height * 0.003f,
                            end.x,
                            end.y
                        )
                    }
                    val lifeFade = sin((local * PI.toFloat()).toDouble()).toFloat()
                        .coerceAtLeast(0f).pow(2.6f)
                    val alpha = ((0.30f + 0.22f * depth) * lifeFade *
                        (0.72f + 0.28f * motion.motionStrength) * spec.windIntensity)
                        .coerceAtMost(0.58f)
                    val core = (0.72.dp.toPx() + 1.25.dp.toPx() * depth)

                    drawPath(
                        path = gust,
                        color = Color(0xFFD7ECFF).copy(alpha = alpha * 0.15f),
                        style = Stroke(width = core * 5.0f, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                    drawPath(
                        path = gust,
                        color = Color.White.copy(alpha = alpha * 0.72f),
                        style = Stroke(width = core, cap = StrokeCap.Round),
                        blendMode = BlendMode.Screen
                    )
                }
            }
        }

        drawSide(leftSide = true)
        drawSide(leftSide = false)
    }
}

@Composable
internal fun DigitalV2CalibrationOverlay(
    spec: DigitalV2SceneSpec,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    if (!enabled) return
    Canvas(modifier) {
        repeat(11) { index ->
            val x = size.width * index / 10f
            val y = size.height * index / 10f
            drawLine(Color.Red.copy(alpha = 0.34f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(Color.Yellow.copy(alpha = 0.34f), Offset(0f, y), Offset(size.width, y), 1f)
        }

        val left = Path()
        val divider = Path()
        val lane = Path()
        val right = Path()
        repeat(101) { index ->
            val p = spec.roadAtDepth(index / 100f)
            val leftP = Offset(p.leftX * size.width, p.screenY * size.height)
            val centerP = Offset(p.centerX * size.width, p.screenY * size.height)
            val laneP = Offset(p.laneX(spec.vehicleLanePosition) * size.width, p.screenY * size.height)
            val rightP = Offset(p.rightX * size.width, p.screenY * size.height)
            if (index == 0) {
                left.moveTo(leftP.x, leftP.y)
                divider.moveTo(centerP.x, centerP.y)
                lane.moveTo(laneP.x, laneP.y)
                right.moveTo(rightP.x, rightP.y)
            } else {
                left.lineTo(leftP.x, leftP.y)
                divider.lineTo(centerP.x, centerP.y)
                lane.lineTo(laneP.x, laneP.y)
                right.lineTo(rightP.x, rightP.y)
            }
        }
        drawPath(left, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(right, Color.Red, style = Stroke(2.dp.toPx()))
        drawPath(divider, Color.Cyan, style = Stroke(2.dp.toPx()))
        drawPath(lane, Color.Green, style = Stroke(2.dp.toPx()))

        val contact = spec.roadAtDepth(spec.vehicleDepth)
        drawCircle(
            color = Color.Magenta,
            radius = 6.dp.toPx(),
            center = Offset(
                contact.laneX(spec.vehicleLanePosition) * size.width,
                contact.screenY * size.height
            )
        )
    }
}
