#!/usr/bin/env python3
"""Fast source/resource preflight executed before Gradle.

This does not replace the Android/Kotlin compiler. It catches common packaging
mistakes early: malformed XML, missing app resources, invalid resource names,
and Compose scope-member imports that previously broke LoganOS builds.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

RESOURCE_NAME = re.compile(r"^[a-z][a-z0-9_]*$")
R_REF = re.compile(r"\bR\.(drawable|mipmap|string|color|dimen|style|xml|raw|font)\.([A-Za-z0-9_]+)\b")
INVALID_IMPORTS = {
    "import androidx.compose.foundation.layout.matchParentSize": "matchParentSize is a BoxScope member and must not be imported",
    "import androidx.compose.foundation.layout.weight": "weight is a RowScope/ColumnScope member and must not be imported",
}

# Kotlin rejects non-local break/continue from scope-function lambdas unless an
# experimental language feature is enabled. LoganOS does not enable that feature;
# keep polling-loop control flow outside let/run/also/apply lambdas.
INLINE_LAMBDA_LOOP_CONTROL = re.compile(
    r"(?:\?\.|\.)\s*(?:let|run|also|apply)\s*\{(?:(?!\n\s*\}).){0,1200}\b(?:break|continue)\b",
    re.S,
)


def fail(message: str) -> None:
    print(f"[FAIL] {message}")
    raise SystemExit(1)


def passed(message: str) -> None:
    print(f"[PASS] {message}")



def read_webp_size(path: Path) -> tuple[int, int]:
    data = path.read_bytes()
    if len(data) < 30 or data[:4] != b"RIFF" or data[8:12] != b"WEBP":
        fail(f"Invalid WebP asset: {path}")
    fourcc = data[12:16]
    if fourcc == b"VP8 ":
        payload = 20
        if data[payload + 3:payload + 6] != b"\x9d\x01\x2a":
            fail(f"Unsupported VP8 frame header: {path}")
        width = int.from_bytes(data[payload + 6:payload + 8], "little") & 0x3FFF
        height = int.from_bytes(data[payload + 8:payload + 10], "little") & 0x3FFF
        return width, height
    if fourcc == b"VP8X":
        payload = 20
        width = 1 + int.from_bytes(data[payload + 4:payload + 7], "little")
        height = 1 + int.from_bytes(data[payload + 7:payload + 10], "little")
        return width, height
    if fourcc == b"VP8L":
        payload = 20
        if data[payload] != 0x2F:
            fail(f"Unsupported VP8L frame header: {path}")
        bits = int.from_bytes(data[payload + 1:payload + 5], "little")
        width = (bits & 0x3FFF) + 1
        height = ((bits >> 14) & 0x3FFF) + 1
        return width, height
    fail(f"Unsupported WebP encoding {fourcc!r}: {path}")


def validate_digital_v2(root: Path) -> None:
    asset_dir = root / "app/src/main/res/drawable-nodpi"
    assets = (
        asset_dir / "digital_v2_mountain_lake_bg.webp",
        asset_dir / "digital_v2_city_day_bg.webp",
        asset_dir / "digital_v2_city_night_bg.webp",
        asset_dir / "digital_v2_snow_road_bg.webp",
    )
    engine = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2SceneEngine.kt"
    cockpit = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/DigitalV2Cockpit.kt"
    if not engine.is_file() or not cockpit.is_file() or any(not asset.is_file() for asset in assets):
        fail("Digital V2 scene engine or one of the four active assets is missing")
    for asset in assets:
        width, height = read_webp_size(asset)
        if (width, height) != (1080, 1320):
            fail(f"Digital V2 stage must be exactly 1080x1320: {asset.name} is {width}x{height}")
        if asset.stat().st_size > 500_000:
            fail(f"Digital V2 stage is unexpectedly large: {asset.name}={asset.stat().st_size} bytes")
    engine_text = engine.read_text(encoding="utf-8")
    cockpit_text = cockpit.read_text(encoding="utf-8")
    shadow_asset = asset_dir / "digital_v2_vehicle_contact_shadow.png"
    if not shadow_asset.is_file():
        fail("Digital V2 contact-shadow asset is missing")
    required_engine_tokens = (
        "DigitalV2SceneSpec",
        "DIGITAL_V2_STAGE_ASPECT_RATIO = 1080f / 1320f",
        "DigitalV2DepthSample",
        "roadAtDepth",
        "vehicleDepth",
        "vehicleVisibleWidthRatio",
        "vehicleLanePosition",
        "DigitalV2RoadLayer",
        "DigitalV2WindLayer",
        "spec: DigitalV2SceneSpec",
        "DigitalV2CalibrationOverlay",
    )
    for token in required_engine_tokens:
        if token not in engine_text:
            fail(f"Digital V2 depth-projection contract is incomplete: {token}")
    forbidden_engine_tokens = (
        "frameAtArc",
        "RoadFrame",
        "roadBlurIntensity",
        "speed-blur",
        "cumulativePx",
    )
    for token in forbidden_engine_tokens:
        if token in engine_text:
            fail(f"Retired Digital V2 screen-arc/fake-blur code is still present: {token}")
    if "vehicleVisibleWidthToRoadWidth" in engine_text or "vehicleVisibleWidthToRoadWidth" in cockpit_text:
        fail("Digital V2 vehicle size must be independent from road width")
    if "DigitalV2WindLayer(\n            spec = spec" not in cockpit_text:
        fail("Digital V2 wind layer must receive the active SceneSpec")
    if "DigitalV2VehicleShadow(" not in cockpit_text:
        fail("Digital V2 must use the asset-based road contact shadow")
    if "drawOval(" in cockpit_text:
        fail("Procedural Digital V2 vehicle shadow is still present")
    if "ContentScale.FillBounds" not in cockpit_text:
        fail("Digital V2 active stage must use the fixed FillBounds coordinate space")
    if "private fun DigitalV2RoadMotion" in cockpit_text or "private fun DigitalV2WindOverlay" in cockpit_text:
        fail("Legacy Digital V2 trial-and-error motion functions are still present")
    passed("Digital V2 depth projection, fixed vehicle scale, asset shadow and SceneSpec wind validated")

def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    res = root / "app/src/main/res"
    source = root / "app/src/main/java"
    if not res.is_dir() or not source.is_dir():
        fail("Android source tree is incomplete")

    resources: dict[str, set[str]] = {key: set() for key in ("drawable", "mipmap", "string", "color", "dimen", "style", "xml", "raw", "font")}

    xml_count = 0
    for path in sorted(res.rglob("*.xml")):
        try:
            tree = ET.parse(path)
        except ET.ParseError as exc:
            fail(f"Malformed XML: {path.relative_to(root)}: {exc}")
        xml_count += 1
        parent = path.parent.name.split("-", 1)[0]
        if parent in ("drawable", "mipmap", "xml", "font"):
            resources[parent].add(path.stem)
        if parent == "values":
            for child in tree.getroot():
                name = child.attrib.get("name")
                tag = child.tag.split("}")[-1]
                if not name:
                    continue
                kind = "style" if tag == "style" else tag
                if kind in resources:
                    resources[kind].add(name)
    passed(f"{xml_count} Android XML file parsed successfully")

    file_types = {
        "drawable": ("drawable",),
        "mipmap": ("mipmap",),
        "raw": ("raw",),
        "font": ("font",),
        "xml": ("xml",),
    }
    for kind, prefixes in file_types.items():
        for directory in res.iterdir():
            if not directory.is_dir() or directory.name.split("-", 1)[0] not in prefixes:
                continue
            for path in directory.iterdir():
                if path.is_file():
                    resources[kind].add(path.stem)
                    if not RESOURCE_NAME.fullmatch(path.stem):
                        fail(f"Invalid Android resource filename: {path.relative_to(root)}")
    passed("Android resource filenames are valid")

    kt_files = list(source.rglob("*.kt"))
    missing: list[str] = []
    for path in kt_files:
        text = path.read_text(encoding="utf-8")
        for token, label in INVALID_IMPORTS.items():
            if token in text:
                fail(f"{label}: {path.relative_to(root)}")
        if INLINE_LAMBDA_LOOP_CONTROL.search(text):
            fail(
                "Kotlin break/continue must not escape an inline scope-function lambda: "
                f"{path.relative_to(root)}"
            )
        for kind, name in R_REF.findall(text):
            if name not in resources[kind]:
                missing.append(f"{path.relative_to(root)} -> R.{kind}.{name}")
    if missing:
        fail("Missing app resource reference(s):\n  " + "\n  ".join(sorted(set(missing))))
    passed(f"{len(kt_files)} Kotlin file checked for resource references and known invalid imports")

    validate_digital_v2(root)

    manifest = root / "app/src/main/AndroidManifest.xml"
    if not manifest.is_file():
        fail("AndroidManifest.xml is missing")
    passed("Android source/resource preflight completed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
