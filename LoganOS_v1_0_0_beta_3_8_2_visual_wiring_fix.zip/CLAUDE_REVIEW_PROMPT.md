# LoganOS v1.0.0-beta.3.8.2 Review Prompt

This ZIP contains LoganOS Android/Kotlin/Jetpack Compose version `1.0.0-beta.3.8.2`.

Please review it specifically for:

1. Build blockers
- Kotlin/Compose syntax errors
- missing imports or broken resource references
- Gradle versionCode/versionName consistency
- GitHub Actions workflow defaults

2. Setup visuals
- Dacia/Renault brand logos should be visible and not clipped.
- Gauge style selection should show a list first, then a large preview in the dialog.
- Gauge previews should be visually distinct across Digital, Sport, Classic OEM, Minimal and RS Performance.

3. Cockpit visuals
- Cockpit icons should be large/readable and preserve their custom XML colors.
- Text size should be readable on a phone in portrait mode.
- Yazı Boyutu / Text Size should visibly affect cockpit typography.
- Kokpit Yoğunluğu / Cockpit Density should visibly affect row height, spacing and cockpit compactness.
- Bottom navigation should not cover content.

4. Style wiring
- Changing Gauge Style in setup/settings should affect the real cockpit speed gauge, not only preview dialogs.
- The chosen style mappings remain: Digital C, Sport C, Classic OEM A, Minimal C, RS Performance D.

5. Do not recommend unnecessary refactors to these unless there is a definite bug:
- FuelAlgorithmV3
- TripComputer
- CUTOFF
- AC_FAST
- Delphi DCM1.2 parser byte positions
- OBD polling loop
- Cranking analysis core logic
- Fuel calibration factor logic
- Fan UNKNOWN/test pending decision
