## v1.0.0-beta.3.8.2 - Visual Wiring Fix

### Fixed
- Fixed setup brand cards so Dacia and Renault logo assets are clearly visible.
- Enlarged brand logo area and removed clipping caused by the previous small logo container.
- Reworked Dacia/Renault XML brand marks for stronger contrast on the setup screen.
- Made gauge style previews larger and more representative of the selected style.
- Made gauge styles visibly different in the actual speed gauge: Digital, Sport, Classic OEM, Minimal and RS Performance now have distinct gauge treatments.
- Enlarged cockpit metric icons and text for better readability in vehicle use.
- Increased the visible effect of Yazı Boyutu / Text Size and Kokpit Yoğunluğu / Cockpit Density.
- Kept the approved custom XML icon set and preserved icon colors with Color.Unspecified.

### Preserved
- FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST and Delphi parser byte positions were not intentionally changed.
- Fan UNKNOWN / test pending behavior remains preserved.
- Optional fuel calibration behavior remains preserved.
