# LoganOS

## Beta 3.8.2 Visual Wiring Fix

Version: `1.0.0-beta.3.8.2`

This package fixes the visual wiring problems reported after v3.8.1:

- Setup brand logos now render as large, clear Dacia/Renault logo cards.
- Gauge style previews are larger and better represent the chosen style.
- Gauge styles are wired into the real cockpit speed gauge instead of only showing a generic preview.
- Cockpit icons and text are larger by default for better readability while driving.
- Text Size and Cockpit Density settings now have a stronger visible effect.

Commit message:

```text
Fix cockpit visual wiring
```

Critical OBD/fuel systems were intentionally left unchanged unless required by UI wiring.
