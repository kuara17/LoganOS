# LoganOS v1.0.0-beta.3.8.7

Gauge area and zero-speed static style fix.
