# LoganOS beta.3.8.7 Claude Review Prompt

Please verify the gauge style fix:

- `SpeedGauge` compact threshold should be `maxHeight < 110.dp`.
- `cockpitGaugeMinHeight` should be Compact 130dp, Balanced 150dp, Wide 170dp.
- Digital/Sport/RS gauges should show static progress-independent tracks/segments at speed 0.
- Classic OEM scale labels should not be hidden behind `if (!compact)`.
- The project should compile without unresolved references.

Do not modify OBD parser, FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, or calibration logic.
