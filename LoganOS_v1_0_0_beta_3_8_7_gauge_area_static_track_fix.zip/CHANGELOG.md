# LoganOS v1.0.0-beta.3.8.7

## v1.0.0-beta.3.8.7 - Gauge Area Static Track Fix

- Increased real cockpit gauge area heights: Compact 130dp, Balanced 150dp, Wide 170dp.
- Lowered SpeedGauge compact threshold to 110dp so real cockpit no longer collapses style identity.
- Added static full background/track drawing for Digital and Sport gauges so style remains visible at speed 0 / OBD waiting.
- Added always-visible 22-segment inactive RS Performance bar plus red static accents at speed 0.
- Kept Classic OEM scale labels visible in compact mode with scaled font.
- Kept PNG/WebP cockpit and brand assets.
- No changes to OBD parser, FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, or calibration core.
