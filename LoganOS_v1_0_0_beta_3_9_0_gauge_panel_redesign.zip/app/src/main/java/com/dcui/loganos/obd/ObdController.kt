package com.dcui.loganos.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.dcui.loganos.data.LoganSqlStore
import com.dcui.loganos.model.DashboardSnapshot
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private data class DeveloperTestPhase(
    val title: String,
    val seconds: Int
)

class ObdController(private val context: Context) {
    var state by mutableStateOf(ObdState())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var developerTestJob: Job? = null
    private var socket: BluetoothSocket? = null
    private val parser = DelphiParser()
    private val tripComputer = TripComputer()
    private val sqlStore = LoganSqlStore(context)
    private var currentSqlSessionId: Long? = null
    private var lastSqlSessionId: Long? = null
    private var rawEcuLogEnabled: Boolean = false
    private var longTripLogEnabled: Boolean = false
    private var lastSqlSampleMs: Long = 0L
    private var lastStableEngineTempC: Int? = null
    private val crankPrefs = context.getSharedPreferences("loganos_crank_tests", Context.MODE_PRIVATE)
    private var lastRpmForCrank: Int? = null
    private var crankStartMs: Long? = null
    private var crankStartVoltage: Double? = null
    private var crankMinVoltage: Double? = null
    private var crankTempC: Int? = null
    private var crankObdGapDetected: Boolean = false
    private var crankManual: Boolean = false
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    init {
        state = state.copy(savedManualCrankTests = loadManualCrankTests())
    }

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    fun setLoggingOptions(rawEcuLog: Boolean, longTripLog: Boolean) {
        rawEcuLogEnabled = rawEcuLog
        longTripLogEnabled = longTripLog
        state = state.copy(rawEcuLogEnabled = rawEcuLog, longTripLogEnabled = longTripLog)
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni bekleniyor. Uygulama izni verilmeden cihaz listesi okunamaz.", error = true)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            appendStatus("Bu cihazda Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        val devices = adapter.bondedDevices.orEmpty()
            .map { PairedObdDevice(it.name ?: "OBD cihazı", it.address) }
            .sortedWith(compareByDescending<PairedObdDevice> { looksLikeObd(it.name) }.thenBy { it.name })
        state = state.copy(
            pairedDevices = devices,
            status = if (devices.isEmpty()) "Eşleşmiş OBD cihazı bulunamadı" else "${devices.size} eşleşmiş cihaz bulundu",
            logText = state.logText + "\n[BT] Paired devices: ${devices.joinToString { it.displayName }}"
        )
    }

    fun selectDevice(device: PairedObdDevice) {
        state = state.copy(
            selectedAddress = device.address,
            selectedName = device.name,
            status = "Seçildi: ${device.name}",
            logText = state.logText + "\n[BT] Selected ${device.displayName}"
        )
    }

    fun connectSelected() {
        val address = state.selectedAddress
        if (address == null) {
            appendStatus("Önce vLinker MC+ / ELM327 cihazını seç.", error = true)
            return
        }
        connect(address)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String, autoReconnectAttempt: Boolean = false) {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni yok. Android izin ekranından izin verilmeli.", error = true)
            return
        }
        disconnect(silent = true)
        currentSqlSessionId = sqlStore.startSession(LOGAN_VERSION, state.selectedName, address)
        lastSqlSessionId = currentSqlSessionId
        lastSqlSampleMs = 0L
        lastStableEngineTempC = null
        lastRpmForCrank = null
        crankStartMs = null
        crankManual = false
        sqlStore.insertEvent(currentSqlSessionId, "CONNECT_REQUEST", "OBD bağlantısı", state.selectedName ?: address)
        state = state.copy(
            connecting = true,
            connected = false,
            status = if (autoReconnectAttempt) "Bluetooth yeniden bağlanıyor..." else "Bluetooth bağlanıyor...",
            lastError = null,
            sqlSessionId = currentSqlSessionId,
            sqlDbPath = sqlStore.databaseFile().absolutePath,
            loopCount = 0,
            noDataCount = 0,
            stoppedCount = 0,
            busInitCount = 0,
            slowLoopCount = 0,
            rawEcuLogEnabled = rawEcuLogEnabled,
            longTripLogEnabled = longTripLogEnabled,
            manualCrankArmed = false,
            crankingInProgress = false
        )
        job = scope.launch {
            try {
                val streams = withTimeout(32000L) {
                    val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth adaptörü yok")
                    val device = adapter.getRemoteDevice(address)
                    withMain { appendLog("[BT] Connecting to ${device.name ?: address} / $address") }
                    adapter.cancelDiscovery()
                    val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                    socket = sock
                    sock.connect()
                    val out = sock.outputStream
                    val input = sock.inputStream
                    withMain { state = state.copy(connecting = false, connected = true, status = "Bluetooth bağlı • ELM init başlıyor") }

                    val initCommands = listOf(
                        // Alpha 1.4.9 ile çalışan Delphi DCM1.2 / VDIAG08 init dizisine yaklaştırıldı.
                        // KWP tarafında erken komut gönderip ELM'i STOPPED durumuna düşürmemek için timeoutlar genişletildi.
                        Triple("ATZ", 1000L, 2200L),
                        Triple("ATE0", 150L, 1000L),
                        Triple("ATL0", 150L, 1000L),
                        Triple("ATS1", 150L, 1000L),
                        Triple("ATH1", 150L, 1000L),
                        Triple("ATSP5", 150L, 1000L),
                        Triple("ATIIA7A", 150L, 1000L),
                        Triple("ATWM817AF1", 150L, 1000L),
                        Triple("ATSH817AF1", 150L, 1000L),
                        Triple("ATFI", 600L, 6500L),
                        Triple("10C0", 250L, 1800L)
                    )
                    initCommands.forEach { (cmd, wait, timeout) ->
                        val resp = send(out, input, cmd, wait, timeout)
                        withMain { appendLog("${if (cmd.isBlank()) "<wake>" else cmd}  =>  $resp") }
                    }
                    Pair(out, input)
                }
                sqlStore.insertEvent(currentSqlSessionId, "CONNECT_OK", "KWP test döngüsü", "poll loop başladı")
                withMain { state = state.copy(connecting = false, connected = true, status = "KWP test döngüsü başladı") }
                pollLoop(streams.first, streams.second)
            } catch (t: TimeoutCancellationException) {
                withMain {
                    sqlStore.insertEvent(currentSqlSessionId, "CONNECT_ERROR", "Zaman aşımı", "Tekrar Bağlan ile yeniden denenebilir")
                    appendStatus("Bağlantı zaman aşımı. Tekrar Bağlan ile yeniden denenebilir.", error = true)
                    state = state.copy(connecting = false, connected = false)
                }
                closeSocket()
            } catch (t: CancellationException) {
                withMain { state = state.copy(connecting = false, connected = false) }
            } catch (t: Throwable) {
                val message = t.message ?: t.javaClass.simpleName
                val wasPolling = state.connected || state.loopCount > 0
                if (crankStartMs != null) {
                    finishCranking(System.currentTimeMillis(), lastRpmForCrank ?: 0, completed = false)
                }
                withMain {
                    sqlStore.insertEvent(currentSqlSessionId, "CONNECT_ERROR", "Bağlantı hatası", message)
                    val shouldRetry = wasPolling && !autoReconnectAttempt && state.selectedAddress == address
                    appendStatus(
                        if (shouldRetry) "Bağlantı koptu: $message • 2 sn içinde bir kez yeniden denenecek" else "Bağlantı hatası: $message",
                        error = true
                    )
                    state = state.copy(connecting = false, connected = false)
                    if (shouldRetry) {
                        sqlStore.insertEvent(currentSqlSessionId, "AUTO_RECONNECT", "Tek deneme", "2 sn sonra yeniden bağlanılacak")
                    }
                }
                closeSocket()
                if (wasPolling && !autoReconnectAttempt && state.selectedAddress == address) {
                    job = null
                    scope.launch {
                        delay(2000L)
                        if (!state.connected && !state.connecting && state.selectedAddress == address) {
                            connect(address, autoReconnectAttempt = true)
                        }
                    }
                }
            }
        }
    }

    fun disconnect(silent: Boolean = false) {
        job?.cancel()
        job = null
        closeSocket()
        if (crankStartMs != null) {
            finishCranking(System.currentTimeMillis(), lastRpmForCrank ?: 0, completed = false)
        }
        sqlStore.insertEvent(currentSqlSessionId, if (silent) "DISCONNECT_SILENT" else "DISCONNECT", "OBD bağlantısı", null)
        sqlStore.endSession(currentSqlSessionId)
        if (currentSqlSessionId != null) lastSqlSessionId = currentSqlSessionId
        currentSqlSessionId = null
        lastStableEngineTempC = null
        lastRpmForCrank = null
        crankStartMs = null
        crankManual = false
        val updated = state.copy(connecting = false, connected = false, manualCrankArmed = false, crankingInProgress = false, status = if (silent) state.status else "Bağlantı kesildi", sqlSessionId = null, sqlDbPath = sqlStore.databaseFile().absolutePath)
        state = updated
        if (!silent) appendLog("[BT] Disconnected")
    }

    fun release() {
        disconnect(silent = true)
        runCatching { sqlStore.close() }
    }

    private suspend fun pollLoop(out: OutputStream, input: InputStream) {
        var loopIndex = 0
        var lastAtrv = ""
        while (job?.isActive == true) {
            val start = System.currentTimeMillis()
            loopIndex++

            // 21CC_FAST artık doğrulanmış klima biti için hızlı kaynak.
            // Fan biti DC UI/log kanıtıyla doğrulanmadığı için burada işlenmez.
            if (loopIndex == 1 || loopIndex % 8 == 0) {
                lastAtrv = send(out, input, "ATRV", 35L, 800L)
                delay(15)
            }
            val rawCCFast = send(out, input, "21CC", 20L, 700L)
            val fastParsed = parser.parse("", "", rawCCFast, "", lastAtrv, runFuelAlgorithm = false)
            val fastAc = fastParsed.acOn
            withMain {
                val previous = state.snapshot
                val acEvent = if (fastAc != null && fastAc != previous.acOn) {
                    sqlStore.insertEvent(currentSqlSessionId, "AC_FAST", if (fastAc) "ON" else "OFF", "loop=$loopIndex raw=$rawCCFast")
                    "\n[AC_FAST] ${if (fastAc) "ON" else "OFF"} loop=$loopIndex raw=$rawCCFast"
                } else ""
                val fastSnapshot = previous.copy(
                    connected = true,
                    rpm = fastParsed.rpm ?: previous.rpm,
                    acOn = fastAc ?: previous.acOn,
                    radiatorFanOn = null,
                    raw21CC = rawCCFast
                )
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • hızlı 21CC",
                    snapshot = fastSnapshot,
                    raw21CC = rawCCFast,
                    timingText = "fast 21CC",
                    logText = trimLog(state.logText + acEvent)
                )
            }
            delay(15)

            val rawA0 = send(out, input, "21A0", 45L, 1150L)
            delay(15)
            val rawCCFresh = rawCCFast

            // 21A2 ve 21CD ağır teknik paketler. beta 3.5: canlı kokpit için seyrek okunur;
            // Teknik sekmede bu paketlerin cached olabileceği kabul edilir.
            val rawA2 = if (loopIndex % 10 == 0 || state.raw21A2.isBlank()) {
                send(out, input, "21A2", 45L, 1150L)
            } else state.raw21A2
            delay(15)
            val rawCD = if (loopIndex % 16 == 0 || state.raw21CD.isBlank()) {
                send(out, input, "21CD", 40L, 950L)
            } else state.raw21CD

            var stdRpm = ""
            var stdSpeed = ""
            var stdTemp = ""
            if (loopIndex % 3 == 0 && !rawA0.contains("61A0", ignoreCase = true) && !rawA0.contains("BUS INIT", ignoreCase = true)) {
                delay(30)
                stdRpm = send(out, input, "010C", 40L, 750L)
                delay(30)
                stdSpeed = send(out, input, "010D", 40L, 750L)
                delay(30)
                stdTemp = send(out, input, "0105", 40L, 750L)
            }

            val parsed = parser.parse(rawA0, rawA2, rawCCFresh, rawCD, lastAtrv, stdRpm, stdSpeed, stdTemp)
            val baseSnapshot = parsed.toSnapshot(rawA0, rawA2, rawCCFresh, rawCD, connected = true)
            val filteredEngineTemp = smoothEngineTemp(baseSnapshot.engineTempC)
            val trip = tripComputer.update(parsed.speedKmh, parsed.fuelLh)
            val snapshot = baseSnapshot.copy(
                engineTempC = filteredEngineTemp,
                // 21CC_FAST cevap verdiyse doğrulanmış klima değerini final snapshot'ta da koru.
                // Fan biti doğrulanmadığı için bilinmiyor kalır.
                acOn = fastAc ?: baseSnapshot.acOn,
                radiatorFanOn = null,
                averageConsumption = trip.averageL100,
                tripDistanceKm = trip.distanceKm,
                fuelUsedL = trip.fuelUsedL,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState
            )
            val elapsed = System.currentTimeMillis() - start
            val nowMs = System.currentTimeMillis()
            val rawCombined = "$rawCCFresh $rawA0 $rawA2 $rawCD"
            processCrankingSample(snapshot, nowMs, rawCombined)
            val hasNoData = rawCombined.contains("NO DATA", ignoreCase = true)
            val hasStopped = rawCombined.contains("STOPPED", ignoreCase = true)
            val hasBusInit = rawCombined.contains("BUS INIT", ignoreCase = true)
            val shouldStoreSql = !longTripLogEnabled || lastSqlSampleMs == 0L || nowMs - lastSqlSampleMs >= 1000L || hasNoData || hasStopped || hasBusInit || snapshot.fuelSource == "CUTOFF"
            if (shouldStoreSql) {
                lastSqlSampleMs = nowMs
                sqlStore.insertSample(
                    currentSqlSessionId,
                    loopIndex,
                    elapsed,
                    snapshot,
                    if (rawEcuLogEnabled) rawCCFresh else "",
                    if (rawEcuLogEnabled) rawA0 else "",
                    if (rawEcuLogEnabled) rawA2 else "",
                    if (rawEcuLogEnabled) rawCD else ""
                )
            }
            val loopClock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(nowMs))
            withMain {
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • ${elapsed} ms",
                    snapshot = snapshot,
                    raw21A0 = rawA0,
                    raw21A2 = rawA2,
                    raw21CC = rawCCFresh,
                    raw21CD = rawCD,
                    timingText = "fast 21CC • loop=${elapsed}ms",
                    loopCount = loopIndex,
                    noDataCount = state.noDataCount + if (hasNoData) 1 else 0,
                    stoppedCount = state.stoppedCount + if (hasStopped) 1 else 0,
                    busInitCount = state.busInitCount + if (hasBusInit) 1 else 0,
                    slowLoopCount = state.slowLoopCount + if (elapsed > 1000L) 1 else 0,
                    logText = trimLog(state.logText + "\n[LOOP #$loopIndex at=$loopClock ${elapsed}ms] rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} fuel=${snapshot.injectionMg ?: "--"} pedal=${snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} map=${snapshot.mapMbar ?: "--"} air=${snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--"} ac=${snapshot.acOn ?: "--"} fan=UNKNOWN src=${snapshot.fuelSource} trip=${snapshot.tripStateText ?: "--"} dist=${snapshot.tripDistanceKm?.let { String.format(Locale.US, "%.3f", it) } ?: "--"} fuelUsed=${snapshot.fuelUsedL?.let { String.format(Locale.US, "%.4f", it) } ?: "--"} avg=${snapshot.averageConsumption?.let { String.format(Locale.US, "%.2f", it) } ?: "--"}")
                )
            }
            delay(55)
        }
    }

    private fun smoothEngineTemp(current: Int?): Int? {
        val last = lastStableEngineTempC
        if (current == null) return last
        val filtered = if (last != null && current < last - 8) {
            // beta 3.8.0: ignore one-frame ECT drops that are not physically plausible.
            last
        } else {
            current
        }
        lastStableEngineTempC = filtered
        return filtered
    }

    private fun send(out: OutputStream, input: InputStream, cmd: String, waitMs: Long, timeoutMs: Long): String {
        drainInput(input)
        if (cmd.isNotBlank()) {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        }
        Thread.sleep(waitMs)
        val buffer = StringBuilder()
        val start = System.currentTimeMillis()
        var gotAny = false
        var lastData = System.currentTimeMillis()

        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = input.available()
            if (available > 0) {
                gotAny = true
                lastData = System.currentTimeMillis()
                repeat(available) {
                    val b = input.read()
                    if (b >= 0) {
                        val ch = b.toChar()
                        buffer.append(ch)
                        if (ch == '>') return clean(buffer.toString())
                    }
                }
            } else {
                val current = buffer.toString()
                val quietFor = System.currentTimeMillis() - lastData
                // BUS INIT devam ederken erken çıkma; aksi halde bir sonraki komut ELM'i STOPPED'a düşürüyor.
                val kwpInitInProgress = current.contains("BUS INIT", ignoreCase = true) && !current.contains("OK", ignoreCase = true) && !current.contains(">")
                if (gotAny && !kwpInitInProgress && quietFor > 260L) return clean(current)
                Thread.sleep(10)
            }
        }
        return clean(buffer.toString())
    }

    private fun drainInput(input: InputStream) {
        runCatching {
            var guard = 0
            while (input.available() > 0 && guard < 4096) {
                input.read()
                guard++
            }
        }
    }

    fun armManualCrankAnalysis() {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Marş analizi için önce OBD bağlantısı gerekli")
            appendLog("[CRANK_MANUAL_BLOCKED] OBD connection required")
            return
        }
        state = state.copy(manualCrankArmed = true, status = "Marş analizi hazır • şimdi marşa basın")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_ARMED", "Marş Analizi", "Kullanıcı manuel testi başlattı")
        appendLog("[CRANK_MANUAL_ARMED] Ready; start engine now")
    }

    fun clearManualCrankTests() {
        crankPrefs.edit().remove(KEY_MANUAL_CRANKS).apply()
        state = state.copy(savedManualCrankTests = emptyList(), status = "Manuel marş testleri silindi")
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_CLEAR", "Marş Analizi", "Manuel kayıtlar silindi")
        appendLog("[CRANK_MANUAL_CLEAR] Saved manual cranking tests cleared")
    }

    private fun processCrankingSample(snapshot: DashboardSnapshot, nowMs: Long, rawCombined: String) {
        val rpm = snapshot.rpm
        val voltage = snapshot.batteryV ?: snapshot.adapterVoltageV
        val previousRpm = lastRpmForCrank
        val obdGap = rawCombined.contains("NO DATA", ignoreCase = true) ||
            rawCombined.contains("STOPPED", ignoreCase = true) ||
            rawCombined.contains("BUS INIT", ignoreCase = true) ||
            (crankStartMs != null && rpm == null)

        if (crankStartMs != null) {
            if (voltage != null) crankMinVoltage = minOf(crankMinVoltage ?: voltage, voltage)
            if (obdGap) crankObdGapDetected = true
            val durationMs = nowMs - (crankStartMs ?: nowMs)
            when {
                rpm != null && rpm >= 600 -> finishCranking(nowMs, rpm, completed = true)
                durationMs > 8000L -> finishCranking(nowMs, rpm ?: previousRpm ?: 0, completed = false)
                rpm != null -> lastRpmForCrank = rpm
            }
            return
        }

        if (rpm == null) return

        val wasStopped = previousRpm != null && previousRpm <= 120
        val startedTurning = wasStopped && rpm >= 180
        if (startedTurning) {
            crankStartMs = nowMs
            crankStartVoltage = voltage
            crankMinVoltage = voltage
            crankTempC = snapshot.engineTempC
            crankObdGapDetected = obdGap
            crankManual = state.manualCrankArmed
            state = state.copy(crankingInProgress = true, status = if (crankManual) "Manuel marş testi algılandı" else "Marş algılandı • analiz ediliyor")
            if (crankManual) {
                sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_START", "Manuel marş", "rpm=$rpm voltage=${voltage ?: "--"}")
            }
            appendLog("[CRANK_START] manual=$crankManual rpm=$rpm voltage=${voltage ?: "--"}")
        }
        lastRpmForCrank = rpm
    }

    private fun finishCranking(nowMs: Long, rpmAtFinish: Int, completed: Boolean) {
        val startMs = crankStartMs ?: return
        val duration = ((nowMs - startMs).coerceAtLeast(0L)) / 1000.0
        val manual = crankManual
        val result = buildCrankResult(
            timestampMs = nowMs,
            manual = manual,
            durationSec = duration,
            startVoltage = crankStartVoltage,
            minVoltage = crankMinVoltage,
            engineTempC = crankTempC,
            rpmAtFinish = rpmAtFinish,
            obdGapDetected = crankObdGapDetected,
            completed = completed
        )
        val autoRecent = if (manual) state.recentAutoCrankResults else (listOf(result) + state.recentAutoCrankResults)
            .filter { nowMs - it.timestampMs <= 24L * 60L * 60L * 1000L }
            .take(5)
        val manualTests = if (manual) {
            val updated = (listOf(result) + state.savedManualCrankTests).take(50)
            saveManualCrankTests(updated)
            updated
        } else state.savedManualCrankTests
        state = state.copy(
            manualCrankArmed = false,
            crankingInProgress = false,
            lastAutoCrankResult = if (manual) state.lastAutoCrankResult else result,
            recentAutoCrankResults = autoRecent,
            savedManualCrankTests = manualTests,
            status = "Marş analizi: ${result.status} • ${String.format(Locale.US, "%.1f", result.durationSec)} sn"
        )
        if (manual) {
            sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "CRANK_MANUAL_RESULT", result.status, result.comment)
        }
        appendLog("[CRANK_RESULT] manual=$manual duration=${String.format(Locale.US, "%.2f", result.durationSec)}s startV=${result.startVoltage ?: "--"} minV=${result.minVoltage ?: "--"} status=${result.status} battery=${result.batteryStatus} gap=${result.obdGapDetected}")
        crankStartMs = null
        crankStartVoltage = null
        crankMinVoltage = null
        crankTempC = null
        crankObdGapDetected = false
        crankManual = false
    }

    private fun buildCrankResult(
        timestampMs: Long,
        manual: Boolean,
        durationSec: Double,
        startVoltage: Double?,
        minVoltage: Double?,
        engineTempC: Int?,
        rpmAtFinish: Int?,
        obdGapDetected: Boolean,
        completed: Boolean
    ): CrankAnalysisResult {
        val cold = engineTempC == null || engineTempC < 50
        val status = when {
            !completed -> "Tamamlanamadı"
            cold && durationSec <= 2.0 -> "Normal"
            !cold && durationSec <= 1.2 -> "Normal"
            cold && durationSec <= 3.0 -> "Hafif uzun"
            !cold && durationSec <= 2.0 -> "Hafif uzun"
            durationSec <= 4.0 -> "Geç marş"
            else -> "Belirgin geç marş"
        }
        val batteryStatus = when {
            minVoltage == null -> "Ölçülemedi"
            minVoltage >= 10.0 -> "İyi"
            minVoltage >= 9.6 -> "Sınırda"
            minVoltage >= 9.0 -> "Zayıf"
            else -> "Çok düşük"
        }
        val comment = buildString {
            append(when (status) {
                "Normal" -> "Marş süresi normal görünüyor."
                "Hafif uzun" -> "Marş süresi hafif uzun; tekrar eden durumda takip edilmeli."
                "Geç marş" -> "Marş süresi uzun. Akü, yakıt hattı, krank/eksantrik sinyali ve kızdırma sistemi kontrol edilebilir."
                "Belirgin geç marş" -> "Belirgin geç marş algılandı. Akü/şase, marş motoru, yakıt basıncı ve sensör senkronu kontrol edilmeli."
                else -> "Marş analizi tamamlanamadı; OBD cevabı veya RPM verisi kesilmiş olabilir."
            })
            if (minVoltage != null && minVoltage < 9.6) append(" Marş sırasında voltaj belirgin düşmüş.")
            if (obdGapDetected) append(" Marş sırasında kısa OBD cevap boşluğu görüldü.")
        }
        return CrankAnalysisResult(timestampMs, manual, durationSec, startVoltage, minVoltage, engineTempC, rpmAtFinish, obdGapDetected, status, batteryStatus, comment)
    }

    private fun loadManualCrankTests(): List<CrankAnalysisResult> {
        val raw = crankPrefs.getString(KEY_MANUAL_CRANKS, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.lineSequence().mapNotNull { line ->
            val p = line.split("|")
            runCatching {
                if (p.size < 10) return@mapNotNull null
                CrankAnalysisResult(
                    timestampMs = p[0].toLong(),
                    manual = true,
                    durationSec = p[1].toDouble(),
                    startVoltage = p[2].toDoubleOrNull(),
                    minVoltage = p[3].toDoubleOrNull(),
                    engineTempC = p[4].toIntOrNull(),
                    rpmAtFinish = p[5].toIntOrNull(),
                    obdGapDetected = p[6].toBoolean(),
                    status = p[7],
                    batteryStatus = p[8],
                    comment = p.drop(9).joinToString("|")
                )
            }.getOrNull()
        }.toList()
    }

    private fun saveManualCrankTests(items: List<CrankAnalysisResult>) {
        val raw = items.joinToString("\n") { r ->
            listOf(
                r.timestampMs.toString(),
                String.format(Locale.US, "%.3f", r.durationSec),
                r.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "",
                r.engineTempC?.toString() ?: "",
                r.rpmAtFinish?.toString() ?: "",
                r.obdGapDetected.toString(),
                r.status,
                r.batteryStatus,
                r.comment.replace("\n", " ").replace("|", "/")
            ).joinToString("|")
        }
        crankPrefs.edit().putString(KEY_MANUAL_CRANKS, raw).apply()
    }


    fun resetTrip() {
        tripComputer.reset()
        sqlStore.insertEvent(currentSqlSessionId ?: lastSqlSessionId, "TRIP_RESET", "Ortalama tüketimi sıfırla", null)
        val trip = tripComputer.snapshot()
        state = state.copy(
            snapshot = state.snapshot.copy(
                averageConsumption = trip.averageL100,
                tripDistanceKm = trip.distanceKm,
                fuelUsedL = trip.fuelUsedL,
                tripDurationText = trip.durationText,
                tripStateText = trip.displayState,
                tripCostText = null
            ),
            status = "Trip sıfırlandı"
        )
        appendLog("[TRIP] Reset")
    }

    fun startDeveloperTest(name: String) {
        if (!state.connected && !state.connecting) {
            state = state.copy(status = "Test için önce OBD bağlantısı gerekli")
            appendLog("[TEST_BLOCKED] $name requires OBD connection")
            return
        }
        developerTestJob?.cancel()
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "TEST_START", name, "Kullanıcı testi başlattı")
        state = state.copy(
            activeDeveloperTest = name,
            developerTestPhaseText = "Hazırlan",
            developerTestRemainingSec = 3,
            developerTestDoneMessage = null,
            status = "Test başladı: $name"
        )
        appendLog("[TEST_START] $name")
        developerTestJob = scope.launch {
            runDeveloperTestGuide(name, sessionId)
        }
    }

    fun finishDeveloperTest() {
        val name = state.activeDeveloperTest ?: return
        developerTestJob?.cancel()
        developerTestJob = null
        val sessionId = currentSqlSessionId ?: lastSqlSessionId
        sqlStore.insertEvent(sessionId, "TEST_END", name, "Kullanıcı testi bitirdi")
        state = state.copy(
            activeDeveloperTest = null,
            developerTestPhaseText = null,
            developerTestRemainingSec = null,
            developerTestDoneMessage = "Test bitti: $name",
            status = "Test bitti: $name"
        )
        appendLog("[TEST_END] $name")
        scope.launch { clearDeveloperTestDoneMessageLater(name) }
    }

    private suspend fun runDeveloperTestGuide(name: String, sessionId: Long?) {
        val phases = developerTestPhases(name)
        try {
            phases.forEach { phase ->
                sqlStore.insertEvent(sessionId, "TEST_PHASE", name, phase.title)
                withMain {
                    state = state.copy(
                        activeDeveloperTest = name,
                        developerTestPhaseText = phase.title,
                        developerTestRemainingSec = phase.seconds,
                        developerTestDoneMessage = null,
                        status = "Test: $name • ${phase.title}"
                    )
                    appendLog("[TEST_PHASE] $name • ${phase.title} • ${phase.seconds}s")
                }
                for (remaining in phase.seconds downTo 1) {
                    withMain {
                        if (state.activeDeveloperTest == name) {
                            state = state.copy(developerTestRemainingSec = remaining)
                        }
                    }
                    delay(1000L)
                }
            }
            sqlStore.insertEvent(sessionId, "TEST_END", name, "Otomatik geri sayım tamamlandı")
            withMain {
                state = state.copy(
                    activeDeveloperTest = null,
                    developerTestPhaseText = null,
                    developerTestRemainingSec = null,
                    developerTestDoneMessage = "Test bitti: $name",
                    status = "Test bitti: $name"
                )
                appendLog("[TEST_END] $name")
            }
            clearDeveloperTestDoneMessageLater(name)
        } catch (_: CancellationException) {
            // Kullanıcı testi manuel bitirdiğinde buraya düşer; log finishDeveloperTest içinde yazılır.
        }
    }

    private fun developerTestPhases(name: String): List<DeveloperTestPhase> = when (name) {
        "Sıcak rölanti testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 60),
            DeveloperTestPhase("Klimayı aç", 60),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Klima testi" -> listOf(
            DeveloperTestPhase("Klima kapalı tut", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Klimayı kapat", 30)
        )
        "Elektrik/yük testi" -> listOf(
            DeveloperTestPhase("Klima kapalı kalsın; tüm yükler kapalı", 30),
            DeveloperTestPhase("Kısa farları aç; klima kapalı", 30),
            DeveloperTestPhase("Uzun/sis farlarını aç; klima kapalı", 30),
            DeveloperTestPhase("Arka rezistansı aç; klima kapalı", 30),
            DeveloperTestPhase("Kalorifer fanını aç; klima kapalı", 30),
            DeveloperTestPhase("Yükleri kapat", 20)
        )
        "Tam yük testi" -> listOf(
            DeveloperTestPhase("Tüm yükler kapalı", 30),
            DeveloperTestPhase("Farlar + sisler + rezistansı aç", 30),
            DeveloperTestPhase("Kalorifer fanını aç", 30),
            DeveloperTestPhase("Klimayı aç", 30),
            DeveloperTestPhase("Tüm yükleri kapat", 20)
        )
        "CUTOFF testi" -> listOf(
            DeveloperTestPhase("20-30 km/h üstüne çık", 20),
            DeveloperTestPhase("Gazı tamamen bırak", 15),
            DeveloperTestPhase("Güvenli şekilde yavaşla", 10)
        )
        "Serbest sürüş testi" -> listOf(
            DeveloperTestPhase("Normal şehir içi sürüşe başla", 60),
            DeveloperTestPhase("Sürüşe devam et", 240)
        )
        else -> listOf(DeveloperTestPhase("Testi uygula", 60))
    }

    private suspend fun clearDeveloperTestDoneMessageLater(name: String) {
        delay(3000L)
        withMain {
            if (state.developerTestDoneMessage == "Test bitti: $name") {
                state = state.copy(developerTestDoneMessage = null)
            }
        }
    }

    private fun exportLogText(): String {
        val base = sqlStore.exportSessionText(currentSqlSessionId ?: lastSqlSessionId) ?: state.logText.ifBlank { "Log yok" }
        val lastAuto = state.lastAutoCrankResult ?: return base
        val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(lastAuto.timestampMs))
        val crank = buildString {
            append("\n\n[LAST_AUTO_CRANK_ANALYSIS]\n")
            append("time=").append(time).append('\n')
            append("duration=").append(String.format(Locale.US, "%.2f", lastAuto.durationSec)).append(" s\n")
            append("status=").append(lastAuto.status).append('\n')
            append("battery=").append(lastAuto.batteryStatus).append('\n')
            append("startV=").append(lastAuto.startVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("minV=").append(lastAuto.minVoltage?.let { String.format(Locale.US, "%.2f", it) } ?: "--").append('\n')
            append("engineTemp=").append(lastAuto.engineTempC?.toString() ?: "--").append(" °C\n")
            append("obdGap=").append(lastAuto.obdGapDetected).append('\n')
            append("comment=").append(lastAuto.comment).append('\n')
        }
        return base + crank
    }

    fun saveLogFile() {
        val fileName = makeLogFileName()
        val text = exportLogText()
        val displayPath = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                    put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LoganOS")
                }
                val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("MediaStore URI oluşturulamadı")
                context.contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                "Download/LoganOS/$fileName"
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.mkdirs()
                val file = File(dir, fileName)
                file.writeText(text)
                file.absolutePath
            }
        }.getOrElse {
            val dir = context.getExternalFilesDir(null) ?: context.filesDir
            val file = File(dir, fileName)
            file.writeText(text)
            file.absolutePath
        }
        state = state.copy(savedLogPath = displayPath, savedLogFileName = fileName, status = "Log kaydedildi: $displayPath", sharedLogReady = true)
        appendLog("[LOG] Saved to $displayPath")
    }

    fun shareLogText() {
        val text = exportLogText()
        val fileName = makeLogFileName(prefix = "loganos_share")
        val shareDir = File(context.cacheDir, "log_share").apply { mkdirs() }
        val file = File(shareDir, fileName).apply { writeText(text) }
        val uri = FileProvider.getUriForFile(context, context.packageName + ".fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "LoganOS OBD Log")
            putExtra(Intent.EXTRA_TITLE, fileName)
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(intent, "LoganOS log paylaş").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        state = state.copy(status = "Log paylaşım ekranı açıldı")
    }

    fun clearLastLogFile() {
        val fileName = state.savedLogFileName
        if (fileName.isNullOrBlank()) {
            state = state.copy(status = "Silinecek son log yok")
            return
        }
        val deleted = deleteDownloadLogByName(fileName)
        state = state.copy(
            savedLogPath = null,
            savedLogFileName = null,
            sharedLogReady = false,
            status = if (deleted) "Son log silindi: $fileName" else "Son log bulunamadı: $fileName"
        )
        appendLog("[LOG] Clear last requested: $fileName deleted=$deleted")
    }

    fun clearAllLogFiles() {
        val deleted = deleteAllDownloadLogs()
        val sqlDeleted = sqlStore.clearAll()
        currentSqlSessionId = null
        lastSqlSessionId = null
        state = state.copy(savedLogPath = null, savedLogFileName = null, sharedLogReady = false, status = "$deleted log dosyası ve $sqlDeleted SQL kaydı silindi", sqlSessionId = null)
        appendLog("[LOG] Clear all requested: files=$deleted sql=$sqlDeleted")
    }

    private fun makeLogFileName(prefix: String = "loganos_obd"): String {
        val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm-ss_SSS", Locale.US).format(Date())
        return "${prefix}_beta3_8_2_${stamp}.txt"
    }

    private fun deleteDownloadLogByName(fileName: String): Boolean {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf(fileName, Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args) > 0
            } else {
                val file = File(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS"), fileName)
                file.exists() && file.delete()
            }
        }.getOrDefault(false)
    }

    private fun deleteAllDownloadLogs(): Int {
        return runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.MediaColumns.DISPLAY_NAME} LIKE ? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?"
                val args = arrayOf("loganos_%", Environment.DIRECTORY_DOWNLOADS + "/LoganOS/")
                context.contentResolver.delete(uri, selection, args)
            } else {
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "LoganOS")
                dir.listFiles { f -> f.name.startsWith("loganos_") && f.name.endsWith(".txt") }?.count { it.delete() } ?: 0
            }
        }.getOrDefault(0)
    }

    private fun clean(text: String): String = text.replace("\r", " ").replace("\n", " ").replace(">", " > ").trim()

    private fun closeSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun appendStatus(text: String, error: Boolean = false) {
        state = state.copy(status = text, lastError = if (error) text else state.lastError, logText = trimLog(state.logText + "\n[STATUS] $text"))
    }

    private fun appendLog(text: String) {
        state = state.copy(logText = trimLog(state.logText + "\n$text"))
    }

    private suspend fun withMain(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun trimLog(log: String): String {
        return if (log.length <= 300000) log else log.takeLast(300000)
    }

    private fun looksLikeObd(name: String): Boolean {
        val n = name.lowercase()
        return listOf("obd", "elm", "vlink", "vgate", "icar", "kwp").any { it in n }
    }

    companion object {
        private const val LOGAN_VERSION = "1.0.0-beta.3.9.0"
        private const val KEY_MANUAL_CRANKS = "manual_crank_tests"
    }
}
