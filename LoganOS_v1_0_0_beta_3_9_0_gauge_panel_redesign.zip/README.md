# LoganOS v1.0.0-beta.3.9.0

Gauge style panel redesign release.

This version changes the cockpit gauge architecture so the selected gauge style controls the full speed panel character, not just small arc/color tweaks inside a shared SpeedGauge.
