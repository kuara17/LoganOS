# LoganOS v1.0.0-beta.3.9.0

## Redesign gauge style panels

- Replaced the cockpit speed block behavior so gauge style now selects a full speed panel, not only a small SpeedGauge brush/arc variation.
- Added distinct panel architecture for Digital C, Sport C, Classic OEM A, Minimal C, and RS Performance D.
- Setup gauge previews now use the same real SpeedPanel system as the cockpit instead of a separate/simplified preview drawing.
- Digital keeps the modern thin arc language.
- Sport has stronger motion rails and dynamic accents.
- Classic OEM emphasizes analog scale identity with a smaller/different readout position.
- Minimal uses a large readout and reduced visual clutter.
- RS Performance uses a red, aggressive panel character with performance underline accents.
- Kept OBD, FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, Delphi parser bytes, and fuel calibration logic untouched.
