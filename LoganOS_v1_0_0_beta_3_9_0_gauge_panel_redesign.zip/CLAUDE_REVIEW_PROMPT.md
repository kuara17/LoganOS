# Claude Review Prompt — LoganOS v1.0.0-beta.3.9.0

Please review the LoganOS Android/Kotlin Jetpack Compose project focusing on the new gauge style panel redesign.

Main goal: GaugeStyle must change the full cockpit speed panel character, not only the small SpeedGauge arc/color.

Expected structure:
- `SpeedPanel(...)` dispatches by `GaugeStyle`.
- Digital uses `DigitalSpeedPanel`.
- Sport uses `SportSpeedPanel`.
- Classic OEM uses `ClassicOemSpeedPanel`.
- Minimal uses `MinimalSpeedPanel`.
- RS Performance uses `RsPerformanceSpeedPanel`.

Please verify:
1. Setup preview uses the same `SpeedPanel` system as the cockpit preview.
2. Dashboard `ConceptSpeedBlock` calls `SpeedPanel`, not only `SpeedGauge`.
3. Each style remains visually distinct at speed 0 / disconnected.
4. No regressions in FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, Delphi parser bytes, OBD connection loop, fuel calibration, or cranking analysis.
5. Build compiles without missing imports or signature errors.
