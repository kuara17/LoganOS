package com.dcui.loganos.ui.cockpit.opengl

/**
 * Pixel-calibrated scene profiles for the exact 1080x1320 background assets.
 *
 * Distance 0m is the near/bottom road. Outer curves follow the photographed
 * asphalt shoulders. The centre curve is the divider left of the follow camera.
 * Curved scenes deliberately fade the divider before the road disappears around
 * the bend; it must not remain visible as a long ribbon behind the corner.
 */
internal object DigitalV2SceneModels {

    private fun curve(vararg points: CalibrationPoint): CalibratedCurve =
        CalibratedCurve(points.toList())

    private val mountainRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.360f, 1.000f),
            CalibrationPoint(6f, 0.385f, 0.920f),
            CalibrationPoint(14f, 0.420f, 0.840f),
            CalibrationPoint(24f, 0.470f, 0.750f),
            CalibrationPoint(38f, 0.530f, 0.660f),
            CalibrationPoint(56f, 0.590f, 0.580f),
            CalibrationPoint(78f, 0.635f, 0.515f),
            CalibrationPoint(100f, 0.657f, 0.472f),
            CalibrationPoint(120f, 0.665f, 0.445f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.030f, 1.000f),
            CalibrationPoint(6f, 0.065f, 0.920f),
            CalibrationPoint(14f, 0.125f, 0.840f),
            CalibrationPoint(24f, 0.220f, 0.750f),
            CalibrationPoint(38f, 0.350f, 0.660f),
            CalibrationPoint(56f, 0.485f, 0.580f),
            CalibrationPoint(78f, 0.585f, 0.515f),
            CalibrationPoint(100f, 0.635f, 0.472f),
            CalibrationPoint(120f, 0.650f, 0.445f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 0.970f, 1.000f),
            CalibrationPoint(6f, 0.930f, 0.920f),
            CalibrationPoint(14f, 0.875f, 0.840f),
            CalibrationPoint(24f, 0.810f, 0.750f),
            CalibrationPoint(38f, 0.750f, 0.660f),
            CalibrationPoint(56f, 0.705f, 0.580f),
            CalibrationPoint(78f, 0.680f, 0.515f),
            CalibrationPoint(100f, 0.672f, 0.472f),
            CalibrationPoint(120f, 0.675f, 0.445f)
        ),
        roadWidthMeters = 10.8f,
        markings = RoadMarkingPattern(
            centerLineWidthMeters = 0.15f,
            edgeLineWidthMeters = 0.16f,
            minimumVisibleWidthPixels = 1.7f,
            maximumVisibleWidthPixels = 9f
        ),
        visibility = RoadMarkingVisibility(
            centerNearFadeStartMeters = 12f, centerNearFadeEndMeters = 20f,
            centerFadeStartMeters = 31f,
            centerFadeEndMeters = 45f,
            edgeFadeStartMeters = 88f,
            edgeFadeEndMeters = 112f
        ),
        centerLineColor = GlColor(0.98f, 0.98f, 0.96f, 0.91f),
        leftEdgeLineColor = GlColor(0.96f, 0.98f, 1.00f, 0.78f),
        rightEdgeLineColor = GlColor(0.96f, 0.98f, 1.00f, 0.78f),
        showLeftEdgeLine = true,
        showRightEdgeLine = true
    )

    val MountainLake = DigitalV2SceneModel(
        key = DigitalV2SceneKey.MountainLake,
        road = mountainRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f,
            tireContactYRatio = 0.872f,
            visibleWidthRatio = 0.335f,
            headingDegrees = 0.35f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.310f, bodyHeightRatio = 0.066f, bodyAlpha = 0.58f,
                tireWidthRatio = 0.055f, tireHeightRatio = 0.028f, tireAlpha = 1.00f,
                groundBlendWidthRatio = 0.245f, groundBlendHeightRatio = 0.034f,
                groundBlendAlpha = 0.52f, offsetYRatio = 0.001f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.90f, contrast = 0.91f, saturation = 0.91f,
                redMultiplier = 0.93f, greenMultiplier = 0.98f,
                blueMultiplier = 1.05f,
                upperRedMultiplier = 0.94f, upperGreenMultiplier = 1.00f, upperBlueMultiplier = 1.08f,
                lowerRedMultiplier = 0.88f, lowerGreenMultiplier = 0.93f, lowerBlueMultiplier = 0.98f,
                edgeSoftness = 0.54f
            )
        ),
        wind = WindZoneProfile(
            edgeOffsetRoadWidthRatio = 0.050f, zoneWidthRoadWidthRatio = 0.080f,
            maxAlpha = 0.060f
        ),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.020f)
    )

    private val cityDayRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.405f, 1.000f),
            CalibrationPoint(6f, 0.419f, 0.920f),
            CalibrationPoint(14f, 0.432f, 0.840f),
            CalibrationPoint(24f, 0.447f, 0.750f),
            CalibrationPoint(38f, 0.463f, 0.660f),
            CalibrationPoint(56f, 0.477f, 0.575f),
            CalibrationPoint(78f, 0.489f, 0.505f),
            CalibrationPoint(100f, 0.496f, 0.462f),
            CalibrationPoint(120f, 0.500f, 0.440f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.020f, 1.000f),
            CalibrationPoint(6f, 0.089f, 0.920f),
            CalibrationPoint(14f, 0.157f, 0.840f),
            CalibrationPoint(24f, 0.234f, 0.750f),
            CalibrationPoint(38f, 0.311f, 0.660f),
            CalibrationPoint(56f, 0.384f, 0.575f),
            CalibrationPoint(78f, 0.444f, 0.505f),
            CalibrationPoint(100f, 0.481f, 0.462f),
            CalibrationPoint(120f, 0.495f, 0.440f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 0.980f, 1.000f),
            CalibrationPoint(6f, 0.911f, 0.920f),
            CalibrationPoint(14f, 0.843f, 0.840f),
            CalibrationPoint(24f, 0.766f, 0.750f),
            CalibrationPoint(38f, 0.689f, 0.660f),
            CalibrationPoint(56f, 0.616f, 0.575f),
            CalibrationPoint(78f, 0.556f, 0.505f),
            CalibrationPoint(100f, 0.519f, 0.462f),
            CalibrationPoint(120f, 0.505f, 0.440f)
        ),
        roadWidthMeters = 14.0f,
        markings = RoadMarkingPattern(
            centerLineWidthMeters = 0.15f, edgeLineWidthMeters = 0.16f,
            minimumVisibleWidthPixels = 1.8f, maximumVisibleWidthPixels = 9f
        ),
        visibility = RoadMarkingVisibility(
            centerNearFadeStartMeters = 12f, centerNearFadeEndMeters = 20f,
            centerFadeStartMeters = 92f, centerFadeEndMeters = 118f,
            edgeFadeStartMeters = 96f, edgeFadeEndMeters = 120f
        ),
        centerLineColor = GlColor(0.98f, 0.98f, 0.97f, 0.90f),
        leftEdgeLineColor = GlColor(0.96f, 0.98f, 1.00f, 0.72f),
        rightEdgeLineColor = GlColor(0.96f, 0.98f, 1.00f, 0.72f),
        showLeftEdgeLine = true, showRightEdgeLine = true
    )

    val CityDay = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityDay, road = cityDayRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f, tireContactYRatio = 0.928f,
            visibleWidthRatio = 0.405f, headingDegrees = 0f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.372f, bodyHeightRatio = 0.071f, bodyAlpha = 0.62f,
                tireWidthRatio = 0.065f, tireHeightRatio = 0.030f, tireAlpha = 1.00f,
                groundBlendWidthRatio = 0.292f, groundBlendHeightRatio = 0.038f,
                groundBlendAlpha = 0.58f, offsetYRatio = 0.001f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.92f, contrast = 0.92f, saturation = 0.92f,
                upperRedMultiplier = 1.02f, upperGreenMultiplier = 1.01f, upperBlueMultiplier = 0.98f,
                lowerRedMultiplier = 0.91f, lowerGreenMultiplier = 0.93f, lowerBlueMultiplier = 0.96f,
                edgeSoftness = 0.50f
            )
        ),
        wind = WindZoneProfile(enabled = false, edgeOffsetRoadWidthRatio = 0.045f,
            zoneWidthRoadWidthRatio = 0.072f, maxAlpha = 0.052f),
        roadMotion = RoadSurfaceMotionProfile(enabled = false, maxAlpha = 0.018f),
        usesBakedRoadPresentation = true
    )

    private val cityNightRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.410f, 1.000f),
            CalibrationPoint(6f, 0.423f, 0.920f),
            CalibrationPoint(14f, 0.437f, 0.840f),
            CalibrationPoint(24f, 0.452f, 0.750f),
            CalibrationPoint(38f, 0.467f, 0.660f),
            CalibrationPoint(56f, 0.480f, 0.580f),
            CalibrationPoint(78f, 0.491f, 0.515f),
            CalibrationPoint(100f, 0.497f, 0.476f),
            CalibrationPoint(120f, 0.500f, 0.460f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.020f, 1.000f),
            CalibrationPoint(6f, 0.091f, 0.920f),
            CalibrationPoint(14f, 0.162f, 0.840f),
            CalibrationPoint(24f, 0.242f, 0.750f),
            CalibrationPoint(38f, 0.322f, 0.660f),
            CalibrationPoint(56f, 0.393f, 0.580f),
            CalibrationPoint(78f, 0.451f, 0.515f),
            CalibrationPoint(100f, 0.486f, 0.476f),
            CalibrationPoint(120f, 0.495f, 0.460f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 0.980f, 1.000f),
            CalibrationPoint(6f, 0.909f, 0.920f),
            CalibrationPoint(14f, 0.838f, 0.840f),
            CalibrationPoint(24f, 0.758f, 0.750f),
            CalibrationPoint(38f, 0.678f, 0.660f),
            CalibrationPoint(56f, 0.607f, 0.580f),
            CalibrationPoint(78f, 0.549f, 0.515f),
            CalibrationPoint(100f, 0.514f, 0.476f),
            CalibrationPoint(120f, 0.505f, 0.460f)
        ),
        roadWidthMeters = 14.4f,
        markings = RoadMarkingPattern(
            centerLineWidthMeters = 0.15f, edgeLineWidthMeters = 0.16f,
            minimumVisibleWidthPixels = 1.8f, maximumVisibleWidthPixels = 9f
        ),
        visibility = RoadMarkingVisibility(
            centerNearFadeStartMeters = 12f, centerNearFadeEndMeters = 20f,
            centerFadeStartMeters = 92f, centerFadeEndMeters = 118f,
            edgeFadeStartMeters = 96f, edgeFadeEndMeters = 120f
        ),
        centerLineColor = GlColor(1.00f, 0.97f, 0.90f, 0.88f),
        leftEdgeLineColor = GlColor(0.93f, 0.95f, 1.00f, 0.68f),
        rightEdgeLineColor = GlColor(0.93f, 0.95f, 1.00f, 0.68f),
        showLeftEdgeLine = true, showRightEdgeLine = true
    )

    val CityNight = DigitalV2SceneModel(
        key = DigitalV2SceneKey.CityNight, road = cityNightRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f, tireContactYRatio = 0.870f,
            visibleWidthRatio = 0.330f, headingDegrees = 0f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.308f, bodyHeightRatio = 0.066f, bodyAlpha = 0.48f,
                tireWidthRatio = 0.055f, tireHeightRatio = 0.029f, tireAlpha = 1.00f,
                groundBlendWidthRatio = 0.245f, groundBlendHeightRatio = 0.035f,
                groundBlendAlpha = 0.46f, offsetYRatio = 0.001f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.70f, contrast = 0.88f, saturation = 0.82f,
                redMultiplier = 1.06f, greenMultiplier = 0.91f,
                blueMultiplier = 0.80f,
                upperRedMultiplier = 0.88f, upperGreenMultiplier = 0.92f, upperBlueMultiplier = 1.08f,
                lowerRedMultiplier = 0.76f, lowerGreenMultiplier = 0.79f, lowerBlueMultiplier = 0.86f,
                edgeSoftness = 0.58f
            )
        ),
        wind = WindZoneProfile(edgeOffsetRoadWidthRatio = 0.045f,
            zoneWidthRoadWidthRatio = 0.075f, maxAlpha = 0.056f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.016f)
    )

    private val snowRoad = DigitalV2RoadCalibration(
        centerLine = curve(
            CalibrationPoint(0f, 0.375f, 1.000f),
            CalibrationPoint(6f, 0.398f, 0.920f),
            CalibrationPoint(14f, 0.425f, 0.840f),
            CalibrationPoint(24f, 0.460f, 0.750f),
            CalibrationPoint(38f, 0.495f, 0.660f),
            CalibrationPoint(56f, 0.525f, 0.580f),
            CalibrationPoint(78f, 0.542f, 0.515f),
            CalibrationPoint(100f, 0.541f, 0.478f),
            CalibrationPoint(120f, 0.542f, 0.455f)
        ),
        leftRoadEdge = curve(
            CalibrationPoint(0f, 0.030f, 1.000f),
            CalibrationPoint(6f, 0.070f, 0.920f),
            CalibrationPoint(14f, 0.140f, 0.840f),
            CalibrationPoint(24f, 0.230f, 0.750f),
            CalibrationPoint(38f, 0.330f, 0.660f),
            CalibrationPoint(56f, 0.425f, 0.580f),
            CalibrationPoint(78f, 0.495f, 0.515f),
            CalibrationPoint(100f, 0.525f, 0.478f),
            CalibrationPoint(120f, 0.535f, 0.455f)
        ),
        rightRoadEdge = curve(
            CalibrationPoint(0f, 0.970f, 1.000f),
            CalibrationPoint(6f, 0.930f, 0.920f),
            CalibrationPoint(14f, 0.860f, 0.840f),
            CalibrationPoint(24f, 0.790f, 0.750f),
            CalibrationPoint(38f, 0.720f, 0.660f),
            CalibrationPoint(56f, 0.660f, 0.580f),
            CalibrationPoint(78f, 0.605f, 0.515f),
            CalibrationPoint(100f, 0.565f, 0.478f),
            CalibrationPoint(120f, 0.548f, 0.455f)
        ),
        roadWidthMeters = 10.6f,
        markings = RoadMarkingPattern(
            centerLineWidthMeters = 0.15f, edgeLineWidthMeters = 0.16f,
            minimumVisibleWidthPixels = 1.7f, maximumVisibleWidthPixels = 9f
        ),
        visibility = RoadMarkingVisibility(
            centerNearFadeStartMeters = 12f, centerNearFadeEndMeters = 20f,
            centerFadeStartMeters = 32f, centerFadeEndMeters = 47f,
            edgeFadeStartMeters = 88f, edgeFadeEndMeters = 112f
        ),
        centerLineColor = GlColor(0.98f, 0.99f, 1.00f, 0.90f),
        leftEdgeLineColor = GlColor(0.95f, 0.98f, 1.00f, 0.76f),
        rightEdgeLineColor = GlColor(0.95f, 0.98f, 1.00f, 0.76f),
        showLeftEdgeLine = true, showRightEdgeLine = true
    )

    val SnowRoad = DigitalV2SceneModel(
        key = DigitalV2SceneKey.SnowRoad, road = snowRoad,
        vehiclePose = VehicleScenePose(
            centerXRatio = 0.500f, tireContactYRatio = 0.872f,
            visibleWidthRatio = 0.335f, headingDegrees = -0.15f,
            shadow = VehicleShadowProfile(
                bodyWidthRatio = 0.312f, bodyHeightRatio = 0.066f, bodyAlpha = 0.50f,
                tireWidthRatio = 0.055f, tireHeightRatio = 0.028f, tireAlpha = 0.98f,
                groundBlendWidthRatio = 0.247f, groundBlendHeightRatio = 0.034f,
                groundBlendAlpha = 0.48f, offsetYRatio = 0.001f
            ),
            colorGrade = VehicleColorGrade(
                exposure = 0.86f, contrast = 0.90f, saturation = 0.86f,
                redMultiplier = 0.87f, greenMultiplier = 0.97f,
                blueMultiplier = 1.11f,
                upperRedMultiplier = 0.98f, upperGreenMultiplier = 1.04f, upperBlueMultiplier = 1.13f,
                lowerRedMultiplier = 0.94f, lowerGreenMultiplier = 1.02f, lowerBlueMultiplier = 1.10f,
                edgeSoftness = 0.56f
            )
        ),
        wind = WindZoneProfile(edgeOffsetRoadWidthRatio = 0.055f,
            zoneWidthRoadWidthRatio = 0.078f, maxAlpha = 0.052f),
        roadMotion = RoadSurfaceMotionProfile(maxAlpha = 0.018f)
    )

    fun forKey(key: DigitalV2SceneKey): DigitalV2SceneModel = when (key) {
        DigitalV2SceneKey.MountainLake -> MountainLake
        DigitalV2SceneKey.CityDay -> CityDay
        DigitalV2SceneKey.CityNight -> CityNight
        DigitalV2SceneKey.SnowRoad -> SnowRoad
    }
}
