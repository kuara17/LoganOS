package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.max
import kotlin.math.min

/**
 * Renderer-independent Digital V2 scene contract.
 *
 * The fixed 1080x1320 stage is calibrated directly against each background
 * image. Road centre/edge curves are stored in normalized image coordinates,
 * while animation distance remains in metres. OpenGL receives preprojected NDC
 * ribbon meshes, so the dynamic markings follow the photographed road rather
 * than a generic camera template.
 */
internal const val DIGITAL_V2_LOGICAL_WIDTH = 1080f
internal const val DIGITAL_V2_LOGICAL_HEIGHT = 1320f
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO =
    DIGITAL_V2_LOGICAL_WIDTH / DIGITAL_V2_LOGICAL_HEIGHT

internal data class DigitalV2PixelViewport(
    val x: Int,
    val y: Int,
    val width: Int,
    val height: Int
)

/** Fits the fixed logical stage into any Surface without X/Y distortion. */
internal fun calculateDigitalV2Viewport(surfaceWidth: Int, surfaceHeight: Int): DigitalV2PixelViewport {
    require(surfaceWidth > 0 && surfaceHeight > 0)
    val surfaceAspect = surfaceWidth.toFloat() / surfaceHeight.toFloat()
    return if (surfaceAspect > DIGITAL_V2_STAGE_ASPECT_RATIO) {
        val viewportHeight = surfaceHeight
        val viewportWidth = (viewportHeight * DIGITAL_V2_STAGE_ASPECT_RATIO)
            .toInt()
            .coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = (surfaceWidth - viewportWidth) / 2,
            y = 0,
            width = viewportWidth,
            height = viewportHeight
        )
    } else {
        val viewportWidth = surfaceWidth
        val viewportHeight = (viewportWidth / DIGITAL_V2_STAGE_ASPECT_RATIO)
            .toInt()
            .coerceAtLeast(1)
        DigitalV2PixelViewport(
            x = 0,
            y = (surfaceHeight - viewportHeight) / 2,
            width = viewportWidth,
            height = viewportHeight
        )
    }
}

internal enum class DigitalV2SceneKey {
    MountainLake,
    CityDay,
    CityNight,
    SnowRoad
}

internal data class GlColor(
    val red: Float,
    val green: Float,
    val blue: Float,
    val alpha: Float
) {
    init {
        require(red in 0f..1.5f)
        require(green in 0f..1.5f)
        require(blue in 0f..1.5f)
        require(alpha in 0f..1f)
    }
}

internal data class NormalizedPoint(val x: Float, val y: Float) {
    init {
        require(x in -0.25f..1.25f)
        require(y in -0.10f..1.10f)
    }
}

internal data class CalibrationPoint(
    val distanceMeters: Float,
    val xRatio: Float,
    val yRatio: Float
) {
    init {
        require(distanceMeters >= 0f)
        require(xRatio in -0.25f..1.25f)
        require(yRatio in -0.10f..1.10f)
    }

    val point: NormalizedPoint get() = NormalizedPoint(xRatio, yRatio)
}

/**
 * C1-continuous non-uniform cubic Hermite curve.
 *
 * Distances are physical/visual road arc-length labels. Tangents are computed
 * using neighbouring distance intervals, avoiding the repeated stop/start
 * behaviour of the retired per-knot smoothstep interpolation.
 */
internal class CalibratedCurve(points: List<CalibrationPoint>) {
    val points: List<CalibrationPoint> = points.sortedBy { it.distanceMeters }
    val maxDistanceMeters: Float = this.points.last().distanceMeters

    init {
        require(this.points.size >= 4)
        require(this.points.first().distanceMeters == 0f)
        require(this.points.zipWithNext().all { (a, b) -> b.distanceMeters > a.distanceMeters })
        require(this.points.zipWithNext().all { (a, b) -> b.yRatio < a.yRatio }) {
            "Road calibration must move monotonically toward the horizon"
        }
    }

    fun sample(distanceMeters: Float): NormalizedPoint {
        val distance = distanceMeters.coerceIn(0f, maxDistanceMeters)
        val segment = points.indexOfLast { it.distanceMeters <= distance }
            .coerceIn(0, points.lastIndex - 1)
        val p1 = points[segment]
        val p2 = points[segment + 1]
        val p0 = points[(segment - 1).coerceAtLeast(0)]
        val p3 = points[(segment + 2).coerceAtMost(points.lastIndex)]
        val span = max(0.001f, p2.distanceMeters - p1.distanceMeters)
        val t = ((distance - p1.distanceMeters) / span).coerceIn(0f, 1f)
        val t2 = t * t
        val t3 = t2 * t
        val h00 = 2f * t3 - 3f * t2 + 1f
        val h10 = t3 - 2f * t2 + t
        val h01 = -2f * t3 + 3f * t2
        val h11 = t3 - t2

        val m1x = derivativeAt(p0, p2, axisX = true)
        val m1y = derivativeAt(p0, p2, axisX = false)
        val m2x = derivativeAt(p1, p3, axisX = true)
        val m2y = derivativeAt(p1, p3, axisX = false)

        return NormalizedPoint(
            x = (h00 * p1.xRatio + h10 * span * m1x + h01 * p2.xRatio + h11 * span * m2x)
                .coerceIn(-0.20f, 1.20f),
            y = (h00 * p1.yRatio + h10 * span * m1y + h01 * p2.yRatio + h11 * span * m2y)
                .coerceIn(-0.05f, 1.05f)
        )
    }

    fun tangent(distanceMeters: Float): NormalizedPoint {
        val epsilon = max(0.15f, maxDistanceMeters / 1000f)
        val before = sample((distanceMeters - epsilon).coerceAtLeast(0f))
        val after = sample((distanceMeters + epsilon).coerceAtMost(maxDistanceMeters))
        return NormalizedPoint(
            x = after.x - before.x,
            y = after.y - before.y
        )
    }

    private fun derivativeAt(a: CalibrationPoint, b: CalibrationPoint, axisX: Boolean): Float {
        val denominator = max(0.001f, b.distanceMeters - a.distanceMeters)
        return if (axisX) {
            (b.xRatio - a.xRatio) / denominator
        } else {
            (b.yRatio - a.yRatio) / denominator
        }
    }
}

internal data class RoadMarkingPattern(
    val dashLengthMeters: Float = 3f,
    val gapLengthMeters: Float = 6f,
    val centerLineWidthMeters: Float = 0.15f,
    val edgeLineWidthMeters: Float = 0.13f,
    val antialiasExpansion: Float = 1.65f,
    val dashEdgeSoftnessMeters: Float = 0.12f,
    val sideEdgeSoftness: Float = 0.22f,
    val minimumVisibleWidthPixels: Float = 1.8f,
    val maximumVisibleWidthPixels: Float = 10f
) {
    val repeatLengthMeters: Float get() = dashLengthMeters + gapLengthMeters

    init {
        require(dashLengthMeters > 0f)
        require(gapLengthMeters > 0f)
        require(centerLineWidthMeters > 0f)
        require(edgeLineWidthMeters > 0f)
        require(antialiasExpansion in 1f..2.5f)
        require(dashEdgeSoftnessMeters in 0.01f..0.5f)
        require(sideEdgeSoftness in 0.05f..0.45f)
        require(minimumVisibleWidthPixels in 0.8f..4f)
        require(maximumVisibleWidthPixels >= minimumVisibleWidthPixels)
    }
}


internal data class RoadMarkingVisibility(
    /** Hide the divider under/behind the fixed follow-camera vehicle. */
    val centerNearFadeStartMeters: Float = 12f,
    val centerNearFadeEndMeters: Float = 20f,
    /** Centre dashes begin fading before a photographed bend/occlusion. */
    val centerFadeStartMeters: Float = 88f,
    val centerFadeEndMeters: Float = 116f,
    /** Outer edge lines may remain visible farther than the lane divider. */
    val edgeFadeStartMeters: Float = 96f,
    val edgeFadeEndMeters: Float = 120f
) {
    init {
        require(centerNearFadeStartMeters >= 0f)
        require(centerNearFadeEndMeters > centerNearFadeStartMeters)
        require(centerFadeStartMeters >= centerNearFadeEndMeters)
        require(centerFadeEndMeters > centerFadeStartMeters)
        require(edgeFadeStartMeters >= 0f)
        require(edgeFadeEndMeters > edgeFadeStartMeters)
    }
}

internal data class DigitalV2RoadCalibration(
    val centerLine: CalibratedCurve,
    val leftRoadEdge: CalibratedCurve,
    val rightRoadEdge: CalibratedCurve,
    val roadWidthMeters: Float,
    val markings: RoadMarkingPattern = RoadMarkingPattern(),
    val visibility: RoadMarkingVisibility = RoadMarkingVisibility(),
    val centerLineColor: GlColor = GlColor(0.98f, 0.98f, 0.96f, 0.98f),
    val leftEdgeLineColor: GlColor = GlColor(0.96f, 0.98f, 1f, 0.55f),
    val rightEdgeLineColor: GlColor = GlColor(0.96f, 0.98f, 1f, 0.55f),
    val showLeftEdgeLine: Boolean = true,
    val showRightEdgeLine: Boolean = true
) {
    val maxDistanceMeters: Float = min(
        centerLine.maxDistanceMeters,
        min(leftRoadEdge.maxDistanceMeters, rightRoadEdge.maxDistanceMeters)
    )

    init {
        require(roadWidthMeters > 2f)
        require(maxDistanceMeters >= 60f)
        require(visibility.centerFadeEndMeters <= maxDistanceMeters + 0.001f)
        require(visibility.edgeFadeEndMeters <= maxDistanceMeters + 0.001f)
    }

    fun roadWidthPixels(distanceMeters: Float): Float {
        val left = leftRoadEdge.sample(distanceMeters)
        val right = rightRoadEdge.sample(distanceMeters)
        val dx = (right.x - left.x) * DIGITAL_V2_LOGICAL_WIDTH
        val dy = (right.y - left.y) * DIGITAL_V2_LOGICAL_HEIGHT
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }
}

internal data class VehicleAssetProfile(
    val textureAspectHeightOverWidth: Float,
    val visibleLeftRatioInTexture: Float,
    val visibleRightRatioInTexture: Float,
    val leftTireContactXRatioInTexture: Float,
    val rightTireContactXRatioInTexture: Float,
    val contactYRatioInTexture: Float,
    val visibleBottomRatioInTexture: Float
) {
    val visibleWidthRatioInTexture: Float
        get() = visibleRightRatioInTexture - visibleLeftRatioInTexture

    init {
        require(textureAspectHeightOverWidth > 0f)
        require(visibleLeftRatioInTexture in 0f..0.5f)
        require(visibleRightRatioInTexture in 0.5f..1f)
        require(visibleWidthRatioInTexture in 0.5f..1f)
        require(leftTireContactXRatioInTexture in visibleLeftRatioInTexture..0.5f)
        require(rightTireContactXRatioInTexture in 0.5f..visibleRightRatioInTexture)
        require(contactYRatioInTexture in 0.5f..1f)
        require(visibleBottomRatioInTexture in contactYRatioInTexture..1f)
    }
}

internal data class VehicleColorGrade(
    val exposure: Float = 1f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val redMultiplier: Float = 1f,
    val greenMultiplier: Float = 1f,
    val blueMultiplier: Float = 1f,
    val upperRedMultiplier: Float = 1f,
    val upperGreenMultiplier: Float = 1f,
    val upperBlueMultiplier: Float = 1f,
    val lowerRedMultiplier: Float = 1f,
    val lowerGreenMultiplier: Float = 1f,
    val lowerBlueMultiplier: Float = 1f,
    /** 0..1, mixed with a five-tap texture sample to soften cutout edges. */
    val edgeSoftness: Float = 0f
) {
    init {
        require(exposure in 0.55f..1.35f)
        require(contrast in 0.65f..1.35f)
        require(saturation in 0.55f..1.25f)
        require(redMultiplier in 0.65f..1.35f)
        require(greenMultiplier in 0.65f..1.35f)
        require(blueMultiplier in 0.65f..1.35f)
        require(upperRedMultiplier in 0.65f..1.35f)
        require(upperGreenMultiplier in 0.65f..1.35f)
        require(upperBlueMultiplier in 0.65f..1.35f)
        require(lowerRedMultiplier in 0.65f..1.35f)
        require(lowerGreenMultiplier in 0.65f..1.35f)
        require(lowerBlueMultiplier in 0.65f..1.35f)
        require(edgeSoftness in 0f..1f)
    }
}

internal data class VehicleShadowProfile(
    val bodyWidthRatio: Float,
    val bodyHeightRatio: Float,
    val bodyAlpha: Float,
    val tireWidthRatio: Float,
    val tireHeightRatio: Float,
    val tireAlpha: Float,
    val groundBlendWidthRatio: Float,
    val groundBlendHeightRatio: Float,
    val groundBlendAlpha: Float,
    val offsetXRatio: Float = 0f,
    val offsetYRatio: Float = -0.006f
) {
    init {
        require(bodyWidthRatio in 0.15f..0.40f)
        require(bodyHeightRatio in 0.015f..0.15f)
        require(bodyAlpha in 0f..1f)
        require(tireWidthRatio in 0.01f..0.10f)
        require(tireHeightRatio in 0.005f..0.08f)
        require(tireAlpha in 0f..1f)
        require(groundBlendWidthRatio in 0.08f..0.35f)
        require(groundBlendHeightRatio in 0.005f..0.10f)
        require(groundBlendAlpha in 0f..1f)
    }
}

internal data class VehicleScenePose(
    val centerXRatio: Float,
    val tireContactYRatio: Float,
    val visibleWidthRatio: Float,
    val headingDegrees: Float,
    val shadow: VehicleShadowProfile,
    val colorGrade: VehicleColorGrade = VehicleColorGrade()
) {
    init {
        require(centerXRatio in 0.35f..0.65f)
        require(tireContactYRatio in 0.75f..0.94f)
        require(visibleWidthRatio in 0.24f..0.45f)
        require(headingDegrees in -4f..4f)
    }
}

internal data class RoadSurfaceMotionProfile(
    val enabled: Boolean = true,
    val maxAlpha: Float = 0.028f,
    val cycleLengthMeters: Float = 4.8f,
    val nearFadeDistanceMeters: Float = 55f
) {
    init {
        require(maxAlpha in 0f..0.10f)
        require(cycleLengthMeters > 0f)
        require(nearFadeDistanceMeters > 5f)
    }
}

/** Wind ribbons are built outside the calibrated edge curves. */
internal data class WindZoneProfile(
    val enabled: Boolean = true,
    val edgeOffsetRoadWidthRatio: Float = 0.035f,
    val zoneWidthRoadWidthRatio: Float = 0.085f,
    val spacingMeters: Float = 8.5f,
    val streakLengthMeters: Float = 1.9f,
    val maxAlpha: Float = 0.085f
) {
    init {
        require(edgeOffsetRoadWidthRatio in 0f..0.25f)
        require(zoneWidthRoadWidthRatio in 0.02f..0.25f)
        require(spacingMeters > streakLengthMeters)
        require(streakLengthMeters > 0f)
        require(maxAlpha in 0f..0.30f)
    }
}

internal data class DigitalV2SceneModel(
    val key: DigitalV2SceneKey,
    val road: DigitalV2RoadCalibration,
    val vehiclePose: VehicleScenePose,
    val wind: WindZoneProfile,
    val roadMotion: RoadSurfaceMotionProfile = RoadSurfaceMotionProfile(),
    /**
     * The exact road markings are already composited into the scene background.
     * Used for the approved City Day visual stage so the renderer does not lay
     * another generic spline/mesh over the photographed asphalt.
     */
    val usesBakedRoadPresentation: Boolean = false
)

internal fun lerp(start: Float, end: Float, t: Float): Float =
    start + (end - start) * min(1f, max(0f, t))
