package com.dcui.loganos.obd

/**
 * Data-coverage check for the fuel calibration measurement.
 *
 * The app only counts fuel and distance while OBD data flows. If part of the drive was not
 * tracked (adapter dropped, app closed) the app liters are too low and the calibration factor
 * would come out too high. Comparing the app-tracked distance with the vehicle odometer
 * distance the user reads off the dashboard exposes that.
 */
object FuelCalibrationCoverage {
    /**
     * Ratio below which a warning (and an explicit confirmation) is shown.
     * null = warning disabled. No default is set on purpose: the threshold must be chosen from
     * real long-drive data and approved by the user first. Until then only the ratio is shown.
     */
    val WARN_BELOW_RATIO: Double? = null

    /** App-tracked distance divided by vehicle odometer distance, or null if not computable. */
    fun ratio(appDistanceKm: Double?, vehicleDistanceKm: Double?): Double? {
        if (appDistanceKm == null || vehicleDistanceKm == null) return null
        if (!appDistanceKm.isFinite() || !vehicleDistanceKm.isFinite()) return null
        if (appDistanceKm < 0.0 || vehicleDistanceKm <= 0.0) return null
        return appDistanceKm / vehicleDistanceKm
    }

    fun isLow(ratio: Double?, warnBelow: Double? = WARN_BELOW_RATIO): Boolean =
        ratio != null && warnBelow != null && ratio < warnBelow
}
