package com.dcui.loganos.obd

/** The three ways an RFCOMM socket to the adapter can be created. */
enum class SocketMethod(val storedName: String) {
    SECURE("secure"),
    INSECURE("insecure"),
    REFLECT_PORT_1("reflect1")
}

/**
 * Plans which socket methods to try, in which order and with which time limits.
 *
 * A method that has worked before for an adapter is remembered and used ALONE, so a setup that
 * already works behaves exactly as before. Only an adapter that never connected goes through the
 * whole chain. The timeouts are named constants; they are unverified on a real head unit.
 */
object SocketMethodPlanner {
    /** Limit for the first attempt (the remembered method, or the secure one). */
    const val PRIMARY_ATTEMPT_TIMEOUT_MS = 20_000L

    /** Limit for each fallback attempt. */
    const val FALLBACK_ATTEMPT_TIMEOUT_MS = 10_000L

    /** Pause between attempts so the Bluetooth stack can release the failed socket. */
    const val PAUSE_BETWEEN_ATTEMPTS_MS = 400L

    /** The previous overall limit for socket connect + ELM init. Unchanged for single-attempt plans. */
    const val BASE_CONNECT_AND_INIT_TIMEOUT_MS = 32_000L

    fun parse(stored: String?): SocketMethod? = SocketMethod.values().firstOrNull { it.storedName == stored }

    fun plan(remembered: SocketMethod?): List<SocketMethod> =
        if (remembered != null) {
            listOf(remembered)
        } else {
            listOf(SocketMethod.SECURE, SocketMethod.INSECURE, SocketMethod.REFLECT_PORT_1)
        }

    fun timeoutFor(attemptIndex: Int): Long =
        if (attemptIndex == 0) PRIMARY_ATTEMPT_TIMEOUT_MS else FALLBACK_ATTEMPT_TIMEOUT_MS

    /** Outer safety net: the old 32 s, plus the extra attempts of a fallback plan. */
    fun outerTimeoutMs(plan: List<SocketMethod>): Long =
        BASE_CONNECT_AND_INIT_TIMEOUT_MS + (plan.size - 1).coerceAtLeast(0) * FALLBACK_ATTEMPT_TIMEOUT_MS
}
