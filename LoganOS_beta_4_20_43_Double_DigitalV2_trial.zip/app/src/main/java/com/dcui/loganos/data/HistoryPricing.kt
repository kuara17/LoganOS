package com.dcui.loganos.data

import java.util.Locale
import kotlin.math.roundToLong

/** Price and calibration factor stored on a trip record when it closes (schema v7). */
data class TripPricing(
    /** Price of one liter in kuruş (minor units), or null when no valid price was set. */
    val pricePerLiterMinor: Long?,
    /** Calibration factor that was active, or null when calibration was off. */
    val calibrationFactor: Double?
)

object HistoryPricing {
    /** "42,35" or "42.35" -> 4235. Null for empty, non-numeric or non-positive input. */
    fun priceMinorPerLiter(priceText: String): Long? {
        val price = priceText.trim().replace(',', '.').toDoubleOrNull() ?: return null
        if (!price.isFinite() || price <= 0.0) return null
        return (price * 100.0).roundToLong().takeIf { it > 0L }
    }

    /** The factor to store: only when calibration is enabled, kept inside its valid limits. */
    fun calibrationFactorToStore(enabled: Boolean, factor: Double): Double? =
        if (enabled && factor.isFinite()) factor.coerceIn(0.50, 1.50) else null

    fun pricing(priceText: String, calibrationEnabled: Boolean, factor: Double): TripPricing =
        TripPricing(priceMinorPerLiter(priceText), calibrationFactorToStore(calibrationEnabled, factor))

    /**
     * Cost of one history record in TL, or null when no price is available.
     * New records use the price stored with them; old records (no stored price) fall back to the
     * current price and report [Result.usesCurrentPrice] = true so the UI can mark them.
     */
    data class Result(val value: Double, val usesCurrentPrice: Boolean)

    fun cost(
        fuelUsedL: Double,
        calibrationFactor: Double?,
        storedPricePerLiterMinor: Long?,
        currentPricePerLiter: Double?
    ): Result? {
        val fuel = fuelUsedL * (calibrationFactor ?: 1.0)
        if (storedPricePerLiterMinor != null && storedPricePerLiterMinor > 0L) {
            return Result(fuel * storedPricePerLiterMinor / 100.0, usesCurrentPrice = false)
        }
        val current = currentPricePerLiter?.takeIf { it.isFinite() && it > 0.0 } ?: return null
        return Result(fuel * current, usesCurrentPrice = true)
    }

    fun formatTl(value: Double): String = String.format(Locale.US, "%.2f \u20BA", value)
}
