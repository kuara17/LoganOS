package com.dcui.loganos.obd

import android.content.Context
import android.content.SharedPreferences
import android.os.SystemClock
import android.util.Log
import java.util.UUID

/**
 * Persists the user-facing cockpit totals across process and ignition cycles.
 *
 * Besides the totals it keeps a [CockpitTripIdentity]: a reset generation (bumped on every explicit
 * reset, in the same commit that zeroes the totals) and a random epoch id (renewed when the file
 * was missing or had to be repaired). Anything that depends on these totals can compare the
 * identity it saw with the current one and knows when it must not trust them any more.
 */
class PersistentCockpitTripStore internal constructor(
    private val prefs: SharedPreferences,
    private val installIdProvider: () -> String,
    private val newEpochId: () -> String
) {
    constructor(context: Context) : this(
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE),
        { InstallIdentity.get(context) },
        { UUID.randomUUID().toString() }
    )

    private var epochId: String = ""
    private var resetGeneration: Long = 1L

    /** Why the identity changed while loading (null when it did not). For diagnostics only. */
    var identityChangeReason: String? = null
        private set

    private val accumulator = PersistentCockpitTripAccumulator(loadStateAndIdentity())
    private var lastPersistElapsedMs: Long = 0L

    init {
        if (identityChangeReason != null) {
            // Make the (possibly repaired) totals and the new identity durable right away.
            persist(accumulator.snapshot(), synchronous = true)
            Log.w("LoganOS", "[TRIP_IDENTITY] identity renewed: $identityChangeReason generation=$resetGeneration")
        }
    }

    @Synchronized
    fun update(
        trip: TripComputerSnapshot,
        force: Boolean = false,
        nowElapsedMs: Long = SystemClock.elapsedRealtime()
    ): PersistentCockpitTripState {
        val previous = accumulator.snapshot()
        val updated = accumulator.update(
            tripToken = trip.tripToken,
            distanceKm = trip.distanceKm,
            fuelLiters = trip.fuelUsedL,
            durationSec = trip.durationSec
        )
        val boundaryChanged = previous.lastTripToken != updated.lastTripToken
        if (force || boundaryChanged || nowElapsedMs - lastPersistElapsedMs >= PERSIST_INTERVAL_MS) {
            persist(updated, force)
            lastPersistElapsedMs = nowElapsedMs
        }
        return updated
    }

    @Synchronized
    fun rebase(
        trip: TripComputerSnapshot,
        force: Boolean = true,
        nowElapsedMs: Long = SystemClock.elapsedRealtime()
    ): PersistentCockpitTripState {
        val updated = accumulator.rebase(
            tripToken = trip.tripToken,
            distanceKm = trip.distanceKm,
            fuelLiters = trip.fuelUsedL,
            durationSec = trip.durationSec
        )
        persist(updated, force)
        lastPersistElapsedMs = nowElapsedMs
        return updated
    }

    @Synchronized
    fun snapshot(): PersistentCockpitTripState = accumulator.snapshot()

    /** The identity of these totals (install id, epoch id, reset generation). */
    @Synchronized
    fun identity(): CockpitTripIdentity = CockpitTripIdentity(installIdProvider(), epochId, resetGeneration)

    /**
     * Clears only the persistent user-facing cockpit trip totals and bumps the reset generation.
     * Totals and generation are written in one synchronous commit, so there is no moment at which
     * the file holds zeroed totals with the old generation (or the other way round).
     */
    @Synchronized
    fun clearAll() {
        resetGeneration += 1L
        accumulator.clearAll()
        persist(accumulator.snapshot(), synchronous = true)
        lastPersistElapsedMs = SystemClock.elapsedRealtime()
    }

    private fun loadStateAndIdentity(): PersistentCockpitTripState {
        val raw = PersistentCockpitTripState(
            totalDistanceKm = Double.fromBits(prefs.getLong(KEY_TOTAL_DISTANCE, 0.0.toBits())),
            totalFuelLiters = Double.fromBits(prefs.getLong(KEY_TOTAL_FUEL, 0.0.toBits())),
            totalDurationSec = prefs.getLong(KEY_TOTAL_DURATION, 0L),
            lastTripToken = prefs.getLong(KEY_LAST_TRIP_TOKEN, 0L),
            lastTripDistanceKm = Double.fromBits(prefs.getLong(KEY_LAST_TRIP_DISTANCE, 0.0.toBits())),
            lastTripFuelLiters = Double.fromBits(prefs.getLong(KEY_LAST_TRIP_FUEL, 0.0.toBits())),
            lastTripDurationSec = prefs.getLong(KEY_LAST_TRIP_DURATION, 0L)
        )
        val resolved = CockpitTripIdentityResolver.resolve(
            storedEpochId = prefs.getString(KEY_EPOCH_ID, null),
            storedGeneration = if (prefs.contains(KEY_RESET_GENERATION)) prefs.getLong(KEY_RESET_GENERATION, 0L) else null,
            stateWasSanitized = raw.needsRepair(),
            newEpochId = newEpochId
        )
        epochId = resolved.epochId
        resetGeneration = resolved.resetGeneration
        identityChangeReason = resolved.changeReason
        return raw
    }

    private fun persist(state: PersistentCockpitTripState, synchronous: Boolean) {
        val editor = prefs.edit()
            .putLong(KEY_TOTAL_DISTANCE, state.totalDistanceKm.toBits())
            .putLong(KEY_TOTAL_FUEL, state.totalFuelLiters.toBits())
            .putLong(KEY_TOTAL_DURATION, state.totalDurationSec)
            .putLong(KEY_LAST_TRIP_TOKEN, state.lastTripToken)
            .putLong(KEY_LAST_TRIP_DISTANCE, state.lastTripDistanceKm.toBits())
            .putLong(KEY_LAST_TRIP_FUEL, state.lastTripFuelLiters.toBits())
            .putLong(KEY_LAST_TRIP_DURATION, state.lastTripDurationSec)
            // Identity travels in the SAME editor as the totals: one atomic write.
            .putString(KEY_EPOCH_ID, epochId)
            .putLong(KEY_RESET_GENERATION, resetGeneration)
        if (synchronous) editor.commit() else editor.apply()
    }

    private companion object {
        const val PREFS_NAME = "loganos_cockpit_trip_metrics"
        const val PERSIST_INTERVAL_MS = 3000L
        const val KEY_TOTAL_DISTANCE = "total_distance_bits"
        const val KEY_TOTAL_FUEL = "total_fuel_bits"
        const val KEY_TOTAL_DURATION = "total_duration_sec"
        const val KEY_LAST_TRIP_TOKEN = "last_trip_token"
        const val KEY_LAST_TRIP_DISTANCE = "last_trip_distance_bits"
        const val KEY_LAST_TRIP_FUEL = "last_trip_fuel_bits"
        const val KEY_LAST_TRIP_DURATION = "last_trip_duration_sec"
        const val KEY_EPOCH_ID = "epoch_id"
        const val KEY_RESET_GENERATION = "reset_generation"
    }
}
