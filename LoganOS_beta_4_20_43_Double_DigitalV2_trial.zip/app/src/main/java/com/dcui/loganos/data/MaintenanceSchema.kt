package com.dcui.loganos.data

/**
 * Database schema version 7: maintenance tracking, odometer anchors, fuel calibration history and
 * the price / calibration factor columns of trip_records.
 *
 * This file is the SINGLE source of truth for the new schema. [LoganSqlStore] creates the tables
 * from it and [DataBackupManager] validates restored backups against it, so the two cannot drift
 * apart. It is plain Kotlin on purpose so the schema can be unit tested without a database.
 *
 * Design rules (see the maintenance plan):
 *  - Money is stored as Long minor units (kuruş), never as Double.
 *  - A service date is a local calendar day (epoch day), not a UTC instant.
 *  - The total cost of a service line is NOT stored: it is parts + labor.
 *  - "Last service" and the due counters are NOT stored: they are derived from service_lines, so
 *    deleting or back-dating one record cannot corrupt another item's counters.
 *  - Both intervals of an item may be NULL (builtin items start without an interval). The rule
 *    "at least one interval" is enforced by the calculator, not by a CHECK constraint.
 */
object MaintenanceSchema {
    const val VERSION = 7

    data class Column(
        val name: String,
        val type: String,
        val notNull: Boolean = false,
        val primaryKey: Boolean = false,
        val defaultSql: String? = null,
        val unique: Boolean = false
    )

    data class ForeignKey(val column: String, val refTable: String, val refColumn: String, val onDelete: String)

    data class Index(val name: String, val table: String, val columns: List<String>)

    private fun id() = Column("id", "INTEGER", primaryKey = true)

    val tables: Map<String, List<Column>> = linkedMapOf(
        "maintenance_items" to listOf(
            id(),
            Column("item_key", "TEXT", notNull = true, unique = true),
            Column("name", "TEXT", notNull = true),
            Column("category", "TEXT", notNull = true),
            Column("km_interval", "INTEGER"),
            Column("month_interval", "INTEGER"),
            Column("warn_km", "INTEGER"),
            Column("warn_days", "INTEGER"),
            Column("builtin", "INTEGER", notNull = true, defaultSql = "0"),
            Column("archived_at_ms", "INTEGER"),
            Column("sort_order", "INTEGER", notNull = true, defaultSql = "0"),
            Column("created_at_ms", "INTEGER", notNull = true),
            Column("updated_at_ms", "INTEGER", notNull = true)
        ),
        "service_visits" to listOf(
            id(),
            Column("visit_epoch_day", "INTEGER", notNull = true),
            Column("odometer_km", "INTEGER", notNull = true),
            Column("odometer_note", "TEXT"),
            Column("shop", "TEXT"),
            Column("note", "TEXT"),
            Column("created_at_ms", "INTEGER", notNull = true),
            Column("updated_at_ms", "INTEGER", notNull = true)
        ),
        "service_lines" to listOf(
            id(),
            Column("visit_id", "INTEGER", notNull = true),
            Column("item_id", "INTEGER", notNull = true),
            Column("brand", "TEXT"),
            Column("product", "TEXT"),
            Column("parts_cost_minor", "INTEGER", notNull = true, defaultSql = "0"),
            Column("labor_cost_minor", "INTEGER", notNull = true, defaultSql = "0"),
            Column("note", "TEXT"),
            // Historical information only: never used by any calculation.
            Column("interval_km_at_service", "INTEGER"),
            Column("interval_months_at_service", "INTEGER")
        ),
        "odometer_anchors" to listOf(
            id(),
            Column("anchor_km", "INTEGER", notNull = true),
            Column("verified_at_ms", "INTEGER", notNull = true),
            Column("verified_time_trusted", "INTEGER", notNull = true, defaultSql = "0"),
            Column("estimated_km_at_verify", "INTEGER"),
            Column("source", "TEXT", notNull = true),
            Column("install_id", "TEXT", notNull = true),
            Column("trip_reset_generation", "INTEGER", notNull = true),
            Column("trip_epoch_id", "TEXT", notNull = true),
            Column("trip_total_distance_at_anchor_km", "REAL", notNull = true),
            Column("note", "TEXT")
        ),
        "calibration_runs" to listOf(
            id(),
            Column("created_at_ms", "INTEGER", notNull = true),
            Column("time_trusted", "INTEGER", notNull = true, defaultSql = "0"),
            Column("pump_liters", "REAL", notNull = true),
            Column("app_liters", "REAL", notNull = true),
            Column("app_distance_km", "REAL"),
            Column("vehicle_distance_km", "REAL"),
            Column("suggested_factor", "REAL", notNull = true),
            Column("applied_factor", "REAL", notNull = true),
            Column("note", "TEXT")
        )
    )

    /** New nullable columns added to the existing trip_records table. Written when a record closes. */
    val tripRecordColumns: List<Column> = listOf(
        Column("fuel_price_per_liter_minor", "INTEGER"),
        Column("calibration_factor", "REAL")
    )

    val foreignKeys: Map<String, Set<ForeignKey>> = linkedMapOf(
        "service_lines" to setOf(
            ForeignKey("visit_id", "service_visits", "id", "CASCADE"),
            ForeignKey("item_id", "maintenance_items", "id", "RESTRICT")
        )
    )

    val indexes: List<Index> = listOf(
        Index("idx_maintenance_items_category", "maintenance_items", listOf("category", "sort_order")),
        Index("idx_service_visits_date", "service_visits", listOf("visit_epoch_day", "id")),
        Index("idx_service_lines_visit", "service_lines", listOf("visit_id")),
        Index("idx_service_lines_item", "service_lines", listOf("item_id")),
        Index("idx_odometer_anchors_verified", "odometer_anchors", listOf("verified_at_ms", "id")),
        Index("idx_calibration_runs_created", "calibration_runs", listOf("created_at_ms", "id"))
    )

    /** Tables that user data lives in and that no "clear logs / clear drive data" action may touch. */
    val protectedTables: Set<String> = tables.keys

    fun createTableSql(table: String): String {
        val columns = tables.getValue(table)
        val parts = columns.map { column ->
            buildString {
                append(column.name).append(' ').append(column.type)
                if (column.primaryKey) append(" PRIMARY KEY AUTOINCREMENT")
                if (column.notNull) append(" NOT NULL")
                if (column.unique) append(" UNIQUE")
                column.defaultSql?.let { append(" DEFAULT ").append(it) }
            }
        } + foreignKeys[table].orEmpty().map {
            "FOREIGN KEY(${it.column}) REFERENCES ${it.refTable}(${it.refColumn}) ON DELETE ${it.onDelete}"
        }
        return "CREATE TABLE IF NOT EXISTS $table (\n    ${parts.joinToString(",\n    ")}\n)"
    }

    val createTableStatements: List<String> get() = tables.keys.map { createTableSql(it) }

    fun addTripRecordColumnSql(column: Column): String =
        "ALTER TABLE trip_records ADD COLUMN ${column.name} ${column.type}"

    val createIndexStatements: List<String>
        get() = indexes.map { "CREATE INDEX IF NOT EXISTS ${it.name} ON ${it.table}(${it.columns.joinToString(", ")})" }
}

/** Record counts of the user data that schema v7 introduced. */
data class MaintenanceCounts(val serviceVisits: Int, val calibrationRuns: Int, val odometerAnchors: Int)

/** The warning shown before a restore replaces the live data (a restore is all-or-nothing). */
object RestoreWarning {
    fun text(backup: MaintenanceCounts, current: MaintenanceCounts?, turkish: Boolean): String {
        val lines = mutableListOf<String>()
        lines += if (turkish) "Geri yükleme bu cihazdaki TÜM verileri yedektekiyle değiştirir."
        else "Restoring replaces ALL data on this device with the backup."
        lines += (if (turkish) "Yedekte: " else "In the backup: ") + describe(backup, turkish)
        if (current != null) {
            lines += (if (turkish) "Bu cihazda şimdi: " else "On this device now: ") + describe(current, turkish)
            if (current.serviceVisits > backup.serviceVisits ||
                current.calibrationRuns > backup.calibrationRuns ||
                current.odometerAnchors > backup.odometerAnchors
            ) {
                lines += if (turkish) {
                    "Dikkat: bu cihazda yedekte olmayan kayıtlar var; geri yükleyince kaybolur."
                } else {
                    "Warning: this device holds records that are not in the backup; they will be lost."
                }
            }
        }
        return lines.joinToString("\n")
    }

    private fun describe(counts: MaintenanceCounts, turkish: Boolean): String =
        if (turkish) {
            "${counts.serviceVisits} servis kaydı, ${counts.calibrationRuns} kalibrasyon ölçümü, ${counts.odometerAnchors} kilometre doğrulaması"
        } else {
            "${counts.serviceVisits} service visits, ${counts.calibrationRuns} calibration runs, ${counts.odometerAnchors} odometer verifications"
        }
}

