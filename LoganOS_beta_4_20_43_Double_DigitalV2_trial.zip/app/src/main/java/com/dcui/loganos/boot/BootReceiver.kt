package com.dcui.loganos.boot

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.bootLaunchEnabled

/** Single place to tune the boot-launch delay. First test value: 10 s. */
object BootLaunchConfig {
    const val LAUNCH_DELAY_MS = 10_000L
}

/**
 * Double Mode only: tries to bring LoganOS up after Android finished booting.
 *
 * Active only while ALL of these hold (see LoganSettings.bootLaunchEnabled()):
 *   deviceMode == HeadUnit, setupCompleted, !demoMode, bootAutoStartEnabled (user switch).
 * Turning the switch off disables this component AND cancels a pending delayed-launch alarm;
 * should a timer still be delivered, [onLaunchTimer] re-checks the settings and does nothing.
 *
 * Chain (each stage is logged separately, see [BootLaunchLog]):
 *   BOOT_COMPLETED received -> mode check -> timer scheduled (LAUNCH_DELAY_MS)
 *   -> timer fired -> mode re-check -> startActivity requested
 *   -> (in MainActivity) activity_created -> (in ObdController) auto-connect results.
 *
 * What this does NOT guarantee:
 *  - "receiver ran" is not "app is on screen". Android 10+ (API 29+) can silently block an
 *    Activity started from the background; startActivity() will not throw in that case.
 *    The proof that the app really opened is the later `stage=activity_created` line.
 *    If `start_request_returned` is logged but `activity_created` never follows, the start
 *    was blocked or ignored.
 *  - BOOT_COMPLETED is sent when Android boots. If the head unit only suspends/resumes on
 *    ACC (instead of a full power-off), this broadcast may NOT arrive. No wake-up mechanism
 *    for that case is added here because it is unverified on this device.
 *  - The component is disabled in the manifest and only enabled by [setEnabled] while Double
 *    Mode automation is on, so phones/Auto mode never receive the boot broadcast. The mode
 *    is checked again in onReceive as a second guard.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val app = context.applicationContext
        when (intent?.action) {
            Intent.ACTION_BOOT_COMPLETED -> onBootCompleted(app)
            ACTION_LAUNCH_DELAYED -> onLaunchTimer(app)
            else -> BootLaunchLog.log(app, "ignored", "action=${intent?.action}")
        }
    }

    private fun onBootCompleted(context: Context) {
        BootLaunchLog.log(context, "received", "action=BOOT_COMPLETED sdk=${Build.VERSION.SDK_INT}")
        val settings = loadSettings(context) ?: return
        if (!checkMode(context, settings)) return

        val delayMs = BootLaunchConfig.LAUNCH_DELAY_MS
        val scheduled = runCatching {
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.setAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + delayMs,
                timerIntent(context, PendingIntent.FLAG_UPDATE_CURRENT)
                    ?: error("PendingIntent unavailable")
            )
        }
        if (scheduled.isSuccess) {
            BootLaunchLog.log(context, "timer_scheduled", "delayMs=$delayMs")
        } else {
            val error = scheduled.exceptionOrNull()
            BootLaunchLog.log(
                context, "timer_failed",
                "${error?.javaClass?.simpleName}: ${error?.message}; launching without delay"
            )
            requestLaunch(context)
        }
    }

    private fun onLaunchTimer(context: Context) {
        BootLaunchLog.log(context, "timer_fired")
        val settings = loadSettings(context) ?: return
        if (!checkMode(context, settings)) return
        requestLaunch(context)
    }

    private fun loadSettings(context: Context): LoganSettings? {
        return runCatching { AppPrefs(context).load() }
            .onFailure {
                BootLaunchLog.log(context, "mode_check", "result=error ${it.javaClass.simpleName}: ${it.message}")
            }
            .getOrNull()
    }

    private fun checkMode(context: Context, settings: LoganSettings): Boolean {
        val enabled = settings.bootLaunchEnabled()
        val reason = when {
            settings.deviceMode != DeviceMode.HeadUnit -> "deviceMode is not HeadUnit"
            !settings.setupCompleted -> "setup not completed"
            settings.demoMode -> "demo mode on"
            !settings.bootAutoStartEnabled -> "boot auto start switch off"
            else -> "all conditions met"
        }
        BootLaunchLog.log(
            context, "mode_check",
            "deviceMode=${settings.deviceMode} setupCompleted=${settings.setupCompleted} " +
                "demoMode=${settings.demoMode} bootAutoStart=${settings.bootAutoStartEnabled} " +
                "result=${if (enabled) "run" else "skip"} reason=\"$reason\""
        )
        return enabled
    }

    private fun requestLaunch(context: Context) {
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            ?: Intent(context, com.dcui.loganos.MainActivity::class.java)
        // Same behaviour as tapping the launcher icon: resumes an existing task instead of
        // stacking a second MainActivity.
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launch.putExtra(EXTRA_BOOT_LAUNCH, true)
        BootLaunchLog.log(context, "start_requested", "sdk=${Build.VERSION.SDK_INT}")
        try {
            context.startActivity(launch)
            BootLaunchLog.log(
                context, "start_request_returned",
                "no exception (NOT proof the app is visible; wait for stage=activity_created)"
            )
        } catch (t: Throwable) {
            BootLaunchLog.log(context, "start_failed", "${t.javaClass.simpleName}: ${t.message}")
        }
    }

    companion object {
        const val ACTION_LAUNCH_DELAYED = "com.dcui.loganos.action.BOOT_LAUNCH_DELAYED"
        const val EXTRA_BOOT_LAUNCH = "com.dcui.loganos.extra.BOOT_LAUNCH"
        private const val TIMER_REQUEST_CODE = 4620

        /**
         * The ONE place that builds the delayed-launch PendingIntent. Scheduling and cancelling
         * both go through it, so requestCode, action and component are identical and the
         * cancel really hits the scheduled alarm. Only the (masked) create/no-create flag differs.
         */
        private fun timerIntent(context: Context, createFlag: Int): PendingIntent? {
            val intent = Intent(context, BootReceiver::class.java).setAction(ACTION_LAUNCH_DELAYED)
            return PendingIntent.getBroadcast(
                context, TIMER_REQUEST_CODE, intent,
                createFlag or PendingIntent.FLAG_IMMUTABLE
            )
        }

        /** Cancels a scheduled delayed launch. Returns true if one was pending. */
        private fun cancelPendingLaunch(context: Context): Boolean {
            val pending = timerIntent(context, PendingIntent.FLAG_NO_CREATE) ?: return false
            runCatching {
                (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
            }
            pending.cancel()
            return true
        }

        /**
         * Enables the receiver only while [LoganSettings.bootLaunchEnabled] is true. The manifest
         * ships it disabled, so on a phone, in Auto mode, or with the user switch off the boot
         * broadcast is never delivered. Disabling also cancels a pending delayed-launch alarm.
         */
        fun setEnabled(context: Context, enabled: Boolean) {
            val app = context.applicationContext
            val pm = app.packageManager
            val component = ComponentName(app, BootReceiver::class.java)
            if (!enabled && cancelPendingLaunch(app)) {
                BootLaunchLog.log(app, "timer_cancelled", "pending delayed launch alarm removed")
            }
            val current = pm.getComponentEnabledSetting(component)
            val currentlyEnabled = current == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
            if (currentlyEnabled == enabled) return
            runCatching {
                pm.setComponentEnabledSetting(
                    component,
                    if (enabled) PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                    else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
                BootLaunchLog.log(app, "receiver_state", "enabled=$enabled")
            }.onFailure {
                BootLaunchLog.log(app, "receiver_state", "enabled=$enabled failed ${it.javaClass.simpleName}: ${it.message}")
            }
        }
    }
}
