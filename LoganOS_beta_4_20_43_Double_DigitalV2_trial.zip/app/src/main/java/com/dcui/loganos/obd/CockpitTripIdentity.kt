package com.dcui.loganos.obd

import android.content.Context
import android.content.SharedPreferences
import java.util.UUID

/**
 * Identifies "this device's persistent trip totals" so a stored value that depends on them (for
 * example an odometer anchor) can tell when the totals it was based on no longer exist.
 *
 *  - [installId]: random id of this installation, kept in its own preferences file that is NOT
 *    part of any backup. A backup restored on another device or install carries a different id.
 *  - [epochId]: random id of the totals file's lifetime. A new one is generated when the file is
 *    missing, unreadable or had to be repaired.
 *  - [resetGeneration]: starts at 1 and only ever grows; bumped on every explicit reset.
 */
data class CockpitTripIdentity(
    val installId: String,
    val epochId: String,
    val resetGeneration: Long
)

/** Pure rules for loading the epoch id and reset generation. */
object CockpitTripIdentityResolver {
    data class Resolved(val epochId: String, val resetGeneration: Long, val changeReason: String?)

    fun resolve(
        storedEpochId: String?,
        storedGeneration: Long?,
        stateWasSanitized: Boolean,
        newEpochId: () -> String
    ): Resolved {
        val epoch = storedEpochId?.takeIf { it.isNotBlank() }
        val generation = storedGeneration?.takeIf { it >= 1L }
        return when {
            epoch == null && generation == null -> Resolved(newEpochId(), 1L, "new_identity")
            epoch == null -> Resolved(newEpochId(), generation!! + 1L, "missing_epoch")
            generation == null -> Resolved(epoch, 1L, "missing_generation")
            stateWasSanitized -> Resolved(newEpochId(), generation + 1L, "totals_repaired")
            else -> Resolved(epoch, generation, null)
        }
    }
}

/** Random id of this installation, stored apart from every backed-up setting. */
object InstallIdentity {
    const val PREFS_NAME = "loganos_install_identity"
    private const val KEY_INSTALL_ID = "install_id"

    fun get(context: Context): String = get(
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    ) { UUID.randomUUID().toString() }

    @Synchronized
    fun get(prefs: SharedPreferences, newId: () -> String): String {
        val existing = prefs.getString(KEY_INSTALL_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val created = newId()
        prefs.edit().putString(KEY_INSTALL_ID, created).commit()
        return created
    }
}
