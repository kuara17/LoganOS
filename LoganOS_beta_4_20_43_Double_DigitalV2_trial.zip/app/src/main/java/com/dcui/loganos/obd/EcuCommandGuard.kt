package com.dcui.loganos.obd

import java.util.Locale

/** Thrown by the command choke point when something outside the approved read set is attempted. */
class EcuCommandBlockedException(val command: String, val reason: String) :
    IllegalStateException("ECU command blocked: $reason")

/**
 * Pure policy for everything LoganOS may write to the OBD adapter / ECU.
 *
 * LoganOS is a READ-ONLY dashboard. The approved set below was taken from an inventory of every
 * command the app really sends (4.20.38):
 *   - ELM327 AT configuration commands (ATZ, ATE0, ATL0, ATS1, ATH1, ATSP0/5, ATIIAxx, ATWM..,
 *     ATSH.., ATFI, ATRV). Adapter-persistent or link-breaking families (ATPP, ATBRD, ATBRT)
 *     are NOT approved.
 *   - 01xx   OBD-II "show current data" (read)
 *   - 1Axx   KWP readECUIdentification (read)
 *   - 21xx   KWP readDataByLocalIdentifier (read)
 *   - 10C0   KWP startDiagnosticSession with the one sub-function the Delphi DCM1.2 init uses.
 *            Opening a diagnostic session is required before reads; any other 10xx is refused.
 * Everything else (clear DTC, ECU reset, security access, write, IO control, routine control,
 * transfer, programming...) is refused, so an experimental feature cannot silently write to the car.
 */
object EcuCommandGuard {

    enum class Kind { EMPTY, ELM_AT, OBD_CURRENT_DATA, KWP_READ_IDENTIFICATION, KWP_READ_LOCAL_ID, KWP_SESSION_START }

    sealed class Decision {
        data class Allowed(val kind: Kind) : Decision()
        data class Blocked(val reason: String) : Decision()
    }

    private val BLOCKED_AT_PREFIXES = listOf("PP", "BRD", "BRT")
    private val HEX = Regex("^[0-9A-F]+$")

    fun check(rawCommand: String): Decision {
        val command = rawCommand.trim().uppercase(Locale.ROOT).replace(" ", "")
        if (command.isEmpty()) return Decision.Allowed(Kind.EMPTY)

        if (command.startsWith("AT")) {
            val rest = command.removePrefix("AT")
            val blocked = BLOCKED_AT_PREFIXES.firstOrNull { rest.startsWith(it) }
            return if (blocked != null) {
                Decision.Blocked("AT$blocked changes adapter configuration or link speed")
            } else {
                Decision.Allowed(Kind.ELM_AT)
            }
        }

        if (!HEX.matches(command) || command.length % 2 != 0) {
            return Decision.Blocked("not a valid hex request")
        }
        if (command == "10C0") return Decision.Allowed(Kind.KWP_SESSION_START)
        if (command.length == 4) {
            when (command.substring(0, 2)) {
                "01" -> return Decision.Allowed(Kind.OBD_CURRENT_DATA)
                "1A" -> return Decision.Allowed(Kind.KWP_READ_IDENTIFICATION)
                "21" -> return Decision.Allowed(Kind.KWP_READ_LOCAL_ID)
            }
        }
        val service = command.substring(0, 2)
        return Decision.Blocked("service 0x$service (${describe(service)}) is not an approved read request")
    }

    private fun describe(service: String): String = when (service) {
        "04" -> "clear DTC (OBD-II)"
        "08" -> "control on-board system"
        "10" -> "diagnostic session other than the approved 10C0"
        "11" -> "ECU reset"
        "14" -> "clear diagnostic information"
        "27" -> "security access"
        "2E" -> "write data by identifier"
        "2F" -> "input/output control"
        "31" -> "routine control"
        "34", "35", "36", "37" -> "data transfer / programming"
        "3B" -> "write data by local identifier"
        "3D" -> "write memory by address"
        else -> "unknown"
    }
}
