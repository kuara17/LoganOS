package com.dcui.loganos.obd

/**
 * Pure presentation maths that used to live inside MainActivity.enrichTrip.
 * Extracted so it can be unit tested. Plain values only (no Android types).
 */
data class TripPresentationSettings(
    val fuelCalibrationEnabled: Boolean,
    val fuelCalibrationFactor: Double,
    val avgResetDistanceKm: Double,
    val avgResetFuelLiters: Double,
    val costResetFuelLiters: Double,
    val fuelPriceText: String,
    val odometerText: String
)

data class TripPresentationInput(
    val averageConsumption: Double?,
    val instantConsumption: Double?,
    val fuelUsedL: Double?,
    val tripDistanceKm: Double?,
    val tripCostText: String?,
    val odometerKm: Int?
)

data class TripPresentationResult(
    val averageConsumption: Double?,
    val instantConsumption: Double?,
    val fuelUsedL: Double?,
    val tripCostText: String?,
    val odometerKm: Int?
)

fun computeTripPresentation(
    settings: TripPresentationSettings,
    input: TripPresentationInput,
    cockpitTotals: PersistentCockpitTripState
): TripPresentationResult {
    val calibrationFactor = if (settings.fuelCalibrationEnabled) {
        settings.fuelCalibrationFactor.coerceIn(0.50, 1.50)
    } else {
        1.0
    }
    val calibratedAverage = if (calibrationFactor != 1.0) input.averageConsumption?.times(calibrationFactor) else input.averageConsumption
    val calibratedInstant = if (calibrationFactor != 1.0) input.instantConsumption?.times(calibrationFactor) else input.instantConsumption
    val fuel = if (calibrationFactor != 1.0) input.fuelUsedL?.times(calibrationFactor) else input.fuelUsedL
    val distance = input.tripDistanceKm

    // Average consumption is the one cockpit metric that intentionally survives
    // ignition/history boundaries. Its reset baseline is stored against the persistent
    // fuel/distance accumulator, not the active TripComputer segment.
    val hasAverageBaseline = settings.avgResetDistanceKm > 0.0 || settings.avgResetFuelLiters > 0.0
    val averageBaselineValid = cockpitTotals.totalDistanceKm >= settings.avgResetDistanceKm &&
        cockpitTotals.totalFuelLiters + 0.000001 >= settings.avgResetFuelLiters
    val avgBaseDistance = if (hasAverageBaseline && averageBaselineValid) settings.avgResetDistanceKm else 0.0
    val avgBaseFuel = if (hasAverageBaseline && averageBaselineValid) settings.avgResetFuelLiters else 0.0
    val avgDistance = (cockpitTotals.totalDistanceKm - avgBaseDistance).coerceAtLeast(0.0)
    val avgFuel = (cockpitTotals.totalFuelLiters - avgBaseFuel).coerceAtLeast(0.0)
    // The persistent totals are RAW (uncalibrated), so the calibration factor is applied here,
    // in both branches, to keep average, used fuel and cost consistent with each other.
    val resetAverage = if (avgDistance >= TripAverageRules.MIN_DISTANCE_KM) {
        (avgFuel / avgDistance.coerceAtLeast(0.0001)) * 100.0 * calibrationFactor
    } else {
        calibratedAverage ?: cockpitTotals.averageL100?.times(calibrationFactor)
    }

    val price = settings.fuelPriceText.replace(',', '.').toDoubleOrNull()
    val hasCostBaseline = settings.costResetFuelLiters > 0.0
    val costBaselineValid = fuel != null && settings.costResetFuelLiters in 0.0..fuel
    val costBaseFuel = if (hasCostBaseline && costBaselineValid) settings.costResetFuelLiters else 0.0
    val costFuel = fuel?.minus(costBaseFuel)?.coerceAtLeast(0.0)
    val cost = if (price != null && price > 0.0 && costFuel != null) {
        String.format(java.util.Locale.US, "%.2f \u20BA", costFuel * price)
    } else input.tripCostText
    val baseOdo = settings.odometerText.toIntOrNull()
    val odo = if (baseOdo != null && distance != null) {
        baseOdo + distance.toInt()
    } else input.odometerKm
    return TripPresentationResult(
        averageConsumption = resetAverage,
        instantConsumption = calibratedInstant,
        fuelUsedL = fuel,
        tripCostText = cost,
        odometerKm = odo
    )
}
