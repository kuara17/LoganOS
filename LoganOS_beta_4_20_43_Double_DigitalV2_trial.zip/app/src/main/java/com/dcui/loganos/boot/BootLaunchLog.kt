package com.dcui.loganos.boot

import android.content.Context
import android.os.SystemClock
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Small persistent diagnostic log for the Double Mode auto-launch chain.
 *
 * Why persistent: the receiver may run in a fresh process right after the head unit boots,
 * and the in-memory OBD log is lost when that process dies. Lines are kept in a tiny
 * SharedPreferences ring (last [MAX_LINES]) and are merged into the in-app log the next
 * time MainActivity starts ([takeUnimported]).
 *
 * Every line carries `up=` (seconds since device boot, from elapsedRealtime). The wall clock
 * of a head unit can be wrong right after boot, so `up=` is the reliable ordering/timing hint.
 *
 * Stages written by the chain (grep for "[BOOT_LAUNCH]"):
 *   receiver_state, received, mode_check, timer_scheduled, timer_fired,
 *   start_requested, start_request_returned / start_failed,
 *   activity_created, obd (auto-connect supervisor results).
 */
object BootLaunchLog {
    private const val TAG = "LoganOS"
    private const val PREFS = "loganos_boot_launch"
    private const val KEY_LINES = "lines"
    private const val KEY_SEQ = "seq"
    private const val KEY_IMPORTED_SEQ = "imported_seq"
    private const val MAX_LINES = 80
    private val MAC_PATTERN = Regex("(?i)\\b([0-9a-f]{2}[:-]){5}[0-9a-f]{2}\\b")

    /** Writes "[BOOT_LAUNCH] stage=<stage> <details>" to logcat and to the persistent ring. */
    @Synchronized
    fun log(context: Context, stage: String, details: String = "") {
        // Never persist a Bluetooth MAC address, even if one slips into an exception message.
        val message = ("[BOOT_LAUNCH] stage=$stage" + if (details.isBlank()) "" else " $details")
            .replace(MAC_PATTERN, "XX:XX:XX:XX:XX:XX")
        Log.i(TAG, message)
        runCatching {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val seq = prefs.getLong(KEY_SEQ, 0L) + 1L
            val upSec = SystemClock.elapsedRealtime() / 1000L
            val wall = SimpleDateFormat("MM-dd HH:mm:ss", Locale.US).format(Date())
            val line = "#$seq up=${upSec}s wall=$wall $message"
            val lines = (prefs.getString(KEY_LINES, "").orEmpty().split('\n').filter { it.isNotBlank() } + line)
                .takeLast(MAX_LINES)
            prefs.edit()
                .putString(KEY_LINES, lines.joinToString("\n"))
                .putLong(KEY_SEQ, seq)
                .commit()
        }.onFailure { Log.w(TAG, "[BOOT_LAUNCH] log persist failed: ${it.javaClass.simpleName}: ${it.message}") }
    }

    /** Returns lines not yet merged into the in-app log, and marks them as merged. */
    @Synchronized
    fun takeUnimported(context: Context): List<String> {
        return runCatching {
            val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val imported = prefs.getLong(KEY_IMPORTED_SEQ, 0L)
            val all = prefs.getString(KEY_LINES, "").orEmpty().split('\n').filter { it.isNotBlank() }
            val fresh = all.filter { line ->
                val seq = line.removePrefix("#").substringBefore(' ').toLongOrNull() ?: return@filter false
                seq > imported
            }
            val newest = fresh.lastOrNull()?.removePrefix("#")?.substringBefore(' ')?.toLongOrNull()
            if (newest != null) prefs.edit().putLong(KEY_IMPORTED_SEQ, newest).apply()
            fresh
        }.getOrDefault(emptyList())
    }
}
