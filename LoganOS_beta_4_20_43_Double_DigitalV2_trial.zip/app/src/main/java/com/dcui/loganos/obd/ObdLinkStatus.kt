package com.dcui.loganos.obd

/**
 * What the OBD link really is, derived from the existing state fields (nothing removed).
 *
 * The raw `ObdState.connected` flag becomes true as soon as the Bluetooth socket opens, long
 * before the ELM adapter and the ECU have answered, so it must not be read as "OBD connected".
 * "OBD connected" is only [DATA_FLOWING]: the connection guard rates the link STABLE and the
 * poll loop produced a snapshot.
 */
enum class ObdLinkLevel {
    /** No socket, nothing in progress. */
    DISCONNECTED,

    /** Opening the socket / running the adapter init. */
    CONNECTING,

    /** A reconnect attempt is in progress. */
    RECONNECTING,

    /** Socket is open but no valid ECU data has arrived yet (ignition off, ECU asleep, init). */
    ADAPTER_WAITING_ECU,

    /** Ignition is off; the app is waiting for the engine. */
    IGNITION_OFF,

    /** Socket open, data stopped arriving. */
    DATA_STALE,

    /** Socket open, data arriving but unreliable. */
    UNSTABLE,

    /** Socket open and valid ECU data is flowing. The only state that may be shown as "OBD connected". */
    DATA_FLOWING;

    /** True when the Bluetooth link exists and the app is (or was just) receiving ECU data. */
    val linkPresent: Boolean
        get() = this == DATA_FLOWING || this == DATA_STALE || this == UNSTABLE || this == IGNITION_OFF

    /** True only when "OBD connected" may be displayed. */
    val showsObdConnected: Boolean
        get() = this == DATA_FLOWING
}

object ObdLinkStatus {
    fun derive(
        socketOpen: Boolean,
        connecting: Boolean,
        health: ObdConnectionHealth,
        healthReason: String?,
        snapshotHasData: Boolean
    ): ObdLinkLevel {
        if (connecting) return ObdLinkLevel.CONNECTING
        if (!socketOpen) {
            return if (health == ObdConnectionHealth.RECONNECTING) ObdLinkLevel.RECONNECTING else ObdLinkLevel.DISCONNECTED
        }
        if (healthReason?.contains("Kontak kapal", ignoreCase = true) == true) return ObdLinkLevel.IGNITION_OFF
        return when (health) {
            ObdConnectionHealth.DATA_STALE -> ObdLinkLevel.DATA_STALE
            ObdConnectionHealth.UNSTABLE -> ObdLinkLevel.UNSTABLE
            ObdConnectionHealth.RECONNECTING -> ObdLinkLevel.RECONNECTING
            ObdConnectionHealth.STABLE ->
                if (snapshotHasData) ObdLinkLevel.DATA_FLOWING else ObdLinkLevel.ADAPTER_WAITING_ECU
            ObdConnectionHealth.CONNECTING, ObdConnectionHealth.DISCONNECTED -> ObdLinkLevel.ADAPTER_WAITING_ECU
        }
    }
}

/** Short wording for settings/status lines: only an adapter with no ECU data is called out. */
fun ObdLinkLevel.settingsLabel(turkish: Boolean): String = when {
    linkPresent -> if (turkish) "Bağlı" else "Connected"
    this == ObdLinkLevel.ADAPTER_WAITING_ECU ->
        if (turkish) "Adaptör bağlı, ECU bekleniyor" else "Adapter connected, waiting for ECU"
    else -> if (turkish) "Bağlı değil" else "Disconnected"
}

