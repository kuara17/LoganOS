package com.dcui.loganos

import android.Manifest
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.graphics.toArgb
import com.dcui.loganos.boot.BootLaunchLog
import kotlin.coroutines.resume
import com.dcui.loganos.data.RestoreWarning
import com.dcui.loganos.boot.BootReceiver
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.data.DataBackupManager
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.MenuTheme
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.bootLaunchEnabled
import com.dcui.loganos.obd.TripPresentationInput
import com.dcui.loganos.obd.TripPresentationSettings
import com.dcui.loganos.obd.computeTripPresentation
import com.dcui.loganos.runtime.LoganRuntime
import com.dcui.loganos.ui.screens.LoganAppShell
import com.dcui.loganos.ui.screens.SetupWizard
import com.dcui.loganos.ui.screens.SplashScreen
import com.dcui.loganos.ui.theme.LoganOSTheme
import com.dcui.loganos.update.SecureUpdateManager
import com.dcui.loganos.update.UpdateUiState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    /** Plain system dialog that suspends until the user decides. Dismissing it counts as "cancel". */
    private suspend fun confirmRestore(title: String, message: String, positive: String, negative: String): Boolean =
        kotlinx.coroutines.suspendCancellableCoroutine { continuation ->
            val dialog = android.app.AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(positive) { _, _ -> if (continuation.isActive) continuation.resume(true) }
                .setNegativeButton(negative) { _, _ -> if (continuation.isActive) continuation.resume(false) }
                .setOnCancelListener { if (continuation.isActive) continuation.resume(false) }
                .create()
            continuation.invokeOnCancellation { runCatching { dialog.dismiss() } }
            dialog.show()
        }

    override fun onStart() {
        super.onStart()
        // The Double Mode supervisor stops by design when its budget is spent or the ignition-off
        // window expired. Coming back to the foreground starts a fresh bounded session. Policy
        // (HeadUnit + setup done + not demo) is checked inside; phones and Auto mode do nothing.
        runCatching {
            val settings = prefs.load()
            val controller = LoganRuntime.obdController(applicationContext)
            controller.setRuntimeSettings(settings)
            controller.requestHeadUnitAutoConnect(settings, "on_start")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = AppPrefs(this)
        BootLaunchLog.log(
            this, "activity_created",
            "fromBoot=${intent?.getBooleanExtra(BootReceiver.EXTRA_BOOT_LAUNCH, false) == true} " +
                "recreated=${savedInstanceState != null}"
        )
        requestBluetoothPermissions()

        setContent {
            var settings by remember {
                val loaded = prefs.load()
                var normalized = if (loaded.gpsRouteEnabled && !loaded.driveHistoryEnabled) {
                    loaded.copy(gpsRouteEnabled = false)
                } else loaded
                // Demo mode is a workshop/test session, never a persistent vehicle mode.
                // Older builds could leave it enabled across a head-unit restart.
                if (normalized.demoMode) normalized = normalized.copy(demoMode = false)
                if (normalized != loaded) prefs.save(normalized)
                mutableStateOf(normalized)
            }
            var showSplash by remember { mutableStateOf(true) }
            var demoTick by remember { mutableIntStateOf(0) }
            val obdController = remember { LoganRuntime.obdController(applicationContext) }
            val updateManager = remember { SecureUpdateManager(applicationContext) }
            val dataBackupManager = remember { DataBackupManager(applicationContext) }
            val uiScope = rememberCoroutineScope()

            val bluetoothPermissions = remember {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN)
                } else {
                    emptyArray()
                }
            }
            val bluetoothPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) {
                if (obdController.hasBluetoothPermission()) {
                    obdController.refreshPairedDevices()
                    Toast.makeText(this@MainActivity, "Eşleşmiş Bluetooth cihazları yenilendi", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Bluetooth / Yakındaki cihazlar izni verilmeden OBD cihaz listesi açılamaz",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            fun refreshObdDevicesWithPermission() {
                if (obdController.hasBluetoothPermission()) {
                    obdController.refreshPairedDevices()
                } else if (bluetoothPermissions.isNotEmpty()) {
                    bluetoothPermissionLauncher.launch(bluetoothPermissions)
                } else {
                    obdController.refreshPairedDevices()
                }
            }

            val gpsPermissionLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { result ->
                val fineGranted = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                    ActivityCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                if (fineGranted) {
                    val updated = settings.copy(
                        gpsRouteEnabled = true,
                        driveHistoryEnabled = true
                    )
                    settings = updated
                    prefs.save(updated)
                    Toast.makeText(
                        this@MainActivity,
                        "GPS rota kaydı açıldı. Konum izni yalnız rota özelliği için kullanılır.",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    val updated = settings.copy(gpsRouteEnabled = false)
                    settings = updated
                    prefs.save(updated)
                    Toast.makeText(
                        this@MainActivity,
                        "Konum izni verilmedi. LoganOS normal çalışmaya devam edecek; yalnız GPS rota kaydı kapalı kalacak.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }

            val createBackupLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.CreateDocument("application/zip")
            ) { uri ->
                if (uri != null) {
                    uiScope.launch {
                        val result = withContext(Dispatchers.IO) {
                            val databaseFile = obdController.createDatabaseBackupSnapshot()
                                ?: return@withContext DataBackupManager.Result(false, "Önce OBD bağlantısını kesin ve aktif işlemlerin bitmesini bekleyin")
                            try {
                                dataBackupManager.writeBackup(uri, prefs.exportBackupJson(), databaseFile)
                            } finally {
                                databaseFile.delete()
                                java.io.File(databaseFile.absolutePath + "-wal").delete()
                                java.io.File(databaseFile.absolutePath + "-shm").delete()
                                java.io.File(databaseFile.absolutePath + "-journal").delete()
                            }
                        }
                        Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
                    }
                }
            }

            val restoreBackupLauncher = rememberLauncherForActivityResult(
                ActivityResultContracts.OpenDocument()
            ) { uri ->
                if (uri != null) {
                    uiScope.launch {
                        if (!obdController.canCreateOrRestoreDataBackup()) {
                            Toast.makeText(this@MainActivity, "Önce OBD bağlantısını kesin ve aktif işlemlerin bitmesini bekleyin", Toast.LENGTH_LONG).show()
                            return@launch
                        }
                        // Tell the user what a restore would replace BEFORE anything is touched.
                        val inspection = withContext(Dispatchers.IO) { dataBackupManager.inspectBackup(uri) }
                        val backupInfo = inspection.inspection
                        if (backupInfo == null) {
                            Toast.makeText(this@MainActivity, "Yedek okunamadı: ${inspection.message}", Toast.LENGTH_LONG).show()
                            return@launch
                        }
                        val currentCounts = withContext(Dispatchers.IO) { runCatching { obdController.maintenanceCounts() }.getOrNull() }
                        val turkish = settings.language != AppLanguage.English
                        val confirmed = confirmRestore(
                            title = if (turkish) "Yedeği geri yükle" else "Restore backup",
                            message = RestoreWarning.text(backupInfo.counts, currentCounts, turkish),
                            positive = if (turkish) "Geri yükle" else "Restore",
                            negative = if (turkish) "Vazgeç" else "Cancel"
                        )
                        if (!confirmed) return@launch
                        // Restore replaces the SQLite file, therefore the open helper must
                        // be fully released first. The activity is recreated afterwards on
                        // both success and failure so a fresh controller/database handle is used.
                        LoganRuntime.releaseObdController()
                        val result = withContext(Dispatchers.IO) { dataBackupManager.restoreBackup(uri, prefs) }
                        Toast.makeText(this@MainActivity, result.message, Toast.LENGTH_LONG).show()
                        delay(500L)
                        this@MainActivity.recreate()
                    }
                }
            }
            val obdState = obdController.state
            val systemDark = isSystemInDarkTheme()
            val dark = when (settings.menuTheme) {
                MenuTheme.Dark -> true
                MenuTheme.System -> systemDark
                else -> false
            }

            LaunchedEffect(obdState.exportFeedbackNonce) {
                if (obdState.exportFeedbackNonce > 0L) {
                    obdState.exportFeedbackMessage?.let { message ->
                        Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                    }
                }
            }
            val configuration = LocalConfiguration.current

            fun persist(requested: LoganSettings) {
                var updated = requested
                val enablingGps = !settings.gpsRouteEnabled && updated.gpsRouteEnabled
                if (enablingGps && !updated.driveHistoryEnabled) {
                    // GPS routes belong to completed drive-history records. Enabling
                    // route recording therefore also enables automatic drive history.
                    updated = updated.copy(driveHistoryEnabled = true)
                }
                if (!updated.driveHistoryEnabled && updated.gpsRouteEnabled) {
                    // Prevent route points from being recorded into sessions that can
                    // never become a completed drive-history record.
                    updated = updated.copy(gpsRouteEnabled = false)
                }
                if (enablingGps) {
                    val fineGranted = ActivityCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (!fineGranted) {
                        gpsPermissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            )
                        )
                        return
                    }
                }
                val bootSwitchChanged = updated.bootAutoStartEnabled != settings.bootAutoStartEnabled
                settings = updated
                prefs.save(updated)
                if (bootSwitchChanged) {
                    BootLaunchLog.log(
                        this@MainActivity, "setting_changed",
                        "bootAutoStartEnabled=${updated.bootAutoStartEnabled}"
                    )
                }
                // Apply right away (also covers mode/demo/setup changes): enables or disables the
                // receiver and cancels a pending delayed launch. Idempotent.
                BootReceiver.setEnabled(applicationContext, updated.bootLaunchEnabled())
            }


            LaunchedEffect(Unit) {
                // Yeni sürüm ilk kez açıldığında önceki OTA kurulum dosyalarını
                // cache'ten temizle. Aynı sürüm yeniden açılırsa bekleyen APK korunur.
                withContext(Dispatchers.IO) {
                    updateManager.cleanupStaleUpdateFilesAfterVersionChange()
                }

                // Açılışta en fazla günde bir kez sessiz sürüm kontrolü. Güncelleme
                // varsa yalnızca bilgi verilir; indirme/kurulum kullanıcı eylemi ister.
                delay(5000L)
                if (updateManager.shouldAutoCheck()) {
                    when (val result = updateManager.checkForUpdate()) {
                        is UpdateUiState.Available -> Toast.makeText(
                            this@MainActivity,
                            "Yeni LoganOS sürümü mevcut: ${result.release.versionName} • Ayarlar > Güncellemeler",
                            Toast.LENGTH_LONG
                        ).show()
                        else -> Unit
                    }
                }
            }

            LaunchedEffect(Unit) {
                // Double head units may receive the real date/time from GPS a
                // few seconds after boot. Keep the UI state in sync even before
                // an OBD polling loop starts.
                while (true) {
                    obdController.refreshTrustedTimeState()
                    delay(1000L)
                }
            }

            LaunchedEffect(settings.rawEcuLogEnabled, settings.developerModeEnabled) {
                // Normal kullanımda kayıt sistemi otomatik/akıllı özet modundadır.
                // Geliştirici modu açıldığında testler için tam frekanslı özet kayıt tutulur.
                val rawLogEnabled = settings.developerModeEnabled && settings.rawEcuLogEnabled
                val smartSummaryLog = !settings.developerModeEnabled
                obdController.setLoggingOptions(rawLogEnabled, smartSummaryLog)
            }

            LaunchedEffect(settings) {
                // Smart Trip kararı ve export metadata'sı güncel ayarlardan beslensin.
                obdController.setRuntimeSettings(settings)
            }

            LaunchedEffect(Unit) {
                // Merge boot-launch lines written by the receiver (possibly in an earlier process)
                // into the in-app log so the whole chain can be read in one place.
                BootLaunchLog.takeUnimported(applicationContext).forEach { obdController.appendExternalLog(it) }
            }

            LaunchedEffect(settings.deviceMode, settings.setupCompleted, settings.demoMode, settings.bootAutoStartEnabled) {
                // Sync PackageManager state with the persisted settings on every start and change
                // (covers backup restore, app update, and anything that bypassed persist()).
                BootReceiver.setEnabled(applicationContext, settings.bootLaunchEnabled())
                // Double Mode only: explicit DeviceMode.HeadUnit (Auto is not HeadUnit).
                // Phone mode: this call only cancels/ignores, manual connect is unchanged.
                // Declared after setRuntimeSettings(settings) so runtime settings are current.
                obdController.requestHeadUnitAutoConnect(settings, "activity_start")
            }

            LaunchedEffect(settings.backgroundTripEnabled, settings.gpsRouteEnabled, obdState.connected) {
                if ((settings.backgroundTripEnabled || settings.gpsRouteEnabled) && obdState.connected) {
                    requestNotificationPermissionIfNeeded()
                }
            }

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(
                settings.deviceMode,
                settings.gaugeStyle,
                settings.setupCompleted,
                configuration.smallestScreenWidthDp,
                configuration.uiMode
            ) {
                val uiModeType = configuration.uiMode and Configuration.UI_MODE_TYPE_MASK
                val autoHeadUnit = uiModeType == Configuration.UI_MODE_TYPE_CAR || configuration.smallestScreenWidthDp >= 600
                val resolvedMode = when (settings.deviceMode) {
                    DeviceMode.Auto -> if (autoHeadUnit) DeviceMode.HeadUnit else DeviceMode.Phone
                    else -> settings.deviceMode
                }
                // Ghost Single now IS the baked former Ghost Single Original design.
                // Both Ghost Single and Ghost Dual are landscape-only on phones.
                val phoneGhostLandscapeOnly = settings.setupCompleted &&
                    resolvedMode == DeviceMode.Phone &&
                    (settings.gaugeStyle == GaugeStyle.GhostSingle || settings.gaugeStyle == GaugeStyle.GhostDual || settings.gaugeStyle == GaugeStyle.GhostSingleOriginal || settings.gaugeStyle == GaugeStyle.GhostDualOriginal)
                requestedOrientation = when {
                    settings.setupCompleted && resolvedMode == DeviceMode.HeadUnit ->
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    phoneGhostLandscapeOnly ->
                        ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                    else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            LaunchedEffect(showSplash) {
                if (showSplash) {
                    // Splash için maksimum bekleme/fallback. Reset akışında showSplash false'a alınır.
                    delay(1700)
                    showSplash = false
                }
            }

            LaunchedEffect(settings.demoMode) {
                while (settings.demoMode) {
                    delay(800)
                    demoTick++
                }
            }

            fun enrichTrip(snapshot: DashboardSnapshot): DashboardSnapshot {
                // Deneysel benzinli profilde temel OBD verileri gösterilir; doğrulanmış
                // enjeksiyon/fuel-rate kaynağı bulunana kadar tüketim ve maliyet üretilmez.
                if (!settings.fuelCalculationSupported) {
                    val distance = snapshot.tripDistanceKm
                    val baseOdo = settings.odometerText.toIntOrNull()
                    val odo = if (baseOdo != null && distance != null) {
                        baseOdo + distance.toInt()
                    } else snapshot.odometerKm
                    return snapshot.copy(
                        averageConsumption = null,
                        instantConsumption = null,
                        instantUnit = "",
                        fuelUsedL = null,
                        tripCostText = null,
                        odometerKm = odo,
                        fuelSource = if (settings.fuelType == FuelType.Petrol) "PETROL_UNVERIFIED" else "PROFILE_UNVERIFIED"
                    )
                }

                // The maths lives in computeTripPresentation() (unit tested); this only maps it back.
                val presentation = computeTripPresentation(
                    TripPresentationSettings(
                        fuelCalibrationEnabled = settings.fuelCalibrationEnabled,
                        fuelCalibrationFactor = settings.fuelCalibrationFactor,
                        avgResetDistanceKm = settings.avgResetDistanceKm,
                        avgResetFuelLiters = settings.avgResetFuelLiters,
                        costResetFuelLiters = settings.costResetFuelLiters,
                        fuelPriceText = settings.fuelPriceText,
                        odometerText = settings.odometerText
                    ),
                    TripPresentationInput(
                        averageConsumption = snapshot.averageConsumption,
                        instantConsumption = snapshot.instantConsumption,
                        fuelUsedL = snapshot.fuelUsedL,
                        tripDistanceKm = snapshot.tripDistanceKm,
                        tripCostText = snapshot.tripCostText,
                        odometerKm = snapshot.odometerKm
                    ),
                    obdController.cockpitTripSnapshot()
                )
                return snapshot.copy(
                    averageConsumption = presentation.averageConsumption,
                    instantConsumption = presentation.instantConsumption,
                    fuelUsedL = presentation.fuelUsedL,
                    tripCostText = presentation.tripCostText,
                    odometerKm = presentation.odometerKm
                )
            }

            val liveSnapshot = when {
                settings.demoMode -> enrichTrip(DashboardSnapshot.demoLive(demoTick))
                obdState.connected -> enrichTrip(obdState.snapshot)
                else -> DashboardSnapshot.empty()
            }

            LoganOSTheme(accentColor = settings.accentColor, darkTheme = dark, menuTheme = settings.menuTheme) { palette ->
                SideEffect {
                    // Keep the Android status/navigation bars in the same theme as LoganOS.
                    // This prevents a light system bar around a dark cockpit (and vice versa).
                    window.statusBarColor = palette.background.toArgb()
                    window.navigationBarColor = palette.surface.toArgb()
                    WindowCompat.getInsetsController(window, window.decorView).apply {
                        isAppearanceLightStatusBars = !dark
                        isAppearanceLightNavigationBars = !dark
                    }
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        window.isStatusBarContrastEnforced = false
                        window.isNavigationBarContrastEnforced = false
                    }
                }
                when {
                    showSplash -> SplashScreen(palette)
                    !settings.setupCompleted -> SetupWizard(
                        palette = palette,
                        initial = settings,
                        onComplete = { updated -> persist(updated) }
                    )
                    else -> LoganAppShell(
                        palette = palette,
                        settings = settings,
                        snapshot = liveSnapshot,
                        averageDistanceKm = run {
                            val totals = obdController.cockpitTripSnapshot()
                            val hasBaseline = settings.avgResetDistanceKm > 0.0 || settings.avgResetFuelLiters > 0.0
                            val baselineValid = totals.totalDistanceKm >= settings.avgResetDistanceKm &&
                                totals.totalFuelLiters + 0.000001 >= settings.avgResetFuelLiters
                            val baseDistance = if (hasBaseline && baselineValid) settings.avgResetDistanceKm else 0.0
                            (totals.totalDistanceKm - baseDistance).coerceAtLeast(0.0)
                        },
                        obdState = obdState,
                        onSettingsChange = { updated -> persist(updated) },
                        onResetSetup = {
                            prefs.resetSetup()
                            settings = settings.copy(setupCompleted = false)
                            // Kurulumu sıfırla sonrası splash'a dönmeden doğrudan sihirbaz açılır.
                            showSplash = false
                        },
                        onResetMetrics = { action ->
                            if (settings.demoMode || liveSnapshot.demo) {
                                Toast.makeText(this, "Demo Modu verileri gerçek yol bilgisayarı sıfırlamalarında kullanılamaz", Toast.LENGTH_SHORT).show()
                            } else if (!settings.fuelCalculationSupported) {
                                Toast.makeText(this, "Benzinli profilde yakıt hesabı henüz doğrulanmadı", Toast.LENGTH_SHORT).show()
                            } else if (liveSnapshot.tripToken == 0L) {
                                Toast.makeText(this, "Aktif yolculuk verisi yok", Toast.LENGTH_SHORT).show()
                            } else {
                                val activeFuel = liveSnapshot.fuelUsedL ?: 0.0
                                val cockpitTotals = obdController.cockpitTripSnapshot()
                                val historicalDistance = cockpitTotals.totalDistanceKm
                                val historicalFuel = cockpitTotals.totalFuelLiters
                                val updated = when (action) {
                                    TripMetricReset.Average -> settings.copy(
                                        avgResetDistanceKm = historicalDistance,
                                        avgResetFuelLiters = historicalFuel,
                                        avgResetTripToken = 0L
                                    )
                                    TripMetricReset.Cost -> settings.copy(
                                        costResetFuelLiters = activeFuel,
                                        costResetTripToken = 0L
                                    )
                                    TripMetricReset.AverageAndCost -> settings.copy(
                                        avgResetDistanceKm = historicalDistance,
                                        avgResetFuelLiters = historicalFuel,
                                        costResetFuelLiters = activeFuel,
                                        avgResetTripToken = 0L,
                                        costResetTripToken = 0L
                                    )
                                }
                                persist(updated)
                                obdController.logMetricReset(action, historicalDistance, activeFuel, settings.fuelPriceText)
                                val message = when (action) {
                                    TripMetricReset.Average -> "Ortalama tüketimi sıfırlandı"
                                    TripMetricReset.Cost -> "Sürüş maliyeti sıfırlandı"
                                    TripMetricReset.AverageAndCost -> "Ortalama ve maliyet sıfırlandı"
                                }
                                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onClearAllDriveData = {
                            val cleared = obdController.clearAllDriveData()
                            if (cleared) {
                                val updated = settings.copy(
                                    avgResetDistanceKm = 0.0,
                                    avgResetFuelLiters = 0.0,
                                    avgResetTripToken = 0L,
                                    costResetFuelLiters = 0.0,
                                    costResetTripToken = 0L
                                )
                                persist(updated)
                            }
                            Toast.makeText(
                                this@MainActivity,
                                if (cleared) "Tüm sürüş verileri silindi" else "Önce OBD bağlantısını kesin",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onEndTripNow = {
                            if (settings.demoMode || liveSnapshot.demo) {
                                Toast.makeText(this@MainActivity, "Demo Modu sırasında gerçek sürüş kaydı sonlandırılamaz", Toast.LENGTH_SHORT).show()
                            } else uiScope.launch {
                                val ended = obdController.finishTripNow()
                                Toast.makeText(
                                    this@MainActivity,
                                    if (ended) "Sürüş tamamlandı; yeni sürüş bekleniyor" else "Tamamlanacak aktif sürüş yok",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        },
                        onRefreshObdDevices = { refreshObdDevicesWithPermission() },
                        onSelectObdDevice = { obdController.selectDevice(it) },
                        onConnectObd = {
                            obdController.connectSelected()
                            // Double Mode only (no-op elsewhere): arm the bounded automatic reconnection too.
                            obdController.requestHeadUnitAutoConnect(settings, "manual_connect")
                        },
                        onDisconnectObd = { obdController.disconnect() },
                        onSaveObdLog = {
                            obdController.saveLogFile()
                            Toast.makeText(this, "Kayıt dışa aktarıldı", Toast.LENGTH_SHORT).show()
                        },
                        onShareObdLog = { obdController.shareLogText() },
                        onExportTechnicalSession = { id -> obdController.exportTechnicalSession(id) },
                        onCreateSupportPackage = {
                            val attachmentUri = obdController.createSupportPackage()
                            Toast.makeText(
                                this,
                                if (attachmentUri != null) "Destek paketi e-postaya hazırlandı" else "Destek paketi oluşturulamadı",
                                Toast.LENGTH_SHORT
                            ).show()
                            attachmentUri
                        },
                        onClearLastObdLog = {
                            obdController.clearLastLogFile()
                            Toast.makeText(this, "Son log işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        },
                        onClearAllObdLogs = {
                            val cleared = obdController.clearAllLogFiles()
                            Toast.makeText(
                                this,
                                if (cleared) "Log temizleme işlemi tamamlandı" else "Önce OBD bağlantısını kesin",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        onDeveloperTestStart = { name ->
                            obdController.startDeveloperTest(name)
                            val current = obdController.state
                            val started = current.activeDeveloperTest == name
                            Toast.makeText(
                                this,
                                if (started) "Test başlatıldı: $name" else current.status,
                                if (started) Toast.LENGTH_SHORT else Toast.LENGTH_LONG
                            ).show()
                        },
                        onDeveloperTestEnd = {
                            obdController.finishDeveloperTest()
                            Toast.makeText(this, "Test bitti", Toast.LENGTH_SHORT).show()
                        },
                        onStartCrankAnalysis = { obdController.armManualCrankAnalysis() },
                        onClearManualCrankTests = {
                            obdController.clearManualCrankTests()
                            Toast.makeText(this, "Marş testleri silindi", Toast.LENGTH_SHORT).show()
                        },
                        onRefreshHistory = { obdController.refreshHistory() },
                        onLoadDriveHistoryDetail = { id -> obdController.loadDriveHistoryDetail(id) },
                        onClearDriveHistoryDetail = { obdController.clearDriveHistoryDetail() },
                        onPinDriveHistory = { id, pinned ->
                            val ok = obdController.setDriveHistoryPinned(id, pinned)
                            Toast.makeText(this, if (ok) (if (pinned) "Sürüş korumaya alındı" else "Sürüş koruması kaldırıldı") else "Sürüş güncellenemedi", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteDriveHistory = { id ->
                            val ok = obdController.deleteDriveHistory(id)
                            Toast.makeText(this, if (ok) "Sürüş kaydı silindi" else "Aktif veya bekleyen sürüş silinemez", Toast.LENGTH_SHORT).show()
                        },
                        onExportDriveHistory = { id ->
                            obdController.exportDriveHistory(id)
                        },
                        onExportGpsRoute = { id ->
                            obdController.exportGpsRoute(id)
                        },
                        onPinTestHistory = { id, pinned ->
                            val ok = obdController.setTestHistoryPinned(id, pinned)
                            Toast.makeText(this, if (ok) (if (pinned) "Test korumaya alındı" else "Test koruması kaldırıldı") else "Test güncellenemedi", Toast.LENGTH_SHORT).show()
                        },
                        onDeleteTestHistory = { id ->
                            val ok = obdController.deleteTestHistory(id)
                            Toast.makeText(this, if (ok) "Test kaydı silindi" else "Aktif test silinemez", Toast.LENGTH_SHORT).show()
                        },
                        onExportTestHistory = { id ->
                            obdController.exportTestHistory(id)
                        },
                        onExportAllHistory = {
                            obdController.exportAllHistory()
                        },
                        onCreateDataBackup = {
                            if (!obdController.canCreateOrRestoreDataBackup()) {
                                Toast.makeText(this, "Yedekleme için önce OBD bağlantısını kesin", Toast.LENGTH_LONG).show()
                            } else {
                                createBackupLauncher.launch(dataBackupManager.defaultBackupFileName())
                            }
                        },
                        onRestoreDataBackup = {
                            if (!obdController.canCreateOrRestoreDataBackup()) {
                                Toast.makeText(this, "Geri yükleme için önce OBD bağlantısını kesin", Toast.LENGTH_LONG).show()
                            } else {
                                restoreBackupLauncher.launch(arrayOf("application/zip", "application/octet-stream", "application/x-zip-compressed"))
                            }
                        },
                        onFuelRefillLitersSave = { text -> obdController.setFuelRefillLiters(text) }
                    )
                }
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                1204
            )
        }
    }

    private fun requestBluetoothPermissions() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions, 1203)
    }
}
