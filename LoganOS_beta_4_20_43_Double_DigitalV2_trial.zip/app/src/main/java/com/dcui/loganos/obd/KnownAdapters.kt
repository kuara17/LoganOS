package com.dcui.loganos.obd

data class KnownAdapter(val address: String, val name: String, val seq: Long)

/**
 * Adapters that connected successfully before (most recent first) - the only devices the app is
 * ever allowed to connect to AUTOMATICALLY, besides the one the user explicitly selected.
 *
 * Uses a sequence number instead of the wall clock for ordering: a head unit clock can be wrong.
 */
data class KnownAdapters(val entries: List<KnownAdapter> = emptyList()) {

    fun record(address: String, name: String?): KnownAdapters {
        val key = address.trim().uppercase()
        if (key.isEmpty()) return this
        val next = (entries.maxOfOrNull { it.seq } ?: 0L) + 1L
        val cleanName = sanitize(name).ifEmpty { key }
        val others = entries.filterNot { it.address == key }
        return KnownAdapters((listOf(KnownAdapter(key, cleanName, next)) + others).take(MAX_ENTRIES))
    }

    /**
     * Addresses to try, in order: an explicitly selected adapter that never connected first,
     * then the known ones, most recent success first. Nothing else is ever a candidate.
     */
    fun candidates(selectedAddress: String?): List<String> {
        val known = entries.sortedByDescending { it.seq }.map { it.address }
        val selected = selectedAddress?.trim()?.uppercase()?.takeIf { it.isNotEmpty() }
        return if (selected != null && selected !in known) listOf(selected) + known else known
    }

    /** Candidate for the n-th attempt: rotates through [candidates]. */
    fun pick(attemptIndex: Int, selectedAddress: String?): String? {
        val list = candidates(selectedAddress)
        if (list.isEmpty()) return null
        return list[Math.floorMod(attemptIndex, list.size)]
    }

    fun nameOf(address: String): String? = entries.firstOrNull { it.address == address.trim().uppercase() }?.name

    fun encode(): String = entries.joinToString("\n") { "${it.address}\t${it.name}\t${it.seq}" }

    companion object {
        const val MAX_ENTRIES = 5

        fun decode(text: String?): KnownAdapters {
            if (text.isNullOrBlank()) return KnownAdapters()
            val parsed = text.split('\n').mapNotNull { line ->
                val parts = line.split('\t')
                if (parts.size != 3) return@mapNotNull null
                val seq = parts[2].toLongOrNull() ?: return@mapNotNull null
                val address = parts[0].trim().uppercase()
                if (address.isEmpty()) return@mapNotNull null
                KnownAdapter(address, sanitize(parts[1]).ifEmpty { address }, seq)
            }
            return KnownAdapters(parsed.sortedByDescending { it.seq }.distinctBy { it.address }.take(MAX_ENTRIES))
        }

        private fun sanitize(name: String?): String =
            (name ?: "").replace(Regex("[\\t\\r\\n]"), " ").trim().take(40)
    }
}
