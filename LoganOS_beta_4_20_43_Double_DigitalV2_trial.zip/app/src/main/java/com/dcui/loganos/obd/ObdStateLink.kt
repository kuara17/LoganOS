package com.dcui.loganos.obd

/** The derived link level of this state (see [ObdLinkLevel]). */
fun ObdState.linkLevel(): ObdLinkLevel = ObdLinkStatus.derive(
    socketOpen = connected,
    connecting = connecting,
    health = connectionHealth,
    healthReason = connectionHealthReason,
    snapshotHasData = snapshot.connected
)
