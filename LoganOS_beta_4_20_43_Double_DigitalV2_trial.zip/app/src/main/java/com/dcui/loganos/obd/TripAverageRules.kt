package com.dcui.loganos.obd

/**
 * Single home for the "when may an average be shown / how is it derived" rules.
 *
 * Before this existed the 1 km threshold was written in three places (TripComputer,
 * PersistentCockpitTripState and MainActivity.enrichTrip).
 */
object TripAverageRules {
    /** Average consumption stays "calculating" until at least this distance was driven. */
    const val MIN_DISTANCE_KM = 1.0

    /**
     * Fuel over distance in L/100 km, or null when it cannot be derived honestly
     * (no fuel, or too little distance for a meaningful ratio).
     */
    fun derivedAverageL100(fuelLiters: Double, distanceKm: Double): Double? =
        if (fuelLiters.isFinite() && distanceKm.isFinite() && fuelLiters > 0.0 && distanceKm >= MIN_DISTANCE_KM) {
            fuelLiters / distanceKm * 100.0
        } else null
}
