package com.dcui.loganos.obd

/**
 * Attempt budget for the Double Mode (HeadUnit) automatic connection. Pure and unit tested.
 *
 * Three independent limits keep the app from ever retrying forever (e.g. hours after the car was
 * stopped):
 *   1. per drop:   at most [perDropMaxAttempts] attempts inside [perDropWindowMs];
 *   2. per session: at most [sessionMaxAttempts] attempts in total;
 *   3. ignition:   once the ignition-off wait window has expired, no attempt at all.
 * The per-drop counters are only refilled after valid ECU data flowed for [stableDataMs]; a mere
 * open Bluetooth socket (adapter powered, ECU asleep) does NOT refill them.
 */
class HeadUnitAutoConnectBudget(
    private val perDropMaxAttempts: Int = DEFAULT_PER_DROP_MAX_ATTEMPTS,
    private val perDropWindowMs: Long = DEFAULT_PER_DROP_WINDOW_MS,
    private val sessionMaxAttempts: Int = DEFAULT_SESSION_MAX_ATTEMPTS,
    private val stableDataMs: Long = DEFAULT_STABLE_DATA_MS,
    private val initialDelayMs: Long = DEFAULT_INITIAL_DELAY_MS,
    private val backoffMs: List<Long> = DEFAULT_BACKOFF_MS
) {
    enum class StopReason { DROP_ATTEMPTS_EXHAUSTED, DROP_WINDOW_EXPIRED, SESSION_BUDGET_EXHAUSTED, IGNITION_OFF }

    sealed class Decision {
        object Wait : Decision()
        data class Attempt(val number: Int, val max: Int) : Decision()
        data class Stop(val reason: StopReason) : Decision()
    }

    var sessionAttempts: Int = 0
        private set
    var attemptsInDrop: Int = 0
        private set

    private var dropStartedAtMs: Long? = null
    private var idleSinceMs: Long? = null
    private var dataFlowingSinceMs: Long? = null

    /** Valid ECU data is flowing. After [stableDataMs] of it the per-drop budget is refilled. */
    fun onDataFlowing(nowMs: Long) {
        idleSinceMs = null
        val since = dataFlowingSinceMs ?: nowMs.also { dataFlowingSinceMs = it }
        if (nowMs - since >= stableDataMs) {
            attemptsInDrop = 0
            dropStartedAtMs = null
        }
    }

    /** Something is already in progress (connecting, reconnecting, socket open without data). */
    fun onBusy() {
        idleSinceMs = null
        dataFlowingSinceMs = null
    }

    /** Nothing is connected and nothing is in progress: decide whether to try again. */
    fun decide(nowMs: Long, ignitionWindowExpired: Boolean): Decision {
        dataFlowingSinceMs = null
        if (ignitionWindowExpired) return Decision.Stop(StopReason.IGNITION_OFF)
        val idleSince = idleSinceMs ?: nowMs.also { idleSinceMs = it }
        val dropStarted = dropStartedAtMs ?: nowMs.also { dropStartedAtMs = it }
        if (nowMs - dropStarted >= perDropWindowMs) return Decision.Stop(StopReason.DROP_WINDOW_EXPIRED)
        if (sessionAttempts >= sessionMaxAttempts) return Decision.Stop(StopReason.SESSION_BUDGET_EXHAUSTED)
        if (attemptsInDrop >= perDropMaxAttempts) return Decision.Stop(StopReason.DROP_ATTEMPTS_EXHAUSTED)
        val waitMs = if (attemptsInDrop == 0) {
            initialDelayMs
        } else {
            backoffMs[(attemptsInDrop - 1).coerceAtMost(backoffMs.size - 1)]
        }
        if (nowMs - idleSince < waitMs) return Decision.Wait
        attemptsInDrop += 1
        sessionAttempts += 1
        idleSinceMs = null
        return Decision.Attempt(attemptsInDrop, perDropMaxAttempts)
    }

    /**
     * Nothing can be tried yet (Bluetooth off, no adapter, no permission). No attempt is consumed,
     * but the drop window keeps running and an expired ignition window still stops everything.
     * Returns the reason to stop, or null to keep waiting.
     */
    fun notReady(nowMs: Long, ignitionWindowExpired: Boolean): StopReason? {
        dataFlowingSinceMs = null
        idleSinceMs = null // the initial delay starts again once everything is ready
        if (ignitionWindowExpired) return StopReason.IGNITION_OFF
        val dropStarted = dropStartedAtMs ?: nowMs.also { dropStartedAtMs = it }
        return if (nowMs - dropStarted >= perDropWindowMs) StopReason.DROP_WINDOW_EXPIRED else null
    }

    companion object {
        const val DEFAULT_PER_DROP_MAX_ATTEMPTS = 6
        const val DEFAULT_PER_DROP_WINDOW_MS = 10L * 60L * 1000L
        const val DEFAULT_SESSION_MAX_ATTEMPTS = 30
        const val DEFAULT_STABLE_DATA_MS = 30_000L
        const val DEFAULT_INITIAL_DELAY_MS = 2_000L
        val DEFAULT_BACKOFF_MS: List<Long> = listOf(5_000L, 10_000L, 20_000L, 30_000L, 60_000L)
    }
}

/** Compact, language-neutral status codes for the UI (localised in [label]). */
object AutoConnectStatus {
    const val IDLE = ""
    const val LINKED = "LINKED"
    fun attempt(number: Int, max: Int) = "ATTEMPT:$number/$max"
    fun waiting(reason: String) = "WAITING:$reason"
    fun stopped(reason: HeadUnitAutoConnectBudget.StopReason) = "STOPPED:${reason.name}"

    fun label(code: String, turkish: Boolean): String = when {
        code.isEmpty() -> ""
        code == LINKED -> if (turkish) "Otomatik bağlanma: bağlı" else "Auto-connect: connected"
        code.startsWith("ATTEMPT:") -> {
            val n = code.removePrefix("ATTEMPT:")
            if (turkish) "Otomatik bağlanma: deneme $n" else "Auto-connect: attempt $n"
        }
        code.startsWith("WAITING:") -> {
            val why = when (code.removePrefix("WAITING:")) {
                "BLUETOOTH_OFF" -> if (turkish) "Bluetooth kapalı" else "Bluetooth is off"
                "NO_ADAPTER" -> if (turkish) "kayıtlı adaptör yok" else "no saved adapter"
                "NO_PERMISSION" -> if (turkish) "Bluetooth izni yok" else "Bluetooth permission missing"
                else -> if (turkish) "hazır değil" else "not ready"
            }
            if (turkish) "Otomatik bağlanma: bekliyor ($why)" else "Auto-connect: waiting ($why)"
        }
        code.startsWith("STOPPED:") -> {
            val why = when (code.removePrefix("STOPPED:")) {
                "DROP_ATTEMPTS_EXHAUSTED" -> if (turkish) "deneme sınırı doldu" else "attempt limit reached"
                "DROP_WINDOW_EXPIRED" -> if (turkish) "süre doldu" else "time window expired"
                "SESSION_BUDGET_EXHAUSTED" -> if (turkish) "oturum sınırı doldu" else "session limit reached"
                "IGNITION_OFF" -> if (turkish) "kontak kapalı" else "ignition off"
                else -> if (turkish) "durdu" else "stopped"
            }
            if (turkish) "Otomatik bağlanma: durdu ($why)" else "Auto-connect: stopped ($why)"
        }
        else -> ""
    }
}
