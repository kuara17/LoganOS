package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

/**
 * CHARACTERIZATION tests for the persistent cockpit totals (4.20.37).
 * The totals are RAW: the fuel calibration factor is not applied here.
 */
class PersistentCockpitTripAccumulatorCharacterizationTest {

    @Test
    fun firstObservationAddsTheFullSegmentValues() {
        val acc = PersistentCockpitTripAccumulator()
        val state = acc.update(tripToken = 1L, distanceKm = 2.0, fuelLiters = 0.1, durationSec = 100L)
        assertEquals(2.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.1, state.totalFuelLiters, 1e-12)
    }

    @Test
    fun sameTokenAddsOnlyTheDelta() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 2.0, 0.1, 100L)
        val state = acc.update(1L, 3.0, 0.15, 150L)
        assertEquals(3.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.15, state.totalFuelLiters, 1e-12)
    }

    @Test
    fun newTokenStartsFromZeroWithoutDiscardingEarlierTotals() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 3.0, 0.15, 150L)
        val state = acc.update(2L, 1.0, 0.05, 50L)
        assertEquals(4.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.20, state.totalFuelLiters, 1e-12)
    }

    @Test
    fun smallerValuesWithTheSameTokenAreTreatedAsASegmentReset() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 1.0, 0.05, 50L)
        val state = acc.update(1L, 0.5, 0.02, 20L)
        assertEquals(1.5, state.totalDistanceKm, 1e-12)
        assertEquals(0.07, state.totalFuelLiters, 1e-12)
    }

    @Test
    fun tokenZeroIsIgnored() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 1.0, 0.05, 50L)
        val state = acc.update(0L, 9.0, 9.0, 9L)
        assertEquals(1.0, state.totalDistanceKm, 1e-12)
    }

    @Test
    fun rebaseDoesNotChangeTotals() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 2.0, 0.1, 100L)
        val state = acc.rebase(5L, 0.0, 0.0, 0L)
        assertEquals(2.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.1, state.totalFuelLiters, 1e-12)
        assertEquals(5L, state.lastTripToken)
    }

    @Test
    fun clearAllZeroesEverything() {
        val acc = PersistentCockpitTripAccumulator()
        acc.update(1L, 2.0, 0.1, 100L)
        val state = acc.clearAll()
        assertEquals(0.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.0, state.totalFuelLiters, 1e-12)
        assertEquals(0L, state.lastTripToken)
    }

    @Test
    fun nonFiniteOrNegativeInitialValuesAreSilentlyCoercedToZero() {
        val acc = PersistentCockpitTripAccumulator(
            PersistentCockpitTripState(totalDistanceKm = Double.NaN, totalFuelLiters = -3.0)
        )
        val state = acc.snapshot()
        assertEquals(0.0, state.totalDistanceKm, 1e-12)
        assertEquals(0.0, state.totalFuelLiters, 1e-12)
    }

    @Test
    fun averageNeedsAtLeastOneKilometre() {
        assertNull(PersistentCockpitTripState(totalDistanceKm = 0.9, totalFuelLiters = 0.05).averageL100)
        val avg = PersistentCockpitTripState(totalDistanceKm = 2.0, totalFuelLiters = 0.1).averageL100
        assertNotNull(avg)
        assertEquals(5.0, avg!!, 1e-9)
    }
}
