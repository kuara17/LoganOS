package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Stage 1.1 / Y3: idle fuel before departure is counted while the engine is confirmed running. */
class TripComputerIdleFuelTest {

    private class Clock(var nowMs: Long = 0L)

    private fun TripComputer.drive(clock: Clock, seconds: Int, speedKmh: Double?, fuelLh: Double?): TripComputerSnapshot {
        var last = snapshot(clock.nowMs)
        repeat(seconds) {
            clock.nowMs += 1000L
            last = update(speedKmh, fuelLh, clock.nowMs)
        }
        return last
    }

    private fun runningComputer(clock: Clock): TripComputer {
        val tc = TripComputer()
        tc.reset(clock.nowMs)
        tc.setEngineRunning(true, clock.nowMs)
        return tc
    }

    @Test
    fun idleBeforeDepartureIsHeldAsPendingFuelWhileTheEngineRuns() {
        val clock = Clock()
        val tc = runningComputer(clock)
        val snap = tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals("WAITING", snap.state)
        assertEquals(0.0, snap.distanceKm, 1e-12)
        assertEquals(60 * 0.8 / 3600.0, tc.exportState(clock.nowMs).pendingFuelL, 1e-12)
    }

    @Test
    fun tripStartFoldsTheIdleFuelIntoTheTotals() {
        val clock = Clock()
        val tc = runningComputer(clock)
        tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        val snap = tc.drive(clock, seconds = 1, speedKmh = 20.0, fuelLh = 2.0)
        assertEquals(60 * 0.8 / 3600.0 + 2.0 / 3600.0, snap.fuelUsedL, 1e-12)
        assertEquals(20.0 / 3600.0, snap.distanceKm, 1e-12)
    }

    @Test
    fun averageNeverRisesDuringIdleBecauseItStaysCalculating() {
        val clock = Clock()
        val tc = runningComputer(clock)
        repeat(10) {
            val snap = tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
            assertEquals("WAITING", snap.state)
            assertNull(snap.averageL100)
        }
    }

    @Test
    fun firstKilometreAverageIncludesTheIdleFuel() {
        val clock = Clock()
        val tc = runningComputer(clock)
        tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        val snap = tc.drive(clock, seconds = 70, speedKmh = 60.0, fuelLh = 3.0)
        assertEquals("ACTIVE", snap.state)
        val idleFuel = 60 * 0.8 / 3600.0
        val drivingFuel = 70 * 3.0 / 3600.0
        val distance = 70 * 60.0 / 3600.0
        assertEquals((idleFuel + drivingFuel) / distance * 100.0, snap.fuelUsedL / snap.distanceKm * 100.0, 1e-9)
        assertEquals(idleFuel + drivingFuel, snap.fuelUsedL, 1e-9)
    }

    @Test
    fun engineConfirmedOffBeforeTheTripStartedDropsTheWaitingFuel() {
        val clock = Clock()
        val tc = runningComputer(clock)
        tc.drive(clock, seconds = 30, speedKmh = 0.0, fuelLh = 0.8)
        tc.pauseDuration(clock.nowMs)
        val state = tc.exportState(clock.nowMs)
        assertEquals(0.0, state.pendingFuelL, 1e-12)
        assertEquals(0.0, state.pendingDistanceKm, 1e-12)
    }

    @Test
    fun noIdleFuelIsCountedAfterEngineOffUntilItRunsAgain() {
        val clock = Clock()
        val tc = runningComputer(clock)
        tc.pauseDuration(clock.nowMs)
        tc.drive(clock, seconds = 30, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals(0.0, tc.exportState(clock.nowMs).pendingFuelL, 1e-12)
        tc.setEngineRunning(true, clock.nowMs)
        tc.drive(clock, seconds = 30, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals(30 * 0.8 / 3600.0, tc.exportState(clock.nowMs).pendingFuelL, 1e-12)
    }

    @Test
    fun withoutAnEngineSignalTheOldBehaviourRemains() {
        val clock = Clock()
        val tc = TripComputer()
        tc.reset(clock.nowMs)
        tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals(0.0, tc.exportState(clock.nowMs).pendingFuelL, 1e-12)
    }
}
