package com.dcui.loganos.model

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BootLaunchPolicyTest {
    private val ready = LoganSettings(
        deviceMode = DeviceMode.HeadUnit,
        setupCompleted = true,
        demoMode = false,
        bootAutoStartEnabled = true
    )

    @Test
    fun bootAutoStartIsOffByDefault() {
        assertFalse(LoganSettings().bootAutoStartEnabled)
        assertFalse(LoganSettings().bootLaunchEnabled())
    }

    @Test
    fun launchesOnlyWhenAllConditionsHold() {
        assertTrue(ready.bootLaunchEnabled())
    }

    @Test
    fun anyMissingConditionDisablesBootLaunch() {
        assertFalse(ready.copy(deviceMode = DeviceMode.Phone).bootLaunchEnabled())
        assertFalse(ready.copy(deviceMode = DeviceMode.Auto).bootLaunchEnabled())
        assertFalse(ready.copy(setupCompleted = false).bootLaunchEnabled())
        assertFalse(ready.copy(demoMode = true).bootLaunchEnabled())
        assertFalse(ready.copy(bootAutoStartEnabled = false).bootLaunchEnabled())
    }

    @Test
    fun switchOffDoesNotAffectObdAutoConnectPolicy() {
        val switchedOff = ready.copy(bootAutoStartEnabled = false)
        assertFalse(switchedOff.bootLaunchEnabled())
        assertTrue(switchedOff.headUnitAutomationEnabled())
    }
}
