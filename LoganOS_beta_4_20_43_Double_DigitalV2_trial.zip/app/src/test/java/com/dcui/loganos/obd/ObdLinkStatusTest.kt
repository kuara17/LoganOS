package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 3.1 / B5: "OBD connected" only with valid ECU data. */
class ObdLinkStatusTest {

    private fun derive(
        socketOpen: Boolean = true,
        connecting: Boolean = false,
        health: ObdConnectionHealth = ObdConnectionHealth.STABLE,
        reason: String? = null,
        data: Boolean = true
    ) = ObdLinkStatus.derive(socketOpen, connecting, health, reason, data)

    @Test
    fun openSocketWithoutEcuDataIsNotObdConnected() {
        val level = derive(health = ObdConnectionHealth.STABLE, data = false)
        assertEquals(ObdLinkLevel.ADAPTER_WAITING_ECU, level)
        assertFalse(level.showsObdConnected)
        assertFalse(level.linkPresent)
    }

    @Test
    fun healthStillConnectingWithAnOpenSocketIsAdapterWaitingForEcu() {
        assertEquals(ObdLinkLevel.ADAPTER_WAITING_ECU, derive(health = ObdConnectionHealth.CONNECTING, data = false))
        assertEquals(ObdLinkLevel.ADAPTER_WAITING_ECU, derive(health = ObdConnectionHealth.DISCONNECTED, data = true))
    }

    @Test
    fun validDataOnAStableLinkIsTheOnlyObdConnected() {
        val level = derive(health = ObdConnectionHealth.STABLE, data = true)
        assertEquals(ObdLinkLevel.DATA_FLOWING, level)
        assertTrue(level.showsObdConnected)
        assertTrue(level.linkPresent)
        ObdLinkLevel.values().filter { it != ObdLinkLevel.DATA_FLOWING }.forEach { assertFalse(it.showsObdConnected) }
    }

    @Test
    fun ignitionOffIsRecognisedFromTheHealthReason() {
        val level = derive(health = ObdConnectionHealth.STABLE, reason = "Kontak kapalı • motor bekleniyor", data = true)
        assertEquals(ObdLinkLevel.IGNITION_OFF, level)
        assertFalse(level.showsObdConnected)
        assertTrue(level.linkPresent)
    }

    @Test
    fun staleAndUnstableLinksKeepTheirOwnLevels() {
        assertEquals(ObdLinkLevel.DATA_STALE, derive(health = ObdConnectionHealth.DATA_STALE))
        assertEquals(ObdLinkLevel.UNSTABLE, derive(health = ObdConnectionHealth.UNSTABLE))
        assertTrue(ObdLinkLevel.DATA_STALE.linkPresent)
        assertTrue(ObdLinkLevel.UNSTABLE.linkPresent)
    }

    @Test
    fun noSocketMeansDisconnectedOrReconnecting() {
        assertEquals(ObdLinkLevel.DISCONNECTED, derive(socketOpen = false, health = ObdConnectionHealth.DISCONNECTED, data = false))
        assertEquals(ObdLinkLevel.RECONNECTING, derive(socketOpen = false, health = ObdConnectionHealth.RECONNECTING, data = false))
        assertFalse(ObdLinkLevel.DISCONNECTED.linkPresent)
        assertFalse(ObdLinkLevel.RECONNECTING.linkPresent)
    }

    @Test
    fun connectingWinsOverEverythingElse() {
        assertEquals(ObdLinkLevel.CONNECTING, derive(socketOpen = false, connecting = true, health = ObdConnectionHealth.DISCONNECTED))
        assertEquals(ObdLinkLevel.CONNECTING, derive(socketOpen = true, connecting = true, health = ObdConnectionHealth.STABLE))
    }

    @Test
    fun settingsLabelsCallOutOnlyTheAdapterWithoutEcuData() {
        assertEquals("Bağlı", ObdLinkLevel.DATA_FLOWING.settingsLabel(true))
        assertEquals("Connected", ObdLinkLevel.DATA_STALE.settingsLabel(false))
        assertEquals("Adaptör bağlı, ECU bekleniyor", ObdLinkLevel.ADAPTER_WAITING_ECU.settingsLabel(true))
        assertEquals("Adapter connected, waiting for ECU", ObdLinkLevel.ADAPTER_WAITING_ECU.settingsLabel(false))
        assertEquals("Bağlı değil", ObdLinkLevel.DISCONNECTED.settingsLabel(true))
        assertEquals("Disconnected", ObdLinkLevel.CONNECTING.settingsLabel(false))
    }
}
