package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 4 / K2: reset detection in the persistent trip store (with an in-memory preferences fake). */
class PersistentCockpitTripStoreTest {

    private var epochCounter = 0
    private fun newStore(prefs: FakeSharedPreferences, installId: String = "install-A") =
        PersistentCockpitTripStore(prefs, { installId }, { "epoch-${++epochCounter}" })

    private fun driveSnapshot(token: Long = 1L, distanceKm: Double = 5.0, fuelL: Double = 0.3): TripComputerSnapshot {
        val clock = LongArray(1)
        val tc = TripComputer()
        tc.reset(clock[0])
        // ~60 km/h for enough seconds to reach the distance, 3 L/h
        val seconds = (distanceKm / 60.0 * 3600.0).toInt() + 1
        var last = tc.snapshot(clock[0])
        repeat(seconds) { clock[0] += 1000L; last = tc.update(60.0, fuelL / (distanceKm / 60.0) , clock[0]) }
        return last.copy(tripToken = token)
    }

    @Test
    fun aFreshInstallGetsGenerationOneAndPersistsItImmediately() {
        val prefs = FakeSharedPreferences()
        val store = newStore(prefs)
        val id = store.identity()
        assertEquals(1L, id.resetGeneration)
        assertEquals("epoch-1", id.epochId)
        assertEquals("install-A", id.installId)
        assertEquals("new_identity", store.identityChangeReason)
        assertEquals("epoch-1", prefs.getString("epoch_id", null))
        assertEquals(1L, prefs.getLong("reset_generation", 0L))
    }

    @Test
    fun aRestartKeepsTheIdentity() {
        val prefs = FakeSharedPreferences()
        val first = newStore(prefs).identity()
        val second = newStore(prefs)
        assertEquals(first, second.identity())
        assertNull(second.identityChangeReason)
    }

    @Test
    fun clearAllBumpsTheGenerationKeepsTheEpochAndZeroesTheTotals() {
        val prefs = FakeSharedPreferences()
        val store = newStore(prefs)
        store.update(driveSnapshot(), force = true)
        assertTrue(store.snapshot().totalDistanceKm > 1.0)
        val before = store.identity()
        store.clearAll()
        val after = store.identity()
        assertEquals(before.resetGeneration + 1, after.resetGeneration)
        assertEquals(before.epochId, after.epochId)
        assertEquals(0.0, store.snapshot().totalDistanceKm, 1e-12)
        assertEquals(0.0, store.snapshot().totalFuelLiters, 1e-12)
    }

    @Test
    fun clearAllWritesTotalsAndGenerationInOneCommit() {
        val prefs = FakeSharedPreferences()
        val store = newStore(prefs)
        store.update(driveSnapshot(), force = true)
        val commitsBefore = prefs.commitCount
        val writesBefore = prefs.writes.size
        store.clearAll()
        assertEquals(commitsBefore + 1, prefs.commitCount)
        assertEquals(writesBefore + 1, prefs.writes.size)
        val written = prefs.writes.last()
        assertEquals(0.0, Double.fromBits(written["total_distance_bits"] as Long), 1e-12)
        assertEquals(2L, written["reset_generation"])
    }

    @Test
    fun theGenerationOnlyEverGrows() {
        val prefs = FakeSharedPreferences()
        val store = newStore(prefs)
        val generations = mutableListOf(store.identity().resetGeneration)
        repeat(3) { store.clearAll(); generations += store.identity().resetGeneration }
        assertEquals(listOf(1L, 2L, 3L, 4L), generations)
        // and it survives a restart
        assertEquals(4L, newStore(prefs).identity().resetGeneration)
    }

    @Test
    fun damagedTotalsRenewTheEpochAndBumpTheGeneration() {
        val prefs = FakeSharedPreferences()
        val seed = newStore(prefs)
        seed.update(driveSnapshot(), force = true)
        val old = seed.identity()
        prefs.data["total_distance_bits"] = Double.NaN.toBits()           // corrupted value
        val reloaded = newStore(prefs)
        val id = reloaded.identity()
        assertEquals("totals_repaired", reloaded.identityChangeReason)
        assertEquals(old.resetGeneration + 1, id.resetGeneration)
        assertTrue(old.epochId != id.epochId)
        assertEquals(0.0, reloaded.snapshot().totalDistanceKm, 1e-12)      // repaired silently to 0, but now detectable
        // the new identity is durable
        assertEquals(id, newStore(prefs).identity())
    }

    @Test
    fun aLostEpochIsDetected() {
        val prefs = FakeSharedPreferences()
        val old = newStore(prefs).identity()
        prefs.data.remove("epoch_id")
        val reloaded = newStore(prefs)
        assertEquals("missing_epoch", reloaded.identityChangeReason)
        assertTrue(old.epochId != reloaded.identity().epochId)
        assertTrue(reloaded.identity().resetGeneration > old.resetGeneration)
    }

    @Test
    fun anUpgradeFromTheOldFormatKeepsTheTotalsAndStartsAnIdentity() {
        val prefs = FakeSharedPreferences()
        prefs.data["total_distance_bits"] = 1234.5.toBits()
        prefs.data["total_fuel_bits"] = 70.25.toBits()
        prefs.data["total_duration_sec"] = 9000L
        val store = newStore(prefs)
        assertEquals(1234.5, store.snapshot().totalDistanceKm, 1e-12)
        assertEquals(70.25, store.snapshot().totalFuelLiters, 1e-12)
        assertEquals(1L, store.identity().resetGeneration)
        assertEquals("new_identity", store.identityChangeReason)
    }

    @Test
    fun normalUpdatesNeverChangeTheIdentity() {
        val prefs = FakeSharedPreferences()
        val store = newStore(prefs)
        val id = store.identity()
        store.update(driveSnapshot(token = 1L), force = true)
        store.update(driveSnapshot(token = 2L, distanceKm = 3.0, fuelL = 0.2), force = true)
        store.rebase(driveSnapshot(token = 3L, distanceKm = 1.0, fuelL = 0.05))
        assertEquals(id, store.identity())
        assertEquals(id.epochId, prefs.getString("epoch_id", null))
        assertEquals(id.resetGeneration, prefs.getLong("reset_generation", 0L))
    }

    @Test
    fun theInstallIdComesFromTheSeparateProvider() {
        val prefs = FakeSharedPreferences()
        assertEquals("install-A", newStore(prefs, "install-A").identity().installId)
        assertEquals("install-B", newStore(prefs, "install-B").identity().installId)
        assertNotNull(prefs.getString("epoch_id", null))
    }
}
