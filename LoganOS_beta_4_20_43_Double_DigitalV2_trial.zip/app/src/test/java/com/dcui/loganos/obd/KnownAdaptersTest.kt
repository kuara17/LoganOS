package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 3.3 / B6: only known adapters are ever connected to automatically. */
class KnownAdaptersTest {

    @Test
    fun theMostRecentSuccessComesFirst() {
        val k = KnownAdapters().record("AA:AA", "Car").record("BB:BB", "Spare").record("AA:AA", "Car")
        assertEquals(listOf("AA:AA", "BB:BB"), k.candidates(null))
    }

    @Test
    fun anUnknownSelectedAdapterIsTriedFirstOthersFollowByRecency() {
        val k = KnownAdapters().record("AA:AA", "Car").record("BB:BB", "Spare")
        assertEquals(listOf("CC:CC", "BB:BB", "AA:AA"), k.candidates("cc:cc"))
    }

    @Test
    fun aKnownSelectedAdapterDoesNotJumpTheQueue() {
        val k = KnownAdapters().record("AA:AA", "Car").record("BB:BB", "Spare")
        assertEquals(listOf("BB:BB", "AA:AA"), k.candidates("AA:AA"))
    }

    @Test
    fun attemptsRotateThroughTheCandidates() {
        val k = KnownAdapters().record("AA:AA", "Car").record("BB:BB", "Spare")
        assertEquals(listOf("BB:BB", "AA:AA", "BB:BB", "AA:AA"), (0..3).map { k.pick(it, null) })
    }

    @Test
    fun nothingKnownAndNothingSelectedMeansNoCandidate() {
        assertNull(KnownAdapters().pick(0, null))
        assertTrue(KnownAdapters().candidates(null).isEmpty())
    }

    @Test
    fun theListIsCapped() {
        var k = KnownAdapters()
        for (i in 1..8) k = k.record("AA:0$i", "A$i")
        assertEquals(KnownAdapters.MAX_ENTRIES, k.entries.size)
        assertEquals("AA:08", k.candidates(null).first())
    }

    @Test
    fun encodeDecodeRoundTrips() {
        val k = KnownAdapters().record("AA:AA", "Car").record("BB:BB", "Spare")
        assertEquals(k, KnownAdapters.decode(k.encode()))
    }

    @Test
    fun junkAndControlCharactersAreHandled() {
        assertTrue(KnownAdapters.decode(null).entries.isEmpty())
        assertTrue(KnownAdapters.decode("garbage").entries.isEmpty())
        assertTrue(KnownAdapters.decode("AA\tname\tnot-a-number").entries.isEmpty())
        val k = KnownAdapters().record("AA:AA", "bad\tname\nwith\rcontrol")
        assertEquals("bad name with control", k.nameOf("aa:aa"))
        assertEquals(k, KnownAdapters.decode(k.encode()))
    }
}
