package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/**
 * Characterization tests written against 4.20.37 BEFORE the Stage 1 changes. They still pass:
 * Stage 1 only adds idle-fuel counting while the engine is confirmed running (see
 * TripComputerIdleFuelTest). Without an engine-running signal the old behaviour is unchanged.
 * The live smoothed average inside TripComputer is untouched; history now derives its average
 * from fuel and distance instead (TripAverageRulesTest).
 */
class TripComputerCharacterizationTest {

    private class Clock(var nowMs: Long = 0L)

    private fun TripComputer.drive(
        clock: Clock,
        seconds: Int,
        speedKmh: Double?,
        fuelLh: Double?
    ): TripComputerSnapshot {
        var last = snapshot(clock.nowMs)
        repeat(seconds) {
            clock.nowMs += 1000L
            last = update(speedKmh, fuelLh, clock.nowMs)
        }
        return last
    }

    private fun newComputer(clock: Clock): TripComputer =
        TripComputer().also { it.reset(clock.nowMs) }

    @Test
    fun idleBeforeFirstMovementIsNotCountedWhenEngineStateIsUnknown() {
        val clock = Clock()
        val tc = newComputer(clock)
        val snap = tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals("WAITING", snap.state)
        assertEquals(0.0, snap.distanceKm, 1e-12)
        assertEquals(0.0, snap.fuelUsedL, 1e-12)
        assertEquals(0.0, tc.exportState(clock.nowMs).pendingFuelL, 1e-12)
    }

    @Test
    fun creepingFramesBeforeStartStillCountTheirFuel() {
        val clock = Clock()
        val tc = newComputer(clock)
        tc.drive(clock, seconds = 10, speedKmh = 3.0, fuelLh = 1.0)
        val state = tc.exportState(clock.nowMs)
        assertEquals("WAITING", tc.snapshot(clock.nowMs).state)
        assertEquals(10 * 3.0 / 3600.0, state.pendingDistanceKm, 1e-12)
        assertEquals(10 * 1.0 / 3600.0, state.pendingFuelL, 1e-12)
    }

    @Test
    fun tripStartFoldsPendingValuesAndCurrentFrameIntoTotals() {
        val clock = Clock()
        val tc = newComputer(clock)
        tc.drive(clock, seconds = 10, speedKmh = 3.0, fuelLh = 1.0)
        val snap = tc.drive(clock, seconds = 1, speedKmh = 10.0, fuelLh = 1.0)
        assertEquals("CALCULATING", snap.state)
        assertEquals(10 * 3.0 / 3600.0 + 10.0 / 3600.0, snap.distanceKm, 1e-12)
        assertEquals(10 * 1.0 / 3600.0 + 1.0 / 3600.0, snap.fuelUsedL, 1e-12)
        val state = tc.exportState(clock.nowMs)
        assertEquals(0.0, state.pendingDistanceKm, 1e-12)
        assertEquals(0.0, state.pendingFuelL, 1e-12)
    }

    @Test
    fun averageStaysCalculatingUntilOneKilometre() {
        val clock = Clock()
        val tc = newComputer(clock)
        val early = tc.drive(clock, seconds = 30, speedKmh = 60.0, fuelLh = 3.0)
        assertEquals("CALCULATING", early.state)
        assertNull(early.averageL100)
        val later = tc.drive(clock, seconds = 40, speedKmh = 60.0, fuelLh = 3.0)
        assertEquals("ACTIVE", later.state)
        assertNotNull(later.averageL100)
        // 3 L/h at 60 km/h is 5 L/100 km; a constant rate must not be distorted.
        assertEquals(5.0, later.averageL100!!, 1e-6)
    }

    @Test
    fun stopsAfterTripStartAreCounted() {
        val clock = Clock()
        val tc = newComputer(clock)
        val moving = tc.drive(clock, seconds = 70, speedKmh = 60.0, fuelLh = 3.0)
        val stopped = tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 0.8)
        assertEquals(moving.distanceKm, stopped.distanceKm, 1e-12)
        assertEquals(moving.fuelUsedL + 60 * 0.8 / 3600.0, stopped.fuelUsedL, 1e-9)
    }

    @Test
    fun liveSmoothedAverageStillLagsFuelOverDistance() {
        val clock = Clock()
        val tc = newComputer(clock)
        tc.drive(clock, seconds = 70, speedKmh = 60.0, fuelLh = 3.0)
        val snap = tc.drive(clock, seconds = 60, speedKmh = 0.0, fuelLh = 3.0)
        val raw = snap.fuelUsedL / snap.distanceKm * 100.0
        val smoothed = snap.averageL100!!
        assertTrue("smoothed value must differ from fuel/distance", abs(raw - smoothed) > 0.05)
        assertTrue("smoothed value lags behind a rising ratio", smoothed < raw)
    }

    @Test
    fun gapsLongerThanTenSecondsAreDiscarded() {
        val clock = Clock()
        val tc = newComputer(clock)
        val before = tc.drive(clock, seconds = 20, speedKmh = 60.0, fuelLh = 3.0)
        clock.nowMs += 15_000L
        val after = tc.update(60.0, 3.0, clock.nowMs)
        assertEquals(before.distanceKm, after.distanceKm, 1e-12)
        assertEquals(before.fuelUsedL, after.fuelUsedL, 1e-12)
    }

    @Test
    fun missingFuelValueCountsDistanceButNoFuel() {
        val clock = Clock()
        val tc = newComputer(clock)
        val snap = tc.drive(clock, seconds = 30, speedKmh = 60.0, fuelLh = null)
        assertEquals(30 * 60.0 / 3600.0, snap.distanceKm, 1e-9)
        assertEquals(0.0, snap.fuelUsedL, 1e-12)
    }

    @Test
    fun exportAndRestoreKeepPendingAndTotals() {
        val clock = Clock()
        val tc = newComputer(clock)
        tc.drive(clock, seconds = 10, speedKmh = 3.0, fuelLh = 1.0)
        val saved = tc.exportState(clock.nowMs)
        val restored = TripComputer()
        restored.restore(saved, clock.nowMs)
        val again = restored.exportState(clock.nowMs)
        assertEquals(saved.pendingDistanceKm, again.pendingDistanceKm, 1e-12)
        assertEquals(saved.pendingFuelL, again.pendingFuelL, 1e-12)
        assertEquals(saved.totalDistanceKm, again.totalDistanceKm, 1e-12)
        assertEquals(saved.totalFuelL, again.totalFuelL, 1e-12)
        assertEquals(saved.tripToken, again.tripToken)
    }
}
