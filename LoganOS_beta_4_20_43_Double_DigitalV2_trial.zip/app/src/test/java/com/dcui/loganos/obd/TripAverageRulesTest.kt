package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Stage 1.3 / Y2: the stored/history average is fuel over distance, not a smoothed value. */
class TripAverageRulesTest {

    @Test
    fun derivedAverageIsFuelOverDistance() {
        assertEquals(5.0, TripAverageRules.derivedAverageL100(fuelLiters = 10.0, distanceKm = 200.0)!!, 1e-12)
    }

    @Test
    fun belowTheMinimumDistanceThereIsNoAverage() {
        assertNull(TripAverageRules.derivedAverageL100(0.05, 0.9))
        assertEquals(TripAverageRules.MIN_DISTANCE_KM, 1.0, 0.0)
    }

    @Test
    fun noFuelOrNonFiniteValuesGiveNoAverage() {
        assertNull(TripAverageRules.derivedAverageL100(0.0, 50.0))
        assertNull(TripAverageRules.derivedAverageL100(Double.NaN, 50.0))
        assertNull(TripAverageRules.derivedAverageL100(5.0, Double.POSITIVE_INFINITY))
    }

    @Test
    fun distanceWeightedAverageOfDerivedValuesEqualsTotalFuelOverTotalDistance() {
        val trips = listOf(10.0 to 100.0, 3.0 to 30.0, 1.0 to 5.0)   // fuel, distance
        val weighted = trips.sumOf { (f, d) -> TripAverageRules.derivedAverageL100(f, d)!! * d } /
            trips.sumOf { it.second }
        val total = trips.sumOf { it.first } / trips.sumOf { it.second } * 100.0
        assertEquals(total, weighted, 1e-9)
    }
}
