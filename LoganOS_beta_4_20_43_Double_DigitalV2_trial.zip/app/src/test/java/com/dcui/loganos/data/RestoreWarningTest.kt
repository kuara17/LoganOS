package com.dcui.loganos.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 5 / M2: the warning shown before a restore. */
class RestoreWarningTest {
    private val backup = MaintenanceCounts(serviceVisits = 4, calibrationRuns = 2, odometerAnchors = 1)

    @Test
    fun showsBothSidesAndWarnsWhenTheDeviceHoldsNewerRecords() {
        val text = RestoreWarning.text(backup, MaintenanceCounts(7, 2, 1), turkish = true)
        assertTrue(text.contains("Yedekte: 4 servis kaydı"))
        assertTrue(text.contains("Bu cihazda şimdi: 7 servis kaydı"))
        assertTrue(text.contains("kaybolur"))
        assertTrue(text.contains("TÜM"))
    }

    @Test
    fun noWarningWhenTheBackupHoldsEverythingTheDeviceHas() {
        val text = RestoreWarning.text(backup, MaintenanceCounts(4, 2, 1), turkish = true)
        assertFalse(text.contains("kaybolur"))
        val older = RestoreWarning.text(backup, MaintenanceCounts(1, 0, 0), turkish = true)
        assertFalse(older.contains("kaybolur"))
    }

    @Test
    fun aMissingDeviceCountSimplyOmitsThatLine() {
        val text = RestoreWarning.text(backup, null, turkish = true)
        assertFalse(text.contains("Bu cihazda şimdi"))
        assertTrue(text.contains("Yedekte"))
    }

    @Test
    fun anOldBackupWithoutMaintenanceDataShowsZeros() {
        val text = RestoreWarning.text(MaintenanceCounts(0, 0, 0), MaintenanceCounts(3, 1, 0), turkish = false)
        assertTrue(text.contains("In the backup: 0 service visits"))
        assertTrue(text.contains("will be lost"))
    }
}
