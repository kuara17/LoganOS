package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Test

/** Stage 4 / K2: pure identity rules and the install id. */
class CockpitTripIdentityTest {

    private var counter = 0
    private fun uuid() = "epoch-${++counter}"

    @Test
    fun aBrandNewInstallStartsAtGenerationOne() {
        val r = CockpitTripIdentityResolver.resolve(null, null, false, ::uuid)
        assertEquals(1L, r.resetGeneration)
        assertEquals("epoch-1", r.epochId)
        assertEquals("new_identity", r.changeReason)
    }

    @Test
    fun anUnchangedFileKeepsItsIdentity() {
        val r = CockpitTripIdentityResolver.resolve("abc", 7L, false, ::uuid)
        assertEquals("abc", r.epochId)
        assertEquals(7L, r.resetGeneration)
        assertNull(r.changeReason)
        assertEquals(0, counter)
    }

    @Test
    fun aMissingEpochOnAnExistingGenerationCountsAsALoss() {
        val r = CockpitTripIdentityResolver.resolve(null, 4L, false, ::uuid)
        assertEquals(5L, r.resetGeneration)
        assertEquals("epoch-1", r.epochId)
        assertEquals("missing_epoch", r.changeReason)
    }

    @Test
    fun aMissingGenerationKeepsTheEpochAndRestartsAtOne() {
        val r = CockpitTripIdentityResolver.resolve("abc", null, false, ::uuid)
        assertEquals("abc", r.epochId)
        assertEquals(1L, r.resetGeneration)
        assertEquals("missing_generation", r.changeReason)
    }

    @Test
    fun repairedTotalsRenewTheEpochAndBumpTheGeneration() {
        val r = CockpitTripIdentityResolver.resolve("abc", 3L, true, ::uuid)
        assertEquals("epoch-1", r.epochId)
        assertEquals(4L, r.resetGeneration)
        assertEquals("totals_repaired", r.changeReason)
    }

    @Test
    fun anInvalidStoredGenerationIsTreatedAsMissing() {
        assertEquals(1L, CockpitTripIdentityResolver.resolve("abc", 0L, false, ::uuid).resetGeneration)
        assertEquals(1L, CockpitTripIdentityResolver.resolve("abc", -5L, false, ::uuid).resetGeneration)
    }

    @Test
    fun theInstallIdIsCreatedOnceAndThenStable() {
        val prefs = FakeSharedPreferences()
        var created = 0
        val first = InstallIdentity.get(prefs) { "install-${++created}" }
        val second = InstallIdentity.get(prefs) { "install-${++created}" }
        assertEquals("install-1", first)
        assertEquals(first, second)
        assertEquals(1, created)
        assertEquals(1, prefs.commitCount)
    }

    @Test
    fun differentInstallsGetDifferentIds() {
        val a = InstallIdentity.get(FakeSharedPreferences()) { "A" }
        val b = InstallIdentity.get(FakeSharedPreferences()) { "B" }
        assertFalse(a == b)
    }

    @Test
    fun needsRepairDetectsEveryDamagedField() {
        assertFalse(PersistentCockpitTripState(totalDistanceKm = 5.0, totalFuelLiters = 0.3).needsRepair())
        assertTrue(PersistentCockpitTripState(totalDistanceKm = Double.NaN).needsRepair())
        assertTrue(PersistentCockpitTripState(totalFuelLiters = -1.0).needsRepair())
        assertTrue(PersistentCockpitTripState(totalDurationSec = -1L).needsRepair())
        assertTrue(PersistentCockpitTripState(lastTripDistanceKm = Double.POSITIVE_INFINITY).needsRepair())
        assertTrue(PersistentCockpitTripState(lastTripFuelLiters = Double.NaN).needsRepair())
        assertTrue(PersistentCockpitTripState(lastTripDurationSec = -9L).needsRepair())
    }
}
