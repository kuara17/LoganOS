package com.dcui.loganos.obd

import android.content.SharedPreferences

/** In-memory SharedPreferences for unit tests. Edits only become visible on commit()/apply(). */
class FakeSharedPreferences : SharedPreferences {
    val data = linkedMapOf<String, Any?>()
    var commitCount = 0
        private set
    var applyCount = 0
        private set

    /** A copy of the stored values after each commit()/apply(), in order. */
    val writes = mutableListOf<Map<String, Any?>>()

    override fun getAll(): MutableMap<String, *> = LinkedHashMap(data)
    override fun getString(key: String?, defValue: String?): String? = if (data.containsKey(key)) data[key] as? String else defValue
    override fun getStringSet(key: String?, defValues: MutableSet<String>?): MutableSet<String>? = defValues
    override fun getInt(key: String?, defValue: Int): Int = (data[key] as? Int) ?: defValue
    override fun getLong(key: String?, defValue: Long): Long = (data[key] as? Long) ?: defValue
    override fun getFloat(key: String?, defValue: Float): Float = (data[key] as? Float) ?: defValue
    override fun getBoolean(key: String?, defValue: Boolean): Boolean = (data[key] as? Boolean) ?: defValue
    override fun contains(key: String?): Boolean = data.containsKey(key)
    override fun edit(): SharedPreferences.Editor = Editor()
    override fun registerOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) = Unit
    override fun unregisterOnSharedPreferenceChangeListener(listener: SharedPreferences.OnSharedPreferenceChangeListener?) = Unit

    private inner class Editor : SharedPreferences.Editor {
        private val pending = linkedMapOf<String, Any?>()
        private val removals = mutableSetOf<String>()
        private var clearAll = false

        override fun putString(key: String?, value: String?): SharedPreferences.Editor = put(key, value)
        override fun putStringSet(key: String?, values: MutableSet<String>?): SharedPreferences.Editor = put(key, values)
        override fun putInt(key: String?, value: Int): SharedPreferences.Editor = put(key, value)
        override fun putLong(key: String?, value: Long): SharedPreferences.Editor = put(key, value)
        override fun putFloat(key: String?, value: Float): SharedPreferences.Editor = put(key, value)
        override fun putBoolean(key: String?, value: Boolean): SharedPreferences.Editor = put(key, value)
        override fun remove(key: String?): SharedPreferences.Editor { key?.let { removals += it; pending.remove(it) }; return this }
        override fun clear(): SharedPreferences.Editor { clearAll = true; return this }

        private fun put(key: String?, value: Any?): SharedPreferences.Editor {
            if (key != null) { pending[key] = value; removals -= key }
            return this
        }

        private fun write() {
            if (clearAll) data.clear()
            removals.forEach { data.remove(it) }
            data.putAll(pending)
            writes += LinkedHashMap(data)
        }

        override fun commit(): Boolean { write(); commitCount++; return true }
        override fun apply() { write(); applyCount++ }
    }
}
