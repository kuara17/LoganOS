package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 2.2 / B2-B3: socket method order and limits. */
class SocketMethodPlannerTest {

    @Test
    fun aNeverConnectedAdapterTriesTheWholeChainInOrder() {
        assertEquals(
            listOf(SocketMethod.SECURE, SocketMethod.INSECURE, SocketMethod.REFLECT_PORT_1),
            SocketMethodPlanner.plan(null)
        )
    }

    @Test
    fun aRememberedMethodIsUsedAlone_soWorkingSetupsBehaveAsBefore() {
        for (method in SocketMethod.values()) {
            assertEquals(listOf(method), SocketMethodPlanner.plan(method))
        }
    }

    @Test
    fun storedNamesRoundTripAndUnknownValuesAreIgnored() {
        for (method in SocketMethod.values()) {
            assertEquals(method, SocketMethodPlanner.parse(method.storedName))
        }
        assertNull(SocketMethodPlanner.parse(null))
        assertNull(SocketMethodPlanner.parse("something-else"))
    }

    @Test
    fun firstAttemptGetsTheLongLimitAndFallbacksTheShortOne() {
        assertEquals(SocketMethodPlanner.PRIMARY_ATTEMPT_TIMEOUT_MS, SocketMethodPlanner.timeoutFor(0))
        assertEquals(SocketMethodPlanner.FALLBACK_ATTEMPT_TIMEOUT_MS, SocketMethodPlanner.timeoutFor(1))
        assertEquals(SocketMethodPlanner.FALLBACK_ATTEMPT_TIMEOUT_MS, SocketMethodPlanner.timeoutFor(2))
    }

    @Test
    fun singleAttemptPlansKeepTheOldThirtyTwoSecondLimit() {
        assertEquals(32_000L, SocketMethodPlanner.outerTimeoutMs(SocketMethodPlanner.plan(SocketMethod.SECURE)))
    }

    @Test
    fun theFallbackChainExtendsTheOuterLimitByItsExtraAttempts() {
        val chain = SocketMethodPlanner.plan(null)
        assertEquals(32_000L + 2 * SocketMethodPlanner.FALLBACK_ATTEMPT_TIMEOUT_MS, SocketMethodPlanner.outerTimeoutMs(chain))
    }

    @Test
    fun theFirstAttemptLeavesRoomForTheElmInitInsideTheOldLimit() {
        assertTrue(SocketMethodPlanner.PRIMARY_ATTEMPT_TIMEOUT_MS < SocketMethodPlanner.BASE_CONNECT_AND_INIT_TIMEOUT_MS)
    }
}
