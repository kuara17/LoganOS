package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 1.4 / Y4: data coverage of a calibration measurement. */
class FuelCalibrationCoverageTest {

    @Test
    fun ratioIsAppDistanceOverVehicleDistance() {
        assertEquals(0.92, FuelCalibrationCoverage.ratio(184.0, 200.0)!!, 1e-12)
    }

    @Test
    fun ratioIsNullWhenEitherSideIsMissingOrInvalid() {
        assertNull(FuelCalibrationCoverage.ratio(null, 200.0))
        assertNull(FuelCalibrationCoverage.ratio(184.0, null))
        assertNull(FuelCalibrationCoverage.ratio(184.0, 0.0))
        assertNull(FuelCalibrationCoverage.ratio(-1.0, 200.0))
        assertNull(FuelCalibrationCoverage.ratio(Double.NaN, 200.0))
    }

    @Test
    fun noWarningIsRaisedUntilAThresholdIsApproved() {
        assertNull(FuelCalibrationCoverage.WARN_BELOW_RATIO)
        assertFalse(FuelCalibrationCoverage.isLow(0.10))
    }

    @Test
    fun aConfiguredThresholdWarnsBelowItOnly() {
        assertTrue(FuelCalibrationCoverage.isLow(0.80, warnBelow = 0.90))
        assertFalse(FuelCalibrationCoverage.isLow(0.95, warnBelow = 0.90))
        assertFalse(FuelCalibrationCoverage.isLow(null, warnBelow = 0.90))
    }
}
