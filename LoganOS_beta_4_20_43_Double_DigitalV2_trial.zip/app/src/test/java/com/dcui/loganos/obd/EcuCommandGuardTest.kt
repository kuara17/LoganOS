package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 2.1 / B1: the approved read-only command set. */
class EcuCommandGuardTest {

    private fun allowed(command: String) {
        val decision = EcuCommandGuard.check(command)
        assertTrue("expected <$command> to be allowed but was $decision", decision is EcuCommandGuard.Decision.Allowed)
    }

    private fun blocked(command: String) {
        val decision = EcuCommandGuard.check(command)
        assertTrue("expected <$command> to be blocked but was $decision", decision is EcuCommandGuard.Decision.Blocked)
    }

    /** Every command the app really sends today (inventory of ObdController, 4.20.38). */
    @Test
    fun everyCommandTheAppSendsTodayIsAllowed() {
        listOf(
            "ATZ", "ATE0", "ATL0", "ATS1", "ATH1", "ATSP0", "ATSP5", "ATFI", "ATRV",
            "ATIIA7A", "ATWM817AF1", "ATSH817AF1",
            "ATIIA51", "ATWM8151F1", "ATSH8151F1",           // KWP target addresses built from a hex byte
            "10C0",
            "1A80", "1A81", "1A87", "1A90", "1A91", "1A92",
            "2180", "21A0", "21A2", "21CC", "21CD",
            "0100", "0120", "0140", "0160",
            "010C", "010D", "0105", "010B", "010F", "0111", "0104", "0103", "0106", "0107", "0110", "0144", "015E"
        ).forEach { allowed(it) }
    }

    @Test
    fun everyLocalIdentifierAndPidReadIsAllowed() {
        for (value in 0..255) {
            val hex = "%02X".format(value)
            allowed("21$hex")
            allowed("01$hex")
        }
    }

    @Test
    fun emptyCommandsAndSpacingAndCaseAreHandled() {
        allowed("")
        allowed("   ")
        allowed("21 A0")
        allowed("21a0")
        allowed(" atfi ")
    }

    @Test
    fun writeControlAndResetServicesAreBlocked() {
        listOf(
            "04", "0401", "08", "0800",
            "1081", "10C1", "1002", "10",
            "1101", "11",
            "14FF00", "14",
            "2701", "2702",
            "2E1234", "2F0101", "3101", "3102",
            "3401", "3501", "3601", "3701",
            "3B80", "3D000000"
        ).forEach { blocked(it) }
    }

    @Test
    fun adapterReconfigurationCommandsAreBlocked() {
        listOf("ATPP01SV00", "ATPP FF OFF", "ATBRD23", "ATBRT20", "atpp 0C sv 62").forEach { blocked(it) }
    }

    @Test
    fun malformedRequestsAreBlocked() {
        listOf("ZZ", "21A", "2", "0x21A0", "21G0", "21A0A0").forEach { blocked(it) }
    }

    @Test
    fun theReasonNamesTheRefusedService() {
        val decision = EcuCommandGuard.check("2E1234") as EcuCommandGuard.Decision.Blocked
        assertTrue(decision.reason.contains("0x2E"))
        assertTrue(decision.reason.contains("write"))
        val reset = EcuCommandGuard.check("1101") as EcuCommandGuard.Decision.Blocked
        assertTrue(reset.reason.contains("ECU reset"))
    }

    @Test
    fun kindsAreReported() {
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.KWP_SESSION_START), EcuCommandGuard.check("10C0"))
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.ELM_AT), EcuCommandGuard.check("ATSH817AF1"))
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.OBD_CURRENT_DATA), EcuCommandGuard.check("010C"))
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.KWP_READ_LOCAL_ID), EcuCommandGuard.check("21A0"))
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.KWP_READ_IDENTIFICATION), EcuCommandGuard.check("1A87"))
        assertEquals(EcuCommandGuard.Decision.Allowed(EcuCommandGuard.Kind.EMPTY), EcuCommandGuard.check(""))
    }
}
