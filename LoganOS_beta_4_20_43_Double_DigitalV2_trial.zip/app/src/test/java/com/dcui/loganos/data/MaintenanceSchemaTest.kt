package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 5 / M1: the v7 schema is internally consistent and safe by construction. */
class MaintenanceSchemaTest {

    private data class Parsed(val name: String, val type: String, val notNull: Boolean, val pk: Boolean)

    /** Reads the generated CREATE TABLE back into columns (what SQLite's table_info would report). */
    private fun parse(sql: String): List<Parsed> {
        val body = sql.substringAfter("(\n").substringBeforeLast("\n)")
        return body.split(",\n").map { it.trim() }
            .filterNot { it.startsWith("FOREIGN KEY") }
            .map { line ->
                val tokens = line.split(" ")
                Parsed(
                    name = tokens[0],
                    type = tokens[1],
                    notNull = line.contains("NOT NULL"),
                    pk = line.contains("PRIMARY KEY")
                )
            }
    }

    @Test
    fun theVersionAndTableSetAreTheAgreedOnes() {
        assertEquals(7, MaintenanceSchema.VERSION)
        assertEquals(
            setOf("maintenance_items", "service_visits", "service_lines", "odometer_anchors", "calibration_runs"),
            MaintenanceSchema.tables.keys
        )
        assertEquals(MaintenanceSchema.tables.keys, MaintenanceSchema.protectedTables)
    }

    @Test
    fun generatedSqlMatchesTheDeclaredColumnsExactly() {
        MaintenanceSchema.tables.forEach { (table, columns) ->
            val parsed = parse(MaintenanceSchema.createTableSql(table))
            assertEquals("columns of $table", columns.map { it.name }, parsed.map { it.name })
            columns.zip(parsed).forEach { (declared, actual) ->
                assertEquals("type of $table.${declared.name}", declared.type, actual.type)
                assertEquals("not-null of $table.${declared.name}", declared.notNull, actual.notNull)
                assertEquals("pk of $table.${declared.name}", declared.primaryKey, actual.pk)
            }
        }
    }

    @Test
    fun everyTableHasAnAutoIncrementIdAndNoDuplicateColumns() {
        MaintenanceSchema.tables.forEach { (table, columns) ->
            assertEquals("id", columns.first().name)
            assertTrue(columns.first().primaryKey)
            assertTrue(MaintenanceSchema.createTableSql(table).contains("id INTEGER PRIMARY KEY AUTOINCREMENT"))
            assertEquals("duplicate column in $table", columns.size, columns.map { it.name }.toSet().size)
        }
    }

    @Test
    fun moneyIsAlwaysWholeMinorUnits_neverAFloat() {
        val moneyColumns = MaintenanceSchema.tables.values.flatten().filter { it.name.contains("cost") }
        assertTrue(moneyColumns.isNotEmpty())
        moneyColumns.forEach {
            assertTrue("${it.name} must end in _minor", it.name.endsWith("_minor"))
            assertEquals("${it.name} must be INTEGER", "INTEGER", it.type)
        }
        assertEquals("INTEGER", MaintenanceSchema.tripRecordColumns.first { it.name == "fuel_price_per_liter_minor" }.type)
    }

    @Test
    fun noTotalIsStored_itIsPartsPlusLabor() {
        val all = MaintenanceSchema.tables.values.flatten().map { it.name }
        assertFalse(all.any { it.startsWith("total") || it.endsWith("_total") || it == "total_cost_minor" })
        assertTrue(all.containsAll(listOf("parts_cost_minor", "labor_cost_minor")))
    }

    @Test
    fun dueCountersAreNeverStored_theyAreDerivedFromServiceLines() {
        val itemColumns = MaintenanceSchema.tables.getValue("maintenance_items").map { it.name }
        listOf("last_service_km", "last_service_date", "next_km", "next_date", "remaining_km", "remaining_days", "status")
            .forEach { assertFalse("$it must not be stored", it in itemColumns) }
    }

    @Test
    fun theHistoricalIntervalOnAServiceLineIsInformationOnly() {
        val lineColumns = MaintenanceSchema.tables.getValue("service_lines")
        assertFalse(lineColumns.first { it.name == "interval_km_at_service" }.notNull)
        assertFalse(lineColumns.first { it.name == "interval_months_at_service" }.notNull)
    }

    @Test
    fun anItemMayHaveNoIntervalYet_soNoCheckConstraintExists() {
        val items = MaintenanceSchema.tables.getValue("maintenance_items")
        assertFalse(items.first { it.name == "km_interval" }.notNull)
        assertFalse(items.first { it.name == "month_interval" }.notNull)
        MaintenanceSchema.createTableStatements.forEach { assertFalse(it.contains("CHECK")) }
        assertTrue(MaintenanceSchema.createTableSql("maintenance_items").contains("item_key TEXT NOT NULL UNIQUE"))
    }

    @Test
    fun deletingAVisitRemovesItsLinesButAnItemWithHistoryCannotBeDeleted() {
        val sql = MaintenanceSchema.createTableSql("service_lines")
        assertTrue(sql.contains("FOREIGN KEY(visit_id) REFERENCES service_visits(id) ON DELETE CASCADE"))
        assertTrue(sql.contains("FOREIGN KEY(item_id) REFERENCES maintenance_items(id) ON DELETE RESTRICT"))
    }

    @Test
    fun foreignKeysAndIndexesPointAtRealColumns() {
        MaintenanceSchema.foreignKeys.forEach { (table, keys) ->
            val columns = MaintenanceSchema.tables.getValue(table).map { it.name }
            keys.forEach { key ->
                assertTrue(key.column in columns)
                val ref = MaintenanceSchema.tables.getValue(key.refTable).map { it.name }
                assertTrue(key.refColumn in ref)
            }
        }
        MaintenanceSchema.indexes.forEach { index ->
            val columns = MaintenanceSchema.tables.getValue(index.table).map { it.name }
            assertTrue(index.columns.all { it in columns })
        }
        assertEquals(MaintenanceSchema.indexes.size, MaintenanceSchema.indexes.map { it.name }.toSet().size)
    }

    @Test
    fun everyStatementIsIdempotentAndTripRecordsOnlyGetNullableColumns() {
        MaintenanceSchema.createTableStatements.forEach { assertTrue(it.startsWith("CREATE TABLE IF NOT EXISTS")) }
        MaintenanceSchema.createIndexStatements.forEach { assertTrue(it.startsWith("CREATE INDEX IF NOT EXISTS")) }
        assertEquals(listOf("fuel_price_per_liter_minor", "calibration_factor"), MaintenanceSchema.tripRecordColumns.map { it.name })
        MaintenanceSchema.tripRecordColumns.forEach {
            assertFalse("${it.name} must be nullable so old rows stay valid", it.notNull)
            assertEquals("ALTER TABLE trip_records ADD COLUMN ${it.name} ${it.type}", MaintenanceSchema.addTripRecordColumnSql(it))
        }
    }
}
