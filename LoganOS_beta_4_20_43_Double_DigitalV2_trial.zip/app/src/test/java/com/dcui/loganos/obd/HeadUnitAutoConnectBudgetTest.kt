package com.dcui.loganos.obd

import com.dcui.loganos.obd.HeadUnitAutoConnectBudget.Decision
import com.dcui.loganos.obd.HeadUnitAutoConnectBudget.StopReason
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 3.2 / B7-B8: the automatic connection is always bounded. */
class HeadUnitAutoConnectBudgetTest {

    private fun HeadUnitAutoConnectBudget.waitFor(startMs: Long, seconds: Long): Long {
        // advance in 1 s steps and return the first time a non-wait decision happens
        var t = startMs
        repeat((seconds + 1).toInt()) {
            val d = decide(t, false)
            if (d !is Decision.Wait) return t
            t += 1000
        }
        return -1L
    }

    @Test
    fun firstAttemptComesAfterTheInitialDelay() {
        val b = HeadUnitAutoConnectBudget()
        assertEquals(Decision.Wait, b.decide(0, false))
        assertEquals(Decision.Wait, b.decide(1_999, false))
        assertEquals(Decision.Attempt(1, 6), b.decide(2_000, false))
    }

    @Test
    fun attemptsBackOffAndStopAtTheDropLimit() {
        val b = HeadUnitAutoConnectBudget()
        var now = 0L
        val numbers = mutableListOf<Int>()
        var stop: Decision? = null
        while (stop == null && now < 24 * 3_600_000L) {
            when (val d = b.decide(now, false)) {
                is Decision.Attempt -> { numbers += d.number; b.onBusy(); now += 1_000 } // attempt runs, then fails
                is Decision.Stop -> stop = d
                Decision.Wait -> now += 1_000
            }
        }
        assertEquals(listOf(1, 2, 3, 4, 5, 6), numbers)
        assertTrue(stop is Decision.Stop)
    }

    @Test
    fun theDropWindowStopsTheLoop() {
        val b = HeadUnitAutoConnectBudget(perDropWindowMs = 60_000L, backoffMs = listOf(30_000L))
        var now = 0L
        var stop: Decision.Stop? = null
        while (stop == null && now < 3_600_000L) {
            val d = b.decide(now, false)
            if (d is Decision.Attempt) b.onBusy()
            if (d is Decision.Stop) stop = d
            now += 1_000
        }
        assertEquals(StopReason.DROP_WINDOW_EXPIRED, stop!!.reason)
    }

    @Test
    fun theSessionBudgetIsHonouredAcrossDrops() {
        val b = HeadUnitAutoConnectBudget(sessionMaxAttempts = 3, perDropMaxAttempts = 2, initialDelayMs = 0, backoffMs = listOf(0L))
        var now = 0L
        var attempts = 0
        var reason: StopReason? = null
        repeat(10) {
            when (val d = b.decide(now, false)) {
                is Decision.Attempt -> { attempts++; b.onBusy() }
                is Decision.Stop -> if (reason == null) reason = d.reason
                Decision.Wait -> Unit
            }
            now += 1000
            // a good connection for a while refills the DROP budget, but never the session budget
            if (attempts == 2) { b.onDataFlowing(now); b.onDataFlowing(now + 31_000) }
        }
        assertEquals(3, attempts)
        assertEquals(StopReason.SESSION_BUDGET_EXHAUSTED, reason)
    }

    @Test
    fun anExpiredIgnitionWindowBlocksEveryAttempt() {
        val b = HeadUnitAutoConnectBudget()
        assertEquals(Decision.Stop(StopReason.IGNITION_OFF), b.decide(0, true))
        assertEquals(Decision.Stop(StopReason.IGNITION_OFF), b.decide(3 * 3_600_000L, true))
    }

    @Test
    fun hoursAfterTheBudgetIsSpentThereIsNeverAnotherAttempt() {
        val b = HeadUnitAutoConnectBudget()
        var now = 0L
        repeat(2_000) {
            val d = b.decide(now, false)
            if (d is Decision.Attempt) b.onBusy()
            now += 1_000
        }
        // 3 hours later, still idle: only Stop is possible
        for (hours in 1..3) {
            val d = b.decide(now + hours * 3_600_000L, false)
            assertTrue("expected Stop but was $d", d is Decision.Stop)
        }
    }

    @Test
    fun anOpenSocketWithoutDataDoesNotRefillTheDropBudget() {
        val b = HeadUnitAutoConnectBudget(initialDelayMs = 0, backoffMs = listOf(0L))
        assertEquals(Decision.Attempt(1, 6), b.decide(0, false))
        // socket open, ECU asleep: the loop reports "busy" for minutes, never "data flowing"
        repeat(200) { b.onBusy() }
        assertEquals(1, b.attemptsInDrop)
        assertEquals(1, b.sessionAttempts)
    }

    @Test
    fun stableDataRefillsTheDropBudgetButShortDataDoesNot() {
        val b = HeadUnitAutoConnectBudget(initialDelayMs = 0, backoffMs = listOf(0L))
        b.decide(0, false)
        assertEquals(1, b.attemptsInDrop)
        b.onDataFlowing(10_000)
        b.onDataFlowing(20_000)            // only 10 s of data
        assertEquals(1, b.attemptsInDrop)
        b.onDataFlowing(40_000)            // 30 s of data
        assertEquals(0, b.attemptsInDrop)
    }

    @Test
    fun statusLabelsAreLocalised() {
        assertEquals("Otomatik bağlanma: deneme 3/6", AutoConnectStatus.label(AutoConnectStatus.attempt(3, 6), true))
        assertEquals("Auto-connect: attempt 3/6", AutoConnectStatus.label(AutoConnectStatus.attempt(3, 6), false))
        assertEquals("Otomatik bağlanma: durdu (kontak kapalı)", AutoConnectStatus.label(AutoConnectStatus.stopped(StopReason.IGNITION_OFF), true))
        assertEquals("Auto-connect: stopped (ignition off)", AutoConnectStatus.label(AutoConnectStatus.stopped(StopReason.IGNITION_OFF), false))
        assertEquals("Otomatik bağlanma: bekliyor (Bluetooth kapalı)", AutoConnectStatus.label(AutoConnectStatus.waiting("BLUETOOTH_OFF"), true))
        assertEquals("", AutoConnectStatus.label(AutoConnectStatus.IDLE, true))
        assertEquals("", AutoConnectStatus.label("garbage", true))
    }

    @Test
    fun notReadyKeepsTheWindowRunningWithoutSpendingAttempts() {
        val b = HeadUnitAutoConnectBudget(perDropWindowMs = 60_000L)
        assertEquals(null, b.notReady(0, false))
        assertEquals(null, b.notReady(30_000, false))
        assertEquals(0, b.sessionAttempts)
        assertEquals(StopReason.DROP_WINDOW_EXPIRED, b.notReady(60_000, false))
    }

    @Test
    fun notReadyStillHonoursAnExpiredIgnitionWindow() {
        val b = HeadUnitAutoConnectBudget()
        assertEquals(StopReason.IGNITION_OFF, b.notReady(0, true))
    }

    @Test
    fun theInitialDelayRestartsOnceTheAdapterBecomesReady() {
        val b = HeadUnitAutoConnectBudget()
        b.notReady(0, false)
        assertEquals(Decision.Wait, b.decide(50_000, false))        // first idle moment: delay starts now
        assertEquals(Decision.Attempt(1, 6), b.decide(52_000, false))
    }
}
