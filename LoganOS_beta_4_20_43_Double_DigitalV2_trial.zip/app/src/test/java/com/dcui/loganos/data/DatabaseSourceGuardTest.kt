package com.dcui.loganos.data

import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Stage 5: "clear logs / clear drive data" must never touch maintenance or calibration data.
 * SQLite cannot run in a plain unit test, so this scans the SQL the store can execute.
 */
class DatabaseSourceGuardTest {

    private fun storeSource(): String {
        val candidates = listOf(
            "src/main/java/com/dcui/loganos/data/LoganSqlStore.kt",
            "app/src/main/java/com/dcui/loganos/data/LoganSqlStore.kt"
        )
        val file = candidates.map { File(it) }.firstOrNull { it.exists() }
            ?: error("LoganSqlStore.kt not found from ${File(".").absoluteFile}")
        return file.readText()
    }

    @Test
    fun noDeleteOrDropEverTargetsAProtectedTable() {
        val source = storeSource()
        val protected = MaintenanceSchema.protectedTables
        val deleteSql = Regex("(?i)DELETE\\s+FROM\\s+([a-z_]+)").findAll(source).map { it.groupValues[1].lowercase() }.toList()
        val dropSql = Regex("(?i)DROP\\s+TABLE\\s+(?:IF\\s+EXISTS\\s+)?([a-z_]+)").findAll(source).map { it.groupValues[1].lowercase() }.toList()
        val deleteApi = Regex("\\.delete\\(\\s*\"([a-z_]+)\"").findAll(source).map { it.groupValues[1].lowercase() }.toList()
        val offending = (deleteSql + dropSql + deleteApi).filter { it in protected }
        assertTrue("these statements would delete protected user data: $offending", offending.isEmpty())
    }

    @Test
    fun theScannerReallyFindsTheExistingDeleteStatements() {
        // Guards the guard: if the regexes matched nothing, the test above would prove nothing.
        val source = storeSource()
        val found = Regex("(?i)DELETE\\s+FROM\\s+([a-z_]+)").findAll(source).count() +
            Regex("\\.delete\\(\\s*\"([a-z_]+)\"").findAll(source).count()
        assertTrue("expected the store's existing delete statements to be found, found $found", found >= 3)
    }

    @Test
    fun theMigrationOnlyCreatesAndAlters_itNeverDropsOrRenames() {
        val migration = storeSource().substringAfter("private fun migrateToV7").substringBefore("private fun createStartEventsTable")
        assertTrue(!migration.contains("DROP", ignoreCase = true))
        assertTrue(!migration.contains("RENAME", ignoreCase = true))
        assertTrue(!migration.contains("DELETE", ignoreCase = true))
        assertTrue(migration.contains("columnNames(db, \"trip_records\")"))
    }
}
