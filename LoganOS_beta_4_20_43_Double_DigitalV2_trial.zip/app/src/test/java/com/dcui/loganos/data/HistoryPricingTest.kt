package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 5 / Y6: price and factor stored with a record, and the display cost rules. */
class HistoryPricingTest {

    @Test
    fun priceTextBecomesKurusPerLiter() {
        assertEquals(4235L, HistoryPricing.priceMinorPerLiter("42,35"))
        assertEquals(4235L, HistoryPricing.priceMinorPerLiter("42.35"))
        assertEquals(4000L, HistoryPricing.priceMinorPerLiter(" 40 "))
        assertEquals(4251L, HistoryPricing.priceMinorPerLiter("42,505"))   // rounded to whole kuruş
    }

    @Test
    fun anInvalidPriceIsNotStored() {
        assertNull(HistoryPricing.priceMinorPerLiter(""))
        assertNull(HistoryPricing.priceMinorPerLiter("abc"))
        assertNull(HistoryPricing.priceMinorPerLiter("0"))
        assertNull(HistoryPricing.priceMinorPerLiter("-5"))
        assertNull(HistoryPricing.priceMinorPerLiter("NaN"))
    }

    @Test
    fun theFactorIsStoredOnlyWhileCalibrationIsOnAndWithinItsLimits() {
        assertNull(HistoryPricing.calibrationFactorToStore(false, 1.05))
        assertEquals(1.05, HistoryPricing.calibrationFactorToStore(true, 1.05)!!, 1e-12)
        assertEquals(1.5, HistoryPricing.calibrationFactorToStore(true, 9.0)!!, 1e-12)
        assertEquals(0.5, HistoryPricing.calibrationFactorToStore(true, 0.1)!!, 1e-12)
        assertNull(HistoryPricing.calibrationFactorToStore(true, Double.NaN))
    }

    @Test
    fun pricingCombinesBoth() {
        assertEquals(TripPricing(4235L, 1.1), HistoryPricing.pricing("42,35", true, 1.1))
        assertEquals(TripPricing(null, null), HistoryPricing.pricing("", false, 1.1))
    }

    @Test
    fun aRecordWithAStoredPriceIgnoresTheCurrentPrice() {
        val r = HistoryPricing.cost(fuelUsedL = 10.0, calibrationFactor = null, storedPricePerLiterMinor = 4000L, currentPricePerLiter = 55.0)!!
        assertEquals(400.0, r.value, 1e-9)
        assertFalse(r.usesCurrentPrice)
    }

    @Test
    fun aPriceChangeNeverRewritesThePastCostOfANewRecord() {
        val before = HistoryPricing.cost(10.0, null, 4000L, 40.0)!!.value
        val afterPriceRise = HistoryPricing.cost(10.0, null, 4000L, 65.0)!!.value
        assertEquals(before, afterPriceRise, 0.0)
    }

    @Test
    fun anOlderRecordUsesTheCurrentPriceAndSaysSo() {
        val r = HistoryPricing.cost(10.0, null, null, 55.0)!!
        assertEquals(550.0, r.value, 1e-9)
        assertTrue(r.usesCurrentPrice)
        assertNull(HistoryPricing.cost(10.0, null, null, null))
        assertNull(HistoryPricing.cost(10.0, null, null, 0.0))
    }

    @Test
    fun theStoredFactorScalesTheFuelBehindTheCost() {
        val r = HistoryPricing.cost(10.0, 1.10, 4000L, null)!!
        assertEquals(440.0, r.value, 1e-9)
    }

    @Test
    fun costTextUsesTheLiraSignWithTwoDecimals() {
        assertEquals("440.00 \u20BA", HistoryPricing.formatTl(440.0))
    }
}
