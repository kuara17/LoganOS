package com.dcui.loganos.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

/** Tests for the maths extracted from MainActivity.enrichTrip (Stage 1). */
class TripPresentationTest {

    private fun settings(
        calibrationEnabled: Boolean = false,
        factor: Double = 1.0,
        avgResetDistanceKm: Double = 0.0,
        avgResetFuelLiters: Double = 0.0,
        costResetFuelLiters: Double = 0.0,
        price: String = "40",
        odometer: String = "100000"
    ) = TripPresentationSettings(
        fuelCalibrationEnabled = calibrationEnabled,
        fuelCalibrationFactor = factor,
        avgResetDistanceKm = avgResetDistanceKm,
        avgResetFuelLiters = avgResetFuelLiters,
        costResetFuelLiters = costResetFuelLiters,
        fuelPriceText = price,
        odometerText = odometer
    )

    private fun input(
        average: Double? = 5.0,
        instant: Double? = 4.0,
        fuel: Double? = 2.0,
        distance: Double? = 40.0
    ) = TripPresentationInput(
        averageConsumption = average,
        instantConsumption = instant,
        fuelUsedL = fuel,
        tripDistanceKm = distance,
        tripCostText = null,
        odometerKm = null
    )

    private fun totals(distance: Double, fuel: Double) =
        PersistentCockpitTripState(totalDistanceKm = distance, totalFuelLiters = fuel)

    @Test
    fun withoutCalibrationValuesPassThrough() {
        val r = computeTripPresentation(settings(), input(), totals(100.0, 6.0))
        assertEquals(6.0, r.averageConsumption!!, 1e-9)   // 6 L / 100 km from the persistent totals
        assertEquals(4.0, r.instantConsumption!!, 1e-9)
        assertEquals(2.0, r.fuelUsedL!!, 1e-9)
    }

    @Test
    fun costIsCalibratedFuelTimesPrice() {
        val r = computeTripPresentation(
            settings(calibrationEnabled = true, factor = 1.10, price = "40,5"),
            input(fuel = 2.0),
            totals(100.0, 6.0)
        )
        assertEquals(2.2, r.fuelUsedL!!, 1e-9)
        assertEquals("89.10 \u20BA", r.tripCostText)
    }

    @Test
    fun calibrationFactorIsClampedToItsLimits() {
        val high = computeTripPresentation(settings(calibrationEnabled = true, factor = 9.0), input(fuel = 2.0), totals(0.0, 0.0))
        assertEquals(3.0, high.fuelUsedL!!, 1e-9)   // 2.0 * 1.5
        val low = computeTripPresentation(settings(calibrationEnabled = true, factor = 0.1), input(fuel = 2.0), totals(0.0, 0.0))
        assertEquals(1.0, low.fuelUsedL!!, 1e-9)    // 2.0 * 0.5
    }

    @Test
    fun averageBelowOneKilometreIsNotShownFromTotals() {
        val r = computeTripPresentation(settings(), input(average = null), totals(0.5, 0.03))
        assertNull(r.averageConsumption)
    }

    @Test
    fun averageUsesTheResetBaseline() {
        val r = computeTripPresentation(
            settings(avgResetDistanceKm = 50.0, avgResetFuelLiters = 3.0),
            input(),
            totals(150.0, 9.0)   // since reset: 100 km, 6 L
        )
        assertEquals(6.0, r.averageConsumption!!, 1e-9)
    }

    @Test
    fun odometerIsBasePlusActiveTripDistance() {
        val r = computeTripPresentation(settings(odometer = "100000"), input(distance = 12.9), totals(0.0, 0.0))
        assertEquals(100012, r.odometerKm)
    }

    // ---- Stage 1.1 / Y1: calibration must reach the average that the cockpit shows -------------

    @Test
    fun calibrationFactorIsAppliedToTheAverageToo() {
        val r = computeTripPresentation(
            settings(calibrationEnabled = true, factor = 1.10),
            input(),
            totals(100.0, 6.0)
        )
        assertEquals(6.6, r.averageConsumption!!, 1e-9)
    }

    @Test
    fun calibrationFactorIsAppliedToTheTotalsFallbackAverageToo() {
        // Under the minimum distance since the reset the cockpit falls back to the persistent average.
        val r = computeTripPresentation(
            settings(calibrationEnabled = true, factor = 1.10, avgResetDistanceKm = 99.5, avgResetFuelLiters = 5.0),
            input(average = null),
            totals(100.0, 6.0)
        )
        assertEquals(6.6, r.averageConsumption!!, 1e-9)
    }

    @Test
    fun factorOneKeepsTheUncalibratedNumbersExactly() {
        val on = computeTripPresentation(settings(calibrationEnabled = true, factor = 1.0), input(), totals(100.0, 6.0))
        val off = computeTripPresentation(settings(calibrationEnabled = false, factor = 1.0), input(), totals(100.0, 6.0))
        assertEquals(off, on)
    }

    // ---- Known quirk, deliberately NOT changed in Stage 1 (reported as Y13) -------------------

    @Test
    fun afterAResetTheAllTimeAverageStaysVisibleUntilOneKilometre_CURRENT() {
        val r = computeTripPresentation(
            settings(avgResetDistanceKm = 99.5, avgResetFuelLiters = 5.0),
            input(average = null),
            totals(100.0, 6.0)   // only 0.5 km since the reset
        )
        assertEquals(6.0, r.averageConsumption!!, 1e-9)   // the all-time value, not "calculating"
    }
}
