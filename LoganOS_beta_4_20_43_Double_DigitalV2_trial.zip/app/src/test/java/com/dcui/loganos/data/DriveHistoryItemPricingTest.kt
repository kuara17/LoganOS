package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Stage 5: history display of fuel and cost for records with and without a stored price/factor. */
class DriveHistoryItemPricingTest {
    private fun item(price: Long? = null, factor: Double? = null) = DriveHistoryItem(
        id = 1L, tripToken = 1L, startedAtMs = 0L, endedAtMs = 1L, timeTrusted = true, status = "ENDED",
        pinned = false, exported = false, distanceKm = 100.0, fuelUsedL = 10.0, durationMs = 3_600_000L,
        averageL100 = 10.0, maxSpeedKmh = 90, maxRpm = 3000, startTempC = 50, endTempC = 80, sessionCount = 1,
        fuelPricePerLiterMinor = price, calibrationFactor = factor
    )

    @Test
    fun anOlderRecordHasNoStoredPriceAndShowsRawFuel() {
        val old = item()
        assertFalse(old.hasStoredPrice)
        assertEquals(10.0, old.displayFuelUsedL, 1e-12)
        val cost = old.costResult(currentPricePerLiter = 50.0)!!
        assertEquals(500.0, cost.value, 1e-9)
        assertTrue(cost.usesCurrentPrice)
    }

    @Test
    fun aNewRecordUsesItsOwnPriceAndFactor() {
        val fresh = item(price = 4000L, factor = 1.05)
        assertTrue(fresh.hasStoredPrice)
        assertEquals(10.5, fresh.displayFuelUsedL, 1e-12)
        val cost = fresh.costResult(currentPricePerLiter = 99.0)!!
        assertEquals(420.0, cost.value, 1e-9)
        assertFalse(cost.usesCurrentPrice)
    }

    @Test
    fun aStoredPriceOfZeroCountsAsNoPrice() {
        assertFalse(item(price = 0L).hasStoredPrice)
    }
}
