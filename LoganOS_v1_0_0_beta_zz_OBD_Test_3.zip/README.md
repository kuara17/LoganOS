# LoganOS

**LoganOS** is an OEM-style digital cockpit project for Renault & Dacia vehicles.

Version: **1.0.0-beta.3**

## Beta 3 Goal

This release is a combined UI and OBD connection test build:

- Responsive portrait/landscape cockpit layout
- Simplified navigation: Kokpit / Sürüş / Teknik / Ayarlar
- Functional settings dialogs for core options
- Live demo driving simulation
- Bluetooth paired-device listing
- ELM327 / vLinker MC+ connection test
- KWP2000 Fast Init command sequence
- 21A0 / 21A2 / 21CC / 21CD raw ECU read test
- Fuel Truth test panel using injection candidate values
- On-device OBD log display and log saving

## Important

LoganOS is not an official Renault or Dacia application. It is an independent, open-source, free, no-ads project.

This beta is a test build. OBD and fuel values must be validated with real logs before being treated as reliable.
