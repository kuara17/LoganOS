package com.dcui.loganos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = modifier) {
        Canvas(modifier = Modifier.size(118.dp, 58.dp)) {
            val c = if (selected) palette.accent else Color(0xFF3F4A3F)
            val h = size.height
            val w = size.width
            val stroke = h * .20f
            val yTop = h * .30f
            val yBot = h * .70f
            drawLine(c, Offset(w * .10f, yTop), Offset(w * .42f, yTop), strokeWidth = stroke)
            drawLine(c, Offset(w * .58f, yTop), Offset(w * .90f, yTop), strokeWidth = stroke)
            drawLine(c, Offset(w * .10f, yBot), Offset(w * .42f, yBot), strokeWidth = stroke)
            drawLine(c, Offset(w * .58f, yBot), Offset(w * .90f, yBot), strokeWidth = stroke)
            drawLine(c, Offset(w * .42f, yTop), Offset(w * .50f, h * .50f), strokeWidth = stroke)
            drawLine(c, Offset(w * .58f, yTop), Offset(w * .50f, h * .50f), strokeWidth = stroke)
            drawLine(c, Offset(w * .42f, yBot), Offset(w * .50f, h * .50f), strokeWidth = stroke)
            drawLine(c, Offset(w * .58f, yBot), Offset(w * .50f, h * .50f), strokeWidth = stroke)
        }
        Spacer(Modifier.height(2.dp))
        Text("DACIA", color = if (selected) palette.accent else palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
    }
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    val c = if (selected) palette.accent else palette.textPrimary
    Canvas(modifier = modifier.size(82.dp)) {
        val outer = Path().apply {
            moveTo(size.width * .50f, size.height * .05f)
            lineTo(size.width * .88f, size.height * .50f)
            lineTo(size.width * .50f, size.height * .95f)
            lineTo(size.width * .12f, size.height * .50f)
            close()
        }
        val inner = Path().apply {
            moveTo(size.width * .50f, size.height * .22f)
            lineTo(size.width * .70f, size.height * .50f)
            lineTo(size.width * .50f, size.height * .78f)
            lineTo(size.width * .30f, size.height * .50f)
            close()
        }
        drawPath(outer, color = c, style = Stroke(width = size.minDimension * .075f))
        drawPath(inner, color = c, style = Stroke(width = size.minDimension * .065f))
    }
}
