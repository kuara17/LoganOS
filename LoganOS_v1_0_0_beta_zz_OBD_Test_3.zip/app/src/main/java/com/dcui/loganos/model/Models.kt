package com.dcui.loganos.model

import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.sin

enum class DeviceMode(val label: String) {
    Phone("Telefon"),
    HeadUnit("Android Multimedya / Double")
}

enum class Brand(val label: String) {
    Dacia("Dacia"),
    Renault("Renault")
}

enum class GaugeStyle(val label: String) {
    Digital("Digital"),
    Sport("Sport"),
    ClassicOem("Classic OEM"),
    Minimal("Minimal"),
    RsPerformance("RS Performance")
}

enum class AccentColor(val label: String, val color: Color) {
    OemGreen("OEM Green", Color(0xFF34C759)),
    TechBlue("Tech Blue", Color(0xFF207DFF)),
    SportOrange("Sport Orange", Color(0xFFFF8A00)),
    RsRed("RS Red", Color(0xFFFF3B30)),
    NeoPurple("Neo Purple", Color(0xFF9B5CFF)),
    GoldEdition("Gold Edition", Color(0xFFFFC107))
}

data class LoganSettings(
    val setupCompleted: Boolean = false,
    val brand: Brand = Brand.Dacia,
    val vehicleModel: String = "Dacia Logan",
    val engine: String = "1.5 dCi 48 kW",
    val deviceMode: DeviceMode = DeviceMode.Phone,
    val gaugeStyle: GaugeStyle = GaugeStyle.Digital,
    val accentColor: AccentColor = AccentColor.OemGreen,
    val darkMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val backgroundTripEnabled: Boolean = true,
    val smartTripMinutes: Int = 60,
    val demoMode: Boolean = false,
    val disclaimerAccepted: Boolean = false,
    val fuelPriceText: String = "",
    val odometerText: String = "335420",
    val oilServiceKm: String = "10000",
    val fuelFilterKm: String = "20000",
    val airFilterKm: String = "10000",
    val timingBeltKm: String = "60000"
)

data class DashboardSnapshot(
    val speedKmh: Int? = null,
    val averageConsumption: Double? = null,
    val instantConsumption: Double? = null,
    val instantUnit: String = "L/h",
    val tripDistanceKm: Double? = null,
    val odometerKm: Int? = null,
    val engineTempC: Int? = null,
    val radiatorFanOn: Boolean? = null,
    val rpm: Int? = null,
    val acOn: Boolean? = null,
    val fuelUsedL: Double? = null,
    val tripCostText: String? = null,
    val batteryV: Double? = null,
    val connected: Boolean = false,
    val demo: Boolean = false,
    val fuelSource: String = "Bekleniyor",
    val injectionMg: Double? = null,
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = ""
) {
    companion object {
        fun empty() = DashboardSnapshot()

        fun demoLive(tick: Int): DashboardSnapshot {
            val phase = (tick % 120) / 120.0
            val wave = (sin(phase * 2.0 * PI) + 1.0) / 2.0
            val cityPulse = (sin(phase * 10.0 * PI) + 1.0) / 2.0
            val speed = (18 + wave * 82 + cityPulse * 12).toInt().coerceIn(0, 110)
            val rpm = (850 + speed * 18 + cityPulse * 380).toInt().coerceIn(820, 3100)
            val temp = (58 + (tick.coerceAtMost(90) * 0.46)).toInt().coerceIn(58, 98)
            val fan = temp >= 96 && (tick / 5) % 2 == 0
            val ac = (tick / 18) % 2 == 0
            val lh = if (speed < 5) 0.7 + if (ac) 0.15 else 0.0 else 1.1 + wave * 2.2 + if (ac) 0.25 else 0.0
            val l100 = if (speed < 5) 0.0 else (lh / speed) * 100.0
            val distance = (tick * speed / 3600.0 * 0.8).coerceAtLeast(0.0)
            val fuelUsed = distance * 4.9 / 100.0
            return DashboardSnapshot(
                speedKmh = speed,
                averageConsumption = 4.7 + wave * 0.5,
                instantConsumption = if (speed < 5) lh else l100,
                instantUnit = if (speed < 5) "L/h" else "L/100 km",
                tripDistanceKm = distance,
                odometerKm = 335420 + distance.toInt(),
                engineTempC = temp,
                radiatorFanOn = fan,
                rpm = rpm,
                acOn = ac,
                fuelUsedL = fuelUsed,
                tripCostText = "Demo",
                batteryV = 13.7 + (wave * 0.2),
                connected = false,
                demo = true,
                fuelSource = "DEMO",
                injectionMg = 3.2 + wave * 8.0,
                raw21A0 = "DEMO 61 A0 ...",
                raw21A2 = "DEMO 61 A2 ...",
                raw21CC = "DEMO 61 CC ...",
                raw21CD = "DEMO 61 CD ..."
            )
        }

        fun demo() = demoLive(42)
    }
}
