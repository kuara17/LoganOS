package com.dcui.loganos.obd

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID

class ObdController(private val context: Context) {
    var state by mutableStateOf(ObdState())
        private set

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var socket: BluetoothSocket? = null
    private val parser = DelphiParser()
    private val sppUuid: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun hasBluetoothPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    @SuppressLint("MissingPermission")
    fun refreshPairedDevices() {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni bekleniyor. Uygulama izni verilmeden cihaz listesi okunamaz.", error = true)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            appendStatus("Bu cihazda Bluetooth adaptörü bulunamadı.", error = true)
            return
        }
        val devices = adapter.bondedDevices.orEmpty()
            .map { PairedObdDevice(it.name ?: "OBD cihazı", it.address) }
            .sortedWith(compareByDescending<PairedObdDevice> { looksLikeObd(it.name) }.thenBy { it.name })
        state = state.copy(
            pairedDevices = devices,
            status = if (devices.isEmpty()) "Eşleşmiş OBD cihazı bulunamadı" else "${devices.size} eşleşmiş cihaz bulundu",
            logText = state.logText + "\n[BT] Paired devices: ${devices.joinToString { it.displayName }}"
        )
    }

    fun selectDevice(device: PairedObdDevice) {
        state = state.copy(
            selectedAddress = device.address,
            selectedName = device.name,
            status = "Seçildi: ${device.name}",
            logText = state.logText + "\n[BT] Selected ${device.displayName}"
        )
    }

    fun connectSelected() {
        val address = state.selectedAddress
        if (address == null) {
            appendStatus("Önce vLinker MC+ / ELM327 cihazını seç.", error = true)
            return
        }
        connect(address)
    }

    @SuppressLint("MissingPermission")
    private fun connect(address: String) {
        if (!hasBluetoothPermission()) {
            appendStatus("Bluetooth izni yok. Android izin ekranından izin verilmeli.", error = true)
            return
        }
        disconnect(silent = true)
        state = state.copy(connecting = true, connected = false, status = "Bluetooth bağlanıyor...", lastError = null)
        job = scope.launch {
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: error("Bluetooth adaptörü yok")
                val device = adapter.getRemoteDevice(address)
                withMain { appendLog("[BT] Connecting to ${device.name ?: address} / $address") }
                adapter.cancelDiscovery()
                val sock = device.createRfcommSocketToServiceRecord(sppUuid)
                socket = sock
                sock.connect()
                val out = sock.outputStream
                val input = sock.inputStream
                withMain { state = state.copy(connecting = false, connected = true, status = "Bluetooth bağlı • ELM init başlıyor") }

                val initCommands = listOf(
                    Triple("", 80L, 600L),
                    Triple("ATZ", 400L, 2200L),
                    Triple("ATE0", 60L, 1000L),
                    Triple("ATL0", 60L, 1000L),
                    Triple("ATS0", 60L, 1000L),
                    Triple("ATH0", 60L, 1000L),
                    Triple("ATSP5", 100L, 1400L),
                    Triple("ATKW0", 80L, 1400L),
                    Triple("ATFI", 150L, 2600L)
                )
                initCommands.forEach { (cmd, wait, timeout) ->
                    val resp = send(out, input, cmd, wait, timeout)
                    withMain { appendLog("${if (cmd.isBlank()) "<wake>" else cmd}  =>  $resp") }
                }
                withMain { state = state.copy(status = "KWP test döngüsü başladı") }
                pollLoop(out, input)
            } catch (t: Throwable) {
                val message = t.message ?: t.javaClass.simpleName
                withMain {
                    appendStatus("Bağlantı hatası: $message", error = true)
                    state = state.copy(connecting = false, connected = false)
                }
                closeSocket()
            }
        }
    }

    fun disconnect(silent: Boolean = false) {
        job?.cancel()
        job = null
        closeSocket()
        val updated = state.copy(connecting = false, connected = false, status = if (silent) state.status else "Bağlantı kesildi")
        state = updated
        if (!silent) appendLog("[BT] Disconnected")
    }

    private suspend fun pollLoop(out: OutputStream, input: InputStream) {
        while (job?.isActive == true) {
            val start = System.currentTimeMillis()
            val atrv = send(out, input, "ATRV", 40L, 900L)
            val rawA0 = send(out, input, "21A0", 50L, 1400L)
            val rawA2 = send(out, input, "21A2", 50L, 1300L)
            val rawCC = send(out, input, "21CC", 40L, 1200L)
            val rawCD = send(out, input, "21CD", 40L, 1200L)

            var stdRpm = ""
            var stdSpeed = ""
            var stdTemp = ""
            if (!rawA0.contains("61A0", ignoreCase = true)) {
                stdRpm = send(out, input, "010C", 40L, 900L)
                stdSpeed = send(out, input, "010D", 40L, 900L)
                stdTemp = send(out, input, "0105", 40L, 900L)
            }

            val parsed = parser.parse(rawA0, rawA2, rawCC, rawCD, atrv, stdRpm, stdSpeed, stdTemp)
            val snapshot = parsed.toSnapshot(rawA0, rawA2, rawCC, rawCD, connected = true)
            val elapsed = System.currentTimeMillis() - start
            withMain {
                state = state.copy(
                    connected = true,
                    connecting = false,
                    status = "OBD bağlı • ${elapsed} ms",
                    snapshot = snapshot,
                    raw21A0 = rawA0,
                    raw21A2 = rawA2,
                    raw21CC = rawCC,
                    raw21CD = rawCD,
                    timingText = "loop=${elapsed}ms",
                    logText = trimLog(state.logText + "\n[LOOP ${elapsed}ms] rpm=${snapshot.rpm ?: "--"} speed=${snapshot.speedKmh ?: "--"} temp=${snapshot.engineTempC ?: "--"} fuel=${snapshot.injectionMg ?: "--"} src=${snapshot.fuelSource}\n21A0=$rawA0\n21A2=$rawA2\n21CC=$rawCC\n21CD=$rawCD")
                )
            }
            delay(350)
        }
    }

    private fun send(out: OutputStream, input: InputStream, cmd: String, waitMs: Long, timeoutMs: Long): String {
        if (cmd.isNotBlank()) {
            out.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            out.flush()
        }
        Thread.sleep(waitMs)
        val buffer = StringBuilder()
        val start = System.currentTimeMillis()
        var gotAny = false
        var lastData = System.currentTimeMillis()
        while (System.currentTimeMillis() - start < timeoutMs) {
            val available = input.available()
            if (available > 0) {
                gotAny = true
                lastData = System.currentTimeMillis()
                repeat(available) {
                    val b = input.read()
                    if (b >= 0) {
                        val ch = b.toChar()
                        buffer.append(ch)
                        if (ch == '>') return clean(buffer.toString())
                    }
                }
            } else {
                if (gotAny && System.currentTimeMillis() - lastData > 120L) return clean(buffer.toString())
                Thread.sleep(10)
            }
        }
        return clean(buffer.toString())
    }

    fun saveLogFile() {
        val dir = context.getExternalFilesDir(null) ?: context.filesDir
        val file = File(dir, "loganos_obd_beta3_log.txt")
        file.writeText(state.logText.ifBlank { "Log yok" })
        state = state.copy(savedLogPath = file.absolutePath, status = "Log kaydedildi")
        appendLog("[LOG] Saved to ${file.absolutePath}")
    }

    private fun clean(text: String): String = text.replace("\r", " ").replace("\n", " ").replace(">", " > ").trim()

    private fun closeSocket() {
        runCatching { socket?.close() }
        socket = null
    }

    private fun appendStatus(text: String, error: Boolean = false) {
        state = state.copy(status = text, lastError = if (error) text else state.lastError, logText = trimLog(state.logText + "\n[STATUS] $text"))
    }

    private fun appendLog(text: String) {
        state = state.copy(logText = trimLog(state.logText + "\n$text"))
    }

    private suspend fun withMain(block: () -> Unit) = withContext(Dispatchers.Main) { block() }

    private fun trimLog(log: String): String {
        return if (log.length <= 60000) log else log.takeLast(60000)
    }

    private fun looksLikeObd(name: String): Boolean {
        val n = name.lowercase()
        return listOf("obd", "elm", "vlink", "vgate", "icar", "kwp").any { it in n }
    }
}
