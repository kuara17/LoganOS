package com.dcui.loganos.ui.cockpit

import androidx.annotation.DrawableRes
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.max

private val OriginalWhite = Color(0xFFF7F9FF)
private val OriginalMuted = Color(0xFFB7C1D0)
private const val GhostSpeedMaxKmh = 200
private const val ConsumptionVisualMax = 15.0

@Composable
fun GhostSingleOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, GhostSpeedMaxKmh)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, settings.tachometerMaxRpm)
    val accent = ghostOriginalAccentColor(settings.ghostOriginalAccent)
    val fuelTrusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    val instantValue = snapshot.instantConsumption.takeIf { fuelTrusted }
    val averageValue = snapshot.averageConsumption.takeIf { fuelTrusted }
    val instant = if (fuelTrusted) formatOne(instantValue) else "--"
    val average = if (fuelTrusted) formatOne(averageValue) else "--"
    val instantUnit = if (fuelTrusted) snapshot.instantUnit else "VERİ BEKLENİYOR"
    val averageUnit = if (fuelTrusted) "L/100 km" else "VERİ BEKLENİYOR"
    val temperature = snapshot.engineTempC
    val tempText = temperature?.let { "$it °C" } ?: "-- °C"
    val tempColor = coolantAccentColor(palette, temperature)
    val vehicleRes = vehicleVisualDrawableRes(
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor,
        style = VehicleAssetStyle.Detailed
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        val stageWidth = maxWidth
        val stageHeight = maxHeight
        val clusterWidth = minOf(stageWidth * 0.57f, stageHeight * 1.32f)
        val clusterHeight = clusterWidth * 0.76f
        val panelWidth = minOf(stageWidth * 0.205f, stageHeight * 0.54f)
        val panelHeight = stageHeight * 0.68f

        Image(
            painter = painterResource(R.drawable.ghost_single_original_background),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        // The reference uses a thin horizon exactly where the compact road begins.
        Image(
            painter = painterResource(ghostOriginalHorizonRes(settings.ghostOriginalAccent)),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .width(stageWidth)
                .height(stageHeight * 0.17f)
                .align(Alignment.Center)
                .offset(y = stageHeight * 0.06f)
        )

        CentralReferenceCluster(
            speed = speed,
            rpm = rpm,
            accent = accent,
            vehicleRes = vehicleRes,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .offset(y = stageHeight * -0.01f)
                .width(clusterWidth)
                .height(clusterHeight)
        )

        LeftInformationPanel(
            temperatureC = temperature,
            temperatureText = tempText,
            temperatureColor = tempColor,
            instantValue = instantValue,
            instantText = instant,
            instantUnit = instantUnit,
            accent = accent,
            onClick = onOpenReset,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .offset(x = stageWidth * 0.027f, y = stageHeight * 0.025f)
                .width(panelWidth)
                .height(panelHeight)
        )

        RightInformationPanel(
            averageValue = averageValue,
            averageText = average,
            averageUnit = averageUnit,
            accent = accent,
            onClick = onOpenReset,
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .offset(x = stageWidth * -0.027f, y = stageHeight * 0.025f)
                .width(panelWidth)
                .height(panelHeight)
        )

        Image(
            painter = painterResource(R.drawable.ghost_single_original_vignette),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        GhostOriginalText(
            cx = 0.91f,
            cy = 0.065f,
            widthFraction = 0.16f,
            heightFraction = 0.06f,
            text = when {
                snapshot.demo -> "DEMO"
                snapshot.connected -> "OBD BAĞLI"
                else -> "OBD BEKLENİYOR"
            },
            size = scaledSp(stageHeight.value * 0.021f),
            color = if (snapshot.demo || snapshot.connected) accent else OriginalMuted,
            weight = FontWeight.Bold
        )
    }
}

@Composable
private fun CentralReferenceCluster(
    speed: Int,
    rpm: Int,
    accent: Color,
    @DrawableRes vehicleRes: Int,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier) {
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_base),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_sheen),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.18f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_edges),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.82f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_soft),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_contact),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(maxWidth * 0.17f)
                .height(maxHeight * 0.28f)
                .offset(y = maxHeight * -0.05f)
        )

        GaugeProgressLayer(
            speedKmh = speed,
            accent = accent,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_gauge_shell),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        ClusterText(
            cx = 0.50f,
            cy = 0.235f,
            widthFraction = 0.30f,
            heightFraction = 0.14f,
            text = speed.toString(),
            size = scaledSp(maxHeight.value * 0.105f),
            color = OriginalWhite,
            weight = FontWeight.Light
        )
        ClusterText(
            cx = 0.50f,
            cy = 0.325f,
            widthFraction = 0.18f,
            heightFraction = 0.05f,
            text = "km/h",
            size = scaledSp(maxHeight.value * 0.027f),
            color = OriginalMuted,
            weight = FontWeight.Medium
        )
        ClusterText(
            cx = 0.50f,
            cy = 0.392f,
            widthFraction = 0.30f,
            heightFraction = 0.06f,
            text = "$rpm rpm",
            size = scaledSp(maxHeight.value * 0.034f),
            color = OriginalWhite.copy(alpha = 0.88f),
            weight = FontWeight.Medium
        )
    }
}

@Composable
private fun GaugeProgressLayer(
    speedKmh: Int,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val scaleX = size.width / 1000f
        val scaleY = size.height / 760f
        val left = (500f - 350f) * scaleX
        val top = (390f - 350f) * scaleY
        val arcSize = Size(700f * scaleX, 700f * scaleY)
        val sweep = 210f * (speedKmh.coerceIn(0, GhostSpeedMaxKmh) / GhostSpeedMaxKmh.toFloat())
        if (sweep <= 0f) return@Canvas

        drawArc(
            color = accent.copy(alpha = 0.18f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = 10f * scaleX, cap = StrokeCap.Butt)
        )
        drawArc(
            color = accent.copy(alpha = 0.92f),
            startAngle = 165f,
            sweepAngle = sweep,
            useCenter = false,
            topLeft = Offset(left, top),
            size = arcSize,
            style = Stroke(width = 4f * scaleX, cap = StrokeCap.Butt)
        )
    }
}

@Composable
private fun LeftInformationPanel(
    temperatureC: Int?,
    temperatureText: String,
    temperatureColor: Color,
    instantValue: Double?,
    instantText: String,
    instantUnit: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.clickable(onClick = onClick)) {
        val temperatureProgress = temperatureC?.let { ((it - 40f) / 80f).coerceIn(0f, 1f) } ?: 0f
        val instantProgress = instantValue
            ?.takeIf { !it.isNaN() && !it.isInfinite() }
            ?.let { (it / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f) }
            ?: 0f

        Canvas(modifier = Modifier.fillMaxSize()) {
            // Open side zone like the reference cluster: no floating card shell.
            drawLine(
                color = OriginalMuted.copy(alpha = 0.16f),
                start = Offset(size.width * 0.08f, size.height * 0.49f),
                end = Offset(size.width * 0.92f, size.height * 0.49f),
                strokeWidth = size.height * 0.002f
            )

            // Reference-style vertical coolant gauge.
            val tempX = size.width * 0.16f
            val tempTop = size.height * 0.10f
            val tempBottom = size.height * 0.41f
            val tempEnd = tempBottom - (tempBottom - tempTop) * temperatureProgress
            drawLine(
                color = OriginalMuted.copy(alpha = 0.22f),
                start = Offset(tempX, tempTop),
                end = Offset(tempX, tempBottom),
                strokeWidth = size.width * 0.035f,
                cap = StrokeCap.Round
            )
            drawLine(
                color = temperatureColor.copy(alpha = 0.96f),
                start = Offset(tempX, tempBottom),
                end = Offset(tempX, tempEnd),
                strokeWidth = size.width * 0.017f,
                cap = StrokeCap.Round
            )
            for (i in 0..4) {
                val y = tempTop + (tempBottom - tempTop) * i / 4f
                drawLine(
                    color = OriginalMuted.copy(alpha = 0.38f),
                    start = Offset(tempX + size.width * 0.035f, y),
                    end = Offset(tempX + size.width * 0.070f, y),
                    strokeWidth = size.height * 0.002f
                )
            }

            // Simple OEM coolant symbol beside the label.
            val iconX = size.width * 0.43f
            val iconY = size.height * 0.105f
            drawLine(
                color = temperatureColor.copy(alpha = 0.92f),
                start = Offset(iconX, iconY),
                end = Offset(iconX, iconY + size.height * 0.065f),
                strokeWidth = size.width * 0.012f,
                cap = StrokeCap.Round
            )
            drawCircle(
                color = temperatureColor.copy(alpha = 0.92f),
                radius = size.width * 0.020f,
                center = Offset(iconX, iconY + size.height * 0.075f)
            )
            repeat(2) { row ->
                val y = iconY + size.height * (0.105f + row * 0.025f)
                drawLine(
                    color = temperatureColor.copy(alpha = 0.78f),
                    start = Offset(iconX - size.width * 0.07f, y),
                    end = Offset(iconX + size.width * 0.07f, y),
                    strokeWidth = size.height * 0.003f,
                    cap = StrokeCap.Round
                )
            }

            // Instant-consumption visual lives inside the enlarged side area.
            val barX1 = size.width * 0.18f
            val barX2 = size.width * 0.82f
            val barY = size.height * 0.91f
            val barEnd = barX1 + (barX2 - barX1) * instantProgress
            drawLine(
                color = OriginalMuted.copy(alpha = 0.20f),
                start = Offset(barX1, barY),
                end = Offset(barX2, barY),
                strokeWidth = size.height * 0.018f,
                cap = StrokeCap.Round
            )
            if (instantValue != null) {
                drawLine(
                    color = accent.copy(alpha = 0.94f),
                    start = Offset(barX1, barY),
                    end = Offset(barEnd, barY),
                    strokeWidth = size.height * 0.008f,
                    cap = StrokeCap.Round
                )
            }
        }

        PanelText(
            cx = 0.63f,
            cy = 0.16f,
            widthFraction = 0.56f,
            heightFraction = 0.08f,
            text = "HARARET",
            size = scaledSp(maxHeight.value * 0.040f),
            color = OriginalMuted,
            weight = FontWeight.Bold
        )
        PanelText(
            cx = 0.63f,
            cy = 0.285f,
            widthFraction = 0.56f,
            heightFraction = 0.14f,
            text = temperatureText,
            size = scaledSp(maxHeight.value * 0.075f),
            color = temperatureColor,
            weight = FontWeight.SemiBold
        )
        PanelText(
            cx = 0.055f,
            cy = 0.10f,
            widthFraction = 0.11f,
            heightFraction = 0.05f,
            text = "120",
            size = scaledSp(maxHeight.value * 0.025f),
            color = OriginalMuted.copy(alpha = 0.72f),
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.055f,
            cy = 0.41f,
            widthFraction = 0.11f,
            heightFraction = 0.05f,
            text = "40",
            size = scaledSp(maxHeight.value * 0.025f),
            color = OriginalMuted.copy(alpha = 0.72f),
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.50f,
            cy = 0.60f,
            widthFraction = 0.76f,
            heightFraction = 0.08f,
            text = "ANLIK",
            size = scaledSp(maxHeight.value * 0.042f),
            color = OriginalMuted,
            weight = FontWeight.Bold
        )
        PanelText(
            cx = 0.50f,
            cy = 0.735f,
            widthFraction = 0.76f,
            heightFraction = 0.16f,
            text = instantText,
            size = scaledSp(maxHeight.value * 0.092f),
            color = OriginalWhite,
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.50f,
            cy = 0.835f,
            widthFraction = 0.84f,
            heightFraction = 0.08f,
            text = instantUnit,
            size = scaledSp(maxHeight.value * 0.034f),
            color = OriginalMuted,
            weight = FontWeight.Medium
        )
    }
}

@Composable
private fun RightInformationPanel(
    averageValue: Double?,
    averageText: String,
    averageUnit: String,
    accent: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier.clickable(onClick = onClick)) {
        val progress = averageValue
            ?.takeIf { !it.isNaN() && !it.isInfinite() }
            ?.let { (it / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f) }
            ?: 0f

        Canvas(modifier = Modifier.fillMaxSize()) {
            // Open right-side zone like the reference cluster: no card border.
            drawLine(
                color = OriginalMuted.copy(alpha = 0.16f),
                start = Offset(size.width * 0.08f, size.height * 0.67f),
                end = Offset(size.width * 0.92f, size.height * 0.67f),
                strokeWidth = size.height * 0.002f
            )

            // Average-consumption icon.
            val iconBaseY = size.height * 0.20f
            val iconCenterX = size.width * 0.44f
            val barWidth = size.width * 0.026f
            listOf(0.045f, 0.075f, 0.105f).forEachIndexed { index, heightFraction ->
                val x = iconCenterX + (index - 1) * size.width * 0.055f
                drawLine(
                    color = accent.copy(alpha = 0.86f),
                    start = Offset(x, iconBaseY),
                    end = Offset(x, iconBaseY - size.height * heightFraction),
                    strokeWidth = barWidth,
                    cap = StrokeCap.Round
                )
            }

            val gaugeX = size.width * 0.86f
            val gaugeTop = size.height * 0.16f
            val gaugeBottom = size.height * 0.82f
            val gaugeEnd = gaugeBottom - (gaugeBottom - gaugeTop) * progress
            drawLine(
                color = OriginalMuted.copy(alpha = 0.22f),
                start = Offset(gaugeX, gaugeTop),
                end = Offset(gaugeX, gaugeBottom),
                strokeWidth = size.width * 0.035f,
                cap = StrokeCap.Round
            )
            if (averageValue != null) {
                drawLine(
                    color = accent.copy(alpha = 0.96f),
                    start = Offset(gaugeX, gaugeBottom),
                    end = Offset(gaugeX, gaugeEnd),
                    strokeWidth = size.width * 0.017f,
                    cap = StrokeCap.Round
                )
            }
            for (i in 0..5) {
                val y = gaugeTop + (gaugeBottom - gaugeTop) * i / 5f
                drawLine(
                    color = OriginalMuted.copy(alpha = 0.38f),
                    start = Offset(gaugeX - size.width * 0.070f, y),
                    end = Offset(gaugeX - size.width * 0.035f, y),
                    strokeWidth = size.height * 0.002f
                )
            }
        }

        PanelText(
            cx = 0.45f,
            cy = 0.31f,
            widthFraction = 0.68f,
            heightFraction = 0.08f,
            text = "ORTALAMA",
            size = scaledSp(maxHeight.value * 0.042f),
            color = OriginalMuted,
            weight = FontWeight.Bold
        )
        PanelText(
            cx = 0.45f,
            cy = 0.47f,
            widthFraction = 0.68f,
            heightFraction = 0.18f,
            text = averageText,
            size = scaledSp(maxHeight.value * 0.095f),
            color = OriginalWhite,
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.45f,
            cy = 0.59f,
            widthFraction = 0.76f,
            heightFraction = 0.08f,
            text = averageUnit,
            size = scaledSp(maxHeight.value * 0.034f),
            color = OriginalMuted,
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.73f,
            cy = 0.16f,
            widthFraction = 0.12f,
            heightFraction = 0.05f,
            text = "15",
            size = scaledSp(maxHeight.value * 0.025f),
            color = OriginalMuted.copy(alpha = 0.72f),
            weight = FontWeight.Medium
        )
        PanelText(
            cx = 0.73f,
            cy = 0.82f,
            widthFraction = 0.12f,
            heightFraction = 0.05f,
            text = "0",
            size = scaledSp(maxHeight.value * 0.025f),
            color = OriginalMuted.copy(alpha = 0.72f),
            weight = FontWeight.Medium
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.ClusterText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.PanelText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.GhostOriginalText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

private fun scaledSp(value: Float): TextUnit = max(9f, value).sp

private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun ghostOriginalAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFF9B5CFF)
    GhostOriginalAccent.Red -> Color(0xFFFF3B30)
    GhostOriginalAccent.Green -> Color(0xFF2EE66B)
    GhostOriginalAccent.White -> Color(0xFFF1F5FF)
    GhostOriginalAccent.Blue -> Color(0xFF3595FF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFC12E)
}

@DrawableRes
private fun ghostOriginalHorizonRes(accent: GhostOriginalAccent): Int = when (accent) {
    GhostOriginalAccent.Purple -> R.drawable.ghost_single_original_horizon_purple
    GhostOriginalAccent.Red -> R.drawable.ghost_single_original_horizon_red
    GhostOriginalAccent.Green -> R.drawable.ghost_single_original_horizon_green
    GhostOriginalAccent.White -> R.drawable.ghost_single_original_horizon_white
    GhostOriginalAccent.Blue -> R.drawable.ghost_single_original_horizon_blue
    GhostOriginalAccent.Yellow -> R.drawable.ghost_single_original_horizon_yellow
}
