#!/usr/bin/env python3
from pathlib import Path
from PIL import Image, ImageDraw, ImageEnhance
import math, re, sys

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
SRC = ROOT / 'app/src/main/java/com/dcui/loganos/ui/cockpit/opengl/DigitalV2SceneProfiles.kt'
ASSETS = ROOT / 'app/src/main/res/drawable-nodpi'
OUT = Path(sys.argv[2] if len(sys.argv) > 2 else ROOT / 'digital_v2_validation.jpg')
TEXT = SRC.read_text(encoding='utf-8')
W, H = 1080, 1320

scene_defs = {
    'MountainLake': ('mountainRoad', 'digital_v2_mountain_lake_bg.webp'),
    'CityDay': ('cityDayRoad', 'digital_v2_city_day_bg.webp'),
    'CityNight': ('cityNightRoad', 'digital_v2_city_night_bg.webp'),
    'SnowRoad': ('snowRoad', 'digital_v2_snow_road_bg.webp'),
}

def balanced_block(text, start):
    depth = 0
    for i in range(start, len(text)):
        if text[i] == '(':
            depth += 1
        elif text[i] == ')':
            depth -= 1
            if depth == 0:
                return text[start:i+1]
    raise ValueError('unbalanced block')

def road_block(var):
    marker = f'private val {var} = DigitalV2RoadCalibration('
    start = TEXT.index(marker) + TEXT.index('(', TEXT.index(marker)) - TEXT.index(marker)
    return balanced_block(TEXT, start)

def curve_points(block, key):
    marker = f'{key} = curve('
    k = block.index(marker)
    start = block.index('(', k)
    cb = balanced_block(block, start)
    pts = [tuple(map(float,m)) for m in re.findall(r'CalibrationPoint\(([\d.]+)f,\s*([\d.]+)f,\s*([\d.]+)f\)', cb)]
    return pts

def scene_block(scene):
    marker = f'val {scene} = DigitalV2SceneModel('
    k = TEXT.index(marker)
    return balanced_block(TEXT, TEXT.index('(', k))

def get_float(block, name, default=None):
    m = re.search(rf'{re.escape(name)}\s*=\s*(-?[\d.]+)f', block)
    if not m:
        if default is not None: return default
        raise KeyError(name)
    return float(m.group(1))

def sample(points, d):
    d = max(points[0][0], min(points[-1][0], d))
    seg = max(0, min(len(points)-2, max(i for i,p in enumerate(points) if p[0] <= d)))
    p1=points[seg]; p2=points[seg+1]
    p0=points[max(0,seg-1)]; p3=points[min(len(points)-1,seg+2)]
    span=max(1e-4,p2[0]-p1[0]); t=max(0,min(1,(d-p1[0])/span)); t2=t*t; t3=t2*t
    h00=2*t3-3*t2+1; h10=t3-2*t2+t; h01=-2*t3+3*t2; h11=t3-t2
    def deriv(a,b,idx): return (b[idx]-a[idx])/max(1e-4,b[0]-a[0])
    x=h00*p1[1]+h10*span*deriv(p0,p2,1)+h01*p2[1]+h11*span*deriv(p1,p3,1)
    y=h00*p1[2]+h10*span*deriv(p0,p2,2)+h01*p2[2]+h11*span*deriv(p1,p3,2)
    return x,y

def tangent(points,d):
    eps=.15
    a=sample(points,max(0,d-eps)); b=sample(points,min(points[-1][0],d+eps))
    return (b[0]-a[0],b[1]-a[1])

def road_width(left,right,d):
    lx,ly=sample(left,d); rx,ry=sample(right,d)
    return math.hypot((rx-lx)*W,(ry-ly)*H)

def ribbon_polygon(curve,left,right,d0,d1,width_m,road_width_m,steps=8,min_px=1.8,max_px=10.0):
    ls=[]; rs=[]
    for i in range(steps+1):
        d=d0+(d1-d0)*i/steps
        x,y=sample(curve,d); tx,ty=tangent(curve,d)
        tx*=W; ty*=H; L=max(1e-6,math.hypot(tx,ty)); nx=-ty/L; ny=tx/L
        px=max(min_px,min(max_px,road_width(left,right,d)*(width_m/road_width_m)))
        cx=x*W; cy=y*H
        ls.append((cx+nx*px/2,cy+ny*px/2)); rs.append((cx-nx*px/2,cy-ny*px/2))
    return ls+rs[::-1]

def alpha_scaled(img, factor):
    img=img.copy().convert('RGBA')
    a=img.getchannel('A').point(lambda v:int(v*factor))
    img.putalpha(a); return img

def place_shadow(stage, shadow_img, x,y,w,h,alpha):
    im=shadow_img.resize((max(1,int(w)),max(1,int(h))),Image.Resampling.LANCZOS)
    im=alpha_scaled(im,alpha)
    stage.alpha_composite(im,(int(x-w/2),int(y-h/2)))

def grade_vehicle(img, exposure, contrast, saturation, rgb):
    out=ImageEnhance.Brightness(img).enhance(exposure)
    out=ImageEnhance.Contrast(out).enhance(contrast)
    out=ImageEnhance.Color(out).enhance(saturation)
    r,g,b,a=out.split()
    r=r.point(lambda v:min(255,int(v*rgb[0]))); g=g.point(lambda v:min(255,int(v*rgb[1]))); b=b.point(lambda v:min(255,int(v*rgb[2])))
    return Image.merge('RGBA',(r,g,b,a))

def fade_alpha(d,start,end):
    if d <= start: return 1.0
    if d >= end: return 0.0
    return 1.0-(d-start)/(end-start)

car=Image.open(ASSETS/'loganos_logan3_rear_cherry_red.webp').convert('RGBA')
shadow=Image.open(ASSETS/'digital_v2_ground_shadow_logan3.webp').convert('RGBA')
results=[]
for scene,(roadvar,bgname) in scene_defs.items():
    rb=road_block(roadvar)
    center=curve_points(rb,'centerLine'); left=curve_points(rb,'leftRoadEdge'); right=curve_points(rb,'rightRoadEdge')
    road_width_m=get_float(rb,'roadWidthMeters')
    center_fade_start=get_float(rb,'centerFadeStartMeters',88)
    center_fade_end=get_float(rb,'centerFadeEndMeters',116)
    edge_fade_start=get_float(rb,'edgeFadeStartMeters',96)
    edge_fade_end=get_float(rb,'edgeFadeEndMeters',120)
    sb=scene_block(scene)
    pose=balanced_block(sb,sb.index('VehicleScenePose(')+len('VehicleScenePose'))
    sx=get_float(pose,'centerXRatio'); sy=get_float(pose,'tireContactYRatio'); vw=get_float(pose,'visibleWidthRatio'); heading=get_float(pose,'headingDegrees')
    shadowb=balanced_block(pose,pose.index('VehicleShadowProfile(')+len('VehicleShadowProfile'))
    body_w=get_float(shadowb,'bodyWidthRatio'); body_h=get_float(shadowb,'bodyHeightRatio'); body_a=get_float(shadowb,'bodyAlpha')
    tire_w=get_float(shadowb,'tireWidthRatio'); tire_h=get_float(shadowb,'tireHeightRatio'); tire_a=get_float(shadowb,'tireAlpha')
    blend_w=get_float(shadowb,'groundBlendWidthRatio'); blend_h=get_float(shadowb,'groundBlendHeightRatio'); blend_a=get_float(shadowb,'groundBlendAlpha')
    gradeb=balanced_block(pose,pose.index('VehicleColorGrade(')+len('VehicleColorGrade'))
    exposure=get_float(gradeb,'exposure',1); contrast=get_float(gradeb,'contrast',1); saturation=get_float(gradeb,'saturation',1)
    rgb=(get_float(gradeb,'redMultiplier',1),get_float(gradeb,'greenMultiplier',1),get_float(gradeb,'blueMultiplier',1))

    stage=Image.open(ASSETS/bgname).convert('RGBA')
    draw=ImageDraw.Draw(stage,'RGBA')
    # Edge lines: curve-following calibrated ribbons.
    for curve,color in [(left,(240,247,255,72)),(right,(240,247,255,72))]:
        d=0
        while d<120:
            d1=min(120,d+3)
            a=int(color[3]*fade_alpha((d+d1)/2,edge_fade_start,edge_fade_end))
            if a>0: draw.polygon(ribbon_polygon(curve,left,right,d,d1,.16,road_width_m,5),fill=color[:3]+(a,))
            d=d1
    # 3m/6m centre markings.
    d=0
    while d+3<=120:
        a=int(235*fade_alpha(d+1.5,center_fade_start,center_fade_end))
        if a>0: draw.polygon(ribbon_polygon(center,left,right,d,d+3,.15,road_width_m,8),fill=(250,250,247,a))
        d+=9

    anchor_x=sx*W; anchor_y=sy*H
    place_shadow(stage,shadow,anchor_x,anchor_y-H*.006,W*body_w,W*body_h,body_a)
    # Logan III exact texture anchors.
    fullw=W*(vw/(901/1014)); fullh=fullw*(914/1014)
    for tx in (.164,.836):
        tire_x=anchor_x+(tx-.5)*fullw
        place_shadow(stage,shadow,tire_x,anchor_y,W*tire_w,W*tire_h,tire_a)
    place_shadow(stage,shadow,anchor_x,anchor_y,W*blend_w,W*blend_h,blend_a)
    car_scaled=car.resize((int(fullw),int(fullh)),Image.Resampling.LANCZOS)
    car_scaled=grade_vehicle(car_scaled,exposure,contrast,saturation,rgb)
    layer=Image.new('RGBA',(W,H),(0,0,0,0))
    layer.alpha_composite(car_scaled,(int(anchor_x-fullw/2),int(anchor_y-fullh*(828/914))))
    if abs(heading)>.01:
        layer=layer.rotate(-heading,resample=Image.Resampling.BICUBIC,center=(anchor_x,anchor_y))
    stage.alpha_composite(layer)
    results.append(stage.convert('RGB').resize((432,528),Image.Resampling.LANCZOS))

canvas=Image.new('RGB',(864,1056),'white')
for i,im in enumerate(results): canvas.paste(im,((i%2)*432,(i//2)*528))
canvas.save(OUT,quality=92)
print(OUT)
