package com.dcui.loganos.ui.cockpit.opengl

/** OpenGL ES 2.0 shader sources kept separate from renderer control flow. */
internal object DigitalV2Shaders {
    const val TEXTURED_VERTEX_SHADER = """
        attribute vec2 aPosition;
        attribute vec2 aTexCoord;
        varying vec2 vTexCoord;
        void main() {
            gl_Position = vec4(aPosition, 0.0, 1.0);
            vTexCoord = aTexCoord;
        }
    """



    /** Lightweight one-sample shader for backgrounds and premultiplied shadow assets. */
    const val SIMPLE_TEXTURED_FRAGMENT_SHADER = """
        precision mediump float;
        uniform sampler2D uTexture;
        uniform float uAlpha;
        uniform vec4 uColorMultiplier;
        varying vec2 vTexCoord;
        void main() {
            vec4 sampled = texture2D(uTexture, vTexCoord);
            float extraAlpha = uAlpha * uColorMultiplier.a;
            float outAlpha = sampled.a * extraAlpha;
            if (outAlpha <= 0.001) discard;
            gl_FragColor = vec4(
                sampled.rgb * uColorMultiplier.rgb * extraAlpha,
                outAlpha
            );
        }
    """

    /**
     * Android textures are premultiplied. The shader briefly unpremultiplies
     * for colour grading, then premultiplies exactly once for GL_ONE blending.
     * uTextureInfo = (texelX, texelY, edgeSoftness, unused)
     * uGrade       = (exposure, contrast, saturation, edgeSoftness)
     */
    const val VEHICLE_FRAGMENT_SHADER = """
        precision mediump float;
        uniform sampler2D uTexture;
        uniform float uAlpha;
        uniform vec4 uColorMultiplier;
        uniform vec4 uTextureInfo;
        uniform vec4 uGrade;
        uniform vec4 uGradeRgb;
        varying vec2 vTexCoord;
        void main() {
            vec4 centre = texture2D(uTexture, vTexCoord);
            vec2 texel = uTextureInfo.xy;
            vec4 neighbours = (
                texture2D(uTexture, vTexCoord + vec2(texel.x, 0.0)) +
                texture2D(uTexture, vTexCoord - vec2(texel.x, 0.0)) +
                texture2D(uTexture, vTexCoord + vec2(0.0, texel.y)) +
                texture2D(uTexture, vTexCoord - vec2(0.0, texel.y))
            ) * 0.25;
            float softness = clamp(uGrade.w, 0.0, 1.0) * 0.42;
            vec4 sampled = mix(centre, neighbours, softness);
            if (sampled.a <= 0.001) discard;

            vec3 straight = sampled.rgb / max(sampled.a, 0.001);
            straight *= uGrade.x;
            straight = (straight - 0.5) * uGrade.y + 0.5;
            float luma = dot(straight, vec3(0.2126, 0.7152, 0.0722));
            straight = mix(vec3(luma), straight, uGrade.z);
            straight *= uGradeRgb.rgb * uColorMultiplier.rgb;
            float lowerBodyShade = 1.0 - 0.18 * uGrade.w *
                smoothstep(0.52, 0.96, vTexCoord.y);
            straight *= lowerBodyShade;
            straight = clamp(straight, 0.0, 1.0);

            float outAlpha = sampled.a * uAlpha * uColorMultiplier.a;
            gl_FragColor = vec4(straight * outAlpha, outAlpha);
        }
    """

    const val SOLID_VERTEX_SHADER = """
        attribute vec2 aPosition;
        void main() {
            gl_Position = vec4(aPosition, 0.0, 1.0);
        }
    """

    const val SOLID_FRAGMENT_SHADER = """
        precision mediump float;
        uniform vec4 uColor;
        void main() {
            gl_FragColor = vec4(uColor.rgb * uColor.a, uColor.a);
        }
    """

    const val ROAD_SURFACE_VERTEX_SHADER = """
        attribute vec2 aPosition;
        attribute float aRoadDistance;
        attribute float aAcross;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            gl_Position = vec4(aPosition, 0.0, 1.0);
            vRoadDistance = aRoadDistance * 0.125;
            vAcross = aAcross;
        }
    """

    const val ROAD_SURFACE_FRAGMENT_SHADER = """
        precision mediump float;
        uniform float uPhaseMeters;
        uniform float uCycleMeters;
        uniform float uNearFadeMeters;
        uniform float uAlpha;
        uniform vec3 uTint;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            float sideMask = smoothstep(0.02, 0.12, vAcross) *
                (1.0 - smoothstep(0.88, 0.98, vAcross));
            float nearMask = 1.0 - smoothstep(uNearFadeMeters * 0.55, uNearFadeMeters, vRoadDistance);
            float local = mod(vRoadDistance + uPhaseMeters, uCycleMeters);
            float broad = smoothstep(0.0, uCycleMeters * 0.07, local) *
                (1.0 - smoothstep(uCycleMeters * 0.30, uCycleMeters * 0.49, local));
            float fineCycle = uCycleMeters * 0.24;
            float fineLocal = mod(vRoadDistance + uPhaseMeters * 1.7, fineCycle);
            float fine = smoothstep(0.0, fineCycle * 0.09, fineLocal) *
                (1.0 - smoothstep(fineCycle * 0.30, fineCycle * 0.48, fineLocal));
            float horizonFade = 1.0 - smoothstep(11.5, 15.0, vRoadDistance);
            float alpha = uAlpha * sideMask * nearMask * horizonFade *
                (0.58 * broad + 0.22 * fine);
            if (alpha <= 0.001) discard;
            gl_FragColor = vec4(uTint * alpha, alpha);
        }
    """

    const val WIND_VERTEX_SHADER = """
        attribute vec2 aPosition;
        attribute float aRoadDistance;
        attribute float aAcross;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            gl_Position = vec4(aPosition, 0.0, 1.0);
            vRoadDistance = aRoadDistance * 0.125;
            vAcross = aAcross;
        }
    """

    const val WIND_FRAGMENT_SHADER = """
        precision mediump float;
        uniform float uPhaseMeters;
        uniform float uSpacingMeters;
        uniform float uStreakLengthMeters;
        uniform float uPulseRadians;
        uniform float uAlpha;
        uniform float uSideSign;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            float sideMask = smoothstep(0.08, 0.28, vAcross) *
                (1.0 - smoothstep(0.72, 0.92, vAcross));
            float skewedDistance = vRoadDistance + uPhaseMeters +
                (vAcross - 0.5) * uSideSign * 1.25;
            float local = mod(skewedDistance, uSpacingMeters);
            float streak = smoothstep(0.0, uStreakLengthMeters * 0.10, local) *
                (1.0 - smoothstep(
                    uStreakLengthMeters * 0.82,
                    uStreakLengthMeters,
                    local
                ));
            float pulse = 0.62 + 0.38 * sin(uPulseRadians + vRoadDistance * 2.48);
            float distanceFade = 1.0 - smoothstep(6.5, 9.25, vRoadDistance);
            float alpha = uAlpha * sideMask * streak * pulse * distanceFade;
            if (alpha <= 0.001) discard;
            vec3 tint = vec3(0.88, 0.95, 1.0);
            gl_FragColor = vec4(tint * alpha, alpha);
        }
    """

    const val ROAD_VERTEX_SHADER = """
        attribute vec2 aPosition;
        attribute float aRoadDistance;
        attribute float aAcross;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            gl_Position = vec4(aPosition, 0.0, 1.0);
            vRoadDistance = aRoadDistance * 0.125;
            vAcross = aAcross;
        }
    """

    const val ROAD_FRAGMENT_SHADER = """
        precision mediump float;
        uniform vec4 uColor;
        uniform float uPhaseMeters;
        uniform float uRepeatMeters;
        uniform float uDashLengthMeters;
        uniform float uDashSoftnessMeters;
        uniform float uSideSoftness;
        uniform float uDashed;
        uniform float uFadeStartMeters;
        uniform float uFadeEndMeters;
        varying mediump float vRoadDistance;
        varying mediump float vAcross;
        void main() {
            float sideIn = smoothstep(0.0, uSideSoftness, vAcross);
            float sideOut = 1.0 - smoothstep(1.0 - uSideSoftness, 1.0, vAcross);
            float mask = sideIn * sideOut;
            if (uDashed > 0.5) {
                float localDistance = mod(vRoadDistance + uPhaseMeters, uRepeatMeters);
                float dashStart = smoothstep(0.0, uDashSoftnessMeters, localDistance);
                float dashEnd = 1.0 - smoothstep(
                    uDashLengthMeters - uDashSoftnessMeters,
                    uDashLengthMeters,
                    localDistance
                );
                mask *= dashStart * dashEnd;
            }
            mask *= 1.0 - smoothstep(uFadeStartMeters, uFadeEndMeters, vRoadDistance);
            float alpha = uColor.a * mask;
            if (alpha <= 0.002) discard;
            gl_FragColor = vec4(uColor.rgb * alpha, alpha);
        }
    """
}
