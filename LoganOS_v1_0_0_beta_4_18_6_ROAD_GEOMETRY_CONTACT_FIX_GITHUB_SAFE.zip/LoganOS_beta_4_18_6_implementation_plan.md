# LoganOS beta.4.18.6 — Uygulama Planı ve Kabul Listesi

## 1. Dört sahnenin yol geometrisi
- Dağ-Göl, Şehir Gündüz, Şehir Gece ve Karlı Yol için merkez çizgisi ile sol/sağ asfalt sınırları bağımsız piksel oranlarıyla tanımlanacak.
- Şehir sahnelerindeki dış çizgiler düz perspektif ışınları gibi yolun gerçek yanlarına yerleşecek.
- Dağ-Göl ve Karlı Yol dış çizgileri görüntüdeki virajlı asfalt omuzlarını takip edecek.

## 2. Viraj görünürlüğü
- Dağ-Göl merkez kesikleri 46 metrede solmaya başlayıp 66 metrede kaybolacak.
- Karlı Yol merkez kesikleri 48 metrede solmaya başlayıp 68 metrede kaybolacak.
- Böylece kesik çizgi virajın arkasına bir kurdele gibi kıvrılarak devam etmeyecek.
- Düz şehir yollarında merkez çizgisi 118 metreye kadar perspektifte küçülerek kalabilecek.

## 3. Sürekli yol kenar çizgileri
- Sol ve sağ sürekli beyaz çizgiler aracın yanındaki sanal şerit sınırına değil, görüntüde ölçülen dış asfalt sınırlarına bağlanacak.
- Çizgiler sahnenin uzak kısmında alfa ile yumuşak kaybolacak.

## 4. Araç ve zemin teması
- Araç görünür genişliği %33–33,5 aralığına çıkarılacak.
- Lastik temas yüksekliği %87–87,2 aralığına alınacak.
- Gövde gölgesi, iki lastik temas gölgesi ve aks altı ground-blend güçlendirilecek.
- Gölge assetlerinin alfa kapasitesi yükseltilecek; araç rengi her sahnenin ortam ışığına göre ayarlanacak.

## 5. Kullanılan Yakıt kartı
- İki satırlı başlık için ikon ve boşluklar küçültülecek.
- Değer ve `L` birimi aynı yatay baseline üzerinde gösterilecek.
- Değerin kartın altından kırpılması önlenecek.

## 6. Ayarlar önizlemesi
- Önizleme aynı sahne kalibrasyonlarını ve merkez/kenar görünürlük pencerelerini kullanacak.
- Virajlı merkez çizgisi önizlemede de aynı noktada kaybolacak.

## 7. Otomatik kontroller
- Dört sahnede yakın dış kenarlar ekranın gerçek yol yanlarına yakın olmalı.
- Merkez çizgisi her örnekte sol ve sağ sınır arasında kalmalı.
- Virajlı sahnelerin merkez çizgisi en geç 66–68 metrede kaybolmalı.
- Düz şehir sahneleri 110 metreden önce merkez çizgisini kaybetmemeli.
- Shader fade uniformları metre ölçeğiyle tutarlı olmalı.
- Eski genel Digital V2 yol motoruna dönüş sağlayan bir runtime yolu bulunmamalı.
- Kompakt Kullanılan Yakıt kartı değer ve birimi tek baseline üzerinde tutmalı.
