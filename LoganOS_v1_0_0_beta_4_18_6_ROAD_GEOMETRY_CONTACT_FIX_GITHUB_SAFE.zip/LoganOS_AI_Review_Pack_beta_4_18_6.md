# LoganOS beta.4.18.6 — Claude / Gemini inceleme paketi

## Amaç
Dijital V2 yol işaretlerinin görüntüdeki gerçek asfalt sınırlarıyla eşleştirilmesi, viraj arkasında kalan merkez çizgisinin görünürlük maskesiyle kaybolması, araç zemin temasının güçlendirilmesi ve Kullanılan Yakıt kartındaki kırpılmanın giderilmesi.

## Kritik dosyalar
- `DigitalV2SceneProfiles.kt`: dört bağımsız piksel kalibrasyonu ve görünürlük mesafeleri
- `DigitalV2SceneModel.kt`: `RoadMarkingVisibility` kontratı
- `DigitalV2Shaders.kt`: sahneye özel fade uniformları
- `DigitalV2Renderer.kt`: merkez/kenar çizgilerine ayrı fade uygulaması
- `DigitalV2Cockpit.kt`: ayarlar önizlemesi ve kompakt kart düzeni
- `validate_digital_v2_geometry.kt`: yol kenarı ve viraj görünürlüğü testleri

## İnceleme soruları
1. Dört sahnenin dış kenar eğrileri gerçek asfalt omuzlarına oturuyor mu?
2. Dağ-Göl ve Karlı Yol merkez kesikleri virajın arkasına kıvrılmadan 66–68 m aralığında doğal kayboluyor mu?
3. Shader mesafe ölçeklemesi fade uniformlarıyla tutarlı mı?
4. Araç gölgesi premultiplied-alpha akışında doğru mu?
5. Kompakt kart düzeni küçük telefonlarda `Kullanılan Yakıt` değerini kırpabilir mi?
6. Yeni kodda eski genel yol şablonuna dönüş sağlayan bir runtime yolu kalmış mı?

Kıdemli Android/OpenGL geliştiricisi gibi incele; somut dosya/satır düzeyinde hata ve düzeltme önerisi ver.
