# LoganOS beta.4.18.6 — Kaynak Denetimi

## Uygulananlar
- Dört arka planın merkez/sol/sağ yol eğrileri yeniden kalibre edildi.
- Şehir sahnelerindeki sürekli kenar çizgileri düz perspektif geometriye geçirildi.
- `RoadMarkingVisibility` eklendi; merkez ve dış çizgiler ayrı fade aralıkları kullanıyor.
- Dağ-Göl ve Karlı Yol merkez kesikleri virajın görünmeyen kısmına ulaşmadan kayboluyor.
- Yol shader'ına `uFadeStartMeters` ve `uFadeEndMeters` uniformları eklendi.
- Araç boyutu/temas yüksekliği ve üç parçalı zemin gölgesi güçlendirildi.
- Logan I ve Logan III temas gölgesi assetlerinin alfa aralığı yükseltildi.
- Kompakt metrik kartlarda değer ve birim tek baseline'a alındı; Kullanılan Yakıt kırpılması giderildi.
- Ayarlar önizlemesi runtime ile aynı görünürlük mesafelerini kullanıyor.

## Eski sistem taraması
Aşağıdaki emekli Digital V2 yolları runtime paketinde bulunmuyor:
- `RoadProjectionSample`
- `RoadProjectionProfile`
- `DigitalV2SceneEngine`
- `frameAtArc`
- `RoadFrame`
- baked road/wind animation kareleri

Dijital V1 ve Premium Drive dosyaları kendi ekranları için korunuyor; Digital V2 tarafından referans edilmiyor.

## Sınırlama
Bu ortamda Android SDK/Gradle Wrapper olmadığı için gerçek `assembleDebug` veya `assembleRelease` çalıştırılamadı. Kotlin/OpenGL kaynakları API stublarıyla, geometri ise gerçek JVM/kotlinc ile derlenip çalıştırıldı.
