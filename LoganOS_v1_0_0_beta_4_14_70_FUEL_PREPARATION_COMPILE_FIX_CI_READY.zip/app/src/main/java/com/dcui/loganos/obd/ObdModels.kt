package com.dcui.loganos.obd

import com.dcui.loganos.data.DriveHistoryItem
import com.dcui.loganos.data.DriveHistoryDetail
import com.dcui.loganos.data.HistoryStorageInfo
import com.dcui.loganos.data.TestHistoryItem
import com.dcui.loganos.data.TechnicalSessionItem
import com.dcui.loganos.data.VehicleHealthEvidence
import com.dcui.loganos.model.DashboardSnapshot


const val FUEL_LEVEL_DISCOVERY_TEST_NAME = "Depo seviyesi hazırlık taraması"

enum class ObdConnectionHealth {
    DISCONNECTED,
    CONNECTING,
    STABLE,
    UNSTABLE,
    RECONNECTING
}

data class PairedObdDevice(
    val name: String,
    val address: String
) {
    val displayName: String get() = if (name.isBlank()) address else "$name • $address"
}



data class CrankAnalysisResult(
    val timestampMs: Long,
    val manual: Boolean,
    val durationSec: Double,
    val startVoltage: Double?,
    val minVoltage: Double?,
    val engineTempC: Int?,
    val rpmAtFinish: Int?,
    val obdGapDetected: Boolean,
    val status: String,
    val batteryStatus: String,
    val comment: String
)

data class ObdState(
    val pairedDevices: List<PairedObdDevice> = emptyList(),
    val selectedAddress: String? = null,
    val selectedName: String? = null,
    val status: String = "Bluetooth cihazı bekleniyor",
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val connectionHealth: ObdConnectionHealth = ObdConnectionHealth.DISCONNECTED,
    val connectionHealthReason: String? = null,
    val signalHoldActive: Boolean = false,
    val connectionUnstableCount: Int = 0,
    val lastError: String? = null,
    val logText: String = "",
    val snapshot: DashboardSnapshot = DashboardSnapshot.empty(),
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val rawStandardObd: String = "",
    val supportedStandardPids: Set<Int> = emptySet(),
    val activeProfile: String = "DELPHI_DCM1_2",
    val timingText: String = "",
    val savedLogPath: String? = null,
    val savedLogFileName: String? = null,
    val sharedLogReady: Boolean = false,
    val activeDeveloperTest: String? = null,
    val developerTestPhaseText: String? = null,
    val developerTestRemainingSec: Int? = null,
    val developerTestProgressText: String? = null,
    val developerTestDoneMessage: String? = null,
    val sqlSessionId: Long? = null,
    val sqlDbPath: String? = null,
    val loopCount: Int = 0,
    val noDataCount: Int = 0,
    val stoppedCount: Int = 0,
    val busInitCount: Int = 0,
    val slowLoopCount: Int = 0,
    val timeTrusted: Boolean = true,
    val rawEcuLogEnabled: Boolean = false,
    val longTripLogEnabled: Boolean = false,
    val manualCrankArmed: Boolean = false,
    val crankingInProgress: Boolean = false,
    val lastAutoCrankResult: CrankAnalysisResult? = null,
    val recentAutoCrankResults: List<CrankAnalysisResult> = emptyList(),
    val savedManualCrankTests: List<CrankAnalysisResult> = emptyList(),
    val startEvents: List<StartEvent> = emptyList(),
    val startAnalysisSummary: StartAnalysisSummary = StartAnalysisSummary(),
    val driveHistory: List<DriveHistoryItem> = emptyList(),
    val driveHistoryDetail: DriveHistoryDetail? = null,
    val driveHistoryDetailLoading: Boolean = false,
    val testHistory: List<TestHistoryItem> = emptyList(),
    val technicalHistory: List<TechnicalSessionItem> = emptyList(),
    val historyStorage: HistoryStorageInfo = HistoryStorageInfo(),
    val vehicleHealthEvidence: VehicleHealthEvidence = VehicleHealthEvidence(),
    val gpsRouteEnabled: Boolean = false,
    val gpsRouteEligible: Boolean = false,
    val gpsRouteRecording: Boolean = false,
    val gpsRouteStatus: String = "Kapalı",
    val gpsRoutePointCount: Int = 0,
    val gpsLastAccuracyM: Float? = null,
    val exportInProgress: Boolean = false,
    val exportFeedbackMessage: String? = null,
    val exportFeedbackNonce: Long = 0L
)
