package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.BuildConfig
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.HeadUnitUiMode
import com.dcui.loganos.model.DefaultMediaApp
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.VehicleProfileSupport
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.model.VehicleColor
import com.dcui.loganos.obd.FUEL_LEVEL_DISCOVERY_TEST_NAME
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.theme.LoganPalette
import com.dcui.loganos.update.InstallLaunchResult
import com.dcui.loganos.update.SecureUpdateManager
import com.dcui.loganos.update.UpdateUiState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SettingsCategory(val title: String, val desc: String) {
    Language("Dil", "Türkçe / English"),
    AppearanceCockpit("Görünüm & Kokpit", "Tema, vurgu rengi, gösterge stili"),
    DriveFuel("Sürüş & Yakıt", "Yakıt fiyatı, kalibrasyon, tüketim"),
    VehicleMaintenance("Araç & Bakım", "Profil, kilometre, bakım aralıkları"),
    Connection("Bağlantı", "Bluetooth ve OBD adaptörü"),
    TripRecords("Sürüş ve Kayıtlar", "Smart Trip, geçmiş, dışa aktarma"),
    Developer("Geliştirici", "Testler, ham log, debug"),
    Updates("Güncellemeler", "Güvenli sürüm kontrolü ve kurulum"),
    About("Hakkında", "Sürüm, lisans, proje bilgisi")
}

private fun categoryTitle(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.title
    return when (category) {
        SettingsCategory.Language -> "Language"
        SettingsCategory.AppearanceCockpit -> "Appearance & Cockpit"
        SettingsCategory.DriveFuel -> "Trip & Fuel"
        SettingsCategory.VehicleMaintenance -> "Vehicle & Maintenance"
        SettingsCategory.Connection -> "Connection"
        SettingsCategory.TripRecords -> "Trips & Records"
        SettingsCategory.Developer -> "Developer"
        SettingsCategory.Updates -> "Updates"
        SettingsCategory.About -> "About"
    }
}

private fun categoryDesc(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.desc
    return when (category) {
        SettingsCategory.Language -> "Turkish / English"
        SettingsCategory.AppearanceCockpit -> "Theme, accent color, gauge style"
        SettingsCategory.DriveFuel -> "Fuel price, calibration, consumption"
        SettingsCategory.VehicleMaintenance -> "Profile, odometer, service intervals"
        SettingsCategory.Connection -> "Bluetooth and OBD adapter"
        SettingsCategory.TripRecords -> "Smart Trip, history, export"
        SettingsCategory.Developer -> "Tests, raw log, debug"
        SettingsCategory.Updates -> "Secure version checks and installation"
        SettingsCategory.About -> "Version, license, project info"
    }
}

private fun tx(language: AppLanguage, tr: String, en: String): String =
    if (language == AppLanguage.English) en else tr

private enum class TripRecordsSubPage { Main, DataManagement }

private sealed class SettingsDialog {
    data class Options(val title: String, val options: List<String>, val onSelect: (String) -> Unit) : SettingsDialog()
    data class TextInput(val title: String, val initial: String, val hint: String, val onSave: (String) -> Unit) : SettingsDialog()
    data class Calibration(
        val sessionActive: Boolean,
        val currentFactor: Double,
        val enabled: Boolean,
        val startTimeMs: Long,
        val startOdometerKm: Int,
        val autoDistanceKm: Double?,
        val autoAppLiters: Double?,
        val initialDistanceText: String,
        val canStart: Boolean,
        val unavailableReason: String?,
        val measurementFactor: Double,
        val onStart: () -> Unit,
        val onSave: (String, String, Double) -> Unit,
        val onCancelSession: () -> Unit,
        val onDisable: () -> Unit,
        val onReset: () -> Unit
    ) : SettingsDialog()
    data class Info(val title: String, val message: String) : SettingsDialog()
    data class Confirm(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit) : SettingsDialog()
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit
) {
    var selected by remember { mutableStateOf(SettingsCategory.Connection) }
    var portraitPage by remember { mutableStateOf<SettingsCategory?>(null) }
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }
    var vehicleVisualPickerOpen by remember { mutableStateOf(false) }

    BackHandler(enabled = vehicleVisualPickerOpen || portraitPage != null) {
        if (vehicleVisualPickerOpen) vehicleVisualPickerOpen = false else portraitPage = null
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSideMenu(palette, selected, settings.language, onSelect = { selected = it }, modifier = Modifier.width(220.dp).fillMaxHeight())
                if (vehicleVisualPickerOpen) {
                    VehicleVisualSelectionScreen(
                        palette = palette,
                        settings = settings,
                        onSave = { model, color ->
                            onSettingsChange(settings.copy(vehicleVisualModel = model, vehicleColor = color))
                            vehicleVisualPickerOpen = false
                        },
                        onCancel = { vehicleVisualPickerOpen = false },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                } else {
                    SettingsContent(
                        palette = palette,
                        category = selected,
                        settings = settings,
                        obdState = obdState,
                        snapshot = snapshot,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetMetrics = onResetMetrics,
                        onEndTripNow = onEndTripNow,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onExportTechnicalSession = onExportTechnicalSession,
                        onCreateSupportPackage = onCreateSupportPackage,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        onRefreshHistory = onRefreshHistory,
                        onOpenTripHistory = onOpenTripHistory,
                        onExportAllHistory = onExportAllHistory,
                        onCreateDataBackup = onCreateDataBackup,
                        onRestoreDataBackup = onRestoreDataBackup,
                        onOpenVehicleVisualPicker = { vehicleVisualPickerOpen = true },
                        openDialog = { dialog = it },
                        modifier = Modifier.weight(1f).fillMaxHeight()
                    )
                }
            }
        } else {
            if (vehicleVisualPickerOpen) {
                VehicleVisualSelectionScreen(
                    palette = palette,
                    settings = settings,
                    onSave = { model, color ->
                        onSettingsChange(settings.copy(vehicleVisualModel = model, vehicleColor = color))
                        vehicleVisualPickerOpen = false
                    },
                    onCancel = { vehicleVisualPickerOpen = false },
                    modifier = Modifier.fillMaxSize()
                )
            } else AnimatedContent(
                targetState = portraitPage,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally(animationSpec = tween(250)) { it } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeOut(animationSpec = tween(180)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { it } + fadeOut(animationSpec = tween(180)))
                    }
                },
                label = "settingsPortraitNav"
            ) { page ->
                if (page == null) {
                    SettingsCategoryList(palette = palette, language = settings.language, onOpen = {
                        selected = it
                        portraitPage = it
                    })
                } else {
                    SettingsDetailPage(
                        palette = palette,
                        category = page,
                        settings = settings,
                        obdState = obdState,
                        snapshot = snapshot,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetMetrics = onResetMetrics,
                        onEndTripNow = onEndTripNow,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onExportTechnicalSession = onExportTechnicalSession,
                        onCreateSupportPackage = onCreateSupportPackage,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        onRefreshHistory = onRefreshHistory,
                        onOpenTripHistory = onOpenTripHistory,
                        onExportAllHistory = onExportAllHistory,
                        onCreateDataBackup = onCreateDataBackup,
                        onRestoreDataBackup = onRestoreDataBackup,
                        onOpenVehicleVisualPicker = { vehicleVisualPickerOpen = true },
                        openDialog = { dialog = it },
                        onBack = { portraitPage = null }
                    )
                }
            }
        }
    }

    dialog?.let { current ->
        when (current) {
            is SettingsDialog.Options -> OptionDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.TextInput -> TextInputDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Calibration -> FuelCalibrationDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Info -> InfoDialog(palette, current, settings.language) { dialog = null }
            is SettingsDialog.Confirm -> ConfirmDialog(palette, current, settings.language) { dialog = null }
        }
    }
}

@Composable
private fun SettingsCategoryList(palette: LoganPalette, language: AppLanguage, onOpen: (SettingsCategory) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(8.dp))
        }
        SettingsCategory.entries.forEach { cat ->
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth(), onClick = { onOpen(cat) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(categoryTitle(cat, language), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text("›", color = palette.textSecondary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSideMenu(palette: LoganPalette, selected: SettingsCategory, language: AppLanguage, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(modifier = modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(6.dp))
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (active) palette.accent.copy(alpha = .12f) else palette.surface)
                    .clickable { onSelect(cat) }
                    .padding(12.dp)
            ) {
                Text(categoryTitle(cat, language), color = if (active) palette.accent else palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCompactSideMenu(palette: LoganPalette, selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .padding(vertical = 10.dp, horizontal = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("☰", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            val icon = when (cat) {
                SettingsCategory.Language -> CardIcon.Time
                SettingsCategory.AppearanceCockpit -> CardIcon.Speed
                SettingsCategory.DriveFuel -> CardIcon.Cost
                SettingsCategory.VehicleMaintenance -> CardIcon.Temperature
                SettingsCategory.Connection -> CardIcon.ObdConnection
                SettingsCategory.TripRecords -> CardIcon.Time
                SettingsCategory.Developer -> CardIcon.Injection
                SettingsCategory.Updates -> CardIcon.LogsSupport
                SettingsCategory.About -> CardIcon.Time
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) palette.accent else palette.surfaceVariant)
                    .clickable { onSelect(cat) },
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(
                    palette = palette,
                    icon = icon,
                    tint = if (active) palette.background else palette.textSecondary,
                    modifier = Modifier.size(27.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDetailPage(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onOpenVehicleVisualPicker: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = if (settings.language == AppLanguage.English) "‹ Settings" else "‹ Ayarlar",
            color = palette.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
        )
        SettingsContent(
            palette = palette,
            category = category,
            settings = settings,
            obdState = obdState,
            snapshot = snapshot,
            onSettingsChange = onSettingsChange,
            onResetSetup = onResetSetup,
            onResetMetrics = onResetMetrics,
            onEndTripNow = onEndTripNow,
            onRefreshObdDevices = onRefreshObdDevices,
            onSelectObdDevice = onSelectObdDevice,
            onConnectObd = onConnectObd,
            onDisconnectObd = onDisconnectObd,
            onSaveObdLog = onSaveObdLog,
            onShareObdLog = onShareObdLog,
            onExportTechnicalSession = onExportTechnicalSession,
            onCreateSupportPackage = onCreateSupportPackage,
            onClearLastObdLog = onClearLastObdLog,
            onClearAllObdLogs = onClearAllObdLogs,
            onDeveloperTestStart = onDeveloperTestStart,
            onDeveloperTestEnd = onDeveloperTestEnd,
            onRefreshHistory = onRefreshHistory,
            onOpenTripHistory = onOpenTripHistory,
            onExportAllHistory = onExportAllHistory,
            onCreateDataBackup = onCreateDataBackup,
            onRestoreDataBackup = onRestoreDataBackup,
            onOpenVehicleVisualPicker = onOpenVehicleVisualPicker,
            openDialog = openDialog,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun SettingsContent(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    snapshot: DashboardSnapshot,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onRefreshHistory: () -> Unit,
    onOpenTripHistory: () -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onOpenVehicleVisualPicker: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    modifier: Modifier
) {
    val context = LocalContext.current
    val appPrefs = remember(context.applicationContext) { AppPrefs(context.applicationContext) }
    var tripRecordsSubPage by remember(category) { mutableStateOf(TripRecordsSubPage.Main) }

    BackHandler(
        enabled = category == SettingsCategory.TripRecords && tripRecordsSubPage != TripRecordsSubPage.Main
    ) {
        tripRecordsSubPage = TripRecordsSubPage.Main
    }

    fun openFuelCalibrationDialog() {
        val activeFactor = if (settings.fuelCalibrationEnabled) {
            settings.fuelCalibrationFactor.coerceIn(0.50, 1.50)
        } else {
            1.0
        }
        val realObdTotalsAvailable = !settings.demoMode && !snapshot.demo && snapshot.connected
        val liveTotalsAvailable = realObdTotalsAvailable &&
            snapshot.tripToken != 0L &&
            snapshot.tripDistanceKm != null &&
            snapshot.fuelUsedL != null
        val currentTripToken = if (liveTotalsAvailable) snapshot.tripToken else obdState.snapshot.tripToken
        val currentDistance = if (liveTotalsAvailable) snapshot.tripDistanceKm else obdState.snapshot.tripDistanceKm
        val currentFuel = if (liveTotalsAvailable) {
            snapshot.fuelUsedL
        } else {
            obdState.snapshot.fuelUsedL?.times(activeFactor)
        }
        val currentOdometer = if (liveTotalsAvailable) {
            snapshot.odometerKm
        } else {
            val base = settings.odometerText.toIntOrNull()
            if (base != null && currentDistance != null) base + currentDistance.toInt() else obdState.snapshot.odometerKm
        }
        val canStart = settings.fuelCalculationSupported &&
            realObdTotalsAvailable &&
            currentTripToken != 0L &&
            currentDistance != null &&
            currentFuel != null

        // Flush the latest frame before opening the result dialog. Progress is
        // accumulated independently from automatic drive-history trip tokens, so
        // one full-tank measurement may safely span many starts and stops.
        val progress = if (
            settings.fuelCalibrationSessionActive &&
            realObdTotalsAvailable &&
            currentTripToken != 0L &&
            currentDistance != null &&
            currentFuel != null
        ) {
            appPrefs.updateFuelCalibrationProgress(
                tripToken = currentTripToken,
                distanceKm = currentDistance,
                fuelLiters = currentFuel,
                force = true
            )
        } else {
            appPrefs.loadFuelCalibrationProgress()
        }
        val autoDistance = progress.accumulatedDistanceKm.takeIf { it > 0.0 }
        val autoAppLiters = progress.accumulatedFuelLiters.takeIf { it > 0.0 }
        val unavailableReason = when {
            settings.demoMode || snapshot.demo -> tx(
                settings.language,
                "Demo Modu sırasında yakıt kalibrasyonu başlatılamaz veya ilerletilemez. Aktif ölçüm korunur ve gerçek OBD bağlantısında devam eder.",
                "Fuel calibration cannot start or advance in Demo Mode. An active measurement is preserved and resumes with a real OBD connection."
            )
            !settings.fuelCalculationSupported -> tx(
                settings.language,
                "Yakıt kalibrasyonu yalnız doğrulanmış dizel yakıt hesabında kullanılabilir.",
                "Fuel calibration is available only for the verified diesel fuel calculation."
            )
            !settings.fuelCalibrationSessionActive && !canStart -> tx(
                settings.language,
                "Ölçümü başlatmak için OBD bağlantısını açın ve yol bilgisayarı verilerinin görünmesini bekleyin.",
                "Connect OBD and wait for trip-computer values before starting the measurement."
            )
            else -> null
        }

        openDialog(
            SettingsDialog.Calibration(
                sessionActive = settings.fuelCalibrationSessionActive,
                currentFactor = settings.fuelCalibrationFactor,
                enabled = settings.fuelCalibrationEnabled,
                startTimeMs = settings.fuelCalibrationStartTimeMs,
                startOdometerKm = settings.fuelCalibrationStartOdometerKm,
                autoDistanceKm = autoDistance,
                autoAppLiters = autoAppLiters,
                initialDistanceText = autoDistance?.let {
                    String.format(Locale.US, "%.1f", it)
                } ?: "",
                canStart = canStart,
                unavailableReason = unavailableReason,
                measurementFactor = settings.fuelCalibrationSessionFactor.coerceIn(0.50, 1.50),
                onStart = {
                    appPrefs.startFuelCalibrationProgress(
                        tripToken = currentTripToken,
                        distanceKm = currentDistance ?: 0.0,
                        fuelLiters = currentFuel ?: 0.0
                    )
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationWarningAccepted = true,
                            fuelCalibrationSessionActive = true,
                            fuelCalibrationStartDistanceKm = currentDistance ?: 0.0,
                            fuelCalibrationStartFuelLiters = currentFuel ?: 0.0,
                            fuelCalibrationStartTripToken = currentTripToken,
                            fuelCalibrationStartOdometerKm = currentOdometer ?: 0,
                            fuelCalibrationStartTimeMs = System.currentTimeMillis(),
                            fuelCalibrationSessionFactor = activeFactor,
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                },
                onSave = { pumpLiters, appLiters, factor ->
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = true,
                            fuelCalibrationFactor = factor,
                            fuelCalibrationAppLitersText = appLiters,
                            fuelCalibrationPumpLitersText = pumpLiters,
                            fuelCalibrationWarningAccepted = true,
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                },
                onCancelSession = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0,
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                },
                onDisable = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) },
                onReset = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = false,
                            fuelCalibrationFactor = 1.0,
                            fuelCalibrationAppLitersText = "",
                            fuelCalibrationPumpLitersText = "",
                            fuelCalibrationSessionActive = false,
                            fuelCalibrationStartDistanceKm = 0.0,
                            fuelCalibrationStartFuelLiters = 0.0,
                            fuelCalibrationStartTripToken = 0L,
                            fuelCalibrationStartOdometerKm = 0,
                            fuelCalibrationStartTimeMs = 0L,
                            fuelCalibrationSessionFactor = 1.0
                        )
                    )
                    appPrefs.clearFuelCalibrationProgress()
                }
            )
        )
    }

    fun openFuelCalibrationFlow() {
        if (settings.fuelCalibrationWarningAccepted) {
            openFuelCalibrationDialog()
        } else {
            openDialog(
                SettingsDialog.Confirm(
                    title = tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                    message = tx(
                        settings.language,
                        "Bu özellik, yakıt tüketimi ve maliyet hesabını full depo yöntemine göre kalibre eder.\n\nDepoyu tamamen doldurduktan sonra ölçümü başlatın. En az 100 km, tercihen 200–300 km kullanıp depoyu yeniden aynı seviyeye kadar doldurun. Ölçüm boyunca LoganOS ve OBD bağlantısını kullanın; OBD olmadan yapılan sürüşler hesaplanan litreye eklenemez. İkinci dolumda yalnızca pompadan alınan litreyi girin; LoganOS kendi hesapladığı yakıtı otomatik kullanır.\n\nYanlış pompa veya mesafe bilgisi hesapları etkileyebilir. İstediğiniz zaman fabrika hesabına dönebilirsiniz.",
                        "This feature calibrates fuel-consumption and cost calculations using the full-tank method.\n\nStart the measurement after filling the tank completely. Drive at least 100 km, preferably 200–300 km, then refill to the same level. Keep LoganOS and the OBD connection active throughout the measurement; driving without OBD cannot be added to the calculated liters. At the second fill, enter only the pump liters; LoganOS uses its own calculated fuel automatically.\n\nIncorrect pump or distance information can affect the calculations. You can return to the factory calculation at any time."
                    ),
                    confirmLabel = tx(settings.language, "Anladım, devam et", "I understand, continue"),
                    onConfirm = {
                        onSettingsChange(settings.copy(fuelCalibrationWarningAccepted = true))
                        openFuelCalibrationDialog()
                    }
                )
            )
        }
    }

    if (category == SettingsCategory.TripRecords && tripRecordsSubPage == TripRecordsSubPage.DataManagement) {
        OemCard(palette, modifier = modifier.fillMaxWidth()) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                item {
                    Text(
                        tx(settings.language, "‹ Sürüş ve Kayıtlar", "‹ Trips & Records"),
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { tripRecordsSubPage = TripRecordsSubPage.Main }
                            .padding(horizontal = 4.dp, vertical = 5.dp)
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Yedekleme ve veri yönetimi", "Backup & data management"),
                        color = palette.accent,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        tx(
                            settings.language,
                            "Ayarları ve sürüş/test kayıtlarını yedekleyin, geri yükleyin veya temizleyin.",
                            "Back up, restore or clear settings and drive/test records."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "YEDEKLEME", "BACKUP")) }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Yedek oluştur", "Create backup"),
                        tx(settings.language, "Ayarlar ile sürüş/test geçmişini taşınabilir ZIP olarak kaydeder.", "Saves settings and drive/test history as a portable ZIP."),
                        tx(settings.language, "Yedekle", "Backup"),
                        onClick = onCreateDataBackup
                    )
                }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Yedeği geri yükle", "Restore backup"),
                        tx(settings.language, "Seçilen LoganOS yedeği mevcut ayar ve geçmişin yerine geçer.", "The selected LoganOS backup replaces current settings and history."),
                        tx(settings.language, "Geri yükle", "Restore"),
                        onClick = {
                            openDialog(SettingsDialog.Confirm(
                                tx(settings.language, "Yedek geri yüklensin mi?", "Restore backup?"),
                                tx(settings.language, "Mevcut ayarlar ve sürüş/test veritabanı seçilen yedekle değiştirilecek. Dosya yapısı, SHA-256 bütünlüğü ve SQLite veritabanı sağlığı geri yüklemeden önce doğrulanır.", "Current settings and the drive/test database will be replaced by the selected backup. File structure, SHA-256 integrity and SQLite database health are verified before restore."),
                                tx(settings.language, "Dosya seç", "Choose file")
                            ) { onRestoreDataBackup() })
                        }
                    )
                }
                item { SettingsSectionHeader(palette, tx(settings.language, "TEMİZLEME", "CLEANUP")) }
                item {
                    SettingsRow(
                        palette,
                        tx(settings.language, "Tüm geçmişi ve teknik logları temizle", "Clear all history and technical logs"),
                        tx(settings.language, "Sürüş/test geçmişini, ilişkili örnekleri ve LoganOS loglarını kalıcı olarak siler.", "Permanently deletes drive/test history, related samples and LoganOS logs."),
                        tx(settings.language, "Temizle", "Clear"),
                        onClick = {
                            openDialog(SettingsDialog.Confirm(
                                tx(settings.language, "Tüm kayıtlar temizlensin mi?", "Clear all records?"),
                                tx(settings.language, "Tüm sürüş ve test geçmişi, ilişkili SQL örnekleri ve LoganOS logları kalıcı olarak silinecek. Bu işlem geri alınamaz.", "All drive and test history, related SQL samples and LoganOS logs will be permanently deleted. This cannot be undone."),
                                tx(settings.language, "Tümünü sil", "Delete all")
                            ) { onClearAllObdLogs() })
                        }
                    )
                }
                item {
                    Text(
                        tx(settings.language, "Aktif OBD bağlantısı sırasında yedekleme ve geri yükleme işlemleri güvenlik nedeniyle engellenir.", "Backup and restore are blocked for safety while an OBD connection is active."),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 15.sp,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )
                }
            }
        }
        return
    }

    OemCard(palette, modifier = modifier.fillMaxWidth()) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            item {
                Text(categoryTitle(category, settings.language), color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(categoryDesc(category, settings.language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.sp)
            }
            item { Spacer(Modifier.height(4.dp)) }
            when (category) {
                SettingsCategory.Language -> {
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "Türkçe",
                            subtitle = "Uygulamayı Türkçe kullan",
                            value = if (settings.language == AppLanguage.Turkish) "✓ Seçili" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.Turkish)) }
                        )
                    }
                    item {
                        SettingsRow(
                            palette = palette,
                            title = "English",
                            subtitle = "Use LoganOS in English",
                            value = if (settings.language == AppLanguage.English) "✓ Selected" else null,
                            onClick = { onSettingsChange(settings.copy(language = AppLanguage.English)) }
                        )
                    }
                }
                SettingsCategory.AppearanceCockpit -> {
                    item { SettingsRow(palette, tx(settings.language, "Koyu Tema", "Dark Theme"), tx(settings.language, "OEM Dark görünümü", "OEM dark appearance"), trailingSwitch = settings.darkMode, onSwitch = { onSettingsChange(settings.copy(darkMode = it)) }) }
                    item { SettingsRow(palette, tx(settings.language, "Vurgu Rengi", "Accent Color"), tx(settings.language, "Tüm LOGANOS vurgu rengi", "Main LOGANOS accent color"), settings.accentColor.label, onClick = { openDialog(SettingsDialog.Options(tx(settings.language, "Vurgu Rengi", "Accent Color"), AccentColor.entries.map { it.label }) { label -> AccentColor.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(accentColor = it)) } }) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Cihaz Kullanım Modu", "Device Usage Mode"),
                            tx(settings.language, "Otomatik algıla veya Telefon / Double seçimini zorla", "Auto-detect or force Phone / Head Unit mode"),
                            deviceModeLabel(settings.deviceMode, settings.language),
                            onClick = {
                                val options = DeviceMode.entries.map { deviceModeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Cihaz Kullanım Modu", "Device Usage Mode"), options) { label ->
                                    DeviceMode.entries.firstOrNull { deviceModeLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(deviceMode = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Double Arayüzü", "Head Unit Interface"),
                            tx(settings.language, "Ghost seçildiğinde Standart Kokpit otomatik etkinleşir", "Standard Cockpit is selected automatically for Ghost styles"),
                            headUnitUiModeLabel(settings.headUnitUiMode, settings.language),
                            onClick = {
                                val options = HeadUnitUiMode.entries.map { headUnitUiModeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Double Arayüzü", "Head Unit Interface"), options) { label ->
                                    HeadUnitUiMode.entries.firstOrNull { headUnitUiModeLabel(it, settings.language) == label }?.let { mode ->
                                        val ghostSelected = settings.gaugeStyle == GaugeStyle.GhostSingle ||
                                            settings.gaugeStyle == GaugeStyle.GhostDual
                                        onSettingsChange(
                                            if (mode == HeadUnitUiMode.PremiumDrive && ghostSelected) {
                                                // Premium Drive owns the full Double cockpit. Resolve the
                                                // mutually exclusive selection instead of silently hiding Ghost.
                                                settings.copy(headUnitUiMode = mode, gaugeStyle = GaugeStyle.Digital)
                                            } else {
                                                settings.copy(headUnitUiMode = mode)
                                            }
                                        )
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Varsayılan Müzik Uygulaması", "Default Music App"),
                            tx(settings.language, "Premium Drive medya kartında kullanılacak uygulama", "App used by the Premium Drive media card"),
                            defaultMediaAppLabel(settings.defaultMediaApp, settings.language),
                            onClick = {
                                val options = DefaultMediaApp.entries.map { defaultMediaAppLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Varsayılan Müzik Uygulaması", "Default Music App"), options) { label ->
                                    DefaultMediaApp.entries.firstOrNull { defaultMediaAppLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(defaultMediaApp = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Gösterge Stili", "Gauge Style"),
                            tx(settings.language, "Digital OEM, Classic veya Ghost kokpit", "Digital OEM, Classic or Ghost cockpit"),
                            gaugeStyleLabel(settings.gaugeStyle, settings.language),
                            onClick = {
                                val enabled = listOf(GaugeStyle.Digital, GaugeStyle.ClassicOem, GaugeStyle.GhostSingle, GaugeStyle.GhostDual)
                                val options = enabled.map { gaugeStyleLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Gösterge Stili", "Gauge Style"), options) { label ->
                                    enabled.firstOrNull { gaugeStyleLabel(it, settings.language) == label }?.let { style ->
                                        val ghostSelected = style == GaugeStyle.GhostSingle || style == GaugeStyle.GhostDual
                                        onSettingsChange(
                                            settings.copy(
                                                gaugeStyle = style,
                                                headUnitUiMode = if (ghostSelected) HeadUnitUiMode.Standard else settings.headUnitUiMode
                                            )
                                        )
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Araç Görünümü", "Vehicle Appearance"),
                            tx(settings.language, "Kokpitlerde kullanılacak Logan kasasını ve rengini seç", "Choose the Logan generation and colour used in cockpits"),
                            vehicleVisualSummary(settings, settings.language),
                            onClick = onOpenVehicleVisualPicker
                        )
                    }
                    if (settings.gaugeStyle == GaugeStyle.GhostDual) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Ghost Dual kadran yerleşimi", "Ghost Dual dial layout"),
                                tx(settings.language, "İstersen hız solda / devir sağda olacak şekilde yer değiştir", "Swap the speed and RPM dial positions whenever you want"),
                                if (settings.ghostDualSpeedOnLeft) tx(settings.language, "Hız solda", "Speed on left") else tx(settings.language, "Devir solda", "RPM on left"),
                                trailingSwitch = settings.ghostDualSpeedOnLeft,
                                onSwitch = { onSettingsChange(settings.copy(ghostDualSpeedOnLeft = it)) },
                                onClick = { onSettingsChange(settings.copy(ghostDualSpeedOnLeft = !settings.ghostDualSpeedOnLeft)) }
                            )
                        }
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yazı Boyutu", "Text Size"),
                            tx(settings.language, "Kart metinleri ve hız göstergesi ölçeği", "Text scale for cards and speed gauge"),
                            cockpitTextSizeLabel(settings.cockpitTextSize, settings.language),
                            onClick = {
                                val options = CockpitTextSize.entries.map { cockpitTextSizeLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yazı Boyutu", "Text Size"), options) { label ->
                                    CockpitTextSize.entries.firstOrNull { cockpitTextSizeLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitTextSize = it)) }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"),
                            tx(settings.language, "Kart, boşluk ve gösterge alanı düzeni", "Card, spacing and gauge area layout"),
                            cockpitDensityLabel(settings.cockpitDensity, settings.language),
                            onClick = {
                                val options = CockpitDensity.entries.map { cockpitDensityLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Kokpit Yoğunluğu", "Cockpit Density"), options) { label ->
                                    CockpitDensity.entries.firstOrNull { cockpitDensityLabel(it, settings.language) == label }?.let { onSettingsChange(settings.copy(cockpitDensity = it)) }
                                })
                            }
                        )
                    }
                }
                SettingsCategory.DriveFuel -> {
                    if (!settings.fuelCalculationSupported) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Yakıt Hesabı Doğrulanmadı", "Fuel Calculation Not Verified"),
                                tx(
                                    settings.language,
                                    "Benzinli deneysel profilde tüketim, maliyet ve kalibrasyon kapalıdır. Önce enjeksiyon veya ECU yakıt debisi kaynağı doğrulanmalıdır.",
                                    "Consumption, cost and calibration stay disabled for the experimental petrol profile until an injection or ECU fuel-rate source is verified."
                                ),
                                tx(settings.language, "Deneysel", "Experimental")
                            )
                        }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), tx(settings.language, "Maliyet hesabı doğrulandığında kullanılacak litre fiyatı", "Fuel price to use after cost calculation is verified"), fuelPriceDisplay(settings.fuelPriceText, settings.language), onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Yakıt Fiyatı", "Fuel Price"), settings.fuelPriceText, tx(settings.language, "Örn. 45,50", "e.g. 45.50")) { v -> onSettingsChange(settings.copy(fuelPriceText = v)) }) }) }
                    if (settings.fuelCalculationSupported) {
                        item { SettingsRow(
                            palette,
                            tx(settings.language, "Ortalama + maliyeti sıfırla", "Reset Average + Cost"),
                            tx(settings.language, "Mesafe, toplam yakıt ve sürüş süresi korunur", "Distance, total fuel and trip time are preserved"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Hesaplar sıfırlansın mı?", "Reset calculations?"),
                                    tx(settings.language, "Ortalama tüketim ve sürüş maliyeti bu noktadan yeniden başlayacak. Yolculuk toplamları silinmez.", "Average consumption and trip cost will restart from this point. Trip totals will not be deleted."),
                                    tx(settings.language, "Sıfırla", "Reset")
                                ) { onResetMetrics(TripMetricReset.AverageAndCost) })
                            }
                        ) }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Sürüş sırasında ekranı açık tut", "Keep Screen On While Driving"), tx(settings.language, "Sürüşte telefon ekranının kapanmasını engeller", "Prevents the phone screen from turning off while driving"), trailingSwitch = settings.keepScreenOn, onSwitch = { onSettingsChange(settings.copy(keepScreenOn = it)) }) }
                    item { SettingsRow(
                        palette,
                        tx(settings.language, "Arka planda sürüşü sürdür", "Continue Driving in Background"),
                        tx(settings.language, "Başka uygulamaya geçince OBD bağlantısı ve aktif sürüş kaydı Foreground Service ile devam eder", "Keeps the OBD connection and active drive recording running through a Foreground Service when you leave LoganOS"),
                        trailingSwitch = settings.backgroundTripEnabled,
                        onSwitch = { onSettingsChange(settings.copy(backgroundTripEnabled = it)) }
                    ) }
                    if (settings.fuelCalculationSupported) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                                tx(settings.language, "Full depo yöntemiyle otomatik kalibrasyon", "Automatic calibration with the full-tank method"),
                                when {
                                    settings.fuelCalibrationSessionActive -> tx(settings.language, "Ölçüm sürüyor", "Measuring")
                                    settings.fuelCalibrationEnabled -> "x${String.format(java.util.Locale.US, "%.3f", settings.fuelCalibrationFactor)}"
                                    else -> tx(settings.language, "Kapalı", "Off")
                                },
                                onClick = { openFuelCalibrationFlow() }
                            )
                        }
                    }
                }
                SettingsCategory.VehicleMaintenance -> {
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Motor / Yakıt Profili", "Engine / Fuel Profile"),
                            if (settings.fuelType == FuelType.Petrol) {
                                tx(settings.language, "Deneysel topluluk testi • tüketim hesabı kapalı • değişiklik yeniden bağlantıda uygulanır", "Experimental community test • fuel calculation disabled • applies after reconnect")
                            } else {
                                tx(settings.language, "Doğrulanmış Delphi DCM1.2 dizel profili • değişiklik yeniden bağlantıda uygulanır", "Verified Delphi DCM1.2 diesel profile • applies after reconnect")
                            },
                            if (settings.fuelType == FuelType.Petrol) tx(settings.language, "Benzinli Deneysel", "Petrol Experimental") else tx(settings.language, "1.5 dCi Doğrulanmış", "1.5 dCi Verified"),
                            onClick = {
                                if (settings.fuelType == FuelType.Petrol) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Doğrulanmış dizel profile dönülsün mü?", "Return to the verified diesel profile?"),
                                            tx(settings.language, "Araç profili 1.5 dCi 68 bg / Delphi DCM1.2 olarak ayarlanacak. Aktif OBD bağlantısı varsa yeniden bağlanmanız gerekir.", "The vehicle profile will be set to 1.5 dCi 68 hp / Delphi DCM1.2. Reconnect if OBD is currently active."),
                                            tx(settings.language, "Dizel Profile Geç", "Use Diesel Profile")
                                        ) {
                                            onSettingsChange(
                                                settings.copy(
                                                    engine = "1.5 dCi 68 bg",
                                                    fuelType = FuelType.Diesel,
                                                    profileSupport = VehicleProfileSupport.Verified,
                                                    modelYearText = "2006",
                                                    engineCodeText = "K9K",
                                                    engineDisplacementCcText = "1461",
                                                    enginePowerHpText = "68",
                                                    cylinderCount = 4,
                                                    experimentalProfileAccepted = false
                                                )
                                            )
                                        }
                                    )
                                } else {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Benzinli deneysel profil açılsın mı?", "Enable the experimental petrol profile?"),
                                            tx(settings.language, "Bu profil henüz uyumlu kabul edilmez. RPM, hız ve hararet gibi temel veriler çalışabilir; tüketim ve maliyet gösterilmez. Salt-okunur OBD test kayıtlarını paylaşarak geliştirmeye katkıda bulunabilirsiniz. Aktif bağlantı varsa yeniden bağlanmanız gerekir.", "This profile is not yet considered compatible. Basic values such as RPM, speed and coolant may work; consumption and cost are hidden. You can help development by sharing read-only OBD test records. Reconnect if OBD is active."),
                                            tx(settings.language, "Deneysel Profili Aç", "Enable Experimental Profile")
                                        ) {
                                            onSettingsChange(
                                                settings.copy(
                                                    engine = "Benzinli motor • Topluluk testi",
                                                    fuelType = FuelType.Petrol,
                                                    profileSupport = VehicleProfileSupport.Experimental,
                                                    modelYearText = settings.modelYearText.ifBlank { "2006" },
                                                    engineCodeText = "",
                                                    engineDisplacementCcText = "1390",
                                                    enginePowerHpText = "75",
                                                    cylinderCount = 4,
                                                    experimentalProfileAccepted = true,
                                                    fuelCalibrationEnabled = false
                                                )
                                            )
                                        }
                                    )
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Araç", "Vehicle"),
                            vehicleProfileSubtitle(settings),
                            settings.vehicleModel,
                            onClick = {
                                openDialog(
                                    SettingsDialog.Info(
                                        tx(settings.language, "Araç Profili", "Vehicle Profile"),
                                        vehicleProfileInfo(settings)
                                    )
                                )
                            }
                        )
                    }
                    if (settings.fuelType == FuelType.Petrol) {
                        item { SettingsRow(palette, tx(settings.language, "Model Yılı", "Model Year"), tx(settings.language, "Destek paketi araç kimliği", "Vehicle identity for support packages"), settings.modelYearText, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Model Yılı", "Model Year"), settings.modelYearText, "2006") { v -> onSettingsChange(settings.copy(modelYearText = v.filter(Char::isDigit).take(4))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Hacmi", "Engine Displacement"), tx(settings.language, "Santimetreküp (cc)", "Cubic centimeters (cc)"), "${settings.engineDisplacementCcText} cc", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Hacmi", "Engine Displacement"), settings.engineDisplacementCcText, "1390") { v -> onSettingsChange(settings.copy(engineDisplacementCcText = v.filter(Char::isDigit).take(5))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Kodu", "Engine Code"), tx(settings.language, "Bilinmiyorsa boş bırakılabilir", "May be left blank if unknown"), settings.engineCodeText.ifBlank { "--" }, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Kodu", "Engine Code"), settings.engineCodeText, "K7J") { v -> onSettingsChange(settings.copy(engineCodeText = v.uppercase().take(20))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Motor Gücü", "Engine Power"), tx(settings.language, "Beygir gücü", "Horsepower"), "${settings.enginePowerHpText} bg", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Gücü", "Engine Power"), settings.enginePowerHpText, "75") { v -> onSettingsChange(settings.copy(enginePowerHpText = v.filter(Char::isDigit).take(4))) }) }) }
                        item { SettingsRow(palette, tx(settings.language, "Silindir Sayısı", "Cylinder Count"), tx(settings.language, "Destek paketi ve gelecekteki ECU profili için", "For the support package and a future ECU profile"), settings.cylinderCount.toString(), onClick = { openDialog(SettingsDialog.Options(tx(settings.language, "Silindir Sayısı", "Cylinder Count"), (1..12).map(Int::toString)) { label -> onSettingsChange(settings.copy(cylinderCount = label.toIntOrNull()?.coerceIn(1, 12) ?: settings.cylinderCount)) }) }) }
                    }
                    item { SettingsRow(palette, tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), tx(settings.language, "Gösterge kilometresini kalibre et", "Calibrate the dashboard odometer"), settings.odometerText, onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Kilometre Eşitleme", "Odometer Sync"), settings.odometerText, tx(settings.language, "Örn. 335420", "e.g. 335420")) { v -> onSettingsChange(settings.copy(odometerText = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Motor Yağı", "Engine Oil"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.oilServiceKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Motor Yağı Aralığı", "Engine Oil Interval"), settings.oilServiceKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(oilServiceKm = v)) }) }) }
                    item { SettingsRow(palette, if (settings.fuelType == FuelType.Petrol) tx(settings.language, "Yakıt Filtresi", "Fuel Filter") else tx(settings.language, "Mazot Filtresi", "Fuel Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.fuelFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Mazot Filtresi Aralığı", "Fuel Filter Interval"), settings.fuelFilterKm, tx(settings.language, "Örn. 20000", "e.g. 20000")) { v -> onSettingsChange(settings.copy(fuelFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Hava Filtresi", "Air Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.airFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Hava Filtresi Aralığı", "Air Filter Interval"), settings.airFilterKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(airFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Polen Filtresi", "Cabin Filter"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.pollenFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Polen Filtresi Aralığı", "Cabin Filter Interval"), settings.pollenFilterKm, tx(settings.language, "Örn. 10000", "e.g. 10000")) { v -> onSettingsChange(settings.copy(pollenFilterKm = v)) }) }) }
                    item { SettingsRow(palette, tx(settings.language, "Triger Seti", "Timing Belt Kit"), tx(settings.language, "Bakım aralığı", "Service interval"), "${settings.timingBeltKm} km", onClick = { openDialog(SettingsDialog.TextInput(tx(settings.language, "Triger Seti Aralığı", "Timing Belt Interval"), settings.timingBeltKm, tx(settings.language, "Örn. 60000", "e.g. 60000")) { v -> onSettingsChange(settings.copy(timingBeltKm = v)) }) }) }
                }
                SettingsCategory.Connection -> {
                    item {
                        ObdConnectionPanel(
                            palette = palette,
                            obdState = obdState,
                            demoMode = settings.demoMode,
                            onRefresh = onRefreshObdDevices,
                            onSelect = onSelectObdDevice,
                            onConnect = onConnectObd,
                            onDisconnect = onDisconnectObd,
                            language = settings.language
                        )
                    }
                }
                SettingsCategory.TripRecords -> {
                    item { SettingsSectionHeader(palette, tx(settings.language, "SÜRÜŞ AYARLARI", "TRIP SETTINGS")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yeni sürüş ayırma süresi", "New trip break time"),
                            tx(
                                settings.language,
                                "Kısa molalarda sürüş aynı kayıtta kalır. Seçilen süre aşılırsa yeni sürüş başlatılır.",
                                "Short stops stay in the same record. A new trip starts when the selected time is exceeded."
                            ),
                            smartTripLabel(settings.smartTripMinutes, settings.language),
                            subtitleMaxLines = 3,
                            onClick = {
                                val minutes = listOf(0, 15, 30, 60, 90, 120)
                                val options = minutes.map { smartTripLabel(it, settings.language) }
                                openDialog(SettingsDialog.Options(tx(settings.language, "Yeni sürüş ayırma süresi", "New trip break time"), options) { label ->
                                    minutes.firstOrNull { smartTripLabel(it, settings.language) == label }?.let {
                                        onSettingsChange(settings.copy(smartTripMinutes = it))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "GPS rota kaydı", "GPS route recording"),
                            if (settings.deviceMode == DeviceMode.HeadUnit) {
                                tx(settings.language, "İlk sürümde yalnız Telefon modu desteklenir.", "The first release supports Phone mode only.")
                            } else {
                                tx(settings.language, "Sürüş sırasında rotayı cihazda kaydeder.", "Records the route on this device while driving.")
                            },
                            trailingSwitch = settings.gpsRouteEnabled,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "GPS rota kaydı", "GPS route recording"),
                                            tx(
                                                settings.language,
                                                "LoganOS sürüş rotasını GPS ile cihazınızda kaydeder ve tamamlanan sürüş analizinde harita üzerinde gösterir. Rota, Sürüş Geçmişi kaydına bağlı olduğu için bu özelliği açmak otomatik sürüş geçmişini de açar. Konum izni verilmezse LoganOS, OBD ve sürüş kaydı normal çalışmaya devam eder; yalnız rota özelliği kapalı kalır. Rota verisi destek paketlerine eklenmez ve varsayılan yedekten hariç tutulur.",
                                                "LoganOS records your driving route with GPS on this device and shows it on the completed-drive analysis map. Because routes belong to Drive History records, enabling this feature also enables automatic drive history. If location permission is denied, LoganOS, OBD and drive recording continue normally; only route recording stays disabled. Route data is excluded from support packages and the default backup."
                                            ),
                                            tx(settings.language, "Konum iznine devam et", "Continue to location permission")
                                        ) { onSettingsChange(settings.copy(gpsRouteEnabled = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(gpsRouteEnabled = false))
                                }
                            }
                        )
                    }
                    if (settings.gpsRouteEnabled) {
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "GPX başlangıç/bitiş gizliliği", "GPX start/end privacy"),
                                tx(settings.language, "Dışa aktarılan rotanın ilk ve son yaklaşık 200 metresini gizler.", "Hides roughly the first and last 200 meters of the exported route."),
                                trailingSwitch = settings.gpsMaskExportEdges,
                                onSwitch = { enabled -> onSettingsChange(settings.copy(gpsMaskExportEdges = enabled)) }
                            )
                        }
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşü şimdi bitir", "End trip now"),
                            tx(settings.language, "Mevcut geçmiş kaydını tamamlar ve yeni sürüş bekler.", "Completes the current history record and waits for a new trip."),
                            tx(settings.language, "Bitir", "End"),
                            onClick = {
                                openDialog(SettingsDialog.Confirm(
                                    tx(settings.language, "Sürüş şimdi bitirilsin mi?", "End trip now?"),
                                    tx(settings.language, "Mevcut sürüş geçmişi kaydı tamamlanacak. Kokpit mesafe, yakıt, süre, ortalama ve maliyet toplamları korunacak.", "The current drive-history record will be completed. Cockpit distance, fuel, time, average and cost totals will be preserved."),
                                    tx(settings.language, "Sürüşü bitir", "End trip")
                                ) { onEndTripNow() })
                            }
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "GEÇMİŞ", "HISTORY")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüş ve test geçmişi", "Drive and test history"),
                            tx(
                                settings.language,
                                "${obdState.historyStorage.driveRecordCount} sürüş • ${obdState.historyStorage.testRecordCount} test • ${formatHistoryBytes(obdState.historyStorage.databaseBytes)}",
                                "${obdState.historyStorage.driveRecordCount} drives • ${obdState.historyStorage.testRecordCount} tests • ${formatHistoryBytes(obdState.historyStorage.databaseBytes)}"
                            ),
                            tx(settings.language, "Görüntüle", "View"),
                            onClick = {
                                onRefreshHistory()
                                onOpenTripHistory()
                            }
                        )
                    }
                    item {
                        val recordCount = obdState.historyStorage.driveRecordCount + obdState.historyStorage.testRecordCount
                        SettingsRow(
                            palette,
                            tx(settings.language, "Tüm geçmişi dışa aktar", "Export all history"),
                            when {
                                obdState.exportInProgress -> tx(settings.language, "Dışa aktarma paketi hazırlanıyor.", "The export package is being prepared.")
                                recordCount <= 0 -> tx(settings.language, "Dışa aktarılacak sürüş veya test kaydı yok.", "There are no drive or test records to export.")
                                else -> tx(settings.language, "Sürüş ve test kayıtlarını tek paket halinde dışa aktarır.", "Exports drive and test records in one package.")
                            },
                            if (obdState.exportInProgress) tx(settings.language, "Hazırlanıyor…", "Preparing…") else tx(settings.language, "Dışa aktar", "Export"),
                            onClick = if (!obdState.exportInProgress && recordCount > 0) onExportAllHistory else null
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "KAYIT AYARLARI", "RECORDING SETTINGS")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüşleri otomatik kaydet", "Save drives automatically"),
                            tx(settings.language, "Tamamlanan sürüşleri geçmişte saklar.", "Keeps completed drives in history."),
                            trailingSwitch = settings.driveHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik sürüş kaydı kapatılsın mı?", "Disable automatic drive history?"),
                                            tx(settings.language, "Yeni sürüşler geçmişe eklenmeyecek. Mevcut kayıtlar silinmez; canlı kokpit ve yol bilgisayarı çalışmaya devam eder.", "New drives will not be added to history. Existing records will remain; the live cockpit and trip computer will continue to work."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(driveHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(driveHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"),
                            tx(settings.language, "Sabitlenen kayıtlar bu sınıra dahil edilmez.", "Pinned records do not count toward this limit."),
                            historyLimitLabel(settings.driveHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Sürüş geçmişi sınırı", "Drive history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.driveHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.driveHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Sürüşler siz silene kadar saklanır ve zamanla depolama alanı kullanabilir.", "Drives will remain until you delete them and may use more storage over time."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski sürüşler silinsin mi?", "Delete older drives?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan sürüş kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned drives."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(driveHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(driveHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Testleri otomatik kaydet", "Save tests automatically"),
                            tx(settings.language, "Manuel ve geliştirici testlerini geçmişte saklar.", "Keeps manual and developer tests in history."),
                            trailingSwitch = settings.testHistoryEnabled,
                            onSwitch = { enabled ->
                                if (!enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Otomatik test kaydı kapatılsın mı?", "Disable automatic test history?"),
                                            tx(settings.language, "Yeni manuel ve geliştirici testleri Test Geçmişi'ne eklenmeyecek. Mevcut test kayıtları silinmez.", "New manual and developer tests will not be added to Test History. Existing test records will remain."),
                                            tx(settings.language, "Kapat", "Disable")
                                        ) { onSettingsChange(settings.copy(testHistoryEnabled = false)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(testHistoryEnabled = true))
                                }
                            }
                        )
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Test geçmişi sınırı", "Test history limit"),
                            tx(settings.language, "Sabitlenen testler otomatik silinmez.", "Pinned tests are never auto-deleted."),
                            historyLimitLabel(settings.testHistoryLimit, settings.language),
                            onClick = {
                                val labels = historyLimitOptions(settings.language)
                                openDialog(SettingsDialog.Options(tx(settings.language, "Test geçmişi sınırı", "Test history limit"), labels) { label ->
                                    val newLimit = historyLimitFromLabel(label)
                                    val currentCount = obdState.testHistory.count { !it.pinned && !it.activeLike }
                                    if (newLimit < 0 && settings.testHistoryLimit >= 0) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Sınırsız saklama açılsın mı?", "Enable unlimited retention?"),
                                            tx(settings.language, "Test kayıtları siz silene kadar saklanır ve zamanla depolama alanı kullanabilir.", "Test records will remain until you delete them and may use more storage over time."),
                                            tx(settings.language, "Sınırsız sakla", "Keep unlimited")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = -1)) })
                                    } else if (newLimit >= 0 && newLimit < currentCount) {
                                        openDialog(SettingsDialog.Confirm(
                                            tx(settings.language, "Eski testler silinsin mi?", "Delete older tests?"),
                                            tx(settings.language, "Sınır $newLimit yapılırsa en eski ${currentCount - newLimit} korunmayan test kalıcı olarak silinecek.", "Setting the limit to $newLimit will permanently delete the oldest ${currentCount - newLimit} unpinned tests."),
                                            tx(settings.language, "Uygula ve sil", "Apply and delete")
                                        ) { onSettingsChange(settings.copy(testHistoryLimit = newLimit)) })
                                    } else {
                                        onSettingsChange(settings.copy(testHistoryLimit = newLimit))
                                    }
                                })
                            }
                        )
                    }

                    item { SettingsSectionHeader(palette, tx(settings.language, "VERİ YÖNETİMİ", "DATA MANAGEMENT")) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Yedekleme ve veri yönetimi", "Backup & data management"),
                            tx(settings.language, "Ayarları ve kayıtları yedekle, geri yükle veya temizle.", "Back up, restore or clear settings and records."),
                            onClick = { tripRecordsSubPage = TripRecordsSubPage.DataManagement }
                        )
                    }
                }
                SettingsCategory.Developer -> {
                    item { SettingsRow(palette, tx(settings.language, "Geliştirici Modu", "Developer Mode"), tx(settings.language, "Testler ve teknik debug seçeneklerini açar", "Enables tests and technical debug options"), trailingSwitch = settings.developerModeEnabled, onSwitch = { enabled -> onSettingsChange(settings.copy(developerModeEnabled = enabled, rawEcuLogEnabled = if (enabled) settings.rawEcuLogEnabled else false)) }) }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Demo Modu", "Demo Mode"),
                            tx(settings.language, "Yalnız bu oturumda simülasyon kullanır; gerçek OBD bağlantısını güvenle kapatır", "Uses simulation only for this session and safely closes the real OBD connection"),
                            trailingSwitch = settings.demoMode,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            tx(settings.language, "Demo Modu", "Demo Mode"),
                                            tx(settings.language, "Bu mod gerçek araç verisi göstermez.\n\nAçılırsa mevcut OBD bağlantısı ve bekleyen yeniden bağlanma işlemi kapatılır. Uygulama yeniden açıldığında Demo Modu otomatik olarak kapalı başlar.", "This mode does not show real vehicle data.\n\nEnabling it closes the current OBD connection and any pending reconnect. Demo Mode always starts disabled after the app is reopened."),
                                            tx(settings.language, "Demo Modunu Aç", "Enable Demo Mode")
                                        ) { onSettingsChange(settings.copy(demoMode = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(demoMode = false))
                                }
                            }
                        )
                    }
                    if (settings.developerModeEnabled) {
                        item { SettingsRow(palette, tx(settings.language, "Geliştirici Ham Log", "Developer Raw Log"), tx(settings.language, "Ham ECU paketlerini ayrıca kaydeder; normalde kapalı kalmalı", "Stores raw ECU packets separately; normally keep this off"), trailingSwitch = settings.rawEcuLogEnabled, onSwitch = { onSettingsChange(settings.copy(rawEcuLogEnabled = it)) }) }
                        item { DeveloperTestRows(palette, obdState.activeDeveloperTest, settings.language, settings.isExperimentalPetrol, onDeveloperTestStart, onDeveloperTestEnd) }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Son geçerli teknik kaydı dışa aktar", "Export last valid technical log"),
                                tx(settings.language, "Örnek içeren en son OBD oturumunu dışa aktarır; sıfır örnekli bağlantı hataları önceki geçerli kaydın önüne geçmez", "Exports the latest OBD session containing samples; zero-sample connection failures do not replace the previous valid log"),
                                tx(settings.language, "Dışa Aktar", "Export"),
                                onClick = {
                                    openDialog(SettingsDialog.Confirm(
                                        tx(settings.language, "Teknik kayıt dışa aktarılsın mı?", "Export technical log?"),
                                        tx(settings.language, "Teknik kayıt araç ve OBD bilgisi içerebilir. Ham ECU paketleri yalnız Geliştirici Ham Log açıksa dahil edilir.", "The technical log may contain vehicle and OBD information. Raw ECU packets are included only when Developer Raw Log is enabled."),
                                        tx(settings.language, "Dışa Aktar", "Export")
                                    ) { onSaveObdLog() })
                                }
                            )
                        }
                        item { SettingsRow(palette, tx(settings.language, "Son geçerli teknik kaydı paylaş", "Share last valid technical log"), tx(settings.language, "Örnek içeren en son OBD oturumunu paylaşır", "Shares the latest OBD session containing samples"), tx(settings.language, "Paylaş", "Share"), onClick = onShareObdLog) }
                        val visibleTechnicalHistory = obdState.technicalHistory
                            .filter { session ->
                                session.activeLike || session.sampleCount > 0 || session.status in setOf("INTERRUPTED", "RECOVERED", "UNSTABLE", "ERROR")
                            }
                            .take(10)
                        if (visibleTechnicalHistory.isNotEmpty()) {
                            item {
                                Column(modifier = Modifier.padding(top = 8.dp, bottom = 3.dp)) {
                                    Text(
                                        tx(settings.language, "Teknik kayıt geçmişi", "Technical log history"),
                                        color = palette.textPrimary,
                                        fontSize = 18.sp,
                                        fontWeight = FontWeight.Black
                                    )
                                    Text(
                                        tx(
                                            settings.language,
                                            "OBD bağlantılarını, ECU örneklerini ve bağlantı kapanışlarını hata analizi için saklar. Veri içermeyen kısa bağlantı denemeleri listede gösterilmez.",
                                            "Stores OBD connections, ECU samples and connection endings for diagnostics. Short attempts without data are hidden from this list."
                                        ),
                                        color = palette.textSecondary,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }
                            }
                            visibleTechnicalHistory.forEach { session ->
                                item(key = "technical_session_${session.id}") {
                                    val started = if (session.timeTrusted && session.startedAtMs > 0L) {
                                        SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale.getDefault()).format(Date(session.startedAtMs))
                                    } else {
                                        tx(settings.language, "Saat bekleniyor", "Time pending")
                                    }
                                    val durationSec = session.durationMs.coerceAtLeast(0L) / 1000L
                                    val durationText = "%02d:%02d".format(Locale.US, durationSec / 60L, durationSec % 60L)
                                    val statusText = when (session.status) {
                                        "ACTIVE" -> tx(settings.language, "Aktif", "Active")
                                        "ENDED", "ENDED_IGNITION_OFF" -> tx(settings.language, "Kontak kapatıldı", "Ignition off")
                                        "ENDED_IGNITION_WAIT" -> tx(settings.language, "Veri alınmadan sona erdi", "Ended without data")
                                        "RECOVERED" -> tx(settings.language, "Kurtarıldı", "Recovered")
                                        "INTERRUPTED" -> tx(settings.language, "Yarım kaldı", "Interrupted")
                                        "UNSTABLE" -> tx(settings.language, "Bağlantı kararsız", "Connection unstable")
                                        "ERROR" -> tx(settings.language, "Bağlantı hatası", "Connection error")
                                        else -> session.status.replace('_', ' ').lowercase().replaceFirstChar { it.uppercase() }
                                    }
                                    SettingsRow(
                                        palette,
                                        tx(settings.language, "Teknik oturum #${session.id}", "Technical session #${session.id}"),
                                        "$started • $durationText • ${session.sampleCount} ${tx(settings.language, "örnek", "samples")} • $statusText",
                                        tx(settings.language, "Dışa aktar", "Export"),
                                        onClick = { onExportTechnicalSession(session.id) }
                                    )
                                }
                            }
                        }
                        item {
                            SettingsRow(
                                palette,
                                tx(settings.language, "Destek Paketi Oluştur", "Create Support Package"),
                                tx(settings.language, "Son geçerli kayıtla birlikte son 10 teknik OBD oturumunu ZIP olarak hazırlar", "Creates a ZIP containing the last valid log and the 10 most recent technical OBD sessions"),
                                tx(settings.language, "Oluştur", "Create"),
                                onClick = {
                                    openDialog(SettingsDialog.Confirm(
                                        tx(settings.language, "Destek paketi oluşturulsun mu?", "Create support package?"),
                                        tx(settings.language, "ZIP son geçerli kaydı ve son 10 teknik oturumu içerir. Sıfır örnekli bağlantı hataları da teşhis için ayrı dosya olarak eklenir. Bluetooth adresi maskelenir; ham ECU paketleri yalnız Geliştirici Ham Log açıksa eklenir.", "The ZIP contains the last valid log and the 10 most recent technical sessions. Zero-sample connection failures are included as separate diagnostic files. The Bluetooth address is masked; raw ECU packets are added only when Developer Raw Log is enabled."),
                                        tx(settings.language, "Oluştur", "Create")
                                    ) { onCreateSupportPackage() })
                                }
                            )
                        }
                        obdState.savedLogPath?.let { path ->
                            item { Text(tx(settings.language, "Son teknik dosya", "Last technical file") + ": $path", color = palette.textSecondary, fontSize = 11.sp, maxLines = 2) }
                        }
                    }
                }
                SettingsCategory.Updates -> {
                    item {
                        SecureUpdateSettingsPanel(
                            palette = palette,
                            language = settings.language
                        )
                    }
                }
                SettingsCategory.About -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
                            Text("LOGANOS", color = palette.textPrimary, fontSize = 26.sp, fontWeight = FontWeight.Black)
                            Text(
                                tx(settings.language, "Sürüm ${BuildConfig.VERSION_NAME}", "Version ${BuildConfig.VERSION_NAME}"),
                                color = palette.accent,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                tx(settings.language, "Dacia Logan 1.5 dCi için geliştirilen bağımsız OBD ve dijital kokpit uygulaması.", "An independent OBD and digital cockpit application developed for the Dacia Logan 1.5 dCi."),
                                color = palette.textSecondary,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Teknik altyapı", "Technical foundation"))
                            AboutBody(palette, "Fuel Truth • Smart Trip")
                            AboutBody(palette, "Delphi DCM1.2 • KWP2000 Fast Init")

                            AboutSectionTitle(palette, tx(settings.language, "Proje", "Project"))
                            AboutBody(palette, tx(settings.language, "Ücretsiz, reklamsız ve GPLv3 açık kaynaklıdır.", "Free, ad-free and open source under GPLv3."))

                            AboutSectionTitle(palette, tx(settings.language, "Gizlilik", "Privacy"))
                            AboutBody(palette, tx(settings.language, "Veriler cihazda saklanır. Kayıtlar yalnızca kullanıcı dışa aktardığında cihaz dışına çıkar.", "Data is stored on the device. Records leave the device only when the user exports them."))

                            AboutSectionTitle(palette, tx(settings.language, "Bağımsızlık bildirimi", "Independence notice"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "LoganOS bağımsız olarak geliştirilmiştir. Renault Group veya Dacia ile resmî bağlantısı bulunmamaktadır.",
                                    "LoganOS is independently developed and is not officially affiliated with Renault Group or Dacia."
                                )
                            )

                            AboutSectionTitle(palette, tx(settings.language, "Geliştirme araçları", "Development tools"))
                            AboutBody(
                                palette,
                                tx(
                                    settings.language,
                                    "Geliştirme sürecinde ChatGPT, Gemini ve Claude yapay zekâ araçlarından yararlanılmıştır.",
                                    "ChatGPT, Gemini and Claude AI tools were used during development."
                                )
                            )
                        }
                    }
                    item {
                        SettingsRow(
                            palette,
                            tx(settings.language, "Kurulum Sihirbazını Yeniden Başlat", "Restart Setup Wizard"),
                            tx(settings.language, "İlk kurulum tercihlerini yeniden seç; kayıtlar ve geçmiş korunur", "Choose initial setup preferences again; records and history are preserved"),
                            tx(settings.language, "Onay", "Confirm"),
                            onClick = {
                                openDialog(
                                    SettingsDialog.Confirm(
                                        tx(settings.language, "Kurulum yeniden başlatılsın mı?", "Restart setup?"),
                                        tx(settings.language, "İlk kurulum ekranı yeniden açılacak. Sürüş geçmişi, test kayıtları ve log dosyaları silinmez.", "The initial setup screen will open again. Drive history, test records and log files will not be deleted."),
                                        tx(settings.language, "Yeniden Başlat", "Restart")
                                    ) { onResetSetup() }
                                )
                            }
                        )
                    }
                }
            }
        }
    }
}


@Composable
private fun SecureUpdateSettingsPanel(
    palette: LoganPalette,
    language: AppLanguage
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val manager = remember { SecureUpdateManager(context.applicationContext) }
    var state by remember { mutableStateOf<UpdateUiState>(manager.initialState()) }

    fun checkNow() {
        if (state is UpdateUiState.Checking || state is UpdateUiState.Downloading) return
        state = UpdateUiState.Checking
        scope.launch { state = manager.checkForUpdate() }
    }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (manager.shouldAutoCheck()) checkNow()
    }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 8.dp, bottom = 10.dp)) {
        Text(
            tx(language, "Güvenli Güncelleme Merkezi", "Secure Update Center"),
            color = palette.textPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Black
        )
        Text(
            tx(
                language,
                "Yeni LoganOS sürümlerini kontrol et, indir ve güvenli biçimde yükle.",
                "Check, download and securely install new LoganOS versions."
            ),
            color = palette.textSecondary,
            fontSize = 13.sp,
            lineHeight = 19.sp
        )

        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text(
                    tx(language, "Mevcut sürüm", "Current version"),
                    color = palette.textSecondary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(BuildConfig.VERSION_NAME, color = palette.textPrimary, fontSize = 19.sp, fontWeight = FontWeight.Black)
            }
        }

        when (val current = state) {
            is UpdateUiState.Idle -> {
                current.lastCheckedAtMs?.let { checkedAt ->
                    Text(
                        tx(language, "Son kontrol", "Last check") + ": " + updateTimeText(checkedAt),
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
                UpdateActionButton(
                    palette,
                    tx(language, "Güncellemeleri kontrol et", "Check for updates"),
                    enabled = manager.isRepositoryConfigured(),
                    onClick = ::checkNow
                )
                if (!manager.isRepositoryConfigured()) {
                    Text(
                        tx(
                            language,
                            "Bu kaynak ZIP'inden yerel derleme yapılırsa depo kimliği boş kalabilir. GitHub Actions derlemesinde GITHUB_REPOSITORY otomatik olarak uygulamaya gömülür.",
                            "A local build from the source ZIP may have no repository identity. GitHub Actions automatically embeds GITHUB_REPOSITORY into the app."
                        ),
                        color = palette.textSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
            UpdateUiState.Checking -> {
                Text(tx(language, "Güvenli sürüm kontrolü yapılıyor…", "Checking securely for updates…"), color = palette.accent, fontWeight = FontWeight.Bold)
            }
            is UpdateUiState.UpToDate -> {
                Text(tx(language, "LoganOS güncel", "LoganOS is up to date"), color = palette.accent, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text(updateTimeText(current.checkedAtMs), color = palette.textSecondary, fontSize = 12.sp)
                UpdateActionButton(palette, tx(language, "Tekrar kontrol et", "Check again"), onClick = ::checkNow)
            }
            is UpdateUiState.Available -> {
                UpdateReleaseCard(palette, language, current.release.versionName, current.release.releaseNotes)
                UpdateActionButton(
                    palette,
                    tx(language, "İndir ve doğrula", "Download and verify")
                ) {
                    state = UpdateUiState.Downloading(current.release, 0)
                    scope.launch {
                        state = manager.downloadAndVerify(current.release) { progress ->
                            scope.launch { state = UpdateUiState.Downloading(current.release, progress) }
                        }
                    }
                }
            }
            is UpdateUiState.Downloading -> {
                Text(
                    tx(language, "Güncelleme indiriliyor ve doğrulanıyor", "Downloading and verifying update"),
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Black
                )
                Text("%${current.progressPercent}", color = palette.accent, fontSize = 24.sp, fontWeight = FontWeight.Black)
                Text(
                    tx(language, "İmza doğrulanmadan kurulum başlatılmaz.", "Installation cannot start until the signature is verified."),
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
            }
            is UpdateUiState.ReadyToInstall -> {
                UpdateReleaseCard(palette, language, current.release.versionName, current.release.releaseNotes)
                Text(
                    tx(language, "✓ APK kimliği ve imza sertifikası doğrulandı", "✓ APK identity and signing certificate verified"),
                    color = palette.accent,
                    fontWeight = FontWeight.Black
                )
                Text(
                    tx(language, "İmza SHA-256", "Signer SHA-256") + ": " + current.signerSha256.take(16) + "…",
                    color = palette.textSecondary,
                    fontSize = 11.sp
                )
                UpdateActionButton(palette, tx(language, "Android kurucusunu aç", "Open Android installer")) {
                    try {
                        when (manager.requestInstall(current.apkPath)) {
                            InstallLaunchResult.INSTALLER_OPENED -> Unit
                            InstallLaunchResult.UNKNOWN_SOURCES_SETTINGS_OPENED -> Unit
                        }
                    } catch (error: Exception) {
                        state = UpdateUiState.Error(error.message ?: tx(language, "Kurulum başlatılamadı", "Installation could not be started"))
                    }
                }
            }
            is UpdateUiState.Error -> {
                Text(
                    tx(language, "İşlem tamamlanamadı", "The operation could not be completed"),
                    color = palette.textPrimary,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Black
                )
                Text(current.message, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
                UpdateActionButton(palette, tx(language, "Yeniden kontrol et", "Check again"), onClick = ::checkNow)
            }
        }

        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Text(
                tx(
                    language,
                    "✓ Güncellemeler, mevcut LoganOS kurulumunun uygulama imzasıyla doğrulanır.",
                    "✓ Updates are verified against the signing identity of the installed LoganOS app."
                ),
                color = palette.accent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun UpdateReleaseCard(
    palette: LoganPalette,
    language: AppLanguage,
    versionName: String,
    releaseNotes: String
) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(tx(language, "Yeni sürüm mevcut", "New version available"), color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Text(versionName, color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
            if (releaseNotes.isNotBlank()) {
                Text(
                    releaseNotes.take(1200),
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    lineHeight = 17.sp,
                    maxLines = 12
                )
            }
        }
    }
}

@Composable
private fun UpdateActionButton(
    palette: LoganPalette,
    label: String,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(if (enabled) palette.textPrimary else palette.surfaceVariant)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 13.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (enabled) palette.background else palette.textSecondary,
            fontWeight = FontWeight.Black,
            fontSize = 14.sp
        )
    }
}

private fun updateTimeText(timeMs: Long): String =
    java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date(timeMs))


@Composable
private fun AboutSectionTitle(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.accent,
        fontSize = 14.sp,
        fontWeight = FontWeight.Black
    )
}

@Composable
private fun AboutBody(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.textSecondary,
        fontSize = 14.sp,
        lineHeight = 20.sp
    )
}

@Composable
private fun SettingsSectionHeader(palette: LoganPalette, text: String) {
    Text(
        text = text,
        color = palette.accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 0.7.sp,
        modifier = Modifier.padding(start = 4.dp, top = 10.dp, bottom = 2.dp)
    )
}

private fun historyLimitOptions(language: AppLanguage): List<String> = listOf(
    "10", "25", "50", if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
)

private fun historyLimitFromLabel(label: String): Int = when {
    label.equals("Unlimited", true) || label.equals("Sınırsız", true) -> -1
    else -> label.toIntOrNull() ?: 10
}

private fun historyLimitLabel(limit: Int, language: AppLanguage): String =
    if (limit < 0) {
        if (language == AppLanguage.English) "Unlimited" else "Sınırsız"
    } else limit.toString()

private fun formatHistoryBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(java.util.Locale.US, "%.1f KB", kb)
    return String.format(java.util.Locale.US, "%.1f MB", kb / 1024.0)
}


@Composable
private fun DeveloperTestRows(
    palette: LoganPalette,
    activeTest: String?,
    language: AppLanguage,
    petrolExperimental: Boolean,
    onStart: (String) -> Unit,
    onEnd: () -> Unit
) {
    val tests = if (petrolExperimental) {
        listOf(
            "Benzinli soğuk çalıştırma testi" to tx(language, "Motor tamamen soğukken marş + 3 dakika rölanti; standart fuel-rate ve ilgili OBD adayları kaydedilir", "Cold engine start + 3 minutes idle; standard fuel-rate and related OBD candidates are recorded"),
            "Benzinli sıcak rölanti testi" to tx(language, "Motor sıcakken yükler kapalı 60 sn → klima açık 60 sn → kapalı 30 sn", "Warm engine, loads off 60s → A/C on 60s → off 30s"),
            "Benzinli sabit devir testi" to tx(language, "Boşta 2000 rpm 30 sn → 3000 rpm 20 sn → rölanti", "Hold 2000 rpm 30s → 3000 rpm 20s → idle"),
            "Benzinli hızlanma testi" to tx(language, "Güvenli yolda hafif ve orta yükte hızlan; ham PID değişimleri kaydedilir", "Accelerate at light and medium load on a safe road; raw PID changes are recorded"),
            "Benzinli DFCO testi" to tx(language, "20-30 km/h üstünde viteste gazı tamamen bırak; yakıt kesme adayı aranır", "Release throttle fully in gear above 20-30 km/h; a fuel-cut candidate is searched"),
            "Benzinli serbest sürüş testi" to tx(language, "5 dk yönlendirmeli şehir içi ham Mode 01 kaydı", "5-minute guided city drive with raw Mode 01 recording")
        )
    } else {
        listOf(
            FUEL_LEVEL_DISCOVERY_TEST_NAME to tx(
                language,
                "Yakıt almadan önce yapılır. Düz zeminde, kontak açık ve motor kapalıyken motor ECU ile erişilebilen KWP modüllerini tarar; 10–20 dakika sürebilir",
                "Run before refuelling. With ignition on and engine off, scans the engine ECU and reachable KWP modules; may take 10–20 minutes"
            ),
            "Sıcak rölanti testi" to tx(language, "Klima kapalı 60 sn → açık 60 sn → kapalı 30 sn", "A/C off 60s → on 60s → off 30s"),
            "Klima testi" to tx(language, "Klima kapalı 30 sn → açık 30 sn → kapalı 30 sn", "A/C off 30s → on 30s → off 30s"),
            "Elektrik/yük testi" to tx(language, "Klima kapalı; far, rezistans ve kalorifer fanını sırayla aç", "A/C off; enable lights, rear defrost and cabin fan one by one"),
            "Tam yük testi" to tx(language, "Far, sis, rezistans, kalorifer fanı ve klimayı birlikte aç", "Turn on lights, fog, rear defrost, cabin fan and A/C together"),
            "Yakıt kesme (CUTOFF) testi" to tx(language, "20-30 km/h üstünde gazı bırak; yakıt kesme beklenir", "Release throttle above 20-30 km/h; fuel cut-off is expected"),
            "Serbest sürüş testi" to tx(language, "5 dk yönlendirmeli şehir içi kayıt", "5-minute guided city drive recording")
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(tx(language, "Geliştirici Testleri", "Developer Tests"), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
        if (activeTest != null) {
            SettingsRow(
                palette = palette,
                title = tx(language, "Aktif test: $activeTest", "Active test: $activeTest"),
                subtitle = tx(language, "Bitirince test kaydı kapatılır", "Ending closes the test record"),
                value = tx(language, "Bitir", "End"),
                onClick = onEnd
            )
        }
        tests.forEach { (name, desc) ->
            val running = activeTest == name
            SettingsRow(
                palette = palette,
                title = name,
                subtitle = desc,
                value = if (running) tx(language, "Bitir", "End") else tx(language, "Başlat", "Start"),
                onClick = { if (running) onEnd() else onStart(name) }
            )
        }
    }
}


private fun gaugeStyleLabel(style: GaugeStyle, language: AppLanguage): String = when (style) {
    GaugeStyle.Digital -> "Digital OEM"
    GaugeStyle.ClassicOem -> "Classic"
    GaugeStyle.GhostSingle -> "Ghost Single"
    GaugeStyle.GhostDual -> "Ghost Dual"
}

private fun vehicleProfileSubtitle(settings: LoganSettings): String {
    return if (settings.fuelType == FuelType.Petrol) {
        "${settings.modelYearText} • ${settings.engineDisplacementCcText} cc • ${settings.enginePowerHpText} bg • ${if (settings.language == AppLanguage.English) "experimental petrol" else "deneysel benzinli"}"
    } else {
        "2005-2012 Sedan/MCV • ${settings.engine}"
    }
}

private fun vehicleProfileInfo(settings: LoganSettings): String {
    return if (settings.fuelType == FuelType.Petrol) {
        tx(
            settings.language,
            "Bu profil topluluk testi içindir. RPM, hız, hararet ve standart OBD parametreleri okunabilir. Tüketim ve maliyet, doğrudan enjeksiyon miktarı, enjeksiyon süresi veya ECU yakıt debisi doğrulanana kadar kapalıdır. Destek paketinde araç yılı, hacim, motor kodu, güç ve silindir bilgileri yer alır.",
            "This profile is for community testing. RPM, speed, coolant and standard OBD parameters may work. Consumption and cost stay disabled until a direct injection quantity, injector pulse width or ECU fuel-rate source is verified. Support packages include model year, displacement, engine code, power and cylinder count."
        )
    } else {
        tx(
            settings.language,
            "Tam destek 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. Diğer 1.5 dCi profilleri deneysel olarak değerlendirilir.",
            "Full support is for the 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 hp. Other 1.5 dCi profiles are treated as experimental."
        )
    }
}

private fun deviceModeLabel(mode: DeviceMode, language: AppLanguage): String = when (mode) {
    DeviceMode.Auto -> tx(language, "Otomatik", "Automatic")
    DeviceMode.Phone -> tx(language, "Telefon", "Phone")
    DeviceMode.HeadUnit -> tx(language, "Android Multimedya / Double", "Android Multimedia / Head Unit")
}

private fun headUnitUiModeLabel(mode: HeadUnitUiMode, language: AppLanguage): String =
    if (language == AppLanguage.English) mode.enLabel else mode.trLabel

private fun defaultMediaAppLabel(app: DefaultMediaApp, language: AppLanguage): String =
    if (language == AppLanguage.English) app.enLabel else app.trLabel

private fun smartTripLabel(minutes: Int, language: AppLanguage): String = when (minutes) {
    0 -> tx(language, "Her kontakta yeni sürüş", "New trip at every ignition")
    15 -> tx(language, "15 dakika", "15 minutes")
    30 -> tx(language, "30 dakika", "30 minutes")
    60 -> tx(language, "60 dakika", "60 minutes")
    90 -> tx(language, "90 dakika", "90 minutes")
    120 -> tx(language, "120 dakika", "120 minutes")
    else -> "$minutes ${tx(language, "dakika", "minutes")}"
}


private fun vehicleVisualSummary(settings: LoganSettings, language: AppLanguage): String {
    val model = when (settings.vehicleVisualModel) {
        com.dcui.loganos.model.VehicleVisualModel.LoganI -> "Logan I"
        com.dcui.loganos.model.VehicleVisualModel.LoganIII -> "Logan III"
    }
    return "$model • ${vehicleColorLabel(settings.vehicleColor, language)}"
}

private fun vehicleColorLabel(color: VehicleColor, language: AppLanguage): String =
    if (language == AppLanguage.English) color.enLabel else color.trLabel

private fun cockpitTextSizeLabel(size: CockpitTextSize, language: AppLanguage): String =
    if (language == AppLanguage.English) size.enLabel else size.trLabel

private fun cockpitDensityLabel(density: CockpitDensity, language: AppLanguage): String =
    if (language == AppLanguage.English) density.enLabel else density.trLabel

private fun fuelPriceDisplay(raw: String, language: AppLanguage): String {
    val value = raw.replace(',', '.').toDoubleOrNull() ?: return tx(language, "Girilmedi", "Not set")
    return String.format(java.util.Locale("tr", "TR"), "%.2f TL/L", value)
}

private fun parseCalibrationNumber(raw: String): Double? {
    return raw.trim().replace(',', '.').toDoubleOrNull()
}

@Composable
private fun OptionDialog(palette: LoganPalette, dialog: SettingsDialog.Options, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                dialog.options.forEach { option ->
                    Text(
                        option,
                        color = palette.textPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onDismiss(); dialog.onSelect(option) }
                            .background(palette.surfaceVariant)
                            .padding(12.dp)
                    )
                }
            }
        }
    )
}

@Composable
private fun TextInputDialog(palette: LoganPalette, dialog: SettingsDialog.TextInput, language: AppLanguage, onDismiss: () -> Unit) {
    var value by remember(dialog.title) { mutableStateOf(dialog.initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(dialog.hint) }, singleLine = true)
                if (dialog.title == "Yakıt Fiyatı" || dialog.title == "Fuel Price") {
                    Text(
                        tx(language, "Daha doğru maliyet hesabı için, yakıt aldığınız zamanki litre fiyatını girin.", "For a more accurate cost calculation, enter the fuel price per liter at the time of refueling."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { dialog.onSave(value); onDismiss() }) { Text(tx(language, "Kaydet", "Save")) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}

@Composable
private fun FuelCalibrationDialog(
    palette: LoganPalette,
    dialog: SettingsDialog.Calibration,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    var distanceText by remember(dialog.startTimeMs, dialog.autoDistanceKm) {
        mutableStateOf(dialog.initialDistanceText)
    }
    var pumpLiters by remember(dialog.startTimeMs) { mutableStateOf("") }

    val distanceValue = parseCalibrationNumber(distanceText)
    val pumpValue = parseCalibrationNumber(pumpLiters)
    val appValue = dialog.autoAppLiters
    val proposedFactor = if (
        dialog.sessionActive &&
        appValue != null &&
        appValue > 0.0 &&
        pumpValue != null &&
        pumpValue > 0.0
    ) {
        dialog.measurementFactor * (pumpValue / appValue)
    } else {
        null
    }
    val factorValid = proposedFactor != null && proposedFactor in 0.50..1.50
    val distanceValid = distanceValue != null && distanceValue > 0.0
    val realAverage = if (distanceValid && pumpValue != null && pumpValue > 0.0) {
        pumpValue / distanceValue!! * 100.0
    } else null
    val appAverage = if (distanceValid && appValue != null && appValue > 0.0) {
        appValue / distanceValue!! * 100.0
    } else null
    val shortMeasurement = distanceValue != null && distanceValue in 0.01..99.99

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                tx(language, "Yakıt Kalibrasyonu", "Fuel Calibration"),
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
                if (!dialog.sessionActive) {
                    Text(
                        tx(language, "Full depo ölçümü", "Full-tank measurement"),
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        fuelCalibrationStartHelpText(language),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    Text(
                        tx(language, "Mevcut kalibrasyon", "Current calibration") +
                            ": " +
                            (if (dialog.enabled) tx(language, "Açık", "On") else tx(language, "Kapalı", "Off")) +
                            " • x${String.format(Locale.US, "%.3f", dialog.currentFactor)}",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                    dialog.unavailableReason?.let {
                        Text(
                            it,
                            color = if (dialog.canStart) palette.warning else palette.critical,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (dialog.enabled) {
                        TextButton(
                            onClick = {
                                dialog.onReset()
                                onDismiss()
                            }
                        ) {
                            Text(tx(language, "Fabrika hesabına dön", "Return to factory calculation"))
                        }
                    }
                } else {
                    Text(
                        tx(
                            language,
                            "Depoyu yeniden aynı seviyeye kadar doldurduktan sonra pompadan alınan litreyi girin. LoganOS kendi hesapladığı litreyi otomatik kullanır.",
                            "After refilling to the same level, enter the liters taken from the pump. LoganOS uses its own calculated liters automatically."
                        ),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    if (dialog.startTimeMs > 0L) {
                        Text(
                            tx(language, "Ölçüm başlangıcı", "Measurement started") +
                                ": ${formatCalibrationDate(dialog.startTimeMs)}",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    if (dialog.startOdometerKm > 0) {
                        Text(
                            tx(language, "Başlangıç kilometresi", "Starting odometer") +
                                ": ${dialog.startOdometerKm} km",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        tx(language, "LoganOS’un otomatik hesapladığı yakıt", "Fuel automatically calculated by LoganOS") +
                            ": " +
                            (appValue?.let { String.format(Locale.US, "%.2f L", it) } ?: "--"),
                        color = palette.textPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    OutlinedTextField(
                        value = distanceText,
                        onValueChange = { distanceText = it },
                        label = { Text(tx(language, "Gidilen mesafe (km)", "Distance driven (km)")) },
                        supportingText = {
                            Text(
                                tx(
                                    language,
                                    "LoganOS otomatik doldurur; gösterge kilometrenize göre düzeltebilirsiniz.",
                                    "LoganOS fills this automatically; you may correct it using the vehicle odometer."
                                )
                            )
                        },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = pumpLiters,
                        onValueChange = { pumpLiters = it },
                        label = { Text(tx(language, "Pompadan alınan litre", "Liters from the pump")) },
                        singleLine = true
                    )
                    dialog.unavailableReason?.let {
                        Text(
                            it,
                            color = palette.critical,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (shortMeasurement) {
                        Text(
                            tx(
                                language,
                                "100 km’den kısa ölçümlerde dolum farklarının etkisi daha büyüktür. 200–300 km ölçüm daha güvenilir sonuç verir.",
                                "Refill differences have a larger effect below 100 km. A 200–300 km measurement is more reliable."
                            ),
                            color = palette.warning,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                    if (realAverage != null && appAverage != null) {
                        Text(
                            tx(language, "Pompa ortalaması", "Pump average") +
                                ": ${String.format(Locale.US, "%.2f L/100 km", realAverage)}",
                            color = palette.textPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            tx(language, "LoganOS ortalaması", "LoganOS average") +
                                ": ${String.format(Locale.US, "%.2f L/100 km", appAverage)}",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = when {
                            factorValid -> tx(language, "Önerilen yeni katsayı", "Suggested new coefficient") +
                                ": x${String.format(Locale.US, "%.3f", proposedFactor)}"
                            proposedFactor != null -> tx(
                                language,
                                "Sonuç güvenli katsayı aralığının dışında (0,50–1,50). Litre ve mesafe değerlerini kontrol edin.",
                                "The result is outside the safe coefficient range (0.50–1.50). Check the liter and distance values."
                            )
                            else -> tx(
                                language,
                                "Pompa litresini girin; mesafeyi gerekirse gösterge kilometrenize göre düzeltin.",
                                "Enter the pump liters; correct the distance from the vehicle odometer if needed."
                            )
                        },
                        color = when {
                            factorValid -> palette.accent
                            proposedFactor != null -> palette.critical
                            else -> palette.textSecondary
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    TextButton(
                        onClick = {
                            dialog.onCancelSession()
                            onDismiss()
                        }
                    ) {
                        Text(tx(language, "Ölçümü iptal et", "Cancel measurement"))
                    }
                }
            }
        },
        confirmButton = {
            if (dialog.sessionActive) {
                TextButton(
                    enabled = factorValid && distanceValid && dialog.unavailableReason == null,
                    onClick = {
                        dialog.onSave(
                            pumpLiters,
                            appValue?.let { String.format(Locale.US, "%.3f", it) } ?: "",
                            proposedFactor ?: 1.0
                        )
                        onDismiss()
                    }
                ) {
                    Text(tx(language, "Kalibrasyonu uygula", "Apply calibration"))
                }
            } else {
                TextButton(
                    enabled = dialog.canStart,
                    onClick = {
                        dialog.onStart()
                        onDismiss()
                    }
                ) {
                    Text(tx(language, "Ölçümü başlat", "Start measurement"))
                }
            }
        },
        dismissButton = {
            Row {
                if (!dialog.sessionActive && dialog.enabled) {
                    TextButton(
                        onClick = {
                            dialog.onDisable()
                            onDismiss()
                        }
                    ) {
                        Text(tx(language, "Kalibrasyonu kapat", "Disable calibration"))
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text(tx(language, "Kapat", "Close"))
                }
            }
        }
    )
}

private fun fuelCalibrationStartHelpText(language: AppLanguage): String =
    if (language == AppLanguage.English) {
        """
        1. Fill the tank completely.
        2. Open OBD and start the measurement.
        3. Keep LoganOS/OBD active and drive at least 100 km; 200–300 km is recommended.
        4. Refill to the same level.
        5. Enter only the pump liters. LoganOS calculates its own fuel automatically.
        """.trimIndent()
    } else {
        """
        1. Depoyu tamamen doldurun.
        2. OBD bağlantısını açıp ölçümü başlatın.
        3. LoganOS/OBD açıkken en az 100 km kullanın; 200–300 km önerilir.
        4. Depoyu yeniden aynı seviyeye kadar doldurun.
        5. Yalnızca pompadan alınan litreyi girin. LoganOS kendi yakıt hesabını otomatik kullanır.
        """.trimIndent()
    }

private fun formatCalibrationDate(timestampMs: Long): String =
    SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(timestampMs))

@Composable
private fun InfoDialog(palette: LoganPalette, dialog: SettingsDialog.Info, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = onDismiss) { Text(tx(language, "Tamam", "OK")) } }
    )
}

@Composable
private fun ConfirmDialog(palette: LoganPalette, dialog: SettingsDialog.Confirm, language: AppLanguage, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = { onDismiss(); dialog.onConfirm() }) { Text(dialog.confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text(tx(language, "İptal", "Cancel")) } }
    )
}
