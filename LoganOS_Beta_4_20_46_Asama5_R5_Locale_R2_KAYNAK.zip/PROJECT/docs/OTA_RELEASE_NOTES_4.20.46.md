# LoganOS 1.0.0-beta.4.20.46 — GitHub Release body

The app selects only the section matching the language selected in LoganOS Settings. Keep the markers exactly as written; do not add a combined-language heading outside the sections.

<!-- LOGANOS_NOTES_TR_START -->
LoganOS 1.0.0-beta.4.20.46

• Teknik oturum dışa aktarımında (.txt), dosya başarıyla kaydedildikten sonra geçmiş listesinin yenilenmesi hata verirse dışa aktarma artık yanlışlıkla başarısız gösterilmez; hata ayrı tanılama kaydına yazılır.
• Güncelleme notları artık uygulama ayarlarında seçili dilde gösterilir.
• OBD/KWP protokolü, Renault/Dacia PID'leri, yakıt ve TripComputer davranışı değiştirilmedi. Veritabanı sürümü v7 olarak korunmuştur.
<!-- LOGANOS_NOTES_TR_END -->

<!-- LOGANOS_NOTES_EN_START -->
LoganOS 1.0.0-beta.4.20.46

• Technical session export (.txt) is no longer incorrectly reported as failed when the file was saved successfully but refreshing the history list fails; the refresh issue is written to a separate diagnostic entry.
• Update notes are now displayed in the language selected in app settings.
• OBD/KWP protocol, Renault/Dacia PIDs, fuel calculations and TripComputer behavior are unchanged. Database version remains v7.
<!-- LOGANOS_NOTES_EN_END -->
