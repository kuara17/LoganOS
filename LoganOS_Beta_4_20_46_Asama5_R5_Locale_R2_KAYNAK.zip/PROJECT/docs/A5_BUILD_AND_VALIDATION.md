# LoganOS 1.0.0-beta.4.20.46 — A5 Build & Validation

## Release identity

- Application ID: `com.dcui.loganos`
- Version name: `1.0.0-beta.4.20.46`
- Version code: `100000845`
- Previous published version: `1.0.0-beta.4.20.45` (`100000844`); do not overwrite its release/tag.
- Database version: `7` (unchanged)
- JDK: `17`
- Android Gradle Plugin: `8.7.3`
- Gradle: `8.9`
- Kotlin / Compose compiler plugin: `2.0.21`
- compileSdk / targetSdk: `35`
- minSdk: `26`
- Current source candidate: `LoganOS_Beta_4_20_46_Asama5_R5_Locale_R2_KAYNAK.zip` (280 files; verify SHA-256 against the delivered value before upload).

## Source lineage

- R5 is based on the user-provided R4 source package.
- R4 source ZIP SHA-256: `2b9fd8fbb5a42f07ca6be3096281b08d455751224dd248fe5ab08fe557471e9a`.
- The first R5 archive changed the app version identity, its matching archive-summary test fixture, and delivery documentation/OTA notes. The R4 production fix in `ObdController.kt` is retained.
- The R5 Locale R1 revision added `ReleaseNotesLocalizer.kt`, integrated it into `SettingsScreen.UpdateReleaseCard`, and added focused unit tests. Locale R2 hardens the parser: all recognized markers are processed as one non-nested stream, and mismatched, nested, duplicated, or unclosed markers reject the entire localized body. The raw GitHub Release body remains cached unchanged; presentation selects only the TR or EN block matching `AppLanguage`.
- Legacy unmarked release bodies remain visible as before. When a localized block is missing or malformed, the UI shows a localized “notes unavailable” message rather than leaking the other language.
- No DB migration, OBD/KWP protocol, PID, polling timing, FuelAlgorithmV3, or TripComputer behavior change is intended.
- This Locale R2 archive is a post-R5-Run-#109 source revision. Run #109 (222 tests + debug APK) validates the immediately previous non-localized R5 ZIP only; neither Locale R1 nor Locale R2 is covered by that run. Locale R2 must be uploaded and CI rerun before release. Expected source count: 229 JUnit tests (222 original + 6 Locale R1 tests + 1 Locale R2 regression test).

## CI evidence already obtained for R4

GitHub Actions run #107: https://github.com/kuara17/LoganOS/actions/runs/44930712435

- Selected source: `LoganOS_Beta_4_20_45_Asama5_R4_KAYNAK.zip`
- Gradle: `8.9`; JDK: `17`
- `:app:testDebugUnitTest`: PASS — 222 tests across 34 suites; 0 failures, 0 errors, 0 skipped.
- `:app:assembleDebug`: PASS.
- Gradle result: `BUILD SUCCESSFUL in 2m 2s`.
- Debug APK artifact ID: `14718105341` (not a production-signed OTA APK).
- Test report artifact ID: `14716989748`.
- This is evidence for R4 at `1.0.0-beta.4.20.45` only. The first R5 ZIP was separately tested in Run #109 below.

## Prior R5 CI evidence — Run #109 (previous R5 archive only)

GitHub Actions run #109: https://github.com/kuara17/LoganOS/actions/runs/44933425515

- Selected source was the first R5 archive (`LoganOS_Beta_4_20_46_Asama5_R5_OTA_KAYNAK.zip`, SHA-256 `1cd0bf04e71f5fc6515e5ba4a395f8e191f7fabf09a1fcee620dd8218dbf382e`).
- Result: SUCCESS; `:app:testDebugUnitTest` and `:app:assembleDebug` both completed successfully.
- JUnit XML artifact: 34 suites, 222 tests, 0 failures, 0 errors, 0 skipped.
- Debug APK artifact ID: `14718028828`; validation report artifact ID: `14718930639`.
- This run does **not** validate this localized-release-notes source revision because it was created after Run #109. The updated ZIP must be re-uploaded and CI rerun.

## Workflow ownership and source-package boundaries

This source package intentionally contains `.github/workflows/android-ci.yml` only.

- Repository-level `.github/workflows/build-from-zip.yml` is the live ZIP-based CI workflow. It selects the sole root ZIP, creates a Gradle 8.9 Wrapper with the pinned distribution checksum, runs `:app:testDebugUnitTest` and `:app:assembleDebug`, and uploads test reports/debug APK.
- `.github/workflows/android-release.yml` is intentionally absent. Do not recreate it.
- Production signing and OTA publication use the existing repository workflow `.github/workflows/publish-secure-release.yml`; it is not copied into the source ZIP.

## Release signing and OTA validation

The production release workflow requires the existing signing environment and creates a release tag from `versionName`. The intended new tag is `v1.0.0-beta.4.20.46`; `v1.0.0-beta.4.20.45` must remain unchanged.

Required release-build values include:

- `LOGANOS_KEYSTORE_PATH`
- `LOGANOS_STORE_PASSWORD`
- `LOGANOS_KEY_ALIAS`
- `LOGANOS_KEY_PASSWORD`
- `LOGANOS_UPDATE_REPOSITORY`

Repository Actions variable:

- Name: `LOGANOS_EXPECTED_SIGNER_SHA256`
- Expected value: `c70451189fbc2d9ca25e8663d1cefc5c876367593d3acac8593cede55ea62290`
- The user reports that this variable has been created. The connector cannot read repository variable values. Confirm the next production release log prints `Production signer SHA-256 fingerprint matches the configured pin.`
- PR #1 fixed parsing for both `V3.0 Signer: certificate SHA-256 digest:` and legacy `Signer #1 certificate SHA-256 digest:` output formats.

Do not run the production release with `override_existing=true` for this new version. The new tag `v1.0.0-beta.4.20.46` should not exist yet. Leave the prior `v1.0.0-beta.4.20.45` release untouched.

The publish workflow produces the signed APK, `.sha256`, `.certificate.txt`, and `.badging.txt`, verifies package/version/signing fingerprint, generates build attestation, then publishes the release. Verify the real workflow run and all output assets. A debug APK is not suitable for OTA.

## Proposed OTA release notes

See `docs/OTA_RELEASE_NOTES_4.20.46.md`. The live publish workflow PR #4 was merged as `3bbca0f50a1f043d9adc5c9c994ddf3422662295`: it now matches `aapt` output (`sdkVersion:'26'`, `targetSdkVersion:'35'`) and makes the `release_notes` input optional. Leave that input blank to have the workflow read the single `docs/OTA_RELEASE_NOTES*.md` file from the selected source ZIP and extract only the marked TR/EN body (without the introductory preamble). The app displays only the section matching the user's selected language. The tag and APK name are generated automatically from `app/build.gradle.kts`.

## Prior A4 review notes carried into R5

- The narrow export-contract mutation coverage still needs independent review; do not treat the existing contract test as exhaustive without mutation evidence.
- The post-save `exportTechnicalSession()` history-refresh false-negative is handled in R4 and retained in R5. This is a source-level correction; real Android runtime behavior remains a device acceptance item.
- Some developer-test completion paths may wait for the shared history-retention gate. Treat this as a responsiveness note unless a reproducible user-visible stall or correctness issue is demonstrated.

## Device acceptance gates still required

- API 26 and API 28: SAF folder selection, cancel, persisted permission, permission loss, and partial-file cleanup.
- API 29+: MediaStore export/delete regression.
- Real Android SQLite: only records actually included in a successful export are marked with `exported_at_ms`; write, ZIP, close, and destination failures must not mark records.
- Concurrent export, delete, retention, and clear-all behavior.
- OBD connected: perform a large bulk ZIP while pressing “Sürüşü şimdi bitir”; polling and gauges must remain responsive.
- Inject file-write and ZIP failures and verify database state after each failure.
- 2 GB head unit: test 500 trip + 500 test records; record peak heap, elapsed time, and OOM behavior.

## Verification ledger

| Gate | Evidence | Status for R5 candidate |
|---|---|---|
| R5 ZIP integrity/source SHA | `sha256sum`, `unzip -t` | Must be checked after package creation |
| R5 version identity | `app/build.gradle.kts`, archive test fixture | Source inspection |
| R4 real JUnit + debug build | Actions #107; 222/222 tests; debug APK | PASS for R4 only |
| Original R5 CI | Actions #109; 222 tests + debug APK | PASS for original R5 archive only |
| Locale R1/R2 localized-notes CI | Re-upload Locale R2 ZIP and rerun Actions; expected 229 tests | NOT RUN |
| R5 production release signature pin | Publish workflow log | NOT RUN yet |
| R5 signed APK / OTA metadata | APK, signer, hash, release assets, attestation | NOT RUN yet |
| API 26/28 SAF and API 29+ MediaStore | Device/API test evidence | NOT RUN |
| Android SQLite export failure/concurrency tests | Device/instrumentation evidence | NOT RUN |
| 2 GB head-unit bulk ZIP | Peak heap, elapsed time, OOM and UI responsiveness | NOT RUN |

A5 is complete only when the current R5 CI/release evidence and required device gates have been reviewed. Do not convert an R4 result into an R5 PASS, and do not treat a debug APK as a production release.


## Locale R1 independent audit follow-up (Locale R2)

- Audit report: `LOGANOS-A5-R5-LOCALE-R1-AUDIT-20261121`; source decision `ACCEPTABLE WITH NOTES`, release workflow `NEEDS CHANGES` at the time of audit.
- R-L4 (cross-nested localized markers could expose raw marker/other-language text) is addressed in `ReleaseNotesLocalizer.kt`; parser now rejects malformed global marker streams and a dedicated JUnit regression test was added.
- R-L1/R-L3 (live release workflow SDK syntax and multi-line notes input) were addressed outside this source ZIP in GitHub PR #4, merged as `3bbca0f50a1f043d9adc5c9c994ddf3422662295`. The SDK checks now match actual `aapt` colon syntax. When `release_notes` is blank, the workflow reads the sole source docs notes file, extracts from `LOGANOS_NOTES_TR_START` through `LOGANOS_NOTES_EN_END`, and passes the marked bilingual body to `gh release create/edit`.
- The current repository root must contain this Locale R2 ZIP as its only source ZIP before CI/release. At package preparation time, GitHub main still held the earlier non-localized R5 ZIP. Do not run production release until current ZIP identity, CI, signer pin, APK, and attestation are verified.
- Real Kotlin/Gradle JUnit, APK signing, OTA, and device tests remain NOT RUN for Locale R2.
