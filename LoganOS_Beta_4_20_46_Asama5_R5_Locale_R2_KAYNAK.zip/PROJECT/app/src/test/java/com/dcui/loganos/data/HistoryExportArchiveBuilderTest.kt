package com.dcui.loganos.data

import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryExportArchiveBuilderTest {
    @Test
    fun zipContainsOnlyProvidedRecordsAndSummaryMatchesItsEntries() {
        val archive = HistoryExportArchiveBuilder.build(
            versionName = "1.0.0-beta.4.20.46",
            drives = sequenceOf(
                DriveHistoryExportEntry(11L, 100L, "drive-11"),
                DriveHistoryExportEntry(12L, 200L, "drive-12")
            ),
            tests = sequenceOf(TestHistoryExportEntry(3, 21L, "test-21"))
        )

        val entries = linkedMapOf<String, String>()
        ZipInputStream(ByteArrayInputStream(archive.bytes)).use { zip ->
            while (true) {
                val entry = zip.nextEntry ?: break
                entries[entry.name] = zip.readBytes().toString(Charsets.UTF_8)
                zip.closeEntry()
            }
        }

        assertEquals(
            setOf(
                "drives/drive_id11_100.txt",
                "drives/drive_id12_200.txt",
                "tests/test_3_id21.txt",
                "summary.txt"
            ),
            entries.keys
        )
        assertTrue(entries.getValue("summary.txt").contains("version=1.0.0-beta.4.20.46"))
        assertTrue(entries.getValue("summary.txt").contains("drive_records=2"))
        assertTrue(entries.getValue("summary.txt").contains("test_records=1"))
        assertEquals(listOf(11L, 12L), archive.recordIds.driveRecordIds)
        assertEquals(listOf(21L), archive.recordIds.testRecordIds)
    }

    @Test
    fun emptyArchiveReportsZeroAndSelectsNoRecords() {
        val archive = HistoryExportArchiveBuilder.build("test-version", emptySequence(), emptySequence())
        val summary = ZipInputStream(ByteArrayInputStream(archive.bytes)).use { zip ->
            assertEquals("summary.txt", zip.nextEntry?.name)
            zip.readBytes().toString(Charsets.UTF_8)
        }

        assertTrue(summary.contains("drive_records=0"))
        assertTrue(summary.contains("test_records=0"))
        assertEquals(emptyList<Long>(), archive.recordIds.driveRecordIds)
        assertEquals(emptyList<Long>(), archive.recordIds.testRecordIds)
    }
}
