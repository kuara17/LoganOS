package com.dcui.loganos.update

import com.dcui.loganos.model.AppLanguage
import org.junit.Assert.assertEquals
import org.junit.Test

class ReleaseNotesLocalizerTest {
    private val notes = """
        <!-- LOGANOS_NOTES_TR_START -->
        Türkçe sürüm notu.
        İkinci satır.
        <!-- LOGANOS_NOTES_TR_END -->

        <!-- LOGANOS_NOTES_EN_START -->
        English release notes.
        Second line.
        <!-- LOGANOS_NOTES_EN_END -->
    """.trimIndent()

    @Test
    fun selectsOnlyTurkishSection() {
        assertEquals(
            "Türkçe sürüm notu.\nİkinci satır.",
            ReleaseNotesLocalizer.select(notes, AppLanguage.Turkish)
        )
    }

    @Test
    fun selectsOnlyEnglishSection() {
        assertEquals(
            "English release notes.\nSecond line.",
            ReleaseNotesLocalizer.select(notes, AppLanguage.English)
        )
    }

    @Test
    fun legacyUnmarkedReleaseNotesRemainVisible() {
        assertEquals(
            "Legacy single-language notes",
            ReleaseNotesLocalizer.select("  Legacy single-language notes  ", AppLanguage.Turkish)
        )
        assertEquals(
            "Legacy single-language notes",
            ReleaseNotesLocalizer.select("  Legacy single-language notes  ", AppLanguage.English)
        )
    }

    @Test
    fun missingSelectedLanguageDoesNotExposeOtherLanguage() {
        val turkishOnly = """
            <!-- LOGANOS_NOTES_TR_START -->
            Yalnızca Türkçe.
            <!-- LOGANOS_NOTES_TR_END -->
        """.trimIndent()

        assertEquals("", ReleaseNotesLocalizer.select(turkishOnly, AppLanguage.English))
    }

    @Test
    fun malformedLocalizedBodyDoesNotLeakRawBilingualContent() {
        val malformed = """
            <!-- LOGANOS_NOTES_TR_START -->
            Türkçe not.
            <!-- LOGANOS_NOTES_EN_START -->
            English notes.
            <!-- LOGANOS_NOTES_EN_END -->
        """.trimIndent()

        assertEquals("", ReleaseNotesLocalizer.select(malformed, AppLanguage.Turkish))
    }


    @Test
    fun crossNestedMarkersNeverLeakOtherLanguageOrRawMarkers() {
        val crossNested = """
            <!-- LOGANOS_NOTES_TR_START -->
            Türkçe not.
            <!-- LOGANOS_NOTES_EN_START -->
            English notes.
            <!-- LOGANOS_NOTES_TR_END -->
            More text.
            <!-- LOGANOS_NOTES_EN_END -->
        """.trimIndent()

        assertEquals("", ReleaseNotesLocalizer.select(crossNested, AppLanguage.Turkish))
        assertEquals("", ReleaseNotesLocalizer.select(crossNested, AppLanguage.English))
    }

    @Test
    fun duplicateRequestedSectionsAreRejected() {
        val duplicate = notes + "\n" + notes
        assertEquals("", ReleaseNotesLocalizer.select(duplicate, AppLanguage.English))
    }
}
