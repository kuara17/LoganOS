package com.dcui.loganos.update

import com.dcui.loganos.model.AppLanguage

/**
 * Selects the release-note section matching the language currently selected in LoganOS.
 *
 * GitHub Release bodies may contain both supported languages, wrapped in these markers:
 * <!-- LOGANOS_NOTES_TR_START --> ... <!-- LOGANOS_NOTES_TR_END -->
 * <!-- LOGANOS_NOTES_EN_START --> ... <!-- LOGANOS_NOTES_EN_END -->
 *
 * Legacy release bodies without localization markers are returned unchanged.
 * If a body opts into localization but the requested section is missing or malformed,
 * no other language is exposed as a fallback.
 */
object ReleaseNotesLocalizer {
    private val markerRegex = Regex(
        "<!--\\s*LOGANOS_NOTES_(TR|EN)_(START|END)\\s*-->",
        RegexOption.IGNORE_CASE
    )

    fun select(releaseNotes: String, language: AppLanguage): String {
        val source = releaseNotes.trim()
        if (source.isEmpty()) return ""

        val markers = markerRegex.findAll(source).toList()
        if (markers.isEmpty()) return source

        // Parse every marker as a single, non-nested stream. Reject the whole body on
        // mismatched, nested, repeated, or unclosed markers so one language can never
        // accidentally expose the other language or raw marker comments.
        val sections = mutableMapOf<String, String>()
        var openCode: String? = null
        var sectionStart = -1

        for (marker in markers) {
            val code = marker.groupValues[1].uppercase()
            val kind = marker.groupValues[2].uppercase()

            when (kind) {
                "START" -> {
                    if (openCode != null || sections.containsKey(code)) return ""
                    openCode = code
                    sectionStart = marker.range.last + 1
                }
                "END" -> {
                    if (openCode != code || sectionStart < 0) return ""
                    sections[code] = source.substring(sectionStart, marker.range.first).trim()
                    openCode = null
                    sectionStart = -1
                }
                else -> return ""
            }
        }

        if (openCode != null) return ""

        val selectedCode = when (language) {
            AppLanguage.Turkish -> "TR"
            AppLanguage.English -> "EN"
        }
        return sections[selectedCode].orEmpty()
    }
}
