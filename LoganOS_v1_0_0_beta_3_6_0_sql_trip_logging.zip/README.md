# LoganOS

**OEM Digital Cockpit • Powered by DC UI**

Version: **1.0.0-beta.3.6.0**

## Beta 3.5.3 Focus

This patch restricts setup to the currently supported Dacia Logan I 1.5 dCi 48 kW profile and marks other model/engine profiles as unavailable.

### Highlights

- Selected icon concepts are drawn directly in Compose Canvas: Anlık 1A, Klima 2A, Hararet 3A, Fan 4C.
- Ortalama fuel icon uses pump + bar chart; Anlık fuel icon uses pump + pulse line and red accent.
- Hararet uses dynamic color: cold blue, warming amber, normal green, critical red.
- Cards use smaller radius and subtle elevation for a less toy-like feel.
- The red car in the gauge is now drawn as a sedan silhouette.
- Faster 21CC quick-status polling for A/C and radiator fan state.
- A/C and fan state can update before the slower technical packets complete.
- Log creation now asks for confirmation from the OBD panel.
- Last log / all log deletion actions require confirmation.
- OEM-style drawn metric icons added to cockpit and technical cards.
- Motor temperature + radiator fan card alignment improved.
- Climate card remains separate and clearer.
- Fuel Truth stays in Technical as a test/debug panel.
- Gauge style labels removed from the main cockpit gauge center.
- Setup gauge previews improved; preview speed value reduced.
- Dacia/Renault brand selection card indicator made more consistent.

## Status

Bluetooth, ELM init, KWP Fast Init and raw ECU response are working in Beta testing.
Trip Computer / Smart Trip persistence is planned for a later beta after live-data validation.


### fix5
- AC fast loop and 21CC priority.
- 21A2/21CD slower technical cycle.
- Portrait settings polish.
