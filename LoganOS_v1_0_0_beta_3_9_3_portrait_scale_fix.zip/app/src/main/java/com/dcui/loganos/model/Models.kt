package com.dcui.loganos.model

import androidx.compose.ui.graphics.Color
import kotlin.math.PI
import kotlin.math.sin

enum class AppLanguage(val label: String, val englishLabel: String) {
    Turkish("Türkçe", "Turkish"),
    English("English", "English")
}

enum class DeviceMode(val label: String) {
    Phone("Telefon"),
    HeadUnit("Android Multimedya / Double")
}

enum class Brand(val label: String) {
    Dacia("Dacia"),
    Renault("Renault")
}

enum class GaugeStyle(val label: String) {
    Digital("Digital"),
    Sport("Sport"),
    ClassicOem("Classic OEM"),
    Minimal("Minimal"),
    RsPerformance("RS Performance")
}

enum class CockpitTextSize(val trLabel: String, val enLabel: String) {
    Small("Küçük", "Small"),
    Normal("Normal", "Normal"),
    Large("Büyük", "Large")
}

enum class TripMetricReset {
    Average,
    Cost,
    AverageAndCost
}

enum class CockpitDensity(val trLabel: String, val enLabel: String) {
    Compact("Kompakt", "Compact"),
    Balanced("Dengeli", "Balanced"),
    Wide("Geniş", "Wide")
}

enum class AccentColor(val label: String, val color: Color) {
    OemGreen("OEM Green", Color(0xFF1FAD55)),
    TechBlue("Tech Blue", Color(0xFF207DFF)),
    SportOrange("Sport Orange", Color(0xFFFF8A00)),
    RsRed("RS Red", Color(0xFFFF3B30)),
    NeoPurple("Neo Purple", Color(0xFF9B5CFF)),
    GoldEdition("Gold Edition", Color(0xFFFFC107))
}

data class LoganSettings(
    val setupCompleted: Boolean = false,
    val language: AppLanguage = AppLanguage.Turkish,
    val brand: Brand = Brand.Dacia,
    val vehicleModel: String = "Dacia Logan",
    val engine: String = "1.5 dCi 68 bg",
    val deviceMode: DeviceMode = DeviceMode.Phone,
    val gaugeStyle: GaugeStyle = GaugeStyle.Digital,
    val cockpitTextSize: CockpitTextSize = CockpitTextSize.Normal,
    val cockpitDensity: CockpitDensity = CockpitDensity.Balanced,
    val accentColor: AccentColor = AccentColor.OemGreen,
    val darkMode: Boolean = false,
    val keepScreenOn: Boolean = true,
    val backgroundTripEnabled: Boolean = true,
    val smartTripMinutes: Int = 60,
    val demoMode: Boolean = false,
    val disclaimerAccepted: Boolean = false,
    val fuelPriceText: String = "",
    val odometerText: String = "335420",
    val oilServiceKm: String = "10000",
    val fuelFilterKm: String = "20000",
    val airFilterKm: String = "10000",
    val timingBeltKm: String = "60000",
    val developerModeEnabled: Boolean = false,
    val rawEcuLogEnabled: Boolean = false,
    val longTripLogEnabled: Boolean = false,
    val fuelCalibrationEnabled: Boolean = false,
    val fuelCalibrationFactor: Double = 1.0,
    val fuelCalibrationAppLitersText: String = "",
    val fuelCalibrationPumpLitersText: String = "",
    val fuelCalibrationWarningAccepted: Boolean = false,
    val avgResetDistanceKm: Double = 0.0,
    val avgResetFuelLiters: Double = 0.0,
    val costResetFuelLiters: Double = 0.0,
    val avgResetTripToken: Long = 0L,
    val costResetTripToken: Long = 0L
)

data class DashboardSnapshot(
    val speedKmh: Int? = null,
    val averageConsumption: Double? = null,
    val instantConsumption: Double? = null,
    val instantUnit: String = "L/h",
    val tripDistanceKm: Double? = null,
    val odometerKm: Int? = null,
    val engineTempC: Int? = null,
    val radiatorFanOn: Boolean? = null,
    val rpm: Int? = null,
    val acOn: Boolean? = null,
    val fuelUsedL: Double? = null,
    val tripCostText: String? = null,
    val batteryV: Double? = null,
    val adapterVoltageV: Double? = null,
    val pedalPercent: Double? = null,
    val mapMbar: Int? = null,
    val requestedMapMbar: Int? = null,
    val airCharge: Double? = null,
    val intakeTempC: Double? = null,
    val fuelTempC: Double? = null,
    val railBar: Double? = null,
    val railTargetBar: Double? = null,
    val sensorSupplyV: Double? = null,
    val connected: Boolean = false,
    val demo: Boolean = false,
    val fuelSource: String = "Bekleniyor",
    val injectionMg: Double? = null,
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val tripDurationText: String? = null,
    val tripStateText: String? = null,
    val tripToken: Long = 0L
) {
    companion object {
        fun empty() = DashboardSnapshot()

        fun demoLive(tick: Int): DashboardSnapshot {
            val phase = (tick % 120) / 120.0
            val wave = (sin(phase * 2.0 * PI) + 1.0) / 2.0
            val cityPulse = (sin(phase * 10.0 * PI) + 1.0) / 2.0
            val speed = (18 + wave * 82 + cityPulse * 12).toInt().coerceIn(0, 110)
            val rpm = (850 + speed * 18 + cityPulse * 380).toInt().coerceIn(820, 3100)
            val temp = (58 + (tick.coerceAtMost(90) * 0.46)).toInt().coerceIn(58, 98)
            val fan: Boolean? = null // Gerçek fan biti doğrulanmadı; demo dahil bilinmiyor gösterilir.
            val ac = (tick / 18) % 2 == 0
            val lh = if (speed < 5) 0.7 + if (ac) 0.15 else 0.0 else 1.1 + wave * 2.2 + if (ac) 0.25 else 0.0
            val l100 = if (speed < 5) 0.0 else (lh / speed) * 100.0
            val distance = (tick * speed / 3600.0 * 0.8).coerceAtLeast(0.0)
            val fuelUsed = distance * 4.9 / 100.0
            return DashboardSnapshot(
                speedKmh = speed,
                averageConsumption = 4.7 + wave * 0.5,
                instantConsumption = if (speed < 5) lh else l100,
                instantUnit = if (speed < 5) "L/h" else "L/100 km",
                tripDistanceKm = distance,
                odometerKm = 335420 + distance.toInt(),
                engineTempC = temp,
                radiatorFanOn = fan,
                rpm = rpm,
                acOn = ac,
                fuelUsedL = fuelUsed,
                tripCostText = "12.80 ₺",
                batteryV = 13.7 + (wave * 0.2),
                adapterVoltageV = 13.8 + (wave * 0.2),
                pedalPercent = (cityPulse * 38.0),
                mapMbar = (980 + wave * 420).toInt(),
                requestedMapMbar = (1000 + wave * 390).toInt(),
                airCharge = 320.0 + wave * 120.0,
                intakeTempC = 28.0 + wave * 8.0,
                fuelTempC = 32.0 + wave * 10.0,
                railBar = 260.0 + wave * 280.0,
                railTargetBar = 270.0 + wave * 260.0,
                sensorSupplyV = 5.0,
                connected = false,
                demo = true,
                fuelSource = "DEMO",
                injectionMg = 3.2 + wave * 8.0,
                raw21A0 = "DEMO 61 A0 ...",
                raw21A2 = "DEMO 61 A2 ...",
                raw21CC = "DEMO 61 CC ...",
                raw21CD = "DEMO 61 CD ...",
                tripDurationText = "%02d:%02d".format((tick / 75), ((tick * 8) % 60)),
                tripStateText = "Demo",
                tripToken = 1L
            )
        }

        fun demo() = demoLive(42)
    }
}
