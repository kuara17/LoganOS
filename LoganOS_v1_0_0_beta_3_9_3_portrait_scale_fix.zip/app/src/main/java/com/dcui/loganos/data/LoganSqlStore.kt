package com.dcui.loganos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.dcui.loganos.model.DashboardSnapshot
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class LoganSqlStore(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val appContext = context.applicationContext

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE drive_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                version_name TEXT NOT NULL,
                adapter_name TEXT,
                adapter_address TEXT,
                note TEXT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE obd_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                loop_index INTEGER,
                loop_ms INTEGER,
                rpm INTEGER,
                speed_kmh INTEGER,
                coolant_c INTEGER,
                fuel_mg REAL,
                fuel_lh REAL,
                instant_value REAL,
                instant_unit TEXT,
                pedal_percent REAL,
                map_mbar INTEGER,
                air_charge REAL,
                ac_on INTEGER,
                fan_state TEXT,
                fuel_source TEXT,
                trip_state TEXT,
                trip_distance_km REAL,
                fuel_used_l REAL,
                avg_l100 REAL,
                raw21cc TEXT,
                raw21a0 TEXT,
                raw21a2 TEXT,
                raw21cd TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id)
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE test_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER,
                time_ms INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                name TEXT NOT NULL,
                note TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id)
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX idx_samples_session_time ON obd_samples(session_id, time_ms)")
        db.execSQL("CREATE INDEX idx_events_session_time ON test_events(session_id, time_ms)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Beta dönemi için güvenli/destructive migration.
        // Şema değişirse eski kurulumlarda "no such column" hatası yerine
        // tablolar temizlenip güncel şema yeniden oluşturulur.
        db.execSQL("DROP TABLE IF EXISTS obd_samples")
        db.execSQL("DROP TABLE IF EXISTS test_events")
        db.execSQL("DROP TABLE IF EXISTS drive_sessions")
        onCreate(db)
    }

    fun databaseFile(): File = appContext.getDatabasePath(DB_NAME)

    fun startSession(versionName: String, adapterName: String?, adapterAddress: String?): Long {
        val values = ContentValues().apply {
            put("started_at_ms", System.currentTimeMillis())
            put("version_name", versionName)
            put("adapter_name", adapterName)
            put("adapter_address", adapterAddress)
            put("note", "LoganOS SQL session")
        }
        return writableDatabase.insert("drive_sessions", null, values)
    }

    fun endSession(sessionId: Long?) {
        if (sessionId == null) return
        val values = ContentValues().apply { put("ended_at_ms", System.currentTimeMillis()) }
        writableDatabase.update("drive_sessions", values, "id=?", arrayOf(sessionId.toString()))
    }

    fun insertEvent(sessionId: Long?, eventType: String, name: String, note: String? = null) {
        val values = ContentValues().apply {
            if (sessionId != null) put("session_id", sessionId)
            put("time_ms", System.currentTimeMillis())
            put("event_type", eventType)
            put("name", name)
            put("note", note)
        }
        writableDatabase.insert("test_events", null, values)
    }

    fun insertSample(
        sessionId: Long?,
        loopIndex: Int,
        loopMs: Long,
        snapshot: DashboardSnapshot,
        raw21cc: String,
        raw21a0: String,
        raw21a2: String,
        raw21cd: String
    ) {
        if (sessionId == null) return
        val values = ContentValues().apply {
            put("session_id", sessionId)
            put("time_ms", System.currentTimeMillis())
            put("loop_index", loopIndex)
            put("loop_ms", loopMs)
            putNullable("rpm", snapshot.rpm)
            putNullable("speed_kmh", snapshot.speedKmh)
            putNullable("coolant_c", snapshot.engineTempC)
            putNullable("fuel_mg", snapshot.injectionMg)
            putNullable("fuel_lh", if (snapshot.instantUnit == "L/h") snapshot.instantConsumption else null)
            putNullable("instant_value", snapshot.instantConsumption)
            put("instant_unit", snapshot.instantUnit)
            putNullable("pedal_percent", snapshot.pedalPercent)
            putNullable("map_mbar", snapshot.mapMbar)
            putNullable("air_charge", snapshot.airCharge)
            putNullable("ac_on", snapshot.acOn?.let { if (it) 1 else 0 })
            put("fan_state", snapshot.radiatorFanOn?.toString() ?: "UNKNOWN")
            put("fuel_source", snapshot.fuelSource)
            put("trip_state", snapshot.tripStateText)
            putNullable("trip_distance_km", snapshot.tripDistanceKm)
            putNullable("fuel_used_l", snapshot.fuelUsedL)
            putNullable("avg_l100", snapshot.averageConsumption)
            put("raw21cc", raw21cc)
            put("raw21a0", raw21a0)
            put("raw21a2", raw21a2)
            put("raw21cd", raw21cd)
        }
        writableDatabase.insert("obd_samples", null, values)
    }

    fun clearAll(): Int {
        val db = writableDatabase
        val samples = db.delete("obd_samples", null, null)
        val events = db.delete("test_events", null, null)
        val sessions = db.delete("drive_sessions", null, null)
        return samples + events + sessions
    }

    fun exportSessionText(sessionId: Long?, includeRaw: Boolean = true): String? {
        val id = sessionId ?: latestSessionId() ?: return null
        val db = readableDatabase
        val session = db.rawQuery("SELECT * FROM drive_sessions WHERE id=?", arrayOf(id.toString()))
        if (!session.moveToFirst()) {
            session.close()
            return null
        }
        val startedAt = session.long("started_at_ms")
        val storedEndedAt = session.optLong("ended_at_ms")
        val effectiveEndedAt = storedEndedAt ?: System.currentTimeMillis()
        val header = buildString {
            appendLine("LOGANOS SQL EXPORT")
            appendLine("session_id=$id")
            appendLine("version=${session.str("version_name")}")
            appendLine("adapter=${session.str("adapter_name") ?: "--"} / ${session.str("adapter_address") ?: "--"}")
            appendLine("started=${formatMs(startedAt)}")
            appendLine("ended=${formatMs(effectiveEndedAt)}")
            appendLine("duration=${formatDuration(effectiveEndedAt - startedAt)}")
            appendLine("session_state=${if (storedEndedAt == null) "ACTIVE_AT_EXPORT" else "ENDED"}")
            appendLine()
        }
        session.close()

        val builder = StringBuilder(header)
        val testStartCounts = mutableMapOf<String, Int>()
        val activeTestStarts = mutableMapOf<String, Long>()
        db.rawQuery(
            "SELECT * FROM test_events WHERE session_id=? ORDER BY time_ms ASC",
            arrayOf(id.toString())
        ).use { c ->
            if (c.count > 0) {
                builder.appendLine("[TEST_EVENTS]")
                while (c.moveToNext()) {
                    val type = c.str("event_type") ?: "EVENT"
                    val name = c.str("name") ?: "--"
                    val note = c.str("note") ?: ""
                    val timeMs = c.long("time_ms")
                    val suffix = if (type == "TEST_START") {
                        val next = (testStartCounts[name] ?: 0) + 1
                        testStartCounts[name] = next
                        activeTestStarts[name] = timeMs
                        " #$next"
                    } else ""
                    val shortNote = if (type == "TEST_END") {
                        val started = activeTestStarts[name]
                        if (started != null && timeMs - started < 5000L) " kısa/geçersiz deneme" else ""
                    } else ""
                    builder.appendLine("[$type$suffix] ${formatMs(timeMs)} name=$name note=$note$shortNote")
                }
                builder.appendLine()
            }
        }
        db.rawQuery(
            "SELECT * FROM obd_samples WHERE session_id=? ORDER BY time_ms ASC",
            arrayOf(id.toString())
        ).use { c ->
            builder.appendLine("[SAMPLES] count=${c.count}")
            builder.appendLine(if (includeRaw) "format=summary+raw; raw ECU packets included when available" else "format=summary; raw ECU packets omitted")
            while (c.moveToNext()) {
                val line = "[LOOP #${c.str("loop_index") ?: "--"} at=${formatTime(c.long("time_ms"))} ${c.long("loop_ms")}ms] " +
                    "speed=${c.str("speed_kmh") ?: "--"} rpm=${c.str("rpm") ?: "--"} temp=${c.str("coolant_c") ?: "--"} " +
                    "fuel=${c.str("fuel_mg") ?: "--"} instant=${c.str("instant_value") ?: "--"} ${c.str("instant_unit") ?: ""} " +
                    "pedal=${c.str("pedal_percent") ?: "--"} map=${c.str("map_mbar") ?: "--"} air=${c.str("air_charge") ?: "--"} " +
                    "ac=${c.str("ac_on") ?: "--"} fan=${c.str("fan_state") ?: "UNKNOWN"} src=${c.str("fuel_source") ?: "--"} " +
                    "trip=${c.str("trip_state") ?: "--"} dist=${c.str("trip_distance_km") ?: "--"} fuelUsed=${c.str("fuel_used_l") ?: "--"} avg=${c.str("avg_l100") ?: "--"}"
                builder.appendLine(line)
                val raw21cc = c.str("raw21cc")
                val raw21a0 = c.str("raw21a0")
                val raw21a2 = c.str("raw21a2")
                val raw21cd = c.str("raw21cd")
                if (includeRaw && (!raw21cc.isNullOrBlank() || !raw21a0.isNullOrBlank() || !raw21a2.isNullOrBlank() || !raw21cd.isNullOrBlank())) {
                    builder.appendLine("RAW 21CC=${raw21cc ?: ""}")
                    builder.appendLine("RAW 21A0=${raw21a0 ?: ""}")
                    builder.appendLine("RAW 21A2=${raw21a2 ?: ""}")
                    builder.appendLine("RAW 21CD=${raw21cd ?: ""}")
                }
            }
        }
        return builder.toString()
    }

    private fun latestSessionId(): Long? {
        readableDatabase.rawQuery("SELECT id FROM drive_sessions ORDER BY id DESC LIMIT 1", emptyArray()).use { c ->
            return if (c.moveToFirst()) c.getLong(0) else null
        }
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun formatMs(ms: Long): String = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(ms))

    private fun formatTime(ms: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(ms))

    private fun ContentValues.putNullable(key: String, value: Int?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun ContentValues.putNullable(key: String, value: Double?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun Cursor.str(column: String): String? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getString(index) else null
    }

    private fun Cursor.long(column: String): Long = getLong(getColumnIndexOrThrow(column))

    private fun Cursor.optLong(column: String): Long? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getLong(index) else null
    }

    companion object {
        private const val DB_NAME = "loganos_records.db"
        private const val DB_VERSION = 1
    }
}
