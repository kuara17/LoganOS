package com.dcui.loganos.ui.components

import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import com.dcui.loganos.R
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun DaciaBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    Image(
        painter = painterResource(id = R.drawable.asset_brand_dacia),
        contentDescription = "Dacia",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}

@Composable
fun RenaultBrandLogo(palette: LoganPalette, modifier: Modifier = Modifier, selected: Boolean = false) {
    Image(
        painter = painterResource(id = R.drawable.asset_brand_renault),
        contentDescription = "Renault",
        contentScale = ContentScale.Fit,
        modifier = modifier
    )
}
