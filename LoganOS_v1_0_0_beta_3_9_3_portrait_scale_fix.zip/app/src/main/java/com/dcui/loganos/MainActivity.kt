package com.dcui.loganos

import android.Manifest
import android.content.pm.ActivityInfo
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.app.ActivityCompat
import androidx.core.view.WindowCompat
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.dcui.loganos.data.AppPrefs
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.obd.ObdController
import com.dcui.loganos.ui.screens.LoganAppShell
import com.dcui.loganos.ui.screens.SetupWizard
import com.dcui.loganos.ui.screens.SplashScreen
import com.dcui.loganos.ui.theme.LoganOSTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    private lateinit var prefs: AppPrefs

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        prefs = AppPrefs(this)
        requestBluetoothPermissions()

        setContent {
            var settings by remember { mutableStateOf(prefs.load()) }
            var showSplash by remember { mutableStateOf(true) }
            var demoTick by remember { mutableIntStateOf(0) }
            val obdController = remember { ObdController(this) }
            DisposableEffect(Unit) {
                onDispose { obdController.release() }
            }
            val obdState = obdController.state
            val dark = settings.darkMode

            fun persist(updated: LoganSettings) {
                settings = updated
                prefs.save(updated)
            }


            LaunchedEffect(settings.rawEcuLogEnabled, settings.developerModeEnabled) {
                // Normal kullanımda kayıt sistemi otomatik/akıllı özet modundadır.
                // Geliştirici modu açıldığında testler için tam frekanslı özet kayıt tutulur.
                val rawLogEnabled = settings.developerModeEnabled && settings.rawEcuLogEnabled
                val smartSummaryLog = !settings.developerModeEnabled
                obdController.setLoggingOptions(rawLogEnabled, smartSummaryLog)
            }

            LaunchedEffect(settings) {
                // Smart Trip kararı ve export metadata'sı güncel ayarlardan beslensin.
                obdController.setRuntimeSettings(settings)
            }

            LaunchedEffect(settings.keepScreenOn) {
                if (settings.keepScreenOn) {
                    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                }
            }

            LaunchedEffect(settings.deviceMode, settings.setupCompleted) {
                requestedOrientation = if (settings.setupCompleted && settings.deviceMode == DeviceMode.HeadUnit) {
                    ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                } else {
                    ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                }
            }

            LaunchedEffect(showSplash) {
                if (showSplash) {
                    // Splash için maksimum bekleme/fallback. Reset akışında showSplash false'a alınır.
                    delay(1700)
                    showSplash = false
                }
            }

            LaunchedEffect(settings.demoMode) {
                while (settings.demoMode) {
                    delay(800)
                    demoTick++
                }
            }

            fun enrichTrip(snapshot: DashboardSnapshot): DashboardSnapshot {
                val calibrationFactor = if (settings.fuelCalibrationEnabled) {
                    settings.fuelCalibrationFactor.coerceIn(0.50, 1.50)
                } else {
                    1.0
                }
                val calibrated = if (calibrationFactor != 1.0) {
                    snapshot.copy(
                        averageConsumption = snapshot.averageConsumption?.times(calibrationFactor),
                        instantConsumption = snapshot.instantConsumption?.times(calibrationFactor),
                        fuelUsedL = snapshot.fuelUsedL?.times(calibrationFactor)
                    )
                } else snapshot

                val distance = calibrated.tripDistanceKm
                val fuel = calibrated.fuelUsedL

                // Ortalama ve maliyet resetleri trip'i silmez; yalnızca ayrı başlangıç
                // noktalarından hesap yapar. Yeni trip toplamları baseline'ın altına
                // düşerse eski baseline otomatik olarak geçersiz sayılır.
                val avgBaselineMatchesTrip = settings.avgResetTripToken != 0L && settings.avgResetTripToken == calibrated.tripToken
                val costBaselineMatchesTrip = settings.costResetTripToken != 0L && settings.costResetTripToken == calibrated.tripToken
                val avgBaseDistance = if (avgBaselineMatchesTrip && distance != null && settings.avgResetDistanceKm in 0.0..distance) settings.avgResetDistanceKm else 0.0
                val avgBaseFuel = if (avgBaselineMatchesTrip && fuel != null && settings.avgResetFuelLiters in 0.0..fuel) settings.avgResetFuelLiters else 0.0
                val avgDistance = distance?.minus(avgBaseDistance)?.coerceAtLeast(0.0)
                val avgFuel = fuel?.minus(avgBaseFuel)?.coerceAtLeast(0.0)
                val resetAverage = if (avgBaselineMatchesTrip && (settings.avgResetDistanceKm > 0.0 || settings.avgResetFuelLiters > 0.0)) {
                    if (avgDistance != null && avgFuel != null && avgDistance >= 1.0) {
                        (avgFuel / avgDistance.coerceAtLeast(0.0001)) * 100.0
                    } else null
                } else calibrated.averageConsumption

                val price = settings.fuelPriceText.replace(',', '.').toDoubleOrNull()
                val costBaseFuel = if (costBaselineMatchesTrip && fuel != null && settings.costResetFuelLiters in 0.0..fuel) settings.costResetFuelLiters else 0.0
                val costFuel = fuel?.minus(costBaseFuel)?.coerceAtLeast(0.0)
                val cost = if (price != null && price > 0.0 && costFuel != null) {
                    String.format(java.util.Locale.US, "%.2f ₺", costFuel * price)
                } else calibrated.tripCostText
                val baseOdo = settings.odometerText.toIntOrNull()
                val odo = if (baseOdo != null && calibrated.tripDistanceKm != null) {
                    baseOdo + calibrated.tripDistanceKm.toInt()
                } else calibrated.odometerKm
                return calibrated.copy(
                    averageConsumption = resetAverage,
                    tripCostText = cost,
                    odometerKm = odo
                )
            }

            val liveSnapshot = when {
                settings.demoMode -> enrichTrip(DashboardSnapshot.demoLive(demoTick))
                obdState.connected -> enrichTrip(obdState.snapshot)
                else -> DashboardSnapshot.empty()
            }

            LoganOSTheme(accentColor = settings.accentColor, darkTheme = dark) { palette ->
                when {
                    showSplash -> SplashScreen(palette)
                    !settings.setupCompleted -> SetupWizard(
                        palette = palette,
                        initial = settings,
                        onComplete = { updated -> persist(updated) }
                    )
                    else -> LoganAppShell(
                        palette = palette,
                        settings = settings,
                        snapshot = liveSnapshot,
                        obdState = obdState,
                        onSettingsChange = { updated -> persist(updated) },
                        onResetSetup = {
                            prefs.resetSetup()
                            settings = settings.copy(setupCompleted = false)
                            // Kurulumu sıfırla sonrası splash'a dönmeden doğrudan sihirbaz açılır.
                            showSplash = false
                        },
                        onResetMetrics = { action ->
                            if (liveSnapshot.tripToken == 0L) {
                                Toast.makeText(this, "Aktif yolculuk verisi yok", Toast.LENGTH_SHORT).show()
                            } else {
                                val currentDistance = liveSnapshot.tripDistanceKm ?: 0.0
                                val currentFuel = liveSnapshot.fuelUsedL ?: 0.0
                                val updated = when (action) {
                                    TripMetricReset.Average -> settings.copy(
                                        avgResetDistanceKm = currentDistance,
                                        avgResetFuelLiters = currentFuel,
                                        avgResetTripToken = liveSnapshot.tripToken
                                    )
                                    TripMetricReset.Cost -> settings.copy(
                                        costResetFuelLiters = currentFuel,
                                        costResetTripToken = liveSnapshot.tripToken
                                    )
                                    TripMetricReset.AverageAndCost -> settings.copy(
                                        avgResetDistanceKm = currentDistance,
                                        avgResetFuelLiters = currentFuel,
                                        costResetFuelLiters = currentFuel,
                                        avgResetTripToken = liveSnapshot.tripToken,
                                        costResetTripToken = liveSnapshot.tripToken
                                    )
                                }
                                persist(updated)
                                obdController.logMetricReset(action, currentDistance, currentFuel, settings.fuelPriceText)
                                val message = when (action) {
                                    TripMetricReset.Average -> "Ortalama tüketimi sıfırlandı"
                                    TripMetricReset.Cost -> "Sürüş maliyeti sıfırlandı"
                                    TripMetricReset.AverageAndCost -> "Ortalama ve maliyet sıfırlandı"
                                }
                                Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
                            }
                        },
                        onRefreshObdDevices = { obdController.refreshPairedDevices() },
                        onSelectObdDevice = { obdController.selectDevice(it) },
                        onConnectObd = { obdController.connectSelected() },
                        onDisconnectObd = { obdController.disconnect() },
                        onSaveObdLog = {
                            obdController.saveLogFile()
                            Toast.makeText(this, "Log oluşturuldu", Toast.LENGTH_SHORT).show()
                        },
                        onShareObdLog = { obdController.shareLogText() },
                        onCreateSupportPackage = {
                            obdController.createSupportPackage()
                            Toast.makeText(this, "Destek paketi oluşturuldu", Toast.LENGTH_SHORT).show()
                        },
                        onClearLastObdLog = {
                            obdController.clearLastLogFile()
                            Toast.makeText(this, "Son log işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        },
                        onClearAllObdLogs = {
                            obdController.clearAllLogFiles()
                            Toast.makeText(this, "Log temizleme işlemi tamamlandı", Toast.LENGTH_SHORT).show()
                        },
                        onDeveloperTestStart = { name ->
                            obdController.startDeveloperTest(name)
                            Toast.makeText(this, "Test başladı: $name", Toast.LENGTH_SHORT).show()
                        },
                        onDeveloperTestEnd = {
                            obdController.finishDeveloperTest()
                            Toast.makeText(this, "Test bitti", Toast.LENGTH_SHORT).show()
                        },
                        onStartCrankAnalysis = { obdController.armManualCrankAnalysis() },
                        onClearManualCrankTests = {
                            obdController.clearManualCrankTests()
                            Toast.makeText(this, "Marş testleri silindi", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }

    private fun requestBluetoothPermissions() {
        val permissions = buildList {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                add(Manifest.permission.BLUETOOTH_CONNECT)
                add(Manifest.permission.BLUETOOTH_SCAN)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P) {
                add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
        }.toTypedArray()
        if (permissions.isNotEmpty()) ActivityCompat.requestPermissions(this, permissions, 1203)
    }
}
