# LoganOS v1.0.0-beta.3.9.3

Focused UI stabilization build.

## Changed
- Version bumped to `1.0.0-beta.3.9.3`.
- Dashboard now forces the active cockpit gauge to a single stable `DigitalSpeedPanel`.
- `SpeedPanel(...)` keeps its public API but renders Digital OEM only for this build.
- Added `DigitalOemGauge` with a persistent zero-speed skeleton: static grey arc/ticks and start dot.
- Setup Wizard and Settings no longer expose unfinished Sport / Classic / Minimal / RS gauge choices.
- Added a cropped Dacia-inspired `loganos_wordmark_header.png` asset for the header wordmark.
- Header layout changed to keep LOGANOS and OBD pill in separate row areas.
- OBD pill label made more compact to avoid covering the wordmark.
- Removed circular border rings from cockpit icon bubbles.
- Removed border from the small fan badge inside Hararet/Fan.
- Increased Setup Wizard Dacia/Renault logo display boxes.
- Fixed duplicated `Ortalama` cell in landscape layout.
- AppPrefs now loads `GaugeStyle.Digital` for this build regardless of older saved gauge preference.

## Not touched
- OBD / KWP polling
- Delphi parser byte positions
- FuelAlgorithmV3
- injection mg/stroke fuel calculation
- CUTOFF / COAST_GUARD
- TripComputer core behavior
- AC_FAST primary bit
- Fan UNKNOWN decision
- OBD speed value
