# Claude Review Prompt — LoganOS v1.0.0-beta.3.9.1

Review this Android/Kotlin/Jetpack Compose project as a focused regression and build-readiness pass.

## Intended changes

1. **Single version source**
   - `app/build.gradle.kts` is the only literal app-version source.
   - Runtime UI/log/export code must use `BuildConfig.VERSION_NAME`.
   - The version is shown only under Settings > About.
   - Export/APK artifact names must not contain stale `beta3_8_2` values.

2. **Cockpit OBD status**
   - A written status pill must show `OBD BAĞLI`, `BAĞLANIYOR`, `OBD BEKLENİYOR`, or `DEMO`.
   - Duplicate Demo labels must not remain.

3. **Cockpit icon fit/alignment**
   - Main bitmap icons use `Image`, `ContentScale.Fit`, and centered safe sizing.
   - Average, instant, distance, trip time, and combined coolant/fan icons must not be clipped.
   - `asset_temp_fan.png` should be used for the Hararet/Fan card.

4. **Average and cost reset baselines**
   - The cockpit reset menu offers Average, Cost, or Average+Cost.
   - A second confirmation is required before applying a reset.
   - Trip distance, total fuel, and trip duration must remain intact.
   - Average and cost baselines use independent trip tokens and are persisted, so resetting one in a new trip cannot reactivate the other from an old trip.
   - Events are logged as `AVG_RESET`, `COST_RESET`, or `AVG_COST_RESET`.

5. **Smart Trip logging**
   - The configured timeout is respected; for example, a 49-minute stop with a 60-minute setting continues the same trip.
   - Decisions are logged as `SMART_TRIP CONTINUE` or `SMART_TRIP NEW_TRIP`, including gap and threshold.
   - Short Bluetooth drops must not erase the trip.

6. **AC validation and fan safety**
   - The existing primary AC parser result remains authoritative.
   - `21CC` payload byte 1 / `0x80` is only a redundant cross-check.
   - Mismatches produce an `AC_BIT_MISMATCH` developer event.
   - Fan remains `UNKNOWN`; do not infer it from AC.

7. **ECT smoothing**
   - Use a 3-sample rolling median, not a hard delta clamp.

8. **Exports**
   - Summary share excludes raw ECU packets.
   - Support package is one ZIP containing `summary_log.txt`, `raw_obd_log.txt`, and `metadata.txt`.
   - Export headers include a real/effective end time, duration, and active/ended session state.
   - Metadata includes Smart Trip threshold and relevant UI/logging settings.

## Must remain unchanged

- OBD speed value and scaling
- FuelAlgorithmV3 formulas
- CUTOFF and COAST_GUARD behavior
- Delphi parser core byte positions
- Fan `UNKNOWN` policy

## Please report

- Compile blockers or invalid Compose/Kotlin calls
- Incorrect callback/signature wiring
- Baseline/reset edge cases
- Smart Trip reconnect/session edge cases
- Export/ZIP/file-provider issues
- Any stale hardcoded version strings
- Any remaining icon clipping risks
- A concise list of fixes required before APK testing
