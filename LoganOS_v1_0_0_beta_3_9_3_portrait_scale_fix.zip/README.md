# LoganOS v1.0.0-beta.3.9.2

Reduced UI patch applied on top of original v1.0.0-beta.3.9.1. Gauge redesign and OBD/fuel/trip logic were not touched.

# LoganOS v1.0.0-beta.3.9.1

Bu sürüm; tek merkezli sürüm yönetimi, yazılı OBD durum rozeti, kokpit ikon hizalaması, bağımsız ortalama/maliyet sıfırlama, Smart Trip karar logları, AC yedek bit doğrulaması, ECT rolling median ve tek ZIP destek paketini içerir.

APK üretimi için `.github/workflows/build-apk.yml` GitHub Actions iş akışı kullanılabilir. İş akışı sürüm adını `app/build.gradle.kts` içinden otomatik okur.

Additional local correction after inspecting Claude patch:
- Removed the remaining duplicate red status text from SpeedReadout in Gauges.kt. Claude's diff removed status text from later panel functions, but SpeedReadout was still active in the current SpeedPanel path.
