# LoganOS 1.0.0-beta.4.20.46

## Bu sürümde

- Teknik oturum ZIP dışa aktarımında, dosya başarıyla kaydedildikten sonra geçmiş listesini yenileme hatası yaşanırsa dışa aktarma artık yanlışlıkla başarısız gösterilmez. Bu durum ayrı tanılama kaydına yazılır.
- Sürüş ve test geçmişi ZIP özetinde uygulama sürüm bilgisi güncellendi.
- Android OTA paket kimliği yeni sürüme yükseltildi.

## Korunan davranışlar

- OBD/KWP protokolü, Renault/Dacia PID'leri ve sorgu zamanlamaları değiştirilmedi.
- FuelAlgorithmV3 ve TripComputer hesaplamaları değiştirilmedi.
- Veritabanı sürümü v7 olarak kaldı; veritabanı şeması yükseltmesi yoktur.

## Teknik doğrulama

- Önceki R4 kaynak paketi GitHub Actions #107 üzerinde 222/222 birim testini başarıyla geçti ve debug APK oluşturdu.
- Bu 1.0.0-beta.4.20.46 sürüm adayı için CI doğrulaması, imzalı release ve gerçek cihaz kabul testleri ayrıca yapılmalıdır.
