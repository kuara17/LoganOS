package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.obd.CrankAnalysisResult
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.components.SpeedGauge
import com.dcui.loganos.ui.components.SpeedPanel
import com.dcui.loganos.ui.theme.LoganPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


private val LoganFuelInstantRed = Color(0xFFE53935)
private val LoganTempColdBlue = Color(0xFF4A78E6)
private val LoganTempWarmAmber = Color(0xFFF39C12)
private val LoganTempNormalGreen = Color(0xFF43A047)
private val LoganAcBlue = Color(0xFF2F80ED)

enum class MainTab {
    Cockpit,
    Trip,
    Tests,
    Technical,
    Settings
}

private fun tabLabel(tab: MainTab, language: AppLanguage): String = when (tab) {
    MainTab.Cockpit -> if (language == AppLanguage.English) "Cockpit" else "Kokpit"
    MainTab.Trip -> if (language == AppLanguage.English) "Trip" else "Sürüş"
    MainTab.Tests -> if (language == AppLanguage.English) "Tests" else "Testler"
    MainTab.Technical -> if (language == AppLanguage.English) "Tech" else "Teknik"
    MainTab.Settings -> if (language == AppLanguage.English) "Settings" else "Ayarlar"
}


private fun cockpitTextScale(settings: LoganSettings): Float = when (settings.cockpitTextSize) {
    // Visible, but not so large that units and titles are clipped on S23 FE portrait.
    CockpitTextSize.Small -> 0.98f
    CockpitTextSize.Normal -> 1.06f
    CockpitTextSize.Large -> 1.16f
}

private fun cockpitCardHeight(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 86.dp
    CockpitDensity.Balanced -> 96.dp
    CockpitDensity.Wide -> 108.dp
}

private fun cockpitCoolingHeight(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 84.dp
    CockpitDensity.Balanced -> 94.dp
    CockpitDensity.Wide -> 104.dp
}

private fun cockpitSpacing(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 0.dp
    CockpitDensity.Balanced -> 2.dp
    CockpitDensity.Wide -> 4.dp
}

private fun cockpitGaugeMinHeight(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    // Give the selected gauge style enough real cockpit height.
    // These values are deliberately above SpeedGauge's 110dp compact threshold.
    CockpitDensity.Compact -> 130.dp
    CockpitDensity.Balanced -> 150.dp
    CockpitDensity.Wide -> 170.dp
}

private fun cockpitStyleAccent(settings: LoganSettings, palette: LoganPalette): Color = when (settings.gaugeStyle) {
    GaugeStyle.RsPerformance -> Color(0xFFD62828)
    GaugeStyle.Sport -> Color(0xFF18A84F)
    GaugeStyle.ClassicOem -> Color(0xFF107C41)
    GaugeStyle.Minimal -> Color(0xFF107C41)
    GaugeStyle.Digital -> palette.accent
}

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit
) {
    var tab by remember { mutableStateOf(MainTab.Cockpit) }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                MainTab.Cockpit -> DashboardContent(palette, settings, snapshot, obdState, onResetMetrics)
                MainTab.Trip -> TripPage(palette, snapshot, settings.language)
                MainTab.Tests -> CrankingPage(palette, settings.language, obdState, onStartCrankAnalysis, onClearManualCrankTests)
                MainTab.Technical -> TechnicalPage(palette, settings, snapshot, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onCreateSupportPackage, onClearLastObdLog, onClearAllObdLogs)
                MainTab.Settings -> SettingsScreen(palette, settings, obdState, onSettingsChange, onResetSetup, onResetMetrics, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onCreateSupportPackage, onClearLastObdLog, onClearAllObdLogs, onDeveloperTestStart, onDeveloperTestEnd, onStartCrankAnalysis, onClearManualCrankTests)
            }
            DeveloperTestOverlay(palette, obdState, onDeveloperTestEnd)
        }
        BottomNavigationBar(palette, current = tab, language = settings.language) { tab = it }
    }
}

@Composable
private fun DeveloperTestOverlay(
    palette: LoganPalette,
    obdState: ObdState,
    onEnd: () -> Unit
) {
    val activeTest = obdState.activeDeveloperTest
    val doneMessage = obdState.developerTestDoneMessage
    if (activeTest == null && doneMessage == null) return

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.55f))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        OemCard(
            palette = palette,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 520.dp)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(14.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (activeTest != null) {
                    Text(
                        text = activeTest,
                        color = palette.textPrimary,
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = obdState.developerTestPhaseText ?: "Hazırlan",
                        color = palette.accent,
                        fontSize = 30.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "${obdState.developerTestRemainingSec ?: 0}",
                        color = palette.textPrimary,
                        fontSize = 64.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Ekrandaki komutu uygula. Test boyunca OBD verisi ve SQL log işaretleri kaydedilir.",
                        color = palette.textSecondary,
                        fontSize = 14.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = onEnd,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Text("Testi Bitir", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(
                        text = doneMessage ?: "Test bitti",
                        color = palette.accent,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Geri sayım ekranı kapatılıyor.",
                        color = palette.textSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun DashboardContent(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onResetMetrics: (TripMetricReset) -> Unit
) {
    var showResetDialog by remember { mutableStateOf(false) }
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        if (maxWidth > maxHeight) {
            DashboardLandscape(palette, settings, snapshot, obdState, onOpenReset = { showResetDialog = true })
        } else {
            DashboardPortrait(palette, settings, snapshot, obdState, onOpenReset = { showResetDialog = true })
        }
    }
    if (showResetDialog) {
        MetricResetDialog(
            palette = palette,
            language = settings.language,
            onDismiss = { showResetDialog = false },
            onReset = { action ->
                showResetDialog = false
                onResetMetrics(action)
            }
        )
    }
}

@Composable
private fun DashboardPortrait(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit
) {
    val textScale = cockpitTextScale(settings)
    val spacing = cockpitSpacing(settings)
    val metricHeight = cockpitCardHeight(settings)
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp, vertical = 4.dp),
        verticalArrangement = Arrangement.spacedBy(spacing),
        contentPadding = PaddingValues(bottom = 10.dp)
    ) {
        item { DashboardConceptHeader(palette, snapshot, obdState, settings.demoMode, settings.language) }
        item {
            ConceptSpeedBlock(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                modifier = Modifier.fillMaxWidth().heightIn(min = cockpitGaugeMinHeight(settings))
            )
        }
        item { ConceptDivider(palette) }
        item {
            ConceptMetricRow(palette, metricHeight) {
                ConceptMetricCell(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, subtitle = if ((snapshot.tripDistanceKm ?: 0.0) < 3.0 && snapshot.averageConsumption != null) "Kısa sürüş" else null, modifier = Modifier.weight(1f), textScale = textScale, onReset = onOpenReset)
                ConceptMetricCell(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, modifier = Modifier.weight(1f), textScale = textScale)
            }
        }
        item { ConceptDivider(palette) }
        item {
            ConceptMetricRow(palette, metricHeight) {
                ConceptMetricCell(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", CardIcon.Distance, modifier = Modifier.weight(1f), textScale = textScale)
                ConceptMetricCell(palette, "Sürüş Maliyeti", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, subtitle = if (settings.demoMode) "Demo veri" else null, modifier = Modifier.weight(1f), textScale = textScale)
            }
        }
        item { ConceptDivider(palette) }
        item {
            ConceptMetricRow(palette, metricHeight) {
                val temp = snapshot.engineTempC?.toString() ?: "--"
                ConceptMetricCell(palette, "Hararet / Fan", temp, "°C", CardIcon.TemperatureFan, subtitle = "Fan: test bekliyor", modifier = Modifier.weight(1f), textScale = textScale)
                ConceptMetricCell(palette, "Klima", snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", null, CardIcon.Ac, modifier = Modifier.weight(1f), textScale = textScale)
            }
        }
        item { ConceptDivider(palette) }
        item {
            ConceptMetricRow(palette, metricHeight) {
                ConceptMetricCell(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", CardIcon.Rpm, modifier = Modifier.weight(1f), textScale = textScale)
                ConceptMetricCell(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, subtitle = if (settings.demoMode) "Demo veri" else null, modifier = Modifier.weight(1f), textScale = textScale)
            }
        }
    }
}

@Composable
private fun DashboardLandscape(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit
) {
    val textScale = cockpitTextScale(settings)
    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(modifier = Modifier.weight(.92f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            DashboardConceptHeader(palette, snapshot, obdState, settings.demoMode, settings.language, compact = true)
            ConceptSpeedBlock(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                modifier = Modifier.fillMaxWidth().weight(1f),
                compact = true
            )
        }
        Column(modifier = Modifier.weight(1.18f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            ConceptDivider(palette)
            ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                ConceptMetricCell(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale, onReset = onOpenReset)
                ConceptMetricCell(palette, "Anlık", fmt(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
            }
            ConceptDivider(palette)
            ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                ConceptMetricCell(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", CardIcon.Distance, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                ConceptMetricCell(palette, "Maliyet", snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
            }
            ConceptDivider(palette)
            ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                ConceptMetricCell(palette, "Hararet / Fan", snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.TemperatureFan, subtitle = "Fan: test bekliyor", modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                ConceptMetricCell(palette, "Klima", snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--", null, CardIcon.Ac, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
            }
            ConceptDivider(palette)
            ConceptMetricRow(palette, 0.dp, modifier = Modifier.weight(1f)) {
                ConceptMetricCell(palette, "Devir", snapshot.rpm?.toString() ?: "--", "rpm", CardIcon.Rpm, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
                ConceptMetricCell(palette, "Sürüş Süresi", snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, modifier = Modifier.weight(1f).fillMaxHeight(), textScale = textScale)
            }
        }
    }
}

@Composable
private fun DashboardConceptHeader(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean = false
) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier.fillMaxWidth().height(if (compact) 36.dp else 42.dp),
            contentAlignment = Alignment.Center
        ) {
            LoganWordmark(palette, compact = true)
            ObdStatusPill(
                palette = palette,
                connected = snapshot.connected || obdState.connected,
                connecting = obdState.connecting,
                demoMode = demoMode,
                language = language,
                compact = compact,
                modifier = Modifier.align(Alignment.CenterEnd)
            )
        }
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .80f)))
    }
}

@Composable
private fun ObdStatusPill(
    palette: LoganPalette,
    connected: Boolean,
    connecting: Boolean,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean,
    modifier: Modifier = Modifier
) {
    val english = language == AppLanguage.English
    val label = when {
        demoMode -> "DEMO"
        connected -> if (english) "OBD CONNECTED" else "OBD BAĞLI"
        connecting -> if (english) "CONNECTING" else "BAĞLANIYOR"
        else -> if (english) "OBD WAITING" else "OBD BEKLENİYOR"
    }
    val color = when {
        demoMode -> palette.warning
        connected -> palette.accent
        connecting -> palette.warning
        else -> palette.textSecondary
    }
    Row(
        modifier = modifier
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = .11f))
            .padding(horizontal = if (compact) 7.dp else 9.dp, vertical = if (compact) 3.dp else 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 6.dp else 7.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(color)
        )
        Text(
            text = label,
            color = color,
            fontSize = if (compact) 8.5.sp else 9.5.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun MetricResetDialog(
    palette: LoganPalette,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onReset: (TripMetricReset) -> Unit
) {
    var pendingAction by remember { mutableStateOf<TripMetricReset?>(null) }
    val english = language == AppLanguage.English
    val pendingLabel = when (pendingAction) {
        TripMetricReset.Average -> if (english) "average consumption" else "ortalama tüketim"
        TripMetricReset.Cost -> if (english) "trip cost" else "sürüş maliyeti"
        TripMetricReset.AverageAndCost -> if (english) "average consumption and trip cost" else "ortalama tüketim ve sürüş maliyeti"
        null -> ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (pendingAction == null) {
                    if (english) "Reset calculations" else "Hesapları sıfırla"
                } else {
                    if (english) "Confirm reset" else "Sıfırlamayı onayla"
                },
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            if (pendingAction == null) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (english) {
                            "Trip distance, total fuel and trip time will be preserved. The selected calculation will restart from this point."
                        } else {
                            "Mevcut yolculuğun mesafe, toplam yakıt ve sürüş süresi korunur. Seçilen hesap bu noktadan itibaren yeniden başlar."
                        },
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    ResetChoice(palette, if (english) "Reset average consumption" else "Ortalama tüketimi sıfırla") {
                        pendingAction = TripMetricReset.Average
                    }
                    ResetChoice(palette, if (english) "Reset trip cost" else "Sürüş maliyetini sıfırla") {
                        pendingAction = TripMetricReset.Cost
                    }
                    ResetChoice(palette, if (english) "Reset average + cost" else "Ortalama + maliyeti sıfırla") {
                        pendingAction = TripMetricReset.AverageAndCost
                    }
                }
            } else {
                Text(
                    if (english) {
                        "Reset $pendingLabel from this point? Trip totals will not be deleted."
                    } else {
                        "$pendingLabel bu noktadan itibaren sıfırlansın mı? Yolculuk toplamları silinmez."
                    },
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            pendingAction?.let { action ->
                TextButton(onClick = { onReset(action) }) {
                    Text(if (english) "Reset" else "Sıfırla")
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (pendingAction != null) pendingAction = null else onDismiss()
                }
            ) {
                Text(
                    if (pendingAction != null) {
                        if (english) "Back" else "Geri"
                    } else {
                        if (english) "Cancel" else "İptal"
                    }
                )
            }
        }
    )
}

@Composable
private fun ResetChoice(palette: LoganPalette, label: String, onClick: () -> Unit) {
    Text(
        text = label,
        color = palette.textPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceVariant)
            .clickable { onClick() }
            .padding(12.dp)
    )
}

@Composable
private fun ConceptSpeedBlock(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier,
    compact: Boolean = false
) {
    val panelHeight = if (compact) 170.dp else cockpitGaugeMinHeight(settings)
    Box(
        modifier = modifier
            .padding(top = if (compact) 0.dp else 2.dp, bottom = 2.dp),
        contentAlignment = Alignment.Center
    ) {
        SpeedPanel(
            palette = palette,
            speed = snapshot.speedKmh,
            style = settings.gaugeStyle,
            modifier = Modifier
                .fillMaxWidth(if (compact) .92f else .98f)
                .heightIn(min = panelHeight),
            demoMode = settings.demoMode
        )
    }
}

@Composable
private fun ConceptDivider(palette: LoganPalette) {
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .68f)))
}

@Composable
private fun ConceptMetricRow(
    palette: LoganPalette,
    height: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (height.value > 0f) Modifier.height(height) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        content = content
    )
}

@Composable
private fun ConceptMetricCell(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    textScale: Float = 1.0f,
    onReset: (() -> Unit)? = null
) {
    val scale = textScale.coerceIn(0.95f, 1.28f)
    val iconBubble = when {
        scale >= 1.14f -> 76.dp
        scale >= 1.04f -> 70.dp
        else -> 64.dp
    }
    val iconSize = when {
        scale >= 1.14f -> 48.dp
        scale >= 1.04f -> 44.dp
        else -> 40.dp
    }
    Box(modifier = modifier.fillMaxHeight().padding(horizontal = 3.dp, vertical = 4.dp)) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(iconBubble)
                    .clip(RoundedCornerShape(42.dp))
                    .background(palette.surfaceVariant.copy(alpha = .72f))
                    .border(1.dp, palette.line.copy(alpha = .65f), RoundedCornerShape(42.dp)),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, Color.Unspecified, Modifier.size(iconSize))
            }
            Column(modifier = Modifier.weight(1f).padding(end = if (onReset != null) 30.dp else 0.dp), verticalArrangement = Arrangement.Center) {
                Text(
                    title.uppercase(),
                    color = palette.accent,
                    fontSize = (11.2f * scale).sp,
                    lineHeight = (12.4f * scale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(3.dp))
                Text(value, color = palette.textPrimary, fontSize = (22f * scale).sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                if (unit != null) {
                    Text(unit, color = palette.textSecondary, fontSize = (11.6f * scale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (subtitle != null) Text(subtitle, color = palette.textSecondary, fontSize = (9.2f * scale).sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        if (onReset != null) {
            Text(
                text = "↻",
                color = palette.accent,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(30.dp)
                    .clip(RoundedCornerShape(15.dp))
                    .background(palette.accent.copy(alpha = .10f))
                    .clickable { onReset() }
                    .padding(top = 3.dp)
            )
        }
    }
}

@Composable
private fun TemperatureCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp < 50 -> LoganTempColdBlue
        temp < 80 -> LoganTempWarmAmber
        temp <= 96 -> LoganTempNormalGreen
        else -> palette.critical
    }
    DataCard(
        palette = palette,
        title = "Hararet",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = tempColor,
        subtitle = "Soğutma suyu",
        icon = CardIcon.Temperature,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun CoolingFanCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val temp = snapshot.engineTempC
    val tempColor = when {
        temp == null -> palette.textSecondary
        temp < 50 -> LoganTempColdBlue
        temp < 80 -> LoganTempWarmAmber
        temp <= 96 -> LoganTempNormalGreen
        else -> palette.critical
    }
    DataCard(
        palette = palette,
        title = "Hararet / Fan",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = tempColor,
        subtitle = "Fan: test bekliyor",
        icon = CardIcon.TemperatureFan,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun FanCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier) {
    CoolingFanCard(palette, snapshot, modifier)
}

@Composable
private fun ClimateCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val label = snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--"
    DataCard(
        palette = palette,
        title = "Klima",
        value = label,
        accent = if (snapshot.acOn == true) LoganAcBlue else palette.textSecondary,
        subtitle = "A/C durumu",
        icon = CardIcon.Ac,
        modifier = modifier,
        textScale = textScale
    )
}

@Composable
private fun BottomNavigationBar(palette: LoganPalette, current: MainTab, language: AppLanguage, onSelect: (MainTab) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(palette.surface)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        MainTab.entries.forEach { tab ->
            val selected = current == tab
            Text(
                text = tabLabel(tab, language),
                color = if (selected) palette.accent else palette.textSecondary,
                fontSize = 12.sp,
                fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(15.dp))
                    .background(if (selected) palette.accent.copy(alpha = .12f) else Color.Transparent)
                    .clickable { onSelect(tab) }
                    .padding(vertical = 12.dp)
            )
        }
    }
}

@Composable
private fun TripPage(palette: LoganPalette, snapshot: DashboardSnapshot, language: AppLanguage) {
    InfoPage(palette, "Sürüş Merkezi", "Smart Trip / TripComputer") {
        DataCard(
            palette,
            "Güncel Yolculuk",
            snapshot.tripStateText ?: if (snapshot.connected || snapshot.demo) "Hesaplanıyor" else "Beklemede",
            subtitle = "Hareket edince başlar",
            icon = CardIcon.Time,
            modifier = Modifier.fillMaxWidth().height(104.dp)
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Mesafe", fmt(snapshot.tripDistanceKm), "km", icon = CardIcon.Distance, modifier = Modifier.weight(1f).height(88.dp))
            DataCard(palette, "Yakıt", fmt(snapshot.fuelUsedL), "L", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100 km", subtitle = "1 km sonrası", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
            DataCard(palette, "Süre", snapshot.tripDurationText ?: "00:00", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(88.dp))
        }
        Spacer(Modifier.height(8.dp))
        DataCard(
            palette,
            "Yakıt Hesabı",
            fuelSourceLabel(snapshot.fuelSource),
            subtitle = if (snapshot.connected || snapshot.demo) "Fuel Truth aktif" else "OBD bağlanınca hesaplanır",
            icon = CardIcon.FuelInstant,
            modifier = Modifier.fillMaxWidth().height(104.dp)
        )
    }
}

@Composable
private fun CrankingPage(
    palette: LoganPalette,
    language: AppLanguage,
    obdState: ObdState,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit
) {
    val tr = language != AppLanguage.English
    var confirmClear by remember { mutableStateOf(false) }
    val last = obdState.lastAutoCrankResult ?: obdState.savedManualCrankTests.firstOrNull()
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(if (tr) "Marş Analizi" else "Cranking Analysis", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text(
                if (tr) "Otomatik algılama + manuel test. Kesin arıza teşhisi değildir." else "Automatic detection + manual test. This is not a definitive diagnosis.",
                color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Manuel Marş Testi" else "Manual Cranking Test", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text(
                        when {
                            obdState.crankingInProgress -> if (tr) "Marş algılandı, veriler analiz ediliyor..." else "Cranking detected, analyzing data..."
                            obdState.manualCrankArmed -> if (tr) "Hazır. Şimdi marşa basın." else "Ready. Start the engine now."
                            obdState.connected -> if (tr) "Motor çalışmadan önce testi başlatın, ardından marşa basın." else "Start the test before the engine is running, then crank the engine."
                            else -> if (tr) "Test için önce OBD bağlantısı gerekli." else "OBD connection is required before testing."
                        },
                        color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        DataCard(palette, if (tr) "RPM" else "RPM", obdState.snapshot.rpm?.toString() ?: "--", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(84.dp))
                        DataCard(palette, if (tr) "Akü" else "Battery", obdState.snapshot.batteryV?.let { String.format(Locale.US, "%.1f", it) } ?: obdState.snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
                    }
                    Button(
                        onClick = onStartCrankAnalysis,
                        enabled = obdState.connected && !obdState.manualCrankArmed && !obdState.crankingInProgress,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) { Text(if (tr) "Marş Analizini Başlat" else "Start Cranking Analysis") }
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Son Otomatik Analiz" else "Last Automatic Analysis", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.lastAutoCrankResult == null) {
                        Text(if (tr) "Henüz otomatik marş analizi yok. Uygulama bağlıyken marş basılırsa arka planda yorum üretir." else "No automatic analysis yet. When the app is connected before cranking, it will analyze in the background.", color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                    } else {
                        CrankResultBlock(palette, obdState.lastAutoCrankResult, language)
                    }
                    Text(if (tr) "Otomatik analizler kalıcı arşive yazılmaz; son 5 kayıt / 24 saat geçici tutulur." else "Automatic analyses are not stored permanently; only the last 5 / 24 hours are kept temporarily.", color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Kayıtlı Manuel Testler" else "Saved Manual Tests", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.savedManualCrankTests.isEmpty()) {
                        Text(if (tr) "Manuel başlatılmış kayıtlı test yok." else "No saved manual tests.", color = palette.textSecondary, fontSize = 13.sp)
                    } else {
                        obdState.savedManualCrankTests.take(8).forEachIndexed { index, result ->
                            Text("#${index + 1} • ${crankDate(result.timestampMs)} • ${String.format(Locale.US, "%.1f", result.durationSec)} sn • ${localCrankStatus(result.status, language)}", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        TextButton(onClick = { confirmClear = true }) { Text(if (tr) "Manuel marş testlerini sil" else "Delete manual cranking tests") }
                    }
                }
            }
        }
        if (last != null) {
            item {
                DataCard(palette, if (tr) "Özet" else "Summary", localCrankStatus(last.status, language), subtitle = localCrankComment(last, language), icon = CardIcon.Battery, modifier = Modifier.fillMaxWidth().height(106.dp))
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(if (tr) "Marş kayıtları silinsin mi?" else "Delete cranking records?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Manuel kaydedilmiş marş testleri silinecek. Otomatik analizler zaten kısa süreli saklanır." else "Saved manual cranking tests will be deleted. Automatic analyses are already temporary.", color = palette.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmClear = false; onClearManualCrankTests() }) { Text(if (tr) "Sil" else "Delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
}

@Composable
private fun CrankResultBlock(palette: LoganPalette, result: CrankAnalysisResult, language: AppLanguage) {
    val tr = language != AppLanguage.English
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        DataCard(palette, if (tr) "Süre" else "Duration", String.format(Locale.US, "%.1f", result.durationSec), if (tr) "sn" else "s", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(84.dp))
        DataCard(palette, if (tr) "Min Volt" else "Min Volt", result.minVoltage?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
    }
    Spacer(Modifier.height(6.dp))
    Text("${localCrankStatus(result.status, language)} • ${localBatteryStatus(result.batteryStatus, language)}", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
    Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
}

private fun crankDate(ms: Long): String = SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(ms))

private fun localBatteryStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "İyi" -> "Good"
        "Sınırda" -> "Borderline"
        "Zayıf" -> "Weak"
        "Çok düşük" -> "Very low"
        "Ölçülemedi" -> "Not measured"
        else -> status
    }
}

private fun localCrankStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "Normal" -> "Normal"
        "Hafif uzun" -> "Slightly long"
        "Geç marş" -> "Long crank"
        "Belirgin geç marş" -> "Very long crank"
        "Tamamlanamadı" -> "Incomplete"
        else -> status
    }
}

private fun localCrankComment(result: CrankAnalysisResult, language: AppLanguage): String {
    if (language != AppLanguage.English) return result.comment
    return when (result.status) {
        "Normal" -> "Cranking duration looks normal. Battery voltage and RPM response are within an acceptable range."
        "Hafif uzun" -> "Cranking is slightly long. Monitor it if it repeats."
        "Geç marş" -> "Cranking is long. Battery, fuel line, crank/cam signal and glow-plug system can be checked."
        "Belirgin geç marş" -> "A very long crank was detected. Battery/ground, starter load, fuel pressure and sensor sync should be checked."
        else -> "Cranking analysis could not be completed; OBD response or RPM data may have been interrupted."
    } + if (result.obdGapDetected) " A short OBD response gap was seen during cranking." else ""
}

@Composable
private fun TechnicalPage(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastLog: () -> Unit,
    onClearAllLogs: () -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("Teknik Veriler", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text("Gelişmiş canlı değerler; ham ECU paketleri geliştirici ham loguna taşındı", color = palette.textSecondary, fontSize = 13.sp)
        }
        item { TechnicalConnectionStatus(palette, snapshot, obdState) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "RPM", snapshot.rpm?.toString() ?: "--", "d/dk", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Hız", snapshot.speedKmh?.toString() ?: "--", "km/h", icon = CardIcon.Speed, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Hararet / Fan", snapshot.engineTempC?.toString() ?: "--", "°C", subtitle = "Fan: test bekliyor", icon = CardIcon.TemperatureFan, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Klima", when (snapshot.acOn) { true -> "Açık"; false -> "Kapalı"; null -> "--" }, null, icon = CardIcon.Ac, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "L/h", if (snapshot.instantUnit == "L/h") fmt(snapshot.instantConsumption) else "--", "L/h", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "L/100", if (snapshot.instantUnit != "L/h") fmt(snapshot.instantConsumption) else "--", "L/100", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Ortalama", fmt(snapshot.averageConsumption), "L/100", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Yakıt Hesabı", fuelSourceLabel(snapshot.fuelSource), null, icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Pedal", snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "MAP", snapshot.mapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Rail", snapshot.railBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.FuelPressure, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Rail Hedef", snapshot.railTargetBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.FuelPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Hava Yükü", snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Hedef MAP", snapshot.requestedMapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Emme", snapshot.intakeTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.IntakeAirTemp, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Yakıt Isı", snapshot.fuelTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.Temperature, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Sensör V", snapshot.sensorSupplyV?.let { String.format(Locale.US, "%.3f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, "Adaptör V", snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "V", icon = CardIcon.ObdConnection, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        if (settings.developerModeEnabled) {
            item { FuelTruthTestPanel(palette, snapshot) }
        }
        item { TechnicalQualityPanel(palette, obdState) }
    }
}


@Composable
private fun TechnicalConnectionStatus(palette: LoganPalette, snapshot: DashboardSnapshot, obdState: ObdState) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text("BAĞLANTI DURUMU", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette = palette,
                    label = "OBD",
                    value = if (snapshot.connected || obdState.connected) "Bağlı" else if (obdState.connecting) "Bağlanıyor" else "Bekliyor",
                    color = if (snapshot.connected || obdState.connected) palette.accent else palette.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette = palette,
                    label = "ECU",
                    value = "DCM1.2",
                    color = palette.warning,
                    modifier = Modifier.weight(1f)
                )
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Protokol", "KWP Fast Init", palette.blue, Modifier.weight(1f))
                TechnicalStatusItem(palette, "Loop", obdState.timingText.ifBlank { "--" }, palette.accent, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "NO DATA", obdState.noDataCount.toString(), if (obdState.noDataCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
                TechnicalStatusItem(palette, "STOPPED", obdState.stoppedCount.toString(), if (obdState.stoppedCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Text(
                if (obdState.lastError != null) "Son hata: ${obdState.lastError}" else "Bağlantı yönetimi: Ayarlar > Bağlantı & Veri",
                color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                fontSize = 11.sp,
                fontWeight = if (obdState.lastError != null) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TechnicalStatusItem(
    palette: LoganPalette,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceVariant.copy(alpha = .34f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(value, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
fun ObdConnectionPanel(
    palette: LoganPalette,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onCreateSupportPackage: () -> Unit,
    onClearLastLog: () -> Unit = {},
    onClearAllLogs: () -> Unit = {},
    language: AppLanguage = AppLanguage.Turkish
) {
    var confirmTitle by remember { mutableStateOf<String?>(null) }
    var confirmMessage by remember { mutableStateOf("") }
    var confirmLabel by remember { mutableStateOf("Tamam") }
    var confirmAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun l(tr: String, en: String): String = if (language == AppLanguage.English) en else tr

    fun ask(title: String, message: String, label: String, action: () -> Unit) {
        confirmTitle = title
        confirmMessage = message
        confirmLabel = label
        confirmAction = action
    }

    val selectedDevice = obdState.pairedDevices.firstOrNull { it.address == obdState.selectedAddress }
    var showDeviceList by remember { mutableStateOf(obdState.selectedAddress.isNullOrBlank()) }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l("OBD BAĞLANTISI", "OBD CONNECTION"), color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    TechnicalStatusItem(
                        palette = palette,
                        label = l("Durum", "Status"),
                        value = if (obdState.connected) l("Bağlı", "Connected") else if (obdState.connecting) l("Bağlanıyor", "Connecting") else l("Bekliyor", "Waiting"),
                        color = if (obdState.lastError != null) palette.critical else if (obdState.connected) palette.accent else palette.textSecondary,
                        modifier = Modifier.weight(1f)
                    )
                    TechnicalStatusItem(
                        palette = palette,
                        label = l("Adaptör", "Adapter"),
                        value = selectedDevice?.name ?: obdState.selectedName ?: l("Seçilmedi", "Not selected"),
                        color = palette.textSecondary,
                        modifier = Modifier.weight(1f)
                    )
                }
                Text(
                    obdState.status,
                    color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 2
                )

                if (obdState.pairedDevices.isEmpty()) {
                    Text(
                        l("Eşleşmiş cihaz yok. Önce Android Bluetooth ayarlarından vLinker MC+ ile eşleştir.", "No paired device. Pair with vLinker MC+ from Android Bluetooth settings first."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(l("Adaptör seçimi", "Adapter selection"), color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        TextButton(onClick = { showDeviceList = !showDeviceList }) {
                            Text(if (showDeviceList) l("Listeyi Gizle", "Hide List") else l("Cihaz Seç", "Choose Device"), color = palette.accent)
                        }
                    }
                    if (showDeviceList) {
                        obdState.pairedDevices.forEach { device ->
                            val selected = obdState.selectedAddress == device.address
                            SettingsRow(
                                palette = palette,
                                title = device.name,
                                subtitle = device.address,
                                value = if (selected) l("Seçili", "Selected") else l("Seç", "Select"),
                                onClick = {
                                    onSelect(device)
                                    showDeviceList = false
                                    onConnect()
                                }
                            )
                        }
                    } else if (selectedDevice != null) {
                        Text(
                            l("Seçili cihaz: ${selectedDevice.name}. Yeni seçim için 'Cihaz Seç' butonunu kullan.", "Selected device: ${selectedDevice.name}. Use the 'Choose Device' button for a new selection."),
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                }

                Button(
                    onClick = onRefresh,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                ) { Text(l("Cihazları Tara", "Scan Devices")) }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = onConnect,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) { Text(if (obdState.connecting) l("Bağlanıyor...", "Connecting...") else if (obdState.connected) l("Yeniden Bağlan", "Reconnect") else l("OBD’ye Bağlan", "Connect OBD")) }
                    Button(
                        onClick = onDisconnect,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.critical)
                    ) { Text(l("Bağlantıyı Kes", "Disconnect")) }
                }
            }
        }

        OemCard(palette, modifier = Modifier.fillMaxWidth()) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(l("LOG & DESTEK", "LOG & SUPPORT"), color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                SettingsRow(
                    palette = palette,
                    title = l("Son Sürüş/Test Kaydını Kaydet", "Save Last Drive/Test Record"),
                    subtitle = l("Son kayıtlı sürüş veya test verisini dosyaya kaydeder", "Saves the last recorded drive or test data to a file"),
                    onClick = { ask(l("Son Sürüş/Test Kaydını Kaydet", "Save Last Drive/Test Record"), l("Son kayıtlı sürüş veya test verisi Download/LoganOS klasörüne kaydedilecek. Oluşturulsun mu?", "The last recorded drive or test data will be saved to Download/LoganOS. Create it?"), l("Oluştur", "Create")) { onSaveLog() } }
                )
                SettingsRow(
                    palette = palette,
                    title = l("Son Sürüş/Test Kaydını Paylaş", "Share Last Drive/Test Record"),
                    subtitle = l("Son kayıtlı sürüş veya test verisini paylaşır", "Shares the last recorded drive or test data"),
                    onClick = onShareLog
                )
                SettingsRow(
                    palette = palette,
                    title = l("Tüm Logları Temizle", "Clear All Logs"),
                    subtitle = l("Download/LoganOS içindeki LoganOS loglarını siler", "Deletes LoganOS logs in Download/LoganOS"),
                    onClick = { ask(l("Tüm Logları Temizle", "Clear All Logs"), l("Kayıtlı tüm LoganOS test logları silinsin mi? Bu işlem geri alınamaz.", "Delete all saved LoganOS test logs? This cannot be undone."), l("Tümünü Sil", "Delete All")) { onClearAllLogs() } }
                )
                SettingsRow(
                    palette = palette,
                    title = l("Destek Paketi Oluştur", "Create Support Package"),
                    subtitle = l("Sorun analizi için özet log ve durum bilgisini hazırlar", "Prepares summary log and status information for troubleshooting"),
                    onClick = { ask(l("Destek Paketi Oluştur", "Create Support Package"), l("Özet log, ham OBD logu ve durum bilgisi tek ZIP içinde hazırlanacak. Oluşturulsun mu?", "Summary log, raw OBD log and status information will be prepared in one ZIP. Create it?"), l("Oluştur", "Create")) { onCreateSupportPackage() } }
                )
                if (obdState.savedLogPath != null) Text(l("Son log", "Last log") + ": ${obdState.savedLogPath}", color = palette.textSecondary, fontSize = 11.sp, maxLines = 2)
            }
        }
    }

    confirmTitle?.let { title ->
        AlertDialog(
            onDismissRequest = { confirmTitle = null; confirmAction = null },
            title = { Text(title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(confirmMessage, color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = {
                    confirmAction?.invoke()
                    confirmTitle = null
                    confirmAction = null
                }) { Text(confirmLabel) }
            },
            dismissButton = { TextButton(onClick = { confirmTitle = null; confirmAction = null }) { Text(l("İptal", "Cancel")) } }
        )
    }
}

@Composable
private fun FuelTruthTestPanel(palette: LoganPalette, snapshot: DashboardSnapshot) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Fuel Truth Test Panel", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
            Text("Hesap: ${fuelSourceLabel(snapshot.fuelSource)} • FuelAlgorithmV3 aktif", color = palette.textSecondary, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Enjeksiyon", snapshot.injectionMg?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "mg/st", icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(92.dp))
                DataCard(palette, "Tüketim", fmt(snapshot.instantConsumption), snapshot.instantUnit, accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(92.dp))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "Pedal", snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(92.dp))
                DataCard(palette, "Hava", snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(92.dp))
            }
            Text("Fuel Truth + Smart Trip + SQL kayıt aktif.", color = palette.textSecondary, fontSize = 12.sp)
        }
    }
}

@Composable
private fun TechnicalQualityPanel(palette: LoganPalette, obdState: ObdState) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("VERİ KALİTESİ", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Loop", obdState.loopCount.toString(), palette.accent, Modifier.weight(1f))
                TechnicalStatusItem(palette, ">1 sn", obdState.slowLoopCount.toString(), if (obdState.slowLoopCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "BUS INIT", obdState.busInitCount.toString(), if (obdState.busInitCount == 0) palette.accent else palette.critical, Modifier.weight(1f))
                TechnicalStatusItem(palette, "Ham Log", if (obdState.rawEcuLogEnabled) "Açık" else "Kapalı", if (obdState.rawEcuLogEnabled) palette.warning else palette.textSecondary, Modifier.weight(1f))
            }
            Text("Ham ECU paketleri normal ekranda gösterilmez; yalnızca Geliştirici Ham Log açıkken exporta eklenir.", color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
        }
    }
}

@Composable
private fun InfoPage(palette: LoganPalette, title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

private fun fmt(value: Double?, suffix: String? = null): String {
    val base = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"
    return if (suffix == null) base else "$base $suffix"
}


private fun fuelSourceLabel(source: String): String = when (source.uppercase(Locale.US)) {
    "INJECTION" -> "Enjeksiyon"
    "CUTOFF" -> "Yakıt kesme"
    "HOLD" -> "Son veri"
    "MAF_FALLBACK" -> "Hava yedek"
    "MAP_FALLBACK" -> "Basınç yedek"
    "CRANK_GUARD" -> "Krank koruma"
    "NONE" -> "Hesap yok"
    "DEMO" -> "Demo"
    else -> if (source.isBlank()) "Bekleniyor" else source
}
