#!/usr/bin/env python3
"""Generate deterministic Digital V2 scene overlays.

The runtime never guesses road geometry. Each approved 1080x1320 scene has a
measured calibration profile. This script bakes road-edge markings, equal-world-
length centre dashes, road-only motion blur, wind frames outside the asphalt,
and model-matched contact shadows into transparent assets.

Run from the repository root:
    python3 tools/generate_digital_v2_scene_assets.py
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import math
import random

import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app" / "src" / "main" / "res" / "drawable-nodpi"
WIDTH = 1080
HEIGHT = 1320
FRAME_COUNT = 8


@dataclass(frozen=True)
class SceneCalibration:
    key: str
    background: str
    y_points: tuple[float, ...]
    left_points: tuple[float, ...]
    right_points: tuple[float, ...]
    wind_y_min: float
    wind_y_max: float
    line_alpha: int
    edge_alpha: int

    def __post_init__(self) -> None:
        if not (len(self.y_points) == len(self.left_points) == len(self.right_points)):
            raise ValueError(f"{self.key}: calibration point counts differ")
        if any(b <= a for a, b in zip(self.y_points, self.y_points[1:])):
            raise ValueError(f"{self.key}: y points must be strictly increasing")


SCENES = (
    SceneCalibration(
        key="mountain_lake",
        background="digital_v2_mountain_lake_bg.webp",
        y_points=(0.425, 0.460, 0.500, 0.550, 0.600, 0.680, 0.780, 0.900, 1.020),
        left_points=(0.635, 0.580, 0.480, 0.360, 0.230, 0.080, -0.020, -0.050, -0.070),
        right_points=(0.685, 0.720, 0.800, 0.880, 0.960, 1.020, 1.050, 1.070, 1.080),
        wind_y_min=0.445,
        wind_y_max=0.655,
        line_alpha=238,
        edge_alpha=188,
    ),
    SceneCalibration(
        key="city_day",
        background="digital_v2_city_day_bg.webp",
        y_points=(0.440, 0.470, 0.500, 0.540, 0.580, 0.640, 0.740, 0.860, 1.020),
        left_points=(0.490, 0.440, 0.350, 0.220, 0.080, -0.020, -0.080, -0.100, -0.120),
        right_points=(0.510, 0.560, 0.650, 0.780, 0.920, 1.020, 1.080, 1.100, 1.120),
        wind_y_min=0.445,
        wind_y_max=0.535,
        line_alpha=232,
        edge_alpha=150,
    ),
    SceneCalibration(
        key="city_night",
        background="digital_v2_city_night_bg.webp",
        y_points=(0.440, 0.470, 0.500, 0.540, 0.580, 0.640, 0.740, 0.860, 1.020),
        left_points=(0.490, 0.435, 0.340, 0.205, 0.060, -0.035, -0.090, -0.110, -0.130),
        right_points=(0.510, 0.565, 0.660, 0.795, 0.940, 1.035, 1.090, 1.110, 1.130),
        wind_y_min=0.445,
        wind_y_max=0.535,
        line_alpha=246,
        edge_alpha=180,
    ),
    SceneCalibration(
        key="snow_road",
        background="digital_v2_snow_road_bg.webp",
        y_points=(0.470, 0.510, 0.560, 0.620, 0.690, 0.770, 0.870, 1.020),
        left_points=(0.465, 0.420, 0.340, 0.250, 0.150, 0.060, -0.020, -0.050),
        right_points=(0.525, 0.580, 0.690, 0.790, 0.890, 0.980, 1.040, 1.070),
        wind_y_min=0.485,
        wind_y_max=0.650,
        line_alpha=246,
        edge_alpha=205,
    ),
)


class NaturalCubicSpline:
    """Small dependency-free natural cubic spline for x(y)."""

    def __init__(self, xs: tuple[float, ...], ys: tuple[float, ...]):
        self.x = np.asarray(xs, dtype=np.float64)
        self.y = np.asarray(ys, dtype=np.float64)
        n = len(xs)
        h = np.diff(self.x)
        alpha = np.zeros(n)
        for i in range(1, n - 1):
            alpha[i] = 3.0 / h[i] * (self.y[i + 1] - self.y[i]) - 3.0 / h[i - 1] * (self.y[i] - self.y[i - 1])
        l = np.ones(n)
        mu = np.zeros(n)
        z = np.zeros(n)
        for i in range(1, n - 1):
            l[i] = 2.0 * (self.x[i + 1] - self.x[i - 1]) - h[i - 1] * mu[i - 1]
            mu[i] = h[i] / l[i]
            z[i] = (alpha[i] - h[i - 1] * z[i - 1]) / l[i]
        self.a = self.y[:-1].copy()
        self.b = np.zeros(n - 1)
        self.c = np.zeros(n)
        self.d = np.zeros(n - 1)
        for j in range(n - 2, -1, -1):
            self.c[j] = z[j] - mu[j] * self.c[j + 1]
            self.b[j] = (self.y[j + 1] - self.y[j]) / h[j] - h[j] * (self.c[j + 1] + 2.0 * self.c[j]) / 3.0
            self.d[j] = (self.c[j + 1] - self.c[j]) / (3.0 * h[j])

    def __call__(self, value: float) -> float:
        i = int(np.searchsorted(self.x, value, side="right") - 1)
        i = max(0, min(i, len(self.a) - 1))
        dx = value - self.x[i]
        return float(self.a[i] + self.b[i] * dx + self.c[i] * dx * dx + self.d[i] * dx * dx * dx)


@dataclass
class SceneMath:
    calibration: SceneCalibration
    left: NaturalCubicSpline
    right: NaturalCubicSpline
    center: NaturalCubicSpline

    @classmethod
    def from_calibration(cls, c: SceneCalibration) -> "SceneMath":
        center = tuple((l + r) * 0.5 for l, r in zip(c.left_points, c.right_points))
        return cls(
            calibration=c,
            left=NaturalCubicSpline(c.y_points, c.left_points),
            right=NaturalCubicSpline(c.y_points, c.right_points),
            center=NaturalCubicSpline(c.y_points, center),
        )

    def road_width_px(self, y: float) -> float:
        return (self.right(y) - self.left(y)) * WIDTH


SCENE_MATH = tuple(SceneMath.from_calibration(c) for c in SCENES)


def save_webp(image: Image.Image, path: Path, *, lossy: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if lossy:
        image.save(path, "WEBP", quality=78, method=0, exact=True)
    else:
        image.save(path, "WEBP", lossless=True, quality=100, method=0, exact=True)


def polyline_ribbon(scene: SceneMath, selector: str, y0: float, y1: float, width_ratio: float, samples: int = 220) -> list[tuple[float, float]]:
    ys = np.linspace(y0, y1, samples)
    spline = getattr(scene, selector)
    points = [(spline(float(y)) * WIDTH, float(y) * HEIGHT, float(y)) for y in ys]
    left: list[tuple[float, float]] = []
    right: list[tuple[float, float]] = []
    for i, (x, y, yn) in enumerate(points):
        before = points[max(0, i - 1)]
        after = points[min(len(points) - 1, i + 1)]
        dx = after[0] - before[0]
        dy = after[1] - before[1]
        length = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / length, dx / length
        half_width = scene.road_width_px(yn) * width_ratio * 0.5
        left.append((x + nx * half_width, y + ny * half_width))
        right.append((x - nx * half_width, y - ny * half_width))
    return left + right[::-1]


def world_to_screen_y(scene: SceneMath, z_m: float, near_m: float = 7.0, far_m: float = 130.0) -> float:
    horizon = scene.calibration.y_points[0]
    bottom = 1.02
    reciprocal = (1.0 / z_m - 1.0 / far_m) / (1.0 / near_m - 1.0 / far_m)
    return horizon + (bottom - horizon) * reciprocal


def dash_ribbon(scene: SceneMath, near_z: float, far_z: float, width_ratio: float = 0.016, samples: int = 22) -> list[tuple[float, float]] | None:
    zs = np.linspace(far_z, near_z, samples)
    points: list[tuple[float, float, float]] = []
    for z in zs:
        y_norm = world_to_screen_y(scene, float(z))
        if scene.calibration.y_points[0] <= y_norm <= 1.02:
            points.append((scene.center(y_norm) * WIDTH, y_norm * HEIGHT, y_norm))
    if len(points) < 2:
        return None
    left: list[tuple[float, float]] = []
    right: list[tuple[float, float]] = []
    for i, (x, y, yn) in enumerate(points):
        before = points[max(0, i - 1)]
        after = points[min(len(points) - 1, i + 1)]
        dx = after[0] - before[0]
        dy = after[1] - before[1]
        length = math.hypot(dx, dy) or 1.0
        nx, ny = -dy / length, dx / length
        half_width = scene.road_width_px(yn) * width_ratio * 0.5
        left.append((x + nx * half_width, y + ny * half_width))
        right.append((x - nx * half_width, y - ny * half_width))
    return left + right[::-1]


def generate_static_road(scene: SceneMath) -> Image.Image:
    c = scene.calibration
    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")
    y0 = c.y_points[0] + 0.004
    for edge in ("left", "right"):
        outline = polyline_ribbon(scene, edge, y0, 1.0, width_ratio=0.019)
        core = polyline_ribbon(scene, edge, y0, 1.0, width_ratio=0.0115)
        draw.polygon(outline, fill=(18, 22, 26, int(c.edge_alpha * 0.48)))
        draw.polygon(core, fill=(245, 247, 250, c.edge_alpha))
    return overlay


def generate_road_frame(scene: SceneMath, frame: int) -> Image.Image:
    c = scene.calibration
    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay, "RGBA")
    near_m, far_m = 7.0, 130.0
    dash_m, gap_m = 3.0, 6.0
    cycle_m = dash_m + gap_m
    offset_m = frame / FRAME_COUNT * cycle_m
    k = -2
    while k < 40:
        start_z = near_m + k * cycle_m - offset_m
        end_z = start_z + dash_m
        if start_z > far_m:
            break
        if end_z >= near_m and start_z <= far_m:
            clipped_start = max(start_z, near_m)
            clipped_end = min(end_z, far_m)
            if clipped_end > clipped_start:
                core = dash_ribbon(scene, clipped_start, clipped_end, width_ratio=0.016)
                outline = dash_ribbon(scene, clipped_start, clipped_end, width_ratio=0.024)
                if core and outline:
                    mid = (clipped_start + clipped_end) * 0.5
                    perspective_alpha = max(0.28, min(1.0, (far_m - mid) / (far_m - near_m) * 1.35))
                    alpha = int(c.line_alpha * perspective_alpha)
                    draw.polygon(outline, fill=(18, 20, 22, int(alpha * 0.50)))
                    draw.polygon(core, fill=(248, 248, 239, alpha))
        k += 1
    return overlay


def road_mask(scene: SceneMath) -> np.ndarray:
    mask = Image.new("L", (WIDTH, HEIGHT), 0)
    draw = ImageDraw.Draw(mask)
    ys = np.linspace(scene.calibration.y_points[0], 1.02, 260)
    left = [(scene.left(float(y)) * WIDTH, float(y) * HEIGHT) for y in ys]
    right = [(scene.right(float(y)) * WIDTH, float(y) * HEIGHT) for y in ys]
    draw.polygon(left + right[::-1], fill=255)
    alpha = np.asarray(mask, dtype=np.float32) / 255.0
    y_grid = np.linspace(0.0, 1.0, HEIGHT, dtype=np.float32)[:, None]
    lower_fade = np.clip((y_grid - 0.52) / 0.28, 0.0, 1.0)
    bottom_fade = np.clip((1.0 - y_grid) / 0.045, 0.0, 1.0)
    return (alpha * lower_fade * bottom_fade * 255.0).astype(np.uint8)


def generate_road_blur(scene: SceneMath) -> Image.Image:
    # A subtle road-only softness layer. Runtime alpha is speed-controlled;
    # lane markings remain sharp because they are rendered above this asset.
    background = Image.open(RES / scene.calibration.background).convert("RGB")
    softened = background.filter(ImageFilter.GaussianBlur(radius=2.2)).convert("RGBA")
    softened.putalpha(Image.fromarray(road_mask(scene), "L"))
    return softened


def generate_wind_frame(scene: SceneMath, frame: int) -> Image.Image:
    c = scene.calibration
    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    phase = frame / FRAME_COUNT
    for side in (-1, 1):
        for index in range(6):
            local = (index / 6.0 + phase * 0.92 + (0.08 if side < 0 else 0.17)) % 1.0
            y_norm = c.wind_y_min + (c.wind_y_max - c.wind_y_min) * (local ** 1.12)
            edge_x = scene.left(y_norm) if side < 0 else scene.right(y_norm)
            start_x = edge_x + side * (0.020 + 0.018 * local)
            length = 0.075 + 0.090 * local
            end_x = start_x + side * length
            end_y = y_norm + 0.007 + 0.012 * local
            if side < 0:
                start_x = max(0.018, start_x)
                end_x = max(-0.03, end_x)
            else:
                start_x = min(0.982, start_x)
                end_x = min(1.03, end_x)
            points: list[tuple[float, float]] = []
            for t in np.linspace(0.0, 1.0, 36):
                x = (start_x + (end_x - start_x) * t) * WIDTH
                bow = math.sin(t * math.pi) * 0.004 * side
                y = (y_norm + (end_y - y_norm) * t + bow) * HEIGHT
                points.append((x, y))
            life = math.sin(math.pi * local) ** 2
            alpha = int((125 + 105 * local) * life)
            width = max(2, int(2.2 + 3.2 * local))
            glow = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
            glow_draw = ImageDraw.Draw(glow, "RGBA")
            glow_draw.line(points, fill=(185, 220, 255, int(alpha * 0.35)), width=width * 5, joint="curve")
            glow = glow.filter(ImageFilter.GaussianBlur(radius=3.2 + 1.8 * local))
            overlay = Image.alpha_composite(overlay, glow)
            core_draw = ImageDraw.Draw(overlay, "RGBA")
            core_draw.line(points, fill=(248, 252, 255, alpha), width=width, joint="curve")
    return overlay


def generate_ground_shadow(key: str, wheel_left: float, wheel_right: float) -> Image.Image:
    width, height = 1014, 260
    result = Image.new("RGBA", (width, height), (0, 0, 0, 0))

    def add_ellipse(box: tuple[int, int, int, int], alpha: int, blur: float) -> None:
        mask = Image.new("L", (width, height), 0)
        draw = ImageDraw.Draw(mask)
        draw.ellipse(box, fill=alpha)
        mask = mask.filter(ImageFilter.GaussianBlur(radius=blur))
        layer = Image.new("RGBA", (width, height), (0, 0, 0, 0))
        layer.putalpha(mask)
        result.alpha_composite(layer)

    add_ellipse((145, 48, 869, 230), 125, 29)
    for centre in (wheel_left, wheel_right):
        x = int(centre * width)
        add_ellipse((x - 92, 82, x + 92, 236), 198, 18)
        add_ellipse((x - 66, 127, x + 66, 226), 228, 9)
    save_webp(result, RES / f"digital_v2_ground_shadow_{key}.webp")
    return result


def main() -> None:
    generate_ground_shadow("logan1", wheel_left=0.165, wheel_right=0.835)
    generate_ground_shadow("logan3", wheel_left=0.155, wheel_right=0.845)

    for scene in SCENE_MATH:
        key = scene.calibration.key
        save_webp(generate_static_road(scene), RES / f"digital_v2_{key}_road_static.webp")
        blur = generate_road_blur(scene).resize((WIDTH // 2, HEIGHT // 2), Image.Resampling.LANCZOS)
        save_webp(blur, RES / f"digital_v2_{key}_road_blur.webp", lossy=True)
        for frame in range(FRAME_COUNT):
            save_webp(generate_road_frame(scene, frame), RES / f"digital_v2_{key}_road_{frame:02d}.webp")
            wind = generate_wind_frame(scene, frame).resize((WIDTH // 2, HEIGHT // 2), Image.Resampling.LANCZOS)
            save_webp(wind, RES / f"digital_v2_{key}_wind_{frame:02d}.webp")
        print(f"generated {key}")


if __name__ == "__main__":
    main()
