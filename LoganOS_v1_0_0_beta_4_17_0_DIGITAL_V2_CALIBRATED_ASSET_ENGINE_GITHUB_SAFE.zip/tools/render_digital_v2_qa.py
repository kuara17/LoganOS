#!/usr/bin/env python3
"""Render a deterministic QA montage from the exact release scene assets."""
from pathlib import Path
from PIL import Image, ImageEnhance

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res/drawable-nodpi"
OUT = ROOT / "digital_v2_qa"
OUT.mkdir(exist_ok=True)

SCENES = {
    "mountain_lake": dict(bg="digital_v2_mountain_lake_bg.webp", x=.700, y=.905, visible=.350, heading=1.20, tone=(.93,.96,.99), shadow=.98),
    "city_day": dict(bg="digital_v2_city_day_bg.webp", x=.700, y=.905, visible=.340, heading=0.0, tone=(.96,.96,.96), shadow=.96),
    "city_night": dict(bg="digital_v2_city_night_bg.webp", x=.700, y=.905, visible=.340, heading=0.0, tone=(.76,.70,.64), shadow=.90),
    "snow_road": dict(bg="digital_v2_snow_road_bg.webp", x=.700, y=.905, visible=.350, heading=-.50, tone=(.90,.95,1.02), shadow=.98),
}

vehicle = Image.open(RES / "loganos_logan3_rear_cherry_red.webp").convert("RGBA")
shadow = Image.open(RES / "digital_v2_ground_shadow_logan3.webp").convert("RGBA")


def tone_vehicle(image: Image.Image, scales: tuple[float,float,float]) -> Image.Image:
    r,g,b,a = image.split()
    r = r.point(lambda v: max(0,min(255,int(v*scales[0]))))
    g = g.point(lambda v: max(0,min(255,int(v*scales[1]))))
    b = b.point(lambda v: max(0,min(255,int(v*scales[2]))))
    return Image.merge("RGBA",(r,g,b,a))

for key, cfg in SCENES.items():
    stage = Image.open(RES / cfg["bg"]).convert("RGBA")
    blur = Image.open(RES / f"digital_v2_{key}_road_blur.webp").convert("RGBA").resize(stage.size, Image.Resampling.LANCZOS)
    blur.putalpha(blur.getchannel("A").point(lambda v: int(v*.22)))
    stage.alpha_composite(blur)
    stage.alpha_composite(Image.open(RES / f"digital_v2_{key}_road_static.webp").convert("RGBA"))
    stage.alpha_composite(Image.open(RES / f"digital_v2_{key}_road_03.webp").convert("RGBA"))
    wind = Image.open(RES / f"digital_v2_{key}_wind_03.webp").convert("RGBA").resize(stage.size, Image.Resampling.LANCZOS)
    wind.putalpha(wind.getchannel("A").point(lambda v: int(v*.82)))
    stage.alpha_composite(wind)

    asset_width = int(1080 * (cfg["visible"] / .888))
    asset_height = int(asset_width * .86)
    shadow_height = int(asset_width * 260 / 1014)
    sh = shadow.resize((asset_width, shadow_height), Image.Resampling.LANCZOS)
    sh.putalpha(sh.getchannel("A").point(lambda v: int(v*cfg["shadow"])))
    sx = int(cfg["x"]*1080 - asset_width/2)
    sy = int(cfg["y"]*1320 - shadow_height*.56)
    stage.alpha_composite(sh,(sx,sy))

    car = tone_vehicle(vehicle.resize((asset_width,asset_height),Image.Resampling.LANCZOS),cfg["tone"])
    if cfg["heading"]:
        car = car.rotate(-cfg["heading"],resample=Image.Resampling.BICUBIC,expand=True)
    cx = int(cfg["x"]*1080 - car.width/2)
    cy = int(cfg["y"]*1320 - asset_height*.906)
    stage.alpha_composite(car,(cx,cy))
    stage.convert("RGB").save(OUT / f"{key}.jpg",quality=92)

# 2x2 montage without external tools
thumbs=[Image.open(OUT/f"{key}.jpg").resize((540,660),Image.Resampling.LANCZOS) for key in SCENES]
montage=Image.new("RGB",(1088,1328),(238,238,238))
for i,img in enumerate(thumbs):
    montage.paste(img,((i%2)*544,(i//2)*664))
montage.save(OUT/"digital_v2_beta_4_17_0_validation.jpg",quality=92)
print(OUT/"digital_v2_beta_4_17_0_validation.jpg")
