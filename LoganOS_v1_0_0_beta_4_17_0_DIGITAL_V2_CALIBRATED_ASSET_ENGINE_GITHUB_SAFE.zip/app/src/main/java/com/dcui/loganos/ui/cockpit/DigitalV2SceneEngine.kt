package com.dcui.loganos.ui.cockpit

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.dcui.loganos.R
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.ui.components.rememberScenicMotionPhases
import kotlin.math.PI
import kotlin.math.sin

/**
 * Digital V2 uses a fixed 1080x1320 stage. Road geometry is calibrated once
 * against each approved background and baked into transparent frame assets by
 * tools/generate_digital_v2_scene_assets.py. Runtime rendering only scales the
 * complete stage uniformly, so screen size changes cannot separate the road,
 * wind, shadow or vehicle.
 */
internal const val DIGITAL_V2_STAGE_ASPECT_RATIO = 1080f / 1320f
internal const val DIGITAL_V2_MOTION_FRAME_COUNT = 8

internal enum class DigitalV2VehicleTone {
    Mountain,
    Day,
    Night,
    Snow
}

internal data class DigitalV2VehiclePose(
    val centerX: Float,
    val tireContactY: Float,
    /** Visible body width, not transparent asset-canvas width. */
    val visibleWidthRatio: Float,
    val headingDegrees: Float,
    val heightToAssetWidth: Float = 0.86f,
    val shadowContactAnchorYRatio: Float = 0.56f,
    val shadowAlpha: Float,
    val tone: DigitalV2VehicleTone
)

internal data class DigitalV2SceneSpec(
    val backgroundRes: Int,
    val roadStaticRes: Int,
    val roadBlurRes: Int,
    val roadFrames: IntArray,
    val windFrames: IntArray,
    val vehiclePose: DigitalV2VehiclePose,
    val roadBlurMaxAlpha: Float,
    val windMaxAlpha: Float,
    val stageAspectRatio: Float = DIGITAL_V2_STAGE_ASPECT_RATIO
) {
    init {
        require(roadFrames.size == DIGITAL_V2_MOTION_FRAME_COUNT)
        require(windFrames.size == DIGITAL_V2_MOTION_FRAME_COUNT)
        require(vehiclePose.centerX in 0f..1f)
        require(vehiclePose.tireContactY in 0f..1f)
        require(vehiclePose.visibleWidthRatio in 0.25f..0.45f)
        require(roadBlurMaxAlpha in 0f..0.45f)
        require(windMaxAlpha in 0f..1f)
    }

    fun frameIndex(roadPhase: Float): Int =
        ((roadPhase.coerceIn(0f, 0.999999f) * DIGITAL_V2_MOTION_FRAME_COUNT).toInt())
            .coerceIn(0, DIGITAL_V2_MOTION_FRAME_COUNT - 1)
}

internal val DigitalV2MountainLakeSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_mountain_lake_bg,
    roadStaticRes = R.drawable.digital_v2_mountain_lake_road_static,
    roadBlurRes = R.drawable.digital_v2_mountain_lake_road_blur,
    roadFrames = intArrayOf(
        R.drawable.digital_v2_mountain_lake_road_00,
        R.drawable.digital_v2_mountain_lake_road_01,
        R.drawable.digital_v2_mountain_lake_road_02,
        R.drawable.digital_v2_mountain_lake_road_03,
        R.drawable.digital_v2_mountain_lake_road_04,
        R.drawable.digital_v2_mountain_lake_road_05,
        R.drawable.digital_v2_mountain_lake_road_06,
        R.drawable.digital_v2_mountain_lake_road_07
    ),
    windFrames = intArrayOf(
        R.drawable.digital_v2_mountain_lake_wind_00,
        R.drawable.digital_v2_mountain_lake_wind_01,
        R.drawable.digital_v2_mountain_lake_wind_02,
        R.drawable.digital_v2_mountain_lake_wind_03,
        R.drawable.digital_v2_mountain_lake_wind_04,
        R.drawable.digital_v2_mountain_lake_wind_05,
        R.drawable.digital_v2_mountain_lake_wind_06,
        R.drawable.digital_v2_mountain_lake_wind_07
    ),
    vehiclePose = DigitalV2VehiclePose(
        centerX = 0.700f,
        tireContactY = 0.905f,
        visibleWidthRatio = 0.350f,
        headingDegrees = 1.20f,
        shadowAlpha = 0.98f,
        tone = DigitalV2VehicleTone.Mountain
    ),
    roadBlurMaxAlpha = 0.24f,
    windMaxAlpha = 1.0f
)

internal val DigitalV2CityDaySceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_day_bg,
    roadStaticRes = R.drawable.digital_v2_city_day_road_static,
    roadBlurRes = R.drawable.digital_v2_city_day_road_blur,
    roadFrames = intArrayOf(
        R.drawable.digital_v2_city_day_road_00,
        R.drawable.digital_v2_city_day_road_01,
        R.drawable.digital_v2_city_day_road_02,
        R.drawable.digital_v2_city_day_road_03,
        R.drawable.digital_v2_city_day_road_04,
        R.drawable.digital_v2_city_day_road_05,
        R.drawable.digital_v2_city_day_road_06,
        R.drawable.digital_v2_city_day_road_07
    ),
    windFrames = intArrayOf(
        R.drawable.digital_v2_city_day_wind_00,
        R.drawable.digital_v2_city_day_wind_01,
        R.drawable.digital_v2_city_day_wind_02,
        R.drawable.digital_v2_city_day_wind_03,
        R.drawable.digital_v2_city_day_wind_04,
        R.drawable.digital_v2_city_day_wind_05,
        R.drawable.digital_v2_city_day_wind_06,
        R.drawable.digital_v2_city_day_wind_07
    ),
    vehiclePose = DigitalV2VehiclePose(
        centerX = 0.700f,
        tireContactY = 0.905f,
        visibleWidthRatio = 0.340f,
        headingDegrees = 0.0f,
        shadowAlpha = 0.96f,
        tone = DigitalV2VehicleTone.Day
    ),
    roadBlurMaxAlpha = 0.22f,
    windMaxAlpha = 1.0f
)

internal val DigitalV2CityNightSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_city_night_bg,
    roadStaticRes = R.drawable.digital_v2_city_night_road_static,
    roadBlurRes = R.drawable.digital_v2_city_night_road_blur,
    roadFrames = intArrayOf(
        R.drawable.digital_v2_city_night_road_00,
        R.drawable.digital_v2_city_night_road_01,
        R.drawable.digital_v2_city_night_road_02,
        R.drawable.digital_v2_city_night_road_03,
        R.drawable.digital_v2_city_night_road_04,
        R.drawable.digital_v2_city_night_road_05,
        R.drawable.digital_v2_city_night_road_06,
        R.drawable.digital_v2_city_night_road_07
    ),
    windFrames = intArrayOf(
        R.drawable.digital_v2_city_night_wind_00,
        R.drawable.digital_v2_city_night_wind_01,
        R.drawable.digital_v2_city_night_wind_02,
        R.drawable.digital_v2_city_night_wind_03,
        R.drawable.digital_v2_city_night_wind_04,
        R.drawable.digital_v2_city_night_wind_05,
        R.drawable.digital_v2_city_night_wind_06,
        R.drawable.digital_v2_city_night_wind_07
    ),
    vehiclePose = DigitalV2VehiclePose(
        centerX = 0.700f,
        tireContactY = 0.905f,
        visibleWidthRatio = 0.340f,
        headingDegrees = 0.0f,
        shadowAlpha = 0.90f,
        tone = DigitalV2VehicleTone.Night
    ),
    roadBlurMaxAlpha = 0.25f,
    windMaxAlpha = 1.0f
)

internal val DigitalV2SnowRoadSceneSpec = DigitalV2SceneSpec(
    backgroundRes = R.drawable.digital_v2_snow_road_bg,
    roadStaticRes = R.drawable.digital_v2_snow_road_road_static,
    roadBlurRes = R.drawable.digital_v2_snow_road_road_blur,
    roadFrames = intArrayOf(
        R.drawable.digital_v2_snow_road_road_00,
        R.drawable.digital_v2_snow_road_road_01,
        R.drawable.digital_v2_snow_road_road_02,
        R.drawable.digital_v2_snow_road_road_03,
        R.drawable.digital_v2_snow_road_road_04,
        R.drawable.digital_v2_snow_road_road_05,
        R.drawable.digital_v2_snow_road_road_06,
        R.drawable.digital_v2_snow_road_road_07
    ),
    windFrames = intArrayOf(
        R.drawable.digital_v2_snow_road_wind_00,
        R.drawable.digital_v2_snow_road_wind_01,
        R.drawable.digital_v2_snow_road_wind_02,
        R.drawable.digital_v2_snow_road_wind_03,
        R.drawable.digital_v2_snow_road_wind_04,
        R.drawable.digital_v2_snow_road_wind_05,
        R.drawable.digital_v2_snow_road_wind_06,
        R.drawable.digital_v2_snow_road_wind_07
    ),
    vehiclePose = DigitalV2VehiclePose(
        centerX = 0.700f,
        tireContactY = 0.905f,
        visibleWidthRatio = 0.350f,
        headingDegrees = -0.50f,
        shadowAlpha = 0.98f,
        tone = DigitalV2VehicleTone.Snow
    ),
    roadBlurMaxAlpha = 0.23f,
    windMaxAlpha = 1.0f
)

internal fun digitalV2SceneSpec(scene: DigitalV2Scene): DigitalV2SceneSpec = when (scene) {
    DigitalV2Scene.MountainLake -> DigitalV2MountainLakeSceneSpec
    DigitalV2Scene.CityDay -> DigitalV2CityDaySceneSpec
    DigitalV2Scene.CityNight -> DigitalV2CityNightSceneSpec
    DigitalV2Scene.SnowRoad -> DigitalV2SnowRoadSceneSpec
}

internal data class DigitalV2SceneMotion(
    val moving: Boolean,
    val roadPhase: Float,
    val motionStrength: Float,
    val suspensionLift: Float,
    val swayWave: Float
)

@Composable
internal fun rememberDigitalV2SceneMotion(
    speedKmh: Int?,
    enabled: Boolean
): DigitalV2SceneMotion {
    val currentSpeed = speedKmh ?: 0
    val scenic = rememberScenicMotionPhases(speedKmh = speedKmh, enabled = enabled)
    val moving = enabled && currentSpeed >= 5
    val motionStrength = when {
        !moving -> 0f
        currentSpeed < 20 -> ((currentSpeed - 5f) / 15f) * 0.34f
        currentSpeed < 50 -> 0.34f + ((currentSpeed - 20f) / 30f) * 0.32f
        currentSpeed < 90 -> 0.66f + ((currentSpeed - 50f) / 40f) * 0.24f
        else -> 0.90f + ((currentSpeed - 90f) / 60f) * 0.10f
    }.coerceIn(0f, 1f)

    val angle = scenic.dynamicsTime * 2f * PI.toFloat()
    val bodyWave = if (moving) {
        val primary = sin(angle.toDouble()).toFloat()
        val secondary = 0.30f * sin((angle * 2.70f + 0.62f).toDouble()).toFloat()
        val settle = 0.14f * sin((angle * 0.57f + 1.38f).toDouble()).toFloat()
        (primary + secondary + settle) / 1.44f
    } else 0f
    val microRoad = if (moving) {
        val coarse = sin((angle * 12f + 0.20f).toDouble()).toFloat()
        val fine = sin((angle * 18.40f + 1.15f).toDouble()).toFloat()
        (coarse * 0.68f + fine * 0.32f) * (0.045f + 0.035f * motionStrength)
    } else 0f
    val sway = if (moving) {
        0.68f * sin((angle * 0.71f + 0.85f).toDouble()).toFloat() +
            0.22f * sin((angle * 1.93f + 2.10f).toDouble()).toFloat() +
            0.10f * sin((angle * 4.40f + 0.22f).toDouble()).toFloat()
    } else 0f

    return DigitalV2SceneMotion(
        moving = moving,
        roadPhase = scenic.roadPhase,
        motionStrength = motionStrength,
        suspensionLift = (bodyWave + microRoad).coerceIn(-1f, 1f),
        swayWave = sway
    )
}

@Composable
internal fun DigitalV2RoadLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    val frameIndex = if (motion.moving) spec.frameIndex(motion.roadPhase) else 0
    Box(modifier = modifier) {
        if (motion.moving && motion.motionStrength > 0.01f) {
            Image(
                painter = painterResource(spec.roadBlurRes),
                contentDescription = null,
                contentScale = ContentScale.FillBounds,
                modifier = Modifier
                    .matchParentSize()
                    .alpha(spec.roadBlurMaxAlpha * motion.motionStrength)
            )
        }
        Image(
            painter = painterResource(spec.roadStaticRes),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.matchParentSize()
        )
        Image(
            painter = painterResource(spec.roadFrames[frameIndex]),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.matchParentSize()
        )
    }
}

@Composable
internal fun DigitalV2WindLayer(
    spec: DigitalV2SceneSpec,
    motion: DigitalV2SceneMotion,
    modifier: Modifier = Modifier
) {
    if (!motion.moving || motion.motionStrength <= 0.02f) return
    val frameIndex = spec.frameIndex(motion.roadPhase)
    Image(
        painter = painterResource(spec.windFrames[frameIndex]),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = modifier.alpha(
            spec.windMaxAlpha * (0.55f + 0.45f * motion.motionStrength)
        )
    )
}

@Composable
internal fun DigitalV2CalibrationOverlay(
    spec: DigitalV2SceneSpec,
    enabled: Boolean,
    modifier: Modifier = Modifier
) {
    if (!enabled) return
    Canvas(modifier = modifier) {
        repeat(11) { index ->
            val x = size.width * index / 10f
            val y = size.height * index / 10f
            drawLine(Color.Red.copy(alpha = 0.34f), Offset(x, 0f), Offset(x, size.height), 1f)
            drawLine(Color.Yellow.copy(alpha = 0.34f), Offset(0f, y), Offset(size.width, y), 1f)
        }
        val pose = spec.vehiclePose
        drawCircle(
            color = Color.Magenta,
            radius = 6.dp.toPx(),
            center = Offset(pose.centerX * size.width, pose.tireContactY * size.height)
        )
        drawLine(
            color = Color.Green,
            start = Offset(pose.centerX * size.width, pose.tireContactY * size.height),
            end = Offset(pose.centerX * size.width, 0f),
            strokeWidth = 2.dp.toPx()
        )
    }
}
