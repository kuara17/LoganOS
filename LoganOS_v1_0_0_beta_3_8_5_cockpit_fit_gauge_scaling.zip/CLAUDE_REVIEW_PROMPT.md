# LoganOS v1.0.0-beta.3.8.5 review prompt

Please review this Android/Kotlin/Jetpack Compose project after the cockpit fit and gauge scaling fix.

Focus areas:
- Confirm versionName is `1.0.0-beta.3.8.5` and versionCode is `100000385`.
- Confirm DashboardScreen.kt compiles and required imports are present.
- Confirm portrait cockpit no longer requires scrolling/pulling down on S23 FE-class displays to see the main 8 metrics.
- Confirm metric labels such as Ortalama, Sürüş Maliyeti, Hararet / Fan, and Sürüş Süresi are not squeezed by oversized icon bubbles.
- Confirm SpeedGauge uses bounded drawing and the five gauge styles remain separate: Digital C, Sport C, Classic OEM A, Minimal C, RS Performance D.
- Confirm no regressions in OBD, FuelAlgorithmV3, TripComputer, AC_FAST, CUTOFF, calibration, or cranking logic.
