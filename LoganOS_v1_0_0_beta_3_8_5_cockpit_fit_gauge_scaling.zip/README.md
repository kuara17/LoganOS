# LoganOS v1.0.0-beta.3.8.5

Cockpit fit and gauge scaling fix for the 3.8.x visual redesign.

