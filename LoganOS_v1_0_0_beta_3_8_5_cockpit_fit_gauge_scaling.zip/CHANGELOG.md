# LoganOS v1.0.0-beta.3.8.5

## v1.0.0-beta.3.8.5 - Cockpit Fit and Gauge Scaling

- Tightened portrait cockpit layout so the main gauge and 8 metrics fit without needing to pull the screen down on S23 FE-class displays.
- Reduced excessive bottom padding inside the cockpit list.
- Rebalanced metric icon bubbles so icons stay visible but labels/units no longer get squeezed.
- Made SpeedGauge draw inside its available bounds instead of overflowing fixed canvas sizes.
- Reduced speed gauge/readout sizes for compact preview and cockpit heights.
- Preserved the real per-style gauge components introduced in 3.8.4.

