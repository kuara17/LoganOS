# LoganOS beta.4.20.10 — Source audit

## Digital V2 asset strategy
- Exactly 48 baked Digital V2 WebP assets are present: 4 scenes × 2 Logan models × 6 colors.
- `digitalV2CompositeRes()` resolves the final bitmap directly from scene/model/color.
- Separate Digital V2 vehicle, road-map, cast-shadow and contact-shadow resource IDs are disabled.
- Legacy Digital V2 background/road/shadow files were removed.
- OpenGL uses center-crop texture coordinates so the approved source images are not stretched.
- Settings preview and scene tiles use the same baked resource resolver as the live cockpit.

## Cleanup / size audit
- Removed unreferenced legacy Ghost scene/horizon/vehicle resources (about 2.56 MiB uncompressed).
- Removed obsolete beta.4.20.1–4.20.8 internal audit/review notes and old Ghost-only helper scripts.
- Restored the two validation scripts that current GitHub Actions workflows call: `tools/validate_release.py` and `tools/preflight_source.py`.
- Five active large opaque WebP scenery resources were re-encoded at quality 90 with unchanged dimensions; this removes several MiB of lossless-source overhead while keeping high visual quality.
- Shared Logan car assets and non-Digital-V2 road assets were retained because they are still referenced by Classic/Ghost/Premium/vehicle-selection code. Removing them would break resource compilation or other cockpits.

## Validation
- 48/48 baked asset mapping: PASS.
- Missing `R.drawable` references: none.
- Legacy Digital V2 background/road/shadow API references: none.
- Legacy Digital V2 resource files: none.
- Signing keys/APK/AAB included in source: none.
- Individual source file >20 MiB: none.
- ZIP integrity test: PASS.

## Package size
- beta.4.20.8 source ZIP: about 22.28 MiB compressed.
- beta.4.20.10 source ZIP after adding 48 final scene assets and cleanup: about 19.6 MiB compressed.
- Target: under 25 MiB — PASS with roughly 5.4 MiB headroom.

Full Gradle/APK compilation is delegated to the existing GitHub Actions Gradle 8.10.2 / JDK 17 workflow; this sandbox does not contain a local Gradle installation.
