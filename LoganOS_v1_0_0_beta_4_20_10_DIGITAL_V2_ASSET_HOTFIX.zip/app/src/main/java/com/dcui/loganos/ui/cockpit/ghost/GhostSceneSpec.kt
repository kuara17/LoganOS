package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

@Immutable
data class GhostPoint(val x: Float, val y: Float)

@Immutable
data class GhostRect(val x: Float, val y: Float, val width: Float, val height: Float) {
    val centerX: Float get() = x + width / 2f
    val centerY: Float get() = y + height / 2f
}

enum class GhostLayoutMode { Single, Dual }

@Immutable
data class GhostRoadSpec(
    val vanishingPoint: GhostPoint,
    val topY: Float,
    val fadeVisibleY: Float,
    val bottomY: Float,
    val topHalfWidth: Float,
    val bottomHalfWidth: Float,
    val clipLeft: Float = 0f,
    val clipRight: Float = GhostSceneSpec.DESIGN_WIDTH
)

@Immutable
data class GhostHorizonSpec(
    val center: GhostPoint,
    val outerWidth: Float,
    val outerHeight: Float,
    val middleWidth: Float,
    val middleHeight: Float,
    val coreWidth: Float,
    val coreHeight: Float,
    val color: Color
)

@Immutable
data class GhostVehiclePlacement(
    val centerX: Float,
    val tireContactY: Float,
    val visibleWidth: Float,
    val shadowWidthMultiplier: Float,
    val shadowYOffset: Float
)

@Immutable
data class GhostGaugeSpec(
    val bounds: GhostRect,
    val center: GhostPoint,
    val radius: Float
)

@Immutable
data class GhostMetricSpec(
    val bounds: GhostRect,
    val iconSize: Float,
    val iconGap: Float
)

@Immutable
data class GhostSingleOverlaySpec(
    val gauge: GhostGaugeSpec,
    val speedValue: GhostRect,
    val speedUnit: GhostRect,
    val rpmValue: GhostRect,
    val coolant: GhostRect,
    val average: GhostMetricSpec,
    val instant: GhostMetricSpec,
    val status: GhostRect
)

@Immutable
data class GhostDualOverlaySpec(
    val speedGauge: GhostGaugeSpec,
    val rpmGauge: GhostGaugeSpec,
    val speedValue: GhostRect,
    val speedUnit: GhostRect,
    val rpmValue: GhostRect,
    val rpmUnit: GhostRect,
    val instantHeader: GhostMetricSpec,
    val instantValue: GhostRect,
    val instantUnit: GhostRect,
    val averageHeader: GhostMetricSpec,
    val averageValue: GhostRect,
    val averageUnit: GhostRect,
    val coolant: GhostRect,
    val status: GhostRect
)

@Immutable
data class GhostSceneSpec(
    val mode: GhostLayoutMode,
    val road: GhostRoadSpec,
    val horizon: GhostHorizonSpec,
    val vehicle: GhostVehiclePlacement,
    val single: GhostSingleOverlaySpec? = null,
    val dual: GhostDualOverlaySpec? = null
) {
    companion object {
        // 4.20.3: cockpit-only design surface. Bottom navigation and system bars are
        // deliberately outside this coordinate space.
        const val DESIGN_WIDTH = 1600f
        const val DESIGN_HEIGHT = 700f
    }
}
