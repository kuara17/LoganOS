package com.dcui.loganos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.Brand
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.FuelType
import com.dcui.loganos.model.VehicleProfileSupport
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.DaciaBrandLogo
import com.dcui.loganos.ui.components.GaugePreview
import com.dcui.loganos.ui.components.LoganSetupLogo
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.RenaultBrandLogo
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun SetupWizard(
    palette: LoganPalette,
    initial: LoganSettings,
    onComplete: (LoganSettings) -> Unit
) {
    var step by remember { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(initial) }
    var languageSelected by remember { mutableStateOf(false) }
    var brandSelected by remember { mutableStateOf(false) }
    var vehicleSelected by remember { mutableStateOf(false) }
    var engineSelected by remember { mutableStateOf(false) }
    var deviceSelected by remember { mutableStateOf(false) }
    var gaugeSelected by remember { mutableStateOf(false) }
    var accentSelected by remember { mutableStateOf(false) }
    val total = 8
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .safeDrawingPadding()
            .padding(horizontal = 18.dp, vertical = 14.dp)
    ) {
        WizardHeader(palette, step, total, settings.language)
        Spacer(Modifier.height(12.dp))
        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxSize()) {
                item {
                    when (step) {
                        0 -> LanguageStep(palette, if (languageSelected) settings.language else null) {
                            languageSelected = true
                            settings = settings.copy(language = it)
                        }
                        1 -> BrandStep(palette, settings.language, if (brandSelected) settings.brand else null) {
                            brandSelected = true
                            vehicleSelected = false
                            engineSelected = false
                            settings = settings.copy(brand = it, vehicleModel = "", engine = "")
                        }
                        2 -> VehicleStep(palette, settings.language, settings.brand, if (vehicleSelected) settings.vehicleModel else null) {
                            vehicleSelected = true
                            engineSelected = false
                            settings = settings.copy(vehicleModel = it, engine = "")
                        }
                        3 -> EngineStep(
                            palette = palette,
                            language = settings.language,
                            selected = if (engineSelected) settings.engine else null,
                            vehicleModel = settings.vehicleModel,
                            settings = settings,
                            onSelect = { engine, fuelType, support ->
                                engineSelected = true
                                settings = if (fuelType == FuelType.Petrol) {
                                    settings.copy(
                                        engine = engine,
                                        fuelType = fuelType,
                                        profileSupport = support,
                                        engineCodeText = "",
                                        engineDisplacementCcText = "",
                                        enginePowerHpText = "",
                                        cylinderCount = 4,
                                        experimentalProfileAccepted = true,
                                        fuelCalibrationEnabled = false
                                    )
                                } else {
                                    settings.copy(
                                        engine = engine,
                                        fuelType = fuelType,
                                        profileSupport = support,
                                        engineCodeText = "K9K",
                                        engineDisplacementCcText = "1461",
                                        enginePowerHpText = if (engine.contains("70")) "70" else "68",
                                        cylinderCount = 4,
                                        experimentalProfileAccepted = support == VehicleProfileSupport.Experimental
                                    )
                                }
                            },
                            onDetailsChange = { settings = it }
                        )
                        4 -> DeviceStep(palette, settings.language, if (deviceSelected) settings.deviceMode else null) {
                            deviceSelected = true
                            settings = settings.copy(deviceMode = it)
                        }
                        5 -> GaugeStep(palette, settings.language, if (gaugeSelected) settings.gaugeStyle else null) {
                            gaugeSelected = true
                            settings = settings.copy(gaugeStyle = it)
                        }
                        6 -> AccentStep(palette, settings.language, if (accentSelected) settings.accentColor else null) {
                            accentSelected = true
                            settings = settings.copy(accentColor = it)
                        }
                        7 -> DataNoticeStep(palette, settings.language, settings.disclaimerAccepted) { settings = settings.copy(disclaimerAccepted = it) }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        val canProceed = when (step) {
            0 -> languageSelected
            1 -> brandSelected
            2 -> vehicleSelected
            3 -> engineSelected && (
                settings.fuelType != FuelType.Petrol ||
                    (settings.modelYearText.toIntOrNull() in 1980..2100 &&
                        settings.engineDisplacementCcText.toIntOrNull() in 500..10000 &&
                        settings.enginePowerHpText.toIntOrNull() in 20..2000 &&
                        settings.cylinderCount in 1..12)
                )
            4 -> deviceSelected
            5 -> gaugeSelected
            6 -> accentSelected
            7 -> settings.disclaimerAccepted
            else -> false
        }
        WizardButtons(
            palette = palette,
            canBack = step > 0,
            canNext = canProceed,
            backText = if (settings.language == AppLanguage.English) "Back" else "Geri",
            nextText = if (step == 7) { if (settings.language == AppLanguage.English) "Finish Setup" else "Kurulumu Tamamla" } else { if (settings.language == AppLanguage.English) "Continue" else if (step == 0) "Devam / Continue" else "Devam" },
            onBack = { if (step > 0) step-- },
            onNext = { if (step < 7) step++ else onComplete(settings.copy(setupCompleted = true)) }
        )
    }
}

@Composable
private fun WizardHeader(palette: LoganPalette, step: Int, total: Int, language: AppLanguage) {
    Column {
        Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            LoganSetupLogo(modifier = Modifier.height(74.dp).fillMaxWidth(.72f))
        }
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Text(if (language == AppLanguage.English) "Setup" else "Kurulum", color = palette.textSecondary, fontSize = 13.sp)
            Text("${step + 1} / $total", color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(7.dp))
        LinearProgressIndicator(
            progress = { (step + 1) / total.toFloat() },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(6.dp)),
            color = palette.accent,
            trackColor = palette.line
        )
    }
}

@Composable
private fun LanguageStep(palette: LoganPalette, selected: AppLanguage?, onSelect: (AppLanguage) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        StepTitle(palette, "Dil Seçimi / Language Selection", "Uygulama dilini seçin. / Choose the app language.")
        SelectRow(palette, "Türkçe", null, selected == AppLanguage.Turkish) { onSelect(AppLanguage.Turkish) }
        SelectRow(palette, "English", null, selected == AppLanguage.English) { onSelect(AppLanguage.English) }
        if (selected == AppLanguage.English) {
            OemCard(palette) {
                Text(
                    "English translation is AI-assisted and may contain wording issues. It will be improved over time.",
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 19.sp
                )
            }
        }
    }
}


@Composable
private fun BrandStep(palette: LoganPalette, language: AppLanguage, selected: Brand?, onSelect: (Brand) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, if (language == AppLanguage.English) "Vehicle Brand" else "Araç Markası", if (language == AppLanguage.English) "Welcome to LoganOS. Start by choosing the vehicle brand." else "LoganOS'a hoş geldiniz. İlk olarak araç markasını seçin.")
        BrandCard(palette, Brand.Dacia, selected == Brand.Dacia, enabled = true) { onSelect(Brand.Dacia) }
        BrandCard(palette, Brand.Renault, selected == Brand.Renault, enabled = false) { }
        Text(if (language == AppLanguage.English) "Dacia profiles are active; Renault profiles are locked until verified." else "Dacia profilleri aktif; Renault profilleri henüz doğrulanmadığı için kilitli.", color = palette.textSecondary, fontSize = 12.sp)
    }
}

@Composable
private fun BrandCard(palette: LoganPalette, brand: Brand, selected: Boolean, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected && enabled) palette.accent.copy(alpha = .08f) else palette.surface)
            .border(1.dp, if (selected && enabled) palette.accent else palette.line, shape)
            .then(if (enabled) Modifier.clickable { onClick() } else Modifier)
            .alpha(if (enabled) 1f else .48f)
            .padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Box(modifier = Modifier.size(width = 154.dp, height = 116.dp), contentAlignment = Alignment.Center) {
            if (brand == Brand.Dacia) {
                // asset_brand_dacia.png is a wide, short mark (~2.24:1) — size by width.
                DaciaBrandLogo(palette, Modifier.size(width = 154.dp, height = 76.dp), selected)
            } else {
                // asset_brand_renault.png is a tall diamond (~0.82:1) — size by height.
                RenaultBrandLogo(palette, Modifier.size(width = 108.dp, height = 112.dp), selected)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(brand.label, color = if (selected) palette.accent else palette.textPrimary, fontSize = 24.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(4.dp))
            Text(
                if (brand == Brand.Dacia) "Modern, dayanıklı ve akıllı sürüş deneyimi." else "İleri teknoloji ve konforlu sürüş deneyimi.",
                color = palette.textSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
        Box(modifier = Modifier.size(width = 34.dp, height = 86.dp), contentAlignment = Alignment.Center) {
            Text(if (selected && enabled) "✓" else if (!enabled) "Kilitli" else "", color = if (enabled) palette.accent else palette.textSecondary, fontSize = if (enabled) 30.sp else 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

private data class VehicleOption(
    val title: String,
    val subtitle: String,
    val enabled: Boolean = true
)

private val daciaVehicleOptions = listOf(
    VehicleOption(
        title = "Dacia Logan",
        subtitle = "2005-2012 Sedan / MCV • 1.5 dCi 68 bg • tam destek"
    ),
    VehicleOption(
        title = "Dacia Sandero I",
        subtitle = "2008-2012 • 1.5 dCi 70 bg • deneysel/doğrulama gerekli"
    ),
    VehicleOption(
        title = "Dacia Logan / MCV II",
        subtitle = "2013 ve üzeri • şu anda desteklenmiyor",
        enabled = false
    ),
    VehicleOption(
        title = "Dacia Duster I",
        subtitle = "2010-2017 • şu anda desteklenmiyor",
        enabled = false
    )
)

private val renaultVehicleOptions = listOf(
    VehicleOption(
        title = "Renault Symbol / Thalia II",
        subtitle = "2008-2013 • Renault profili henüz doğrulanmadı",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Clio II",
        subtitle = "1998-2012 • Renault profili henüz doğrulanmadı",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Clio III",
        subtitle = "2005-2014 • çoğu donanım yol bilgisayarlı; destek yok",
        enabled = false
    ),
    VehicleOption(
        title = "Renault Kangoo I",
        subtitle = "1997-2008 • Renault profili henüz doğrulanmadı",
        enabled = false
    )
)

@Composable
private fun VehicleStep(palette: LoganPalette, language: AppLanguage, brand: Brand, selected: String?, onSelect: (String) -> Unit) {
    val models = if (brand == Brand.Dacia) daciaVehicleOptions else renaultVehicleOptions
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(
            palette,
            if (language == AppLanguage.English) "Vehicle Model" else "Araç Modeli",
            if (language == AppLanguage.English) "Logan Sedan/MCV use one profile; Sandero is experimental, Duster is locked." else "Logan Sedan/MCV tek profil altında; Sandero deneysel, Duster kilitli."
        )
        models.forEach { item ->
            SelectRow(
                palette = palette,
                title = item.title,
                subtitle = item.subtitle,
                selected = selected == item.title,
                enabled = item.enabled
            ) { onSelect(item.title) }
        }
    }
}

private data class EngineOption(
    val title: String,
    val subtitle: String,
    val fuelType: FuelType = FuelType.Diesel,
    val support: VehicleProfileSupport = VehicleProfileSupport.Verified,
    val enabled: Boolean = true
) {
    val experimental: Boolean get() = support == VehicleProfileSupport.Experimental
}

@Composable
private fun EngineStep(
    palette: LoganPalette,
    language: AppLanguage,
    selected: String?,
    vehicleModel: String,
    settings: LoganSettings,
    onSelect: (String, FuelType, VehicleProfileSupport) -> Unit,
    onDetailsChange: (LoganSettings) -> Unit
) {
    var pendingExperimental by remember { mutableStateOf<EngineOption?>(null) }
    val engines = when (vehicleModel) {
        "Dacia Logan" -> listOf(
            EngineOption(
                title = "1.5 dCi 68 bg",
                subtitle = "Tam destek • 2005-2012 Logan Sedan/MCV doğrulanmış profil"
            ),
            EngineOption(
                title = "Diğer 1.5 dCi",
                subtitle = "Deneysel • log ile doğrulanmalı",
                support = VehicleProfileSupport.Experimental
            ),
            EngineOption(
                title = "Benzinli motor • Topluluk testi",
                subtitle = "Deneysel • temel OBD verileri ve ham paket toplama",
                fuelType = FuelType.Petrol,
                support = VehicleProfileSupport.Experimental
            )
        )
        "Dacia Sandero I" -> listOf(
            EngineOption(
                title = "1.5 dCi 70 bg",
                subtitle = "Deneysel • Sandero I için log ile doğrulama gerekli",
                support = VehicleProfileSupport.Experimental
            ),
            EngineOption(
                title = "Benzinli motor • Topluluk testi",
                subtitle = "Deneysel • temel OBD verileri ve ham paket toplama",
                fuelType = FuelType.Petrol,
                support = VehicleProfileSupport.Experimental
            )
        )
        else -> listOf(
            EngineOption(
                title = "Bu model desteklenmiyor",
                subtitle = "Şimdilik LoganOS profili yok",
                enabled = false
            )
        )
    }
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(
            palette,
            if (language == AppLanguage.English) "Engine" else "Motor",
            if (language == AppLanguage.English) "Options are simplified according to the selected model." else "Seçenekler seçilen model yılına göre sadeleştirildi."
        )
        engines.forEach { item ->
            SelectRow(
                palette = palette,
                title = item.title,
                subtitle = item.subtitle,
                selected = selected == item.title,
                enabled = item.enabled
            ) {
                if (item.experimental) pendingExperimental = item else onSelect(item.title, item.fuelType, item.support)
            }
        }

        if (selected == "Benzinli motor • Topluluk testi") {
            OemCard(palette) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (language == AppLanguage.English) "Experimental petrol vehicle details" else "Deneysel benzinli araç bilgileri",
                        color = palette.textPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        if (language == AppLanguage.English) {
                            "Fuel calculation stays disabled until the injection/fuel-rate source is verified. Engine code is optional; the other fields are required for the support package."
                        } else {
                            "Enjeksiyon/yakıt debisi kaynağı doğrulanana kadar tüketim hesabı kapalı kalır. Motor kodu isteğe bağlıdır; diğer alanlar destek paketi için gereklidir."
                        },
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )
                    PetrolDetailField(
                        palette = palette,
                        label = if (language == AppLanguage.English) "Model year" else "Model yılı",
                        value = settings.modelYearText,
                        numeric = true
                    ) { onDetailsChange(settings.copy(modelYearText = it.filter(Char::isDigit).take(4))) }
                    PetrolDetailField(
                        palette = palette,
                        label = if (language == AppLanguage.English) "Engine displacement (cc)" else "Motor hacmi (cc)",
                        value = settings.engineDisplacementCcText,
                        numeric = true
                    ) { onDetailsChange(settings.copy(engineDisplacementCcText = it.filter(Char::isDigit).take(5))) }
                    PetrolDetailField(
                        palette = palette,
                        label = if (language == AppLanguage.English) "Engine code (optional)" else "Motor kodu (isteğe bağlı)",
                        value = settings.engineCodeText,
                        numeric = false
                    ) { onDetailsChange(settings.copy(engineCodeText = it.uppercase().take(20))) }
                    PetrolDetailField(
                        palette = palette,
                        label = if (language == AppLanguage.English) "Engine power (hp)" else "Motor gücü (bg)",
                        value = settings.enginePowerHpText,
                        numeric = true
                    ) { onDetailsChange(settings.copy(enginePowerHpText = it.filter(Char::isDigit).take(4))) }
                    PetrolDetailField(
                        palette = palette,
                        label = if (language == AppLanguage.English) "Cylinder count" else "Silindir sayısı",
                        value = settings.cylinderCount.toString(),
                        numeric = true
                    ) { raw ->
                        onDetailsChange(settings.copy(cylinderCount = raw.filter(Char::isDigit).toIntOrNull()?.coerceIn(1, 12) ?: 0))
                    }
                }
            }
        }
    }

    pendingExperimental?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingExperimental = null },
            title = { Text("Deneysel motor profili", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    if (item.fuelType == FuelType.Petrol) {
                        "Bu benzinli profil henüz doğrulanmamıştır. LoganOS yalnızca güvenli, salt-okunur OBD sorguları kullanır. RPM, hız ve hararet çalışabilir; tüketim ve maliyet doğrulanana kadar gösterilmez. Oluşturulan destek paketini paylaşarak geliştirmeye katkı sağlayabilirsiniz."
                    } else {
                        "LoganOS tam doğrulanmış profili 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. ${item.title} seçerseniz uygulama çalışabilir; ancak yakıt, tüketim ve bazı ECU değerleri sapmalı görünebilir."
                    },
                    color = palette.textSecondary,
                    lineHeight = 20.sp
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    onSelect(item.title, item.fuelType, item.support)
                    pendingExperimental = null
                }) { Text("Anladım, seç") }
            },
            dismissButton = {
                TextButton(onClick = { pendingExperimental = null }) { Text("Vazgeç") }
            }
        )
    }
}

@Composable
private fun PetrolDetailField(
    palette: LoganPalette,
    label: String,
    value: String,
    numeric: Boolean,
    onValueChange: (String) -> Unit
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text),
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun DeviceStep(palette: LoganPalette, language: AppLanguage, selected: DeviceMode?, onSelect: (DeviceMode) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, if (language == AppLanguage.English) "Device Mode" else "Cihaz Kullanım Modu", if (language == AppLanguage.English) "Phone mode supports portrait/landscape. Android head units default to landscape dashboard." else "Telefon dikey/yatay kullanımı destekler. Android multimedya cihazlarda yatay mod varsayılandır.")
        DeviceMode.entries.forEach { mode ->
            val title = when (mode) {
                DeviceMode.Auto -> if (language == AppLanguage.English) "Automatic" else "Otomatik"
                DeviceMode.Phone -> if (language == AppLanguage.English) "Phone" else "Telefon"
                DeviceMode.HeadUnit -> if (language == AppLanguage.English) "Android Multimedia / Head Unit" else "Android Multimedya / Double"
            }
            val description = when (mode) {
                DeviceMode.Auto -> if (language == AppLanguage.English) "Detect from the available screen" else "Kullanılabilir ekrana göre otomatik seçim"
                DeviceMode.Phone -> if (language == AppLanguage.English) "Portrait and landscape use" else "Dikey ve yatay kullanım"
                DeviceMode.HeadUnit -> if (language == AppLanguage.English) "Landscape cockpit for multimedia screens" else "Multimedya ekranlar için yatay kokpit"
            }
            SelectRow(palette, title, description, selected == mode) { onSelect(mode) }
        }
    }
}

@Composable
private fun GaugeStep(palette: LoganPalette, language: AppLanguage, selected: GaugeStyle?, onSelect: (GaugeStyle) -> Unit) {
    val enabledStyles = listOf(GaugeStyle.Digital, GaugeStyle.DigitalV2, GaugeStyle.ClassicOem, GaugeStyle.GhostSingle, GaugeStyle.GhostDual, GaugeStyle.GhostSingleOriginal, GaugeStyle.GhostDualOriginal)
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        StepTitle(
            palette,
            if (language == AppLanguage.English) "Gauge Style" else "Gösterge Stili",
            if (language == AppLanguage.English) "Choose between Digital OEM, Digital V2, Classic, Ghost Single and Ghost Dual cockpits." else "Digital OEM, Dijital V2, Classic, Ghost Single ve Ghost Dual kokpit arasında seçim yapın."
        )
        enabledStyles.forEach { style ->
            SelectRow(
                palette = palette,
                title = when (style) {
                    GaugeStyle.Digital -> "Digital OEM"
                    GaugeStyle.DigitalV2 -> if (language == AppLanguage.English) "Digital V2" else "Dijital V2"
                    GaugeStyle.ClassicOem -> "Classic"
                    GaugeStyle.GhostSingle -> "Ghost Single"
                    GaugeStyle.GhostDual -> "Ghost Dual"
                    GaugeStyle.GhostSingleOriginal -> "Ghost Single Original"
                    GaugeStyle.GhostDualOriginal -> "Ghost Dual Original"
                },
                subtitle = gaugeSetupDescription(style, language),
                selected = selected == style,
                enabled = true
            ) { onSelect(style) }
            if (selected == style) {
                OemCard(palette) {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GaugePreview(palette, style, true, modifier = Modifier.fillMaxWidth())
                        Text(
                            gaugeSetupLongDescription(style, language),
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    }
                }
            }
        }
        Text(
            if (language == AppLanguage.English) {
                "Six cockpit styles are available: Digital OEM, Digital V2, Classic, Ghost Single, Ghost Dual and Ghost Single Original."
            } else {
                "Altı kokpit stili kullanılabilir: Digital OEM, Dijital V2, Classic, Ghost Single, Ghost Dual ve Ghost Single Original."
            },
            color = palette.textSecondary,
            fontSize = 12.sp
        )
    }
}

private fun gaugeSetupDescription(style: GaugeStyle, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (style) {
        GaugeStyle.Digital -> if (tr) "C düzeni • modern dijital hız ve temiz veri alanı" else "C layout • modern digital speed and clean data area"
        GaugeStyle.DigitalV2 -> if (tr) "4 sahne • hız/devir kadranı • canlı yol efekti" else "4 scenes • speed/RPM gauge • live road motion"
        GaugeStyle.ClassicOem -> if (tr) "A düzeni • fabrika tipi klasik gösterge hissi" else "A layout • factory-style classic gauge feel"
        GaugeStyle.GhostSingle -> if (tr) "Tek büyük gösterge • telefonda dikey/yatay uyarlanır" else "Single large gauge • adapts to phone portrait/landscape"
        GaugeStyle.GhostDual -> if (tr) "Çift kadran • yatay hayalet kokpit" else "Dual dial • landscape ghost cockpit"
        GaugeStyle.GhostSingleOriginal -> if (tr) "Asset tabanlı tek kadran • yalnız yatay" else "Asset-based single dial • landscape only"
        GaugeStyle.GhostDualOriginal -> if (tr) "Referans tabanlı çift kadran • yalnız yatay" else "Reference-based dual dial • landscape only"
    }
}

private fun gaugeSetupLongDescription(style: GaugeStyle, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (style) {
        GaugeStyle.Digital -> if (tr) "Digital C: beyaz temaya uygun, büyük hız göstergesi ve düzenli veri satırları." else "Digital C: large speed readout and clean data rows for the white cockpit theme."
        GaugeStyle.DigitalV2 -> if (tr) "Dijital V2: Dağ-Göl, Şehir Gündüz, Şehir Gece ve Karlı Yol sahneleri; seçilebilir hız/devir kadranı ve hareket efektleri." else "Digital V2: Mountain-Lake, City Day, City Night and Snow Road scenes; selectable speed/RPM gauge and motion effects."
        GaugeStyle.ClassicOem -> if (tr) "Classic OEM A: eski-yeni fabrika göstergesi hissi; sade ve tanıdık." else "Classic OEM A: familiar factory-gauge feeling with a clean OEM look."
        GaugeStyle.GhostSingle -> if (tr) "Ghost Single: telefonda dikey tutulunca Portrait, yatay tutulunca 19.5:9 görünüm; Double'da geniş ekran hayalet gösterge." else "Ghost Single: Portrait when the phone is upright, 19.5:9 when rotated, and a widescreen Ghost cluster on head units."
        GaugeStyle.GhostDual -> if (tr) "Ghost Dual: hız ve devir için iki büyük kadran ve ortada araç görünümü." else "Ghost Dual: two large dials for speed and RPM with a centered vehicle view."
        GaugeStyle.GhostSingleOriginal -> if (tr) "Ghost Single Original: ayrı asset katmanları, ufuk ışığı, düz yol kenarı akışı ve seçili Logan görünümü; yalnız yatay çalışır." else "Ghost Single Original: separate asset layers, horizon glow, straight road-edge motion and the selected Logan view; landscape only."
        GaugeStyle.GhostDualOriginal -> if (tr) "Ghost Dual Original: Logan ölçekli iki kadran, ortada hararet çubuğu, yol ve seçili Logan görünümü; yalnız yatay çalışır." else "Ghost Dual Original: two Logan-scaled dials, centered coolant bar, road and selected Logan view; landscape only."
    }
}

@Composable
private fun AccentStep(palette: LoganPalette, language: AppLanguage, selected: AccentColor?, onSelect: (AccentColor) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(palette, if (language == AppLanguage.English) "Accent Color" else "Vurgu Rengi", if (language == AppLanguage.English) "Default LoganOS accent is OEM Green." else "Varsayılan LoganOS rengi OEM Green'dir.")
        AccentColor.entries.forEach { accent ->
            SelectRow(palette, accent.label, "Logo, göstergeler, aktif menüler ve switch renkleri", selected == accent, color = accent.color) { onSelect(accent) }
        }
    }
}

@Composable
private fun DataNoticeStep(palette: LoganPalette, language: AppLanguage, accepted: Boolean, onAccepted: (Boolean) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        StepTitle(palette, if (language == AppLanguage.English) "Data Use" else "Veri Kullanımı", if (language == AppLanguage.English) "LoganOS does not make a definitive diagnosis; it interprets ECU data for information." else "LoganOS teşhis koymaz; ECU verilerini yorumlayarak bilgilendirme sağlar.")
        OemCard(palette) {
            Text(
                if (language == AppLanguage.English) "Fuel consumption, cost, performance and vehicle health evaluations are based on ECU data and LoganOS algorithms. Deviations may occur depending on the vehicle, ECU and OBD adapter. This information is not an official measurement or warranty." else "Yakıt tüketimi, maliyet, performans ve araç sağlığı değerlendirmeleri ECU verileri ile LoganOS algoritmalarına dayanır. Araç, ECU ve OBD adaptörüne bağlı olarak sapmalar oluşabilir. Bu bilgiler resmi ölçüm veya garanti niteliğinde değildir.",
                color = palette.textSecondary,
                fontSize = 15.sp,
                lineHeight = 24.sp
            )
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (accepted) palette.accent.copy(alpha = .08f) else palette.surface)
                .border(1.dp, if (accepted) palette.accent else palette.line, RoundedCornerShape(16.dp))
                .clickable { onAccepted(!accepted) }
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = accepted,
                onCheckedChange = onAccepted,
                colors = CheckboxDefaults.colors(
                    checkedColor = palette.accent,
                    uncheckedColor = palette.textSecondary,
                    checkmarkColor = palette.background
                )
            )
            Column {
                Text(if (language == AppLanguage.English) "I have read and accept" else "Okudum ve kabul ediyorum", color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text(if (language == AppLanguage.English) "Check the box to finish setup." else "Kurulumu tamamlamak için kutucuğu işaretle.", color = palette.textSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun SelectListStep(palette: LoganPalette, title: String, itemsList: List<String>, selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        StepTitle(palette, title, "Sonradan ayarlardan değiştirilebilir.")
        itemsList.forEach { item ->
            SelectRow(palette, item, null, selected == item) { onSelect(item) }
        }
    }
}

@Composable
private fun SelectRow(
    palette: LoganPalette,
    title: String,
    subtitle: String?,
    selected: Boolean,
    color: Color = palette.accent,
    enabled: Boolean = true,
    onClick: () -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    val effectiveColor = if (enabled) color else palette.textSecondary
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (selected && enabled) color.copy(alpha = .10f) else palette.surface)
            .border(1.dp, if (selected && enabled) color else palette.line, shape)
            .then(if (enabled) Modifier.clickable { onClick() } else Modifier)
            .alpha(if (enabled) 1f else .48f)
            .padding(15.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = if (selected && enabled) color else effectiveColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            if (subtitle != null) {
                Text(subtitle, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
        Text(if (selected && enabled) "✓" else if (!enabled) "Kilitli" else "", color = effectiveColor, fontSize = if (enabled) 24.sp else 12.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun StepTitle(palette: LoganPalette, title: String, subtitle: String) {
    Column {
        Text(title, color = palette.textPrimary, fontSize = 27.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

@Composable
private fun WizardButtons(palette: LoganPalette, canBack: Boolean, canNext: Boolean, backText: String, nextText: String, onBack: () -> Unit, onNext: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
        OutlinedButton(onClick = onBack, enabled = canBack, modifier = Modifier.weight(1f).height(48.dp)) { Text(backText) }
        Button(
            onClick = onNext,
            enabled = canNext,
            colors = ButtonDefaults.buttonColors(containerColor = palette.accent),
            modifier = Modifier.weight(1.4f).height(48.dp)
        ) { Text(nextText) }
    }
}
