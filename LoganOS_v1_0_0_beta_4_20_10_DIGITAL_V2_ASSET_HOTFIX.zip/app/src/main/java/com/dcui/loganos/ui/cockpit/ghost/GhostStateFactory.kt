package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.ui.graphics.Color
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette

internal fun ghostRenderState(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    rpmLimit: Int
): GhostRenderState {
    val trusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    val instantValue = snapshot.instantConsumption.takeIf { trusted }
    val averageValue = snapshot.averageConsumption.takeIf { trusted }
    return GhostRenderState(
        speedKmh = (snapshot.speedKmh ?: 0).coerceIn(0, 200),
        rpm = (snapshot.rpm ?: 0).coerceIn(0, rpmLimit),
        tachometerMaxRpm = rpmLimit,
        coolantCelsius = snapshot.engineTempC,
        instantValue = instantValue,
        instantText = if (trusted) formatGhostValue(instantValue) else "--",
        instantUnit = if (trusted) snapshot.instantUnit.takeIf { it.isNotBlank() } ?: "L/100 km" else "VERİ BEKLENİYOR",
        averageValue = averageValue,
        averageText = if (trusted) formatGhostValue(averageValue) else "--",
        averageUnit = if (trusted) "L/100 km" else "VERİ BEKLENİYOR",
        connected = snapshot.connected,
        demo = snapshot.demo,
        accentColor = ghostAccentColor(settings.ghostOriginalAccent),
        coolantColor = coolantAccentColor(palette, snapshot.engineTempC),
        vehicleRes = vehicleVisualDrawableRes(
            model = settings.vehicleVisualModel,
            color = settings.vehicleColor,
            style = VehicleAssetStyle.Detailed
        ),
        vehicleCalibration = ghostVehicleCalibration(settings.vehicleVisualModel)
    )
}

internal fun ghostAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFF9B5CFF)
    GhostOriginalAccent.Red -> Color(0xFFFF3B30)
    GhostOriginalAccent.Green -> Color(0xFF2EE66B)
    GhostOriginalAccent.White -> Color(0xFFF1F5FF)
    GhostOriginalAccent.Blue -> Color(0xFF3595FF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFC12E)
}

