package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.runtime.Immutable
import androidx.compose.ui.unit.Dp

@Immutable
data class GhostSceneTransform(
    val scale: Float,
    val sceneWidth: Dp,
    val sceneHeight: Dp
) {
    fun x(logicalX: Float): Dp = sceneWidth * (logicalX / GhostSceneSpec.DESIGN_WIDTH)
    fun y(logicalY: Float): Dp = sceneHeight * (logicalY / GhostSceneSpec.DESIGN_HEIGHT)
    fun width(logicalWidth: Float): Dp = sceneWidth * (logicalWidth / GhostSceneSpec.DESIGN_WIDTH)
    fun height(logicalHeight: Float): Dp = sceneHeight * (logicalHeight / GhostSceneSpec.DESIGN_HEIGHT)
}
