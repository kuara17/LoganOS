package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.ui.graphics.Color

/**
 * Ghost Single fixed OEM layout profile.
 * Reference: the user's single-centre Megane matrix cluster photo.
 * 4.20.4 keeps the layout deterministic and fixes the oversized/clipped gauge,
 * horizon/road separation and vehicle grounding seen on the real device.
 */
internal val GhostSingleSceneSpec = GhostSceneSpec(
    mode = GhostLayoutMode.Single,
    road = GhostRoadSpec(
        vanishingPoint = GhostPoint(800f, 376f),
        topY = 432f,
        fadeVisibleY = 466f,
        bottomY = 700f,
        topHalfWidth = 34f,
        bottomHalfWidth = 205f
    ),
    horizon = GhostHorizonSpec(
        center = GhostPoint(800f, 376f),
        outerWidth = 330f,
        outerHeight = 24f,
        middleWidth = 210f,
        middleHeight = 12f,
        coreWidth = 56f,
        coreHeight = 5f,
        color = Color(0xFF3D9FFF)
    ),
    vehicle = GhostVehiclePlacement(
        centerX = 800f,
        tireContactY = 644f,
        visibleWidth = 178f,
        shadowWidthMultiplier = 1.0f,
        shadowYOffset = 3f
    ),
    single = GhostSingleOverlaySpec(
        gauge = GhostGaugeSpec(
            bounds = GhostRect(552f, 6f, 496f, 496f),
            center = GhostPoint(800f, 254f),
            radius = 248f
        ),
        speedValue = GhostRect(665f, 174f, 270f, 82f),
        speedUnit = GhostRect(708f, 249f, 184f, 31f),
        rpmValue = GhostRect(680f, 283f, 240f, 34f),
        coolant = GhostRect(112f, 178f, 270f, 278f),
        average = GhostMetricSpec(
            bounds = GhostRect(1185f, 155f, 285f, 156f),
            iconSize = 25f,
            iconGap = 8f
        ),
        instant = GhostMetricSpec(
            bounds = GhostRect(1185f, 357f, 285f, 156f),
            iconSize = 25f,
            iconGap = 8f
        ),
        status = GhostRect(1410f, 18f, 150f, 34f)
    )
)
