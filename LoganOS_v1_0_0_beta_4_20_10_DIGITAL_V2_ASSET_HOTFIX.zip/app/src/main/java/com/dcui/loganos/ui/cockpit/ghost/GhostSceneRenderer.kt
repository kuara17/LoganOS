package com.dcui.loganos.ui.cockpit.ghost

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.isActive

private val GhostWhite = Color(0xFFF7F9FF)
private val GhostMuted = Color(0xFFBAC3D2)
private val GhostDark = Color(0xFF39404D)
private val GhostHot = Color(0xFFFF3347)
private const val GhostSpeedMax = 200
private const val ConsumptionVisualMax = 15.0

@Composable
internal fun GhostSceneRenderer(
    spec: GhostSceneSpec,
    state: GhostRenderState,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier,
    calibrationVisible: Boolean = false
) {
    val roadPhase = remember { Animatable(0f) }
    LaunchedEffect(state.speedKmh) {
        if (state.speedKmh <= 0) {
            roadPhase.snapTo(0f)
            return@LaunchedEffect
        }
        val durationMs = (1900 - state.speedKmh * 12).coerceIn(450, 1900)
        while (isActive) {
            roadPhase.snapTo(0f)
            roadPhase.animateTo(1f, animationSpec = tween(durationMs, easing = LinearEasing))
        }
    }

    GhostSceneViewport(modifier = modifier) { transform ->
        Box(modifier = Modifier.fillMaxSize()) {
            // A neutral base sits under the common scene renderer. Reference-specific
            // ambient light is drawn by GhostReferenceSceneLayer for both layouts.
            Box(Modifier.fillMaxSize().background(Color(0xFF05080D)))

            // 4.20.3: road, ambient light and horizon are rendered from one fixed straight
            // logical scene geometry. No road bitmap is stretched or warped at runtime.
            GhostReferenceSceneLayer(
                mode = spec.mode,
                road = spec.road,
                horizon = spec.horizon,
                modifier = Modifier.fillMaxSize()
            )

            GhostRoadMotionLayer(
                road = spec.road,
                speedKmh = state.speedKmh,
                phase = roadPhase.value,
                modifier = Modifier.fillMaxSize()
            )

            GhostVehicleLayer(
                transform = transform,
                spec = spec.vehicle,
                state = state
            )

            when (spec.mode) {
                GhostLayoutMode.Single -> GhostSingleOverlay(
                    transform = transform,
                    spec = requireNotNull(spec.single),
                    state = state,
                    onOpenReset = onOpenReset
                )
                GhostLayoutMode.Dual -> GhostDualOverlay(
                    transform = transform,
                    spec = requireNotNull(spec.dual),
                    state = state,
                    onOpenReset = onOpenReset
                )
            }

            if (calibrationVisible) {
                GhostCalibrationOverlay(
                    spec = spec,
                    vehicleCalibration = state.vehicleCalibration,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

@Composable
private fun GhostReferenceSceneLayer(
    mode: GhostLayoutMode,
    road: GhostRoadSpec,
    horizon: GhostHorizonSpec,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val sx = size.width / GhostSceneSpec.DESIGN_WIDTH
        val sy = size.height / GhostSceneSpec.DESIGN_HEIGHT
        val vp = Offset(road.vanishingPoint.x * sx, road.vanishingPoint.y * sy)

        // Fixed OEM ambient field. Never pure black in the active centre corridor.
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF05080D),
                    Color(0xFF0A101A),
                    Color(0xFF0D1520),
                    Color(0xFF05080D)
                ),
                startY = 0f,
                endY = size.height
            ),
            size = size
        )
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFF22354B).copy(alpha = 0.34f),
                    Color(0xFF101824).copy(alpha = 0.20f),
                    Color.Transparent
                ),
                center = Offset(800f * sx, 500f * sy),
                radius = 570f * sx
            ),
            size = size
        )

        // The road is a deterministic four-corner trapezoid. There are no curves,
        // Beziers or runtime width heuristics in 4.20.3.
        clipRect(
            left = road.clipLeft * sx,
            top = 0f,
            right = road.clipRight * sx,
            bottom = size.height
        ) {
            val roadPath = Path().apply {
                moveTo((road.vanishingPoint.x - road.topHalfWidth) * sx, road.topY * sy)
                lineTo((road.vanishingPoint.x + road.topHalfWidth) * sx, road.topY * sy)
                lineTo((road.vanishingPoint.x + road.bottomHalfWidth) * sx, road.bottomY * sy)
                lineTo((road.vanishingPoint.x - road.bottomHalfWidth) * sx, road.bottomY * sy)
                close()
            }

            val fadeProgress = ((road.fadeVisibleY - road.topY) / (road.bottomY - road.topY))
                .coerceIn(0.01f, 0.99f)
            drawPath(
                path = roadPath,
                brush = Brush.verticalGradient(
                    0f to Color.Transparent,
                    (fadeProgress * 0.35f) to Color(0xFF111821).copy(alpha = 0.03f),
                    fadeProgress to Color(0xFF171E27).copy(alpha = 0.58f),
                    1f to Color(0xFF252C33).copy(alpha = 0.78f),
                    startY = road.topY * sy,
                    endY = road.bottomY * sy
                )
            )

            // Road edges use the same fade. At the horizon they are fully transparent,
            // leaving a visible breathing gap under the compact horizon bloom.
            val edgeBrush = Brush.verticalGradient(
                0f to Color.Transparent,
                (fadeProgress * 0.55f) to Color.Transparent,
                fadeProgress to Color(0xFFDCE5F1).copy(alpha = 0.38f),
                1f to Color(0xFFEAF0F8).copy(alpha = 0.52f),
                startY = road.topY * sy,
                endY = road.bottomY * sy
            )
            drawLine(
                brush = edgeBrush,
                start = Offset((road.vanishingPoint.x - road.topHalfWidth) * sx, road.topY * sy),
                end = Offset((road.vanishingPoint.x - road.bottomHalfWidth) * sx, road.bottomY * sy),
                strokeWidth = 1.25f * sx,
                cap = StrokeCap.Round
            )
            drawLine(
                brush = edgeBrush,
                start = Offset((road.vanishingPoint.x + road.topHalfWidth) * sx, road.topY * sy),
                end = Offset((road.vanishingPoint.x + road.bottomHalfWidth) * sx, road.bottomY * sy),
                strokeWidth = 1.25f * sx,
                cap = StrokeCap.Round
            )
        }

        // 4.20.4: reference-style horizon beam. It is deliberately a thin light
        // line with a tiny core, not an oval lens/"UFO" bloom.
        val c = horizon.color
        val center = Offset(horizon.center.x * sx, horizon.center.y * sy)
        val outerHalf = horizon.outerWidth * 0.5f * sx
        val middleHalf = horizon.middleWidth * 0.5f * sx
        val coreHalf = horizon.coreWidth * 0.5f * sx

        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, c.copy(alpha = 0.18f), Color.Transparent),
                startX = center.x - outerHalf,
                endX = center.x + outerHalf
            ),
            start = Offset(center.x - outerHalf, center.y),
            end = Offset(center.x + outerHalf, center.y),
            strokeWidth = horizon.outerHeight * 0.42f * sy,
            cap = StrokeCap.Round
        )
        drawLine(
            brush = Brush.horizontalGradient(
                colors = listOf(Color.Transparent, c.copy(alpha = 0.52f), Color.Transparent),
                startX = center.x - middleHalf,
                endX = center.x + middleHalf
            ),
            start = Offset(center.x - middleHalf, center.y),
            end = Offset(center.x + middleHalf, center.y),
            strokeWidth = horizon.middleHeight * 0.44f * sy,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFFEAF6FF).copy(alpha = 0.84f),
            start = Offset(center.x - coreHalf, center.y),
            end = Offset(center.x + coreHalf, center.y),
            strokeWidth = horizon.coreHeight.coerceAtLeast(2f) * sy,
            cap = StrokeCap.Round
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.92f),
            radius = 2.2f * sx,
            center = center
        )

    }
}

@Composable
private fun GhostVehicleLayer(
    transform: GhostSceneTransform,
    spec: GhostVehiclePlacement,
    state: GhostRenderState
) {
    val geometry = remember(spec, state.vehicleCalibration) {
        GhostVehicleGeometry.calculate(spec, state.vehicleCalibration)
    }

    GhostVehicleGroundShadow(
        geometry = geometry,
        modifier = Modifier.fillMaxSize()
    )

    Image(
        painter = painterResource(state.vehicleRes),
        contentDescription = null,
        contentScale = ContentScale.Fit,
        modifier = ghostBounds(transform, geometry.vehicleRect)
            .graphicsLayer { alpha = 0.995f }
    )
}

@Composable
private fun GhostVehicleGroundShadow(
    geometry: GhostVehicleGeometryResult,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val sx = size.width / GhostSceneSpec.DESIGN_WIDTH
        val sy = size.height / GhostSceneSpec.DESIGN_HEIGHT
        val centerX = (geometry.leftTireContact.x + geometry.rightTireContact.x) * 0.5f
        val groundY = geometry.leftTireContact.y

        // Fixed shallow body-contact shadow. The size is intentionally restrained;
        // it must read as contact, not as a second object under the car.
        drawOval(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.Black.copy(alpha = 0.28f),
                    Color.Black.copy(alpha = 0.14f),
                    Color.Transparent
                ),
                center = Offset(centerX * sx, (groundY + 5f) * sy),
                radius = 63f * sx
            ),
            topLeft = Offset((centerX - 63f) * sx, (groundY - 4.5f) * sy),
            size = Size(126f * sx, 19f * sy)
        )

        // Rear tyre contact patches are always attached to the calibrated tyre line.
        listOf(geometry.leftTireContact, geometry.rightTireContact).forEach { contact ->
            drawOval(
                color = Color.Black.copy(alpha = 0.34f),
                topLeft = Offset((contact.x - 13f) * sx, (contact.y - 1f) * sy),
                size = Size(26f * sx, 8f * sy)
            )
        }
    }
}

@Composable
private fun GhostRoadMotionLayer(
    road: GhostRoadSpec,
    speedKmh: Int,
    phase: Float,
    modifier: Modifier = Modifier
) {
    if (speedKmh <= 0) return
    Canvas(modifier = modifier) {
        val sx = size.width / GhostSceneSpec.DESIGN_WIDTH
        val sy = size.height / GhostSceneSpec.DESIGN_HEIGHT
        clipRect(
            left = road.clipLeft * sx,
            top = road.fadeVisibleY * sy,
            right = road.clipRight * sx,
            bottom = road.bottomY * sy
        ) {
            repeat(4) { index ->
                val t = (phase + index / 4f) % 1f
                val perspective = t * t
                val logicalY = road.fadeVisibleY + perspective * (road.bottomY - road.fadeVisibleY)
                val roadProgress = ((logicalY - road.fadeVisibleY) / (road.bottomY - road.fadeVisibleY)).coerceIn(0f, 1f)
                val markerLength = 3f + 17f * roadProgress
                val markerWidth = 0.7f + 1.8f * roadProgress
                val alpha = (sin(PI.toFloat() * t) * 0.12f).coerceAtLeast(0f)
                drawLine(
                    color = GhostWhite.copy(alpha = alpha),
                    start = Offset(road.vanishingPoint.x * sx, logicalY * sy),
                    end = Offset(road.vanishingPoint.x * sx, (logicalY + markerLength) * sy),
                    strokeWidth = markerWidth * sx,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun GhostSingleOverlay(
    transform: GhostSceneTransform,
    spec: GhostSingleOverlaySpec,
    state: GhostRenderState,
    onOpenReset: () -> Unit
) {
    val gaugeAssetRect = ghostSingleGaugeAssetBounds(spec.gauge)
    Image(
        painter = painterResource(R.drawable.ghost_single_original_gauge_shell),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = ghostBounds(transform, gaugeAssetRect)
    )
    GhostSingleNeedle(
        gauge = spec.gauge,
        speedKmh = state.speedKmh,
        modifier = Modifier.fillMaxSize()
    )
    Image(
        painter = painterResource(R.drawable.ghost_single_original_gauge_marks),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = ghostBounds(transform, gaugeAssetRect)
    )

    GhostAutoFitText(
        text = state.speedKmh.toString(),
        color = GhostWhite,
        weight = FontWeight.Light,
        maxLogicalSp = 84f,
        modifier = ghostBounds(transform, spec.speedValue)
    )
    GhostAutoFitText(
        text = "km/h",
        color = GhostMuted,
        weight = FontWeight.Medium,
        maxLogicalSp = 18f,
        modifier = ghostBounds(transform, spec.speedUnit)
    )
    GhostAutoFitText(
        text = "${state.rpm} rpm",
        color = GhostWhite.copy(alpha = 0.88f),
        weight = FontWeight.Medium,
        maxLogicalSp = 21f,
        modifier = ghostBounds(transform, spec.rpmValue)
    )

    GhostSingleCoolantModule(
        transform = transform,
        rect = spec.coolant,
        temperature = state.coolantCelsius,
        color = state.coolantColor
    )
    GhostSingleMetricModule(
        transform = transform,
        metric = spec.average,
        iconRes = R.drawable.cockpit_fuel_average,
        title = "ORTALAMA TÜKETİM",
        value = state.averageValue,
        valueText = state.averageText,
        unit = state.averageUnit,
        accent = state.accentColor,
        onClick = onOpenReset
    )
    GhostSingleMetricModule(
        transform = transform,
        metric = spec.instant,
        iconRes = R.drawable.cockpit_fuel_instant,
        title = "ANLIK TÜKETİM",
        value = state.instantValue,
        valueText = state.instantText,
        unit = state.instantUnit,
        accent = state.accentColor,
        onClick = onOpenReset
    )
    GhostAutoFitText(
        text = ghostConnectionLabel(state),
        color = if (state.demo || state.connected) state.accentColor else GhostMuted,
        weight = FontWeight.Bold,
        maxLogicalSp = 16f,
        modifier = ghostBounds(transform, spec.status)
    )
}

@Composable
private fun GhostDualOverlay(
    transform: GhostSceneTransform,
    spec: GhostDualOverlaySpec,
    state: GhostRenderState,
    onOpenReset: () -> Unit
) {
    Image(
        painter = painterResource(R.drawable.ghost_dual_original_speed_shell),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = ghostBounds(transform, spec.speedGauge.bounds)
    )
    Image(
        painter = painterResource(R.drawable.ghost_dual_oem_rpm_shell_4203),
        contentDescription = null,
        contentScale = ContentScale.FillBounds,
        modifier = ghostBounds(transform, spec.rpmGauge.bounds)
    )
    GhostAutoFitText(
        text = state.speedKmh.toString(),
        color = GhostWhite,
        weight = FontWeight.Light,
        maxLogicalSp = 64f,
        modifier = ghostBounds(transform, spec.speedValue)
    )
    GhostAutoFitText(
        text = "km/h",
        color = GhostMuted,
        weight = FontWeight.Medium,
        maxLogicalSp = 19f,
        modifier = ghostBounds(transform, spec.speedUnit)
    )
    GhostAutoFitText(
        text = state.rpm.toString(),
        color = GhostWhite,
        weight = FontWeight.Light,
        maxLogicalSp = 60f,
        modifier = ghostBounds(transform, spec.rpmValue)
    )
    GhostAutoFitText(
        text = "rpm",
        color = GhostMuted,
        weight = FontWeight.Medium,
        maxLogicalSp = 19f,
        modifier = ghostBounds(transform, spec.rpmUnit)
    )

    GhostMetricHeader(
        transform = transform,
        metric = spec.instantHeader,
        iconRes = R.drawable.cockpit_fuel_instant,
        title = "ANLIK TÜKETİM"
    )
    GhostAutoFitText(
        text = state.instantText,
        color = GhostWhite,
        weight = FontWeight.SemiBold,
        maxLogicalSp = 40f,
        modifier = ghostBounds(transform, spec.instantValue)
    )
    GhostAutoFitText(
        text = state.instantUnit,
        color = GhostMuted,
        weight = FontWeight.Medium,
        maxLogicalSp = 17f,
        modifier = ghostBounds(transform, spec.instantUnit)
    )

    GhostMetricHeader(
        transform = transform,
        metric = spec.averageHeader,
        iconRes = R.drawable.cockpit_fuel_average,
        title = "ORTALAMA TÜKETİM"
    )
    GhostAutoFitText(
        text = state.averageText,
        color = GhostWhite,
        weight = FontWeight.SemiBold,
        maxLogicalSp = 40f,
        modifier = ghostBounds(transform, spec.averageValue)
    )
    GhostAutoFitText(
        text = state.averageUnit,
        color = GhostMuted,
        weight = FontWeight.Medium,
        maxLogicalSp = 17f,
        modifier = ghostBounds(transform, spec.averageUnit)
    )

    GhostDualCoolantModule(
        transform = transform,
        rect = spec.coolant,
        temperature = state.coolantCelsius,
        color = state.coolantColor
    )
    GhostAutoFitText(
        text = ghostConnectionLabel(state),
        color = if (state.demo || state.connected) state.accentColor else GhostMuted,
        weight = FontWeight.Bold,
        maxLogicalSp = 16f,
        modifier = ghostBounds(transform, spec.status)
    )

    Box(modifier = ghostBounds(transform, GhostRect(120f, 548f, 410f, 132f)).clickable(onClick = onOpenReset))
    Box(modifier = ghostBounds(transform, GhostRect(1070f, 548f, 410f, 132f)).clickable(onClick = onOpenReset))
}

private fun ghostSingleGaugeAssetBounds(gauge: GhostGaugeSpec): GhostRect {
    // Source assets were authored on the old 1846x852 artboard with a logical gauge
    // centre at (923,410) and radius 350. This maps them uniformly into the fixed
    // 1600x700 cockpit artboard without FillBounds distortion.
    val scale = gauge.radius / 350f
    val width = 1846f * scale
    val height = 852f * scale
    return GhostRect(
        x = gauge.center.x - 923f * scale,
        y = gauge.center.y - 410f * scale,
        width = width,
        height = height
    )
}

@Composable
private fun GhostSingleNeedle(
    gauge: GhostGaugeSpec,
    speedKmh: Int,
    modifier: Modifier
) {
    Canvas(modifier = modifier) {
        val sx = size.width / GhostSceneSpec.DESIGN_WIDTH
        val sy = size.height / GhostSceneSpec.DESIGN_HEIGHT
        val ratio = speedKmh.coerceIn(0, GhostSpeedMax) / GhostSpeedMax.toFloat()
        val angle = Math.toRadians((165f + 210f * ratio).toDouble())
        val center = Offset(gauge.center.x * sx, gauge.center.y * sy)
        val direction = Offset(cos(angle).toFloat(), sin(angle).toFloat())
        val startRadius = gauge.radius * 0.49f
        val tipRadius = gauge.radius * 0.91f
        val start = Offset(center.x + direction.x * startRadius * sx, center.y + direction.y * startRadius * sy)
        val tip = Offset(center.x + direction.x * tipRadius * sx, center.y + direction.y * tipRadius * sy)
        drawLine(
            color = GhostWhite.copy(alpha = 0.88f),
            start = start,
            end = tip,
            strokeWidth = 2.6f * sx,
            cap = StrokeCap.Round
        )
        drawCircle(Color.Black.copy(alpha = 0.88f), 5.2f * sx, center)
        drawCircle(GhostWhite.copy(alpha = 0.94f), 2.4f * sx, center)
    }
}

@Composable
private fun GhostSingleCoolantModule(
    transform: GhostSceneTransform,
    rect: GhostRect,
    temperature: Int?,
    color: Color
) {
    val progress = temperature?.let { ((it - 40f) / 80f).coerceIn(0f, 1f) } ?: 0f
    BoxWithConstraints(modifier = ghostBounds(transform, rect)) {
        val boxWidth = maxWidth
        val boxHeight = maxHeight
        Image(
            painter = painterResource(R.drawable.cockpit_coolant),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            colorFilter = ColorFilter.tint(color),
            modifier = Modifier
                .offset(x = boxWidth * 0.20f, y = boxHeight * 0.08f)
                .size(boxHeight * 0.16f)
        )
        Text(
            text = "HARARET",
            color = GhostWhite,
            fontSize = sceneSp(transform, 20f),
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            modifier = Modifier.offset(x = boxWidth * 0.46f, y = boxHeight * 0.115f)
        )
        GhostVerticalGauge(
            progress = progress,
            color = color,
            modifier = Modifier
                .offset(x = boxWidth * 0.03f, y = boxHeight * 0.20f)
                .width(boxWidth * 0.18f)
                .height(boxHeight * 0.68f)
        )
        GhostAutoFitText(
            text = temperature?.let { "$it °C" } ?: "-- °C",
            color = color,
            weight = FontWeight.Bold,
            maxLogicalSp = 44f,
            modifier = Modifier
                .offset(x = boxWidth * 0.27f, y = boxHeight * 0.39f)
                .width(boxWidth * 0.68f)
                .height(boxHeight * 0.25f)
        )
    }
}

@Composable
private fun GhostSingleMetricModule(
    transform: GhostSceneTransform,
    metric: GhostMetricSpec,
    @DrawableRes iconRes: Int,
    title: String,
    value: Double?,
    valueText: String,
    unit: String,
    accent: Color,
    onClick: () -> Unit
) {
    val progress = ((value ?: 0.0) / ConsumptionVisualMax).toFloat().coerceIn(0f, 1f)
    BoxWithConstraints(
        modifier = ghostBounds(transform, metric.bounds).clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .offset(y = maxHeight * 0.03f)
                .width(maxWidth)
                .height(maxHeight * 0.22f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            Image(
                painter = painterResource(iconRes),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(accent),
                modifier = Modifier.size(transform.width(metric.iconSize))
            )
            Spacer(Modifier.width(transform.width(metric.iconGap)))
            Text(
                text = title,
                color = GhostMuted,
                fontSize = sceneSp(transform, 21f),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Clip
            )
        }
        GhostAutoFitText(
            text = valueText,
            color = GhostWhite,
            weight = FontWeight.SemiBold,
            maxLogicalSp = 48f,
            modifier = Modifier
                .offset(y = maxHeight * 0.28f)
                .width(maxWidth)
                .height(maxHeight * 0.30f)
        )
        GhostAutoFitText(
            text = unit,
            color = GhostMuted,
            weight = FontWeight.Medium,
            maxLogicalSp = 18f,
            modifier = Modifier
                .offset(y = maxHeight * 0.57f)
                .width(maxWidth)
                .height(maxHeight * 0.18f)
        )
        GhostHorizontalGauge(
            progress = progress,
            color = accent,
            modifier = Modifier
                .offset(x = maxWidth * 0.08f, y = maxHeight * 0.82f)
                .width(maxWidth * 0.84f)
                .height(maxHeight * 0.08f)
        )
    }
}

@Composable
private fun GhostMetricHeader(
    transform: GhostSceneTransform,
    metric: GhostMetricSpec,
    @DrawableRes iconRes: Int,
    title: String
) {
    Box(modifier = ghostBounds(transform, metric.bounds), contentAlignment = Alignment.Center) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(iconRes),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(GhostHot),
                modifier = Modifier.size(transform.width(metric.iconSize))
            )
            Spacer(Modifier.width(transform.width(metric.iconGap)))
            Text(
                text = title,
                color = GhostMuted,
                fontSize = sceneSp(transform, 24f),
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Clip
            )
        }
    }
}

@Composable
private fun GhostDualCoolantModule(
    transform: GhostSceneTransform,
    rect: GhostRect,
    temperature: Int?,
    color: Color
) {
    val progress = temperature?.let { ((it - 40f) / 80f).coerceIn(0f, 1f) } ?: 0f
    BoxWithConstraints(modifier = ghostBounds(transform, rect)) {
        val boxWidth = maxWidth
        val boxHeight = maxHeight
        Row(
            modifier = Modifier
                .offset(y = boxHeight * 0.02f)
                .width(boxWidth)
                .height(boxHeight * 0.48f),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = androidx.compose.foundation.layout.Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.cockpit_coolant),
                contentDescription = null,
                contentScale = ContentScale.Fit,
                colorFilter = ColorFilter.tint(color),
                modifier = Modifier.size(boxHeight * 0.36f)
            )
            Spacer(Modifier.width(boxWidth * 0.035f))
            Text(
                text = temperature?.let { "$it °C" } ?: "-- °C",
                color = color,
                fontSize = sceneSp(transform, 22f),
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
        }
        GhostHorizontalGauge(
            progress = progress,
            color = color,
            modifier = Modifier
                .offset(x = boxWidth * 0.12f, y = boxHeight * 0.72f)
                .width(boxWidth * 0.76f)
                .height(boxHeight * 0.12f)
        )
    }
}

@Composable
private fun GhostVerticalGauge(
    progress: Float,
    color: Color,
    modifier: Modifier
) {
    Canvas(modifier = modifier) {
        val x = size.width * 0.50f
        val top = size.height * 0.12f
        val bottom = size.height * 0.88f
        drawLine(GhostDark, Offset(x, top), Offset(x, bottom), size.width * 0.12f, StrokeCap.Round)
        val activeTop = bottom - (bottom - top) * progress.coerceIn(0f, 1f)
        drawLine(color, Offset(x, activeTop), Offset(x, bottom), size.width * 0.10f, StrokeCap.Round)
    }
}

@Composable
private fun GhostHorizontalGauge(
    progress: Float,
    color: Color,
    modifier: Modifier
) {
    Canvas(modifier = modifier) {
        val y = size.height / 2f
        val start = size.width * 0.03f
        val end = size.width * 0.97f
        val activeEnd = start + (end - start) * progress.coerceIn(0f, 1f)
        drawLine(GhostDark, Offset(start, y), Offset(end, y), size.height * 0.62f, StrokeCap.Round)
        if (activeEnd > start) {
            drawLine(
                brush = Brush.horizontalGradient(listOf(color.copy(alpha = 0.55f), color), startX = start, endX = end),
                start = Offset(start, y),
                end = Offset(activeEnd, y),
                strokeWidth = size.height * 0.56f,
                cap = StrokeCap.Round
            )
        }
    }
}

@Composable
private fun GhostAutoFitText(
    text: String,
    color: Color,
    weight: FontWeight,
    maxLogicalSp: Float,
    modifier: Modifier
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        val measurer = rememberTextMeasurer()
        val fontScale = LocalDensity.current.fontScale.coerceAtLeast(0.75f)
        val maxWidthPx = constraints.maxWidth.toFloat() * 0.96f
        val maxHeightPx = constraints.maxHeight.toFloat() * 0.92f
        val requestedMaxSp = minOf(maxLogicalSp, maxHeight.value * 0.92f).coerceAtLeast(8f)
        val fitted = remember(text, weight, maxWidthPx, maxHeightPx, requestedMaxSp, fontScale) {
            fitGhostText(
                measurer = measurer,
                text = text,
                weight = weight,
                maxSp = requestedMaxSp / fontScale,
                maxWidthPx = maxWidthPx,
                maxHeightPx = maxHeightPx
            )
        }
        Text(
            text = text,
            color = color,
            fontSize = fitted.sp,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1,
            softWrap = false,
            overflow = TextOverflow.Clip
        )
    }
}

private fun fitGhostText(
    measurer: androidx.compose.ui.text.TextMeasurer,
    text: String,
    weight: FontWeight,
    maxSp: Float,
    maxWidthPx: Float,
    maxHeightPx: Float
): Float {
    var low = 4f
    var high = maxSp.coerceAtLeast(low)
    repeat(12) {
        val mid = (low + high) / 2f
        val result = measurer.measure(
            text = AnnotatedString(text),
            style = TextStyle(fontSize = mid.sp, fontWeight = weight),
            maxLines = 1,
            softWrap = false
        )
        if (result.size.width <= maxWidthPx && result.size.height <= maxHeightPx) low = mid else high = mid
    }
    return low
}

private fun ghostBounds(transform: GhostSceneTransform, rect: GhostRect): Modifier = Modifier
    .offset(x = transform.x(rect.x), y = transform.y(rect.y))
    .width(transform.width(rect.width))
    .height(transform.height(rect.height))

@Composable
private fun sceneSp(transform: GhostSceneTransform, logicalPx: Float): TextUnit {
    val fontScale = LocalDensity.current.fontScale.coerceAtLeast(0.75f)
    return (logicalPx * transform.scale / fontScale).sp
}

private fun ghostConnectionLabel(state: GhostRenderState): String = when {
    state.demo -> "DEMO"
    state.connected -> "OBD BAĞLI"
    else -> "OBD BEKLENİYOR"
}

internal fun formatGhostValue(value: Double?): String =
    value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"
