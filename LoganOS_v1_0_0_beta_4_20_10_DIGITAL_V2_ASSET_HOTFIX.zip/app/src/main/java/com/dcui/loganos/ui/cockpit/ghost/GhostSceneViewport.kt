package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
internal fun GhostSceneViewport(
    modifier: Modifier = Modifier,
    content: @Composable (GhostSceneTransform) -> Unit
) {
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF05080D)),
        contentAlignment = Alignment.Center
    ) {
        val scale = minOf(
            maxWidth.value / GhostSceneSpec.DESIGN_WIDTH,
            maxHeight.value / GhostSceneSpec.DESIGN_HEIGHT
        ).coerceAtLeast(0.0001f)
        val sceneWidth = (GhostSceneSpec.DESIGN_WIDTH * scale).dp
        val sceneHeight = (GhostSceneSpec.DESIGN_HEIGHT * scale).dp
        val transform = GhostSceneTransform(
            scale = scale,
            sceneWidth = sceneWidth,
            sceneHeight = sceneHeight
        )
        Box(
            modifier = Modifier
                .width(sceneWidth)
                .height(sceneHeight)
        ) {
            content(transform)
        }
    }
}
