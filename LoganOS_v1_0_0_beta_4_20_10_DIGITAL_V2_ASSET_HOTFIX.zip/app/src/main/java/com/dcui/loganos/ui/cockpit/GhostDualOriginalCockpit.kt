package com.dcui.loganos.ui.cockpit

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.cockpit.ghost.GhostDualSceneSpec
import com.dcui.loganos.ui.cockpit.ghost.GhostSceneRenderer
import com.dcui.loganos.ui.cockpit.ghost.ghostRenderState
import com.dcui.loganos.ui.theme.LoganPalette

@Composable
fun GhostDualOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    GhostSceneRenderer(
        spec = GhostDualSceneSpec,
        state = ghostRenderState(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            rpmLimit = 7000
        ),
        onOpenReset = onOpenReset,
        modifier = modifier
    )
}
