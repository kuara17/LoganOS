package com.dcui.loganos.ui.cockpit.ghost

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

@Immutable
data class GhostRenderState(
    val speedKmh: Int,
    val rpm: Int,
    val tachometerMaxRpm: Int,
    val coolantCelsius: Int?,
    val instantValue: Double?,
    val instantText: String,
    val instantUnit: String,
    val averageValue: Double?,
    val averageText: String,
    val averageUnit: String,
    val connected: Boolean,
    val demo: Boolean,
    val accentColor: Color,
    val coolantColor: Color,
    @DrawableRes val vehicleRes: Int,
    val vehicleCalibration: GhostVehicleCalibration
)
