package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.runtime.Immutable
import com.dcui.loganos.model.VehicleVisualModel

@Immutable
data class GhostVehicleCalibration(
    val textureAspectHeightOverWidth: Float,
    val visibleLeftRatioInTexture: Float,
    val visibleRightRatioInTexture: Float,
    val leftTireContactXRatioInTexture: Float,
    val rightTireContactXRatioInTexture: Float,
    val contactYRatioInTexture: Float,
    val visibleBottomRatioInTexture: Float
) {
    val visibleWidthRatioInTexture: Float
        get() = visibleRightRatioInTexture - visibleLeftRatioInTexture
}

internal fun ghostVehicleCalibration(model: VehicleVisualModel): GhostVehicleCalibration = when (model) {
    VehicleVisualModel.LoganI -> GhostVehicleCalibration(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleLeftRatioInTexture = 69f / 1014f,
        visibleRightRatioInTexture = 946f / 1014f,
        leftTireContactXRatioInTexture = 0.178f,
        rightTireContactXRatioInTexture = 0.822f,
        contactYRatioInTexture = 828f / 914f,
        visibleBottomRatioInTexture = 0.928f
    )
    VehicleVisualModel.LoganIII -> GhostVehicleCalibration(
        textureAspectHeightOverWidth = 914f / 1014f,
        visibleLeftRatioInTexture = 57f / 1014f,
        visibleRightRatioInTexture = 958f / 1014f,
        leftTireContactXRatioInTexture = 0.164f,
        rightTireContactXRatioInTexture = 0.836f,
        contactYRatioInTexture = 828f / 914f,
        visibleBottomRatioInTexture = 0.928f
    )
}
