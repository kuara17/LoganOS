package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.ui.graphics.Color

/**
 * Ghost Dual fixed OEM layout profile.
 * Reference: the user's two-dial Megane matrix cluster photo.
 * 4.20.4 retains the full-size dials and shortens the centre road scene.
 */
internal val GhostDualSceneSpec = GhostSceneSpec(
    mode = GhostLayoutMode.Dual,
    road = GhostRoadSpec(
        vanishingPoint = GhostPoint(800f, 378f),
        topY = 434f,
        fadeVisibleY = 468f,
        bottomY = 700f,
        topHalfWidth = 30f,
        bottomHalfWidth = 176f,
        clipLeft = 575f,
        clipRight = 1025f
    ),
    horizon = GhostHorizonSpec(
        center = GhostPoint(800f, 378f),
        outerWidth = 278f,
        outerHeight = 20f,
        middleWidth = 178f,
        middleHeight = 10f,
        coreWidth = 48f,
        coreHeight = 4f,
        color = Color(0xFF6AB8FF)
    ),
    vehicle = GhostVehiclePlacement(
        centerX = 800f,
        tireContactY = 646f,
        visibleWidth = 166f,
        shadowWidthMultiplier = 1.0f,
        shadowYOffset = 2f
    ),
    dual = GhostDualOverlaySpec(
        speedGauge = GhostGaugeSpec(
            bounds = GhostRect(75f, 50f, 500f, 500f),
            center = GhostPoint(325f, 300f),
            radius = 250f
        ),
        rpmGauge = GhostGaugeSpec(
            bounds = GhostRect(1025f, 50f, 500f, 500f),
            center = GhostPoint(1275f, 300f),
            radius = 250f
        ),
        speedValue = GhostRect(195f, 190f, 260f, 88f),
        speedUnit = GhostRect(230f, 270f, 190f, 32f),
        rpmValue = GhostRect(1145f, 190f, 260f, 88f),
        rpmUnit = GhostRect(1180f, 270f, 190f, 32f),
        instantHeader = GhostMetricSpec(
            bounds = GhostRect(135f, 555f, 380f, 32f),
            iconSize = 25f,
            iconGap = 8f
        ),
        instantValue = GhostRect(205f, 590f, 240f, 50f),
        instantUnit = GhostRect(185f, 636f, 280f, 30f),
        averageHeader = GhostMetricSpec(
            bounds = GhostRect(1085f, 555f, 380f, 32f),
            iconSize = 25f,
            iconGap = 8f
        ),
        averageValue = GhostRect(1155f, 590f, 240f, 50f),
        averageUnit = GhostRect(1135f, 636f, 280f, 30f),
        coolant = GhostRect(680f, 35f, 240f, 62f),
        status = GhostRect(1410f, 18f, 150f, 34f)
    )
)
