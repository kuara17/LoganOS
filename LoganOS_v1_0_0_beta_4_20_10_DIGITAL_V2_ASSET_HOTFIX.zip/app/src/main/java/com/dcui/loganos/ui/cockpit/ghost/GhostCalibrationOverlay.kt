package com.dcui.loganos.ui.cockpit.ghost

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

@Composable
internal fun GhostCalibrationOverlay(
    spec: GhostSceneSpec,
    vehicleCalibration: GhostVehicleCalibration,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val sx = size.width / GhostSceneSpec.DESIGN_WIDTH
        val sy = size.height / GhostSceneSpec.DESIGN_HEIGHT
        val grid = Color(0xFF4CC9F0).copy(alpha = 0.32f)
        for (x in 0..1600 step 100) {
            drawLine(grid, Offset(x * sx, 0f), Offset(x * sx, size.height), 1f)
        }
        for (y in 0..700 step 100) {
            drawLine(grid, Offset(0f, y * sy), Offset(size.width, y * sy), 1f)
        }
        drawLine(Color.Yellow, Offset(800f * sx, 0f), Offset(800f * sx, size.height), 2f)
        drawLine(
            Color.Yellow,
            Offset(0f, spec.road.vanishingPoint.y * sy),
            Offset(size.width, spec.road.vanishingPoint.y * sy),
            2f
        )
        drawCircle(
            Color.Magenta,
            7f * sx,
            Offset(spec.road.vanishingPoint.x * sx, spec.road.vanishingPoint.y * sy)
        )

        val roadPath = Path().apply {
            moveTo((spec.road.vanishingPoint.x - spec.road.topHalfWidth) * sx, spec.road.topY * sy)
            lineTo((spec.road.vanishingPoint.x + spec.road.topHalfWidth) * sx, spec.road.topY * sy)
            lineTo((spec.road.vanishingPoint.x + spec.road.bottomHalfWidth) * sx, spec.road.bottomY * sy)
            lineTo((spec.road.vanishingPoint.x - spec.road.bottomHalfWidth) * sx, spec.road.bottomY * sy)
            close()
        }
        drawPath(
            path = roadPath,
            color = Color.Cyan.copy(alpha = 0.85f),
            style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 7f)))
        )

        val geometry = GhostVehicleGeometry.calculate(spec.vehicle, vehicleCalibration)
        drawLogicalRect(geometry.vehicleRect, sx, sy, Color.Green)
        drawLogicalRect(geometry.shadowRect, sx, sy, Color(0xFFFFA000))
        drawCircle(Color.Red, 6f * sx, Offset(geometry.leftTireContact.x * sx, geometry.leftTireContact.y * sy))
        drawCircle(Color.Red, 6f * sx, Offset(geometry.rightTireContact.x * sx, geometry.rightTireContact.y * sy))

        spec.single?.let { overlay ->
            drawCircle(Color.White, 6f * sx, Offset(overlay.gauge.center.x * sx, overlay.gauge.center.y * sy))
            listOf(overlay.speedValue, overlay.speedUnit, overlay.rpmValue, overlay.status).forEach {
                drawLogicalRect(it, sx, sy, Color(0xFF00E5FF))
            }
        }
        spec.dual?.let { overlay ->
            drawCircle(Color.White, 6f * sx, Offset(overlay.speedGauge.center.x * sx, overlay.speedGauge.center.y * sy))
            drawCircle(Color.White, 6f * sx, Offset(overlay.rpmGauge.center.x * sx, overlay.rpmGauge.center.y * sy))
            listOf(
                overlay.speedValue,
                overlay.speedUnit,
                overlay.rpmValue,
                overlay.rpmUnit,
                overlay.instantValue,
                overlay.instantUnit,
                overlay.averageValue,
                overlay.averageUnit,
                overlay.status
            ).forEach { drawLogicalRect(it, sx, sy, Color(0xFF00E5FF)) }
        }

        // The 1600x700 artboard is cockpit-only. The lower red line marks the safe
        // pre-navigation edge, not the application's navigation itself.
        drawLine(
            color = Color(0xFFFF5252),
            start = Offset(0f, 690f * sy),
            end = Offset(size.width, 690f * sy),
            strokeWidth = 2f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))
        )
    }
}

private fun DrawScope.drawLogicalRect(
    rect: GhostRect,
    sx: Float,
    sy: Float,
    color: Color
) {
    drawRect(
        color = color,
        topLeft = Offset(rect.x * sx, rect.y * sy),
        size = Size(rect.width * sx, rect.height * sy),
        style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 6f)))
    )
}

internal data class GhostVehicleGeometryResult(
    val vehicleRect: GhostRect,
    val shadowRect: GhostRect,
    val leftTireContact: GhostPoint,
    val rightTireContact: GhostPoint
)

internal object GhostVehicleGeometry {
    fun calculate(
        placement: GhostVehiclePlacement,
        calibration: GhostVehicleCalibration
    ): GhostVehicleGeometryResult {
        val fullTextureWidth = placement.visibleWidth / calibration.visibleWidthRatioInTexture
        val fullTextureHeight = fullTextureWidth * calibration.textureAspectHeightOverWidth
        val left = placement.centerX - fullTextureWidth / 2f
        val top = placement.tireContactY - fullTextureHeight * calibration.contactYRatioInTexture
        val leftTire = GhostPoint(
            x = left + fullTextureWidth * calibration.leftTireContactXRatioInTexture,
            y = placement.tireContactY
        )
        val rightTire = GhostPoint(
            x = left + fullTextureWidth * calibration.rightTireContactXRatioInTexture,
            y = placement.tireContactY
        )
        val tireSpan = rightTire.x - leftTire.x
        val shadowWidth = maxOf(
            tireSpan * placement.shadowWidthMultiplier,
            placement.visibleWidth * 1.12f
        )
        val shadowHeight = shadowWidth * (260f / 1014f)
        val shadowRect = GhostRect(
            x = placement.centerX - shadowWidth / 2f,
            y = placement.tireContactY + placement.shadowYOffset - shadowHeight / 2f,
            width = shadowWidth,
            height = shadowHeight
        )
        return GhostVehicleGeometryResult(
            vehicleRect = GhostRect(left, top, fullTextureWidth, fullTextureHeight),
            shadowRect = shadowRect,
            leftTireContact = leftTire,
            rightTireContact = rightTire
        )
    }
}
