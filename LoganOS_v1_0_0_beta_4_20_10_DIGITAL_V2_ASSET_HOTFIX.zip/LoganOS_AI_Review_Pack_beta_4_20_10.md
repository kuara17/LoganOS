# LoganOS AI Review Pack — beta.4.20.10

## Goal
Replace the failed Digital V2 multi-layer road/vehicle grounding strategy with deterministic baked scene assets.

## Architecture decision
Digital V2 now resolves one image from `(scene, vehicle model, vehicle color)`. The bitmap already contains the road, vehicle, perspective, shadow and scene lighting. Compose still owns HUD/data/settings. OpenGL only presents the baked scene under the HUD; separate Digital V2 vehicle/road/shadow textures are disabled.

## Asset matrix
- Scenes: Mountain Lake, Snow Road, City Day, City Night
- Models: Logan I, Logan III
- Colors: Cherry Red, White, Gray, Blue, Green, Yellow
- Total: 48 WebP assets

## Important implementation details
- `digitalV2CompositeRes()` is the single resource resolver.
- Main GL background uses center-crop UV coordinates matching Compose `ContentScale.Crop`; source images are not stretched.
- `vehicleResId`, shadow IDs and road-map ID are zero for Digital V2 baked states.
- Settings mini-preview and scene tiles show the exact selected model/color composite.
- Digital V2 motion switch was removed because all current scenes are baked and the old road/wind path is intentionally inactive.

## Size/cleanup
Legacy Digital V2 background/road-map/shadow resources and unused Ghost legacy resources were removed. Five large active opaque WebPs were re-encoded at quality 90 to keep the GitHub source ZIP comfortably below 25 MB.

## Review questions
1. Confirm no code path still overlays a separate Digital V2 vehicle/shadow on the baked image.
2. Confirm `digitalV2CompositeRes()` covers all 48 combinations with no duplicate/missing resource.
3. Check OpenGL center-crop UV math for portrait/landscape stage consistency.
4. Confirm retained shared Logan vehicle assets are still required by non-Digital-V2 screens.
