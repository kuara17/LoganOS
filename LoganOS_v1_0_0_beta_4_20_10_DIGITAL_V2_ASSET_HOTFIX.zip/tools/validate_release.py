#!/usr/bin/env python3
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
APP = ROOT / 'app'
GRADLE = APP / 'build.gradle.kts'
MANIFEST = APP / 'src/main/AndroidManifest.xml'
DRAWABLE = APP / 'src/main/res/drawable-nodpi'


def fail(message: str) -> None:
    print(f'[FAIL] {message}')
    raise SystemExit(1)


def ok(message: str) -> None:
    print(f'[OK] {message}')

if not GRADLE.is_file():
    fail('app/build.gradle.kts missing')
if not MANIFEST.is_file():
    fail('AndroidManifest.xml missing')

text = GRADLE.read_text(encoding='utf-8')
vm = re.search(r'versionName\s*=\s*"([^"]+)"', text)
vc = re.search(r'versionCode\s*=\s*(\d+)', text)
if not vm or not vc:
    fail('versionName/versionCode not found')
version_name = vm.group(1)
version_code = int(vc.group(1))
if not re.fullmatch(r'1\.0\.0-beta\.\d+\.\d+\.\d+', version_name):
    fail(f'unexpected versionName: {version_name}')
if version_code <= 0:
    fail('versionCode must be positive')
ok(f'version {version_name} ({version_code})')

colors = ('cherry_red', 'white', 'gray', 'blue', 'green', 'yellow')
scenes = ('mountain_lake', 'snow_road', 'city_day', 'city_night')
models = ('logan1', 'logan3')
expected = {
    f'digital_v2_{scene}_{model}_{color}.webp'
    for scene in scenes for model in models for color in colors
}
actual = {p.name for p in DRAWABLE.glob('digital_v2_*.webp')}
missing = sorted(expected - actual)
extra = sorted(actual - expected)
if missing:
    fail('missing Digital V2 baked assets: ' + ', '.join(missing[:8]))
if extra:
    fail('unexpected/legacy Digital V2 WebP assets remain: ' + ', '.join(extra[:8]))
if len(actual) != 48:
    fail(f'expected 48 Digital V2 baked assets, got {len(actual)}')
ok('48 baked Digital V2 scene/model/color assets present')

legacy_names = (
    'digital_v2_mountain_lake_bg.webp', 'digital_v2_city_day_bg.webp',
    'digital_v2_city_night_bg.webp', 'digital_v2_snow_road_bg.webp',
    'digital_v2_ground_shadow_logan1.webp', 'digital_v2_ground_shadow_logan3.webp',
)
for name in legacy_names:
    if (DRAWABLE / name).exists():
        fail(f'legacy Digital V2 resource still present: {name}')
if list(DRAWABLE.glob('digital_v2_*_road_map.png')):
    fail('legacy Digital V2 road-map resources still present')
if list(DRAWABLE.glob('digital_v2_*_shadow_*.webp')):
    fail('legacy Digital V2 shadow resources still present')
ok('legacy Digital V2 road/car-compositing resources removed')

for pattern in ('*.jks', '*.keystore', '*.apk', '*.aab'):
    found = [p for p in ROOT.rglob(pattern) if '.gradle' not in p.parts]
    if found:
        fail(f'packaging must not include {pattern}: {found[0].relative_to(ROOT)}')
ok('no signing keys/APK/AAB payloads in source tree')
