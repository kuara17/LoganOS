@file:OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)

package com.dcui.loganos.ui.screens

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.net.Uri
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.dcui.loganos.R
import com.dcui.loganos.data.DriveHistoryItem
import com.dcui.loganos.data.TestHistoryItem
import com.dcui.loganos.health.VehicleHealthAnalyzer
import com.dcui.loganos.health.VehicleHealthFinding
import com.dcui.loganos.health.VehicleHealthLevel
import com.dcui.loganos.health.VehicleHealthReport
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.CockpitDensity
import com.dcui.loganos.model.CockpitTextSize
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.HeadUnitUiMode
import com.dcui.loganos.model.TripMetricReset
import com.dcui.loganos.obd.CrankAnalysisResult
import com.dcui.loganos.obd.CONTROL_HANDBRAKE_TEST_NAME
import com.dcui.loganos.obd.CONTROL_CLUTCH_TEST_NAME
import com.dcui.loganos.obd.CONTROL_BRAKE_TEST_NAME
import com.dcui.loganos.obd.CONTROL_GEAR_STATIC_TEST_NAME
import com.dcui.loganos.obd.CONTROL_GEAR_DRIVE_TEST_NAME
import com.dcui.loganos.obd.TRIP_CONTEXT_IDLE_TEST_NAME
import com.dcui.loganos.obd.TRIP_CONTEXT_DRIVE_TEST_NAME
import com.dcui.loganos.obd.isTripContextDeveloperTest
import com.dcui.loganos.obd.FUEL_LEVEL_DISCOVERY_TEST_NAME
import com.dcui.loganos.obd.FUEL_CANDIDATE_CONTROL_TEST_NAME
import com.dcui.loganos.obd.isKwp026DeveloperTest
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.StartEvent
import com.dcui.loganos.obd.StartConfidence
import com.dcui.loganos.obd.StartThermalClass
import com.dcui.loganos.obd.ObdConnectionHealth
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.DataCard
import com.dcui.loganos.ui.components.DigitalSpeedPanel
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.LoganWordmark
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.RouteMapCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.components.SpeedPanel
import com.dcui.loganos.ui.components.ConsumptionSparkline
import com.dcui.loganos.ui.components.acAccentColor
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.rememberConsumptionTrend
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.cockpit.ClassicCockpit
import com.dcui.loganos.ui.cockpit.DigitalV2Cockpit
import com.dcui.loganos.ui.cockpit.GhostSinglePhoneWideCockpit
import com.dcui.loganos.ui.cockpit.GhostSingleHeadUnitCockpit
import com.dcui.loganos.ui.cockpit.GhostSingleCockpit
import com.dcui.loganos.ui.cockpit.GhostDualOriginalCockpit
import com.dcui.loganos.ui.cockpit.GhostDualPhoneWideCockpit
import com.dcui.loganos.ui.cockpit.GhostDualHeadUnitCockpit
import com.dcui.loganos.ui.cockpit.PremiumDriveCockpit
import com.dcui.loganos.ui.theme.LoganPalette
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


private val LoganFuelInstantRed = Color(0xFFE53935)

enum class MainTab {
    Cockpit,
    Trip,
    VehicleHealth,
    Technical,
    Settings
}

private fun tabLabel(tab: MainTab, language: AppLanguage): String = when (tab) {
    MainTab.Cockpit -> if (language == AppLanguage.English) "Cockpit" else "Kokpit"
    MainTab.Trip -> if (language == AppLanguage.English) "Trip" else "Sürüş"
    MainTab.VehicleHealth -> if (language == AppLanguage.English) "Health" else "Araç Sağlığı"
    MainTab.Technical -> if (language == AppLanguage.English) "Tech" else "Teknik"
    MainTab.Settings -> if (language == AppLanguage.English) "Settings" else "Ayarlar"
}

private fun tabIcon(tab: MainTab): CardIcon = when (tab) {
    MainTab.Cockpit -> CardIcon.Speed
    MainTab.Trip -> CardIcon.Distance
    MainTab.VehicleHealth -> CardIcon.EngineFault
    MainTab.Technical -> CardIcon.EcuStatus
    MainTab.Settings -> CardIcon.Settings
}


private fun cockpitTextScale(settings: LoganSettings): Float = when (settings.cockpitTextSize) {
    CockpitTextSize.Small -> 0.90f
    CockpitTextSize.Normal -> 1.00f
    CockpitTextSize.Large -> 1.22f
}

private fun headUnitCockpitTextScale(settings: LoganSettings): Float = when (settings.cockpitTextSize) {
    CockpitTextSize.Small -> 0.96f
    CockpitTextSize.Normal -> 1.14f
    CockpitTextSize.Large -> 1.30f
}

private fun cockpitCardHeight(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 80.dp
    CockpitDensity.Balanced -> 96.dp
    CockpitDensity.Wide -> 112.dp
}

private fun cockpitSpacing(settings: LoganSettings): androidx.compose.ui.unit.Dp = when (settings.cockpitDensity) {
    CockpitDensity.Compact -> 2.dp
    CockpitDensity.Balanced -> 6.dp
    CockpitDensity.Wide -> 10.dp
}

@Composable
fun LoganAppShell(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    averageDistanceKm: Double,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onExportTechnicalSession: (Long) -> Unit,
    onCreateSupportPackage: () -> Uri?,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onLoadDriveHistoryDetail: (Long) -> Unit,
    onClearDriveHistoryDetail: () -> Unit,
    onPinDriveHistory: (Long, Boolean) -> Unit,
    onDeleteDriveHistory: (Long) -> Unit,
    onExportDriveHistory: (Long) -> Unit,
    onExportGpsRoute: (Long) -> Unit,
    onPinTestHistory: (Long, Boolean) -> Unit,
    onDeleteTestHistory: (Long) -> Unit,
    onExportTestHistory: (Long) -> Unit,
    onExportAllHistory: () -> Unit,
    onCreateDataBackup: () -> Unit,
    onRestoreDataBackup: () -> Unit,
    onFuelRefillLitersSave: (String) -> Boolean
) {
    var tab by remember { mutableStateOf(MainTab.Cockpit) }
    val configuration = LocalConfiguration.current
    val resolvedHeadUnit = settings.deviceMode == DeviceMode.HeadUnit ||
        (settings.deviceMode == DeviceMode.Auto && configuration.smallestScreenWidthDp >= 600)
    val premiumNavigationPalette = if (
        tab == MainTab.Cockpit && (
            (resolvedHeadUnit && settings.headUnitUiMode == HeadUnitUiMode.PremiumDrive) ||
                settings.gaugeStyle == GaugeStyle.GhostSingle || settings.gaugeStyle == GaugeStyle.GhostDual || settings.gaugeStyle == GaugeStyle.GhostSingleOriginal || settings.gaugeStyle == GaugeStyle.GhostDualOriginal
        )
    ) {
        palette.copy(
            background = Color(0xFF050A12),
            surface = Color(0xFF111B2A),
            surfaceVariant = Color(0xFF17263A),
            textPrimary = Color(0xFFF5F8FC),
            textSecondary = Color(0xFF95A9C0),
            muted = Color(0xFF71849A),
            line = Color(0xFF2B405C),
            accent = Color(0xFF5FE18A),
            blue = Color(0xFF5BB7FF)
        )
    } else {
        palette
    }
    val context = LocalContext.current
    val completionPrefs = remember(context) {
        context.getSharedPreferences("loganos_drive_completion_ui", Context.MODE_PRIVATE)
    }
    var completionWatchReady by remember { mutableStateOf(false) }
    var lastCompletedDriveId by remember {
        mutableStateOf(
            completionPrefs.getLong("last_seen_completed_drive_id", -1L)
                .takeIf { it >= 0L }
        )
    }
    var completedDriveSummary by remember { mutableStateOf<DriveHistoryItem?>(null) }
    LaunchedEffect(obdState.driveHistory) {
        val newestCompleted = obdState.driveHistory
            .filterNot { it.activeLike }
            .maxByOrNull { it.id }
        if (!completionWatchReady) {
            // App/OBD startup is only a baseline. Historical PARKED records may
            // be finalized in the background at this point; never present those
            // old records as if the just-finished drive ended now.
            val baselineId = listOfNotNull(lastCompletedDriveId, newestCompleted?.id).maxOrNull()
            lastCompletedDriveId = baselineId
            baselineId?.let { completionPrefs.edit().putLong("last_seen_completed_drive_id", it).apply() }
            completionWatchReady = true
        } else if (newestCompleted != null && newestCompleted.id != lastCompletedDriveId) {
            lastCompletedDriveId = newestCompleted.id
            completionPrefs.edit().putLong("last_seen_completed_drive_id", newestCompleted.id).apply()

            // Only a record whose actual end timestamp is recent is eligible for
            // the completion dialog. A record finalized on a later reconnect keeps
            // its old ignition-off end time and is therefore handled silently.
            val endedAt = newestCompleted.endedAtMs
            val ageMs = endedAt?.let { System.currentTimeMillis() - it }
            val endedRecently = ageMs != null && ageMs in 0L..120_000L
            if (endedRecently) completedDriveSummary = newestCompleted
        }
    }
    val resolvedHeadUnitShell = settings.deviceMode == DeviceMode.HeadUnit ||
        (settings.deviceMode == DeviceMode.Auto && configuration.smallestScreenWidthDp >= 600)
    val landscapeGhostCockpit = tab == MainTab.Cockpit &&
        configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&
        (settings.gaugeStyle == GaugeStyle.GhostSingle || settings.gaugeStyle == GaugeStyle.GhostDual || settings.gaugeStyle == GaugeStyle.GhostSingleOriginal || settings.gaugeStyle == GaugeStyle.GhostDualOriginal)
    val headUnitCockpit = tab == MainTab.Cockpit &&
        configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&
        resolvedHeadUnitShell
    val immersiveCockpit = landscapeGhostCockpit || headUnitCockpit
    val rootView = LocalView.current
    val activity = context as? Activity
    val guidedDiagnosticActive = obdState.activeDeveloperTest == FUEL_LEVEL_DISCOVERY_TEST_NAME ||
        isKwp026DeveloperTest(obdState.activeDeveloperTest) ||
        isTripContextDeveloperTest(obdState.activeDeveloperTest)

    DisposableEffect(guidedDiagnosticActive, rootView) {
        val previousKeepScreenOn = rootView.keepScreenOn
        if (guidedDiagnosticActive) rootView.keepScreenOn = true
        onDispose { rootView.keepScreenOn = previousKeepScreenOn }
    }

    DisposableEffect(immersiveCockpit, rootView, activity) {
        val controller = ViewCompat.getWindowInsetsController(rootView)
        val decorView = activity?.window?.decorView
        @Suppress("DEPRECATION")
        val previousSystemUiVisibility = decorView?.systemUiVisibility

        if (immersiveCockpit) {
            controller?.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller?.hide(WindowInsetsCompat.Type.statusBars())
            // The AC8227L reports API 27 behavior. Keep the legacy fullscreen
            // flags alongside WindowInsetsController so the head-unit launcher
            // cannot leave a white status strip above Premium Drive.
            @Suppress("DEPRECATION")
            decorView?.systemUiVisibility =
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            // Some Android head units keep a 1px status-bar divider even when
            // the status bar is hidden through WindowInsetsController. Force the
            // actual window fullscreen flag as well so no white strip remains.
            activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        } else {
            controller?.show(WindowInsetsCompat.Type.statusBars())
        }
        onDispose {
            if (immersiveCockpit) {
                controller?.show(WindowInsetsCompat.Type.statusBars())
                activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
                if (previousSystemUiVisibility != null) {
                    @Suppress("DEPRECATION")
                    decorView?.systemUiVisibility = previousSystemUiVisibility
                }
            }
        }
    }

    val navigationHorizontalInsets = WindowInsets.navigationBarsIgnoringVisibility
        .only(WindowInsetsSides.Horizontal)
    val shellInsets = when {
        headUnitCockpit -> {
            // Reserve side navigation space even while transient system controls are hidden.
            Modifier.windowInsetsPadding(navigationHorizontalInsets)
        }
        landscapeGhostCockpit -> {
            // Preserve both the display cutout and visibility-independent side navigation area.
            Modifier
                .displayCutoutPadding()
                .windowInsetsPadding(navigationHorizontalInsets)
        }
        else -> Modifier
            .statusBarsPadding()
            .windowInsetsPadding(navigationHorizontalInsets)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(premiumNavigationPalette.background)
            .then(shellInsets)
    ) {
        Box(modifier = Modifier.weight(1f)) {
            when (tab) {
                MainTab.Cockpit -> DashboardContent(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    averageDistanceKm = averageDistanceKm,
                    obdState = obdState,
                    onResetMetrics = onResetMetrics,
                    onEndTripNow = onEndTripNow,
                    onRefreshObdDevices = onRefreshObdDevices,
                    onSelectObdDevice = onSelectObdDevice,
                    onConnectObd = onConnectObd,
                    onDisconnectObd = onDisconnectObd
                )
                MainTab.Trip -> TripPage(
                    palette = palette,
                    snapshot = snapshot,
                    settings = settings,
                    obdState = obdState,
                    onEndTripNow = onEndTripNow,
                    onRefreshHistory = onRefreshHistory,
                    onLoadHistoryDetail = onLoadDriveHistoryDetail,
                    onClearHistoryDetail = onClearDriveHistoryDetail,
                    onPinHistory = onPinDriveHistory,
                    onDeleteHistory = onDeleteDriveHistory,
                    onExportHistory = onExportDriveHistory,
                    onExportGpsRoute = onExportGpsRoute,
                    onExportAllHistory = onExportAllHistory
                )
                MainTab.VehicleHealth -> VehicleHealthPage(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    obdState = obdState,
                    onStartCrankAnalysis = onStartCrankAnalysis,
                    onClearManualCrankTests = onClearManualCrankTests,
                    onRefreshHistory = onRefreshHistory,
                    onPinHistory = onPinTestHistory,
                    onDeleteHistory = onDeleteTestHistory,
                    onExportHistory = onExportTestHistory
                )
                MainTab.Technical -> TechnicalPage(palette, settings, snapshot, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onCreateSupportPackage, onClearLastObdLog, onClearAllObdLogs)
                MainTab.Settings -> SettingsScreen(
                    palette,
                    settings,
                    obdState,
                    snapshot,
                    { requested ->
                        val requestedGhost = requested.gaugeStyle == GaugeStyle.GhostSingle ||
                            requested.gaugeStyle == GaugeStyle.GhostDual ||
                            requested.gaugeStyle == GaugeStyle.GhostSingleOriginal ||
                            requested.gaugeStyle == GaugeStyle.GhostDualOriginal
                        // Ghost and Premium Drive are mutually exclusive surfaces. Selecting a
                        // Ghost style on a Double always resolves to Standard Cockpit so the
                        // Ghost composable and its intro cannot be hidden by Premium Drive.
                        val updated = if (resolvedHeadUnit && requestedGhost) {
                            requested.copy(headUnitUiMode = HeadUnitUiMode.Standard)
                        } else {
                            requested
                        }
                        val enteringGhost = requestedGhost && updated.gaugeStyle != settings.gaugeStyle
                        val swappingGhostDual = updated.gaugeStyle == GaugeStyle.GhostDual &&
                            updated.ghostDualSpeedOnLeft != settings.ghostDualSpeedOnLeft
                        onSettingsChange(updated)
                        if (enteringGhost || swappingGhostDual) tab = MainTab.Cockpit
                    },
                    onResetSetup,
                    onResetMetrics,
                    onEndTripNow,
                    onRefreshObdDevices,
                    onSelectObdDevice,
                    onConnectObd,
                    onDisconnectObd,
                    onSaveObdLog,
                    onShareObdLog,
                    onExportTechnicalSession,
                    onCreateSupportPackage,
                    onClearLastObdLog,
                    onClearAllObdLogs,
                    onDeveloperTestStart,
                    onDeveloperTestEnd,
                    onStartCrankAnalysis,
                    onClearManualCrankTests,
                    onRefreshHistory,
                    { tab = MainTab.Trip },
                    onExportAllHistory,
                    onCreateDataBackup,
                    onRestoreDataBackup,
                    onFuelRefillLitersSave
                )
            }
            DeveloperTestOverlay(palette, obdState, onDeveloperTestEnd)
        }
        BottomNavigationBar(
            palette = premiumNavigationPalette,
            current = tab,
            language = settings.language,
            largeTouchTargets = resolvedHeadUnit
        ) { tab = it }
    }

    completedDriveSummary?.let { item ->
        val tr = settings.language != AppLanguage.English
        AlertDialog(
            onDismissRequest = { completedDriveSummary = null },
            title = {
                Text(
                    if (tr) "Sürüş tamamlandı" else "Drive completed",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, settings.language), color = palette.textSecondary, fontSize = 13.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompletionMetric(palette, if (tr) "Mesafe" else "Distance", String.format(Locale.US, "%.1f km", item.distanceKm), Modifier.weight(1f))
                        CompletionMetric(palette, if (tr) "Süre" else "Duration", historyDuration(item.durationMs), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompletionMetric(palette, if (tr) "Ortalama" else "Average", item.averageL100?.let { String.format(Locale.US, "%.1f L/100 km", it) } ?: "--", Modifier.weight(1f))
                        CompletionMetric(palette, if (tr) "Maliyet" else "Cost", historyCostText(item.fuelUsedL, settings.fuelPriceText), Modifier.weight(1f))
                    }
                    Text(
                        buildString {
                            append(if (tr) "Azami hız: " else "Max speed: ")
                            append(item.maxSpeedKmh?.let { "$it km/h" } ?: "--")
                            append("  •  ")
                            append(if (tr) "Azami devir: " else "Max RPM: ")
                            append(item.maxRpm?.let { "$it rpm" } ?: "--")
                        },
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { completedDriveSummary = null; tab = MainTab.Trip }) {
                    Text(if (tr) "Sürüşü incele" else "View drive")
                }
            },
            dismissButton = {
                TextButton(onClick = { completedDriveSummary = null }) {
                    Text(if (tr) "Kapat" else "Close")
                }
            }
        )
    }
}

@Composable
private fun CompletionMetric(
    palette: LoganPalette,
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    OemCard(palette, modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, color = palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Text(value, color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

private fun controlDiscoveryActivePlan(testName: String?): String? = when (testName) {
    CONTROL_HANDBRAKE_TEST_NAME -> "8 adım • yaklaşık 12–25 dk\nİlk iki aşamada cevap veren modüller tam taranır; sonraki altı aşamada yalnız değişen bloklar 3 tur doğrulanır. Ayak freni basılı kalırken ÇEK/İNDİR komutunu uygula."
    CONTROL_CLUTCH_TEST_NAME -> "6 adım × 5 sn • yaklaşık 3 dk\nVites boşta ve el freni çekiliyken debriyajı ekrandaki sırayla tamamen bırak veya sonuna kadar bas."
    CONTROL_BRAKE_TEST_NAME -> "6 adım × 5 sn • yaklaşık 3 dk\nVites boşta ve el freni çekiliyken fren pedalını ekrandaki sırayla bırak veya normal kuvvetle bas."
    CONTROL_GEAR_STATIC_TEST_NAME -> "13 adım • yaklaşık 5 dk\nDebriyaj ve ayak freni basılıyken Boş→1→Boş→2→Boş→3→Boş→4→Boş→5→Boş→Geri→Boş sırasını uygula."
    CONTROL_GEAR_DRIVE_TEST_NAME -> "5 sürüş adımı • yaklaşık 5 dk\nTelefonu sabitle; ekrandaki vites ve minimum hız oluşana kadar sayaç başlamaz. Sürüş sırasında telefona dokunma."
    else -> null
}

@Composable
private fun DeveloperTestOverlay(
    palette: LoganPalette,
    obdState: ObdState,
    onEnd: () -> Unit
) {
    val activeTest = obdState.activeDeveloperTest
    val doneMessage = obdState.developerTestDoneMessage
    if (activeTest == null && doneMessage == null) return

    val fuelDiscovery = activeTest == FUEL_LEVEL_DISCOVERY_TEST_NAME
    val dynamic026 = isKwp026DeveloperTest(activeTest)
    val fuelCandidateControl = activeTest == FUEL_CANDIDATE_CONTROL_TEST_NAME
    val fuelRefill = activeTest?.startsWith("Yakıt •") == true
    val controlDiscovery = activeTest?.startsWith("Kontrol •") == true
    val tripContextTest = isTripContextDeveloperTest(activeTest)
    val guidedDiagnostic = fuelDiscovery || dynamic026 || tripContextTest
    var minimized by remember(activeTest) { mutableStateOf(false) }
    var showStopConfirmation by remember(activeTest) { mutableStateOf(false) }
    LaunchedEffect(activeTest, doneMessage, obdState.developerTestOverlayRequestNonce) {
        if (activeTest != null || doneMessage != null) {
            minimized = false
            showStopConfirmation = false
        }
    }

    if (guidedDiagnostic && minimized) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            contentAlignment = Alignment.TopCenter
        ) {
            OemCard(
                palette = palette,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 620.dp)
                    .clickable { minimized = false }
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                when {
                                    fuelCandidateControl -> "Fuel Candidate Control sürüyor"
                                    fuelRefill -> "Yakıt doğrulama bölümü sürüyor"
                                    controlDiscovery && activeTest == CONTROL_HANDBRAKE_TEST_NAME -> "El freni doğrulaması sürüyor"
                                    controlDiscovery -> "Kontrol keşfi sürüyor"
                                    tripContextTest -> "Trip bağlamı canlılık testi sürüyor"
                                    dynamic026 -> "0x26 araştırma bölümü sürüyor"
                                    else -> "Depo hazırlık taraması sürüyor"
                                },
                                color = palette.textPrimary,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                obdState.developerTestPhaseText ?: "Hazırlanıyor",
                                color = palette.textSecondary,
                                fontSize = 12.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                        Text(
                            obdState.developerTestProgressPercent?.let { "%$it • Aç ›" } ?: "Aç ›",
                            color = palette.accent,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                    obdState.developerTestProgressPercent?.let { percent ->
                        LinearProgressIndicator(
                            progress = { percent.coerceIn(0, 100) / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = palette.accent,
                            trackColor = palette.surfaceVariant
                        )
                    }
                }
            }
        }
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.58f))
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        OemCard(
            palette = palette,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 620.dp)
                .then(if (guidedDiagnostic && activeTest != null) Modifier.fillMaxHeight(0.92f) else Modifier)
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(13.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .then(if (guidedDiagnostic && activeTest != null) Modifier.verticalScroll(rememberScrollState()) else Modifier)
            ) {
                if (activeTest != null) {
                    Text(
                        text = if (activeTest == CONTROL_HANDBRAKE_TEST_NAME) "El freni sinyali son doğrulama" else activeTest,
                        color = palette.textPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = obdState.developerTestPhaseText ?: "Hazırlanıyor",
                        color = palette.accent,
                        fontSize = if (guidedDiagnostic) 20.sp else 30.sp,
                        lineHeight = if (guidedDiagnostic) 25.sp else 34.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )

                    if (activeTest == CONTROL_HANDBRAKE_TEST_NAME) {
                        obdState.developerTestStageLabel?.let { stage ->
                            Text(
                                text = stage,
                                color = if (stage == "ÖLÇÜM") palette.accent else palette.blue,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Black,
                                textAlign = TextAlign.Center
                            )
                        }
                        obdState.developerTestStepLabel?.let { label ->
                            OemCard(palette = palette, modifier = Modifier.fillMaxWidth()) {
                                Column(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = palette.textPrimary,
                                        fontSize = 28.sp,
                                        lineHeight = 32.sp,
                                        fontWeight = FontWeight.Black,
                                        textAlign = TextAlign.Center
                                    )
                                    Text(
                                        text = "AYAK FRENİ BASILI • VİTES BOŞ • ARAÇ SABİT",
                                        color = palette.textSecondary,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center
                                    )
                                    val stepIndex = obdState.developerTestStepIndex
                                    val stepTotal = obdState.developerTestStepTotal
                                    if (stepIndex != null && stepTotal != null) {
                                        Text(
                                            text = "Adım $stepIndex / $stepTotal",
                                            color = palette.accent,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (controlDiscovery) {
                        controlDiscoveryActivePlan(activeTest)?.let { plan ->
                            Text(
                                text = plan,
                                color = palette.textSecondary,
                                fontSize = 13.sp,
                                lineHeight = 18.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    if (guidedDiagnostic) {
                        val percent = obdState.developerTestProgressPercent
                        if (percent != null) {
                            LinearProgressIndicator(
                                progress = { percent.coerceIn(0, 100) / 100f },
                                modifier = Modifier.fillMaxWidth(),
                                color = palette.accent,
                                trackColor = palette.surfaceVariant
                            )
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            FuelProgressMetric(
                                palette,
                                "İlerleme",
                                percent?.let { "%$it" } ?: "--"
                            )
                            FuelProgressMetric(
                                palette,
                                "Geçen",
                                formatTestDuration(obdState.developerTestElapsedSec)
                            )
                            FuelProgressMetric(
                                palette,
                                "Yaklaşık kalan",
                                obdState.developerTestEstimatedRemainingSec?.let(::formatTestDuration) ?: "Hesaplanıyor"
                            )
                        }
                        obdState.developerTestCurrentTarget?.takeIf { it.isNotBlank() }?.let { target ->
                            Text(
                                text = "Şu an: $target",
                                color = palette.blue,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                        Text(
                            text = buildString {
                                append("Geçerli ${obdState.developerTestValidFrameCount} • Geçersiz ${obdState.developerTestInvalidFrameCount}")
                                obdState.developerTestExpectedPasses?.let { expected ->
                                    append(" • Tur ${obdState.developerTestSuccessfulPasses}/$expected")
                                    if (obdState.developerTestFailedPasses > 0) append(" • Eksik ${obdState.developerTestFailedPasses}")
                                }
                            },
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }

                    obdState.developerTestProgressText?.takeIf { it.isNotBlank() }?.let { progress ->
                        Text(
                            text = progress,
                            color = palette.textPrimary,
                            fontSize = if (guidedDiagnostic) 16.sp else 22.sp,
                            lineHeight = if (guidedDiagnostic) 21.sp else 26.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                    obdState.developerTestRemainingSec?.let { remaining ->
                        Text(
                            text = if (fuelCandidateControl || remaining >= 60) formatTestDuration(remaining.toLong()) else "$remaining sn",
                            color = palette.textPrimary,
                            fontSize = 64.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                    }
                    Text(
                        text = when {
                            fuelCandidateControl -> "Bu yakıtsız bir kontrol testidir. Başlangıçta motor rölantide 21A0[39] ve 21CC[9] üç tur okunur. Ardından motor ve kontak tamamen kapatılır, 15 dakika beklenir ve yakıt eklemeden motor yeniden çalıştırılarak aynı ölçüm tekrarlanır. Uygulamayı küçültebilir veya telefonu kilitleyebilirsin; geçen ve kalan süre korunur. Araç düz zeminde, vites boş ve el freni çekili kalsın."
                            fuelDiscovery -> "Bu yalnız hazırlık taramasıdır; bugün yakıt alma. Kontak açık, motor kapalı ve araç sabit kalmalı. Canlı OBD değerleri tarama boyunca geçici olarak durur. Tarama genellikle 10–20 dakika sürer. Uygulamayı zorla kapatmayın; ekranı küçültseniz bile foreground hizmeti ve bildirim ilerlemeyi gösterir."
                            fuelRefill -> "Bu, Gerçek Yakıt Dolum Doğrulaması içindeki bağımsız bir bölümdür. Ekrandaki süreli yönergeyi uygula. Motor veya kontak durumunu yalnız bölüm başlamadan önce değiştir; pompa başında uygulamayla işlem yapma. Marş sonrası RPM gelmezse LoganOS OBD/KWP oturumunu otomatik yeniler ve aynı adımı sürdürür."
                            tripContextTest -> if (activeTest == TRIP_CONTEXT_IDLE_TEST_NAME) {
                                "Motor rölantide, araç tamamen sabit ve mümkünse klima kapalı kalsın. Ekranda kalan süre, başlangıç/güncel fuelUsedL, yakıt farkı ve Trip context yaşı canlı gösterilir. OBD kesilirse sayaç duraklar; tamamlanan örnekler korunur."
                            } else {
                                "Testi araç güvenli biçimde dururken başlat. Telefonu sabitle; sürüş sırasında ekrana dokunma. LoganOS 1 km hedefe kadar tripDistanceKm, fuelUsedL ve Trip context freshness değerlerini kaydeder; ardından güvenli duruş ister."
                            }
                            controlDiscovery -> if (activeTest == CONTROL_HANDBRAKE_TEST_NAME) {
                                "Bu KOEO tam keşif doğrudan LoganOS içinde çalışır; Pydroid ve pyjnius gerekmez. İlk aşamada fiziksel KWP adresleri 0x10–0x7F araştırılır ve cevap veren her modülde 2100–21FF salt-okunur taranır. İkinci tam tarama el freni indirilmişken alınır; yalnız değişen bloklar sonraki altı aşamada üçer tur doğrulanır. Ölçüm sırasında kolu oynatma. Bağlantı kesilirse test aynı aşamada duraklar."
                            } else {
                                "Bu bağımsız bölüm el freni, debriyaj, fren veya vites durumunu hedefli salt-okuma bloklarıyla kaydeder. Ekrandaki konumu belirtilen süre boyunca koru. Sürüş bölümünde telefonu arka plana al ve telefonla ilgilenme; tam 2100–21FF taraması yapılmaz."
                            }
                            dynamic026 -> "Bu, 0x26 Dinamik Veri Doğrulama altındaki bağımsız bir bölümdür. Ekrandaki yönergeyi uygula; motor veya kontak durumunu yalnız bölüm başlamadan önce değiştir. Canlı RPM, hız, süre ve taranan blok ekranda görünür. Bağlantı kesilirse bölüm duraklar; tamamlanan okumalar korunur. Orta güvenli 0x7A/21A0[39] ve 0x7A/21CC[9] adayları ile bağlam blokları ham olarak kaydedilir; doğrulanmamış hiçbir değer yakıt seviyesi olarak gösterilmez."
                            else -> "Ekrandaki komutu uygula. Test boyunca OBD verisi ve SQL log işaretleri kaydedilir."
                        },
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp,
                        textAlign = TextAlign.Center
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (guidedDiagnostic) {
                            Button(
                                onClick = { minimized = true },
                                colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant)
                            ) {
                                Text("Küçült • üst karttan geri aç", color = palette.textPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                        Button(
                            onClick = { if (guidedDiagnostic) showStopConfirmation = true else onEnd() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                        ) {
                            Text(if (guidedDiagnostic) "Durdur ve kısmi paket oluştur" else "Testi Bitir", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Text(
                        text = doneMessage ?: "Test bitti",
                        color = palette.accent,
                        fontSize = 26.sp,
                        fontWeight = FontWeight.Black,
                        textAlign = TextAlign.Center
                    )
                    obdState.developerTestProgressPercent?.let { percent ->
                        LinearProgressIndicator(
                            progress = { percent.coerceIn(0, 100) / 100f },
                            modifier = Modifier.fillMaxWidth(),
                            color = palette.accent,
                            trackColor = palette.surfaceVariant
                        )
                    }
                    Text(
                        text = when {
                            doneMessage?.contains("yarım", ignoreCase = true) == true ->
                                "Uygulama veya Android işlemi taramayı durdurdu. Kısmi paket korunmuştur; hazırlık taramasını baştan çalıştırın."
                            doneMessage?.contains("kısmi", ignoreCase = true) == true ->
                                "Tarama kullanıcı tarafından durduruldu. Oluşturulan paket kısmi veridir ve kararlı hazırlık profili yerine geçmez."
                            doneMessage?.contains("Yakıt adayı", ignoreCase = true) == true ->
                                "Fuel Candidate Control ZIP'i oluşturuldu. Yakıt eklenmeden alınan başlangıç ve 15 dakikalık kontak kapalı bekleme sonrası ölçümler karşılaştırma için kaydedildi."
                            doneMessage?.contains("0x26", ignoreCase = true) == true ->
                                "Dinamik test ZIP'i oluşturuldu. 0x7A/21A0[39], 0x7A/21CC[9] ve bağlam blokları kontrollü araç durumlarıyla birlikte kaydedildi."
                            doneMessage?.contains("depo", ignoreCase = true) == true ->
                                "Hazırlık ZIP'i oluşturuldu. Bu dosyayı analiz için gönder; gerçek yakıt alma testi yalnız doğrulanan modül ve kimliklerle hazırlanacak."
                            else -> "Test tamamlandı."
                        },
                        color = palette.textSecondary,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Center
                    )
                    obdState.savedLogPath?.takeIf { it.isNotBlank() }?.let { path ->
                        Text(
                            text = path,
                            color = palette.textPrimary,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center,
                            maxLines = 3,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Button(
                        onClick = onEnd,
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Text("Kapat", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showStopConfirmation && activeTest != null) {
        AlertDialog(
            onDismissRequest = { showStopConfirmation = false },
            title = { Text("Testi sonlandır?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "Test henüz tamamlanmadı. Yalnız alınmış geçerli ham kayıtlar korunacak ve sonuç kullanıcı tarafından iptal edildi olarak işaretlenecek.",
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showStopConfirmation = false
                        onEnd()
                    }
                ) { Text("Evet • kısmi paketi oluştur", fontWeight = FontWeight.Black) }
            },
            dismissButton = {
                TextButton(onClick = { showStopConfirmation = false }) { Text("Teste dön") }
            }
        )
    }
}

@Composable
private fun FuelProgressMetric(
    palette: LoganPalette,
    label: String,
    value: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = palette.textSecondary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(value, color = palette.textPrimary, fontSize = 14.sp, fontWeight = FontWeight.Black)
    }
}

private fun formatTestDuration(seconds: Long?): String {
    if (seconds == null) return "--"
    val safe = seconds.coerceAtLeast(0L)
    val minutes = safe / 60L
    val remaining = safe % 60L
    return "%02d:%02d".format(Locale.US, minutes, remaining)
}

@Composable
private fun DashboardContent(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    averageDistanceKm: Double,
    obdState: ObdState,
    onResetMetrics: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit
) {
    var showResetDialog by remember { mutableStateOf(false) }
    var showObdQuickDialog by remember { mutableStateOf(false) }
    var showMovingWarning by remember { mutableStateOf(false) }
    val configuration = LocalConfiguration.current

    val onObdPillClick = {
        if ((snapshot.speedKmh ?: 0) > 0) {
            showMovingWarning = true
        } else {
            onRefreshObdDevices()
            showObdQuickDialog = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val portrait = maxWidth <= maxHeight
        val ghostSingle = settings.gaugeStyle == GaugeStyle.GhostSingle
        val ghostDual = settings.gaugeStyle == GaugeStyle.GhostDual
        val ghostSingleOriginal = settings.gaugeStyle == GaugeStyle.GhostSingleOriginal
        val ghostDualOriginal = settings.gaugeStyle == GaugeStyle.GhostDualOriginal
        val resolvedHeadUnit = settings.deviceMode == DeviceMode.HeadUnit ||
            (settings.deviceMode == DeviceMode.Auto && configuration.smallestScreenWidthDp >= 600)

        // Ghost Single is the approved baked former Original stack. The old portrait Ghost Single is retired.
        if (!portrait && ghostDualOriginal) {
            GhostDualOriginalCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                showHeadUnitTabs = resolvedHeadUnit,
                onOpenReset = { showResetDialog = true }
            )
        } else if (!portrait && ghostSingleOriginal) {
            GhostSingleCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                showHeadUnitTabs = resolvedHeadUnit,
                onOpenReset = { showResetDialog = true }
            )
        } else if (resolvedHeadUnit && !portrait && ghostSingle) {
            GhostSingleCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                showHeadUnitTabs = true,
                onOpenReset = { showResetDialog = true }
            )
        } else if (resolvedHeadUnit && !portrait && ghostDual) {
            GhostDualHeadUnitCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                onOpenReset = { showResetDialog = true }
            )
        } else if (!portrait && ghostSingle) {
            GhostSingleCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                showHeadUnitTabs = false,
                onOpenReset = { showResetDialog = true }
            )
        } else if (!portrait && ghostDual) {
            GhostDualPhoneWideCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                onOpenReset = { showResetDialog = true }
            )
        } else if (settings.gaugeStyle == GaugeStyle.DigitalV2) {
            DigitalV2Cockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                portrait = portrait,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        } else if (resolvedHeadUnit && settings.headUnitUiMode == HeadUnitUiMode.PremiumDrive) {
            PremiumDriveCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        } else if (settings.gaugeStyle == GaugeStyle.ClassicOem) {
            ClassicCockpit(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                portrait = portrait,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick,
                textScale = if (resolvedHeadUnit) headUnitCockpitTextScale(settings) else 1.0f
            )
        } else if (portrait) {
            DashboardPortrait(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        } else {
            DashboardLandscape(
                palette = palette,
                settings = settings,
                snapshot = snapshot,
                obdState = obdState,
                onOpenReset = { showResetDialog = true },
                onObdClick = onObdPillClick
            )
        }
    }

    if (showResetDialog) {
        MetricResetDialog(
            palette = palette,
            language = settings.language,
            fuelActionsEnabled = settings.fuelCalculationSupported,
            averageConsumption = snapshot.averageConsumption,
            averageDistanceKm = averageDistanceKm,
            onDismiss = { showResetDialog = false },
            onReset = { action: TripMetricReset ->
                showResetDialog = false
                onResetMetrics(action)
            },
            onEndTripNow = {
                showResetDialog = false
                onEndTripNow()
            }
        )
    }

    if (showObdQuickDialog) {
        ObdQuickConnectDialog(
            palette = palette,
            language = settings.language,
            obdState = obdState,
            demoMode = settings.demoMode,
            onDismiss = { showObdQuickDialog = false },
            onRefresh = onRefreshObdDevices,
            onSelectAndConnect = { device: PairedObdDevice ->
                onSelectObdDevice(device)
                onConnectObd()
                showObdQuickDialog = false
            },
            onDisconnect = {
                onDisconnectObd()
                showObdQuickDialog = false
            }
        )
    }

    if (showMovingWarning) {
        AlertDialog(
            onDismissRequest = { showMovingWarning = false },
            title = {
                Text(
                    if (settings.language == AppLanguage.English) "Vehicle is moving" else "Araç hareket halinde",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Black
                )
            },
            text = {
                Text(
                    if (settings.language == AppLanguage.English) {
                        "OBD device selection is available when the vehicle is stopped."
                    } else {
                        "OBD cihaz seçimi araç durduğunda kullanılabilir."
                    },
                    color = palette.textSecondary
                )
            },
            confirmButton = {
                TextButton(onClick = { showMovingWarning = false }) {
                    Text(if (settings.language == AppLanguage.English) "OK" else "Tamam")
                }
            }
        )
    }
}


@Composable
private fun HeadUnitConsumptionCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    trend: List<Float>,
    textScale: Float,
    modifier: Modifier = Modifier
) {
    val scale = textScale.coerceIn(0.90f, 1.16f)
    val resolvedUnit = unit.orEmpty().trim()
    OemCard(palette = palette, modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            MetricIcon(
                palette = palette,
                icon = icon,
                modifier = Modifier.size((44f * scale.coerceAtMost(1.06f)).dp)
            )
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    title.uppercase(),
                    color = palette.accent,
                    fontSize = (9.5f * scale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        value,
                        color = palette.textPrimary,
                        fontSize = (22f * scale).sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (resolvedUnit.isNotBlank()) {
                        Spacer(Modifier.width(4.dp))
                        Text(
                            resolvedUnit,
                            color = palette.textSecondary,
                            fontSize = (10.5f * scale).sp,
                            modifier = Modifier.padding(bottom = 2.dp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Spacer(Modifier.height(3.dp))
                ConsumptionSparkline(
                    values = trend,
                    lineColor = palette.blue,
                    guideColor = palette.line,
                    modifier = Modifier.fillMaxWidth().height(28.dp)
                )
            }
        }
    }
}

@Composable
private fun DashboardPortrait(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val english = settings.language == AppLanguage.English
    fun t(tr: String, en: String): String = if (english) en else tr
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource),
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    )
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource),
        tripToken = snapshot.tripToken,
        unitKey = "average"
    )
    val coolantColor = coolantAccentColor(palette, snapshot.engineTempC)
    val acColor = acAccentColor(palette, snapshot.acOn)
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val smallScreen = maxWidth < 360.dp || maxHeight < 680.dp
        val largeScreen = maxWidth >= 430.dp && maxHeight >= 820.dp
        val screenScale = when {
            smallScreen -> 0.90f
            largeScreen -> 1.05f
            else -> 1.0f
        }
        val textScale = cockpitTextScale(settings) * screenScale
        val spacing = cockpitSpacing(settings) * if (smallScreen) 0.65f else 1f
        val baseMetricHeight = (cockpitCardHeight(settings) * screenScale).coerceIn(74.dp, 118.dp)
        val gaugeFraction = when (settings.cockpitDensity) {
            CockpitDensity.Compact -> 0.22f
            CockpitDensity.Balanced -> 0.25f
            CockpitDensity.Wide -> 0.28f
        }
        val gaugeHeight = (maxHeight * gaugeFraction)
            .coerceIn(if (smallScreen) 132.dp else 146.dp, if (largeScreen) 236.dp else 216.dp)
        val headerEstimate = if (obdState.timeTrusted) 44.dp else 58.dp
        val fixedContent = headerEstimate + gaugeHeight + 4.dp + (spacing * 9f) + 10.dp
        val fillMetricHeight = ((maxHeight - fixedContent).value / 4f).dp
        val metricHeight = maxOf(baseMetricHeight, fillMetricHeight).coerceAtMost(124.dp)
        val horizontalPadding = if (maxWidth < 360.dp) 8.dp else 14.dp

        Box(
            modifier = Modifier
                .matchParentSize()
                .background(palette.background)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = horizontalPadding, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(spacing),
            contentPadding = PaddingValues(bottom = 8.dp)
        ) {
            item { DashboardConceptHeader(palette, snapshot, obdState, settings.demoMode, settings.language, onOpenReset = onOpenReset, onObdClick = onObdClick) }
            item {
                ConceptSpeedBlock(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.fillMaxWidth().height(gaugeHeight),
                    carScale = if (settings.deviceMode == DeviceMode.HeadUnit) 1.0f else 1.25f,
                    scenic = true
                )
            }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(
                        palette = palette,
                        title = t("Ortalama Tüketim", "Average Consumption"),
                        value = fmt(snapshot.averageConsumption),
                        unit = "L/100 km",
                        icon = CardIcon.FuelAverage,
                        subtitle = if ((snapshot.tripDistanceKm ?: 0.0) < 3.0 && snapshot.averageConsumption != null) t("Kısa sürüş", "Short trip") else null,
                        modifier = Modifier.weight(1f).clickable { onOpenReset() },
                        textScale = textScale,
                        trendValues = averageTrend,
                        glassCard = true
                    )
                    ConceptMetricCell(
                        palette = palette,
                        title = t("Anlık Tüketim", "Instant Consumption"),
                        value = fmt(snapshot.instantConsumption),
                        unit = snapshot.instantUnit,
                        icon = CardIcon.FuelInstant,
                        modifier = Modifier.weight(1f),
                        textScale = textScale,
                        trendValues = instantTrend,
                        glassCard = true
                    )
                }
            }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(palette, t("Mesafe", "Distance"), fmt(snapshot.tripDistanceKm), "km", CardIcon.Distance, modifier = Modifier.weight(1f), textScale = textScale, glassCard = true)
                    ConceptMetricCell(palette, t("Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, modifier = Modifier.weight(1f), textScale = textScale, glassCard = true)
                }
            }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    val temp = snapshot.engineTempC?.toString() ?: "--"
                    ConceptMetricCell(
                        palette = palette,
                        title = t("Hararet", "Coolant"),
                        value = temp,
                        unit = "°C",
                        icon = CardIcon.Temperature,
                        modifier = Modifier.weight(1f),
                        textScale = textScale,
                        titleColor = palette.textSecondary,
                        iconTint = coolantColor,
                        valueColor = coolantColor,
                        unitColor = coolantColor.copy(alpha = .86f),
                        glassCard = true
                    )
                    ConceptMetricCell(
                        palette = palette,
                        title = t("Klima", "A/C"),
                        value = snapshot.acOn?.let { if (it) t("Açık", "On") else t("Kapalı", "Off") } ?: "--",
                        unit = null,
                        icon = CardIcon.Ac,
                        modifier = Modifier.weight(1f),
                        textScale = textScale,
                        titleColor = palette.textSecondary,
                        iconTint = acColor,
                        valueColor = acColor,
                        glassCard = true
                    )
                }
            }
            item {
                ConceptMetricRow(palette, metricHeight) {
                    ConceptMetricCell(palette, t("Devir", "RPM"), snapshot.rpm?.toString() ?: "--", "rpm", CardIcon.Rpm, modifier = Modifier.weight(1f), textScale = textScale, glassCard = true)
                    ConceptMetricCell(palette, t("Sürüş Süresi", "Trip Time"), snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, modifier = Modifier.weight(1f), textScale = textScale, glassCard = true)
                }
            }
        }
    }
}

@Composable
private fun DashboardLandscape(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val english = settings.language == AppLanguage.English
    fun t(tr: String, en: String): String = if (english) en else tr
    val instantTrend = rememberConsumptionTrend(
        value = snapshot.instantConsumption,
        enabled = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource),
        tripToken = snapshot.tripToken,
        unitKey = snapshot.instantUnit
    )
    val averageTrend = rememberConsumptionTrend(
        value = snapshot.averageConsumption,
        enabled = settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource),
        tripToken = snapshot.tripToken,
        unitKey = "average"
    )
    val coolantColor = coolantAccentColor(palette, snapshot.engineTempC)
    val acColor = acAccentColor(palette, snapshot.acOn)
    val configuration = LocalConfiguration.current
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val shortScreen = maxHeight < 360.dp
        val resolvedHeadUnit = settings.deviceMode == DeviceMode.HeadUnit ||
            (settings.deviceMode == DeviceMode.Auto && configuration.smallestScreenWidthDp >= 600)
        val textScale = if (resolvedHeadUnit) {
            headUnitCockpitTextScale(settings)
        } else {
            cockpitTextScale(settings) * if (shortScreen) 0.98f else 1.08f
        }
        val gap = if (shortScreen) 6.dp else 10.dp
        val pad = if (shortScreen) 6.dp else 10.dp

        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = pad, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(gap)
        ) {
            DashboardConceptHeader(
                palette, snapshot, obdState, settings.demoMode, settings.language,
                compact = true, onOpenReset = onOpenReset, onObdClick = onObdClick
            )
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                OemCard(
                    palette = palette,
                    modifier = Modifier.weight(0.72f).fillMaxHeight()
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.SpaceEvenly
                    ) {
                        if (!snapshot.demo) {
                            Text(
                                snapshot.tripStateText ?: t("Sürüş bekleniyor", "Waiting for trip"),
                                color = if ((snapshot.tripDistanceKm ?: 0.0) > 0.0) palette.accent else palette.textSecondary,
                                fontWeight = FontWeight.Black,
                                fontSize = (16f * textScale).sp
                            )
                        }
                        LandscapeTripLine(palette, CardIcon.Distance, t("Mesafe", "Distance"), fmt(snapshot.tripDistanceKm), "km", textScale)
                        LandscapeTripLine(palette, CardIcon.Time, t("Süre", "Time"), snapshot.tripDurationText ?: "00:00", null, textScale)
                        LandscapeTripLine(palette, CardIcon.Cost, t("Maliyet", "Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, textScale)
                    }
                }
                ConceptSpeedBlock(
                    palette = palette,
                    settings = settings,
                    snapshot = snapshot,
                    modifier = Modifier.weight(1.62f).fillMaxHeight(),
                    compact = false,
                    carScale = 0.90f,
                    scenic = true
                )
                Column(
                    modifier = Modifier.weight(0.92f).fillMaxHeight(),
                    verticalArrangement = Arrangement.spacedBy(gap)
                ) {
                    if (resolvedHeadUnit) {
                        HeadUnitConsumptionCard(
                            palette = palette,
                            title = t("Ortalama Tüketim", "Average Consumption"),
                            value = fmt(snapshot.averageConsumption),
                            unit = "L/100 km",
                            icon = CardIcon.FuelAverage,
                            trend = averageTrend,
                            textScale = textScale,
                            modifier = Modifier.fillMaxWidth().weight(1f).clickable { onOpenReset() }
                        )
                        HeadUnitConsumptionCard(
                            palette = palette,
                            title = t("Anlık Tüketim", "Instant Consumption"),
                            value = fmt(snapshot.instantConsumption),
                            unit = snapshot.instantUnit,
                            icon = CardIcon.FuelInstant,
                            trend = instantTrend,
                            textScale = textScale,
                            modifier = Modifier.fillMaxWidth().weight(1f)
                        )
                    } else {
                        DataCard(
                            palette = palette,
                            title = t("Ortalama Tüketim", "Average Consumption"),
                            value = fmt(snapshot.averageConsumption),
                            unit = "L/100 km",
                            icon = CardIcon.FuelAverage,
                            textScale = textScale,
                            modifier = Modifier.fillMaxWidth().weight(1f).clickable { onOpenReset() },
                            trailingContent = {
                                ConsumptionSparkline(
                                    values = averageTrend,
                                    lineColor = palette.blue,
                                    guideColor = palette.line,
                                    modifier = Modifier.fillMaxWidth().height(34.dp)
                                )
                            },
                            trailingWidthDp = 58f
                        )
                        DataCard(
                            palette = palette,
                            title = t("Anlık Tüketim", "Instant Consumption"),
                            value = fmt(snapshot.instantConsumption),
                            unit = snapshot.instantUnit,
                            icon = CardIcon.FuelInstant,
                            textScale = textScale,
                            modifier = Modifier.fillMaxWidth().weight(1f),
                            trailingContent = {
                                ConsumptionSparkline(
                                    values = instantTrend,
                                    lineColor = palette.blue,
                                    guideColor = palette.line,
                                    modifier = Modifier.fillMaxWidth().height(34.dp)
                                )
                            },
                            trailingWidthDp = 58f
                        )
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().height(if (shortScreen) 72.dp else 86.dp),
                horizontalArrangement = Arrangement.spacedBy(gap)
            ) {
                DataCard(palette, t("Devir", "RPM"), snapshot.rpm?.toString() ?: "--", "rpm", icon = CardIcon.Rpm, modifier = Modifier.weight(1f), textScale = textScale)
                DataCard(
                    palette = palette,
                    title = t("Hararet", "Coolant"),
                    value = snapshot.engineTempC?.toString() ?: "--",
                    unit = "°C",
                    accent = palette.textSecondary,
                    icon = CardIcon.Temperature,
                    modifier = Modifier.weight(1f),
                    textScale = textScale,
                    iconTint = coolantColor,
                    valueColor = coolantColor,
                    unitColor = coolantColor.copy(alpha = .86f)
                )
                DataCard(
                    palette = palette,
                    title = t("Klima", "A/C"),
                    value = snapshot.acOn?.let { if (it) t("Açık", "On") else t("Kapalı", "Off") } ?: "--",
                    accent = palette.textSecondary,
                    icon = CardIcon.Ac,
                    modifier = Modifier.weight(1f),
                    textScale = textScale,
                    iconTint = acColor,
                    valueColor = acColor
                )
            }
        }
    }
}

@Composable
private fun LandscapeTripLine(
    palette: LoganPalette,
    icon: CardIcon,
    title: String,
    value: String,
    unit: String?,
    textScale: Float
) {
    val resolvedUnit = unit.orEmpty().trim()
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(38.dp), contentAlignment = Alignment.Center) { MetricIcon(palette, icon) }
        Spacer(Modifier.width(10.dp))
        Column {
            Text(title.uppercase(), color = palette.textSecondary, fontSize = (9f * textScale).sp, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.Bottom) {
                Text(value, color = palette.textPrimary, fontSize = (22f * textScale).sp, fontWeight = FontWeight.Black)
                if (resolvedUnit.isNotBlank()) {
                    Spacer(Modifier.width(5.dp))
                    Text(resolvedUnit, color = palette.textSecondary, fontSize = (10f * textScale).sp)
                }
            }
        }
    }
}

@Composable
private fun DashboardConceptHeader(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean = false,
    onOpenReset: (() -> Unit)? = null,
    onObdClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (compact) 38.dp else 44.dp)
                .clipToBounds(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(start = if (compact) 2.dp else 4.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                LoganWordmark(palette, compact = true)
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                ObdStatusPill(
                    palette = palette,
                    connected = snapshot.connected || obdState.connected,
                    connecting = obdState.connecting,
                    connectionHealth = obdState.connectionHealth,
                    ignitionOff = obdState.status.contains("Kontak kapalı", ignoreCase = true) ||
                        (obdState.connectionHealthReason?.contains("Kontak kapalı", ignoreCase = true) == true),
                    demoMode = demoMode,
                    language = language,
                    compact = true,
                    onClick = onObdClick
                )
                if (onOpenReset != null) {
                    HeaderOverflowButton(palette = palette, compact = true, onClick = onOpenReset)
                }
            }
        }
        Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .80f)))
        if (!obdState.timeTrusted) {
            Text(
                text = if (language == AppLanguage.English) "Time synchronizing…" else "Saat eşitleniyor…",
                color = palette.warning,
                fontSize = if (compact) 8.sp else 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun HeaderOverflowButton(palette: LoganPalette, compact: Boolean, onClick: () -> Unit) {
    // More visible cockpit menu while keeping a restrained OEM-style footprint.
    val size = if (compact) 32.dp else 36.dp
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(999.dp))
            .background(palette.surfaceVariant)
            .clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "⋮",
            color = palette.textPrimary,
            fontSize = if (compact) 20.sp else 22.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center,
            lineHeight = if (compact) 20.sp else 22.sp
        )
    }
}

@Composable
private fun ObdStatusPill(
    palette: LoganPalette,
    connected: Boolean,
    connecting: Boolean,
    connectionHealth: ObdConnectionHealth,
    ignitionOff: Boolean,
    demoMode: Boolean,
    language: AppLanguage,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val english = language == AppLanguage.English
    val label = when {
        demoMode -> "DEMO"
        ignitionOff -> if (english) "IGNITION OFF" else "KONTAK KAPALI"
        connectionHealth == ObdConnectionHealth.DATA_STALE -> if (english) "WAITING DATA" else "VERİ BEKLENİYOR"
        connectionHealth == ObdConnectionHealth.UNSTABLE -> if (english) "UNSTABLE" else "KARARSIZ"
        connectionHealth == ObdConnectionHealth.RECONNECTING -> if (english) "RECONNECTING" else "YENİDEN"
        connected -> if (english) "OBD ON" else "OBD BAĞLI"
        connecting || connectionHealth == ObdConnectionHealth.CONNECTING -> if (english) "CONNECTING" else "BAĞLANIYOR"
        else -> if (english) "OBD WAIT" else "OBD BEK."
    }
    val color = when {
        demoMode -> palette.warning
        ignitionOff -> palette.warning
        connectionHealth == ObdConnectionHealth.DATA_STALE -> palette.warning
        connectionHealth == ObdConnectionHealth.UNSTABLE -> palette.warning
        connectionHealth == ObdConnectionHealth.RECONNECTING -> palette.warning
        connected -> palette.accent
        connecting || connectionHealth == ObdConnectionHealth.CONNECTING -> palette.warning
        else -> palette.textSecondary
    }
    Row(
        modifier = modifier
            .heightIn(min = if (compact) 32.dp else 36.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(color.copy(alpha = .12f))
            .clickable { onClick() }
            .padding(horizontal = if (compact) 9.dp else 11.dp, vertical = if (compact) 4.dp else 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(if (compact) 7.dp else 8.dp)
                .clip(RoundedCornerShape(99.dp))
                .background(color)
        )
        Text(
            text = label,
            color = color,
            fontSize = if (compact) 9.sp else 10.sp,
            fontWeight = FontWeight.Black,
            maxLines = 1
        )
    }
}

@Composable
private fun ObdQuickConnectDialog(
    palette: LoganPalette,
    language: AppLanguage,
    obdState: ObdState,
    demoMode: Boolean,
    onDismiss: () -> Unit,
    onRefresh: () -> Unit,
    onSelectAndConnect: (PairedObdDevice) -> Unit,
    onDisconnect: () -> Unit
) {
    val english = language == AppLanguage.English
    var chooseDevice by remember(obdState.connected) { mutableStateOf(!obdState.connected) }
    val selectedDevice = obdState.pairedDevices.firstOrNull { it.address == obdState.selectedAddress }
    val orderedDevices = obdState.pairedDevices.sortedWith(
        compareByDescending<PairedObdDevice> { it.address == obdState.selectedAddress }
            .thenBy { it.name.lowercase(Locale.getDefault()) }
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (obdState.connected && !chooseDevice) {
                    if (english) "OBD connected" else "OBD bağlı"
                } else {
                    if (english) "Choose OBD device" else "OBD cihazı seç"
                },
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 360.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (demoMode) {
                    Text(
                        if (english) {
                            "Demo Mode is active. Real OBD connection is disabled until Demo Mode is turned off."
                        } else {
                            "Demo Modu açık. Demo kapatılana kadar gerçek OBD bağlantısı devre dışıdır."
                        },
                        color = palette.warning,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 17.sp
                    )
                }
                if (obdState.connected && !chooseDevice) {
                    Text(
                        selectedDevice?.name ?: obdState.selectedName ?: if (english) "Connected adapter" else "Bağlı adaptör",
                        color = palette.textPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                    val address = selectedDevice?.address ?: obdState.selectedAddress
                    if (!address.isNullOrBlank()) {
                        Text(address, color = palette.textSecondary, fontSize = 11.sp)
                    }
                    Text(obdState.status, color = palette.textSecondary, fontSize = 12.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onDisconnect,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = palette.surfaceVariant,
                                contentColor = palette.critical
                            )
                        ) {
                            Text(if (english) "Disconnect" else "Bağlantıyı kes")
                        }
                        Button(
                            onClick = {
                                chooseDevice = true
                                onRefresh()
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                        ) {
                            Text(if (english) "Change device" else "Cihaz değiştir")
                        }
                    }
                } else {
                    if (obdState.connecting) {
                        Text(
                            if (english) "Connecting…" else "Bağlanıyor…",
                            color = palette.warning,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    if (orderedDevices.isEmpty()) {
                        Text(
                            if (english) {
                                "No paired OBD adapter was found. Pair the adapter in Android Bluetooth settings, then refresh."
                            } else {
                                "Eşleşmiş OBD adaptörü bulunamadı. Adaptörü Android Bluetooth ayarlarından eşleştirip yenileyin."
                            },
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp
                        )
                    } else {
                        orderedDevices.forEach { device: PairedObdDevice ->
                            val lastUsed = device.address == obdState.selectedAddress
                            SettingsRow(
                                palette = palette,
                                title = device.name,
                                subtitle = buildString {
                                    if (lastUsed) {
                                        append(if (english) "Last used" else "Son kullanılan")
                                        append(" • ")
                                    }
                                    append(device.address)
                                },
                                value = if (demoMode) {
                                    if (english) "Demo active" else "Demo açık"
                                } else if (lastUsed) {
                                    if (english) "Connect" else "Bağlan"
                                } else {
                                    if (english) "Select" else "Seç"
                                },
                                onClick = { if (!demoMode) onSelectAndConnect(device) }
                            )
                        }
                    }
                    TextButton(
                        onClick = onRefresh,
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(if (english) "Refresh devices" else "Cihazları yenile")
                    }
                    if (obdState.lastError != null) {
                        Text(
                            obdState.lastError ?: "",
                            color = palette.critical,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    } else if (obdState.status.isNotBlank()) {
                        Text(
                            obdState.status,
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (english) "Close" else "Kapat")
            }
        }
    )
}

private enum class CockpitAction {
    ResetAverage,
    ResetCost,
    ResetAverageAndCost,
    EndTrip
}

@Composable
private fun MetricResetDialog(
    palette: LoganPalette,
    language: AppLanguage,
    fuelActionsEnabled: Boolean,
    averageConsumption: Double?,
    averageDistanceKm: Double,
    onDismiss: () -> Unit,
    onReset: (TripMetricReset) -> Unit,
    onEndTripNow: () -> Unit
) {
    var pendingAction by remember { mutableStateOf<CockpitAction?>(null) }
    val english = language == AppLanguage.English
    val pendingLabel = when (pendingAction) {
        CockpitAction.ResetAverage -> if (english) "average consumption" else "ortalama tüketim"
        CockpitAction.ResetCost -> if (english) "trip cost" else "sürüş maliyeti"
        CockpitAction.ResetAverageAndCost -> if (english) "average consumption and trip cost" else "ortalama tüketim ve sürüş maliyeti"
        CockpitAction.EndTrip -> if (english) "the current trip" else "mevcut sürüş"
        null -> ""
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                when {
                    pendingAction == null -> if (english) "Cockpit actions" else "Kokpit işlemleri"
                    pendingAction == CockpitAction.EndTrip -> if (english) "End trip now?" else "Sürüş şimdi bitirilsin mi?"
                    else -> if (english) "Confirm reset" else "Sıfırlamayı onayla"
                },
                color = palette.textPrimary,
                fontWeight = FontWeight.Black
            )
        },
        text = {
            if (pendingAction == null) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = (LocalConfiguration.current.screenHeightDp * 0.52f).dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        if (english) "Average consumption" else "Ortalama tüketim",
                        color = palette.textPrimary,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        averageConsumption?.takeIf { it.isFinite() }?.let {
                            String.format(Locale.US, "%.1f L/100 km", it)
                        } ?: "--",
                        color = palette.textPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        if (averageDistanceKm >= 0.1) {
                            if (english) {
                                "Calculation distance: ${String.format(Locale.US, "%.0f", averageDistanceKm)} km"
                            } else {
                                "Hesaplama mesafesi: ${String.format(Locale.US, "%.0f", averageDistanceKm)} km"
                            }
                        } else {
                            if (english) "Calculation distance: not available yet" else "Hesaplama mesafesi: henüz yeterli değil"
                        },
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        if (english) {
                            "Reset calculations without deleting trip totals, or close the current trip manually."
                        } else {
                            "Toplamları silmeden ortalama veya maliyet değerlerini sıfırlayabilirsiniz."
                        },
                        color = palette.textSecondary,
                        fontSize = 13.sp,
                        lineHeight = 18.sp
                    )
                    if (fuelActionsEnabled) {
                        ResetChoice(palette, if (english) "Reset average consumption" else "Ortalama tüketimi sıfırla") {
                            pendingAction = CockpitAction.ResetAverage
                        }
                        ResetChoice(palette, if (english) "Reset trip cost" else "Sürüş maliyetini sıfırla") {
                            pendingAction = CockpitAction.ResetCost
                        }
                        ResetChoice(palette, if (english) "Reset average + cost" else "Ortalama + maliyeti sıfırla") {
                            pendingAction = CockpitAction.ResetAverageAndCost
                        }
                    } else {
                        Text(
                            if (english) "Fuel calculation is disabled until this petrol profile is validated." else "Benzinli profil doğrulanana kadar tüketim ve maliyet işlemleri kapalıdır.",
                            color = palette.warning,
                            fontSize = 12.sp,
                            lineHeight = 16.sp
                        )
                    }
                    ResetChoice(palette, if (english) "End trip now" else "Sürüşü şimdi bitir") {
                        pendingAction = CockpitAction.EndTrip
                    }
                }
            } else {
                Text(
                    if (pendingAction == CockpitAction.EndTrip) {
                        if (english) {
                            "Close $pendingLabel? The next movement will start a new trip."
                        } else {
                            "$pendingLabel kapatılsın mı? Sonraki hareket yeni sürüş olarak başlayacak."
                        }
                    } else {
                        if (english) {
                            "Reset $pendingLabel from this point? Trip totals will not be deleted."
                        } else {
                            "$pendingLabel bu noktadan itibaren sıfırlansın mı? Yolculuk toplamları silinmez."
                        }
                    },
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            }
        },
        confirmButton = {
            pendingAction?.let { action ->
                TextButton(
                    onClick = {
                        when (action) {
                            CockpitAction.ResetAverage -> onReset(TripMetricReset.Average)
                            CockpitAction.ResetCost -> onReset(TripMetricReset.Cost)
                            CockpitAction.ResetAverageAndCost -> onReset(TripMetricReset.AverageAndCost)
                            CockpitAction.EndTrip -> onEndTripNow()
                        }
                    }
                ) {
                    Text(
                        if (action == CockpitAction.EndTrip) {
                            if (english) "End trip" else "Sürüşü bitir"
                        } else {
                            if (english) "Reset" else "Sıfırla"
                        }
                    )
                }
            }
        },
        dismissButton = {
            TextButton(
                onClick = {
                    if (pendingAction != null) pendingAction = null else onDismiss()
                }
            ) {
                Text(
                    if (pendingAction != null) {
                        if (english) "Back" else "Geri"
                    } else {
                        if (english) "Cancel" else "İptal"
                    }
                )
            }
        }
    )
}

@Composable
private fun ResetChoice(palette: LoganPalette, label: String, onClick: () -> Unit) {
    Text(
        text = label,
        color = palette.textPrimary,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(palette.surfaceVariant)
            .clickable { onClick() }
            .padding(12.dp)
    )
}

@Composable
private fun ConceptSpeedBlock(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    modifier: Modifier,
    compact: Boolean = false,
    carScale: Float = 1.0f,
    scenic: Boolean = false
) {
    BoxWithConstraints(
        modifier = modifier
            .padding(top = if (compact) 2.dp else 6.dp, bottom = 3.dp)
            .clipToBounds(),
        contentAlignment = Alignment.Center
    ) {
        val maxSpeed = 240f
        val progress = ((snapshot.speedKmh ?: 0) / maxSpeed).coerceIn(0f, 1f)
        DigitalSpeedPanel(
            palette = palette,
            speed = snapshot.speedKmh,
            progress = progress,
            modifier = Modifier.fillMaxSize(),
            demoMode = settings.demoMode,
            previewMode = false,
            textScale = cockpitTextScale(settings),
            vehicleColor = settings.vehicleColor,
            vehicleVisualModel = settings.vehicleVisualModel,
            motionEnabled = snapshot.connected || settings.demoMode,
            carScale = carScale,
            rpm = snapshot.rpm,
            scenicMode = scenic
        )
    }
}

@Composable
private fun ConceptDivider(palette: LoganPalette) {
    Box(modifier = Modifier.fillMaxWidth().height(1.dp).background(palette.line.copy(alpha = .68f)))
}

@Composable
private fun ConceptMetricRow(
    palette: LoganPalette,
    height: androidx.compose.ui.unit.Dp,
    modifier: Modifier = Modifier,
    content: @Composable RowScope.() -> Unit
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .then(if (height.value > 0f) Modifier.height(height) else Modifier),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(0.dp),
        content = content
    )
}

@Composable
private fun ConceptMetricCell(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    subtitle: String? = null,
    modifier: Modifier = Modifier,
    textScale: Float = 1.0f,
    titleColor: Color = palette.accent,
    iconTint: Color = Color.Unspecified,
    valueColor: Color = palette.textPrimary,
    unitColor: Color = palette.textSecondary,
    trendValues: List<Float>? = null,
    trendColor: Color = palette.blue,
    glassCard: Boolean = false
) {
    val scale = textScale.coerceIn(0.84f, 1.24f)
    val iconSlot = ((if (trendValues != null) 38f else 46f) * scale.coerceIn(0.92f, 1.06f)).dp
    val gap = (7f * scale.coerceIn(0.94f, 1.04f)).dp
    val resolvedUnit = unit.orEmpty().trim()
    val compactUnit = when {
        resolvedUnit.contains("L/100", ignoreCase = true) -> "L/100 km"
        else -> resolvedUnit
    }
    val titleSize = when {
        title.length > 17 -> 9.2f
        title.length > 13 -> 10.1f
        else -> 11.4f
    }

    val cardShape = RoundedCornerShape(20.dp)
    val cellModifier = modifier
        .fillMaxHeight()
        .padding(horizontal = 4.dp, vertical = 3.dp)
        .then(
            if (glassCard) {
                Modifier
                    .clip(cardShape)
                    .background(palette.surface.copy(alpha = .88f))
                    .border(1.dp, palette.line.copy(alpha = .30f), cardShape)
                    .padding(horizontal = 7.dp)
            } else {
                Modifier
            }
        )

    Box(modifier = cellModifier) {
        Row(
            modifier = Modifier.fillMaxSize(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MetricIcon(
                palette = palette,
                icon = icon,
                tint = iconTint,
                modifier = Modifier.size(iconSlot)
            )
            Spacer(modifier = Modifier.width(gap))
            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    title.uppercase(),
                    color = titleColor,
                    fontSize = (titleSize * scale).sp,
                    lineHeight = (titleSize * 1.08f * scale).sp,
                    fontWeight = FontWeight.Black,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(1.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        value,
                        color = valueColor,
                        fontSize = ((if (trendValues != null) 20f else 22f) * scale).sp,
                        lineHeight = ((if (trendValues != null) 22f else 23f) * scale).sp,
                        fontWeight = FontWeight.Black,
                        maxLines = 1,
                        overflow = TextOverflow.Clip,
                        softWrap = false
                    )
                    if (compactUnit.isNotBlank()) {
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            compactUnit,
                            color = unitColor,
                            fontSize = ((if (compactUnit.length > 6) 8.8f else 10.3f) * scale).sp,
                            lineHeight = ((if (compactUnit.length > 6) 9.4f else 10.8f) * scale).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Clip,
                            softWrap = false,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
                if (trendValues != null) {
                    if (subtitle != null) {
                        Text(
                            subtitle,
                            color = palette.textSecondary,
                            fontSize = (8.5f * scale).sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Spacer(Modifier.height(1.dp))
                    ConsumptionSparkline(
                        values = trendValues,
                        lineColor = trendColor,
                        guideColor = palette.line,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(13.dp)
                            .padding(top = 1.dp)
                    )
                } else if (subtitle != null) {
                    Text(
                        subtitle,
                        color = palette.textSecondary,
                        fontSize = (9.3f * scale).sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
private fun TemperatureCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val temp = snapshot.engineTempC
    val tempColor = coolantAccentColor(palette, temp)
    DataCard(
        palette = palette,
        title = "Hararet",
        value = temp?.toString() ?: "--",
        unit = "°C",
        accent = palette.textSecondary,
        subtitle = "Soğutma suyu",
        icon = CardIcon.Temperature,
        modifier = modifier,
        textScale = textScale,
        iconTint = tempColor,
        valueColor = tempColor,
        unitColor = tempColor.copy(alpha = .86f)
    )
}

@Composable
private fun ClimateCard(palette: LoganPalette, snapshot: DashboardSnapshot, modifier: Modifier, textScale: Float = 1.0f) {
    val label = snapshot.acOn?.let { if (it) "Açık" else "Kapalı" } ?: "--"
    val acColor = acAccentColor(palette, snapshot.acOn)
    DataCard(
        palette = palette,
        title = "Klima",
        value = label,
        accent = palette.textSecondary,
        subtitle = "A/C durumu",
        icon = CardIcon.Ac,
        modifier = modifier,
        textScale = textScale,
        iconTint = acColor,
        valueColor = acColor
    )
}

@Composable
private fun BottomNavigationBar(
    palette: LoganPalette,
    current: MainTab,
    language: AppLanguage,
    largeTouchTargets: Boolean,
    onSelect: (MainTab) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.surface)
            .windowInsetsPadding(
                WindowInsets.navigationBarsIgnoringVisibility.only(WindowInsetsSides.Bottom)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(if (largeTouchTargets) 76.dp else 60.dp)
                .padding(horizontal = if (largeTouchTargets) 10.dp else 8.dp, vertical = if (largeTouchTargets) 9.dp else 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            MainTab.entries.forEach { tab ->
                val selected = current == tab
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .clip(RoundedCornerShape(15.dp))
                        .background(if (selected) palette.accent.copy(alpha = .12f) else Color.Transparent)
                        .clickable { onSelect(tab) }
                        .padding(vertical = if (largeTouchTargets) 5.dp else 12.dp)
                ) {
                    if (largeTouchTargets) {
                        MetricIcon(
                            palette = palette,
                            icon = tabIcon(tab),
                            tint = if (selected) palette.accent else Color.Unspecified,
                            modifier = Modifier.size(25.dp)
                        )
                        Spacer(Modifier.height(2.dp))
                    }
                    Text(
                        text = tabLabel(tab, language),
                        color = if (selected) palette.accent else palette.textSecondary,
                        fontSize = if (largeTouchTargets) 14.sp else 11.sp,
                        fontWeight = if (selected) FontWeight.Black else FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
private fun TripPage(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    settings: LoganSettings,
    obdState: ObdState,
    onEndTripNow: () -> Unit,
    onRefreshHistory: () -> Unit,
    onLoadHistoryDetail: (Long) -> Unit,
    onClearHistoryDetail: () -> Unit,
    onPinHistory: (Long, Boolean) -> Unit,
    onDeleteHistory: (Long) -> Unit,
    onExportHistory: (Long) -> Unit,
    onExportGpsRoute: (Long) -> Unit,
    onExportAllHistory: () -> Unit
) {
    val language = settings.language
    val tr = language != AppLanguage.English
    var selected by remember { mutableStateOf<DriveHistoryItem?>(null) }
    var deleteCandidate by remember { mutableStateOf<DriveHistoryItem?>(null) }
    val moving = (snapshot.speedKmh ?: 0) > 0
    val tripHasProgress = (snapshot.tripDistanceKm ?: 0.0) > 0.0001 ||
        (snapshot.fuelUsedL ?: 0.0) > 0.00001 ||
        (snapshot.tripDurationText != null && snapshot.tripDurationText != "00:00")
    val currentTripSubtitle = when {
        snapshot.demo -> if (tr) "Demo sürüşü aktif" else "Demo trip active"
        tripHasProgress -> if (tr) "Sürüş aktif • ${settings.smartTripMinutes} dk mola kuralı" else "Trip active • ${settings.smartTripMinutes} min pause rule"
        snapshot.connected -> if (tr) "Hareket edince başlar • ${settings.smartTripMinutes} dk mola kuralı" else "Starts when the vehicle moves • ${settings.smartTripMinutes} min pause rule"
        else -> if (tr) "OBD bağlantısı bekleniyor" else "Waiting for OBD connection"
    }
    val completed = obdState.driveHistory.filterNot { it.activeLike }
    val recent = completed.take(10)
    val recentDistance = recent.sumOf { it.distanceKm }
    val recentFuel = recent.sumOf { it.fuelUsedL }
    val recentAverage = if (recentDistance > 0.1) recentFuel / recentDistance * 100.0 else null
    val totalDistance = completed.sumOf { it.distanceKm }
    val totalFuel = completed.sumOf { it.fuelUsedL }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Sürüş Merkezi" else "Trip Center", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
                    Text(if (tr) "Canlı yolculuk, geçmiş ve sürüş analizleri" else "Live trip, history and drive insights", color = palette.textSecondary, fontSize = 13.sp)
                }
                TextButton(onClick = onRefreshHistory) { Text(if (tr) "Yenile" else "Refresh") }
            }
        }

        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (tr) "Güncel Yolculuk" else "Current Trip", color = palette.textPrimary, fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text(currentTripSubtitle, color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text(
                            snapshot.tripStateText ?: if (snapshot.connected || snapshot.demo) (if (tr) "Hesaplanıyor" else "Calculating") else (if (tr) "Beklemede" else "Waiting"),
                            color = palette.accent,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        TripCenterMetric(palette, if (tr) "Mesafe" else "Distance", "${fmt(snapshot.tripDistanceKm)} km", CardIcon.Distance, Modifier.weight(1f))
                        TripCenterMetric(palette, if (tr) "Süre" else "Duration", snapshot.tripDurationText ?: "00:00", CardIcon.Time, Modifier.weight(1f))
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        TripCenterMetric(palette, if (tr) "Ortalama" else "Average", snapshot.averageConsumption?.let { String.format(Locale.US, "%.1f L/100 km", it) } ?: "--", CardIcon.FuelAverage, Modifier.weight(1f))
                        TripCenterMetric(palette, if (tr) "Maliyet" else "Cost", snapshot.tripCostText ?: "--", CardIcon.Cost, Modifier.weight(1f))
                    }
                    Button(
                        onClick = onEndTripNow,
                        enabled = tripHasProgress && !moving,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black)
                    ) {
                        Text(if (tr) "Sürüşü şimdi bitir" else "End trip now", color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    if (tripHasProgress && moving) {
                        Text(if (tr) "Sürüş güvenliği için araç hareket ederken manuel bitirme kapalıdır." else "Manual ending is disabled while the vehicle is moving.", color = palette.textSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        if (completed.isNotEmpty()) {
            item {
                Text(if (tr) "Sürüş Özeti" else "Drive Summary", color = palette.textPrimary, fontSize = 21.sp, fontWeight = FontWeight.Black)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    TripCenterMetric(
                        palette,
                        if (tr) "Son 10 ortalama" else "Last 10 average",
                        recentAverage?.let { String.format(Locale.US, "%.1f L/100 km", it) } ?: "--",
                        CardIcon.FuelAverage,
                        Modifier.weight(1f)
                    )
                    TripCenterMetric(
                        palette,
                        if (tr) "Toplam mesafe" else "Total distance",
                        String.format(Locale.US, "%.1f km", totalDistance),
                        CardIcon.Distance,
                        Modifier.weight(1f)
                    )
                }
            }
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text(if (tr) "Kayıtlı sürüşler" else "Saved drives", color = palette.textSecondary, fontSize = 12.sp)
                            Text("${completed.size}", color = palette.textPrimary, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(if (tr) "Tahmini toplam maliyet" else "Estimated total cost", color = palette.textSecondary, fontSize = 12.sp)
                            Text(historyCostText(totalFuel, settings.fuelPriceText), color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Sürüş Geçmişi" else "Drive History", color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(
                        if (tr) "${obdState.driveHistory.size} kayıt • Tamamlanan sürüşler otomatik kaydedilir" else "${obdState.driveHistory.size} records • Completed drives are saved automatically",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
                TextButton(onClick = onExportAllHistory, enabled = !obdState.exportInProgress && (obdState.driveHistory.isNotEmpty() || obdState.testHistory.isNotEmpty())) {
                    Text(if (tr) "Tümünü aktar" else "Export all")
                }
            }
        }
        if (obdState.driveHistory.isEmpty()) {
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricIcon(palette, CardIcon.Distance, modifier = Modifier.size(42.dp))
                        Text(if (tr) "Henüz tamamlanmış bir sürüş yok" else "No completed drive yet", color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
                        Text(if (tr) "İlk sürüşün tamamlandığında mesafe, tüketim, süre ve grafikler burada görünecek." else "When your first drive is completed, distance, consumption, duration and charts will appear here.", color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(obdState.driveHistory.size, key = { obdState.driveHistory[it].id }) { index ->
                val item = obdState.driveHistory[index]
                DriveHistoryCard(
                    palette = palette,
                    item = item,
                    language = language,
                    fuelPriceText = settings.fuelPriceText,
                    moving = moving,
                    onInspect = {
                        selected = item
                        onLoadHistoryDetail(item.id)
                    },
                    onPin = { onPinHistory(item.id, !item.pinned) },
                    onExport = { onExportHistory(item.id) },
                    onDelete = { deleteCandidate = item }
                )
            }
        }
    }

    selected?.let { item ->
        val detail = obdState.driveHistoryDetail?.takeIf { it.recordId == item.id }
        AlertDialog(
            onDismissRequest = { selected = null; onClearHistoryDetail() },
            title = { Text(if (tr) "Sürüş Analizi" else "Drive Analysis", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Column(
                    modifier = Modifier.heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompletionMetric(palette, if (tr) "Mesafe" else "Distance", String.format(Locale.US, "%.2f km", item.distanceKm), Modifier.weight(1f))
                        CompletionMetric(palette, if (tr) "Süre" else "Duration", historyDuration(item.durationMs), Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        CompletionMetric(palette, if (tr) "Ortalama" else "Average", item.averageL100?.let { String.format(Locale.US, "%.2f L/100 km", it) } ?: "--", Modifier.weight(1f))
                        CompletionMetric(palette, if (tr) "Maliyet" else "Cost", historyCostText(item.fuelUsedL, settings.fuelPriceText), Modifier.weight(1f))
                    }
                    HistoryDetailLine(palette, if (tr) "Yakıt" else "Fuel", String.format(Locale.US, "%.3f L", item.fuelUsedL))
                    HistoryDetailLine(palette, if (tr) "Azami hız" else "Max speed", item.maxSpeedKmh?.let { "$it km/h" } ?: "--")
                    HistoryDetailLine(palette, if (tr) "Azami devir" else "Max RPM", item.maxRpm?.let { "$it rpm" } ?: "--")
                    HistoryDetailLine(palette, if (tr) "Başlangıç → son hararet" else "Start → end coolant", "${item.startTempC?.let { "$it °C" } ?: "--"} → ${item.endTempC?.let { "$it °C" } ?: "--"}")
                    HistoryDetailLine(palette, if (tr) "OBD oturumu" else "OBD sessions", item.sessionCount.toString())

                    if (detail != null && detail.gpsRoute.hasRoute) {
                        Text(if (tr) "GPS Rotası" else "GPS Route", color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black)
                        RouteMapCard(palette = palette, route = detail.gpsRoute)
                        HistoryDetailLine(
                            palette,
                            if (tr) "Rota kaydı" else "Route recording",
                            if (tr) "${detail.gpsRoute.pointCount} nokta • ${detail.gpsRoute.segments.size} segment" else "${detail.gpsRoute.pointCount} points • ${detail.gpsRoute.segments.size} segments"
                        )
                        Text(
                            if (tr) "Harita zemini internet varsa yüklenir. İnternet olmasa da GPS rota kaydı sürer ve rota verisi cihazda kalır." else "The basemap loads when internet is available. GPS route recording continues without internet and route data stays on the device.",
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )
                        TextButton(
                            onClick = { onExportGpsRoute(item.id) },
                            enabled = !obdState.exportInProgress
                        ) {
                            Text(if (tr) "Rotayı GPX olarak dışa aktar" else "Export route as GPX")
                        }
                    } else if (detail != null && settings.gpsRouteEnabled) {
                        Text(
                            if (tr) "Bu sürüşte kullanılabilir GPS rota kaydı yok." else "No usable GPS route was recorded for this drive.",
                            color = palette.textSecondary,
                            fontSize = 12.sp
                        )
                    }

                    if (obdState.driveHistoryDetailLoading && detail == null) {
                        Text(if (tr) "Sürüş grafikleri yükleniyor…" else "Loading drive charts…", color = palette.textSecondary, fontSize = 13.sp)
                    } else if (detail != null && detail.points.isNotEmpty()) {
                        Text(if (tr) "Gelişmiş Sürüş Analizi" else "Advanced Drive Analysis", color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black)
                        Text(
                            if (tr) "Yalnız kayıtlı OBD örneklerinden hesaplanan gerçek sürüş ölçümleri." else "Factual drive metrics calculated only from stored OBD samples.",
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        val stationaryShare = historyRatio(detail.stationaryDurationMs, detail.engineRunningDurationMs)
                        val stationaryFuelShare = if (item.fuelUsedL > 0.0001) (detail.stationaryFuelUsedL / item.fuelUsedL * 100.0).coerceIn(0.0, 100.0) else null
                        val acUsage = if (detail.acKnownDurationMs >= 30_000L) historyRatio(detail.acOnDurationMs, detail.acKnownDurationMs) else null
                        val cutoffUsage = if (detail.fuelSourceKnownDurationMs >= 30_000L) historyRatio(detail.cutoffDurationMs, detail.fuelSourceKnownDurationMs) else null

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            CompletionMetric(
                                palette,
                                if (tr) "Hareketli ortalama" else "Moving average",
                                detail.movingAverageL100?.let { String.format(Locale.US, "%.2f L/100 km", it) } ?: "--",
                                Modifier.weight(1f)
                            )
                            CompletionMetric(
                                palette,
                                if (tr) "Hareketli hız" else "Moving speed",
                                detail.averageMovingSpeedKmh?.let { String.format(Locale.US, "%.1f km/h", it) } ?: "--",
                                Modifier.weight(1f)
                            )
                        }
                        HistoryDetailLine(palette, if (tr) "Motor çalışır süre" else "Engine-running time", historyDuration(detail.engineRunningDurationMs))
                        HistoryDetailLine(palette, if (tr) "Hareket halinde" else "Moving time", historyDuration(detail.movingDurationMs))
                        HistoryDetailLine(
                            palette,
                            if (tr) "Rölantide geçen süre" else "Stationary engine time",
                            historyDuration(detail.stationaryDurationMs) + stationaryShare?.let { " • ${String.format(Locale.US, "%.1f", it)}%" }.orEmpty()
                        )
                        HistoryDetailLine(
                            palette,
                            if (tr) "Rölanti yakıtı" else "Stationary fuel",
                            String.format(Locale.US, "%.3f L", detail.stationaryFuelUsedL) + stationaryFuelShare?.let { " • ${String.format(Locale.US, "%.1f", it)}%" }.orEmpty()
                        )
                        HistoryDetailLine(
                            palette,
                            if (tr) "Hareket halinde kullanılan yakıt" else "Fuel used while moving",
                            detail.movingFuelUsedL?.let { String.format(Locale.US, "%.3f L", it) } ?: "--"
                        )
                        HistoryDetailLine(
                            palette,
                            if (tr) "Klima kullanım oranı" else "A/C usage",
                            acUsage?.let { String.format(Locale.US, "%.1f%%", it) } ?: "--"
                        )
                        HistoryDetailLine(
                            palette,
                            if (tr) "Yakıt kesme süresi" else "Fuel cut-off time",
                            if (detail.fuelSourceKnownDurationMs > 0L) {
                                historyDuration(detail.cutoffDurationMs) + cutoffUsage?.let { " • ${String.format(Locale.US, "%.1f", it)}%" }.orEmpty()
                            } else {
                                "--"
                            }
                        )
                        Text(
                            if (tr) "Hareketli ortalama, toplam sürüş yakıtından rölantide tüketilen yakıt çıkarılarak hesaplanır. Klima oranı yalnız klima durumu bilinen örnekleri; yakıt kesme oranı yalnız güvenilir yakıt-kaynağı örneklerini kullanır." else "Moving average subtracts stationary fuel from total trip fuel. A/C ratio uses only samples with known A/C state; fuel cut-off ratio uses only trustworthy fuel-source samples.",
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            lineHeight = 14.sp
                        )

                        HistoryChartCard(palette, if (tr) "Hız" else "Speed", detail.points.mapNotNull { it.speedKmh }, "km/h", palette.accent)
                        HistoryChartCard(palette, if (tr) "Devir" else "RPM", detail.points.mapNotNull { it.rpm }, "rpm", palette.textPrimary)
                        HistoryChartCard(palette, if (tr) "Tüketim" else "Consumption", detail.points.mapNotNull { it.consumption }, "L/100 km", LoganFuelInstantRed)
                        HistoryChartCard(palette, if (tr) "Hararet" else "Coolant", detail.points.mapNotNull { it.coolantC }, "°C", coolantAccentColor(palette, item.endTempC))
                    } else if (!obdState.driveHistoryDetailLoading) {
                        Text(if (tr) "Bu sürüş için grafik oluşturacak örnek bulunamadı." else "No samples were available to build charts for this drive.", color = palette.textSecondary, fontSize = 13.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { selected = null; onClearHistoryDetail(); onExportHistory(item.id) }) { Text(if (tr) "Dışa aktar" else "Export") } },
            dismissButton = { TextButton(onClick = { selected = null; onClearHistoryDetail() }) { Text(if (tr) "Kapat" else "Close") } }
        )
    }

    deleteCandidate?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteCandidate = null },
            title = { Text(if (tr) "Sürüş kaydı silinsin mi?" else "Delete drive record?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Bu sürüş ve ilişkili OBD örnekleri kalıcı olarak silinecek. Dışa aktarılmış dosyalar etkilenmez." else "This drive and its related OBD samples will be permanently deleted. Exported files are not affected.", color = palette.textSecondary) },
            confirmButton = {
                TextButton(onClick = { deleteCandidate = null; onDeleteHistory(item.id) }, enabled = !moving && !item.activeLike) {
                    Text(if (tr) "Sil" else "Delete")
                }
            },
            dismissButton = { TextButton(onClick = { deleteCandidate = null }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
}

private fun historyRatio(partMs: Long, totalMs: Long): Double? {
    if (totalMs <= 0L) return null
    return (partMs.toDouble() / totalMs.toDouble() * 100.0).coerceIn(0.0, 100.0)
}

@Composable
private fun TripCenterMetric(
    palette: LoganPalette,
    label: String,
    value: String,
    icon: CardIcon,
    modifier: Modifier = Modifier
) {
    OemCard(palette, modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MetricIcon(palette, icon, modifier = Modifier.size(28.dp))
            Column {
                Text(label, color = palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(value, color = palette.textPrimary, fontSize = 17.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
        }
    }
}

@Composable
private fun HistoryChartCard(
    palette: LoganPalette,
    title: String,
    values: List<Float>,
    unit: String,
    color: Color
) {
    val clean = values.filter { it.isFinite() && it >= 0f }
    if (clean.isEmpty()) return
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(title, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text("${String.format(Locale.US, "%.1f", clean.last())} $unit", color = palette.textSecondary, fontSize = 12.sp)
            }
            ConsumptionSparkline(
                values = clean,
                lineColor = color,
                guideColor = palette.line,
                modifier = Modifier.fillMaxWidth().height(56.dp)
            )
        }
    }
}

@Composable
private fun DriveHistoryCard(
    palette: LoganPalette,
    item: DriveHistoryItem,
    language: AppLanguage,
    fuelPriceText: String,
    moving: Boolean,
    onInspect: () -> Unit,
    onPin: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val tr = language != AppLanguage.English
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                    Text(driveStatusLabel(item.status, language), color = if (item.activeLike) palette.accent else palette.textSecondary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
                if (item.pinned) Text("★", color = palette.accent, fontSize = 21.sp)
            }
            Text(
                "${String.format(Locale.US, "%.2f", item.distanceKm)} km • ${historyDuration(item.durationMs)} • ${item.averageL100?.let { String.format(Locale.US, "%.2f L/100 km", it) } ?: "--"}",
                color = palette.textSecondary,
                fontSize = 13.sp
            )
            Text(
                "${String.format(Locale.US, "%.3f L", item.fuelUsedL)} • ${historyCostText(item.fuelUsedL, fuelPriceText)}${if (item.sessionCount > 1) " • ${item.sessionCount} OBD oturumu" else ""}",
                color = palette.textSecondary,
                fontSize = 12.sp
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(onClick = onInspect, modifier = Modifier.weight(1f)) { Text(if (tr) "İncele" else "Inspect", fontSize = 11.sp) }
                TextButton(onClick = onExport, modifier = Modifier.weight(1f)) { Text(if (tr) "Dışa aktar" else "Export", fontSize = 11.sp) }
                TextButton(onClick = onPin, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (item.pinned) (if (tr) "Korumayı kaldır" else "Unpin") else (if (tr) "Koru" else "Pin"), fontSize = 11.sp) }
                TextButton(onClick = onDelete, enabled = !moving && !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (tr) "Sil" else "Delete", fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun HistoryDetailLine(palette: LoganPalette, label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = palette.textSecondary, fontSize = 13.sp)
        Text(value, color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
    }
}

private fun historyCostText(fuelUsedL: Double, fuelPriceText: String): String {
    val price = fuelPriceText.replace(',', '.').toDoubleOrNull()
    return if (price != null && price > 0.0) {
        String.format(Locale.US, "%.2f ₺", fuelUsedL.coerceAtLeast(0.0) * price)
    } else "--"
}

private fun historyDate(ms: Long, trusted: Boolean, language: AppLanguage): String {
    if (!trusted || ms <= 0L) return if (language == AppLanguage.English) "Time pending" else "Saat eşitleniyor"
    return SimpleDateFormat("dd.MM.yyyy • HH:mm", Locale.getDefault()).format(Date(ms))
}

private fun historyDuration(ms: Long): String {
    val totalSeconds = ms.coerceAtLeast(0L) / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return when {
        hours > 0L -> "%d sa %02d dk".format(hours, minutes)
        minutes > 0L -> "%d dk %02d sn".format(minutes, seconds)
        else -> "%d sn".format(seconds)
    }
}

private fun driveStatusLabel(status: String, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (status) {
        "ACTIVE" -> if (tr) "Aktif sürüş" else "Active drive"
        "PARKED" -> if (tr) "Mola • devam edebilir" else "Paused • may continue"
        "TIME_PENDING" -> if (tr) "Saat doğrulaması bekleniyor" else "Waiting for trusted time"
        "RECOVERED" -> if (tr) "Kontak kesintisinden kurtarıldı" else "Recovered after power loss"
        else -> if (tr) "Tamamlandı" else "Completed"
    }
}


@Composable
private fun VehicleHealthPage(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit,
    onRefreshHistory: () -> Unit,
    onPinHistory: (Long, Boolean) -> Unit,
    onDeleteHistory: (Long) -> Unit,
    onExportHistory: (Long) -> Unit
) {
    val language = settings.language
    val tr = language != AppLanguage.English
    val healthReport = VehicleHealthAnalyzer.analyze(settings, snapshot, obdState)
    var confirmClear by remember { mutableStateOf(false) }
    var selectedHistory by remember { mutableStateOf<TestHistoryItem?>(null) }
    var deleteHistory by remember { mutableStateOf<TestHistoryItem?>(null) }
    val last = obdState.startEvents.firstOrNull()
    val startSummary = obdState.startAnalysisSummary
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(if (tr) "Araç Sağlığı" else "Vehicle Health", color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text(
                if (tr) "Canlı veriler, kayıtlı sürüşler, marş analizi ve manuel testler tek merkezde." else "Live data, stored drives, start analysis and manual tests in one place.",
                color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
        item { VehicleHealthOverviewCard(palette, healthReport, language) }
        items(healthReport.findings, key = { "health_${it.id}" }) { finding ->
            VehicleHealthFindingCard(palette, finding, language)
        }
        item {
            Text(
                if (tr) "Araç Sağlığı kesin arıza teşhisi koymaz ve DTC okumaz; yalnız LoganOS'un güvenilir verilerini temkinli biçimde yorumlar." else "Vehicle Health does not provide a definitive diagnosis or read DTCs; it conservatively interprets only data LoganOS trusts.",
                color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp, modifier = Modifier.padding(horizontal = 2.dp)
            )
        }
        item {
            Spacer(Modifier.height(6.dp))
            Text(if (tr) "Marş Analizi" else "Cranking Analysis", color = palette.textPrimary, fontSize = 25.sp, fontWeight = FontWeight.Black)
            Text(
                if (tr) "Otomatik algılama + manuel test. Kesin arıza teşhisi değildir." else "Automatic detection + manual test. This is not a definitive diagnosis.",
                color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
            )
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Otomatik Marş Eğilimi" else "Automatic Start Trend", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text(if (tr) startSummary.trendMessageTr else startSummary.trendMessageEn, color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        DataCard(palette, if (tr) "Soğuk Ort." else "Cold Avg", startSummary.coldAverageMs?.let { String.format(Locale.US, "%.2f", it / 1000.0) } ?: "--", if (tr) "sn" else "s", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(84.dp))
                        DataCard(palette, if (tr) "Sıcak Ort." else "Hot Avg", startSummary.hotAverageMs?.let { String.format(Locale.US, "%.2f", it / 1000.0) } ?: "--", if (tr) "sn" else "s", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(84.dp))
                    }
                    Text(
                        if (tr) "${startSummary.totalRecorded} kayıt • ${startSummary.coldCount} güvenilir soğuk • ${startSummary.hotCount} güvenilir sıcak • ${startSummary.failedRecorded} başarısız/tamamlanmamış"
                        else "${startSummary.totalRecorded} records • ${startSummary.coldCount} reliable cold • ${startSummary.hotCount} reliable hot • ${startSummary.failedRecorded} unsuccessful/incomplete",
                        color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp
                    )
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Manuel Marş Testi" else "Manual Cranking Test", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    Text(
                        when {
                            obdState.crankingInProgress -> if (tr) "Marş algılandı, veriler analiz ediliyor..." else "Cranking detected, analyzing data..."
                            obdState.manualCrankArmed -> if (tr) "Hazır. Şimdi marşa basın." else "Ready. Start the engine now."
                            obdState.connected -> if (tr) "Motor çalışmadan önce testi başlatın, ardından marşa basın." else "Start the test before the engine is running, then crank the engine."
                            else -> if (tr) "Test için önce OBD bağlantısı gerekli." else "OBD connection is required before testing."
                        },
                        color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        DataCard(palette, if (tr) "RPM" else "RPM", obdState.snapshot.rpm?.toString() ?: "--", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(84.dp))
                        DataCard(palette, if (tr) "Akü" else "Battery", obdState.snapshot.batteryV?.let { String.format(Locale.US, "%.1f", it) } ?: obdState.snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
                    }
                    Button(
                        onClick = onStartCrankAnalysis,
                        enabled = obdState.connected && !obdState.manualCrankArmed && !obdState.crankingInProgress,
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) { Text(if (tr) "Marş Analizini Başlat" else "Start Cranking Analysis") }
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Son Otomatik Marşlar" else "Recent Automatic Starts", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.startEvents.isEmpty()) {
                        Text(if (tr) "Henüz kalıcı marş kaydı yok. LoganOS OBD bağlıyken motorun duruştan çalışmaya geçişini otomatik izler." else "No persistent start record yet. While OBD is connected, LoganOS automatically observes the transition from engine-off to running.", color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
                    } else {
                        obdState.startEvents.take(10).forEach { event ->
                            StartEventRow(palette, event, language)
                        }
                    }
                    Text(if (tr) "Düşük güvenli veya OBD boşluklu kayıtlar kişisel trend ortalamasına dahil edilmez. Tek bir kayıt parça arızası teşhisi olarak yorumlanmaz." else "Low-confidence or OBD-gap records are excluded from the personal trend baseline. A single record is not treated as a component diagnosis.", color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                }
            }
        }
        item {
            OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(if (tr) "Kayıtlı Manuel Testler" else "Saved Manual Tests", color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
                    if (obdState.savedManualCrankTests.isEmpty()) {
                        Text(if (tr) "Manuel başlatılmış kayıtlı test yok." else "No saved manual tests.", color = palette.textSecondary, fontSize = 13.sp)
                    } else {
                        obdState.savedManualCrankTests.take(8).forEachIndexed { index, result ->
                            Text("#${index + 1} • ${crankDate(result.timestampMs, language)} • ${String.format(Locale.US, "%.1f", result.durationSec)} sn • ${localCrankStatus(result.status, language)}", color = palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 15.sp)
                        }
                        TextButton(onClick = { confirmClear = true }) { Text(if (tr) "Manuel marş testlerini sil" else "Delete manual cranking tests") }
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(Modifier.weight(1f)) {
                    Text(if (tr) "Test Geçmişi" else "Test History", color = palette.textPrimary, fontSize = 22.sp, fontWeight = FontWeight.Black)
                    Text(if (tr) "Başlatılan teknik ve manuel testler otomatik kaydedilir" else "Started technical and manual tests are saved automatically", color = palette.textSecondary, fontSize = 12.sp)
                }
                TextButton(onClick = onRefreshHistory) { Text(if (tr) "Yenile" else "Refresh") }
            }
        }
        if (obdState.testHistory.isEmpty()) {
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Text(if (tr) "Henüz otomatik kaydedilmiş test yok." else "No automatically saved test yet.", color = palette.textSecondary, fontSize = 13.sp)
                }
            }
        } else {
            items(obdState.testHistory.size, key = { obdState.testHistory[it].id }) { index ->
                val item = obdState.testHistory[index]
                TestHistoryCard(
                    palette = palette,
                    item = item,
                    language = language,
                    onInspect = { selectedHistory = item },
                    onPin = { onPinHistory(item.id, !item.pinned) },
                    onExport = { onExportHistory(item.id) },
                    onDelete = { deleteHistory = item }
                )
            }
        }
        if (last != null) {
            item {
                DataCard(
                    palette,
                    if (tr) "Son marş" else "Latest start",
                    if (last.successful) (last.crankDurationMs?.let { String.format(Locale.US, "%.2f sn", it / 1000.0) } ?: if (tr) "Süre ölçülemedi" else "Duration unavailable") else (if (tr) "Başarısız/tamamlanmamış" else "Unsuccessful/incomplete"),
                    subtitle = if (tr) "${startThermalLabel(last.thermalClass, language)} • ${startConfidenceLabel(last.confidence, language)}${if (last.attemptCount > 1) " • ${last.attemptCount}. deneme" else ""}" else "${startThermalLabel(last.thermalClass, language)} • ${startConfidenceLabel(last.confidence, language)}${if (last.attemptCount > 1) " • attempt ${last.attemptCount}" else ""}",
                    icon = CardIcon.Time,
                    modifier = Modifier.fillMaxWidth().height(106.dp)
                )
            }
        }
    }
    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(if (tr) "Marş kayıtları silinsin mi?" else "Delete cranking records?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Eski geçici manuel marş sonuçları silinecek. Yeni Test Geçmişi kayıtları bu işlemden etkilenmez." else "Legacy temporary manual crank results will be deleted. New Test History records are not affected.", color = palette.textSecondary) },
            confirmButton = { TextButton(onClick = { confirmClear = false; onClearManualCrankTests() }) { Text(if (tr) "Sil" else "Delete") } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
    selectedHistory?.let { item ->
        AlertDialog(
            onDismissRequest = { selectedHistory = null },
            title = { Text(item.name, color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(historyDate(item.startedAtMs, item.timeTrusted, language), color = palette.textPrimary, fontWeight = FontWeight.Bold)
                    HistoryDetailLine(palette, if (tr) "Tür" else "Type", item.testType)
                    HistoryDetailLine(palette, if (tr) "Durum" else "Status", testStatusLabel(item.status, language))
                    HistoryDetailLine(palette, if (tr) "Süre" else "Duration", historyDuration(item.durationMs))
                    HistoryDetailLine(palette, if (tr) "Örnek" else "Samples", item.sampleCount.toString())
                    item.summary?.let { Text(it, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp) }
                }
            },
            confirmButton = { TextButton(onClick = { selectedHistory = null; onExportHistory(item.id) }) { Text(if (tr) "Dışa aktar" else "Export") } },
            dismissButton = { TextButton(onClick = { selectedHistory = null }) { Text(if (tr) "Kapat" else "Close") } }
        )
    }
    deleteHistory?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteHistory = null },
            title = { Text(if (tr) "Test kaydı silinsin mi?" else "Delete test record?", color = palette.textPrimary, fontWeight = FontWeight.Black) },
            text = { Text(if (tr) "Test ve ilişkili örnekler kalıcı olarak silinecek. Dışa aktarılmış dosyalar etkilenmez." else "The test and its related samples will be permanently deleted. Exported files are not affected.", color = palette.textSecondary) },
            confirmButton = { TextButton(onClick = { deleteHistory = null; onDeleteHistory(item.id) }, enabled = !item.activeLike) { Text(if (tr) "Sil" else "Delete") } },
            dismissButton = { TextButton(onClick = { deleteHistory = null }) { Text(if (tr) "İptal" else "Cancel") } }
        )
    }
}

@Composable
private fun TestHistoryCard(
    palette: LoganPalette,
    item: TestHistoryItem,
    language: AppLanguage,
    onInspect: () -> Unit,
    onPin: () -> Unit,
    onExport: () -> Unit,
    onDelete: () -> Unit
) {
    val tr = language != AppLanguage.English
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(item.name, color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text("${historyDate(item.startedAtMs, item.timeTrusted, language)} • ${testStatusLabel(item.status, language)}", color = palette.textSecondary, fontSize = 11.sp)
                }
                if (item.pinned) Text("★", color = palette.accent, fontSize = 21.sp)
            }
            Text("${historyDuration(item.durationMs)} • ${item.sampleCount} ${if (tr) "örnek" else "samples"}", color = palette.textSecondary, fontSize = 13.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                TextButton(onClick = onInspect, modifier = Modifier.weight(1f)) { Text(if (tr) "İncele" else "Inspect", fontSize = 11.sp) }
                TextButton(onClick = onExport, modifier = Modifier.weight(1f)) { Text(if (tr) "Dışa aktar" else "Export", fontSize = 11.sp) }
                TextButton(onClick = onPin, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (item.pinned) (if (tr) "Korumayı kaldır" else "Unpin") else (if (tr) "Koru" else "Pin"), fontSize = 11.sp) }
                TextButton(onClick = onDelete, enabled = !item.activeLike, modifier = Modifier.weight(1f)) { Text(if (tr) "Sil" else "Delete", fontSize = 11.sp) }
            }
        }
    }
}

private fun testStatusLabel(status: String, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (status) {
        "ACTIVE" -> if (tr) "Aktif" else "Active"
        "INTERRUPTED" -> if (tr) "Kesintiye uğradı" else "Interrupted"
        "COMPLETED_MANUAL" -> if (tr) "Manuel tamamlandı" else "Completed manually"
        else -> if (tr) "Tamamlandı" else "Completed"
    }
}

@Composable
private fun StartEventRow(palette: LoganPalette, event: StartEvent, language: AppLanguage) {
    val tr = language != AppLanguage.English
    val duration = event.crankDurationMs?.let { String.format(Locale.US, "%.2f ${if (tr) "sn" else "s"}", it / 1000.0) }
        ?: if (tr) "Süre ölçülemedi" else "Duration unavailable"
    val result = if (event.successful) duration else if (tr) "Başarısız/tamamlanmamış" else "Unsuccessful/incomplete"
    Text(
        "${crankDate(event.timestampMs, language)} • ${startThermalLabel(event.thermalClass, language)} • $result",
        color = palette.textPrimary,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
    )
    Text(
        buildString {
            append(startConfidenceLabel(event.confidence, language))
            if (event.attemptCount > 1) append(if (tr) " • ${event.attemptCount}. deneme" else " • attempt ${event.attemptCount}")
            event.stabilizationDurationMs?.let { append(if (tr) " • stabilizasyon ${String.format(Locale.US, "%.1f", it / 1000.0)} sn" else " • stabilization ${String.format(Locale.US, "%.1f", it / 1000.0)} s") }
            if (event.obdGapDetected) append(if (tr) " • OBD boşluğu" else " • OBD gap")
        },
        color = palette.textSecondary,
        fontSize = 11.sp,
        lineHeight = 15.sp
    )
}

private fun startThermalLabel(value: StartThermalClass, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (value) {
        StartThermalClass.COLD -> if (tr) "Soğuk" else "Cold"
        StartThermalClass.WARM -> if (tr) "Ilık" else "Warm"
        StartThermalClass.HOT -> if (tr) "Sıcak" else "Hot"
        StartThermalClass.UNKNOWN -> if (tr) "Sıcaklık bilinmiyor" else "Temperature unknown"
    }
}

private fun startConfidenceLabel(value: StartConfidence, language: AppLanguage): String {
    val tr = language != AppLanguage.English
    return when (value) {
        StartConfidence.HIGH -> if (tr) "Yüksek güven" else "High confidence"
        StartConfidence.MEDIUM -> if (tr) "Orta güven" else "Medium confidence"
        StartConfidence.LOW -> if (tr) "Düşük güven" else "Low confidence"
    }
}

@Composable
private fun CrankResultBlock(palette: LoganPalette, result: CrankAnalysisResult, language: AppLanguage) {
    val tr = language != AppLanguage.English
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        DataCard(palette, if (tr) "Süre" else "Duration", String.format(Locale.US, "%.1f", result.durationSec), if (tr) "sn" else "s", icon = CardIcon.Time, modifier = Modifier.weight(1f).height(84.dp))
        DataCard(palette, if (tr) "Min Volt" else "Min Volt", result.minVoltage?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "V", icon = CardIcon.Battery, modifier = Modifier.weight(1f).height(84.dp))
    }
    Spacer(Modifier.height(6.dp))
    Text("${localCrankStatus(result.status, language)} • ${localBatteryStatus(result.batteryStatus, language)}", color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
    Text(localCrankComment(result, language), color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
}

private fun crankDate(ms: Long, language: AppLanguage): String = if (ms > 0L) {
    SimpleDateFormat("dd.MM HH:mm", Locale.US).format(Date(ms))
} else if (language == AppLanguage.English) {
    "Time pending"
} else {
    "Saat bekleniyor"
}

private fun localBatteryStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "İyi" -> "Good"
        "Sınırda" -> "Borderline"
        "Zayıf" -> "Weak"
        "Çok düşük" -> "Very low"
        "Ölçülemedi" -> "Not measured"
        else -> status
    }
}

private fun localCrankStatus(status: String, language: AppLanguage): String {
    if (language != AppLanguage.English) return status
    return when (status) {
        "Normal" -> "Normal"
        "Hafif uzun" -> "Slightly long"
        "Geç marş" -> "Long crank"
        "Belirgin geç marş" -> "Very long crank"
        "Tamamlanamadı" -> "Incomplete"
        "Kaydedildi" -> "Recorded"
        "Düşük güven" -> "Low confidence"
        else -> status
    }
}

private fun localCrankComment(result: CrankAnalysisResult, language: AppLanguage): String {
    if (language != AppLanguage.English) return result.comment
    return when (result.status) {
        "Normal" -> "Cranking duration looks normal. Battery voltage and RPM response are within an acceptable range."
        "Hafif uzun" -> "Cranking is slightly long. Monitor it if it repeats."
        "Geç marş" -> "Cranking is long. Battery, fuel line, crank/cam signal and glow-plug system can be checked."
        "Belirgin geç marş" -> "A very long crank was detected. Battery/ground, starter load, fuel pressure and sensor sync should be checked."
        else -> "Cranking analysis could not be completed; OBD response or RPM data may have been interrupted."
    } + if (result.obdGapDetected) " A short OBD response gap was seen during cranking." else ""
}


private fun vehicleHealthStatusLabel(level: VehicleHealthLevel, language: AppLanguage): String {
    val english = language == AppLanguage.English
    return when (level) {
        VehicleHealthLevel.NORMAL -> if (english) "Looks normal" else "Normal görünüyor"
        VehicleHealthLevel.WATCH -> if (english) "Monitor" else "Takip edilmeli"
        VehicleHealthLevel.CHECK_RECOMMENDED -> if (english) "Check recommended" else "Kontrol önerilir"
        VehicleHealthLevel.INSUFFICIENT_DATA -> if (english) "Insufficient data" else "Veri yetersiz"
    }
}

private fun vehicleHealthStatusColor(palette: LoganPalette, level: VehicleHealthLevel): Color = when (level) {
    VehicleHealthLevel.NORMAL -> palette.accent
    VehicleHealthLevel.WATCH -> palette.warning
    VehicleHealthLevel.CHECK_RECOMMENDED -> palette.critical
    VehicleHealthLevel.INSUFFICIENT_DATA -> palette.muted
}

@Composable
private fun VehicleHealthOverviewCard(
    palette: LoganPalette,
    report: VehicleHealthReport,
    language: AppLanguage
) {
    val english = language == AppLanguage.English
    val statusColor = vehicleHealthStatusColor(palette, report.overallLevel)
    val normalCount = report.findings.count { it.level == VehicleHealthLevel.NORMAL }
    val watchCount = report.findings.count { it.level == VehicleHealthLevel.WATCH }
    val checkCount = report.findings.count { it.level == VehicleHealthLevel.CHECK_RECOMMENDED }
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        vehicleHealthStatusLabel(report.overallLevel, language).uppercase(),
                        color = statusColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(report.summary, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Bold, lineHeight = 21.sp)
                }
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .clip(RoundedCornerShape(9.dp))
                        .background(statusColor)
                )
            }
            Text(
                if (english) {
                    "${report.completedDriveCount} eligible drives available • $normalCount normal • $watchCount monitor • $checkCount check"
                } else {
                    "${report.completedDriveCount} değerlendirilen sürüş mevcut • $normalCount normal • $watchCount takip • $checkCount kontrol"
                },
                color = palette.textSecondary,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
private fun VehicleHealthFindingCard(
    palette: LoganPalette,
    finding: VehicleHealthFinding,
    language: AppLanguage
) {
    val statusColor = vehicleHealthStatusColor(palette, finding.level)
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(finding.title, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Text(
                    vehicleHealthStatusLabel(finding.level, language),
                    color = statusColor,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.End
                )
            }
            Text(finding.summary, color = palette.textSecondary, fontSize = 12.sp, lineHeight = 17.sp)
            Text(finding.evidence, color = statusColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, lineHeight = 14.sp)
        }
    }
}

@Composable
private fun TechnicalPage(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onSaveLog: () -> Unit,
    onShareLog: () -> Unit,
    onCreateSupportPackage: () -> Uri?,
    onClearLastLog: () -> Unit,
    onClearAllLogs: () -> Unit
) {
    val english = settings.language == AppLanguage.English
    fun t(tr: String, en: String): String = if (english) en else tr
    LazyColumn(modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(t("Teknik Veriler", "Technical Data"), color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
            Text(t("OBD bağlantısı, gelişmiş canlı değerler, teknik loglar ve destek araçları", "OBD connection, advanced live values, technical logs and support tools"), color = palette.textSecondary, fontSize = 13.sp, lineHeight = 18.sp)
        }
        item { TechnicalConnectionStatus(palette, snapshot, obdState, settings.language) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, "RPM", snapshot.rpm?.toString() ?: "--", "rpm", icon = CardIcon.Rpm, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, t("Hız", "Speed"), snapshot.speedKmh?.toString() ?: "--", "km/h", icon = CardIcon.Speed, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, t("Hararet", "Coolant"), snapshot.engineTempC?.toString() ?: "--", "°C", subtitle = t("Soğutma suyu", "Coolant temperature"), icon = CardIcon.Temperature, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, t("Klima", "A/C"), when (snapshot.acOn) { true -> t("Açık", "On"); false -> t("Kapalı", "Off"); null -> "--" }, null, icon = CardIcon.Ac, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        if (settings.isExperimentalPetrol) {
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(t("BENZİNLİ DENEYSEL PROFİL", "EXPERIMENTAL PETROL PROFILE"), color = palette.warning, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text(
                            t("Tüketim ve maliyet kapalıdır. Aşağıdaki değerler enjeksiyon/fuel-rate adayını bulmak için kaydedilir; MAF üzerinden yakıt hesabı yapılmaz.", "Consumption and cost are disabled. The values below are recorded to locate an injection/fuel-rate candidate; fuel is not calculated from MAF."),
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Fuel-rate adayı", "Fuel-rate candidate"), snapshot.engineFuelRateLh?.let { String.format(Locale.US, "%.3f", it) } ?: "--", "L/h", icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, "MAF", snapshot.mafGramsPerSec?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "g/s", subtitle = t("Sadece karşılaştırma", "Comparison only"), icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "STFT", snapshot.shortFuelTrimPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, "LTFT", snapshot.longFuelTrimPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Lambda komutu", "Commanded lambda"), snapshot.commandedEquivalenceRatio?.let { String.format(Locale.US, "%.3f", it) } ?: "--", null, icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Yakıt sistemi", "Fuel system"), snapshot.fuelSystemStatus ?: "--", null, icon = CardIcon.EcuStatus, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Gaz kelebeği", "Throttle"), snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, "MAP", snapshot.mapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Motor yükü", "Engine load"), snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Emme havası", "Intake air"), snapshot.intakeTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.IntakeAirTemp, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(t("Desteklenen standart PID'ler", "Supported standard PIDs"), color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                        Text(
                            obdState.supportedStandardPids.sorted().joinToString { "01%02X".format(Locale.US, it) }.ifBlank { "--" },
                            color = palette.textSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        } else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "L/h", if (snapshot.instantUnit == "L/h") fmt(snapshot.instantConsumption) else "--", "L/h", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, "L/100", if (snapshot.instantUnit != "L/h") fmt(snapshot.instantConsumption) else "--", "L/100", icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Ortalama", "Average"), fmt(snapshot.averageConsumption), "L/100", icon = CardIcon.FuelAverage, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Yakıt Hesabı", "Fuel Calculation"), fuelSourceLabel(snapshot.fuelSource), null, icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Pedal", "Pedal"), snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, "MAP", snapshot.mapMbar?.toString() ?: "--", "mbar", icon = CardIcon.MapPressure, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Rail", "Rail"), snapshot.railBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.FuelPressure, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Rail Hedef", "Target Rail"), snapshot.railTargetBar?.let { String.format(Locale.US, "%.0f", it) } ?: "--", "bar", icon = CardIcon.RailTarget, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Hava Yükü", "Air Load"), snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Hedef MAP", "Target MAP"), snapshot.requestedMapMbar?.toString() ?: "--", "mbar", icon = CardIcon.TargetMap, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, t("Emme Havası", "Intake Air"), snapshot.intakeTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.IntakeAirTemp, modifier = Modifier.weight(1f).height(88.dp))
                    DataCard(palette, t("Yakıt Isı", "Fuel Temp"), snapshot.fuelTempC?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "°C", icon = CardIcon.FuelTemp, modifier = Modifier.weight(1f).height(88.dp))
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                DataCard(palette, t("Sensör V", "Sensor V"), snapshot.sensorSupplyV?.let { String.format(Locale.US, "%.3f", it) } ?: "--", "V", icon = CardIcon.SensorVoltage, modifier = Modifier.weight(1f).height(88.dp))
                DataCard(palette, t("Adaptör V", "Adapter V"), snapshot.adapterVoltageV?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "V", icon = CardIcon.AdapterVoltage, modifier = Modifier.weight(1f).height(88.dp))
            }
        }
        if (settings.developerModeEnabled) {
            item { FuelTruthTestPanel(palette, snapshot, settings) }
        }
        item { TechnicalQualityPanel(palette, obdState, settings.language) }
    }
}


@Composable
private fun TechnicalConnectionStatus(palette: LoganPalette, snapshot: DashboardSnapshot, obdState: ObdState, language: AppLanguage) {
    val english = language == AppLanguage.English
    fun t(tr: String, en: String): String = if (english) en else tr
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(t("BAĞLANTI DURUMU", "CONNECTION STATUS"), color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            val ignitionOff = obdState.status.contains("Kontak kapalı", ignoreCase = true) ||
                (obdState.connectionHealthReason?.contains("Kontak kapalı", ignoreCase = true) == true)
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette = palette,
                    label = "OBD",
                    value = if (ignitionOff) {
                        t("Kontak kapalı", "Ignition off")
                    } else when (obdState.connectionHealth) {
                        ObdConnectionHealth.DATA_STALE -> t("Veri bekleniyor", "Waiting for data")
                        ObdConnectionHealth.UNSTABLE -> t("Bağlantı kararsız", "Connection unstable")
                        ObdConnectionHealth.RECONNECTING -> t("Yeniden bağlanıyor", "Reconnecting")
                        ObdConnectionHealth.CONNECTING -> t("Bağlanıyor", "Connecting")
                        ObdConnectionHealth.STABLE -> if (snapshot.connected) t("Bağlı", "Connected") else t("Veri bekleniyor", "Waiting for data")
                        ObdConnectionHealth.DISCONNECTED -> if (snapshot.connected) t("Bağlı", "Connected") else t("Bekliyor", "Waiting")
                    },
                    color = if (ignitionOff) {
                        palette.warning
                    } else when (obdState.connectionHealth) {
                        ObdConnectionHealth.DATA_STALE, ObdConnectionHealth.UNSTABLE, ObdConnectionHealth.RECONNECTING, ObdConnectionHealth.CONNECTING -> palette.warning
                        ObdConnectionHealth.STABLE -> if (snapshot.connected) palette.accent else palette.warning
                        ObdConnectionHealth.DISCONNECTED -> if (snapshot.connected) palette.accent else palette.textSecondary
                    },
                    modifier = Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette = palette,
                    label = "ECU",
                    value = if (obdState.activeProfile == "GENERIC_PETROL_EXPERIMENTAL") t("Genel benzinli", "Generic petrol") else "DCM1.2",
                    color = if (obdState.activeProfile == "GENERIC_PETROL_EXPERIMENTAL") palette.warning else palette.accent,
                    modifier = Modifier.weight(1f)
                )
            }
            if (!obdState.connectionHealthReason.isNullOrBlank()) {
                Text(
                    text = t("Guard: ", "Guard: ") + obdState.connectionHealthReason,
                    color = if (obdState.connectionHealth == ObdConnectionHealth.DATA_STALE || obdState.connectionHealth == ObdConnectionHealth.UNSTABLE) palette.warning else palette.textSecondary,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette,
                    t("Protokol", "Protocol"),
                    if (obdState.activeProfile == "GENERIC_PETROL_EXPERIMENTAL") "OBD-II Mode 01 / Auto" else "KWP Fast Init",
                    palette.blue,
                    Modifier.weight(1f)
                )
                TechnicalStatusItem(palette, "Loop", obdState.timingText.ifBlank { "--" }, palette.accent, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "NO DATA", obdState.noDataCount.toString(), if (obdState.noDataCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
                TechnicalStatusItem(palette, "STOPPED", obdState.stoppedCount.toString(), if (obdState.stoppedCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Text(
                if (obdState.lastError != null) t("Son hata: ${obdState.lastError}", "Last error: ${obdState.lastError}") else t("Bağlantı yönetimi: Ayarlar > Bağlantı", "Connection management: Settings > Connection"),
                color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                fontSize = 11.sp,
                fontWeight = if (obdState.lastError != null) FontWeight.Bold else FontWeight.Normal
            )
        }
    }
}

@Composable
private fun TechnicalStatusItem(
    palette: LoganPalette,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(palette.surfaceVariant.copy(alpha = .34f))
            .padding(horizontal = 10.dp, vertical = 8.dp)
    ) {
        Text(label.uppercase(), color = color, fontSize = 10.sp, fontWeight = FontWeight.Black, maxLines = 1)
        Text(value, color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black, maxLines = 1)
    }
}

@Composable
fun ObdConnectionPanel(
    palette: LoganPalette,
    obdState: ObdState,
    demoMode: Boolean = false,
    onRefresh: () -> Unit,
    onSelect: (PairedObdDevice) -> Unit,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    language: AppLanguage = AppLanguage.Turkish
) {
    fun l(tr: String, en: String): String = if (language == AppLanguage.English) en else tr

    val context = LocalContext.current
    val selectedDevice = obdState.pairedDevices.firstOrNull { it.address == obdState.selectedAddress }
    var showDeviceList by remember { mutableStateOf(obdState.selectedAddress.isNullOrBlank()) }

    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(l("OBD BAĞLANTISI", "OBD CONNECTION"), color = palette.accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette = palette,
                    label = l("Durum", "Status"),
                    value = when (obdState.connectionHealth) {
                        ObdConnectionHealth.DATA_STALE -> l("Veri bekleniyor", "Waiting for data")
                        ObdConnectionHealth.UNSTABLE -> l("Bağlantı kararsız", "Connection unstable")
                        ObdConnectionHealth.RECONNECTING -> l("Yeniden bağlanıyor", "Reconnecting")
                        ObdConnectionHealth.CONNECTING -> l("Bağlanıyor", "Connecting")
                        ObdConnectionHealth.STABLE -> l("Bağlı", "Connected")
                        ObdConnectionHealth.DISCONNECTED -> if (obdState.connected) l("Bağlı", "Connected") else l("Bekliyor", "Waiting")
                    },
                    color = when {
                        obdState.lastError != null && obdState.connectionHealth == ObdConnectionHealth.DISCONNECTED -> palette.critical
                        obdState.connectionHealth == ObdConnectionHealth.DATA_STALE || obdState.connectionHealth == ObdConnectionHealth.UNSTABLE || obdState.connectionHealth == ObdConnectionHealth.RECONNECTING -> palette.warning
                        obdState.connected -> palette.accent
                        else -> palette.textSecondary
                    },
                    modifier = Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette = palette,
                    label = l("Adaptör", "Adapter"),
                    value = selectedDevice?.name ?: obdState.selectedName ?: l("Seçilmedi", "Not selected"),
                    color = palette.textSecondary,
                    modifier = Modifier.weight(1f)
                )
            }
            Text(
                obdState.status,
                color = if (obdState.lastError != null) palette.critical else palette.textSecondary,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2
            )
            if (demoMode) {
                Text(
                    l("Demo Modu açık: cihaz listesi görülebilir ancak gerçek bağlantı başlatılamaz.", "Demo Mode is active: devices can be listed, but a real connection cannot start."),
                    color = palette.warning,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    lineHeight = 16.sp
                )
            }

            if (obdState.pairedDevices.isEmpty()) {
                Text(
                    l("Eşleşmiş cihaz yok. Önce Android Bluetooth ayarlarından vLinker MC+ ile eşleştir.", "No paired device. Pair with vLinker MC+ from Android Bluetooth settings first."),
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(l("Adaptör seçimi", "Adapter selection"), color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.Black)
                    TextButton(onClick = { showDeviceList = !showDeviceList }) {
                        Text(if (showDeviceList) l("Listeyi Gizle", "Hide List") else l("Cihaz Seç", "Choose Device"), color = palette.accent)
                    }
                }
                if (showDeviceList) {
                    obdState.pairedDevices.forEach { device ->
                        val selected = obdState.selectedAddress == device.address
                        SettingsRow(
                            palette = palette,
                            title = device.name,
                            subtitle = device.address,
                            value = if (selected) l("Seçili", "Selected") else l("Seç", "Select"),
                            onClick = {
                                if (!demoMode) {
                                    onSelect(device)
                                    showDeviceList = false
                                    onConnect()
                                }
                            }
                        )
                    }
                } else if (selectedDevice != null) {
                    Text(
                        l("Seçili cihaz: ${selectedDevice.name}. Yeni seçim için 'Cihaz Seç' butonunu kullan.", "Selected device: ${selectedDevice.name}. Use the 'Choose Device' button for a new selection."),
                        color = palette.textSecondary,
                        fontSize = 12.sp,
                        lineHeight = 16.sp
                    )
                }
            }

            Button(
                onClick = {
                    showDeviceList = true
                    onRefresh()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
            ) { Text(l("Cihazları Tara ve Listeyi Aç", "Refresh and Show Devices")) }
            TextButton(
                onClick = {
                    runCatching {
                        context.startActivity(
                            Intent(Settings.ACTION_BLUETOOTH_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                },
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(l("Android Bluetooth Ayarlarını Aç", "Open Android Bluetooth Settings"), color = palette.accent)
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = onConnect,
                    enabled = !demoMode && !obdState.connecting,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                ) {
                    Text(
                        if (demoMode) l("Demo Modunu Kapat", "Turn Off Demo")
                        else if (obdState.connecting) l("Bağlanıyor...", "Connecting...")
                        else if (obdState.connected) l("Yeniden Bağlan", "Reconnect")
                        else l("OBD’ye Bağlan", "Connect OBD")
                    )
                }
                Button(
                    onClick = onDisconnect,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.surfaceVariant, contentColor = palette.critical)
                ) { Text(l("Bağlantıyı Kes", "Disconnect")) }
            }
        }
    }
}

@Composable
private fun FuelTruthTestPanel(
    palette: LoganPalette,
    snapshot: DashboardSnapshot,
    settings: LoganSettings
) {
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (settings.isExperimentalPetrol) {
                Text("Petrol Injection Discovery", color = palette.warning, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Standart Engine Fuel Rate ve ilgili Mode 01 verileri taranıyor. Enjeksiyon miktarı/pulse width, üreticiye özel ECU profiliyle eklenecek; MAF yalnızca karşılaştırmadır.", color = palette.textSecondary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "Fuel-rate PID", snapshot.engineFuelRateLh?.let { String.format(Locale.US, "%.3f", it) } ?: "--", "L/h", icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(92.dp))
                    DataCard(palette, "MAF", snapshot.mafGramsPerSec?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "g/s", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(92.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "STFT", snapshot.shortFuelTrimPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.FuelCalculation, modifier = Modifier.weight(1f).height(92.dp))
                    DataCard(palette, "Fuel system", snapshot.fuelSystemStatus ?: "--", null, icon = CardIcon.EcuStatus, modifier = Modifier.weight(1f).height(92.dp))
                }
                Text("Salt-okunur Mode 01 taraması + ham cevap kaydı aktif. Tüketim hesabı üretilmez.", color = palette.textSecondary, fontSize = 12.sp)
            } else {
                Text("Fuel Truth Test Panel", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("Hesap: ${fuelSourceLabel(snapshot.fuelSource)} • FuelAlgorithmV3 aktif", color = palette.textSecondary, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "Enjeksiyon", snapshot.injectionMg?.let { String.format(Locale.US, "%.2f", it) } ?: "--", "mg/st", icon = CardIcon.Injection, modifier = Modifier.weight(1f).height(92.dp))
                    DataCard(palette, "Tüketim", fmt(snapshot.instantConsumption), snapshot.instantUnit, accent = LoganFuelInstantRed, icon = CardIcon.FuelInstant, modifier = Modifier.weight(1f).height(92.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    DataCard(palette, "Pedal", snapshot.pedalPercent?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "%", icon = CardIcon.Pedal, modifier = Modifier.weight(1f).height(92.dp))
                    DataCard(palette, "Hava", snapshot.airCharge?.let { String.format(Locale.US, "%.1f", it) } ?: "--", "mg", icon = CardIcon.AirFlow, modifier = Modifier.weight(1f).height(92.dp))
                }
                Text("Fuel Truth + Smart Trip + SQL kayıt aktif.", color = palette.textSecondary, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun TechnicalQualityPanel(palette: LoganPalette, obdState: ObdState, language: AppLanguage) {
    val english = language == AppLanguage.English
    fun t(tr: String, en: String): String = if (english) en else tr
    OemCard(palette, modifier = Modifier.fillMaxWidth()) {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(t("VERİ KALİTESİ", "DATA QUALITY"), color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Black)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "Loop", obdState.loopCount.toString(), palette.accent, Modifier.weight(1f))
                TechnicalStatusItem(palette, ">1 sn", obdState.slowLoopCount.toString(), if (obdState.slowLoopCount == 0) palette.accent else palette.warning, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(palette, "BUS INIT", obdState.busInitCount.toString(), if (obdState.busInitCount == 0) palette.accent else palette.critical, Modifier.weight(1f))
                TechnicalStatusItem(palette, t("Ham Log", "Raw Log"), if (obdState.rawEcuLogEnabled) t("Açık", "On") else t("Kapalı", "Off"), if (obdState.rawEcuLogEnabled) palette.warning else palette.textSecondary, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                TechnicalStatusItem(
                    palette,
                    t("Kararsızlık", "Unstable events"),
                    obdState.connectionUnstableCount.toString(),
                    if (obdState.connectionUnstableCount == 0) palette.accent else palette.warning,
                    Modifier.weight(1f)
                )
                TechnicalStatusItem(
                    palette,
                    t("Veri koruma", "Signal hold"),
                    if (obdState.signalHoldActive) t("Aktif", "Active") else t("Kapalı", "Off"),
                    if (obdState.signalHoldActive) palette.warning else palette.textSecondary,
                    Modifier.weight(1f)
                )
            }
            Text(
                if (obdState.activeProfile == "GENERIC_PETROL_EXPERIMENTAL") {
                    t("Deneysel benzinli profilde salt-okunur Mode 01 cevapları destek ve test exportlarına kaydedilir; bunlardan tüketim hesaplanmaz.", "In the experimental petrol profile, read-only Mode 01 responses are stored in support and test exports; they are not used to calculate consumption.")
                } else {
                    t("Ham ECU paketleri normal ekranda gösterilmez; yalnızca Geliştirici Ham Log açıkken exporta eklenir.", "Raw ECU packets are hidden from the normal screen and included in exports only when Developer Raw Log is enabled.")
                },
                color = palette.textSecondary,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
private fun InfoPage(palette: LoganPalette, title: String, subtitle: String, content: @Composable () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(title, color = palette.textPrimary, fontSize = 29.sp, fontWeight = FontWeight.Black)
        Text(subtitle, color = palette.textSecondary, fontSize = 13.sp)
        Spacer(Modifier.height(14.dp))
        content()
    }
}

private fun fmt(value: Double?, suffix: String? = null): String {
    val base = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"
    return if (suffix == null) base else "$base $suffix"
}

private fun fmtFuelLiters(value: Double?): String = when {
    value == null -> "--"
    value < 1.0 -> String.format(Locale.US, "%.2f", value)
    else -> String.format(Locale.US, "%.1f", value)
}


private fun fuelSourceLabel(source: String): String = when (source.uppercase(Locale.US)) {
    "INJECTION" -> "Enjeksiyon"
    "CUTOFF" -> "Yakıt kesme"
    "COAST_GUARD" -> "Kesme koruması"
    "HOLD" -> "Son enjeksiyon verisi"
    "MAF_FALLBACK" -> "Hava yedek"
    "MAP_FALLBACK" -> "Basınç yedek"
    "NO_FUEL_DATA" -> "Yakıt verisi bekleniyor"
    "SIGNAL_HOLD" -> "Son güvenilir veri"
    "NO_SIGNAL" -> "OBD verisi bekleniyor"
    "CRANK_GUARD" -> "Krank koruma"
    "NONE" -> "Hesap yok"
    "DEMO" -> "Demo"
    else -> if (source.isBlank()) "Bekleniyor" else source
}
