## v1.0.0-beta.3.7.0 - Start Analysis and English

- Added real Marş Analizi / Cranking Analysis module.
- Added automatic passive cranking detection when LoganOS is already connected before engine start.
- Added manual cranking test flow: connect with ignition on, start the test, then crank the engine.
- Cranking analysis now records duration, start voltage, minimum cranking voltage, coolant temperature, RPM finish value, and OBD response gaps.
- Added user-facing comments for normal, slightly long, long crank, very long crank, and low-voltage cases.
- Automatic cranking analyses are temporary: last 5 / 24 hours only, not permanent archive records.
- Manual cranking tests are saved locally until the user deletes them.
- Added “Manuel marş testlerini sil” control.
- Added new bottom navigation page: Testler / Tests.
- Added first-run Dil Seçimi / Language Selection setup screen.
- Added Settings > Dil / Settings > Language.
- Added English UI option with AI-assisted translation notice.
- Turkish remains the primary language; English translation may be improved over time.
- Updated version metadata to 1.0.0-beta.3.7.0.
- FuelAlgorithmV3, TripComputer, CUTOFF, AC_FAST, Delphi parser byte positions, SQL core logging, fuel calibration, and Fan UNKNOWN behavior retained.

## v1.0.0-beta.3.6.6 - Polish UX and Calibration

- Applied the approved LoganOS road / mountain / infinity splash and setup logo.
- Applied the approved LoganOS launcher icon.
- Fixed setup reset flow: setup flag is committed synchronously and the wizard opens directly.
- Added splash fallback behavior to avoid indefinite splash waits.
- Added working Yakıt Kalibrasyonu with pump-fill factor calculation.
- Calibration formula: pump liters / app liters; display fuel values use FuelAlgorithmV3 × factor.
- Added options to disable calibration, return to factory calculation, and reset the calibration factor.
- Cleaned setup vehicle/motor texts and removed “uyarı ile seçilir” / duplicated “kilitli” wording.
- Removed misleading marş analysis wording from setup device mode.
- Added Demo Mode confirmation dialog.
- Improved cockpit/trip card spacing and typography for large values.
- Developer tests and raw log rows stay hidden until Developer Mode is enabled.

## v1.0.0-beta.3.6.5 - Settings UX and Developer Cleanup

- Fuel Truth / FuelAlgorithmV3 kept intact from beta 3.6.x.
- Smart Trip / TripComputer kept intact; total fuel / total distance average remains the source of truth.
- SQL trip logging kept and improved.
- SQL export now uses readable summary sample lines with loop index and real time.
- Normal exports no longer include raw 21A0 / 21A2 / 21CC / 21CD hex packets by default.
- Added Long Trip Log option for lighter 1-second summary logging on 300-400 km drives.
- Added Developer Raw Log option; raw ECU packets are recorded only when this is enabled.
- Technical screen changed from raw ECU/debug blocks to meaningful advanced live values and connection quality counters.
- Added OBD quality counters: loop count, slow loop count, NO DATA, STOPPED, BUS INIT.
- Developer guided tests clarified: Electric Load keeps A/C off; Full Load test added for A/C + electrical loads.
- Setup wizard now requires explicit selections before Continue becomes active.
- Vehicle list simplified: Dacia Logan 2005-2012 Sedan/MCV is the supported profile; Sandero I is experimental; 2013+ Logan/MCV and Duster are unsupported/locked.
