package com.dcui.loganos.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.ExperimentalAnimationApi
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.obd.PairedObdDevice
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.OemCard
import com.dcui.loganos.ui.components.SettingsRow
import com.dcui.loganos.ui.theme.LoganPalette

enum class SettingsCategory(val title: String, val desc: String) {
    Language("Dil", "Türkçe / English"),
    AppearanceCockpit("Görünüm & Kokpit", "Tema, vurgu rengi, gösterge stili"),
    DriveFuel("Sürüş & Yakıt", "Smart Trip, yakıt fiyatı, tüketim"),
    VehicleMaintenance("Araç & Bakım", "Profil, kilometre, bakım aralıkları"),
    ConnectionData("Bağlantı & Veri", "Bluetooth, OBD, log, yedek"),
    Developer("Geliştirici", "Testler, ham log, debug"),
    About("Hakkında", "Sürüm, lisans, proje bilgisi")
}

private fun categoryTitle(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.title
    return when (category) {
        SettingsCategory.Language -> "Language"
        SettingsCategory.AppearanceCockpit -> "Appearance & Cockpit"
        SettingsCategory.DriveFuel -> "Trip & Fuel"
        SettingsCategory.VehicleMaintenance -> "Vehicle & Maintenance"
        SettingsCategory.ConnectionData -> "Connection & Data"
        SettingsCategory.Developer -> "Developer"
        SettingsCategory.About -> "About"
    }
}

private fun categoryDesc(category: SettingsCategory, language: AppLanguage): String {
    if (language != AppLanguage.English) return category.desc
    return when (category) {
        SettingsCategory.Language -> "Turkish / English"
        SettingsCategory.AppearanceCockpit -> "Theme, accent color, gauge style"
        SettingsCategory.DriveFuel -> "Smart Trip, fuel price, consumption"
        SettingsCategory.VehicleMaintenance -> "Profile, odometer, service intervals"
        SettingsCategory.ConnectionData -> "Bluetooth, OBD, logs, backup"
        SettingsCategory.Developer -> "Tests, raw log, debug"
        SettingsCategory.About -> "Version, license, project info"
    }
}

private sealed class SettingsDialog {
    data class Options(val title: String, val options: List<String>, val onSelect: (String) -> Unit) : SettingsDialog()
    data class TextInput(val title: String, val initial: String, val hint: String, val onSave: (String) -> Unit) : SettingsDialog()
    data class Calibration(
        val appLiters: String,
        val pumpLiters: String,
        val currentFactor: Double,
        val enabled: Boolean,
        val onSave: (String, String, Double) -> Unit,
        val onDisable: () -> Unit,
        val onReset: () -> Unit
    ) : SettingsDialog()
    data class Info(val title: String, val message: String) : SettingsDialog()
    data class Confirm(val title: String, val message: String, val confirmLabel: String, val onConfirm: () -> Unit) : SettingsDialog()
}

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun SettingsScreen(
    palette: LoganPalette,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetTrip: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    onStartCrankAnalysis: () -> Unit,
    onClearManualCrankTests: () -> Unit
) {
    var selected by remember { mutableStateOf(SettingsCategory.ConnectionData) }
    var portraitPage by remember { mutableStateOf<SettingsCategory?>(null) }
    var dialog by remember { mutableStateOf<SettingsDialog?>(null) }

    BackHandler(enabled = portraitPage != null) {
        portraitPage = null
    }

    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(palette.background)
            .padding(horizontal = 10.dp, vertical = 9.dp)
    ) {
        if (maxWidth > maxHeight) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                SettingsSideMenu(palette, selected, settings.language, onSelect = { selected = it }, modifier = Modifier.width(220.dp).fillMaxHeight())
                SettingsContent(
                    palette = palette,
                    category = selected,
                    settings = settings,
                    obdState = obdState,
                    onSettingsChange = onSettingsChange,
                    onResetSetup = onResetSetup,
                    onResetTrip = onResetTrip,
                    onRefreshObdDevices = onRefreshObdDevices,
                    onSelectObdDevice = onSelectObdDevice,
                    onConnectObd = onConnectObd,
                    onDisconnectObd = onDisconnectObd,
                    onSaveObdLog = onSaveObdLog,
                    onShareObdLog = onShareObdLog,
                    onClearLastObdLog = onClearLastObdLog,
                    onClearAllObdLogs = onClearAllObdLogs,
                    onDeveloperTestStart = onDeveloperTestStart,
                    onDeveloperTestEnd = onDeveloperTestEnd,
                    openDialog = { dialog = it },
                    modifier = Modifier.weight(1f).fillMaxHeight()
                )
            }
        } else {
            AnimatedContent(
                targetState = portraitPage,
                transitionSpec = {
                    if (targetState != null) {
                        (slideInHorizontally(animationSpec = tween(250)) { it } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeOut(animationSpec = tween(180)))
                    } else {
                        (slideInHorizontally(animationSpec = tween(250)) { -it / 4 } + fadeIn(animationSpec = tween(220))) togetherWith
                            (slideOutHorizontally(animationSpec = tween(250)) { it } + fadeOut(animationSpec = tween(180)))
                    }
                },
                label = "settingsPortraitNav"
            ) { page ->
                if (page == null) {
                    SettingsCategoryList(palette = palette, language = settings.language, onOpen = {
                        selected = it
                        portraitPage = it
                    })
                } else {
                    SettingsDetailPage(
                        palette = palette,
                        category = page,
                        settings = settings,
                        obdState = obdState,
                        onSettingsChange = onSettingsChange,
                        onResetSetup = onResetSetup,
                        onResetTrip = onResetTrip,
                        onRefreshObdDevices = onRefreshObdDevices,
                        onSelectObdDevice = onSelectObdDevice,
                        onConnectObd = onConnectObd,
                        onDisconnectObd = onDisconnectObd,
                        onSaveObdLog = onSaveObdLog,
                        onShareObdLog = onShareObdLog,
                        onClearLastObdLog = onClearLastObdLog,
                        onClearAllObdLogs = onClearAllObdLogs,
                        onDeveloperTestStart = onDeveloperTestStart,
                        onDeveloperTestEnd = onDeveloperTestEnd,
                        openDialog = { dialog = it },
                        onBack = { portraitPage = null }
                    )
                }
            }
        }
    }

    dialog?.let { current ->
        when (current) {
            is SettingsDialog.Options -> OptionDialog(palette, current) { dialog = null }
            is SettingsDialog.TextInput -> TextInputDialog(palette, current) { dialog = null }
            is SettingsDialog.Calibration -> FuelCalibrationDialog(palette, current) { dialog = null }
            is SettingsDialog.Info -> InfoDialog(palette, current) { dialog = null }
            is SettingsDialog.Confirm -> ConfirmDialog(palette, current) { dialog = null }
        }
    }
}

@Composable
private fun SettingsCategoryList(palette: LoganPalette, language: AppLanguage, onOpen: (SettingsCategory) -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 30.sp, fontWeight = FontWeight.Black)
            Text("LoganOS v1.0.0-beta.3.7.0", color = palette.textSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
        }
        SettingsCategory.entries.forEach { cat ->
            item {
                OemCard(palette, modifier = Modifier.fillMaxWidth(), onClick = { onOpen(cat) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(categoryTitle(cat, language), color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
                            Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 12.sp)
                        }
                        Text("›", color = palette.textSecondary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsSideMenu(palette: LoganPalette, selected: SettingsCategory, language: AppLanguage, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(modifier = modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(if (language == AppLanguage.English) "Settings" else "Ayarlar", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
        Text("v1.0.0-beta.3.7.0", color = palette.textSecondary, fontSize = 12.sp)
        Spacer(Modifier.height(6.dp))
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(if (active) palette.accent.copy(alpha = .12f) else palette.surface)
                    .clickable { onSelect(cat) }
                    .padding(12.dp)
            ) {
                Text(categoryTitle(cat, language), color = if (active) palette.accent else palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                Text(categoryDesc(cat, language), color = palette.textSecondary, fontSize = 11.sp)
            }
        }
    }
}

@Composable
private fun SettingsCompactSideMenu(palette: LoganPalette, selected: SettingsCategory, onSelect: (SettingsCategory) -> Unit, modifier: Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .background(palette.surface)
            .padding(vertical = 10.dp, horizontal = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("☰", color = palette.textSecondary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        SettingsCategory.entries.forEach { cat ->
            val active = selected == cat
            val icon = when (cat) {
                SettingsCategory.Language -> CardIcon.Time
                SettingsCategory.AppearanceCockpit -> CardIcon.Speed
                SettingsCategory.DriveFuel -> CardIcon.Cost
                SettingsCategory.VehicleMaintenance -> CardIcon.Temperature
                SettingsCategory.ConnectionData -> CardIcon.Injection
                SettingsCategory.Developer -> CardIcon.Injection
                SettingsCategory.About -> CardIcon.Time
            }
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (active) palette.accent else palette.surfaceVariant)
                    .clickable { onSelect(cat) },
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(
                    palette = palette,
                    icon = icon,
                    tint = if (active) palette.background else palette.textSecondary,
                    modifier = Modifier.size(27.dp)
                )
            }
        }
    }
}

@Composable
private fun SettingsDetailPage(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetTrip: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    onBack: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "‹ Ayarlar",
            color = palette.textPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onBack() }
                .padding(horizontal = 6.dp, vertical = 4.dp)
        )
        SettingsContent(
            palette = palette,
            category = category,
            settings = settings,
            obdState = obdState,
            onSettingsChange = onSettingsChange,
            onResetSetup = onResetSetup,
            onResetTrip = onResetTrip,
            onRefreshObdDevices = onRefreshObdDevices,
            onSelectObdDevice = onSelectObdDevice,
            onConnectObd = onConnectObd,
            onDisconnectObd = onDisconnectObd,
            onSaveObdLog = onSaveObdLog,
            onShareObdLog = onShareObdLog,
            onClearLastObdLog = onClearLastObdLog,
            onClearAllObdLogs = onClearAllObdLogs,
            onDeveloperTestStart = onDeveloperTestStart,
            onDeveloperTestEnd = onDeveloperTestEnd,
            openDialog = openDialog,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun SettingsContent(
    palette: LoganPalette,
    category: SettingsCategory,
    settings: LoganSettings,
    obdState: ObdState,
    onSettingsChange: (LoganSettings) -> Unit,
    onResetSetup: () -> Unit,
    onResetTrip: () -> Unit,
    onRefreshObdDevices: () -> Unit,
    onSelectObdDevice: (PairedObdDevice) -> Unit,
    onConnectObd: () -> Unit,
    onDisconnectObd: () -> Unit,
    onSaveObdLog: () -> Unit,
    onShareObdLog: () -> Unit,
    onClearLastObdLog: () -> Unit,
    onClearAllObdLogs: () -> Unit,
    onDeveloperTestStart: (String) -> Unit,
    onDeveloperTestEnd: () -> Unit,
    openDialog: (SettingsDialog) -> Unit,
    modifier: Modifier
) {
    fun openFuelCalibrationDialog() {
        openDialog(
            SettingsDialog.Calibration(
                appLiters = settings.fuelCalibrationAppLitersText,
                pumpLiters = settings.fuelCalibrationPumpLitersText,
                currentFactor = settings.fuelCalibrationFactor,
                enabled = settings.fuelCalibrationEnabled,
                onSave = { appLiters, pumpLiters, factor ->
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = true,
                            fuelCalibrationFactor = factor,
                            fuelCalibrationAppLitersText = appLiters,
                            fuelCalibrationPumpLitersText = pumpLiters,
                            fuelCalibrationWarningAccepted = true
                        )
                    )
                },
                onDisable = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) },
                onReset = {
                    onSettingsChange(
                        settings.copy(
                            fuelCalibrationEnabled = false,
                            fuelCalibrationFactor = 1.0,
                            fuelCalibrationAppLitersText = "",
                            fuelCalibrationPumpLitersText = ""
                        )
                    )
                }
            )
        )
    }

    fun openFuelCalibrationFlow() {
        if (settings.fuelCalibrationWarningAccepted) {
            openFuelCalibrationDialog()
        } else {
            openDialog(
                SettingsDialog.Confirm(
                    title = "Yakıt Kalibrasyonu",
                    message = "Bu özellik, pompa dolumuna göre yakıt hesabını ince ayarlar.\n\nGirilen litre bilgisi hatalı olursa tüketim ve maliyet hesabı sapabilir. İstediğiniz zaman fabrika hesabına dönebilirsiniz.",
                    confirmLabel = "Anladım, devam et",
                    onConfirm = {
                        onSettingsChange(settings.copy(fuelCalibrationWarningAccepted = true))
                        openFuelCalibrationDialog()
                    }
                )
            )
        }
    }

    OemCard(palette, modifier = modifier.fillMaxWidth()) {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(5.dp)) {
            item {
                Text(categoryTitle(category, settings.language), color = palette.accent, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(categoryDesc(category, settings.language), color = palette.textSecondary, fontSize = 11.sp, lineHeight = 14.sp)
            }
            item { Spacer(Modifier.height(4.dp)) }
            when (category) {
                SettingsCategory.Language -> {
                    item {
                        SettingsRow(
                            palette,
                            if (settings.language == AppLanguage.English) "App Language" else "Uygulama Dili",
                            if (settings.language == AppLanguage.English) "Choose the display language" else "Uygulama dilini seçin",
                            settings.language.label,
                            onClick = {
                                openDialog(SettingsDialog.Options(if (settings.language == AppLanguage.English) "Language" else "Dil", listOf("Türkçe", "English")) { label ->
                                    val lang = if (label == "English") AppLanguage.English else AppLanguage.Turkish
                                    onSettingsChange(settings.copy(language = lang))
                                })
                            }
                        )
                    }
                    item { SettingsRow(palette, "Türkçe", "Ana dil / Primary language", if (settings.language == AppLanguage.Turkish) "Seçili" else "", onClick = { onSettingsChange(settings.copy(language = AppLanguage.Turkish)) }) }
                    item { SettingsRow(palette, "English", "AI-assisted translation", if (settings.language == AppLanguage.English) "Selected" else "", onClick = { onSettingsChange(settings.copy(language = AppLanguage.English)) }) }
                    item {
                        Text(
                            if (settings.language == AppLanguage.English) "Turkish is the primary language. English translation is AI-assisted and may be improved over time." else "Türkçe ana dildir. İngilizce çeviri AI desteklidir ve bazı ifadeler zamanla iyileştirilebilir.",
                            color = palette.textSecondary,
                            fontSize = 12.sp,
                            lineHeight = 17.sp,
                            modifier = Modifier.padding(4.dp)
                        )
                    }
                }
                SettingsCategory.AppearanceCockpit -> {
                    item { SettingsRow(palette, "Koyu Tema", "OEM Dark görünümü", trailingSwitch = settings.darkMode, onSwitch = { onSettingsChange(settings.copy(darkMode = it)) }) }
                    item { SettingsRow(palette, "Vurgu Rengi", "Tüm LOGANOS vurgu rengi", settings.accentColor.label, onClick = { openDialog(SettingsDialog.Options("Vurgu Rengi", AccentColor.entries.map { it.label }) { label -> AccentColor.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(accentColor = it)) } }) }) }
                    item { SettingsRow(palette, "Gösterge Stili", "Digital, Sport, Classic OEM, Minimal, RS", settings.gaugeStyle.label, onClick = { openDialog(SettingsDialog.Options("Gösterge Stili", GaugeStyle.entries.map { it.label }) { label -> GaugeStyle.entries.firstOrNull { it.label == label }?.let { onSettingsChange(settings.copy(gaugeStyle = it)) } }) }) }
                    item { SettingsRow(palette, "Yazı Boyutu", "Normal / büyük seçenekleri hazırlanıyor", "Yakında", onClick = { openDialog(SettingsDialog.Info("Yazı Boyutu", "Kalıcı yazı ölçeklendirme sonraki tasarım paketinde açılacak.")) }) }
                    item { SettingsRow(palette, "Kokpit Düzenleri", "Hazır şablonlar ve gösterilecek veriler", "Yakında", onClick = { openDialog(SettingsDialog.Info("Kokpit Düzenleri", "Hazır kokpit şablonları ve kart seçimi sonraki tasarım paketinde genişletilecek.")) }) }
                }
                SettingsCategory.DriveFuel -> {
                    item { SettingsRow(palette, "Akıllı Yolculuk", "Kısa molalarda aynı sürüşü kaldığı yerden sürdürür", "${settings.smartTripMinutes} dk", onClick = { openDialog(SettingsDialog.Options("Akıllı Yolculuk Süresi", listOf("15", "30", "60", "120", "240")) { v -> onSettingsChange(settings.copy(smartTripMinutes = v.toIntOrNull() ?: 60)) }) }) }
                    item { SettingsRow(palette, "Yakıt Fiyatı", "Masraf hesabı için litre fiyatını kullanır", fuelPriceDisplay(settings.fuelPriceText), onClick = { openDialog(SettingsDialog.TextInput("Yakıt Fiyatı", settings.fuelPriceText, "Örn. 45,50") { v -> onSettingsChange(settings.copy(fuelPriceText = v)) }) }) }
                    item { SettingsRow(palette, "Ortalama tüketimi sıfırla", "Bu sürüşün mesafe, süre, yakıt ve ortalamasını sıfırlar", onClick = { openDialog(SettingsDialog.Confirm("Ortalama tüketimi sıfırlansın mı?", "Güncel sürüşün mesafe, süre, yakıt ve ortalama tüketim bilgileri sıfırlanacak. Log dosyaları silinmez.", "Sıfırla") { onResetTrip() }) }) }
                    item { SettingsRow(palette, "Sürüş sırasında ekranı açık tut", "Sürüşte telefon ekranının kapanmasını engeller", trailingSwitch = settings.keepScreenOn, onSwitch = { onSettingsChange(settings.copy(keepScreenOn = it)) }) }
                    item { SettingsRow(palette, "Arka planda kaydı sürdür", "Uygulama arkadayken OBD kaydı devam eder", trailingSwitch = settings.backgroundTripEnabled, onSwitch = { onSettingsChange(settings.copy(backgroundTripEnabled = it)) }) }
                    item {
                        SettingsRow(
                            palette,
                            "Yakıt Kalibrasyonu",
                            "Depo dolumu ile ince ayar",
                            if (settings.fuelCalibrationEnabled) "x${String.format(java.util.Locale.US, "%.3f", settings.fuelCalibrationFactor)}" else "Kapalı",
                            onClick = { openFuelCalibrationFlow() }
                        )
                    }
                    if (settings.fuelCalibrationEnabled) {
                        item { SettingsRow(palette, "Kalibrasyonu kapat", "Katsayı saklanır; gösterim fabrika hesabına döner", "Kapat", onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false)) }) }
                        item { SettingsRow(palette, "Fabrika hesabına dön", "FuelAlgorithmV3 ana hesabını katsayısız göster", "Dön", onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false, fuelCalibrationFactor = 1.0)) }) }
                        item { SettingsRow(palette, "Kalibrasyon katsayısını sıfırla", "Pompa ve uygulama litre girişlerini temizler", "Sıfırla", onClick = { onSettingsChange(settings.copy(fuelCalibrationEnabled = false, fuelCalibrationFactor = 1.0, fuelCalibrationAppLitersText = "", fuelCalibrationPumpLitersText = "")) }) }
                    }
                }
                SettingsCategory.VehicleMaintenance -> {
                    item { SettingsRow(palette, "Araç", "2005-2012 Sedan/MCV • ${settings.engine}", settings.vehicleModel, onClick = { openDialog(SettingsDialog.Info("Araç Profili", "Tam destek 2005-2012 Dacia Logan Sedan/MCV 1.5 dCi 68 bg içindir. Sandero I deneysel, 2013+ Logan/MCV ve benzinli motorlar desteklenmez.")) }) }
                    item { SettingsRow(palette, "Kurulum Sihirbazını Yeniden Başlat", "Araç, tema ve gösterge tercihlerini yeniden seç", "Onay", onClick = { openDialog(SettingsDialog.Confirm("Kurulum yeniden başlatılsın mı?", "İlk kurulum ekranı yeniden açılacak. Log dosyaları ve test kayıtları silinmez.", "Yeniden Başlat") { onResetSetup() }) }) }
                    item { SettingsRow(palette, "Kilometre Eşitleme", "Gösterge kilometresini kalibre et", settings.odometerText, onClick = { openDialog(SettingsDialog.TextInput("Kilometre Eşitleme", settings.odometerText, "Örn. 335420") { v -> onSettingsChange(settings.copy(odometerText = v)) }) }) }
                    item { SettingsRow(palette, "Motor Yağı", "Bakım aralığı", "${settings.oilServiceKm} km", onClick = { openDialog(SettingsDialog.TextInput("Motor Yağı Aralığı", settings.oilServiceKm, "Örn. 10000") { v -> onSettingsChange(settings.copy(oilServiceKm = v)) }) }) }
                    item { SettingsRow(palette, "Mazot Filtresi", "Bakım aralığı", "${settings.fuelFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput("Mazot Filtresi Aralığı", settings.fuelFilterKm, "Örn. 20000") { v -> onSettingsChange(settings.copy(fuelFilterKm = v)) }) }) }
                    item { SettingsRow(palette, "Hava Filtresi", "Bakım aralığı", "${settings.airFilterKm} km", onClick = { openDialog(SettingsDialog.TextInput("Hava Filtresi Aralığı", settings.airFilterKm, "Örn. 10000") { v -> onSettingsChange(settings.copy(airFilterKm = v)) }) }) }
                    item { SettingsRow(palette, "Triger Seti", "Bakım aralığı", "${settings.timingBeltKm} km", onClick = { openDialog(SettingsDialog.TextInput("Triger Seti Aralığı", settings.timingBeltKm, "Örn. 60000") { v -> onSettingsChange(settings.copy(timingBeltKm = v)) }) }) }
                }
                SettingsCategory.ConnectionData -> {
                    item { ObdConnectionPanel(palette, obdState, onRefreshObdDevices, onSelectObdDevice, onConnectObd, onDisconnectObd, onSaveObdLog, onShareObdLog, onClearLastObdLog, onClearAllObdLogs) }
                }
                SettingsCategory.Developer -> {
                    item { SettingsRow(palette, "Geliştirici Modu", "Testler ve debug seçeneklerini açar", trailingSwitch = settings.developerModeEnabled, onSwitch = { enabled -> onSettingsChange(settings.copy(developerModeEnabled = enabled, rawEcuLogEnabled = if (enabled) settings.rawEcuLogEnabled else false)) }) }
                    item {
                        SettingsRow(
                            palette,
                            "Demo Modu",
                            "Ekranları simülasyon verisiyle dene",
                            trailingSwitch = settings.demoMode,
                            onSwitch = { enabled ->
                                if (enabled) {
                                    openDialog(
                                        SettingsDialog.Confirm(
                                            "Demo Modu",
                                            "Bu mod gerçek araç verisi göstermez.\n\nEkranları ve göstergeleri denemek için simülasyon verisi üretir.",
                                            "Demo Modunu Aç"
                                        ) { onSettingsChange(settings.copy(demoMode = true)) }
                                    )
                                } else {
                                    onSettingsChange(settings.copy(demoMode = false))
                                }
                            }
                        )
                    }
                    if (settings.developerModeEnabled) {
                        item { SettingsRow(palette, "Geliştirici Ham Log", "Ham ECU paketlerini ayrıca kaydeder; normalde kapalı kalmalı", trailingSwitch = settings.rawEcuLogEnabled, onSwitch = { onSettingsChange(settings.copy(rawEcuLogEnabled = it)) }) }
                        item { DeveloperTestRows(palette, obdState.activeDeveloperTest, onDeveloperTestStart, onDeveloperTestEnd) }
                    }
                }
                SettingsCategory.About -> {
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                            Text("LOGANOS", color = palette.textPrimary, fontSize = 28.sp, fontWeight = FontWeight.Black)
                            Text("Version 1.0.0-beta.3.7.0", color = palette.accent, fontWeight = FontWeight.Bold)
                            Text("OEM Digital Cockpit • Powered by DC UI", color = palette.textSecondary)
                            Text("Fuel Truth + Smart Trip • Delphi DCM1.2 • KWP2000 Fast Init", color = palette.textSecondary)
                            Text("Ücretsiz, reklamsız ve açık kaynaklı proje.", color = palette.textSecondary)
                            Text("Gizlilik: veriler cihazda tutulur; paylaşım kullanıcı isteğiyle yapılır.", color = palette.textSecondary)
                            Text("Dil ve Çeviri: Türkçe ana dildir. İngilizce çeviri AI desteklidir.", color = palette.textSecondary)
                        }
                    }
                }
            }
        }
    }
}


@Composable
private fun DeveloperTestRows(
    palette: LoganPalette,
    activeTest: String?,
    onStart: (String) -> Unit,
    onEnd: () -> Unit
) {
    val tests = listOf(
        "Sıcak rölanti testi" to "Klima kapalı 60 sn → açık 60 sn → kapalı 30 sn",
        "Klima testi" to "Klima kapalı 30 sn → açık 30 sn → kapalı 30 sn",
        "Elektrik/yük testi" to "Klima kapalı; far, rezistans ve kalorifer fanını sırayla aç",
        "Tam yük testi" to "Far, sis, rezistans, kalorifer fanı ve klimayı birlikte aç",
        "Yakıt kesme (CUTOFF) testi" to "20-30 km/h üstünde gazı bırak; yakıt kesme beklenir",
        "Serbest sürüş testi" to "5 dk yönlendirmeli şehir içi kayıt"
    )
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Geliştirici Testleri", color = palette.textPrimary, fontSize = 18.sp, fontWeight = FontWeight.Black)
        if (activeTest != null) {
            SettingsRow(
                palette = palette,
                title = "Aktif test: $activeTest",
                subtitle = "Bitirince test kaydı kapatılır",
                value = "Bitir",
                onClick = onEnd
            )
        }
        tests.forEach { (name, desc) ->
            val running = activeTest == name
            SettingsRow(
                palette = palette,
                title = name,
                subtitle = desc,
                value = if (running) "Bitir" else "Başlat",
                onClick = { if (running) onEnd() else onStart(name) }
            )
        }
    }
}

private fun fuelPriceDisplay(raw: String): String {
    val value = raw.replace(',', '.').toDoubleOrNull() ?: return "Girilmedi"
    return String.format(java.util.Locale("tr", "TR"), "%.2f TL/L", value)
}

private fun parseCalibrationNumber(raw: String): Double? {
    return raw.trim().replace(',', '.').toDoubleOrNull()
}

@Composable
private fun OptionDialog(palette: LoganPalette, dialog: SettingsDialog.Options, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                dialog.options.forEach { option ->
                    Text(
                        option,
                        color = palette.textPrimary,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { dialog.onSelect(option); onDismiss() }
                            .background(palette.surfaceVariant)
                            .padding(12.dp)
                    )
                }
            }
        }
    )
}

@Composable
private fun TextInputDialog(palette: LoganPalette, dialog: SettingsDialog.TextInput, onDismiss: () -> Unit) {
    var value by remember(dialog.title) { mutableStateOf(dialog.initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { OutlinedTextField(value = value, onValueChange = { value = it }, label = { Text(dialog.hint) }, singleLine = true) },
        confirmButton = { TextButton(onClick = { dialog.onSave(value); onDismiss() }) { Text("Kaydet") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@Composable
private fun FuelCalibrationDialog(palette: LoganPalette, dialog: SettingsDialog.Calibration, onDismiss: () -> Unit) {
    var appLiters by remember { mutableStateOf(dialog.appLiters) }
    var pumpLiters by remember { mutableStateOf(dialog.pumpLiters) }
    val appValue = parseCalibrationNumber(appLiters)
    val pumpValue = parseCalibrationNumber(pumpLiters)
    val factor = if (appValue != null && pumpValue != null && appValue > 0.0 && pumpValue > 0.0) {
        (pumpValue / appValue)
    } else null
    val factorValid = factor != null && factor in 0.50..1.50

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yakıt Kalibrasyonu", color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Depo dolumu ile ince ayar", color = palette.textPrimary, fontWeight = FontWeight.Bold)
                Text(
                    "Kalibrasyon katsayısı = Pompadan alınan litre / Uygulamanın hesapladığı litre",
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
                OutlinedTextField(
                    value = appLiters,
                    onValueChange = { appLiters = it },
                    label = { Text("Uygulamanın hesapladığı litre") },
                    singleLine = true
                )
                OutlinedTextField(
                    value = pumpLiters,
                    onValueChange = { pumpLiters = it },
                    label = { Text("Pompadan alınan litre") },
                    singleLine = true
                )
                Text(
                    text = if (factor != null) {
                        "Yeni katsayı: x${String.format(java.util.Locale.US, "%.3f", factor)}"
                    } else {
                        "Örnek: uygulama 42,3 L / pompa 43,8 L = x1,035"
                    },
                    color = if (factorValid) palette.accent else palette.textSecondary,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Mevcut durum: ${if (dialog.enabled) "Açık" else "Kapalı"} • mevcut katsayı x${String.format(java.util.Locale.US, "%.3f", dialog.currentFactor)}",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
                if (factor != null && !factorValid) {
                    Text("Katsayı 0,50 ile 1,50 arasında olmalı. Litre girişlerini kontrol edin.", color = palette.critical, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = factorValid,
                onClick = {
                    dialog.onSave(appLiters, pumpLiters, factor ?: 1.0)
                    onDismiss()
                }
            ) { Text("Kaydet ve Aç") }
        },
        dismissButton = {
            Row {
                TextButton(onClick = { dialog.onDisable(); onDismiss() }) { Text("Kalibrasyonu Kapat") }
                TextButton(onClick = { dialog.onReset(); onDismiss() }) { Text("Sıfırla") }
                TextButton(onClick = onDismiss) { Text("İptal") }
            }
        }
    )
}


@Composable
private fun InfoDialog(palette: LoganPalette, dialog: SettingsDialog.Info, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Tamam") } }
    )
}

@Composable
private fun ConfirmDialog(palette: LoganPalette, dialog: SettingsDialog.Confirm, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(dialog.title, color = palette.textPrimary, fontWeight = FontWeight.Black) },
        text = { Text(dialog.message, color = palette.textSecondary) },
        confirmButton = { TextButton(onClick = { onDismiss(); dialog.onConfirm() }) { Text(dialog.confirmLabel) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}
