# LoganOS

Version: **1.0.0-beta.3.7.0**

## Beta 3.7.0 Start Analysis and English

This build adds the first real LoganOS cranking/start analysis module and the first language-selection layer.

Highlights:

- Marş Analizi / Cranking Analysis screen added.
- Passive automatic cranking detection added for normal use: if the app is connected before starting the engine, LoganOS can analyze the start even if the user did not manually open the test.
- Manual cranking test flow added for deliberate testing.
- Cranking result includes duration, voltage, minimum voltage during crank, RPM response, coolant temperature and OBD response-gap note.
- Automatic cranking analyses are temporary to avoid storage bloat: last 5 / 24 hours.
- Manual cranking tests are saved locally until the user deletes them.
- First setup step is now Dil Seçimi / Language Selection.
- Settings > Dil / Settings > Language added.
- English option added with AI-assisted translation note.
- Turkish remains the primary language.

Protected core systems:

- FuelAlgorithmV3 retained.
- TripComputer retained.
- CUTOFF logic retained.
- AC_FAST bit retained.
- Delphi parser byte positions retained.
- SQL core logging retained.
- Fuel calibration layer retained.
- Fan UNKNOWN behavior retained.

## Previous 3.6.6 notes

The previous build applied the selected LoganOS identity assets, fixed setup-reset navigation, and turned Yakıt Kalibrasyonu into a working optional correction layer while keeping the validated FuelAlgorithmV3 / TripComputer foundation intact.
