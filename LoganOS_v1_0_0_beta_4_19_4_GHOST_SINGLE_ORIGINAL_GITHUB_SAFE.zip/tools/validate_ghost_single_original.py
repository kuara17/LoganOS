#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
res = root / "app/src/main/res/drawable-nodpi"
source = (root / "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt").read_text(encoding="utf-8")
models = (root / "app/src/main/java/com/dcui/loganos/model/Models.kt").read_text(encoding="utf-8")
dashboard = (root / "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/java/com/dcui/loganos/MainActivity.kt").read_text(encoding="utf-8")
settings = (root / "app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt").read_text(encoding="utf-8")

def require(cond, msg):
    if not cond:
        raise SystemExit(f"[FAIL] {msg}")
    print(f"[PASS] {msg}")

full = [
    "ghost_single_original_background.webp",
    "ghost_single_original_gauge_shell.webp",
    "ghost_single_original_preview.webp",
    "ghost_single_original_road_base.webp",
    "ghost_single_original_road_edges.webp",
    "ghost_single_original_road_sheen.webp",
    "ghost_single_original_shadow_contact.webp",
    "ghost_single_original_shadow_soft.webp",
    "ghost_single_original_vignette.webp",
]
horizons = [f"ghost_single_original_horizon_{c}.webp" for c in ["purple", "red", "green", "white", "blue", "yellow"]]
for name in full:
    p = res / name
    require(p.exists(), f"asset exists: {name}")
    require(Image.open(p).size == (1846, 852), f"asset uses 1846x852 stage: {name}")
for name in horizons:
    p = res / name
    require(p.exists(), f"horizon asset exists: {name}")
    require(Image.open(p).size == (1846, 300), f"horizon asset uses 1846x300 strip: {name}")

require("GhostSingleOriginal(\"Ghost Single Original\")" in models, "separate GaugeStyle identity exists")
require("GhostOriginalAccent" in models, "separate accent enum exists")
require("fun GhostSingleOriginalCockpit" in source, "isolated cockpit composable exists")
require("GhostSingleV2" not in source, "retired V2 identity is not reused")
require("GhostSingleOriginalCockpit(" in dashboard, "dashboard routes to the isolated cockpit")
require("settings.gaugeStyle == GaugeStyle.GhostSingleOriginal" in dashboard, "dashboard branch is separately keyed")
require("GaugeStyle.GhostSingleOriginal" in main and "SCREEN_ORIENTATION_LANDSCAPE" in main, "phone orientation remains landscape-only")
require("Ghost Single Original ışık rengi" in settings, "dedicated glow-color setting is exposed")
require("road_sheen" in source and "RoadMotionLayer" in source, "continuous edges and moving sheen are both wired")
require("vehicleVisualDrawableRes" in source, "existing Logan I/III asset selector is reused")
print("\nGhost Single Original validation passed.")
