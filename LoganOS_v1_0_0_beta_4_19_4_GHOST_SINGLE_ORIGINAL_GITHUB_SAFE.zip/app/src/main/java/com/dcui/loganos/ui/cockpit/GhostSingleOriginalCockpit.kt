package com.dcui.loganos.ui.cockpit

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.GhostOriginalAccent
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.coolantAccentColor
import com.dcui.loganos.ui.components.isTrustedFuelSourceForDisplay
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.max

private val OriginalWhite = Color(0xFFF7F9FF)
private val OriginalMuted = Color(0xFFB7C1D0)

@Composable
fun GhostSingleOriginalCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    onOpenReset: () -> Unit,
    modifier: Modifier = Modifier
) {
    val speed = (snapshot.speedKmh ?: 0).coerceIn(0, 200)
    val rpm = (snapshot.rpm ?: 0).coerceIn(0, settings.tachometerMaxRpm)
    val accent = ghostOriginalAccentColor(settings.ghostOriginalAccent)
    val motion = remember { Animatable(0f) }

    LaunchedEffect(speed, settings.demoMode) {
        if (speed < 3) {
            motion.snapTo(0f)
        } else {
            while (true) {
                motion.snapTo(0f)
                val duration = (2700 - speed * 18).coerceIn(650, 2500)
                motion.animateTo(1f, animationSpec = tween(duration, easing = LinearEasing))
            }
        }
    }

    val fuelTrusted = snapshot.demo || (
        settings.fuelCalculationSupported && isTrustedFuelSourceForDisplay(snapshot.fuelSource)
    )
    val instant = if (fuelTrusted) formatOne(snapshot.instantConsumption) else "--"
    val average = if (fuelTrusted) formatOne(snapshot.averageConsumption) else "--"
    val instantUnit = if (fuelTrusted) snapshot.instantUnit else "VERİ BEKLENİYOR"
    val averageUnit = if (fuelTrusted) "L/100 km" else "VERİ BEKLENİYOR"
    val temp = snapshot.engineTempC?.toString() ?: "--"
    val tempColor = coolantAccentColor(palette, snapshot.engineTempC)
    val vehicleRes = vehicleVisualDrawableRes(
        model = settings.vehicleVisualModel,
        color = settings.vehicleColor,
        style = VehicleAssetStyle.Detailed
    )

    BoxWithConstraints(modifier = modifier.fillMaxSize()) {
        Image(
            painter = painterResource(R.drawable.ghost_single_original_background),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(ghostOriginalHorizonRes(settings.ghostOriginalAccent)),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier
                .width(maxWidth)
                .height(maxHeight * 0.352f)
                .align(Alignment.Center)
                .offset(y = maxHeight * 0.011f)
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_base),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_edges),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.82f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_road_sheen),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            colorFilter = ColorFilter.tint(accent.copy(alpha = 0.20f), BlendMode.SrcIn),
            modifier = Modifier.fillMaxSize()
        )
        RoadMotionLayer(
            phase = motion.value,
            accent = accent,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_soft),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_shadow_contact),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(vehicleRes),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .width(maxWidth * 0.128f)
                .height(maxHeight * 0.255f)
                .offset(y = maxHeight * -0.126f)
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_gauge_shell),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )
        Image(
            painter = painterResource(R.drawable.ghost_single_original_vignette),
            contentDescription = null,
            contentScale = ContentScale.FillBounds,
            modifier = Modifier.fillMaxSize()
        )

        GhostOriginalText(
            cx = 0.50f,
            cy = 0.205f,
            widthFraction = 0.24f,
            heightFraction = 0.13f,
            text = speed.toString(),
            size = scaledSp(maxHeight.value * 0.091f),
            color = OriginalWhite,
            weight = FontWeight.Light
        )
        GhostOriginalText(0.50f, 0.287f, 0.14f, 0.05f, "km/h", scaledSp(maxHeight.value * 0.025f), OriginalMuted, FontWeight.Medium)
        GhostOriginalText(0.50f, 0.345f, 0.26f, 0.06f, "$rpm rpm", scaledSp(maxHeight.value * 0.032f), OriginalWhite.copy(alpha = 0.88f), FontWeight.Medium)

        MetricBlock(
            cx = 0.16f,
            cy = 0.735f,
            label = "ANLIK",
            value = instant,
            unit = instantUnit,
            onClick = onOpenReset,
            maxHeightValue = maxHeight.value
        )
        MetricBlock(
            cx = 0.84f,
            cy = 0.735f,
            label = "ORTALAMA",
            value = average,
            unit = averageUnit,
            onClick = onOpenReset,
            maxHeightValue = maxHeight.value
        )
        GhostOriginalText(
            cx = 0.50f,
            cy = 0.895f,
            widthFraction = 0.28f,
            heightFraction = 0.06f,
            text = "HARARET  $temp °C",
            size = scaledSp(maxHeight.value * 0.025f),
            color = tempColor,
            weight = FontWeight.SemiBold
        )
        GhostOriginalText(
            cx = 0.91f,
            cy = 0.065f,
            widthFraction = 0.16f,
            heightFraction = 0.06f,
            text = when {
                snapshot.demo -> "DEMO"
                snapshot.connected -> "OBD BAĞLI"
                else -> "OBD BEKLENİYOR"
            },
            size = scaledSp(maxHeight.value * 0.021f),
            color = if (snapshot.demo || snapshot.connected) accent else OriginalMuted,
            weight = FontWeight.Bold
        )
    }
}

@Composable
private fun RoadMotionLayer(phase: Float, accent: Color, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val vanishing = Offset(size.width * 0.5f, size.height * 0.434f)
        val leftBottom = Offset(size.width * 0.092f, size.height)
        val rightBottom = Offset(size.width * 0.908f, size.height)
        val length = 0.18f
        fun point(a: Offset, b: Offset, t: Float) = Offset(
            x = a.x + (b.x - a.x) * t,
            y = a.y + (b.y - a.y) * t
        )
        fun drawMovingSegment(bottom: Offset) {
            val startT = phase.coerceIn(0f, 1f)
            val endT = (startT + length).coerceAtMost(1f)
            if (endT <= startT) return
            val start = point(vanishing, bottom, startT)
            val end = point(vanishing, bottom, endT)
            drawLine(accent.copy(alpha = 0.23f), start, end, strokeWidth = 12f, cap = StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.82f), start, end, strokeWidth = 2.4f, cap = StrokeCap.Round)
        }
        if (phase > 0f) {
            drawMovingSegment(leftBottom)
            drawMovingSegment(rightBottom)
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.MetricBlock(
    cx: Float,
    cy: Float,
    label: String,
    value: String,
    unit: String,
    onClick: () -> Unit,
    maxHeightValue: Float
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - 0.13f), y = maxHeight * (cy - 0.075f))
            .width(maxWidth * 0.26f)
            .height(maxHeight * 0.15f)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.layout.Column(horizontalAlignment = Alignment.CenterHorizontally) {
            androidx.compose.material3.Text(label, color = OriginalMuted, fontSize = scaledSp(maxHeightValue * 0.022f), fontWeight = FontWeight.Bold)
            androidx.compose.material3.Text(value, color = OriginalWhite, fontSize = scaledSp(maxHeightValue * 0.036f), fontWeight = FontWeight.Medium)
            androidx.compose.material3.Text(unit, color = OriginalMuted, fontSize = scaledSp(maxHeightValue * 0.017f), maxLines = 1)
        }
    }
}

@Composable
private fun BoxWithConstraintsScope.GhostOriginalText(
    cx: Float,
    cy: Float,
    widthFraction: Float,
    heightFraction: Float,
    text: String,
    size: TextUnit,
    color: Color,
    weight: FontWeight
) {
    Box(
        modifier = Modifier
            .offset(x = maxWidth * (cx - widthFraction / 2f), y = maxHeight * (cy - heightFraction / 2f))
            .width(maxWidth * widthFraction)
            .height(maxHeight * heightFraction),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.material3.Text(
            text = text,
            color = color,
            fontSize = size,
            fontWeight = weight,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

private fun scaledSp(value: Float): TextUnit = max(9f, value).sp

private fun formatOne(value: Double?): String = value?.let { String.format(Locale.US, "%.1f", it) } ?: "--"

private fun ghostOriginalAccentColor(accent: GhostOriginalAccent): Color = when (accent) {
    GhostOriginalAccent.Purple -> Color(0xFF9B5CFF)
    GhostOriginalAccent.Red -> Color(0xFFFF3B30)
    GhostOriginalAccent.Green -> Color(0xFF2EE66B)
    GhostOriginalAccent.White -> Color(0xFFF1F5FF)
    GhostOriginalAccent.Blue -> Color(0xFF3595FF)
    GhostOriginalAccent.Yellow -> Color(0xFFFFC12E)
}

@DrawableRes
private fun ghostOriginalHorizonRes(accent: GhostOriginalAccent): Int = when (accent) {
    GhostOriginalAccent.Purple -> R.drawable.ghost_single_original_horizon_purple
    GhostOriginalAccent.Red -> R.drawable.ghost_single_original_horizon_red
    GhostOriginalAccent.Green -> R.drawable.ghost_single_original_horizon_green
    GhostOriginalAccent.White -> R.drawable.ghost_single_original_horizon_white
    GhostOriginalAccent.Blue -> R.drawable.ghost_single_original_horizon_blue
    GhostOriginalAccent.Yellow -> R.drawable.ghost_single_original_horizon_yellow
}
