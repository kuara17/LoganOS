package com.dcui.loganos.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.ui.theme.LoganPalette
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedGauge(palette: LoganPalette, speed: Int?, style: GaugeStyle, modifier: Modifier = Modifier, demoMode: Boolean = false) {
    when (style) {
        GaugeStyle.Digital -> DigitalGauge(palette, speed, modifier, demoMode)
        GaugeStyle.Sport -> SportGauge(palette, speed, modifier, demoMode)
        GaugeStyle.ClassicOem -> ClassicGauge(palette, speed, modifier, demoMode)
        GaugeStyle.Minimal -> MinimalGauge(palette, speed, modifier, demoMode)
        GaugeStyle.RsPerformance -> RsGauge(palette, speed, modifier, demoMode)
    }
}

@Composable
private fun DigitalGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(((speed ?: 0) / 200f).coerceIn(0f, 1f), tween(450), label = "digitalSpeed")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GaugeArc(palette, progress, strokeDp = 11, start = 145f, sweep = 250f)
        SpeedCenter(palette, speed, when { demoMode -> "DEMO"; speed == null -> "OBD BEKLENİYOR"; else -> "CANLI VERİ" }, if (demoMode) palette.warning else if (speed == null) palette.textSecondary else palette.accent)
    }
}

@Composable
private fun SportGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(((speed ?: 0) / 220f).coerceIn(0f, 1f), tween(450), label = "sportSpeed")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val side = size.minDimension
            val left = (size.width - side) / 2f
            val top = (size.height - side) / 2f
            val stroke = 13.dp.toPx()
            val pad = stroke / 2 + 8.dp.toPx()
            val arcSize = Size(side - pad * 2, side - pad * 2)
            drawArc(color = palette.line, startAngle = 150f, sweepAngle = 240f, useCenter = false, topLeft = Offset(left + pad, top + pad), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(brush = Brush.sweepGradient(listOf(palette.warning, palette.critical, palette.warning)), startAngle = 150f, sweepAngle = 240f * progress, useCenter = false, topLeft = Offset(left + pad, top + pad), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            repeat(30) { i ->
                val angle = Math.toRadians((150 + i * 240 / 29.0).toDouble())
                val r1 = side / 2 - 28.dp.toPx()
                val r2 = side / 2 - 12.dp.toPx()
                val c = Offset(size.width / 2, size.height / 2)
                drawLine(
                    color = palette.muted.copy(alpha = .55f),
                    start = Offset(c.x + cos(angle).toFloat() * r1, c.y + sin(angle).toFloat() * r1),
                    end = Offset(c.x + cos(angle).toFloat() * r2, c.y + sin(angle).toFloat() * r2),
                    strokeWidth = if (i % 5 == 0) 3f else 1.6f
                )
            }
        }
        SpeedCenter(palette, speed, if (demoMode) "DEMO" else if (speed == null) "OBD BEKLENİYOR" else "CANLI VERİ", if (demoMode) palette.warning else palette.critical)
    }
}

@Composable
private fun ClassicGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress = ((speed ?: 0) / 200f).coerceIn(0f, 1f)
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val side = size.minDimension
            val c = Offset(size.width / 2f, size.height / 2f)
            val radius = side / 2f - 18.dp.toPx()
            drawCircle(color = palette.line.copy(alpha = .45f), radius = radius, center = c, style = Stroke(5.dp.toPx()))
            repeat(41) { i ->
                val angleDeg = 145 + i * 250 / 40f
                val angle = Math.toRadians(angleDeg.toDouble())
                val major = i % 5 == 0
                val r1 = radius - if (major) 18.dp.toPx() else 10.dp.toPx()
                val r2 = radius
                drawLine(
                    color = if (major) palette.textSecondary else palette.muted.copy(alpha = .6f),
                    start = Offset(c.x + cos(angle).toFloat() * r1, c.y + sin(angle).toFloat() * r1),
                    end = Offset(c.x + cos(angle).toFloat() * r2, c.y + sin(angle).toFloat() * r2),
                    strokeWidth = if (major) 3f else 1.4f
                )
            }
            val needleAngle = Math.toRadians((145 + 250 * progress).toDouble())
            drawLine(color = palette.accent, start = c, end = Offset(c.x + cos(needleAngle).toFloat() * (radius - 30.dp.toPx()), c.y + sin(needleAngle).toFloat() * (radius - 30.dp.toPx())), strokeWidth = 5f, cap = StrokeCap.Round)
            drawCircle(color = palette.accent, radius = 6.dp.toPx(), center = c)
        }
        SpeedCenter(palette, speed, if (demoMode) "DEMO" else if (speed == null) "OBD BEKLENİYOR" else "CANLI VERİ", if (demoMode) palette.warning else palette.accent)
    }
}

@Composable
private fun MinimalGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(speed?.toString() ?: "--", color = palette.textPrimary, fontSize = if (speed == null) 64.sp else 76.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text("km/h", color = palette.textSecondary, fontSize = 18.sp)
            Text(if (demoMode) "DEMO" else if (speed == null) "OBD BEKLENİYOR" else "CANLI VERİ", color = if (demoMode) palette.warning else if (speed == null) palette.textSecondary else palette.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun RsGauge(palette: LoganPalette, speed: Int?, modifier: Modifier, demoMode: Boolean) {
    val progress by animateFloatAsState(((speed ?: 0) / 220f).coerceIn(0f, 1f), tween(450), label = "rsSpeed")
    Box(modifier = modifier, contentAlignment = Alignment.Center) {
        GaugeArc(palette.copy(accent = palette.critical), progress, strokeDp = 14, start = 135f, sweep = 270f)
        Canvas(modifier = Modifier.fillMaxSize()) {
            val baseY = size.height * .78f
            val w = size.width * .70f
            val startX = (size.width - w) / 2f
            repeat(8) { i ->
                val bar = (i + 1) / 8f
                val h = 5.dp.toPx() + i * 2.2.dp.toPx()
                drawRoundRect(
                    color = if (bar <= progress) palette.critical else palette.line,
                    topLeft = Offset(startX + i * (w / 8f), baseY - h),
                    size = Size(w / 10f, h),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f, 4f)
                )
            }
        }
        SpeedCenter(palette, speed, if (demoMode) "DEMO" else if (speed == null) "OBD BEKLENİYOR" else "CANLI VERİ", if (demoMode) palette.warning else palette.critical)
    }
}

@Composable
private fun GaugeArc(palette: LoganPalette, progress: Float, strokeDp: Int = 12, start: Float = 145f, sweep: Float = 250f) {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val side = size.minDimension
        val left = (size.width - side) / 2f
        val top = (size.height - side) / 2f
        val stroke = strokeDp.dp.toPx()
        val pad = stroke / 2 + 8.dp.toPx()
        val arcSize = Size(side - pad * 2, side - pad * 2)
        drawArc(color = palette.line, startAngle = start, sweepAngle = sweep, useCenter = false, topLeft = Offset(left + pad, top + pad), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        if (progress > 0f) {
            drawArc(brush = Brush.sweepGradient(listOf(palette.accent, palette.accent.copy(alpha = .65f), palette.accent)), startAngle = start, sweepAngle = sweep * progress, useCenter = false, topLeft = Offset(left + pad, top + pad), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun SpeedCenter(palette: LoganPalette, speed: Int?, label: String, labelColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(speed?.toString() ?: "--", color = palette.textPrimary, fontSize = if (speed == null) 48.sp else 54.sp, fontWeight = FontWeight.Black)
        Text("km/h", color = palette.textSecondary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        Text(label, color = labelColor, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
    }
}

@Composable
fun GaugePreview(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.height(156.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(104.dp)
                .padding(horizontal = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            PreviewGaugeArt(palette, style, selected, Modifier.fillMaxSize())
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "42",
                    color = palette.textPrimary,
                    fontSize = 30.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center
                )
                Text("km/h", color = palette.textSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text(style.label, color = if (selected) palette.accent else palette.textSecondary, fontSize = 12.sp, fontWeight = FontWeight.Black)
        Text(previewSubtitle(style), color = palette.textSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 1)
    }
}

@Composable
private fun PreviewGaugeArt(palette: LoganPalette, style: GaugeStyle, selected: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier = modifier) {
        val side = size.minDimension
        val c = Offset(size.width / 2f, size.height * .50f)
        val radius = side * .42f
        val accent = if (selected) palette.accent else palette.textSecondary
        val muted = palette.line.copy(alpha = .95f)

        fun arc(color: Color, start: Float, sweep: Float, stroke: Float, r: Float = radius) {
            drawArc(
                color = color,
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(c.x - r, c.y - r),
                size = Size(r * 2f, r * 2f),
                style = Stroke(stroke, cap = StrokeCap.Round)
            )
        }

        when (style) {
            GaugeStyle.Digital -> {
                arc(muted, 145f, 250f, 12.dp.toPx())
                arc(accent, 145f, 84f, 12.dp.toPx())
                drawCircle(palette.surfaceVariant.copy(alpha = .18f), radius * .62f, c, style = Stroke(1.5.dp.toPx()))
            }
            GaugeStyle.Sport -> {
                arc(muted, 150f, 240f, 13.dp.toPx())
                arc(palette.critical, 150f, 76f, 13.dp.toPx())
                repeat(25) { i ->
                    val deg = 150f + i * 240f / 24f
                    val a = Math.toRadians(deg.toDouble())
                    val major = i % 4 == 0
                    val r1 = radius - if (major) 18.dp.toPx() else 11.dp.toPx()
                    val r2 = radius - 2.dp.toPx()
                    drawLine(
                        color = if (major) palette.textSecondary.copy(alpha = .80f) else palette.muted.copy(alpha = .55f),
                        start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                        end = Offset(c.x + cos(a).toFloat() * r2, c.y + sin(a).toFloat() * r2),
                        strokeWidth = if (major) 2.6f else 1.4f,
                        cap = StrokeCap.Round
                    )
                }
            }
            GaugeStyle.ClassicOem -> {
                drawCircle(muted, radius, c, style = Stroke(4.dp.toPx()))
                repeat(31) { i ->
                    val deg = 145f + i * 250f / 30f
                    val a = Math.toRadians(deg.toDouble())
                    val major = i % 5 == 0
                    val r1 = radius - if (major) 16.dp.toPx() else 9.dp.toPx()
                    drawLine(
                        color = if (major) palette.textSecondary else palette.muted.copy(alpha = .60f),
                        start = Offset(c.x + cos(a).toFloat() * r1, c.y + sin(a).toFloat() * r1),
                        end = Offset(c.x + cos(a).toFloat() * radius, c.y + sin(a).toFloat() * radius),
                        strokeWidth = if (major) 2.7f else 1.3f,
                        cap = StrokeCap.Round
                    )
                }
                val needle = Math.toRadians(225.0)
                drawLine(accent, c, Offset(c.x + cos(needle).toFloat() * radius * .72f, c.y + sin(needle).toFloat() * radius * .72f), 4.dp.toPx(), cap = StrokeCap.Round)
                drawCircle(accent, 5.dp.toPx(), c)
            }
            GaugeStyle.Minimal -> {
                val y = c.y + radius * .72f
                drawRoundRect(
                    color = muted,
                    topLeft = Offset(c.x - radius * .82f, y),
                    size = Size(radius * 1.64f, 5.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                )
                drawRoundRect(
                    color = accent,
                    topLeft = Offset(c.x - radius * .82f, y),
                    size = Size(radius * .62f, 5.dp.toPx()),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                )
            }
            GaugeStyle.RsPerformance -> {
                arc(muted, 135f, 270f, 10.dp.toPx())
                arc(palette.critical, 135f, 98f, 10.dp.toPx())
                val bars = 8
                val baseY = c.y + radius * .70f
                val totalW = radius * 1.75f
                val startX = c.x - totalW / 2f
                repeat(bars) { i ->
                    val h = 7.dp.toPx() + i * 2.5.dp.toPx()
                    drawRoundRect(
                        color = if (i < 3) palette.critical else muted,
                        topLeft = Offset(startX + i * (totalW / bars), baseY - h),
                        size = Size(totalW / 11f, h),
                        cornerRadius = androidx.compose.ui.geometry.CornerRadius(5f, 5f)
                    )
                }
            }
        }
    }
}

private fun previewSubtitle(style: GaugeStyle): String = when (style) {
    GaugeStyle.Digital -> "Sade dijital"
    GaugeStyle.Sport -> "Sport halka"
    GaugeStyle.ClassicOem -> "Analog ibre"
    GaugeStyle.Minimal -> "En sade"
    GaugeStyle.RsPerformance -> "Performans"
}
