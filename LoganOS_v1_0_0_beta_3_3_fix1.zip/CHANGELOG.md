# Changelog

## v1.0.0-beta.3.3-fix1 - Setup Preview + Cockpit Balance Fix

### Fixed

- Rebuilt setup gauge previews so the gauge design is visible and the sample speed number no longer dominates the card.
- Enlarged cockpit metric icons, title text, values and units for better glanceability.
- Balanced Motor / Radyatör and Klima cards so the climate card no longer looks like a smaller side tile.
- Reduced portrait Settings page transition to a short fade to remove the odd slide/jump feeling.
- OBD connect button can be pressed again while connecting, so it no longer stays passively locked during a failed or stale connection attempt.
- Log save/delete actions now show a visible completion toast after confirmation.
- 21CC quick-status polling is prioritized; 21A2 and 21CD are read less frequently to reduce A/C and fan display delay.

### Notes

- This is a Beta 3.3 fix package, not the Beta 3.4 cockpit-layout release.
- User-selectable cockpit layouts/cards remain planned for Beta 3.4.

## v1.0.0-beta.3.3 - Live Data Refresh + Cockpit UI Polish

### Fixed

- Reduced A/C and radiator fan display delay by adding a fast 21CC read before the slower data packets.
- Log Kaydet now opens a confirmation dialog instead of saving immediately.
- Son Logu Sil and Tüm Logları Sil buttons now exist in the OBD panel and require confirmation.
- Main cockpit no longer shows Fuel Truth as a user-facing card.
- Motor Sıcaklığı / Radyatör Fanı typography and alignment were refined.
- Klima card remains separate and visually clearer.
- Average consumption unit changed to `L/100 km`.
- Sürüş Maliyeti now shows `-- ₺` when no price/cost is available.
- Gauge style names such as SPORT / CLASSIC / RS are no longer shown inside the main speed gauge.
- Setup gauge preview speed value reduced so the design is more visible.
- Dacia/Renault brand card selection icon language made consistent.

### Added

- OEM-style drawn metric icons for average fuel, instant fuel, distance, cost, temperature, fan, A/C, RPM, time, battery, speed and injection.
- 21CC_FAST entries in logs to help diagnose A/C and radiator fan response time.
- Faster UI update path for A/C / radiator fan state.

### Notes

- Beta 3.3 is not the full Trip Computer release.
- User-selectable cockpit data and ready-made cockpit layouts are planned for Beta 3.4.
- Smart Trip, stored trip history, and full Fuel Truth trip computer remain planned for Beta 4.
