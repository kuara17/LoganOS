package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PendingPollHistoryEventQueueTest {
    private fun event(name: String) = PendingPollHistoryEvent(7L, "SMART_TRIP", name, "detail", "test")

    @Test fun preservesFifoOrder() {
        val queue = PendingPollHistoryEventQueue(3)
        val first = event("first")
        val second = event("second")
        queue.enqueue(first)
        queue.enqueue(second)
        assertEquals(first, queue.peek())
        assertTrue(queue.removeHead(first))
        assertEquals(second, queue.peek())
    }

    @Test fun duplicateEventsAreNotQueuedTwice() {
        val queue = PendingPollHistoryEventQueue(3)
        val item = event("same")
        assertNull(queue.enqueue(item))
        assertNull(queue.enqueue(item))
        assertEquals(1, queue.size())
    }

    @Test fun capacityEvictsOldestAndStaleHeadCannotRemoveNext() {
        val queue = PendingPollHistoryEventQueue(2)
        val first = event("first")
        val second = event("second")
        val third = event("third")
        queue.enqueue(first)
        queue.enqueue(second)
        assertEquals(first, queue.enqueue(third))
        assertFalse(queue.removeHead(first))
        assertEquals(second, queue.peek())
        assertEquals(2, queue.size())
    }
    @Test fun duplicateEventsRemainDeduplicatedWhenRetryTimestampDiffers() {
        val queue = PendingPollHistoryEventQueue(3)
        val first = event("same")
        val later = first.copy(mark = TimeMark(100L, 100L, "boot", true))
        queue.enqueue(first)
        queue.enqueue(later)
        assertEquals(1, queue.size())
    }

    @Test fun removesOnlyEventsForDeletedSessions() {
        val queue = PendingPollHistoryEventQueue(4)
        val deletedSession = event("old")
        val retained = event("new").copy(sessionId = 8L)
        queue.enqueue(deletedSession)
        queue.enqueue(retained)
        assertEquals(1, queue.removeSessions(setOf(7L)))
        assertEquals(retained, queue.peek())
        assertEquals(1, queue.size())
    }

    @Test fun tracksSqlFailuresOnlyForCurrentHeadAndResetsAfterRemoval() {
        val queue = PendingPollHistoryEventQueue(2)
        val first = event("first")
        val second = event("second")
        queue.enqueue(first)
        queue.enqueue(second)

        assertEquals(0, queue.recordSqlFailure(first))
        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(first))
        assertEquals(1, queue.recordSqlFailure(first))
        assertNull(queue.recordSqlFailure(second))
        assertTrue(queue.removeHead(first))
        // The successful write while the first event was active also proves the database
        // was writable after the second event entered the queue.
        assertEquals(1, queue.recordSqlFailure(second))
        assertEquals(1, queue.recordSqlFailure(second))
        queue.noteSuccessfulSqlWrite()
        assertEquals(2, queue.recordSqlFailure(second))
    }

    @Test fun failureCountersAreRemovedWhenSessionEventsArePrunedOrEvicted() {
        val queue = PendingPollHistoryEventQueue(1)
        val old = event("old")
        val next = event("next").copy(sessionId = 8L)
        queue.enqueue(old)
        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(old))
        assertEquals(1, queue.removeSessions(setOf(7L)))
        queue.enqueue(next)
        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(next))
        val newest = event("newest").copy(sessionId = 9L)
        assertEquals(next, queue.enqueue(newest))
        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(newest))
    }

    @Test fun failuresAdvanceOnlyAfterAnotherSqlWriteSucceeds() {
        val queue = PendingPollHistoryEventQueue(3)
        val item = event("transient-db-outage")
        queue.enqueue(item)

        // Repeated exceptions while the DB has not demonstrated a successful write do not
        // consume the event-specific failure budget.
        assertEquals(0, queue.recordSqlFailure(item))
        assertEquals(0, queue.recordSqlFailure(item))
        assertEquals(0, queue.recordSqlFailure(item))

        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(item))
        assertEquals(1, queue.recordSqlFailure(item))
        queue.noteSuccessfulSqlWrite()
        assertEquals(2, queue.recordSqlFailure(item))
    }

    @Test fun quarantiningHeadRetainsItAndAllowsNextEventToProceed() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val poison = event("event-specific-error")
        val next = event("next-event")
        queue.enqueue(poison)
        queue.enqueue(next)

        val result = queue.quarantineHead(poison, 0L)
        assertTrue(result.quarantined)
        assertNull(result.evicted)
        assertEquals(1, queue.quarantinedSize())
        assertEquals(2, queue.size())
        assertEquals(next, queue.peek())
    }

    @Test fun quarantinedEventDoesNotSuppressLaterOccurrenceOfSameLogicalEvent() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val quarantined = event("same-event")
        val laterOccurrence = quarantined.copy(mark = TimeMark(200L, 200L, "boot", true))
        queue.enqueue(quarantined)
        assertTrue(queue.quarantineHead(quarantined, 1_000L).quarantined)

        queue.enqueue(laterOccurrence)
        assertEquals(1, queue.quarantinedSize())
        assertEquals(laterOccurrence, queue.peek())
        assertEquals(2, queue.size())
    }

    @Test fun quarantinedEventIsNotPromotedBeforeItsRetryDeadline() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val item = event("retry-later")
        queue.enqueue(item)
        val quarantined = queue.quarantineHead(item, 10_000L)
        assertTrue(quarantined.quarantined)
        assertNull(queue.promoteDueQuarantine(69_999L))
        assertNull(queue.peek())
        assertEquals(1, queue.quarantinedSize())
    }

    @Test fun dueQuarantineIsPromotedToActiveTailAndKeepsOriginalEventMark() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val retry = event("quarantine").copy(mark = TimeMark(123L, 456L, "boot", true))
        val existing = event("active")
        queue.enqueue(retry)
        queue.enqueue(existing)
        assertTrue(queue.quarantineHead(retry, 1_000L).quarantined)

        assertEquals(retry, queue.promoteDueQuarantine(61_000L))
        assertEquals(existing, queue.peek())
        assertTrue(queue.removeHead(existing))
        assertEquals(retry, queue.peek())
        assertTrue(queue.isQuarantineRetry(retry))
        assertEquals(0, queue.recordSqlFailure(retry))
        assertTrue(queue.removeHead(retry))
        assertFalse(queue.isQuarantineRetry(retry))
        assertEquals(0, queue.size())
    }

    @Test fun retryCanBeQuarantinedAgainWithIncrementedRetryRound() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val item = event("retry-round")
        queue.enqueue(item)
        val first = queue.quarantineHead(item, 1_000L)
        assertEquals(1, first.retryRound)
        assertEquals(item, queue.promoteDueQuarantine(61_000L))
        queue.noteSuccessfulSqlWrite()
        assertEquals(1, queue.recordSqlFailure(item))
        val second = queue.quarantineHead(item, 62_000L)
        assertEquals(2, second.retryRound)
        assertEquals(1, queue.quarantinedSize())
    }

    @Test fun retryBackoffUsesSixtySecondsFiveMinutesFifteenMinutesThenOneHourCap() {
        val queue = PendingPollHistoryEventQueue(2, quarantineCapacity = 2)
        val item = event("backoff")
        queue.enqueue(item)
        val first = queue.quarantineHead(item, 0L)
        assertEquals(60_000L, first.retryAtElapsedMs)
        assertEquals(item, queue.promoteDueQuarantine(60_000L))
        assertEquals(360_001L, queue.quarantineHead(item, 60_001L).retryAtElapsedMs)
        assertEquals(item, queue.promoteDueQuarantine(360_001L))
        assertEquals(1_260_002L, queue.quarantineHead(item, 360_002L).retryAtElapsedMs)
        assertEquals(item, queue.promoteDueQuarantine(1_260_002L))
        assertEquals(4_860_003L, queue.quarantineHead(item, 1_260_003L).retryAtElapsedMs)
        assertEquals(item, queue.promoteDueQuarantine(4_860_003L))
        assertEquals(8_460_004L, queue.quarantineHead(item, 4_860_004L).retryAtElapsedMs)
    }

    @Test fun noAttemptDeferralPreservesRetryRoundAndDoesNotDropEvent() {
        val queue = PendingPollHistoryEventQueue(2, quarantineCapacity = 2)
        val item = event("no-attempt")
        queue.enqueue(item)
        queue.quarantineHead(item, 0L)
        assertEquals(item, queue.promoteDueQuarantine(60_000L))
        val deferred = queue.deferQuarantineRetryWithoutAttempt(item, 60_001L)
        assertEquals(1, deferred.retryRound)
        assertEquals(120_001L, deferred.retryAtElapsedMs)
        assertEquals(1, queue.quarantinedSize())
    }

    @Test fun retryLogIsRateLimitedToOncePerHour() {
        val queue = PendingPollHistoryEventQueue(2, quarantineCapacity = 2)
        val item = event("log-rate")
        assertTrue(queue.shouldLogQuarantineRetry(item, 1_000L))
        assertFalse(queue.shouldLogQuarantineRetry(item, 2_000L))
        assertTrue(queue.shouldLogQuarantineRetry(item, 3_601_000L))
    }

    @Test fun activeDuplicateRetiresOlderQuarantineCopyWithoutBlockingNextEntry() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 3, retryDelaysMs = listOf(10L, 20L, 30L, 40L))
        val older = event("same")
        val later = older.copy(mark = TimeMark(300L, 300L, "boot", true))
        val nextQuarantine = event("next-quarantine")

        queue.enqueue(older)
        queue.quarantineHead(older, 0L)
        queue.enqueue(nextQuarantine)
        queue.quarantineHead(nextQuarantine, 0L)
        queue.enqueue(later)

        // The first quarantine entry is now represented by an active newer occurrence.
        assertNull(queue.promoteDueQuarantine(10L))
        assertEquals(1, queue.quarantinedSize())
        assertEquals(later, queue.peek())
        assertEquals(2, queue.size())
        assertEquals(nextQuarantine, queue.promoteDueQuarantine(10L))
    }

    @Test fun deletingSessionDuringQuarantineRetryClearsInFlightMetadata() {
        val queue = PendingPollHistoryEventQueue(2, quarantineCapacity = 2, retryDelaysMs = listOf(10L, 20L, 30L, 40L))
        val item = event("deleted-session")
        queue.enqueue(item)
        queue.quarantineHead(item, 0L)
        assertEquals(item, queue.promoteDueQuarantine(10L))
        assertTrue(queue.isQuarantineRetry(item))

        assertEquals(1, queue.removeSessions(setOf(7L)))
        assertFalse(queue.isQuarantineRetry(item))
        assertNull(queue.recordSqlFailure(item))
        assertEquals(0, queue.size())
    }

    @Test fun dueQuarantineWaitsWhenActiveQueueIsFull() {
        val queue = PendingPollHistoryEventQueue(1, quarantineCapacity = 2, retryDelaysMs = listOf(10L, 20L, 30L, 40L))
        val active = event("active")
        val retry = event("retry")
        queue.enqueue(retry)
        queue.quarantineHead(retry, 0L)
        queue.enqueue(active)
        assertNull(queue.promoteDueQuarantine(10L))
        assertEquals(active, queue.peek())
        assertEquals(1, queue.quarantinedSize())
    }

    @Test fun quarantineIsBoundedAndReturnsEvictedOldestItem() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val first = event("first")
        val second = event("second")
        val third = event("third")
        queue.enqueue(first)
        queue.enqueue(second)
        assertTrue(queue.quarantineHead(first, 0L).quarantined)
        assertTrue(queue.quarantineHead(second, 0L).quarantined)
        queue.enqueue(third)
        val result = queue.quarantineHead(third, 0L)

        assertTrue(result.quarantined)
        assertEquals(first, result.evicted)
        assertEquals(2, queue.quarantinedSize())
        assertEquals(2, queue.size())
    }

    @Test fun sessionPruningAndClearIncludeQuarantinedEvents() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 3, retryDelaysMs = listOf(10L, 20L, 30L, 40L))
        val quarantined = event("quarantined")
        val active = event("active").copy(sessionId = 8L)
        queue.enqueue(quarantined)
        queue.quarantineHead(quarantined, 0L)
        queue.enqueue(active)

        assertEquals(1, queue.removeSessions(setOf(7L)))
        assertEquals(1, queue.size())
        assertEquals(active, queue.peek())

        queue.clear()
        assertEquals(0, queue.size())
        assertEquals(0, queue.quarantinedSize())
    }

    @Test fun fiveFailuresWithSuccessfulWritesCanQuarantineWithoutDeletingEvent() {
        val queue = PendingPollHistoryEventQueue(3, quarantineCapacity = 2, retryDelaysMs = listOf(60_000L, 300_000L, 900_000L, 3_600_000L))
        val item = event("repeated-event-specific-failure")
        val next = event("next")
        queue.enqueue(item)
        queue.enqueue(next)

        repeat(5) { expected ->
            queue.noteSuccessfulSqlWrite()
            assertEquals(expected + 1, queue.recordSqlFailure(item))
        }
        val result = queue.quarantineHead(item, 0L)
        assertTrue(result.quarantined)
        assertNull(result.evicted)
        assertEquals(1, queue.quarantinedSize())
        assertEquals(next, queue.peek())
        assertEquals(2, queue.size())
    }

}
