package com.dcui.loganos.data

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class LoganDatabaseAccessGateTest {
    @Test
    fun restoreWaitsForAnAlreadyRunningDatabaseOperation() = runBlocking {
        val operationEntered = CountDownLatch(1)
        val finishOperation = CountDownLatch(1)
        val writer = thread(name = "db-gate-test-writer") {
            LoganDatabaseAccessGate.withDatabaseAccess {
                operationEntered.countDown()
                check(finishOperation.await(3, TimeUnit.SECONDS))
            }
        }
        assertTrue(operationEntered.await(2, TimeUnit.SECONDS))

        val restoreEntered = CompletableDeferred<Unit>()
        val restore = async {
            LoganDatabaseAccessGate.withExclusiveRestoreAccess(waitTimeoutMs = 3_000) {
                restoreEntered.complete(Unit)
                "restored"
            }
        }
        delay(100)
        assertFalse("restore must drain the active operation", restoreEntered.isCompleted)
        finishOperation.countDown()
        assertEquals("restored", restore.await())
        writer.join(2_000)
        assertFalse("writer thread should finish", writer.isAlive)
    }

    @Test
    fun newDatabaseOperationsFailFastDuringRestoreAndResumeAfterward() = runBlocking {
        val restoreEntered = CompletableDeferred<Unit>()
        val allowRestoreToFinish = CompletableDeferred<Unit>()
        val restore = async {
            LoganDatabaseAccessGate.withExclusiveRestoreAccess {
                restoreEntered.complete(Unit)
                allowRestoreToFinish.await()
                "done"
            }
        }
        restoreEntered.await()

        var rejected = false
        try {
            LoganDatabaseAccessGate.withDatabaseAccess { error("operation must not enter") }
        } catch (_: LoganDatabaseAccessGate.RestoreInProgressException) {
            rejected = true
        }
        assertTrue("new DB operations must fail fast during restore", rejected)

        allowRestoreToFinish.complete(Unit)
        assertEquals("done", restore.await())
        assertEquals("normal access must resume after restore", 42,
            LoganDatabaseAccessGate.withDatabaseAccess { 42 })
    }
    @Test
    fun nestedStoreCallsAreReentrantAndDoNotLeakTheOperationCount() {
        val value = LoganDatabaseAccessGate.withDatabaseAccess {
            LoganDatabaseAccessGate.withDatabaseAccess { "nested-ok" }
        }
        assertEquals("nested-ok", value)
        assertEquals("gate remains usable after nested calls", 9,
            LoganDatabaseAccessGate.withDatabaseAccess { 9 })
    }

    @Test
    fun restoreFailureAlwaysReopensNormalDatabaseAccess() = runBlocking {
        try {
            LoganDatabaseAccessGate.withExclusiveRestoreAccess<Unit> {
                throw IllegalStateException("simulated restore failure")
            }
        } catch (_: IllegalStateException) {
            // Expected: verify the finally path released the gate.
        }
        assertEquals(7, LoganDatabaseAccessGate.withDatabaseAccess { 7 })
    }

    @Test
    fun operationExceptionDoesNotLeakTheActiveCount() {
        try {
            LoganDatabaseAccessGate.withDatabaseAccess {
                throw IllegalArgumentException("simulated store failure")
            }
        } catch (_: IllegalArgumentException) {
            // Expected. The next exclusive restore must not see a leaked operation.
        }
        runBlocking {
            assertEquals("restore must acquire after a failed operation", "ok",
                LoganDatabaseAccessGate.withExclusiveRestoreAccess { "ok" })
        }
    }

    @Test
    fun restoreTimeoutReopensTheGate() = runBlocking {
        val entered = CountDownLatch(1)
        val release = CountDownLatch(1)
        val writer = thread(name = "db-gate-timeout-writer") {
            LoganDatabaseAccessGate.withDatabaseAccess {
                entered.countDown()
                release.await(2, TimeUnit.SECONDS)
            }
        }
        assertTrue(entered.await(1, TimeUnit.SECONDS))
        var timedOut = false
        try {
            LoganDatabaseAccessGate.withExclusiveRestoreAccess(waitTimeoutMs = 40) { Unit }
        } catch (_: IllegalStateException) {
            timedOut = true
        } finally {
            release.countDown()
        }
        writer.join(2_000)
        assertTrue("restore must time out while a writer is active", timedOut)
        assertFalse("writer must finish after release", writer.isAlive)
        assertEquals("normal access must resume after timeout", 11,
            LoganDatabaseAccessGate.withDatabaseAccess { 11 })
    }
}
