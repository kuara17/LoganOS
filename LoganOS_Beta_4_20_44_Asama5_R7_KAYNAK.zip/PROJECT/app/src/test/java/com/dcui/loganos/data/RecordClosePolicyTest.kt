package com.dcui.loganos.data

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RecordClosePolicyTest {
    @Test fun onlyStillOpenIsQueuedForRetry() {
        assertTrue(shouldRetryRecordClose(RecordCloseStatus.STILL_OPEN))
        assertFalse(shouldRetryRecordClose(RecordCloseStatus.CLOSED))
        assertFalse(shouldRetryRecordClose(RecordCloseStatus.ALREADY_CLOSED))
        assertFalse(shouldRetryRecordClose(RecordCloseStatus.NOT_FOUND))
        assertFalse(shouldRetryRecordClose(RecordCloseStatus.NOT_REQUESTED))
    }

    @Test fun terminalOrMissingRowsCanDetachFromActivePolling() {
        assertFalse(shouldDetachActiveRecord(RecordCloseStatus.STILL_OPEN))
        assertTrue(shouldDetachActiveRecord(RecordCloseStatus.CLOSED))
        assertTrue(shouldDetachActiveRecord(RecordCloseStatus.ALREADY_CLOSED))
        assertTrue(shouldDetachActiveRecord(RecordCloseStatus.NOT_FOUND))
        assertTrue(shouldDetachActiveRecord(RecordCloseStatus.NOT_REQUESTED))
    }
}
