package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PendingRecordRetryPolicyTest {
    @Test fun retryDelayBacksOffAndCapsAtThirtySeconds() {
        assertEquals(1_000L, pendingRecordRetryDelayMs(1))
        assertEquals(2_000L, pendingRecordRetryDelayMs(2))
        assertEquals(4_000L, pendingRecordRetryDelayMs(3))
        assertEquals(8_000L, pendingRecordRetryDelayMs(4))
        assertEquals(16_000L, pendingRecordRetryDelayMs(5))
        assertEquals(30_000L, pendingRecordRetryDelayMs(6))
        assertEquals(30_000L, pendingRecordRetryDelayMs(99))
        assertEquals(1_000L, pendingRecordRetryDelayMs(0))
    }

    @Test fun retryDeadlineUsesMonotonicComparison() {
        assertFalse(isPendingRecordRetryDue(999L, 1_000L))
        assertTrue(isPendingRecordRetryDue(1_000L, 1_000L))
        assertTrue(isPendingRecordRetryDue(1_001L, 1_000L))
    }

    @Test fun developerReconnectDoesNotConsumeOrScheduleGeneralBudget() {
        assertFalse(shouldConsumeGeneralReconnectBudget(true, false, true))
        assertFalse(shouldScheduleGeneralReconnectAfterContention(true, true))
        assertTrue(shouldConsumeGeneralReconnectBudget(true, false, false))
        assertTrue(shouldScheduleGeneralReconnectAfterContention(true, false))
        assertFalse(shouldConsumeGeneralReconnectBudget(true, true, false))
    }

    @Test fun automaticReconnectAttemptsStopAtConfiguredBudget() {
        assertEquals(1, nextAutomaticReconnectAttemptCount(0, 3))
        assertEquals(2, nextAutomaticReconnectAttemptCount(1, 3))
        assertEquals(3, nextAutomaticReconnectAttemptCount(2, 3))
        assertNull(nextAutomaticReconnectAttemptCount(3, 3))
        assertNull(nextAutomaticReconnectAttemptCount(99, 3))
        assertNull(nextAutomaticReconnectAttemptCount(0, 0))
    }
}
