package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Test

class HistoryExportSelectionTest {
    @Test
    fun onlySuccessfullyIncludedPositiveIdsAreRetainedOnce() {
        val selection = HistoryExportSelection()
        selection.includeDriveRecord(12L)
        selection.includeDriveRecord(12L)
        selection.includeDriveRecord(0L)
        selection.includeDriveRecord(-4L)
        selection.includeTestRecord(31L)
        selection.includeTestRecord(31L)
        selection.includeTestRecord(0L)

        assertEquals(listOf(12L), selection.snapshot().driveRecordIds)
        assertEquals(listOf(31L), selection.snapshot().testRecordIds)
    }

    @Test
    fun snapshotIsAnImmutableCopyOfTheCurrentSelection() {
        val selection = HistoryExportSelection()
        selection.includeDriveRecord(7L)
        val first = selection.snapshot()

        selection.includeDriveRecord(8L)
        selection.includeTestRecord(9L)

        assertEquals(listOf(7L), first.driveRecordIds)
        assertEquals(emptyList<Long>(), first.testRecordIds)
        assertEquals(listOf(7L, 8L), selection.snapshot().driveRecordIds)
        assertEquals(listOf(9L), selection.snapshot().testRecordIds)
    }
}
