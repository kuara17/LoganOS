package com.dcui.loganos.obd

import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MutexPostActionTest {
    @Test
    fun postActionRunsOnlyAfterMutexHasBeenReleased() = runBlocking {
        val mutex = Mutex()
        var blockSawLock = false
        var postActionSawLock = true

        val result = withMutexThenPostAction(
            lock = mutex,
            block = {
                blockSawLock = mutex.isLocked
                "finished"
            },
            postAction = { value ->
                assertTrue(value == "finished")
                postActionSawLock = mutex.isLocked
            }
        )

        assertTrue(blockSawLock)
        assertFalse(postActionSawLock)
        assertFalse(mutex.isLocked)
        assertTrue(result == "finished")
    }

    @Test
    fun labelledEarlyReturnStillReleasesMutexBeforePostAction() = runBlocking {
        val mutex = Mutex()
        var postActionSawLock = true
        val result = withMutexThenPostAction(
            lock = mutex,
            block = { return@withMutexThenPostAction false },
            postAction = { postActionSawLock = mutex.isLocked }
        )
        assertFalse(result)
        assertFalse(postActionSawLock)
        assertFalse(mutex.isLocked)
    }

    @Test
    fun postActionIsSkippedWhenLockedWorkFails() = runBlocking {
        val mutex = Mutex()
        var postActionCalled = false

        runCatching {
            withMutexThenPostAction(
                lock = mutex,
                block = { throw IllegalStateException("trip finalization failed") },
                postAction = { postActionCalled = true }
            )
        }

        assertFalse(postActionCalled)
        assertFalse(mutex.isLocked)
    }
}
