package com.dcui.loganos.data

import java.io.File
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Source-level guards for the file-save-before-exported_at_ms contract (SQLite needs Android). */
class HistoryExportContractTest {
    private fun source(path: String): String {
        val candidates = listOf(
            "src/main/java/$path",
            "app/src/main/java/$path"
        )
        val file = candidates.map(::File).firstOrNull { it.exists() }
            ?: error("$path not found from ${File(".").absoluteFile}")
        return file.readText()
    }

    private fun stripKotlinCommentsAndStringLiterals(code: String): String {
        val out = StringBuilder(code.length)
        var index = 0
        var blockDepth = 0
        var state = 0 // 0=code, 1=line comment, 2=block comment, 3=string, 4=char, 5=raw string
        while (index < code.length) {
            val ch = code[index]
            val next = code.getOrNull(index + 1)
            val triple = code.startsWith("\"\"\"", index)
            when (state) {
                0 -> when {
                    ch == '/' && next == '/' -> { out.append("  "); index += 2; state = 1; continue }
                    ch == '/' && next == '*' -> { out.append("  "); index += 2; blockDepth = 1; state = 2; continue }
                    triple -> { out.append("   "); index += 3; state = 5; continue }
                    ch == '\"' -> { out.append(' '); index++; state = 3; continue }
                    ch == '\'' -> { out.append(' '); index++; state = 4; continue }
                    else -> { out.append(ch); index++ }
                }
                1 -> {
                    if (ch == '\n') { out.append('\n'); state = 0 } else out.append(' ')
                    index++
                }
                2 -> when {
                    ch == '/' && next == '*' -> { out.append("  "); index += 2; blockDepth++ }
                    ch == '*' && next == '/' -> {
                        out.append("  "); index += 2; blockDepth--
                        if (blockDepth == 0) state = 0
                    }
                    ch == '\n' -> { out.append('\n'); index++ }
                    else -> { out.append(' '); index++ }
                }
                3, 4 -> {
                    val closing = if (state == 3) '\"' else '\''
                    when {
                        ch == '\\' -> {
                            out.append("  "); index++
                            if (index < code.length) {
                                out.append(if (code[index] == '\n') '\n' else ' ')
                                index++
                            }
                        }
                        ch == closing -> { out.append(' '); index++; state = 0 }
                        ch == '\n' -> { out.append('\n'); index++ }
                        else -> { out.append(' '); index++ }
                    }
                }
                5 -> {
                    if (triple) { out.append("   "); index += 3; state = 0 }
                    else { out.append(if (ch == '\n') '\n' else ' '); index++ }
                }
            }
        }
        return out.toString()
    }

    private fun section(source: String, start: String, end: String): String {
        val startIndex = source.indexOf(start)
        assertTrue("Missing section start: $start", startIndex >= 0)
        val endIndex = source.indexOf(end, startIndex + start.length)
        assertTrue("Missing section end: $end", endIndex > startIndex)
        return source.substring(startIndex, endIndex)
    }

    @Test
    fun recordTextBuildersDoNotMutateExportTimestamp() {
        val store = source("com/dcui/loganos/data/LoganSqlStore.kt")
        val drive = section(store, "fun exportTripRecordText(", "fun exportTestRecordText(")
        val test = section(store, "fun exportTestRecordText(", "fun markHistoryRecordsExported(")

        val forbiddenMutation = Regex("\\bwritableDatabase\\b|\\.update\\s*\\(|\\bexecSQL\\s*\\(|\\bUPDATE\\b")
        val driveCode = stripKotlinCommentsAndStringLiterals(drive)
        val testCode = stripKotlinCommentsAndStringLiterals(test)
        assertFalse(driveCode.contains("exported_at_ms"))
        assertFalse(testCode.contains("exported_at_ms"))
        assertFalse("drive text builder must not access a writable DB", forbiddenMutation.containsMatchIn(driveCode))
        assertFalse("test text builder must not access a writable DB", forbiddenMutation.containsMatchIn(testCode))
    }

    @Test
    fun exportTimestampUpdatesAreOneTransactionForBothTables() {
        val store = source("com/dcui/loganos/data/LoganSqlStore.kt")
        val marker = section(store, "fun markHistoryRecordsExported(", "private fun findTripRecordId(")

        assertTrue(marker.contains("db.beginTransaction()"))
        assertTrue(marker.contains("db.setTransactionSuccessful()"))
        assertTrue(marker.contains("db.endTransaction()"))
        assertTrue(marker.contains("trip_records"))
        assertTrue(marker.contains("test_sessions"))
        assertTrue(marker.contains("id IN (\$placeholders)"))
    }

    @Test
    fun singleHistoryExportsUseTheSaveThenMarkCoordinator() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val drive = section(controller, "fun exportDriveHistory(", "fun exportGpsRoute(")
        val test = section(controller, "fun exportTestHistory(", "fun exportAllHistory(")
        val commit = section(controller, "private suspend fun saveAndPublishHistoryExport(", "fun exportDriveHistory(")

        assertTrue(drive.contains("saveAndPublishHistoryExport("))
        assertTrue(test.contains("saveAndPublishHistoryExport("))
        assertTrue(drive.contains("HistoryExportRecordIds(driveRecordIds = listOf(id))"))
        assertTrue(test.contains("HistoryExportRecordIds(testRecordIds = listOf(id))"))
        assertTrue(commit.indexOf("saveArtifact = { saveBytesToDownloads") < commit.indexOf("markRecords = sqlStore::markHistoryRecordsExported"))
        assertTrue(commit.contains("HistoryExportCommitCoordinator.commit("))
    }

    @Test
    fun bulkHistoryExportUsesTestedZipBuilderAndMarksAfterSave() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val bulk = section(controller, "fun exportAllHistory()", "private suspend fun publishExportFeedback(")
        val archiveBuilder = source("com/dcui/loganos/data/HistoryExportArchiveBuilder.kt")

        assertTrue(bulk.contains("HistoryExportArchiveBuilder.build("))
        assertTrue(bulk.contains("saveAndPublishHistoryExport("))
        assertTrue(archiveBuilder.indexOf("zip.closeEntry()") < archiveBuilder.indexOf("selected.includeDriveRecord"))
        assertTrue(archiveBuilder.indexOf("zip.closeEntry()", archiveBuilder.indexOf("tests.forEach")) < archiveBuilder.indexOf("selected.includeTestRecord"))
        assertTrue(archiveBuilder.contains("drive_records=\${ids.driveRecordIds.size}"))
        assertTrue(archiveBuilder.contains("test_records=\${ids.testRecordIds.size}"))
    }

    @Test
    fun asynchronousExportsAcquireTheGateInsideTheirCoroutineBody() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val functions = listOf(
            "fun exportDriveHistory(",
            "fun exportGpsRoute(",
            "fun exportTestHistory(",
            "fun exportAllHistory(",
            "fun exportTechnicalSession(",
            "fun saveLogFile("
        )
        functions.forEachIndexed { index, signature ->
            val next = functions.getOrNull(index + 1) ?: "fun shareLogText("
            val body = section(controller, signature, next)
            assertTrue("$signature must launch before acquiring the gate", body.indexOf("scope.launch") < body.indexOf("beginExportOperation("))
            assertTrue("$signature must release the gate in finally", body.contains("finally {") && body.contains("finishExportOperation()"))
        }
    }


    @Test
    fun commentTextDoesNotTriggerWritableDatabaseContract() {
        val source = """
            fun exportTripRecordText() {
                // writableDatabase.update(values)
                /* execSQL(\"UPDATE trip_records\") */
                return
            }
        """.trimIndent()
        val cleaned = stripKotlinCommentsAndStringLiterals(source)
        val forbiddenMutation = Regex("\\bwritableDatabase\\b|\\.update\\s*\\(|\\bexecSQL\\s*\\(|\\bUPDATE\\b")
        assertFalse(forbiddenMutation.containsMatchIn(cleaned))
    }

    @Test
    fun commentMarkersInsideStringLiteralsAreNotTreatedAsComments() {
        val source = "fun exportTripRecordText() { val note = \"// not a comment writableDatabase.update\"; return }"
        val forbiddenMutation = Regex("\\bwritableDatabase\\b|\\.update\\s*\\(|\\bexecSQL\\s*\\(|\\bUPDATE\\b")
        assertFalse(forbiddenMutation.containsMatchIn(stripKotlinCommentsAndStringLiterals(source)))
    }

    @Test
    fun indirectWritableDatabaseMutationIsDetected() {
        val source = "fun exportTripRecordText() { val dbx = writableDatabase; dbx.update(values) }"
        val forbiddenMutation = Regex("\\bwritableDatabase\\b|\\.update\\s*\\(|\\bexecSQL\\s*\\(|\\bUPDATE\\b")
        assertTrue(forbiddenMutation.containsMatchIn(stripKotlinCommentsAndStringLiterals(source)))
    }

    @Test
    fun manualTripRetentionRunsThroughPostUnlockAction() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val finish = section(controller, "suspend fun finishTripNow()", "private fun persistTripRuntime(")
        assertTrue(finish.contains("withMutexThenPostAction("))
        assertTrue(finish.contains("postAction = { finished ->"))
        val postActionStart = finish.indexOf("postAction = { finished ->")
        assertTrue(postActionStart >= 0)
        assertTrue(postActionStart < finish.indexOf("applyHistoryRetentionSafely(\"active_history_flow\")"))
        assertTrue(postActionStart < finish.indexOf("refreshHistoryState()"))
        assertFalse(finish.substring(0, postActionStart).contains("refreshHistoryState()"))
    }

    @Test
    fun rejectedConcurrentExportPublishesAVisibleStatus() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val begin = section(controller, "private fun beginExportOperation(", "private suspend fun finishExportOperation(")
        assertTrue(begin.contains("Dışa aktarma zaten sürüyor; yeni istek başlatılmadı"))
        assertTrue(begin.contains("Başka bir dışa aktarma veya geçmiş işlemi devam ediyor"))
        assertTrue(begin.contains("exportFeedbackMessage = message"))
        assertTrue(begin.contains("exportFeedbackNonce = current.exportFeedbackNonce + 1L"))
    }

    @Test
    fun exportRefreshFailureIsNotReportedAsArtifactSaveFailure() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        val commit = section(controller, "private suspend fun saveAndPublishHistoryExport(", "fun exportDriveHistory(")
        assertTrue(commit.contains("[HISTORY_EXPORT_REFRESH_FAILED]"))
        assertTrue(commit.indexOf("publishExportFeedback(") < commit.indexOf("refreshHistoryState()"))
    }

    @Test
    fun exportDeletionAndRetentionShareTheSameOperationGate() {
        val controller = source("com/dcui/loganos/obd/ObdController.kt")
        assertTrue(controller.contains("private val exportOperationMutex = Mutex()"))
        assertTrue(controller.contains("exportOperationMutex.withLock"))
        assertTrue(controller.contains("if (!exportOperationMutex.tryLock())"))
    }
}
