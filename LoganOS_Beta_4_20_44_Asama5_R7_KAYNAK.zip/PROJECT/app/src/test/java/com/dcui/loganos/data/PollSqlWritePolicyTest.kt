package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PollSqlWritePolicyTest {
    @Test fun threeConsecutiveExpectedFailuresStartCooldown() {
        val policy = PollSqlWritePolicy(failureThreshold = 3, cooldownMs = 15_000L)
        assertTrue(policy.shouldAttempt(100L))
        assertFalse(policy.onExpectedFailure(100L))
        assertFalse(policy.onExpectedFailure(200L))
        assertTrue(policy.onExpectedFailure(300L))
        assertEquals(15_300L, policy.restrictedUntilForTest())
        assertFalse(policy.shouldAttempt(15_299L))
        assertTrue(policy.shouldAttempt(15_300L))
        assertEquals(0, policy.consecutiveFailuresForTest())
        assertEquals(0L, policy.restrictedUntilForTest())
    }

    @Test fun successResetsConsecutiveFailureCount() {
        val policy = PollSqlWritePolicy(failureThreshold = 3, cooldownMs = 10_000L)
        assertFalse(policy.onExpectedFailure(1L))
        assertFalse(policy.onExpectedFailure(2L))
        policy.onSuccess()
        assertFalse(policy.onExpectedFailure(3L))
        assertFalse(policy.onExpectedFailure(4L))
        assertTrue(policy.onExpectedFailure(5L))
    }

    @Test fun failuresDuringCooldownDoNotExtendWindow() {
        val policy = PollSqlWritePolicy(failureThreshold = 1, cooldownMs = 500L)
        assertTrue(policy.onExpectedFailure(100L))
        assertFalse(policy.onExpectedFailure(200L))
        assertEquals(600L, policy.restrictedUntilForTest())
    }
    @Test fun cooldownExpiresAndPolicyCanBeReusedForNextGeneration() {
        val policy = PollSqlWritePolicy(failureThreshold = 1, cooldownMs = 500L)
        assertTrue(policy.onExpectedFailure(100L))
        assertFalse(policy.shouldAttempt(599L))
        assertTrue(policy.shouldAttempt(600L))
        assertEquals(0, policy.consecutiveFailuresForTest())
        assertEquals(0L, policy.restrictedUntilForTest())
        assertTrue(policy.onExpectedFailure(601L))
    }

    @Test fun resetClearsCooldownAndFailureCount() {
        val policy = PollSqlWritePolicy(failureThreshold = 2, cooldownMs = 500L)
        assertFalse(policy.onExpectedFailure(10L))
        policy.reset()
        assertEquals(0, policy.consecutiveFailuresForTest())
        assertTrue(policy.shouldAttempt(11L))
        assertFalse(policy.onExpectedFailure(12L))
    }

}
