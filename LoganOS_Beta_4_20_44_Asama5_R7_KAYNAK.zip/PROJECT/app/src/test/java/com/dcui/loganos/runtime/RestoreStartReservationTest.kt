package com.dcui.loganos.runtime

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RestoreStartReservationTest {
    @Test
    fun completionBeforeCoroutineEntryClaimsCleanupExactlyOnce() {
        val reservation = RestoreStartReservation()

        assertTrue(reservation.claimIfCoroutineNeverEntered())
        assertFalse(reservation.claimIfCoroutineNeverEntered())
    }

    @Test
    fun enteredCoroutineLeavesCleanupToItsFinallyBlock() {
        val reservation = RestoreStartReservation()

        reservation.markCoroutineEntered()

        assertFalse(reservation.claimIfCoroutineNeverEntered())
        assertFalse(reservation.claimIfCoroutineNeverEntered())
    }

    @Test
    fun repeatedEntryMarkingDoesNotReopenCompletionCleanup() {
        val reservation = RestoreStartReservation()

        reservation.markCoroutineEntered()
        reservation.markCoroutineEntered()

        assertFalse(reservation.claimIfCoroutineNeverEntered())
    }
}
