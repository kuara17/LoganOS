package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Test

class ExportTreePathPolicyTest {
    @Test
    fun relativeSegmentsKeepTheLoganOsFolderLayout() {
        assertEquals(
            listOf("LoganOS", "Surus_Kayitlari", "2026-11"),
            ExportTreePathPolicy.relativeSegments("Surus_Kayitlari", "2026-11")
        )
    }

    @Test(expected = IllegalArgumentException::class)
    fun invalidMonthFolderIsRejected() {
        ExportTreePathPolicy.relativeSegments("Surus_Kayitlari", "2026/11")
    }

    @Test
    fun duplicateFileNamesReceiveANonOverwritingSuffix() {
        assertEquals(
            "loganos_drive (3).txt",
            ExportTreePathPolicy.uniqueFileName(
                "loganos_drive.txt",
                listOf("loganos_drive.txt", "loganos_drive (2).txt")
            )
        )
    }

    @Test
    fun duplicateDetectionIsCaseInsensitive() {
        assertEquals(
            "LOGANOS_TEST (2).TXT",
            ExportTreePathPolicy.uniqueFileName("LOGANOS_TEST.TXT", listOf("loganos_test.txt"))
        )
    }
    @Test
    fun monthFolderRejectsOutOfRangeMonths() {
        listOf("2026-00", "2026-13").forEach { month ->
            assertEquals(true, runCatching {
                ExportTreePathPolicy.relativeSegments("Surus_Kayitlari", month)
            }.isFailure)
        }
    }

    @Test
    fun duplicateNameWithoutExtensionReceivesSuffix() {
        assertEquals(
            "archive (2)",
            ExportTreePathPolicy.uniqueFileName("archive", listOf("archive"))
        )
    }

    @Test
    fun existingNumericSuffixIsPreservedAsPartOfBaseName() {
        assertEquals(
            "archive (2) (2).zip",
            ExportTreePathPolicy.uniqueFileName("archive (2).zip", listOf("archive (2).zip"))
        )
    }

}
