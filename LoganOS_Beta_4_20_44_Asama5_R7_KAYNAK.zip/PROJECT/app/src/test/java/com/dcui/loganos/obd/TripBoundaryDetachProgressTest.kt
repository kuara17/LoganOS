package com.dcui.loganos.obd

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TripBoundaryDetachProgressTest {
    @Test fun detachIsAppliedOnlyOnceAcrossRetries() {
        val progress = TripBoundaryDetachProgress()
        assertTrue(progress.shouldApplyDetach())
        progress.markDetachApplied()
        assertTrue(progress.isDetachApplied())
        assertFalse(progress.shouldApplyDetach())
        // A later rebase/cleanup retry must not detach the already-rebased TripComputer again.
        assertFalse(progress.shouldApplyDetach())
    }

    @Test fun aNewBoundaryGetsIndependentProgress() {
        val first = TripBoundaryDetachProgress()
        first.markDetachApplied()
        val next = TripBoundaryDetachProgress()
        assertFalse(first.shouldApplyDetach())
        assertTrue(next.shouldApplyDetach())
    }
}
