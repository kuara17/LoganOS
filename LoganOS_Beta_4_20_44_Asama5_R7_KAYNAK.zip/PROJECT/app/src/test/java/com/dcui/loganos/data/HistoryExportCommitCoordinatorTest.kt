package com.dcui.loganos.data

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CancellationException

class HistoryExportCommitCoordinatorTest {
    @Test
    fun markerRunsOnlyAfterArtifactSaveReturnsSuccessfully() {
        val events = mutableListOf<String>()
        val ids = HistoryExportRecordIds(driveRecordIds = listOf(4L), testRecordIds = listOf(8L))
        val outcome = HistoryExportCommitCoordinator.commit(
            saveArtifact = {
                events += "save"
                "Download/LoganOS/history.zip"
            },
            recordIds = ids,
            markRecords = { selected ->
                events += "mark"
                assertEquals(ids, selected)
                HistoryExportMarkResult(1, 1)
            }
        )

        assertEquals(listOf("save", "mark"), events)
        assertEquals("Download/LoganOS/history.zip", outcome.displayPath)
        assertEquals(1, outcome.markResult?.driveRecordsMarked)
        assertEquals(1, outcome.markResult?.testRecordsMarked)
        assertNull(outcome.markError)
    }

    @Test
    fun failedArtifactSaveNeverInvokesMarker() {
        var markerCalled = false
        val failure = runCatching {
            HistoryExportCommitCoordinator.commit(
                saveArtifact = { throw IllegalStateException("disk full") },
                recordIds = HistoryExportRecordIds(driveRecordIds = listOf(9L)),
                markRecords = {
                    markerCalled = true
                    HistoryExportMarkResult(1, 0)
                }
            )
        }

        assertTrue(failure.isFailure)
        assertTrue("marker must not run after save failure", !markerCalled)
    }

    @Test
    fun markerCancellationIsPropagatedAfterTheArtifactWasSaved() {
        var saved = false
        val failure = runCatching {
            HistoryExportCommitCoordinator.commit(
                saveArtifact = {
                    saved = true
                    "Download/LoganOS/drive.txt"
                },
                recordIds = HistoryExportRecordIds(driveRecordIds = listOf(6L)),
                markRecords = { throw CancellationException("cancelled") }
            )
        }

        assertTrue(saved)
        assertTrue(failure.exceptionOrNull() is CancellationException)
    }

    @Test
    fun markerFailureKeepsTheSavedArtifactAndReturnsSeparateMetadataFailure() {
        val outcome = HistoryExportCommitCoordinator.commit(
            saveArtifact = { "Download/LoganOS/drive.txt" },
            recordIds = HistoryExportRecordIds(driveRecordIds = listOf(5L)),
            markRecords = { throw IllegalStateException("database locked") }
        )

        assertEquals("Download/LoganOS/drive.txt", outcome.displayPath)
        assertNull(outcome.markResult)
        assertNotNull(outcome.markError)
        assertEquals("database locked", outcome.markError?.message)
    }
}
