package com.dcui.loganos.runtime

import android.content.Context
import com.dcui.loganos.data.LoganDatabaseAccessGate
import com.dcui.loganos.obd.ObdController
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide owner for the live OBD controller.
 *
 * The controller must outlive MainActivity while a foreground driving service is
 * active. Restore is an asynchronous lifecycle transition: no caller is ever
 * made to wait on the Main thread for controller shutdown or database draining.
 */
object LoganRuntime {
    private var controller: ObdController? = null
    private var restoreInProgress: Boolean = false
    private var restoreQuarantined: Boolean = false
    private val restoreScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutableRestoreInProgress = MutableStateFlow(false)
    val restoreInProgressFlow: StateFlow<Boolean> = mutableRestoreInProgress.asStateFlow()
    private val mutableRestoreQuarantined = MutableStateFlow(false)
    val restoreQuarantinedFlow: StateFlow<Boolean> = mutableRestoreQuarantined.asStateFlow()

    val isRestoreInProgress: Boolean
        get() = synchronized(this) { restoreInProgress }

    /** Starts restore independently of an Activity so configuration changes cannot cancel it.
     * The short state reservation is synchronous; all shutdown, draining and file work is
     * dispatched on the process IO scope (never executed undispatched on the caller thread).
     */
    fun <T> launchDatabaseRestore(block: suspend () -> T): Deferred<T> {
        val current = synchronized(this) {
            check(!restoreInProgress && !restoreQuarantined) {
                "LoganOS geri yükleme işlemi zaten devam ediyor veya güvenli duruma alınmış"
            }
            restoreInProgress = true
            mutableRestoreInProgress.value = true
            controller
        }
        val reservation = RestoreStartReservation()
        val deferred = restoreScope.async {
            reservation.markCoroutineEntered()
            withObdControllerReleased(current, block)
        }
        // If the scope is cancelled before the coroutine gets its first instruction,
        // its finally block cannot release the synchronous reservation. Completion is
        // therefore the fallback owner for that narrow pre-start window.
        deferred.invokeOnCompletion {
            if (reservation.claimIfCoroutineNeverEntered()) {
                synchronized(this) {
                    if (!restoreQuarantined) {
                        restoreInProgress = false
                        mutableRestoreInProgress.value = false
                    }
                }
            }
        }
        return deferred
    }

    /** True only when the old controller was safely discarded and a fresh one may be created. */
    fun canRecreateControllerAfterRestore(): Boolean = synchronized(this) {
        // A precondition failure may leave the original controller healthy and reusable.
        // Activity recreation is safe in that case too; quarantine is the only blocked state.
        !restoreInProgress && !restoreQuarantined
    }

    val isRestoreQuarantined: Boolean
        get() = synchronized(this) { restoreQuarantined }

    fun obdController(context: Context): ObdController = synchronized(this) {
        check(!restoreInProgress && !restoreQuarantined) {
            "LoganOS veritabanı geri yükleme/kurtarma durumunda; OBD controller kullanılamaz"
        }
        controller ?: ObdController(context.applicationContext).also { controller = it }
    }

    /**
     * Stops controller/GPS producers, drains all synchronous store operations,
     * closes the old helper, and executes restore under the process-wide gate.
     * The caller must invoke this from a coroutine; blocking waits run on IO.
     */
    private suspend fun <T> withObdControllerReleased(
        current: ObdController?,
        block: suspend () -> T
    ): T {
        var controllerDiscarded = current == null
        var quarantineRequired = false
        try {
            return withContext(Dispatchers.IO) {
                try {
                    current?.prepareForDatabaseRestore()
                } catch (cancelled: CancellationException) {
                    // Preserve structured cancellation. If shutdown already began, do not
                    // let the partially stopped controller be reused; quarantine it.
                    if (current?.hasStartedDatabaseRestoreShutdown == true) {
                        quarantineRequired = true
                    }
                    throw cancelled
                } catch (prepareFailure: Exception) {
                    if (current?.hasStartedDatabaseRestoreShutdown == true) {
                        // A partially stopped controller must never be handed back. Retire it
                        // only after every synchronous DB operation has drained successfully.
                        try {
                            LoganDatabaseAccessGate.withExclusiveRestoreAccess {
                                current.closeDatabaseForRestore()
                                controllerDiscarded = true
                            }
                        } catch (cancelled: CancellationException) {
                            quarantineRequired = true
                            cancelled.addSuppressed(prepareFailure)
                            throw cancelled
                        } catch (drainFailure: Exception) {
                            prepareFailure.addSuppressed(drainFailure)
                            quarantineRequired = true
                            throw IllegalStateException(
                                "OBD kapatıldı ancak veritabanı erişimleri güvenle boşaltılamadı. LoganOS'u zorla durdurup yeniden açın.",
                                prepareFailure
                            )
                        }
                    }
                    throw prepareFailure
                }

                try {
                    LoganDatabaseAccessGate.withExclusiveRestoreAccess {
                        current?.closeDatabaseForRestore()
                        if (current != null) controllerDiscarded = true
                        block()
                    }
                } catch (cancelled: CancellationException) {
                    if (current?.hasStartedDatabaseRestoreShutdown == true && !controllerDiscarded) {
                        quarantineRequired = true
                    }
                    throw cancelled
                } catch (restoreFailure: Exception) {
                    // If shutdown started but exclusive access could not be acquired (for
                    // example a drain timeout), the old controller/store cannot be reused.
                    if (current?.hasStartedDatabaseRestoreShutdown == true && !controllerDiscarded) {
                        quarantineRequired = true
                        throw IllegalStateException(
                            "Veritabanı işlemleri güvenli biçimde boşaltılamadı. LoganOS'u zorla durdurup yeniden açın.",
                            restoreFailure
                        )
                    }
                    throw restoreFailure
                }
            }
        } finally {
            synchronized(this) {
                if (controllerDiscarded && controller === current) controller = null
                if (quarantineRequired) {
                    // Keep restore blocked for the remainder of this process. A partially
                    // stopped controller must not be reused and another restore must not race it.
                    restoreQuarantined = true
                    mutableRestoreQuarantined.value = true
                    restoreInProgress = true
                    mutableRestoreInProgress.value = true
                } else {
                    restoreInProgress = false
                    mutableRestoreInProgress.value = false
                }
            }
        }
    }

}
