package com.dcui.loganos.data

/** IDs of history records whose entries were actually written into an export artifact. */
internal data class HistoryExportRecordIds(
    val driveRecordIds: List<Long> = emptyList(),
    val testRecordIds: List<Long> = emptyList()
)

/** Result of the post-save exported_at_ms transaction. */
internal data class HistoryExportMarkResult(
    val driveRecordsMarked: Int,
    val testRecordsMarked: Int
)

/** Tracks only successfully written ZIP entries; failed/missing records are never marked. */
internal class HistoryExportSelection {
    private val driveIds = linkedSetOf<Long>()
    private val testIds = linkedSetOf<Long>()

    fun includeDriveRecord(id: Long) {
        if (id > 0L) driveIds += id
    }

    fun includeTestRecord(id: Long) {
        if (id > 0L) testIds += id
    }

    fun snapshot(): HistoryExportRecordIds = HistoryExportRecordIds(
        driveRecordIds = driveIds.toList(),
        testRecordIds = testIds.toList()
    )
}
