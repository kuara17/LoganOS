package com.dcui.loganos.data

/**
 * Bounds repeated transient history-write failures without taking down the live OBD poll loop.
 * Calls are synchronized because a retiring poll generation may briefly overlap a new one.
 */
internal class PollSqlWritePolicy(
    private val failureThreshold: Int = 3,
    private val cooldownMs: Long = 15_000L
) {
    private var consecutiveFailures: Int = 0
    private var restrictedUntilElapsedMs: Long = 0L

    init {
        require(failureThreshold > 0)
        require(cooldownMs > 0L)
    }

    @Synchronized
    fun shouldAttempt(nowElapsedMs: Long): Boolean {
        expireCooldownIfNeeded(nowElapsedMs)
        return restrictedUntilElapsedMs == 0L
    }

    @Synchronized
    fun onSuccess() {
        consecutiveFailures = 0
    }

    /** Returns true when this failure starts a new cooldown window. */
    @Synchronized
    fun onExpectedFailure(nowElapsedMs: Long): Boolean {
        expireCooldownIfNeeded(nowElapsedMs)
        if (restrictedUntilElapsedMs != 0L) return false
        consecutiveFailures++
        if (consecutiveFailures < failureThreshold) return false
        consecutiveFailures = 0
        restrictedUntilElapsedMs = nowElapsedMs + cooldownMs
        return true
    }

    @Synchronized
    fun reset() {
        consecutiveFailures = 0
        restrictedUntilElapsedMs = 0L
    }

    @Synchronized
    internal fun consecutiveFailuresForTest(): Int = consecutiveFailures

    @Synchronized
    internal fun restrictedUntilForTest(): Long = restrictedUntilElapsedMs

    private fun expireCooldownIfNeeded(nowElapsedMs: Long) {
        if (restrictedUntilElapsedMs != 0L && nowElapsedMs >= restrictedUntilElapsedMs) {
            restrictedUntilElapsedMs = 0L
            consecutiveFailures = 0
        }
    }
}
