package com.dcui.loganos.data

import java.util.Locale

/** Pure path/name policy shared by the SAF exporter and its JVM tests. */
internal object ExportTreePathPolicy {
    fun relativeSegments(folderName: String, monthFolder: String): List<String> {
        require(folderName.isNotBlank()) { "Export folder name is required" }
        require(monthFolder.matches(Regex("\\d{4}-(0[1-9]|1[0-2])"))) { "Month folder must use yyyy-MM" }
        return listOf("LoganOS", folderName, monthFolder)
    }

    fun uniqueFileName(requestedName: String, existingNames: Collection<String>): String {
        require(requestedName.isNotBlank()) { "File name is required" }
        val existing = existingNames.mapTo(HashSet()) { it.lowercase(Locale.ROOT) }
        if (requestedName.lowercase(Locale.ROOT) !in existing) return requestedName

        val dot = requestedName.lastIndexOf('.')
        val base = if (dot > 0) requestedName.substring(0, dot) else requestedName
        val extension = if (dot > 0) requestedName.substring(dot) else ""
        var suffix = 2
        while (true) {
            val candidate = "$base ($suffix)$extension"
            if (candidate.lowercase(Locale.ROOT) !in existing) return candidate
            suffix++
        }
    }
}
