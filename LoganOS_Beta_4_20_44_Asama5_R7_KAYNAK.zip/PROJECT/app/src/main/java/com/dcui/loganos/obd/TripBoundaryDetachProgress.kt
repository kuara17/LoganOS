package com.dcui.loganos.obd

/**
 * Tracks the irreversible TripComputer detach step across retries of one pending boundary.
 * The instance belongs to PendingTripBoundary and is discarded only when that boundary resolves.
 */
internal class TripBoundaryDetachProgress {
    private var detachApplied: Boolean = false

    @Synchronized
    fun shouldApplyDetach(): Boolean = !detachApplied

    @Synchronized
    fun markDetachApplied() {
        detachApplied = true
    }

    @Synchronized
    fun isDetachApplied(): Boolean = detachApplied
}
