package com.dcui.loganos.data

import java.util.ArrayDeque

data class PendingPollHistoryEvent(
    val sessionId: Long?,
    val category: String,
    val name: String,
    val detail: String?,
    val label: String,
    val mark: TimeMark? = null
)

internal data class PendingPollEventQuarantineResult(
    val quarantined: Boolean,
    val evicted: PendingPollHistoryEvent? = null,
    val retryAtElapsedMs: Long? = null,
    val retryRound: Int? = null
)

/**
 * Bounded in-memory FIFO for critical poll events plus a bounded dead-letter quarantine.
 *
 * A head failure is considered event-specific only when another poll SQL write succeeded since
 * the previous counted failure. Known transient SQLite failures do not advance that counter.
 * After repeated event-specific failures the event moves to quarantine so later critical events
 * can proceed. Quarantined events are retried at a low frequency while this controller lives;
 * they remain memory-only and are cleared on session deletion, Clear All, or restore shutdown.
 */
internal class PendingPollHistoryEventQueue(
    private val capacity: Int = 32,
    private val quarantineCapacity: Int = capacity,
    retryDelaysMs: List<Long> = listOf(60_000L, 300_000L, 900_000L, 3_600_000L),
    private val retryLogIntervalMs: Long = 3_600_000L
) {
    private val retryDelaysMs = retryDelaysMs.toList()
    private data class SqlFailureProgress(
        var failures: Int,
        var lastSuccessfulWriteGeneration: Long
    )

    private data class QuarantinedEvent(
        val event: PendingPollHistoryEvent,
        val nextRetryElapsedMs: Long
    )

    private val queue = ArrayDeque<PendingPollHistoryEvent>()
    private val quarantine = ArrayDeque<QuarantinedEvent>()
    private val sqlFailureProgress = mutableMapOf<PendingPollHistoryEvent, SqlFailureProgress>()
    private val quarantineRetryRounds = mutableMapOf<PendingPollHistoryEvent, Int>()
    private val quarantineRetryInFlight = mutableSetOf<PendingPollHistoryEvent>()
    private val lastQuarantineRetryLogElapsedMs = mutableMapOf<PendingPollHistoryEvent, Long>()
    private var successfulSqlWriteGeneration: Long = 0L

    init {
        require(capacity > 0)
        require(quarantineCapacity > 0)
        require(this.retryDelaysMs.isNotEmpty() && this.retryDelaysMs.all { it > 0L })
        require(retryLogIntervalMs > 0L)
    }

    /** Returns the oldest active event dropped by capacity pressure, if any. */
    @Synchronized
    fun enqueue(event: PendingPollHistoryEvent): PendingPollHistoryEvent? {
        // Only active entries suppress duplicates. A quarantined event must not suppress a new
        // occurrence of the same logical event; the new occurrence gets its own active slot.
        if (queue.any { sameLogicalEvent(it, event) }) return null
        val dropped = if (queue.size >= capacity) queue.removeFirst() else null
        dropped?.let {
            sqlFailureProgress.remove(it)
            quarantineRetryInFlight.remove(it)
            quarantineRetryRounds.remove(it)
            lastQuarantineRetryLogElapsedMs.remove(it)
        }
        queue.addLast(event)
        sqlFailureProgress[event] = SqlFailureProgress(
            failures = 0,
            lastSuccessfulWriteGeneration = successfulSqlWriteGeneration
        )
        return dropped
    }

    @Synchronized
    fun peek(): PendingPollHistoryEvent? = queue.peekFirst()

    @Synchronized
    fun removeHead(expected: PendingPollHistoryEvent): Boolean {
        if (queue.peekFirst() != expected) return false
        queue.removeFirst()
        sqlFailureProgress.remove(expected)
        quarantineRetryInFlight.remove(expected)
        quarantineRetryRounds.remove(expected)
        lastQuarantineRetryLogElapsedMs.remove(expected)
        return true
    }

    /** Marks a successful poll SQL write. */
    @Synchronized
    fun noteSuccessfulSqlWrite() {
        if (successfulSqlWriteGeneration < Long.MAX_VALUE) successfulSqlWriteGeneration++
    }

    /** Counts a head failure only after another poll SQL write succeeded since the last count. */
    @Synchronized
    fun recordSqlFailure(expected: PendingPollHistoryEvent): Int? {
        if (queue.peekFirst() != expected) return null
        val progress = sqlFailureProgress[expected] ?: return null
        if (successfulSqlWriteGeneration > progress.lastSuccessfulWriteGeneration) {
            if (progress.failures < Int.MAX_VALUE) progress.failures++
            progress.lastSuccessfulWriteGeneration = successfulSqlWriteGeneration
        }
        return progress.failures
    }

    /** Moves the current head into quarantine and returns any older quarantined event evicted. */
    @Synchronized
    fun quarantineHead(
        expected: PendingPollHistoryEvent,
        nowElapsedMs: Long,
    ): PendingPollEventQuarantineResult {
        if (queue.peekFirst() != expected) return PendingPollEventQuarantineResult(quarantined = false)
        queue.removeFirst()
        sqlFailureProgress.remove(expected)
        quarantineRetryInFlight.remove(expected)
        val retryRound = ((quarantineRetryRounds[expected]?.toLong() ?: 0L) + 1L)
            .coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        quarantineRetryRounds[expected] = retryRound
        val retryDelayMs = retryDelaysMs[(retryRound - 1).coerceAtMost(retryDelaysMs.lastIndex)]
        val retryAt = if (Long.MAX_VALUE - nowElapsedMs < retryDelayMs) Long.MAX_VALUE else nowElapsedMs + retryDelayMs
        val evicted = if (quarantine.size >= quarantineCapacity) quarantine.removeFirst().event else null
        evicted?.let {
            quarantineRetryRounds.remove(it)
            lastQuarantineRetryLogElapsedMs.remove(it)
        }
        quarantine.addLast(QuarantinedEvent(expected, retryAt))
        return PendingPollEventQuarantineResult(
            quarantined = true,
            evicted = evicted,
            retryAtElapsedMs = retryAt,
            retryRound = retryRound
        )
    }

    /**
     * Promotes at most one due quarantined event to the active FIFO tail. Returns null when no
     * event is due or active capacity is full. Retry rounds remain associated until persistence.
     */
    @Synchronized
    fun promoteDueQuarantine(nowElapsedMs: Long): PendingPollHistoryEvent? {
        val candidate = quarantine.peekFirst() ?: return null
        if (candidate.nextRetryElapsedMs > nowElapsedMs || queue.size >= capacity) return null
        if (queue.any { sameLogicalEvent(it, candidate.event) }) {
            // An active occurrence already represents this logical event. Retire the older
            // quarantined copy so it cannot block later quarantine entries at the FIFO head.
            quarantine.removeFirst()
            quarantineRetryRounds.remove(candidate.event)
            lastQuarantineRetryLogElapsedMs.remove(candidate.event)
            return null
        }
        quarantine.removeFirst()
        queue.addLast(candidate.event)
        sqlFailureProgress[candidate.event] = SqlFailureProgress(
            failures = 0,
            lastSuccessfulWriteGeneration = successfulSqlWriteGeneration
        )
        quarantineRetryInFlight.add(candidate.event)
        return candidate.event
    }

    /** Requeues a promoted retry when SQL was not attempted; does not consume a retry round. */
    @Synchronized
    fun deferQuarantineRetryWithoutAttempt(
        expected: PendingPollHistoryEvent,
        nowElapsedMs: Long
    ): PendingPollEventQuarantineResult {
        if (queue.peekFirst() != expected || expected !in quarantineRetryInFlight) {
            return PendingPollEventQuarantineResult(quarantined = false)
        }
        queue.removeFirst()
        sqlFailureProgress.remove(expected)
        quarantineRetryInFlight.remove(expected)
        val retryRound = quarantineRetryRounds[expected] ?: 1
        val retryDelayMs = retryDelaysMs[(retryRound - 1).coerceAtMost(retryDelaysMs.lastIndex)]
        val retryAt = if (Long.MAX_VALUE - nowElapsedMs < retryDelayMs) Long.MAX_VALUE else nowElapsedMs + retryDelayMs
        val evicted = if (quarantine.size >= quarantineCapacity) quarantine.removeFirst().event else null
        evicted?.let {
            quarantineRetryRounds.remove(it)
            lastQuarantineRetryLogElapsedMs.remove(it)
        }
        quarantine.addLast(QuarantinedEvent(expected, retryAt))
        return PendingPollEventQuarantineResult(true, evicted, retryAt, retryRound)
    }

    @Synchronized
    fun isQuarantineRetry(event: PendingPollHistoryEvent): Boolean = event in quarantineRetryInFlight

    /** Log the first retry failure and then at most once per configured interval. */
    @Synchronized
    fun shouldLogQuarantineRetry(event: PendingPollHistoryEvent, nowElapsedMs: Long): Boolean {
        val previous = lastQuarantineRetryLogElapsedMs[event]
        if (previous == null || nowElapsedMs < previous || nowElapsedMs - previous >= retryLogIntervalMs) {
            lastQuarantineRetryLogElapsedMs[event] = nowElapsedMs
            return true
        }
        return false
    }

    /** Removes active and quarantined events tied to drive sessions deleted by the user. */
    @Synchronized
    fun removeSessions(sessionIds: Set<Long>): Int {
        if (sessionIds.isEmpty()) return 0
        val activeRemoved = queue.filter { it.sessionId != null && it.sessionId in sessionIds }
        queue.removeIf { it.sessionId != null && it.sessionId in sessionIds }
        activeRemoved.forEach {
            sqlFailureProgress.remove(it)
            quarantineRetryInFlight.remove(it)
            quarantineRetryRounds.remove(it)
            lastQuarantineRetryLogElapsedMs.remove(it)
        }

        val quarantinedRemoved = quarantine.filter { it.event.sessionId != null && it.event.sessionId in sessionIds }
        quarantine.removeIf { it.event.sessionId != null && it.event.sessionId in sessionIds }
        quarantinedRemoved.forEach {
            quarantineRetryRounds.remove(it.event)
            lastQuarantineRetryLogElapsedMs.remove(it.event)
        }
        return activeRemoved.size + quarantinedRemoved.size
    }

    @Synchronized
    fun clear() {
        queue.clear()
        quarantine.clear()
        sqlFailureProgress.clear()
        quarantineRetryRounds.clear()
        quarantineRetryInFlight.clear()
        lastQuarantineRetryLogElapsedMs.clear()
    }

    /** Total retained events, including quarantined events. */
    @Synchronized
    fun size(): Int = queue.size + quarantine.size

    @Synchronized
    fun quarantinedSize(): Int = quarantine.size

    private fun sameLogicalEvent(existing: PendingPollHistoryEvent, event: PendingPollHistoryEvent): Boolean =
        existing.sessionId == event.sessionId && existing.category == event.category &&
            existing.name == event.name && existing.detail == event.detail && existing.label == event.label
}
