package com.dcui.loganos.data

import java.util.concurrent.CancellationException

internal data class HistoryExportCommitOutcome(
    val displayPath: String,
    val markResult: HistoryExportMarkResult?,
    val markError: Exception?
)

/** Ensures exported_at_ms marking is attempted only after the artifact writer returns success. */
internal object HistoryExportCommitCoordinator {
    fun commit(
        saveArtifact: () -> String,
        recordIds: HistoryExportRecordIds,
        markRecords: (HistoryExportRecordIds) -> HistoryExportMarkResult
    ): HistoryExportCommitOutcome {
        val displayPath = saveArtifact() // A failure here must prevent the mark callback entirely.
        return try {
            HistoryExportCommitOutcome(
                displayPath = displayPath,
                markResult = markRecords(recordIds),
                markError = null
            )
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Exception) {
            // The file already exists. Preserve it and report the metadata commit failure separately.
            HistoryExportCommitOutcome(displayPath, markResult = null, markError = error)
        }
    }
}
