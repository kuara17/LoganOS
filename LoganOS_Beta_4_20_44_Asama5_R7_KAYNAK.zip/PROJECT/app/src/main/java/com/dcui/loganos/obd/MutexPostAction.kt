package com.dcui.loganos.obd

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Runs the post-action only after [lock] has been released. */
internal suspend fun <T> withMutexThenPostAction(
    lock: Mutex,
    block: suspend () -> T,
    postAction: suspend (T) -> Unit
): T {
    val result = lock.withLock { block() }
    postAction(result)
    return result
}
