package com.dcui.loganos.data

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

internal data class DriveHistoryExportEntry(
    val recordId: Long,
    val startedAtMs: Long,
    val text: String
)

internal data class TestHistoryExportEntry(
    val archiveIndex: Int,
    val recordId: Long,
    val text: String
)

internal data class HistoryExportArchive(
    val bytes: ByteArray,
    val recordIds: HistoryExportRecordIds
)

/** Pure ZIP builder. Only records whose ZIP entries close successfully are selected for marking. */
internal object HistoryExportArchiveBuilder {
    fun build(
        versionName: String,
        drives: Sequence<DriveHistoryExportEntry>,
        tests: Sequence<TestHistoryExportEntry>
    ): HistoryExportArchive {
        val selected = HistoryExportSelection()
        val bytes = ByteArrayOutputStream().use { buffer ->
            ZipOutputStream(buffer).use { zip ->
                drives.forEach { item ->
                    zip.putNextEntry(ZipEntry("drives/drive_id${item.recordId}_${item.startedAtMs}.txt"))
                    zip.write(item.text.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    selected.includeDriveRecord(item.recordId)
                }
                tests.forEach { item ->
                    zip.putNextEntry(ZipEntry("tests/test_${item.archiveIndex}_id${item.recordId}.txt"))
                    zip.write(item.text.toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    selected.includeTestRecord(item.recordId)
                }
                val ids = selected.snapshot()
                val summary = buildString {
                    appendLine("LOGANOS HISTORY EXPORT")
                    appendLine("version=$versionName")
                    appendLine("drive_records=${ids.driveRecordIds.size}")
                    appendLine("test_records=${ids.testRecordIds.size}")
                    appendLine("drive_format=summary")
                    appendLine("drive_raw_ecu_packets=false")
                    appendLine("test_format=summary+raw")
                }
                zip.putNextEntry(ZipEntry("summary.txt"))
                zip.write(summary.toByteArray(Charsets.UTF_8))
                zip.closeEntry()
            }
            buffer.toByteArray()
        }
        return HistoryExportArchive(bytes = bytes, recordIds = selected.snapshot())
    }
}
