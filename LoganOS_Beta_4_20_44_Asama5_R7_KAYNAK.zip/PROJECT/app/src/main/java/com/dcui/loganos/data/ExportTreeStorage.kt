package com.dcui.loganos.data

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import java.io.IOException

/**
 * Persisted Storage Access Framework tree used only on Android 8/9.
 * All document operations stay inside the user-selected tree and LoganOS directory.
 */
class ExportTreeStorage(context: Context) {
    private val appContext = context.applicationContext
    private val resolver = appContext.contentResolver
    private val preferences = appContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    data class SavedFile(val displayPath: String, val fileName: String)
    data class DeleteResult(val deleted: Int, val failed: Int)

    fun currentTreeUri(): Uri? = preferences.getString(KEY_TREE_URI, null)
        ?.let { runCatching { Uri.parse(it) }.getOrNull() }

    fun persistTree(uri: Uri): String {
        val oldUri = currentTreeUri()
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        resolver.takePersistableUriPermission(uri, flags)
        val permission = resolver.persistedUriPermissions.firstOrNull { it.uri == uri }
        if (permission == null || !permission.isReadPermission || !permission.isWritePermission) {
            if (oldUri != uri) releasePermission(uri)
            throw SecurityException("Seçilen klasör için kalıcı okuma/yazma izni alınamadı")
        }
        val label = queryDisplayName(uri) ?: "Seçilen klasör"
        val stored = preferences.edit()
            .putString(KEY_TREE_URI, uri.toString())
            .putString(KEY_TREE_LABEL, label)
            .commit()
        if (!stored) {
            if (oldUri != uri) releasePermission(uri)
            throw IOException("Dışa aktarma klasörü tercihi kaydedilemedi")
        }
        if (oldUri != null && oldUri != uri) releasePermission(oldUri)
        return label
    }

    fun displayName(uri: Uri? = currentTreeUri()): String? {
        uri ?: return null
        if (!hasReadWritePermission(uri)) return null
        return preferences.getString(KEY_TREE_LABEL, null) ?: "Seçilen klasör"
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        val root = rootDocumentUri(uri)
        resolver.query(root, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            ?.use { cursor -> if (cursor.moveToFirst()) cursor.getString(0) else null }
    }.getOrNull()

    fun save(
        requestedFileName: String,
        mimeType: String,
        bytes: ByteArray,
        folderName: String,
        monthFolder: String
    ): SavedFile {
        val tree = currentTreeUri() ?: throw IOException(
            "Android 8/9 için dışa aktarma klasörü seçilmedi. Ayarlar > Sürüş ve Kayıtlar bölümünden klasör seçin."
        )
        if (!hasReadWritePermission(tree)) {
            throw SecurityException(
                "Dışa aktarma klasörünün izni geçersiz. Ayarlar > Sürüş ve Kayıtlar bölümünden klasörü yeniden seçin."
            )
        }

        try {
            val root = rootDocumentUri(tree)
            val appRoot = findOrCreateDirectory(tree, root, "LoganOS")
            var parent = appRoot
            ExportTreePathPolicy.relativeSegments(folderName, monthFolder).drop(1).forEach { segment ->
                parent = findOrCreateDirectory(tree, parent, segment)
            }
            // Names are unique across the complete LoganOS tree because the UI keeps
            // only the last file name for the "clear last log" action.
            val existingNames = collectDocumentNames(tree, appRoot)
            val actualName = ExportTreePathPolicy.uniqueFileName(requestedFileName, existingNames)
            val created = DocumentsContract.createDocument(resolver, parent, mimeType, actualName)
                ?: throw IOException("SAF sağlayıcısı dosyayı oluşturamadı: $actualName")
            try {
                val output = resolver.openOutputStream(created, "w")
                    ?: throw IOException("Dışa aktarma dosya akışı açılamadı")
                output.use { stream ->
                    stream.write(bytes)
                    stream.flush()
                }
            } catch (error: Exception) {
                runCatching { DocumentsContract.deleteDocument(resolver, created) }
                if (error is SecurityException) throw error
                throw IOException("Seçilen klasöre dosya yazılamadı: ${error.message ?: error.javaClass.simpleName}", error)
            }

            val treeName = displayName(tree) ?: "Seçilen klasör"
            val path = (listOf(treeName) + ExportTreePathPolicy.relativeSegments(folderName, monthFolder) + actualName)
                .joinToString("/")
            return SavedFile(path, actualName)
        } catch (error: SecurityException) {
            throw SecurityException(
                "Dışa aktarma klasörünün erişim izni geçersiz. Ayarlar > Sürüş ve Kayıtlar bölümünden klasörü yeniden seçin.",
                error
            )
        }
    }

    fun deleteFile(fileName: String): Boolean {
        val tree = currentTreeUri() ?: return false
        if (!hasReadWritePermission(tree)) {
            throw SecurityException("Dışa aktarma klasörünün izni geçersiz. Klasörü yeniden seçin.")
        }
        val appRoot = findChild(tree, rootDocumentUri(tree), "LoganOS") ?: return false
        val target = findFileRecursively(tree, appRoot, fileName) ?: return false
        return DocumentsContract.deleteDocument(resolver, target)
    }

    fun deleteAllLogFiles(): DeleteResult {
        val tree = currentTreeUri() ?: return DeleteResult(0, 0)
        if (!hasReadWritePermission(tree)) {
            throw SecurityException("Dışa aktarma klasörünün izni geçersiz. Klasörü yeniden seçin.")
        }
        val appRoot = findChild(tree, rootDocumentUri(tree), "LoganOS") ?: return DeleteResult(0, 0)
        return deleteLogFilesRecursively(tree, appRoot, HashSet())
    }

    private data class ChildDocument(val uri: Uri, val name: String, val mimeType: String)

    private fun hasReadWritePermission(uri: Uri): Boolean =
        resolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission && it.isWritePermission
        }

    private fun rootDocumentUri(tree: Uri): Uri =
        DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))

    private fun children(tree: Uri, parent: Uri): List<ChildDocument> {
        val parentId = DocumentsContract.getDocumentId(parent)
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        val result = ArrayList<ChildDocument>()
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeColumn = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
            while (cursor.moveToNext()) {
                val id = cursor.getString(idColumn)
                result += ChildDocument(
                    DocumentsContract.buildDocumentUriUsingTree(tree, id),
                    cursor.getString(nameColumn) ?: "",
                    cursor.getString(mimeColumn) ?: ""
                )
            }
        } ?: throw IOException("Seçilen klasörün içeriği okunamadı")
        return result
    }

    private fun findChild(tree: Uri, parent: Uri, name: String): Uri? {
        val existing = children(tree, parent).firstOrNull { it.name.equals(name, ignoreCase = true) }
            ?: return null
        if (existing.mimeType != DocumentsContract.Document.MIME_TYPE_DIR) {
            throw IOException("Dışa aktarma klasörünün yerinde aynı isimli dosya var: ${existing.name}")
        }
        return existing.uri
    }

    private fun findOrCreateDirectory(tree: Uri, parent: Uri, name: String): Uri {
        val existing = children(tree, parent).firstOrNull { it.name.equals(name, ignoreCase = true) }
        if (existing != null) {
            if (existing.mimeType != DocumentsContract.Document.MIME_TYPE_DIR) {
                throw IOException("Dışa aktarma klasörünün yerinde aynı isimli dosya var: ${existing.name}")
            }
            return existing.uri
        }
        return DocumentsContract.createDocument(
            resolver, parent, DocumentsContract.Document.MIME_TYPE_DIR, name
        ) ?: throw IOException("Dışa aktarma klasörü oluşturulamadı: $name")
    }

    private fun collectDocumentNames(
        tree: Uri,
        parent: Uri,
        visitedDocumentIds: MutableSet<String> = HashSet()
    ): List<String> {
        val parentId = DocumentsContract.getDocumentId(parent)
        if (!visitedDocumentIds.add(parentId)) return emptyList()
        val names = ArrayList<String>()
        children(tree, parent).forEach { child ->
            names += child.name
            if (child.mimeType == DocumentsContract.Document.MIME_TYPE_DIR) {
                names += collectDocumentNames(tree, child.uri, visitedDocumentIds)
            }
        }
        return names
    }

    private fun findFileRecursively(
        tree: Uri,
        parent: Uri,
        fileName: String,
        visitedDocumentIds: MutableSet<String> = HashSet()
    ): Uri? {
        val parentId = DocumentsContract.getDocumentId(parent)
        if (!visitedDocumentIds.add(parentId)) return null
        children(tree, parent).forEach { child ->
            if (child.mimeType == DocumentsContract.Document.MIME_TYPE_DIR) {
                findFileRecursively(tree, child.uri, fileName, visitedDocumentIds)?.let { return it }
            } else if (child.name.equals(fileName, ignoreCase = true)) {
                return child.uri
            }
        }
        return null
    }

    private fun deleteLogFilesRecursively(
        tree: Uri,
        parent: Uri,
        visitedDocumentIds: MutableSet<String>
    ): DeleteResult {
        val parentId = DocumentsContract.getDocumentId(parent)
        if (!visitedDocumentIds.add(parentId)) return DeleteResult(0, 0)
        var deleted = 0
        var failed = 0
        val childDocuments = try {
            children(tree, parent)
        } catch (_: Exception) {
            return DeleteResult(deleted = 0, failed = 1)
        }
        childDocuments.forEach { child ->
            if (child.mimeType == DocumentsContract.Document.MIME_TYPE_DIR) {
                val nested = deleteLogFilesRecursively(tree, child.uri, visitedDocumentIds)
                deleted += nested.deleted
                failed += nested.failed
            } else if (
                child.name.startsWith("loganos_", ignoreCase = true) &&
                listOf(".txt", ".zip", ".gpx").any { child.name.endsWith(it, ignoreCase = true) }
            ) {
                val wasDeleted = try {
                    DocumentsContract.deleteDocument(resolver, child.uri)
                } catch (_: Exception) {
                    false
                }
                if (wasDeleted) deleted++ else failed++
            }
        }
        return DeleteResult(deleted, failed)
    }

    private fun releasePermission(uri: Uri) {
        val flags = android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
            android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
        runCatching { resolver.releasePersistableUriPermission(uri, flags) }
    }

    companion object {
        private const val PREFERENCES_NAME = "loganos_export_storage"
        private const val KEY_TREE_URI = "export_tree_uri_v1"
        private const val KEY_TREE_LABEL = "export_tree_label_v1"
    }
}
