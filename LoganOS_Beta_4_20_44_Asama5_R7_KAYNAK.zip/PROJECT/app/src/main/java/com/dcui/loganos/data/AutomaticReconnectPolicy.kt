package com.dcui.loganos.data

/** Returns the next bounded automatic reconnect attempt, or null when the budget is exhausted. */
fun nextAutomaticReconnectAttemptCount(currentAttemptCount: Int, maxAttempts: Int): Int? {
    if (maxAttempts <= 0 || currentAttemptCount >= maxAttempts) return null
    return currentAttemptCount.coerceAtLeast(0) + 1
}

/** True only for attempts charged to the shared automatic reconnect budget. */
fun shouldConsumeGeneralReconnectBudget(
    autoReconnectAttempt: Boolean,
    ignitionWakeProbe: Boolean,
    developerTestReconnect: Boolean
): Boolean = autoReconnectAttempt && !ignitionWakeProbe && !developerTestReconnect

/** Developer-test reconnects keep ownership of their own bounded retry scheduler. */
fun shouldScheduleGeneralReconnectAfterContention(
    autoReconnectAttempt: Boolean,
    developerTestReconnect: Boolean
): Boolean = autoReconnectAttempt && !developerTestReconnect
