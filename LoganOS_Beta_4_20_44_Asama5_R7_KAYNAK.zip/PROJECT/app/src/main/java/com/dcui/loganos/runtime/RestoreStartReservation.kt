package com.dcui.loganos.runtime

import java.util.concurrent.atomic.AtomicBoolean

/** Coordinates the coroutine-entry and Deferred-completion race for restore reservation cleanup. */
internal class RestoreStartReservation {
    private val coroutineEntered = AtomicBoolean(false)

    fun markCoroutineEntered() {
        coroutineEntered.set(true)
    }

    /** Returns true exactly once only when completion happened before the body entered. */
    fun claimIfCoroutineNeverEntered(): Boolean = coroutineEntered.compareAndSet(false, true)
}
