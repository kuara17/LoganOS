package com.dcui.loganos.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit
import kotlin.coroutines.coroutineContext

/**
 * Process-wide gate for synchronous LoganSqlStore operations.
 *
 * Ordinary database calls fail fast once restore has started; they never wait on
 * the UI thread. Restore waits on Dispatchers.IO until all already-entered calls
 * have left, then owns the database exclusively until its block completes.
 */
object LoganDatabaseAccessGate {
    private val monitor = Object()
    private val operationDepth = ThreadLocal.withInitial { 0 }
    private var activeOperations = 0
    private var restoreActive = false

    class RestoreInProgressException : IllegalStateException(
        "LoganOS veritabanı geri yükleme sırasında kullanılamaz"
    )

    @PublishedApi
    internal fun enterOperation() {
        val depth = operationDepth.get()
        if (depth > 0) {
            operationDepth.set(depth + 1)
            return
        }
        synchronized(monitor) {
            if (restoreActive) throw RestoreInProgressException()
            activeOperations++
            operationDepth.set(1)
        }
    }

    @PublishedApi
    internal fun exitOperation() {
        val depth = operationDepth.get()
        check(depth > 0) { "Unbalanced LoganOS database access gate" }
        if (depth > 1) {
            operationDepth.set(depth - 1)
            return
        }
        operationDepth.remove()
        synchronized(monitor) {
            activeOperations--
            check(activeOperations >= 0) { "Negative LoganOS database operation count" }
            if (activeOperations == 0) monitor.notifyAll()
        }
    }

    inline fun <T> withDatabaseAccess(block: () -> T): T {
        enterOperation()
        try {
            return block()
        } finally {
            exitOperation()
        }
    }

    /**
     * Must be called from a coroutine. The wait is deliberately performed on
     * Dispatchers.IO, never on Main. New synchronous store operations fail fast
     * from the moment restoreActive is set.
     */
    suspend fun <T> withExclusiveRestoreAccess(
        waitTimeoutMs: Long = DEFAULT_DRAIN_TIMEOUT_MS,
        block: suspend () -> T
    ): T = withContext(Dispatchers.IO) {
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(waitTimeoutMs)
        val callerContext = coroutineContext
        synchronized(monitor) {
            check(!restoreActive) { "Başka bir veritabanı geri yükleme işlemi devam ediyor" }
            restoreActive = true
        }
        try {
            synchronized(monitor) {
                while (activeOperations > 0) {
                    callerContext.ensureActive()
                    val remainingNanos = deadline - System.nanoTime()
                    if (remainingNanos <= 0L) {
                        throw IllegalStateException(
                            "Veritabanı işlemleri ${waitTimeoutMs} ms içinde tamamlanmadı"
                        )
                    }
                    val waitMs = (TimeUnit.NANOSECONDS.toMillis(remainingNanos)).coerceAtLeast(1L).coerceAtMost(250L)
                    monitor.wait(waitMs)
                }
            }
            block()
        } finally {
            synchronized(monitor) {
                // Even a timeout/cancellation must reopen normal access.
                restoreActive = false
                monitor.notifyAll()
            }
        }
    }

    private const val DEFAULT_DRAIN_TIMEOUT_MS = 30_000L
}
