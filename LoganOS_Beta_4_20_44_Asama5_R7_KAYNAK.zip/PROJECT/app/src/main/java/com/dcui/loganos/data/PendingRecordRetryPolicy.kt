package com.dcui.loganos.data

/** Exponential retry delay for transient pending-history writes, capped at 30 seconds. */
fun pendingRecordRetryDelayMs(attempt: Int): Long {
    val normalized = attempt.coerceAtLeast(1)
    val exponent = (normalized - 1).coerceAtMost(5)
    return (1_000L shl exponent).coerceAtMost(30_000L)
}

/** A pending write is due only after its monotonic retry deadline. */
fun isPendingRecordRetryDue(nowElapsedMs: Long, retryAtElapsedMs: Long): Boolean =
    nowElapsedMs >= retryAtElapsedMs
