package com.dcui.loganos.data

/** Result of attempting to close a persisted SQL session or test-history row. */
enum class RecordCloseStatus { CLOSED, ALREADY_CLOSED, NOT_FOUND, NOT_REQUESTED, STILL_OPEN }

/** Pure close policy, kept Android-free so it can be deterministically unit tested. */
fun shouldRetryRecordClose(status: RecordCloseStatus): Boolean = status == RecordCloseStatus.STILL_OPEN
fun shouldDetachActiveRecord(status: RecordCloseStatus): Boolean = status != RecordCloseStatus.STILL_OPEN
