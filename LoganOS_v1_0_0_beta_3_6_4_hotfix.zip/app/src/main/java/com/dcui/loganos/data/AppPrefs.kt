package com.dcui.loganos.data

import android.content.Context
import com.dcui.loganos.model.AccentColor
import com.dcui.loganos.model.Brand
import com.dcui.loganos.model.DeviceMode
import com.dcui.loganos.model.GaugeStyle
import com.dcui.loganos.model.LoganSettings

class AppPrefs(context: Context) {
    private val prefs = context.getSharedPreferences("loganos_settings", Context.MODE_PRIVATE)

    fun load(): LoganSettings {
        return LoganSettings(
            setupCompleted = prefs.getBoolean(KEY_SETUP, false),
            brand = prefs.getEnum(KEY_BRAND, Brand.Dacia),
            vehicleModel = prefs.getString(KEY_MODEL, "Dacia Logan") ?: "Dacia Logan",
            engine = prefs.getString(KEY_ENGINE, "1.5 dCi 68 bg") ?: "1.5 dCi 68 bg",
            deviceMode = prefs.getEnum(KEY_DEVICE, DeviceMode.Phone),
            gaugeStyle = prefs.getEnum(KEY_GAUGE, GaugeStyle.Digital),
            accentColor = prefs.getEnum(KEY_ACCENT, AccentColor.OemGreen),
            darkMode = prefs.getBoolean(KEY_DARK, false),
            keepScreenOn = prefs.getBoolean(KEY_KEEP_SCREEN, true),
            backgroundTripEnabled = prefs.getBoolean(KEY_BACKGROUND_TRIP, true),
            smartTripMinutes = prefs.getInt(KEY_SMART_TRIP, 60),
            demoMode = prefs.getBoolean(KEY_DEMO_MODE, false),
            disclaimerAccepted = prefs.getBoolean(KEY_DISCLAIMER, false),
            fuelPriceText = prefs.getString(KEY_FUEL_PRICE, "") ?: "",
            odometerText = prefs.getString(KEY_ODOMETER, "335420") ?: "335420",
            oilServiceKm = prefs.getString(KEY_OIL_SERVICE, "10000") ?: "10000",
            fuelFilterKm = prefs.getString(KEY_FUEL_FILTER, "20000") ?: "20000",
            airFilterKm = prefs.getString(KEY_AIR_FILTER, "10000") ?: "10000",
            timingBeltKm = prefs.getString(KEY_TIMING_BELT, "60000") ?: "60000",
            rawEcuLogEnabled = prefs.getBoolean(KEY_RAW_ECU_LOG, false),
            longTripLogEnabled = prefs.getBoolean(KEY_LONG_TRIP_LOG, false)
        )
    }

    fun save(settings: LoganSettings) {
        prefs.edit()
            .putBoolean(KEY_SETUP, settings.setupCompleted)
            .putString(KEY_BRAND, settings.brand.name)
            .putString(KEY_MODEL, settings.vehicleModel)
            .putString(KEY_ENGINE, settings.engine)
            .putString(KEY_DEVICE, settings.deviceMode.name)
            .putString(KEY_GAUGE, settings.gaugeStyle.name)
            .putString(KEY_ACCENT, settings.accentColor.name)
            .putBoolean(KEY_DARK, settings.darkMode)
            .putBoolean(KEY_KEEP_SCREEN, settings.keepScreenOn)
            .putBoolean(KEY_BACKGROUND_TRIP, settings.backgroundTripEnabled)
            .putInt(KEY_SMART_TRIP, settings.smartTripMinutes)
            .putBoolean(KEY_DEMO_MODE, settings.demoMode)
            .putBoolean(KEY_DISCLAIMER, settings.disclaimerAccepted)
            .putString(KEY_FUEL_PRICE, settings.fuelPriceText)
            .putString(KEY_ODOMETER, settings.odometerText)
            .putString(KEY_OIL_SERVICE, settings.oilServiceKm)
            .putString(KEY_FUEL_FILTER, settings.fuelFilterKm)
            .putString(KEY_AIR_FILTER, settings.airFilterKm)
            .putString(KEY_TIMING_BELT, settings.timingBeltKm)
            .putBoolean(KEY_RAW_ECU_LOG, settings.rawEcuLogEnabled)
            .putBoolean(KEY_LONG_TRIP_LOG, settings.longTripLogEnabled)
            .apply()
    }

    fun resetSetup() {
        prefs.edit().clear().apply()
    }

    private inline fun <reified T : Enum<T>> android.content.SharedPreferences.getEnum(key: String, default: T): T {
        val value = getString(key, default.name) ?: default.name
        return runCatching { enumValueOf<T>(value) }.getOrDefault(default)
    }

    companion object {
        private const val KEY_SETUP = "setup_completed"
        private const val KEY_BRAND = "brand"
        private const val KEY_MODEL = "vehicle_model"
        private const val KEY_ENGINE = "engine"
        private const val KEY_DEVICE = "device_mode"
        private const val KEY_GAUGE = "gauge_style"
        private const val KEY_ACCENT = "accent_color"
        private const val KEY_DARK = "dark_mode"
        private const val KEY_KEEP_SCREEN = "keep_screen_on"
        private const val KEY_BACKGROUND_TRIP = "background_trip"
        private const val KEY_SMART_TRIP = "smart_trip_minutes"
        private const val KEY_DEMO_MODE = "demo_mode"
        private const val KEY_DISCLAIMER = "disclaimer_accepted"
        private const val KEY_FUEL_PRICE = "fuel_price"
        private const val KEY_ODOMETER = "odometer"
        private const val KEY_OIL_SERVICE = "oil_service_km"
        private const val KEY_FUEL_FILTER = "fuel_filter_km"
        private const val KEY_AIR_FILTER = "air_filter_km"
        private const val KEY_TIMING_BELT = "timing_belt_km"
        private const val KEY_RAW_ECU_LOG = "raw_ecu_log"
        private const val KEY_LONG_TRIP_LOG = "long_trip_log"
    }
}
