## v1.0.0-beta.3.6.4 - Test, Log, Setup and Technical Screen Polish

- Fuel Truth / FuelAlgorithmV3 kept intact from beta 3.6.x.
- Smart Trip / TripComputer kept intact; total fuel / total distance average remains the source of truth.
- SQL trip logging kept and improved.
- SQL export now uses readable summary sample lines with loop index and real time.
- Normal exports no longer include raw 21A0 / 21A2 / 21CC / 21CD hex packets by default.
- Added Long Trip Log option for lighter 1-second summary logging on 300-400 km drives.
- Added Developer Raw Log option; raw ECU packets are recorded only when this is enabled.
- Technical screen changed from raw ECU/debug blocks to meaningful advanced live values and connection quality counters.
- Added OBD quality counters: loop count, slow loop count, NO DATA, STOPPED, BUS INIT.
- Developer guided tests clarified: Electric Load keeps A/C off; Full Load test added for A/C + electrical loads.
- Setup wizard now requires explicit selections before Continue becomes active.
- Vehicle list simplified: Dacia Logan 2005-2012 Sedan/MCV is the supported profile; Sandero I is experimental; 2013+ Logan/MCV and Duster are unsupported/locked.

