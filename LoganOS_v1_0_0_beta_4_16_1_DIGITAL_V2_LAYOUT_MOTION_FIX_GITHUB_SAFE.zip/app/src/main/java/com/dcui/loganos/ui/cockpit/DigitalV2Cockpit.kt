package com.dcui.loganos.ui.cockpit

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.dcui.loganos.R
import com.dcui.loganos.model.AppLanguage
import com.dcui.loganos.model.DashboardSnapshot
import com.dcui.loganos.model.DigitalV2GaugeMode
import com.dcui.loganos.model.DigitalV2Scene
import com.dcui.loganos.model.LoganSettings
import com.dcui.loganos.obd.ObdState
import com.dcui.loganos.ui.components.CardIcon
import com.dcui.loganos.ui.components.MetricIcon
import com.dcui.loganos.ui.components.VehicleAssetStyle
import com.dcui.loganos.ui.components.vehicleVisualDrawableRes
import com.dcui.loganos.ui.theme.LoganPalette
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

private val DigitalV2Blue = Color(0xFF1479FF)
private val DigitalV2Red = Color(0xFFFF3B30)
private val DigitalV2Glass = Color(0xEAF7F9FC)

@Composable
fun DigitalV2Cockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    portrait: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    if (portrait) {
        DigitalV2PortraitCockpit(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick
        )
    } else {
        DigitalV2LandscapeCockpit(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            obdState = obdState,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick
        )
    }
}

@Composable
private fun DigitalV2PortraitCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    BoxWithConstraints(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        val sceneHeight = maxHeight * 0.60f
        val panelTop = maxHeight * 0.575f
        val gaugeHeight = sceneHeight * 0.74f
        val carWidth = maxWidth * 0.30f
        val movement = settings.digitalV2MotionEnabled

        Image(
            painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .fillMaxWidth()
                .height(sceneHeight)
        )
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(sceneHeight)
                .background(
                    Brush.verticalGradient(
                        listOf(
                            Color(0x3F062B55),
                            Color.Transparent,
                            Color(0x20061422),
                            Color(0x65081420)
                        )
                    )
                )
        )

        DigitalV2RoadMotion(
            speedKmh = snapshot.speedKmh ?: 0,
            enabled = movement,
            modifier = Modifier
                .fillMaxWidth()
                .height(sceneHeight)
        )
        DigitalV2WindOverlay(
            speedKmh = snapshot.speedKmh ?: 0,
            enabled = movement,
            modifier = Modifier
                .fillMaxWidth()
                .height(sceneHeight)
        )

        DigitalV2Header(
            tr = tr,
            connected = snapshot.connected || obdState.connected,
            demo = settings.demoMode || snapshot.demo,
            onOpenReset = onOpenReset,
            onObdClick = onObdClick,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )

        DigitalV2Gauge(
            mode = settings.digitalV2GaugeMode,
            speedKmh = snapshot.speedKmh,
            rpm = snapshot.rpm,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .padding(top = 12.dp)
                .fillMaxWidth(0.98f)
                .height(gaugeHeight)
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(panelTop)
        ) {
            DigitalV2Vehicle(
                settings = settings,
                speedKmh = snapshot.speedKmh ?: 0,
                motionEnabled = movement,
                width = carWidth,
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .offset(y = (-5).dp)
            )
        }

        DigitalV2DataPanel(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            tr = tr,
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .padding(top = panelTop)
        )
    }
}

@Composable
private fun DigitalV2LandscapeCockpit(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    obdState: ObdState,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    Row(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE9EEF4))
    ) {
        Box(modifier = Modifier.weight(1.55f).fillMaxHeight()) {
            Image(
                painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0x3A052242), Color.Transparent, Color(0x73061018))))
            )
            DigitalV2RoadMotion(snapshot.speedKmh ?: 0, settings.digitalV2MotionEnabled, Modifier.fillMaxSize())
            DigitalV2WindOverlay(snapshot.speedKmh ?: 0, settings.digitalV2MotionEnabled, Modifier.fillMaxSize())
            DigitalV2Header(
                tr = tr,
                connected = snapshot.connected || obdState.connected,
                demo = settings.demoMode || snapshot.demo,
                onOpenReset = onOpenReset,
                onObdClick = onObdClick,
                modifier = Modifier.fillMaxWidth().padding(10.dp)
            )
            DigitalV2Gauge(
                mode = settings.digitalV2GaugeMode,
                speedKmh = snapshot.speedKmh,
                rpm = snapshot.rpm,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 4.dp).fillMaxWidth(0.94f).fillMaxHeight(0.86f)
            )
            DigitalV2Vehicle(
                settings = settings,
                speedKmh = snapshot.speedKmh ?: 0,
                motionEnabled = settings.digitalV2MotionEnabled,
                width = 166.dp,
                modifier = Modifier.align(Alignment.BottomCenter).offset(y = (-5).dp)
            )
        }
        DigitalV2CompactDataPanel(
            palette = palette,
            settings = settings,
            snapshot = snapshot,
            tr = tr,
            modifier = Modifier.weight(1f).fillMaxHeight()
        )
    }
}

@Composable
private fun DigitalV2Header(
    tr: Boolean,
    connected: Boolean,
    demo: Boolean,
    onOpenReset: () -> Unit,
    onObdClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(13.dp))
                .background(Color.White.copy(alpha = .16f))
                .border(1.dp, Color.White.copy(alpha = .30f), RoundedCornerShape(13.dp))
                .clickable(onClick = onOpenReset),
            contentAlignment = Alignment.Center
        ) {
            Text("⋮", color = Color.White, fontSize = 27.sp, fontWeight = FontWeight.Black)
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xB2123657))
                .border(1.dp, Color.White.copy(alpha = .27f), RoundedCornerShape(14.dp))
                .clickable(onClick = onObdClick)
                .padding(horizontal = 11.dp, vertical = 9.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                when {
                    demo -> "DEMO"
                    connected -> if (tr) "OBD BAĞLI" else "OBD ON"
                    else -> if (tr) "OBD BEKLENİYOR" else "OBD WAITING"
                },
                color = if (connected || demo) Color(0xFF9BE8B5) else Color.White,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun DigitalV2Gauge(
    mode: DigitalV2GaugeMode,
    speedKmh: Int?,
    rpm: Int?,
    modifier: Modifier = Modifier,
    preview: Boolean = false
) {
    val rawProgress = when (mode) {
        DigitalV2GaugeMode.Speed -> ((speedKmh ?: 0) / 200f).coerceIn(0f, 1f)
        DigitalV2GaugeMode.Rpm -> ((rpm ?: 0) / 7000f).coerceIn(0f, 1f)
    }
    val progress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(if (preview) 0 else 380),
        label = "digitalV2GaugeProgress"
    )
    val labels = if (mode == DigitalV2GaugeMode.Speed) (0..200 step 20).toList() else (0..70 step 10).toList()
    val majorCount = labels.lastIndex.coerceAtLeast(1)

    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * 0.485f
            val center = Offset(size.width / 2f, size.height * 0.60f)
            val startAngle = 145f
            val sweep = 250f
            val arcTopLeft = Offset(center.x - radius, center.y - radius)
            val arcSize = Size(radius * 2f, radius * 2f)

            drawArc(
                color = Color.White.copy(alpha = .92f),
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.014f, cap = StrokeCap.Round)
            )
            drawArc(
                brush = Brush.sweepGradient(listOf(DigitalV2Blue, Color.White, Color.White, DigitalV2Red), center),
                startAngle = startAngle,
                sweepAngle = sweep * progress,
                useCenter = false,
                topLeft = arcTopLeft,
                size = arcSize,
                style = Stroke(width = radius * 0.021f, cap = StrokeCap.Round)
            )

            val minorTicks = majorCount * 5
            repeat(minorTicks + 1) { index ->
                val fraction = index / minorTicks.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val major = index % 5 == 0
                val outer = radius * 0.99f
                val inner = radius * if (major) 0.865f else 0.925f
                val p1 = Offset(center.x + cos(angle).toFloat() * inner, center.y + sin(angle).toFloat() * inner)
                val p2 = Offset(center.x + cos(angle).toFloat() * outer, center.y + sin(angle).toFloat() * outer)
                drawLine(
                    color = Color.White.copy(alpha = if (major) .98f else .67f),
                    start = p1,
                    end = p2,
                    strokeWidth = if (major) radius * .014f else radius * .0055f,
                    cap = StrokeCap.Round
                )
            }

            labels.forEachIndexed { index, value ->
                val fraction = index / majorCount.toFloat()
                val angle = Math.toRadians((startAngle + sweep * fraction).toDouble())
                val labelRadius = radius * .735f
                val x = center.x + cos(angle).toFloat() * labelRadius
                val y = center.y + sin(angle).toFloat() * labelRadius + radius * .038f
                drawContext.canvas.nativeCanvas.drawText(
                    value.toString(),
                    x,
                    y,
                    Paint().apply {
                        isAntiAlias = true
                        color = android.graphics.Color.WHITE
                        textAlign = Paint.Align.CENTER
                        textSize = radius * if (preview) .112f else .124f
                        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
                        setShadowLayer(radius * .020f, 0f, radius * .009f, android.graphics.Color.argb(175, 0, 0, 0))
                    }
                )
            }

            val needleAngle = Math.toRadians((startAngle + sweep * progress).toDouble())
            val needleEnd = Offset(
                center.x + cos(needleAngle).toFloat() * radius * .80f,
                center.y + sin(needleAngle).toFloat() * radius * .80f
            )
            drawLine(Color.White.copy(alpha = .98f), center, needleEnd, radius * .018f, StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = .95f), radius * .027f, center)
            drawCircle(Color(0xFF3E739D), radius * .013f, center)
        }

        val centerValue = when (mode) {
            DigitalV2GaugeMode.Speed -> rpm?.let { (it / 100f).toInt().toString() } ?: "--"
            DigitalV2GaugeMode.Rpm -> speedKmh?.toString() ?: "--"
        }
        val centerUnit = if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h"
        val textShadow = Shadow(Color.Black.copy(alpha = .70f), Offset(0f, if (preview) 1f else 2f), if (preview) 3f else 7f)

        Column(
            modifier = Modifier.align(Alignment.Center).offset(y = maxHeight * 0.075f),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                centerValue,
                color = Color.White,
                fontSize = if (preview) 34.sp else 72.sp,
                fontWeight = FontWeight.Black,
                lineHeight = if (preview) 34.sp else 72.sp,
                style = TextStyle(shadow = textShadow)
            )
            Text(
                centerUnit,
                color = Color.White.copy(alpha = .96f),
                fontSize = if (preview) 9.5.sp else 16.sp,
                fontWeight = FontWeight.Black,
                style = TextStyle(shadow = textShadow)
            )
        }
    }
}

@Composable
private fun DigitalV2Vehicle(
    settings: LoganSettings,
    speedKmh: Int,
    motionEnabled: Boolean,
    width: Dp,
    modifier: Modifier = Modifier
) {
    val density = LocalDensity.current
    val verticalPx = with(density) { 1.45.dp.toPx() }
    val horizontalPx = with(density) { 0.55.dp.toPx() }
    val movingFactor = if (motionEnabled) (speedKmh / 55f).coerceIn(0f, 1f) else 0f
    val transition = rememberInfiniteTransition(label = "digitalV2VehicleMotion")
    val verticalWave by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(920), RepeatMode.Reverse),
        label = "digitalV2VehicleVertical"
    )
    val lateralWave by transition.animateFloat(
        initialValue = -1f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1370), RepeatMode.Reverse),
        label = "digitalV2VehicleLateral"
    )
    Box(modifier = modifier.width(width), contentAlignment = Alignment.BottomCenter) {
        Canvas(
            modifier = Modifier
                .fillMaxWidth(.82f)
                .height(width * .16f)
                .align(Alignment.BottomCenter)
                .offset(y = width * .006f)
        ) {
            drawOval(
                brush = Brush.radialGradient(
                    listOf(Color.Black.copy(alpha = .52f), Color.Black.copy(alpha = .19f), Color.Transparent)
                )
            )
        }
        Image(
            painter = painterResource(
                vehicleVisualDrawableRes(
                    settings.vehicleVisualModel,
                    settings.vehicleColor,
                    VehicleAssetStyle.Detailed
                )
            ),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxWidth()
                .graphicsLayer {
                    translationY = verticalWave * verticalPx * movingFactor
                    translationX = lateralWave * horizontalPx * movingFactor
                    rotationZ = lateralWave * .16f * movingFactor
                    transformOrigin = TransformOrigin(0.5f, 0.90f)
                }
        )
    }
}

@Composable
private fun DigitalV2RoadMotion(speedKmh: Int, enabled: Boolean, modifier: Modifier = Modifier) {
    val active = enabled && speedKmh > 2
    val duration = (1550 - speedKmh.coerceIn(0, 130) * 8).coerceIn(390, 1550)
    val transition = rememberInfiniteTransition(label = "digitalV2RoadMotion")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(duration, easing = LinearEasing), RepeatMode.Restart),
        label = "digitalV2RoadPhase"
    )
    Canvas(modifier) {
        val p0 = Offset(size.width * .625f, size.height * .565f)
        val p1 = Offset(size.width * .735f, size.height * .625f)
        val p2 = Offset(size.width * .405f, size.height * .785f)
        val p3 = Offset(size.width * -.035f, size.height * 1.025f)

        fun point(t: Float): Offset {
            val u = 1f - t
            val uu = u * u
            val tt = t * t
            return Offset(
                uu * u * p0.x + 3f * uu * t * p1.x + 3f * u * tt * p2.x + tt * t * p3.x,
                uu * u * p0.y + 3f * uu * t * p1.y + 3f * u * tt * p2.y + tt * t * p3.y
            )
        }
        fun tangent(t: Float): Offset {
            val u = 1f - t
            val x = 3f * u * u * (p1.x - p0.x) + 6f * u * t * (p2.x - p1.x) + 3f * t * t * (p3.x - p2.x)
            val y = 3f * u * u * (p1.y - p0.y) + 6f * u * t * (p2.y - p1.y) + 3f * t * t * (p3.y - p2.y)
            val len = kotlin.math.sqrt(x * x + y * y).coerceAtLeast(.001f)
            return Offset(x / len, y / len)
        }

        val roadMask = Path().apply {
            moveTo(size.width * .53f, size.height * .55f)
            cubicTo(size.width * .76f, size.height * .62f, size.width * .88f, size.height * .78f, size.width * .86f, size.height)
            lineTo(size.width * -.08f, size.height)
            cubicTo(size.width * .18f, size.height * .78f, size.width * .42f, size.height * .63f, size.width * .53f, size.height * .55f)
            close()
        }

        clipPath(roadMask) {
            // Static lane markings in the photo are covered by a narrow asphalt repair strip.
            // Animated markings are then drawn on the exact same curved route.
            var previous = point(0f)
            for (i in 1..44) {
                val t = i / 44f
                val current = point(t)
                drawLine(
                    color = Color(0xFF686D70).copy(alpha = .72f),
                    start = previous,
                    end = current,
                    strokeWidth = size.width * (.0055f + .016f * t * t),
                    cap = StrokeCap.Round
                )
                previous = current
            }

            val effectivePhase = if (active) phase else 0f
            repeat(8) { index ->
                val raw = ((index / 8f + effectivePhase) % 1f)
                val t = .04f + .96f * raw * raw
                val center = point(t)
                val dir = tangent(t)
                val dashLength = size.height * (.009f + .048f * t * t)
                val dashWidth = size.width * (.0032f + .0105f * t * t)
                val half = dashLength * .5f
                val start = Offset(center.x - dir.x * half, center.y - dir.y * half)
                val end = Offset(center.x + dir.x * half, center.y + dir.y * half)
                drawLine(
                    color = Color(0xFFFFD44D).copy(alpha = .52f + .42f * t),
                    start = start,
                    end = end,
                    strokeWidth = dashWidth,
                    cap = StrokeCap.Round
                )
                drawLine(
                    color = Color(0xFFFFF0A0).copy(alpha = .20f + .28f * t),
                    start = start,
                    end = end,
                    strokeWidth = dashWidth * .34f,
                    cap = StrokeCap.Round
                )
            }
        }
    }
}

@Composable
private fun DigitalV2WindOverlay(speedKmh: Int, enabled: Boolean, modifier: Modifier = Modifier) {
    val strength = if (enabled) ((speedKmh - 10) / 65f).coerceIn(0f, 1f) else 0f
    val duration = (1450 - speedKmh.coerceIn(0, 130) * 7).coerceIn(430, 1450)
    val transition = rememberInfiniteTransition(label = "digitalV2Wind")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(duration, easing = LinearEasing), RepeatMode.Restart),
        label = "digitalV2WindPhase"
    )
    Canvas(modifier) {
        if (strength <= 0f) return@Canvas
        repeat(12) { index ->
            val side = if (index % 2 == 0) -1f else 1f
            val lane = index % 6
            val p = ((index * .117f + phase) % 1f)
            val y = size.height * (.20f + .52f * p)
            val jitter = sin(p.toDouble() * 2.0 * PI + index.toDouble()).toFloat() * size.height * .006f
            val baseX = if (side < 0) size.width * (.05f + lane * .028f) else size.width * (.95f - lane * .028f)
            val len = size.width * (.08f + .14f * p) * (0.75f + strength * .35f)
            val endY = y + size.height * (.018f + .014f * p) + jitter
            val start = Offset(baseX, y)
            val end = Offset(baseX + side * len, endY)
            drawLine(Color.White.copy(alpha = strength * (.020f + .030f * p)), start, end, size.width * (.007f + .004f * p), StrokeCap.Round)
            drawLine(Color.White.copy(alpha = strength * (.055f + .075f * p)), start, end, size.width * (.0035f + .0025f * p), StrokeCap.Round)
            drawLine(Color.White.copy(alpha = strength * (.10f + .13f * p)), start, end, size.width * (.0012f + .0013f * p), StrokeCap.Round)
        }
    }
}

@Composable
private fun DigitalV2DataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(
                Brush.verticalGradient(
                    listOf(DigitalV2Glass, Color(0xFFF0F3F7), Color(0xFFE3E8EF))
                )
            )
            .border(1.dp, Color.White.copy(alpha = .82f), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth().weight(1.12f), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2MetricCard(palette, trLabel(tr, "Hararet", "Coolant"), snapshot.engineTempC?.toString() ?: "--", "°C", CardIcon.Temperature, Modifier.weight(1f), compact = true, accent = if ((snapshot.engineTempC ?: 0) >= 100) palette.critical else DigitalV2Red)
            DigitalV2MetricCard(palette, trLabel(tr, "Klima", "A/C"), snapshot.acOn?.let { if (it) "A/C" else trLabel(tr, "Kapalı", "Off") } ?: "--", snapshot.acOn?.let { if (it) "ON" else null }, CardIcon.Ac, Modifier.weight(1f), compact = true, accent = DigitalV2Blue)
            DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Süresi", "Trip Time"), snapshot.tripDurationText ?: "--:--", null, CardIcon.Time, Modifier.weight(1f), compact = true)
            DigitalV2MetricCard(palette, trLabel(tr, "Kullanılan Yakıt", "Fuel Used"), format1(snapshot.fuelUsedL), "L", CardIcon.FuelCalculation, Modifier.weight(1f), compact = true)
        }
    }
}

@Composable
private fun DigitalV2CompactDataPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    snapshot: DashboardSnapshot,
    tr: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(Color(0xFFE7ECF2))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        DigitalV2MetricCard(palette, trLabel(tr, "Ortalama Tüketim", "Average Consumption"), format1(snapshot.averageConsumption), "L/100 km", CardIcon.FuelAverage, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Anlık Tüketim", "Instant Consumption"), format1(snapshot.instantConsumption), snapshot.instantUnit, CardIcon.FuelInstant, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Mesafe", "Distance"), format1(snapshot.tripDistanceKm), "km", CardIcon.Distance, Modifier.weight(1f))
        DigitalV2MetricCard(palette, trLabel(tr, "Sürüş Maliyeti", "Trip Cost"), snapshot.tripCostText ?: "--", if (snapshot.tripCostText == null) "₺" else null, CardIcon.Cost, Modifier.weight(1f))
    }
}

@Composable
private fun DigitalV2MetricCard(
    palette: LoganPalette,
    title: String,
    value: String,
    unit: String?,
    icon: CardIcon,
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    accent: Color = DigitalV2Blue
) {
    if (compact) {
        Column(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(16.dp))
                .padding(horizontal = 5.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                title.uppercase(),
                color = Color(0xFF596778),
                fontSize = 8.8.sp,
                lineHeight = 9.4.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                textAlign = TextAlign.Center,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(3.dp))
            Box(
                modifier = Modifier
                    .size(29.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(4.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Spacer(Modifier.height(2.dp))
            Text(
                value,
                color = Color(0xFF172235),
                fontSize = 19.sp,
                lineHeight = 19.sp,
                fontWeight = FontWeight.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (!unit.isNullOrBlank()) {
                Text(unit, color = Color(0xFF596778), fontSize = 9.sp, lineHeight = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
        }
    } else {
        Row(
            modifier = modifier
                .fillMaxHeight()
                .clip(RoundedCornerShape(20.dp))
                .background(Color.White.copy(alpha = .80f))
                .border(1.dp, Color.White.copy(alpha = .92f), RoundedCornerShape(20.dp))
                .padding(horizontal = 11.dp, vertical = 7.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = .76f))
                    .padding(6.dp),
                contentAlignment = Alignment.Center
            ) {
                MetricIcon(palette, icon, tint = accent)
            }
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title.uppercase(), color = Color(0xFF596778), fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(value, color = Color(0xFF172235), fontSize = 26.sp, lineHeight = 27.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (!unit.isNullOrBlank()) {
                        Spacer(Modifier.width(4.dp))
                        Text(unit, color = Color(0xFF596778), fontSize = 10.5.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 3.dp), maxLines = 1)
                    }
                }
            }
        }
    }
}

@Composable
fun DigitalV2SettingsPanel(
    palette: LoganPalette,
    settings: LoganSettings,
    onSettingsChange: (LoganSettings) -> Unit,
    modifier: Modifier = Modifier
) {
    val tr = settings.language != AppLanguage.English
    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Dijital V2", color = palette.accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(
            trLabel(tr, "Dağ-Göl ilk aktif sahnedir. Diğer sahneler hazırlandıkça açılacaktır.", "Mountain-Lake is the first active scene. Other scenes will unlock when completed."),
            color = palette.textSecondary,
            fontSize = 12.5.sp
        )
        DigitalV2MiniPreview(
            settings = settings,
            mode = settings.digitalV2GaugeMode,
            modifier = Modifier.fillMaxWidth().height(184.dp)
        )
        Text(trLabel(tr, "Kadran Türü", "Gauge Type"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Speed,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Speed,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Speed)) }
            )
            DigitalV2ModeTile(
                palette = palette,
                settings = settings,
                mode = DigitalV2GaugeMode.Rpm,
                selected = settings.digitalV2GaugeMode == DigitalV2GaugeMode.Rpm,
                modifier = Modifier.weight(1f),
                onClick = { onSettingsChange(settings.copy(digitalV2GaugeMode = DigitalV2GaugeMode.Rpm)) }
            )
        }
        Text(trLabel(tr, "Arka Plan Sahnesi", "Background Scene"), color = palette.textPrimary, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.take(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            DigitalV2Scene.entries.drop(2).forEach { scene ->
                DigitalV2SceneTile(palette, settings, scene, Modifier.weight(1f)) {
                    if (scene.available) onSettingsChange(settings.copy(digitalV2Scene = scene))
                }
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(palette.surfaceVariant.copy(alpha = .72f))
                .border(1.dp, palette.line, RoundedCornerShape(16.dp))
                .clickable { onSettingsChange(settings.copy(digitalV2MotionEnabled = !settings.digitalV2MotionEnabled)) }
                .padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(trLabel(tr, "Hareket efektleri", "Motion effects"), color = palette.textPrimary, fontWeight = FontWeight.Black, fontSize = 13.sp)
                Text(trLabel(tr, "Şerit akışı, hafif rüzgâr ve araç mikro sallantısı", "Lane flow, light wind and subtle vehicle movement"), color = palette.textSecondary, fontSize = 10.sp)
            }
            Switch(
                checked = settings.digitalV2MotionEnabled,
                onCheckedChange = { onSettingsChange(settings.copy(digitalV2MotionEnabled = it)) }
            )
        }
    }
}

@Composable
private fun DigitalV2MiniPreview(settings: LoganSettings, mode: DigitalV2GaugeMode, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .border(2.dp, DigitalV2Blue.copy(alpha = .70f), RoundedCornerShape(20.dp))
    ) {
        Image(
            painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0x50062A51), Color.Transparent, Color(0x79061018)))))
        DigitalV2Gauge(mode, 78, 2400, Modifier.align(Alignment.TopCenter).fillMaxWidth(.88f).fillMaxHeight(.90f), preview = true)
        Image(
            painter = painterResource(vehicleVisualDrawableRes(settings.vehicleVisualModel, settings.vehicleColor, VehicleAssetStyle.Detailed)),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(.20f).padding(bottom = 5.dp)
        )
        Text("DAĞ-GÖL • AKTİF", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopStart).padding(8.dp))
    }
}

@Composable
private fun DigitalV2GaugeThumbnail(
    mode: DigitalV2GaugeMode,
    modifier: Modifier = Modifier
) {
    BoxWithConstraints(modifier = modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val radius = size.minDimension * .47f
            val center = Offset(size.width / 2f, size.height * .68f)
            val start = 150f
            val sweep = 240f
            drawArc(
                color = Color.White.copy(alpha = .90f),
                startAngle = start,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = Offset(center.x - radius, center.y - radius),
                size = Size(radius * 2f, radius * 2f),
                style = Stroke(radius * .022f, cap = StrokeCap.Round)
            )
            repeat(9) { i ->
                val f = i / 8f
                val a = Math.toRadians((start + sweep * f).toDouble())
                val p1 = Offset(center.x + cos(a).toFloat() * radius * .84f, center.y + sin(a).toFloat() * radius * .84f)
                val p2 = Offset(center.x + cos(a).toFloat() * radius, center.y + sin(a).toFloat() * radius)
                drawLine(Color.White.copy(alpha = .90f), p1, p2, radius * .016f, StrokeCap.Round)
            }
            val progress = if (mode == DigitalV2GaugeMode.Speed) 78f / 200f else 2400f / 7000f
            val needleAngle = Math.toRadians((start + sweep * progress).toDouble())
            drawLine(
                Color.White,
                center,
                Offset(center.x + cos(needleAngle).toFloat() * radius * .76f, center.y + sin(needleAngle).toFloat() * radius * .76f),
                radius * .020f,
                StrokeCap.Round
            )
        }
        Column(modifier = Modifier.align(Alignment.Center).offset(y = maxHeight * .14f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(if (mode == DigitalV2GaugeMode.Speed) "24" else "78", color = Color.White, fontSize = 31.sp, lineHeight = 31.sp, fontWeight = FontWeight.Black)
            Text(if (mode == DigitalV2GaugeMode.Speed) "x100 rpm" else "km/h", color = Color.White.copy(alpha = .94f), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DigitalV2ModeTile(
    palette: LoganPalette,
    settings: LoganSettings,
    mode: DigitalV2GaugeMode,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) DigitalV2Blue.copy(alpha = .10f) else palette.surfaceVariant.copy(alpha = .62f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(82.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF1B5D91))
        ) {
            DigitalV2GaugeThumbnail(mode, Modifier.fillMaxSize())
        }
        Spacer(Modifier.height(6.dp))
        Text(if (tr) mode.trLabel else mode.enLabel, color = if (selected) DigitalV2Blue else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black)
        Text(
            if (mode == DigitalV2GaugeMode.Speed) trLabel(tr, "Ortada devir", "RPM in center") else trLabel(tr, "Ortada hız", "Speed in center"),
            color = palette.textSecondary,
            fontSize = 10.5.sp
        )
    }
}

@Composable
private fun DigitalV2SceneTile(
    palette: LoganPalette,
    settings: LoganSettings,
    scene: DigitalV2Scene,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val tr = settings.language != AppLanguage.English
    val selected = settings.digitalV2Scene == scene && scene.available
    Box(
        modifier = modifier
            .height(72.dp)
            .clip(RoundedCornerShape(15.dp))
            .background(if (scene.available) Color(0xFF4C86AD) else palette.surfaceVariant.copy(alpha = .80f))
            .border(if (selected) 2.dp else 1.dp, if (selected) DigitalV2Blue else palette.line, RoundedCornerShape(15.dp))
            .clickable(enabled = scene.available, onClick = onClick)
    ) {
        if (scene == DigitalV2Scene.MountainLake) {
            Image(
                painter = painterResource(R.drawable.digital_v2_mountain_lake_bg),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = .20f)))
        }
        Text(if (tr) scene.trLabel else scene.enLabel, color = if (scene.available) Color.White else palette.textPrimary, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.BottomStart).padding(8.dp))
        Text(
            if (scene.available) trLabel(tr, "Aktif", "Active") else trLabel(tr, "Pasif", "Inactive"),
            color = if (scene.available) Color.White else palette.textSecondary,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Black,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(6.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color.Black.copy(alpha = if (scene.available) .35f else .08f))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        )
    }
}

private fun trLabel(tr: Boolean, trValue: String, enValue: String): String = if (tr) trValue else enValue

private fun format1(value: Double?): String = value?.takeIf { it.isFinite() }?.let {
    String.format(Locale.US, "%.1f", it)
} ?: "--"
