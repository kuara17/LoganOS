package com.dcui.loganos.ui.cockpit.opengl

import kotlin.math.abs
import kotlin.math.sqrt

private fun requireGeometry(condition: Boolean, message: String) {
    check(condition) { message }
}

private fun distance(a: NormalizedPoint, b: NormalizedPoint): Float {
    val dx = (b.x - a.x) * DIGITAL_V2_LOGICAL_WIDTH
    val dy = (b.y - a.y) * DIGITAL_V2_LOGICAL_HEIGHT
    return sqrt(dx * dx + dy * dy)
}

private fun closestDistanceForY(curve: CalibratedCurve, targetY: Float): Float {
    var bestDistance = 0f
    var bestError = Float.POSITIVE_INFINITY
    var d = 0f
    while (d <= curve.maxDistanceMeters) {
        val error = abs(curve.sample(d).y - targetY)
        if (error < bestError) {
            bestError = error
            bestDistance = d
        }
        d += 0.1f
    }
    return bestDistance
}

fun main() {
    listOf(1080 to 1320, 720 to 1600, 1846 to 852, 320 to 184).forEach { (width, height) ->
        val viewport = calculateDigitalV2Viewport(width, height)
        val aspect = viewport.width.toFloat() / viewport.height.toFloat()
        requireGeometry(
            abs(aspect - DIGITAL_V2_STAGE_ASPECT_RATIO) < 0.005f,
            "Viewport $width x $height stretches the logical stage"
        )
        requireGeometry(viewport.x >= 0 && viewport.y >= 0, "Viewport offset is negative")
        requireGeometry(viewport.x + viewport.width <= width, "Viewport exceeds surface width")
        requireGeometry(viewport.y + viewport.height <= height, "Viewport exceeds surface height")
    }
    println("[PASS] viewport: fixed 1080x1320 stage fits phone, Double and preview surfaces")

    val scenes = listOf(
        DigitalV2SceneModels.MountainLake,
        DigitalV2SceneModels.CityDay,
        DigitalV2SceneModels.CityNight,
        DigitalV2SceneModels.SnowRoad
    )

    scenes.forEach { scene ->
        val road = scene.road

        requireGeometry(
            road.visibility.centerNearFadeStartMeters >= 10f &&
                road.visibility.centerNearFadeEndMeters >= 18f &&
                road.visibility.centerNearFadeEndMeters < road.visibility.centerFadeStartMeters,
            "${scene.key}: divider can remain visible under the follow-camera vehicle"
        )
        requireGeometry(
            road.visibility.centerFadeStartMeters < road.visibility.centerFadeEndMeters &&
                road.visibility.centerFadeEndMeters <= road.maxDistanceMeters,
            "${scene.key}: invalid centre-line visibility window"
        )
        requireGeometry(
            road.visibility.edgeFadeStartMeters < road.visibility.edgeFadeEndMeters &&
                road.visibility.edgeFadeEndMeters <= road.maxDistanceMeters,
            "${scene.key}: invalid edge-line visibility window"
        )
        val nearLeft = road.leftRoadEdge.sample(0f)
        val nearRight = road.rightRoadEdge.sample(0f)
        requireGeometry(nearLeft.x <= 0.08f && nearRight.x >= 0.92f,
            "${scene.key}: continuous edge lines are not placed at photographed road sides")
        listOf(road.centerLine, road.leftRoadEdge, road.rightRoadEdge).forEach { curve ->
            curve.points.forEach { control ->
                val sampled = curve.sample(control.distanceMeters)
                requireGeometry(
                    abs(sampled.x - control.xRatio) < 0.0001f &&
                        abs(sampled.y - control.yRatio) < 0.0001f,
                    "${scene.key}: calibrated curve misses a measured control point"
                )
            }
        }
        var previousY = Float.POSITIVE_INFINITY
        var previousRoadWidth = Float.POSITIVE_INFINITY
        var previousTangentAngle = Float.NaN
        var d = 0f
        while (d <= road.maxDistanceMeters) {
            val center = road.centerLine.sample(d)
            val left = road.leftRoadEdge.sample(d)
            val right = road.rightRoadEdge.sample(d)
            requireGeometry(center.y < previousY || d == 0f, "${scene.key}: centre curve reverses toward camera at ${d}m")
            requireGeometry(left.x < center.x, "${scene.key}: centre line crosses left edge at ${d}m")
            requireGeometry(center.x < right.x, "${scene.key}: centre line crosses right edge at ${d}m")
            val width = distance(left, right)
            requireGeometry(width <= previousRoadWidth + 1.5f || d == 0f, "${scene.key}: road width grows again at ${d}m")
            previousRoadWidth = width
            previousY = center.y

            val tangent = road.centerLine.tangent(d)
            val angle = kotlin.math.atan2(tangent.y, tangent.x)
            if (previousTangentAngle.isFinite()) {
                requireGeometry(abs(angle - previousTangentAngle) < 0.18f, "${scene.key}: centre tangent jumps at ${d}m")
            }
            previousTangentAngle = angle
            d += 0.5f
        }

        val pattern = road.markings
        requireGeometry(abs(pattern.dashLengthMeters - 3f) < 0.001f, "${scene.key}: dash length changed")
        requireGeometry(abs(pattern.gapLengthMeters - 6f) < 0.001f, "${scene.key}: gap length changed")
        requireGeometry(abs(pattern.repeatLengthMeters - 9f) < 0.001f, "${scene.key}: repeat length must be 9m")
        requireGeometry(road.showLeftEdgeLine && road.showRightEdgeLine, "${scene.key}: calibrated edge lines are disabled")

        var previousDashLength = Float.POSITIVE_INFINITY
        var dashStart = 0f
        while (dashStart + pattern.dashLengthMeters <= 96f) {
            val near = road.centerLine.sample(dashStart)
            val far = road.centerLine.sample(dashStart + pattern.dashLengthMeters)
            val dashPixels = distance(near, far)
            requireGeometry(dashPixels <= previousDashLength + 0.8f, "${scene.key}: projected 3m dash grows again at ${dashStart}m")
            requireGeometry(dashPixels >= 1.2f, "${scene.key}: far dash becomes unstable")
            previousDashLength = dashPixels
            dashStart += pattern.repeatLengthMeters
        }

        val pose = scene.vehiclePose
        requireGeometry(abs(pose.centerXRatio - 0.5f) < 0.015f, "${scene.key}: vehicle is not centred")
        val expectedContactRange = if (scene.key == DigitalV2SceneKey.CityDay) 0.91f..0.94f else 0.84f..0.88f
        val expectedWidthRange = if (scene.key == DigitalV2SceneKey.CityDay) 0.420f..0.440f else 0.315f..0.335f
        requireGeometry(pose.tireContactYRatio in expectedContactRange, "${scene.key}: tyre contact Y is not grounded")
        requireGeometry(pose.visibleWidthRatio in expectedWidthRange, "${scene.key}: vehicle does not fill the accepted scene area")
        val vehicleDistance = closestDistanceForY(road.centerLine, pose.tireContactYRatio)
        val leftAtVehicle = road.leftRoadEdge.sample(vehicleDistance)
        val rightAtVehicle = road.rightRoadEdge.sample(vehicleDistance)
        val halfVisible = pose.visibleWidthRatio * 0.5f
        requireGeometry(pose.centerXRatio - halfVisible > leftAtVehicle.x, "${scene.key}: vehicle body crosses left asphalt edge")
        requireGeometry(pose.centerXRatio + halfVisible < rightAtVehicle.x, "${scene.key}: vehicle body crosses right asphalt edge")
        val logan3 = VehicleAssetProfile(
            textureAspectHeightOverWidth = 914f / 1014f,
            visibleLeftRatioInTexture = 57f / 1014f,
            visibleRightRatioInTexture = 958f / 1014f,
            leftTireContactXRatioInTexture = 0.164f,
            rightTireContactXRatioInTexture = 0.836f,
            contactYRatioInTexture = 828f / 914f,
            visibleBottomRatioInTexture = 0.928f
        )
        val fullVehicleWidth = pose.visibleWidthRatio / logan3.visibleWidthRatioInTexture
        val leftTireX = pose.centerXRatio +
            (logan3.leftTireContactXRatioInTexture - 0.5f) * fullVehicleWidth
        val rightTireX = pose.centerXRatio +
            (logan3.rightTireContactXRatioInTexture - 0.5f) * fullVehicleWidth
        requireGeometry(leftTireX > leftAtVehicle.x, "${scene.key}: left tyre contact leaves asphalt")
        requireGeometry(rightTireX < rightAtVehicle.x, "${scene.key}: right tyre contact leaves asphalt")

        val centerMesh = buildCalibratedLineMesh(road, RoadCurveRole.CenterLine, pattern.centerLineWidthMeters)
        val leftMesh = buildCalibratedLineMesh(road, RoadCurveRole.LeftEdge, pattern.edgeLineWidthMeters)
        val rightMesh = buildCalibratedLineMesh(road, RoadCurveRole.RightEdge, pattern.edgeLineWidthMeters)
        val surfaceMesh = buildCalibratedRoadSurfaceMesh(road)
        listOf(centerMesh, leftMesh, rightMesh, surfaceMesh).forEach { mesh ->
            requireGeometry(mesh.vertices.all { it.isFinite() }, "${scene.key}: mesh contains non-finite values")
            requireGeometry(mesh.vertices.filterIndexed { index, _ -> index % 4 < 2 }.all { it in -1.25f..1.25f }, "${scene.key}: mesh escapes calibrated stage")
            var lastDistance = -1f
            for (index in 0 until mesh.vertexCount step 2) {
                val leftBase = index * 4
                val rightBase = (index + 1) * 4
                val leftDistance = mesh.vertices[leftBase + 2]
                val rightDistance = mesh.vertices[rightBase + 2]
                requireGeometry(abs(leftDistance - rightDistance) < 0.0001f, "${scene.key}: ribbon pair distances differ")
                requireGeometry(leftDistance >= lastDistance, "${scene.key}: ribbon distance goes backwards")
                lastDistance = leftDistance
            }
        }

        val leftWind = buildCalibratedWindZoneMesh(road, scene.wind, RoadSide.Left)
        val rightWind = buildCalibratedWindZoneMesh(road, scene.wind, RoadSide.Right)
        requireGeometry(leftWind.vertices.all { it.isFinite() } && rightWind.vertices.all { it.isFinite() }, "${scene.key}: wind mesh invalid")
        fun assertWindOutside(mesh: RoadRibbonMeshData, side: RoadSide) {
            for (index in 0 until mesh.vertexCount step 2) {
                val base = index * 4
                val distanceMeters = mesh.vertices[base + 2]
                val left = road.leftRoadEdge.sample(distanceMeters)
                val right = road.rightRoadEdge.sample(distanceMeters)
                val centerX = (left.x + right.x) * 0.5f
                val centerY = (left.y + right.y) * 0.5f
                val edge = if (side == RoadSide.Left) left else right
                val outwardX = edge.x - centerX
                val outwardY = edge.y - centerY
                for (vertexOffset in 0..1) {
                    val vertexBase = (index + vertexOffset) * 4
                    val x = (mesh.vertices[vertexBase] + 1f) * 0.5f
                    val y = (1f - mesh.vertices[vertexBase + 1]) * 0.5f
                    val fromEdgeX = x - edge.x
                    val fromEdgeY = y - edge.y
                    val outwardDot = fromEdgeX * outwardX + fromEdgeY * outwardY
                    requireGeometry(outwardDot > 0f, "${scene.key}: ${side} wind crosses onto asphalt")
                }
            }
        }
        assertWindOutside(leftWind, RoadSide.Left)
        assertWindOutside(rightWind, RoadSide.Right)
        println("[PASS] ${scene.key}: calibrated curves, 3m/6m flow, centred vehicle, grounded tyres and off-road wind meshes")
    }

    requireGeometry(
        DigitalV2SceneModels.MountainLake.road.visibility.centerFadeEndMeters <= 70f,
        "Mountain divider remains visible around the hidden bend"
    )
    requireGeometry(
        DigitalV2SceneModels.SnowRoad.road.visibility.centerFadeEndMeters <= 72f,
        "Snow divider remains visible around the hidden bend"
    )
    requireGeometry(
        DigitalV2SceneModels.CityDay.road.visibility.centerFadeEndMeters >= 110f &&
            DigitalV2SceneModels.CityNight.road.visibility.centerFadeEndMeters >= 110f,
        "Straight city roads fade centre markings too early"
    )

    val mountain = DigitalV2SceneModels.MountainLake.road.centerLine
    requireGeometry(abs(mountain.sample(0f).x - mountain.sample(120f).x) > 0.25f, "Mountain road remains a straight generic template")
    val cityDay = DigitalV2SceneModels.CityDay.road
    val cityNight = DigitalV2SceneModels.CityNight.road
    requireGeometry(cityDay !== cityNight, "City day/night still share one road calibration")
    requireGeometry(cityDay.centerLine.points != cityNight.centerLine.points, "City day/night calibration points are identical")
    requireGeometry(
        DigitalV2SceneModels.CityNight.vehiclePose.colorGrade.exposure <
            DigitalV2SceneModels.CityDay.vehiclePose.colorGrade.exposure,
        "Night scene does not darken the vehicle"
    )
    requireGeometry(
        DigitalV2SceneModels.SnowRoad.vehiclePose.colorGrade.blueMultiplier > 1f,
        "Snow scene does not apply cold ambient vehicle grading"
    )
    requireGeometry(
        DigitalV2SceneModels.CityNight.vehiclePose.colorGrade.upperBlueMultiplier >
            DigitalV2SceneModels.CityNight.vehiclePose.colorGrade.upperRedMultiplier,
        "Night scene lacks directional cool ambient light"
    )
    requireGeometry(
        DigitalV2SceneModels.SnowRoad.vehiclePose.colorGrade.lowerBlueMultiplier > 1f,
        "Snow scene lacks road-reflected lower-body light"
    )

    val stoppedSpeed = nextDigitalV2SmoothedSpeedKmh(108f, 0f, 0.016f)
    requireGeometry(stoppedSpeed == 0f, "Stopped WHEN_DIRTY state preserves stale smoothed speed")
    val restartSpeed = nextDigitalV2SmoothedSpeedKmh(stoppedSpeed, 8f, 0.016f)
    requireGeometry(restartSpeed in 0f..2f, "Low-speed restart begins with excessive visual speed")

    val formerBoundaryBefore = roadPatternPhaseMeters(9_999.99, 9f)
    val formerBoundaryAfter = roadPatternPhaseMeters(10_000.01, 9f)
    val roadForwardDelta = positiveModulo((formerBoundaryAfter - formerBoundaryBefore).toDouble(), 9.0)
    requireGeometry(abs(roadForwardDelta - 0.02) < 0.0005, "Road phase jumps at former 10,000m boundary")
    println("[PASS] animation: idle reset and phase continuity")
}
