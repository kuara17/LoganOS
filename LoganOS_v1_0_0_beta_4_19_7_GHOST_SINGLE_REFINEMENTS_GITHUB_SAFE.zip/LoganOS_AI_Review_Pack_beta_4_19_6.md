# LoganOS AI Review Pack — beta.4.19.6

## Scope
This release changes only the isolated **Ghost Single Original** cockpit, its dedicated assets, validation scripts and app version metadata. Existing Ghost Single, Ghost Dual, portrait layouts, OBD decoding, trip logic and vehicle data policy are not changed.

## Intended visual behaviour
- Centre gauge keeps a near-circular reference composition and is no longer vertically compressed by a full-screen `FillBounds` asset.
- Static gauge numerals are `0, 20, 40, …, 200` km/h.
- Speed and RPM remain live Compose text.
- The road has exactly two continuous outer borders, no middle lane marks and no `RoadMotionLayer`.
- The road, vehicle, shadows and gauge share one `1000×760` coordinate system.
- The horizon is a thin strip centred on the road vanishing point.
- Left zone: vertical coolant visual, numeric coolant temperature, enlarged instant consumption and unit.
- Right zone: enlarged average consumption, unit and vertical visual scale.

## Data policy
Allowed live fields:
- speed,
- RPM,
- instant consumption and its valid unit,
- average consumption,
- engine coolant temperature,
- OBD/demo state.

Forbidden/absent fields:
- fuel level,
- range,
- gear,
- outside temperature,
- speed-limit recognition,
- drive mode,
- ECO/ADAS information.

## Important files
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt`
- `app/src/main/res/drawable-nodpi/ghost_single_original_gauge_shell.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_base.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_edges.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_road_sheen.webp`
- `app/src/main/res/drawable-nodpi/ghost_single_original_horizon_*.webp`
- `tools/render_ghost_single_original_assets.py`
- `tools/validate_ghost_single_original.py`

## Review checklist
1. Confirm the centre gauge remains circular on the 1846×702 cockpit content area.
2. Confirm the road is narrow and single-lane, with no centre dashes.
3. Confirm the road does not extend past the intended central gauge composition.
4. Confirm coolant is on the left and `59 °C`-style numeric text is visible.
5. Confirm instant and average units are not clipped.
6. Confirm the 0–200 scale and live speed progress align.
7. Confirm no unsupported vehicle information appears.
