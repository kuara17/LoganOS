# LoganOS beta.4.19.6 Source Audit

## Base
- Based on `1.0.0-beta.4.19.5`.
- Version bumped to `1.0.0-beta.4.19.6` / versionCode `100000706`.

## Deliberate source changes
- Replaced the full-screen Ghost Original shell layout with a responsive centre cluster that preserves the `1000×760` asset ratio.
- Removed `Animatable`, `RoadMotionLayer`, centre highway dashes and the bottom-centre coolant block.
- Added integrated left/right information zones with live coolant and consumption visuals.
- Retained the existing Logan vehicle selector and trusted-fuel-display checks.

## Deliberate asset changes
- `ghost_single_original_gauge_shell.webp`: `1000×760`, static 0–200 numerals and ticks only.
- Road/shadow assets: `1000×760`, all sharing the gauge reference space.
- Horizon variants: reduced from `1846×300` to thin `1846×180` strips.
- Preview regenerated from packaged assets.

## Road invariants
- `ROAD_TOP_Y = 432`
- `ROAD_BOTTOM_Y = 718`
- `ROAD_TOP_HALF_WIDTH = 34`
- `ROAD_BOTTOM_HALF_WIDTH = 232`
- Two continuous outer boundaries only.
- No centre dashes.
- No moving road-line layer.

## Validation
- `tools/validate_ghost_single_original.py`: passed.
- `tools/validate_release.py`: all static release gates passed.
- Python asset/validator scripts: `py_compile` passed.
- Kotlin source delimiters: balanced; standalone Android/Compose compilation was not available in this container.

## Isolation
A directory comparison against beta.4.19.5 showed changes only in:
- version metadata,
- `GhostSingleOriginalCockpit.kt`,
- dedicated `ghost_single_original_*` assets,
- dedicated asset renderer and validation rules,
- beta.4.19.6 audit/release files.
