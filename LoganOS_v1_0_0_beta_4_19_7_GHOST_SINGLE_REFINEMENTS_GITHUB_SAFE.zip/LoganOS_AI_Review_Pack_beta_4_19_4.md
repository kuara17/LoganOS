# LoganOS AI Review Pack — beta.4.19.4

## Amaç
Ghost Single V2 adı ve önceki deneysel uygulaması yeniden kullanılmadan, mevcut Ghost göstergeleri bozmayan ayrı bir **Ghost Single Original** yatay kokpiti eklemek.

## Mimari kararlar
- Mevcut `GhostSinglePhoneWideCockpit`, `GhostSingleHeadUnitCockpit`, `GhostSinglePortraitCockpit` ve Ghost Dual kaynakları değiştirilmedi.
- Yeni kimlik: `GaugeStyle.GhostSingleOriginal`.
- Yeni composable: `GhostSingleOriginalCockpit.kt`.
- Yeni preference: `ghost_single_original_accent`.
- Bütün yeni drawable dosyaları `ghost_single_original_` önekini kullanır.
- Telefon tarafında yalnız yatay; Double zaten yatay kilitli.
- OpenGL kullanılmadı. Statik katmanlar asset, düz yol kenarı hareketi Compose Canvas ile sınırlı tutuldu.
- Araç için yeni sprite üretilmedi; mevcut Logan I ve Logan III seçim sistemi kullanıldı.

## Katman sırası
1. Koyu arka plan
2. Seçilen ufuk ışığı
3. Koyu yol yüzeyi
4. İki sürekli yol kenarı çizgisi
5. Düşük opaklıklı çizgi parlaması
6. Hızla hareket eden kısa parlak vurgu
7. Yumuşak araç gölgesi
8. Lastik temas gölgesi
9. Mevcut Logan araç asseti
10. Kadran kabuğu
11. Vignette
12. Canlı Compose metinleri

## Ufuk renkleri
- Purple
- Red
- Green
- White
- Blue
- Yellow

Mor, kırmızı, yeşil, beyaz ve mavi maskeler kullanıcının onayladığı Gemini tasarımından ayrıştırılıp checkerboard kalıntıları temizlenerek hazırlandı. Sarı, aynı temizlenmiş geometri ve alfa maskesi korunarak renklendirildi.

## Değişen kaynaklar
- `app/build.gradle.kts`
- `app/src/main/java/com/dcui/loganos/model/Models.kt`
- `app/src/main/java/com/dcui/loganos/data/AppPrefs.kt`
- `app/src/main/java/com/dcui/loganos/MainActivity.kt`
- `app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt`
- `app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt`
- `app/src/main/java/com/dcui/loganos/ui/screens/SetupWizard.kt`
- `app/src/main/java/com/dcui/loganos/ui/components/Gauges.kt`
- `app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt`
- `tools/validate_release.py`
- `tools/validate_ghost_single_original.py`
- `app/src/main/res/drawable-nodpi/ghost_single_original_*`

## Veri güvenliği
Gösterge yalnız mevcut güvenilir alanları kullanır:
- speedKmh
- rpm
- instantConsumption + instantUnit
- averageConsumption
- engineTempC
- connected/demo durumu

Tüketim kaynağı güvenilir değilse değerler `-- / VERİ BEKLENİYOR` olarak gösterilir.

## Kontroller
- `tools/preflight_source.py`: PASS
- `tools/validate_release.py`: PASS
- `tools/validate_ghost_single_original.py`: PASS
- `Models.kt` Kotlin stub derlemesi: PASS
- Eski Ghost dosyalarının baseline ile hash/diff karşılaştırması: değişmedi
- ZIP CRC ve ikinci açma denetimi final paket aşamasında uygulanır

## Bilinen sınır
Bu çalışma ortamında Android SDK ve Gradle wrapper bulunmadığından gerçek `assembleDebug` / `assembleRelease` çalıştırılamadı. GitHub Actions derlemesi gerçek Android/Kotlin derleme doğrulaması olacaktır.

## İnceleme soruları
1. `GhostSingleOriginalCockpit.kt` içindeki Compose API kullanımlarında Kotlin 2.0.21 / Compose BOM 2024.11 ile uyumsuzluk var mı?
2. Dinamik `Animatable` döngüsü hız her değiştiğinde iptal edilip yeniden başlatıldığında demo modunda gözle görülür sıçrama oluşturur mu?
3. 2 GB RAM’li head unit üzerinde 1846×852 WebP katmanlarının bellek kullanımı kabul edilebilir mi?
4. Seçilen Logan sprite ölçeği Logan I ve Logan III için aynı görsel anchor’da yeterince tutarlı mı?
