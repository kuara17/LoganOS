#!/usr/bin/env python3
"""Render Ghost Single Original assets for the Megane-reference layout.

The reference composition is preserved deliberately:
- near-circular 0–200 km/h centre gauge,
- compact single-lane road inside the lower gauge opening,
- thin horizon band,
- no centre lane markings or wide motorway geometry.

Only static artwork is baked into assets. Live speed, RPM, consumption and
coolant values remain Compose layers.
"""
from __future__ import annotations

import math
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res/drawable-nodpi"
STAGE_W, STAGE_H = 1846, 852
GAUGE_W, GAUGE_H = 1000, 760
HORIZON_W, HORIZON_H = 1846, 180
SCALE = 2

SPEED_LABELS = list(range(0, 201, 20))
GAUGE_CENTER = (500, 390)
GAUGE_RADIUS = 350
GAUGE_START_DEG = 165.0
GAUGE_SWEEP_DEG = 210.0

# Compact road geometry copied from the reference composition: a narrow road
# that begins at the horizon and remains inside the centre gauge.
ROAD_TOP_Y = 432
ROAD_BOTTOM_Y = 718
ROAD_TOP_HALF_WIDTH = 34
ROAD_BOTTOM_HALF_WIDTH = 232

FONT_REGULAR = "/usr/share/fonts/opentype/inter/InterDisplay-Regular.otf"
FONT_MEDIUM = "/usr/share/fonts/opentype/inter/InterDisplay-Medium.otf"
if not Path(FONT_REGULAR).exists():
    FONT_REGULAR = "/usr/share/fonts/truetype/lato/Lato-Regular.ttf"
if not Path(FONT_MEDIUM).exists():
    FONT_MEDIUM = "/usr/share/fonts/truetype/lato/Lato-Medium.ttf"


def sc(v: float) -> int:
    return int(round(v * SCALE))


def rgba(size: tuple[int, int]) -> Image.Image:
    return Image.new("RGBA", (size[0] * SCALE, size[1] * SCALE), (0, 0, 0, 0))


def font(size: int, medium: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MEDIUM if medium else FONT_REGULAR, sc(size))


def line(draw: ImageDraw.ImageDraw, points, fill, width=1):
    flat = tuple(sc(v) for point in points for v in point)
    draw.line(flat, fill=fill, width=sc(width), joint="curve")


def point_on_gauge(radius: float, angle_deg: float) -> tuple[float, float]:
    a = math.radians(angle_deg)
    return (
        GAUGE_CENTER[0] + radius * math.cos(a),
        GAUGE_CENTER[1] + radius * math.sin(a),
    )


def render_gauge_shell() -> Image.Image:
    base = rgba((GAUGE_W, GAUGE_H))

    # Very restrained shell glow. The bright colour progress arc stays live.
    glow = rgba((GAUGE_W, GAUGE_H))
    gd = ImageDraw.Draw(glow)
    bbox = (
        sc(GAUGE_CENTER[0] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[0] + GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] + GAUGE_RADIUS),
    )
    gd.arc(
        bbox,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(103, 119, 151, 92),
        width=sc(11),
    )
    base.alpha_composite(glow.filter(ImageFilter.GaussianBlur(sc(7))))

    d = ImageDraw.Draw(base)
    d.arc(
        bbox,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(235, 239, 247, 235),
        width=sc(3),
    )

    inner_radius = GAUGE_RADIUS - 17
    inner_box = (
        sc(GAUGE_CENTER[0] - inner_radius),
        sc(GAUGE_CENTER[1] - inner_radius),
        sc(GAUGE_CENTER[0] + inner_radius),
        sc(GAUGE_CENTER[1] + inner_radius),
    )
    d.arc(
        inner_box,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(115, 127, 151, 145),
        width=sc(1),
    )

    # 0–200 scale: 20 km/h major, 10 km/h medium, 2 km/h minor.
    subdivisions = 100
    for i in range(subdivisions + 1):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * i / subdivisions
        if i % 10 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 7, GAUGE_RADIUS - 36, 4, 245
        elif i % 5 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 8, GAUGE_RADIUS - 28, 3, 215
        else:
            outer, inner, width, alpha = GAUGE_RADIUS - 9, GAUGE_RADIUS - 18, 2, 160
        line(
            d,
            (point_on_gauge(inner, angle), point_on_gauge(outer, angle)),
            (235, 239, 247, alpha),
            width,
        )

    number_font = font(27, medium=True)
    label_radius = GAUGE_RADIUS - 73
    for idx, value in enumerate(SPEED_LABELS):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * idx / (len(SPEED_LABELS) - 1)
        x, y = point_on_gauge(label_radius, angle)
        text = str(value)
        box = d.textbbox((0, 0), text, font=number_font)
        tw, th = box[2] - box[0], box[3] - box[1]
        d.text(
            (sc(x) - tw / 2, sc(y) - th / 2),
            text,
            font=number_font,
            fill=(239, 242, 249, 240),
        )

    # Thin centre separator, matching the reference's restrained OEM layout.
    sep = rgba((GAUGE_W, GAUGE_H))
    sd = ImageDraw.Draw(sep)
    sd.line((sc(356), sc(340), sc(644), sc(340)), fill=(105, 133, 188, 80), width=sc(4))
    base.alpha_composite(sep.filter(ImageFilter.GaussianBlur(sc(6))))
    d = ImageDraw.Draw(base)
    d.line((sc(372), sc(340), sc(628), sc(340)), fill=(128, 143, 174, 110), width=sc(1))

    return base.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def road_polygon_scaled():
    return [
        (sc(GAUGE_W / 2 - ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(GAUGE_W / 2 + ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(GAUGE_W / 2 + ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
        (sc(GAUGE_W / 2 - ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
    ]


def render_road_base() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    mask = Image.new("L", img.size, 0)
    md = ImageDraw.Draw(mask)
    md.polygon(road_polygon_scaled(), fill=235)

    gradient = rgba((GAUGE_W, GAUGE_H))
    gd = ImageDraw.Draw(gradient)
    for y in range(sc(ROAD_TOP_Y), sc(ROAD_BOTTOM_Y) + 1):
        t = (y / SCALE - ROAD_TOP_Y) / (ROAD_BOTTOM_Y - ROAD_TOP_Y)
        shade = int(17 + 16 * t)
        alpha = int(145 + 72 * t)
        gd.line((0, y, GAUGE_W * SCALE, y), fill=(shade, shade + 2, shade + 6, alpha), width=1)
    gradient.putalpha(Image.composite(gradient.getchannel("A"), Image.new("L", img.size, 0), mask))
    img.alpha_composite(gradient)

    # Slight road-centre light, subtle enough not to turn into a trapezoid cap.
    sheen = rgba((GAUGE_W, GAUGE_H))
    sd = ImageDraw.Draw(sheen)
    sd.polygon(road_polygon_scaled(), fill=(85, 91, 110, 28))
    img.alpha_composite(sheen.filter(ImageFilter.GaussianBlur(sc(18))))
    return img.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_road_edges() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    left_top = (GAUGE_W / 2 - ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    right_top = (GAUGE_W / 2 + ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    left_bottom = (GAUGE_W / 2 - ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)
    right_bottom = (GAUGE_W / 2 + ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)

    # Exactly two continuous boundaries: no centre dashes, no motorway lanes.
    line(d, (left_top, left_bottom), (255, 255, 255, 230), 3)
    line(d, (right_top, right_bottom), (255, 255, 255, 230), 3)
    return img.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_road_sheen() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    # Thin light cone beginning at the horizon, constrained inside the road.
    d.polygon(
        [
            (sc(GAUGE_W / 2 - 22), sc(ROAD_TOP_Y + 2)),
            (sc(GAUGE_W / 2 + 22), sc(ROAD_TOP_Y + 2)),
            (sc(GAUGE_W / 2 + 130), sc(ROAD_BOTTOM_Y - 8)),
            (sc(GAUGE_W / 2 - 130), sc(ROAD_BOTTOM_Y - 8)),
        ],
        fill=(255, 255, 255, 72),
    )
    return img.filter(ImageFilter.GaussianBlur(sc(18))).resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_shadow_soft() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    d.ellipse((sc(400), sc(620), sc(600), sc(710)), fill=(0, 0, 0, 150))
    return img.filter(ImageFilter.GaussianBlur(sc(26))).resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_shadow_contact() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    d.ellipse((sc(422), sc(657), sc(578), sc(696)), fill=(0, 0, 0, 195))
    return img.filter(ImageFilter.GaussianBlur(sc(8))).resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_horizon(rgb: tuple[int, int, int]) -> Image.Image:
    img = rgba((HORIZON_W, HORIZON_H))
    glow = rgba((HORIZON_W, HORIZON_H))
    d = ImageDraw.Draw(glow)
    y = HORIZON_H // 2

    # Long but vertically thin glow like the reference cluster.
    d.rectangle((sc(120), sc(y - 5), sc(HORIZON_W - 120), sc(y + 5)), fill=(*rgb, 90))
    d.ellipse((sc(HORIZON_W / 2 - 260), sc(y - 30), sc(HORIZON_W / 2 + 260), sc(y + 30)), fill=(*rgb, 155))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(sc(18))))

    crisp = ImageDraw.Draw(img)
    crisp.line((sc(150), sc(y), sc(HORIZON_W - 150), sc(y)), fill=(*rgb, 135), width=sc(1))
    return img.resize((HORIZON_W, HORIZON_H), Image.Resampling.LANCZOS)


def save_webp(image: Image.Image, name: str, *, lossless: bool = True) -> None:
    path = RES / name
    image.save(path, "WEBP", lossless=lossless, quality=94, method=6)
    print(f"wrote {path.relative_to(ROOT)} {image.size} {path.stat().st_size} bytes")


def fit_rgba(image: Image.Image, box: tuple[int, int]) -> Image.Image:
    copy = image.copy().convert("RGBA")
    copy.thumbnail(box, Image.Resampling.LANCZOS)
    return copy


def draw_centered(draw: ImageDraw.ImageDraw, text: str, x: float, y: float, fnt, fill):
    box = draw.textbbox((0, 0), text, font=fnt)
    draw.text((x - (box[2] - box[0]) / 2, y - (box[3] - box[1]) / 2), text, font=fnt, fill=fill)


def render_preview() -> Image.Image:
    """Settings preview built from the exact packaged assets, not concept art."""
    bg = Image.open(RES / "ghost_single_original_background.webp").convert("RGBA")
    bg = bg.resize((STAGE_W, STAGE_H), Image.Resampling.LANCZOS)

    horizon = Image.open(RES / "ghost_single_original_horizon_purple.webp").convert("RGBA")
    bg.alpha_composite(horizon, (0, 330))

    cluster_w = 980
    cluster_h = round(cluster_w * GAUGE_H / GAUGE_W)
    cluster_x = (STAGE_W - cluster_w) // 2
    cluster_y = 8

    def cluster_asset(name: str, tint: tuple[int, int, int, int] | None = None, alpha_mul: float = 1.0):
        src = Image.open(RES / name).convert("RGBA").resize((cluster_w, cluster_h), Image.Resampling.LANCZOS)
        if tint is None:
            return src
        alpha = src.getchannel("A").point(lambda v: int(v * alpha_mul))
        out = Image.new("RGBA", src.size, tint)
        out.putalpha(alpha)
        return out

    bg.alpha_composite(cluster_asset("ghost_single_original_road_base.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_road_edges.webp", (155, 92, 255, 255), 0.80), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_road_sheen.webp", (155, 92, 255, 255), 0.18), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_shadow_soft.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_shadow_contact.webp"), (cluster_x, cluster_y))

    car = fit_rgba(Image.open(RES / "loganos_logan_rear_cherry_red.webp"), (170, 190))
    bg.alpha_composite(car, ((STAGE_W - car.width) // 2, 514))

    # Static mock progress for preview only.
    progress = Image.new("RGBA", (cluster_w, cluster_h), (0, 0, 0, 0))
    pd = ImageDraw.Draw(progress)
    sx = cluster_w / GAUGE_W
    sy = cluster_h / GAUGE_H
    bbox = (
        (GAUGE_CENTER[0] - GAUGE_RADIUS) * sx,
        (GAUGE_CENTER[1] - GAUGE_RADIUS) * sy,
        (GAUGE_CENTER[0] + GAUGE_RADIUS) * sx,
        (GAUGE_CENTER[1] + GAUGE_RADIUS) * sy,
    )
    pd.arc(bbox, int(GAUGE_START_DEG), int(GAUGE_START_DEG + GAUGE_SWEEP_DEG * 88 / 200), fill=(155, 92, 255, 225), width=5)
    bg.alpha_composite(progress, (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_gauge_shell.webp"), (cluster_x, cluster_y))

    d = ImageDraw.Draw(bg)
    regular = lambda s: ImageFont.truetype(FONT_REGULAR, s)
    medium = lambda s: ImageFont.truetype(FONT_MEDIUM, s)
    draw_centered(d, "88", STAGE_W / 2, 168, regular(72), (247, 249, 255, 255))
    draw_centered(d, "km/h", STAGE_W / 2, 236, medium(20), (183, 193, 208, 255))
    draw_centered(d, "2673 rpm", STAGE_W / 2, 292, medium(25), (235, 239, 247, 225))

    # Open side information zones, matching the reference cluster.
    d.line((95, 430, 395, 430), fill=(86, 101, 130, 100), width=1)
    d.line((STAGE_W - 395, 500, STAGE_W - 95, 500), fill=(86, 101, 130, 100), width=1)

    draw_centered(d, "HARARET", 255, 250, medium(18), (183, 193, 208, 255))
    draw_centered(d, "59 °C", 255, 302, medium(34), (247, 249, 255, 255))
    draw_centered(d, "ANLIK", 245, 492, medium(18), (183, 193, 208, 255))
    draw_centered(d, "3.5", 245, 548, medium(40), (247, 249, 255, 255))
    draw_centered(d, "L/100 km", 245, 598, regular(17), (183, 193, 208, 255))

    draw_centered(d, "ORTALAMA", STAGE_W - 245, 360, medium(18), (183, 193, 208, 255))
    draw_centered(d, "5.1", STAGE_W - 245, 424, medium(40), (247, 249, 255, 255))
    draw_centered(d, "L/100 km", STAGE_W - 245, 477, regular(17), (183, 193, 208, 255))

    vignette = Image.open(RES / "ghost_single_original_vignette.webp").convert("RGBA").resize((STAGE_W, STAGE_H), Image.Resampling.LANCZOS)
    bg.alpha_composite(vignette)
    return bg.convert("RGB")


def main() -> None:
    RES.mkdir(parents=True, exist_ok=True)
    save_webp(render_gauge_shell(), "ghost_single_original_gauge_shell.webp")
    save_webp(render_road_base(), "ghost_single_original_road_base.webp")
    save_webp(render_road_edges(), "ghost_single_original_road_edges.webp")
    save_webp(render_road_sheen(), "ghost_single_original_road_sheen.webp")
    save_webp(render_shadow_soft(), "ghost_single_original_shadow_soft.webp")
    save_webp(render_shadow_contact(), "ghost_single_original_shadow_contact.webp")

    colours = {
        "purple": (155, 92, 255),
        "red": (255, 59, 48),
        "green": (46, 230, 107),
        "white": (241, 245, 255),
        "blue": (53, 149, 255),
        "yellow": (255, 193, 46),
    }
    for name, rgb in colours.items():
        save_webp(render_horizon(rgb), f"ghost_single_original_horizon_{name}.webp")

    save_webp(render_preview(), "ghost_single_original_preview.webp", lossless=False)


if __name__ == "__main__":
    main()
