#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
res = root / "app/src/main/res/drawable-nodpi"
source_path = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt"
source = source_path.read_text(encoding="utf-8")
models = (root / "app/src/main/java/com/dcui/loganos/model/Models.kt").read_text(encoding="utf-8")
dashboard = (root / "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/java/com/dcui/loganos/MainActivity.kt").read_text(encoding="utf-8")
settings = (root / "app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt").read_text(encoding="utf-8")
generator_path = root / "tools/render_ghost_single_original_assets.py"
generator = generator_path.read_text(encoding="utf-8")


def require(cond, msg):
    if not cond:
        raise SystemExit(f"[FAIL] {msg}")
    print(f"[PASS] {msg}")


stage_assets = [
    "ghost_single_original_background.webp",
    "ghost_single_original_preview.webp",
    "ghost_single_original_vignette.webp",
]
cluster_assets = [
    "ghost_single_original_gauge_shell.webp",
    "ghost_single_original_road_base.webp",
    "ghost_single_original_road_edges.webp",
    "ghost_single_original_road_sheen.webp",
    "ghost_single_original_shadow_contact.webp",
    "ghost_single_original_shadow_soft.webp",
]
horizons = [f"ghost_single_original_horizon_{c}.webp" for c in ["purple", "red", "green", "white", "blue", "yellow"]]

for name in stage_assets:
    p = res / name
    require(p.exists(), f"stage asset exists: {name}")
    require(Image.open(p).size == (1846, 852), f"stage asset uses 1846x852: {name}")
for name in cluster_assets:
    p = res / name
    require(p.exists(), f"cluster asset exists: {name}")
    require(Image.open(p).size == (1000, 760), f"cluster asset uses undistorted 1000x760 reference space: {name}")
for name in horizons:
    p = res / name
    require(p.exists(), f"horizon asset exists: {name}")
    require(Image.open(p).size == (1846, 180), f"horizon is a thin 1846x180 strip: {name}")

require("GhostSingleOriginal(\"Ghost Single Original\")" in models, "separate GaugeStyle identity exists")
require("GhostOriginalAccent" in models, "separate accent enum exists")
require("fun GhostSingleOriginalCockpit" in source, "isolated cockpit composable exists")
require("GhostSingleV2" not in source, "retired V2 identity is not reused")
require("GhostSingleOriginalCockpit(" in dashboard, "dashboard routes to the isolated cockpit")
require("settings.gaugeStyle == GaugeStyle.GhostSingleOriginal" in dashboard, "dashboard branch is separately keyed")
require("GaugeStyle.GhostSingleOriginal" in main and "SCREEN_ORIENTATION_LANDSCAPE" in main, "phone orientation remains landscape-only")
require("Ghost Single Original ışık rengi" in settings, "dedicated glow-colour setting is exposed")
require("CentralReferenceCluster" in source, "gauge, road and car share one reference coordinate system")
require("clusterWidth * 0.76f" in source, "central cluster preserves the 1000x760 asset ratio")
require("RoadMotionLayer" not in source, "invented moving motorway lines are removed")
require("TemperatureBlock" not in source and "LeftInformationPanel" in source, "coolant moved from road bottom to the left information zone")
require("RightInformationPanel" in source, "average-consumption zone is enlarged and independent")
require("vehicleVisualDrawableRes" in source, "existing Logan I/III asset selector is reused")
require("GhostSpeedMaxKmh = 200" in source, "live speed is clamped to the Logan 0–200 km/h scale")
require("GaugeProgressLayer" in source, "live speed progress remains separate from static numerals")
require("SPEED_LABELS = list(range(0, 201, 20))" in generator, "asset-baked speed scale is 0–200 in 20 km/h steps")
require("ROAD_TOP_HALF_WIDTH = 34" in generator and "ROAD_BOTTOM_HALF_WIDTH = 232" in generator, "road uses the compact reference geometry")
require("no centre dashes" in generator.lower(), "generator documents that centre lane markings are forbidden")
require("RoadMotionLayer" not in generator, "asset generator does not add moving road segments")

for forbidden in ["MENZİL", "VİTES", "DIŞ SICAKLIK", "HIZ SINIRI", "ADAS", "ECO", "COMFORT"]:
    require(forbidden not in source, f"unsupported field is absent: {forbidden}")

# Basic source integrity checks.
require(source.count("{") == source.count("}"), "Kotlin source braces are balanced")
require(source.count("(") == source.count(")"), "Kotlin source parentheses are balanced")
print("\nGhost Single Original reference-layout validation passed.")
