# Review Prompt — LoganOS v1.0.0-beta.4.1.2

Review this Android/Kotlin/Jetpack Compose project as a compile-readiness, UI-regression and frozen-core audit.

## Intended 4.1.2 changes

1. Keep the 4.1.1 gauge, card, text and icon-slot sizes.
2. Remove the generated `cockpit_*.png` set and use normalized copies of the previously selected existing `asset_*.png` artwork.
3. All cockpit icons must use the same centered transparent canvas and `ContentScale.Fit`; no runtime Canvas drawing, Crop, arbitrary offset or asymmetric padding.
4. Fix cockpit bottom clipping and remove repeated `Demo veri` subtitles.
5. Fix Trip Center unit/subtitle clipping, current-trip status text, short-trip fuel precision and demo duration continuity.
6. Open Turkish/English choices directly when Language is selected; no second “App language” row.
7. Split the old “Connection & Data” category into “Connection” and “Trips & Records”.
8. Keep raw ECU logging, technical tests, technical export/share and support package under Developer.
9. Normalize About typography and remove the Turkish-main-language/AI-translation sentence.
10. BuildConfig version must be `1.0.0-beta.4.1.2` / `100000412`.

## Must remain byte-for-byte unchanged from 4.1.1

- `DelphiParser.kt`
- `FuelAlgorithmV3.kt`
- `TripComputer.kt`
- `ObdController.kt`
- `LoganSqlStore.kt`
- `TrustedTimeSource.kt`
- KWP command order/timeouts and Bluetooth connection core
- injection mg/stroke, CUTOFF/COAST_GUARD, AC_FAST, fan UNKNOWN and OBD speed behavior

## Please report

- Compile blockers, invalid Compose calls and callback/signature mistakes
- Any icon resource that is missing, cropped, off-center or visually much smaller/larger than the others
- Portrait/landscape/head-unit clipping regressions
- Language/settings navigation duplication
- Trip Center display/state inconsistencies
- Any accidental change to frozen OBD, parser, fuel, TripComputer, database or History behavior
