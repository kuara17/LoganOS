# LoganOS v1.0.0-beta.4.1.2 — UI Cleanup & Settings Reorganization

LoganOS, Dacia Logan 2005–2012 1.5 dCi / Delphi DCM1.2 için geliştirilen Kotlin + Jetpack Compose tabanlı bağımsız bir Android OBD kokpit uygulamasıdır.

## Beta 4.1.2 odağı

- 4.1.1’de beğenilen gösterge, kart, yazı ve ikon yuvası ölçüleri korunur.
- Sonradan oluşturulan kokpit ikonları yerine daha önce seçilen LoganOS ikon artwork’lerinin mevcut proje kaynakları kullanılır.
- İkonlar ortak şeffaf tuvalde merkezlenir, optik boyutları eşitlenir ve `ContentScale.Fit` ile kırpılmadan gösterilir.
- Kokpit alt güvenli alanı ve Sürüş Merkezi kart kırpılmaları düzeltilir.
- Kısa sürüş yakıt miktarı daha hassas gösterilir; demo süreleri ekranlar arasında tutarlı ilerler.
- Dil seçenekleri ikinci bir alt menü olmadan doğrudan açılır.
- Eski **Bağlantı & Veri** bölümü, **Bağlantı** ve **Sürüş ve Kayıtlar** olarak ayrılır.
- Ham log, teknik test ve destek paketi seçenekleri **Geliştirici** altında tutulur.
- Hakkında ekranı ortak tipografi ve daha sade içerikle yeniden düzenlenir.

## History ve güvenilirlik temeli

- Sürüşler kullanıcıdan ayrıca **Kaydet** istemeden otomatik geçmişe alınır.
- Başlatılan manuel marş ve geliştirici testleri ayrı **Test Geçmişi**ne kaydedilir.
- Sürüş ve test için ayrı 10 / 25 / 50 / sınırsız saklama seçenekleri bulunur.
- Sabitlenen kayıtlar otomatik temizlikten korunur.
- Her kayıt İncele, Dışa aktar ve onaylı Sil işlemlerine sahiptir.
- Aktif, kısa mola nedeniyle devam edebilecek veya saat doğrulaması bekleyen sürüşler otomatik silinmez.
- SQLite migration, WAL, foreign-key, `elapsedRealtime` ve boot-session tabanlı güvenilir zaman altyapısı korunur.

## APK oluşturma

`.github/workflows/build-apk.yml` manuel olarak `debug` veya `release` APK üretebilir.

- Test için `debug` seçilebilir.
- Kalıcı dağıtım ve gelecekteki OTA zinciri için aynı release anahtarı kullanılmalıdır.
- Release imza kurulumu: `docs/RELEASE_SIGNING_SETUP_TR.md`

> Debug paket kimliği `com.dcui.loganos.debug`, release paket kimliği `com.dcui.loganos` değeridir. İlk release geçişi bir defaya mahsus ayrı kurulum gerektirebilir.

## Değiştirilmeyen doğrulanmış çekirdek

Delphi parser byte konumları, FuelAlgorithmV3, injection mg/stroke hesabı, KWP komut/polling dizisi, CUTOFF, COAST_GUARD, AC_FAST ana biti, fan `UNKNOWN` kararı, OBD hız değeri, History migration altyapısı ve TripComputer hesaplama çekirdeği korunmuştur.

## Lisans ve bağımsızlık

LoganOS GPLv3 lisanslı, ücretsiz ve reklamsız bir açık kaynak projesidir.

LoganOS bağımsız olarak geliştirilen bir araç bilgi ve OBD uygulamasıdır. Renault Group veya Dacia ile resmî bağlantısı bulunmamaktadır.
