package com.dcui.loganos.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.dcui.loganos.model.DashboardSnapshot
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class LoganSqlStore(
    context: Context,
    private val timeSource: TrustedTimeSource = TrustedTimeSource(context)
) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    private val appContext = context.applicationContext
    private var anchoredBootId: String? = null
    private var anchoredOffsetMs: Long? = null

    init {
        // Better concurrent read/write behavior and safer short transactions on
        // head units that may lose power abruptly.
        setWriteAheadLoggingEnabled(true)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE drive_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                boot_session_id TEXT NOT NULL,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                session_state TEXT NOT NULL DEFAULT 'ACTIVE',
                version_name TEXT NOT NULL,
                adapter_name TEXT,
                adapter_address TEXT,
                note TEXT,
                trip_record_id INTEGER
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE obd_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                loop_index INTEGER,
                loop_ms INTEGER,
                rpm INTEGER,
                speed_kmh INTEGER,
                coolant_c INTEGER,
                fuel_mg REAL,
                fuel_lh REAL,
                instant_value REAL,
                instant_unit TEXT,
                pedal_percent REAL,
                map_mbar INTEGER,
                air_charge REAL,
                ac_on INTEGER,
                fan_state TEXT,
                fuel_source TEXT,
                trip_state TEXT,
                trip_distance_km REAL,
                fuel_used_l REAL,
                avg_l100 REAL,
                raw21cc TEXT,
                raw21a0 TEXT,
                raw21a2 TEXT,
                raw21cd TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE test_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                event_type TEXT NOT NULL,
                name TEXT NOT NULL,
                note TEXT,
                FOREIGN KEY(session_id) REFERENCES drive_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
        createHistoryTables(db)
        createIndexes(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        var version = oldVersion
        if (version < 2) {
            // Non-destructive v1 -> v2 migration. Existing beta.3.9.x sessions
            // remain available instead of being dropped.
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN started_elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN ended_elapsed_ms INTEGER")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN start_time_trusted INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN end_time_trusted INTEGER NOT NULL DEFAULT 1")
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN session_state TEXT NOT NULL DEFAULT 'ACTIVE'")

            db.execSQL("ALTER TABLE obd_samples ADD COLUMN elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE obd_samples ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE obd_samples ADD COLUMN time_trusted INTEGER NOT NULL DEFAULT 1")

            db.execSQL("ALTER TABLE test_events ADD COLUMN elapsed_ms INTEGER NOT NULL DEFAULT 0")
            db.execSQL("ALTER TABLE test_events ADD COLUMN boot_session_id TEXT NOT NULL DEFAULT 'legacy'")
            db.execSQL("ALTER TABLE test_events ADD COLUMN time_trusted INTEGER NOT NULL DEFAULT 1")

            db.execSQL("UPDATE drive_sessions SET session_state=CASE WHEN ended_at_ms IS NULL THEN 'ACTIVE' ELSE 'ENDED' END")
            createCoreIndexes(db)
            version = 2
        }
        if (version < 3) {
            db.execSQL("ALTER TABLE drive_sessions ADD COLUMN trip_record_id INTEGER")
            createHistoryTables(db)
            createIndexes(db)
            version = 3
        }
        check(version == newVersion) {
            "Unsupported LoganOS database migration: $oldVersion -> $newVersion"
        }
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        throw IllegalStateException("LoganOS database downgrade is not supported: $oldVersion -> $newVersion")
    }

    fun databaseFile(): File = appContext.getDatabasePath(DB_NAME)

    fun isTimeTrusted(): Boolean = timeSource.isTrusted()

    /** Close sessions left ACTIVE by an abrupt ignition/power cut. */
    fun recoverOpenSessions(): Int {
        val db = writableDatabase
        val openSessions = mutableListOf<RecoverableSession>()
        db.rawQuery(
            "SELECT id, started_at_ms, started_elapsed_ms, start_time_trusted FROM drive_sessions WHERE ended_at_ms IS NULL OR session_state='ACTIVE' ORDER BY id ASC",
            emptyArray()
        ).use { sessions ->
            while (sessions.moveToNext()) {
                openSessions += RecoverableSession(
                    id = sessions.getLong(0),
                    startedAtMs = sessions.getLong(1),
                    startedElapsedMs = sessions.getLong(2),
                    startTrusted = sessions.getInt(3) == 1
                )
            }
        }
        if (openSessions.isEmpty()) return 0

        db.beginTransaction()
        try {
            openSessions.forEach { session ->
                val last = latestStoredMark(db, session.id)
                val endEpoch = last?.epochMs ?: if (session.startTrusted) session.startedAtMs else 0L
                val endElapsed = last?.elapsedMs ?: session.startedElapsedMs
                val endTrusted = last?.trusted ?: session.startTrusted
                val values = ContentValues().apply {
                    put("ended_at_ms", endEpoch)
                    put("ended_elapsed_ms", endElapsed)
                    put("end_time_trusted", if (endTrusted) 1 else 0)
                    put("session_state", "RECOVERED")
                }
                db.update("drive_sessions", values, "id=?", arrayOf(session.id.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return openSessions.size
    }

    fun startSession(versionName: String, adapterName: String?, adapterAddress: String?, tripRecordId: Long? = null): Long {
        val mark = currentMark()
        val values = ContentValues().apply {
            put("started_at_ms", mark.epochMs ?: 0L)
            put("started_elapsed_ms", mark.elapsedMs)
            put("boot_session_id", mark.bootSessionId)
            put("start_time_trusted", if (mark.trusted) 1 else 0)
            put("end_time_trusted", 0)
            put("session_state", "ACTIVE")
            put("version_name", versionName)
            put("adapter_name", adapterName)
            put("adapter_address", adapterAddress)
            put("note", "LoganOS SQL session")
            if (tripRecordId != null) put("trip_record_id", tripRecordId)
        }
        return writableDatabase.insertOrThrow("drive_sessions", null, values)
    }

    fun endSession(sessionId: Long?, state: String = "ENDED") {
        if (sessionId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("session_state", state)
        }
        writableDatabase.update("drive_sessions", values, "id=?", arrayOf(sessionId.toString()))
    }

    fun insertEvent(sessionId: Long?, eventType: String, name: String, note: String? = null) {
        val mark = currentMark()
        val values = ContentValues().apply {
            if (sessionId != null) put("session_id", sessionId)
            putTime(mark)
            put("event_type", eventType)
            put("name", name)
            put("note", note)
        }
        writableDatabase.insertOrThrow("test_events", null, values)
    }

    fun insertSample(
        sessionId: Long?,
        loopIndex: Int,
        loopMs: Long,
        snapshot: DashboardSnapshot,
        raw21cc: String,
        raw21a0: String,
        raw21a2: String,
        raw21cd: String
    ) {
        if (sessionId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("session_id", sessionId)
            putTime(mark)
            put("loop_index", loopIndex)
            put("loop_ms", loopMs)
            putNullable("rpm", snapshot.rpm)
            putNullable("speed_kmh", snapshot.speedKmh)
            putNullable("coolant_c", snapshot.engineTempC)
            putNullable("fuel_mg", snapshot.injectionMg)
            putNullable("fuel_lh", if (snapshot.instantUnit == "L/h") snapshot.instantConsumption else null)
            putNullable("instant_value", snapshot.instantConsumption)
            put("instant_unit", snapshot.instantUnit)
            putNullable("pedal_percent", snapshot.pedalPercent)
            putNullable("map_mbar", snapshot.mapMbar)
            putNullable("air_charge", snapshot.airCharge)
            putNullable("ac_on", snapshot.acOn?.let { if (it) 1 else 0 })
            put("fan_state", snapshot.radiatorFanOn?.toString() ?: "UNKNOWN")
            put("fuel_source", snapshot.fuelSource)
            put("trip_state", snapshot.tripStateText)
            putNullable("trip_distance_km", snapshot.tripDistanceKm)
            putNullable("fuel_used_l", snapshot.fuelUsedL)
            putNullable("avg_l100", snapshot.averageConsumption)
            put("raw21cc", raw21cc)
            put("raw21a0", raw21a0)
            put("raw21a2", raw21a2)
            put("raw21cd", raw21cd)
        }
        writableDatabase.insertOrThrow("obd_samples", null, values)
    }

    fun clearAll(): Int {
        val db = writableDatabase
        var count = 0
        db.beginTransaction()
        try {
            count += db.delete("test_samples", null, null)
            count += db.delete("test_sessions", null, null)
            count += db.delete("obd_samples", null, null)
            count += db.delete("test_events", null, null)
            count += db.delete("drive_sessions", null, null)
            count += db.delete("trip_records", null, null)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return count
    }

    fun exportSessionText(sessionId: Long?, includeRaw: Boolean = true): String? {
        val id = sessionId ?: latestSessionId() ?: return null
        val db = readableDatabase
        val session = db.rawQuery("SELECT * FROM drive_sessions WHERE id=?", arrayOf(id.toString()))
        if (!session.moveToFirst()) {
            session.close()
            return null
        }
        val startedAt = session.long("started_at_ms")
        val storedEndedAt = session.optLong("ended_at_ms")
        val startedElapsed = session.optLong("started_elapsed_ms") ?: 0L
        val endedElapsed = session.optLong("ended_elapsed_ms")
        val startTrusted = session.optInt("start_time_trusted") == 1
        val endTrusted = session.optInt("end_time_trusted") == 1
        val sessionState = session.str("session_state") ?: if (storedEndedAt == null) "ACTIVE" else "ENDED"
        val nowMark = timeSource.now()
        val effectiveEndedElapsed = endedElapsed ?: nowMark.elapsedMs
        val effectiveEndedEpoch = storedEndedAt ?: nowMark.epochMs
        val durationMs = if (startedElapsed > 0L && effectiveEndedElapsed >= startedElapsed) {
            effectiveEndedElapsed - startedElapsed
        } else {
            ((effectiveEndedEpoch ?: startedAt) - startedAt).coerceAtLeast(0L)
        }
        val header = buildString {
            appendLine("LOGANOS SQL EXPORT")
            appendLine("session_id=$id")
            appendLine("version=${session.str("version_name")}")
            appendLine("adapter=${session.str("adapter_name") ?: "--"} / ${session.str("adapter_address") ?: "--"}")
            appendLine("started=${formatTimestamp(startedAt, startTrusted)}")
            appendLine("ended=${formatTimestamp(effectiveEndedEpoch ?: 0L, endTrusted || (storedEndedAt == null && nowMark.trusted))}")
            appendLine("duration=${formatDuration(durationMs)}")
            appendLine("session_state=$sessionState")
            appendLine("time_source=${if (startTrusted && (storedEndedAt == null || endTrusted)) "TRUSTED" else "MONOTONIC_PENDING"}")
            appendLine()
        }
        session.close()

        val builder = StringBuilder(header)
        val testStartCounts = mutableMapOf<String, Int>()
        val activeTestStarts = mutableMapOf<String, Long>()
        db.rawQuery(
            "SELECT * FROM test_events WHERE session_id=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC",
            arrayOf(id.toString())
        ).use { c ->
            if (c.count > 0) {
                builder.appendLine("[TEST_EVENTS]")
                while (c.moveToNext()) {
                    val type = c.str("event_type") ?: "EVENT"
                    val name = c.str("name") ?: "--"
                    val note = c.str("note") ?: ""
                    val timeMs = c.long("time_ms")
                    val elapsedMs = c.optLong("elapsed_ms") ?: 0L
                    val trusted = c.optInt("time_trusted") == 1
                    val suffix = if (type == "TEST_START") {
                        val next = (testStartCounts[name] ?: 0) + 1
                        testStartCounts[name] = next
                        activeTestStarts[name] = elapsedMs
                        " #$next"
                    } else ""
                    val shortNote = if (type == "TEST_END") {
                        val started = activeTestStarts[name]
                        if (started != null && elapsedMs - started < 5000L) " kısa/geçersiz deneme" else ""
                    } else ""
                    builder.appendLine("[$type$suffix] ${formatTimestamp(timeMs, trusted)} name=$name note=$note$shortNote")
                }
                builder.appendLine()
            }
        }
        db.rawQuery(
            "SELECT * FROM obd_samples WHERE session_id=? ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END ASC, id ASC",
            arrayOf(id.toString())
        ).use { c ->
            builder.appendLine("[SAMPLES] count=${c.count}")
            builder.appendLine(if (includeRaw) "format=summary+raw; raw ECU packets included when available" else "format=summary; raw ECU packets omitted")
            while (c.moveToNext()) {
                val trusted = c.optInt("time_trusted") == 1
                val at = if (trusted) formatTime(c.long("time_ms")) else "TIME_PENDING+${c.optLong("elapsed_ms") ?: 0L}ms"
                val line = "[LOOP #${c.str("loop_index") ?: "--"} at=$at ${c.long("loop_ms")}ms] " +
                    "speed=${c.str("speed_kmh") ?: "--"} rpm=${c.str("rpm") ?: "--"} temp=${c.str("coolant_c") ?: "--"} " +
                    "fuel=${c.str("fuel_mg") ?: "--"} instant=${c.str("instant_value") ?: "--"} ${c.str("instant_unit") ?: ""} " +
                    "pedal=${c.str("pedal_percent") ?: "--"} map=${c.str("map_mbar") ?: "--"} air=${c.str("air_charge") ?: "--"} " +
                    "ac=${c.str("ac_on") ?: "--"} fan=${c.str("fan_state") ?: "UNKNOWN"} src=${c.str("fuel_source") ?: "--"} " +
                    "trip=${c.str("trip_state") ?: "--"} dist=${c.str("trip_distance_km") ?: "--"} fuelUsed=${c.str("fuel_used_l") ?: "--"} avg=${c.str("avg_l100") ?: "--"}"
                builder.appendLine(line)
                val raw21cc = c.str("raw21cc")
                val raw21a0 = c.str("raw21a0")
                val raw21a2 = c.str("raw21a2")
                val raw21cd = c.str("raw21cd")
                if (includeRaw && (!raw21cc.isNullOrBlank() || !raw21a0.isNullOrBlank() || !raw21a2.isNullOrBlank() || !raw21cd.isNullOrBlank())) {
                    builder.appendLine("RAW 21CC=${raw21cc ?: ""}")
                    builder.appendLine("RAW 21A0=${raw21a0 ?: ""}")
                    builder.appendLine("RAW 21A2=${raw21a2 ?: ""}")
                    builder.appendLine("RAW 21CD=${raw21cd ?: ""}")
                }
            }
        }
        return builder.toString()
    }


    fun recoverOpenHistory(): Pair<Int, Int> {
        val mark = currentMark()
        val db = writableDatabase
        var tripCount: Int
        var testCount = 0
        db.beginTransaction()
        try {
            // A head unit can lose power without lifecycle callbacks. The trip
            // row is updated on every stored OBD sample, so its existing end mark
            // is the best estimate of the real ignition-off moment. Only change
            // the state here; do not stretch the trip until the next app launch.
            tripCount = db.update(
                "trip_records",
                ContentValues().apply { put("status", "PARKED") },
                "status='ACTIVE'",
                emptyArray()
            )

            val activeTests = mutableListOf<Long>()
            db.rawQuery("SELECT id FROM test_sessions WHERE status='ACTIVE'", emptyArray()).use { c ->
                while (c.moveToNext()) activeTests += c.getLong(0)
            }
            activeTests.forEach { id ->
                val last = latestTestStoredMark(db, id)
                val values = ContentValues().apply {
                    put("status", "INTERRUPTED")
                    put("ended_at_ms", last?.epochMs ?: (mark.epochMs ?: 0L))
                    put("ended_elapsed_ms", last?.elapsedMs ?: mark.elapsedMs)
                    put("end_boot_session_id", last?.bootSessionId ?: mark.bootSessionId)
                    put("end_time_trusted", if (last?.trusted ?: mark.trusted) 1 else 0)
                    put("summary", "Kontak veya uygulama kapanışı nedeniyle yarım kaldı")
                }
                db.update("test_sessions", values, "id=?", arrayOf(id.toString()))
                testCount++
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return tripCount to testCount
    }

    fun upsertTripRecord(
        sessionId: Long?,
        tripToken: Long,
        snapshot: DashboardSnapshot,
        durationMs: Long,
        versionName: String
    ): Long? {
        if (tripToken == 0L) return null
        val distance = snapshot.tripDistanceKm ?: 0.0
        val meaningful = distance > 0.00001 || (snapshot.tripStateText != null && snapshot.tripStateText != "Sürüş bekleniyor")
        if (!meaningful) return findTripRecordId(tripToken)
        val mark = currentMark()
        val db = writableDatabase
        var recordId = findTripRecordId(db, tripToken)
        db.beginTransaction()
        try {
            if (recordId == null) {
                val values = ContentValues().apply {
                    put("trip_token", tripToken)
                    put("started_at_ms", mark.epochMs ?: 0L)
                    put("started_elapsed_ms", mark.elapsedMs)
                    put("start_boot_session_id", mark.bootSessionId)
                    put("start_time_trusted", if (mark.trusted) 1 else 0)
                    put("ended_at_ms", mark.epochMs ?: 0L)
                    put("ended_elapsed_ms", mark.elapsedMs)
                    put("end_boot_session_id", mark.bootSessionId)
                    put("end_time_trusted", if (mark.trusted) 1 else 0)
                    put("status", "ACTIVE")
                    put("distance_km", distance)
                    put("fuel_used_l", snapshot.fuelUsedL ?: 0.0)
                    put("duration_ms", durationMs.coerceAtLeast(0L))
                    putNullable("average_l100", snapshot.averageConsumption)
                    putNullable("max_speed_kmh", snapshot.speedKmh)
                    putNullable("max_rpm", snapshot.rpm)
                    putNullable("start_temp_c", snapshot.engineTempC)
                    putNullable("end_temp_c", snapshot.engineTempC)
                    put("sample_count", 1)
                    if (sessionId != null) {
                        put("first_session_id", sessionId)
                        put("last_session_id", sessionId)
                    }
                    put("created_version", versionName)
                }
                recordId = db.insertOrThrow("trip_records", null, values)
            } else {
                val values = ContentValues().apply {
                    put("ended_at_ms", mark.epochMs ?: 0L)
                    put("ended_elapsed_ms", mark.elapsedMs)
                    put("end_boot_session_id", mark.bootSessionId)
                    put("end_time_trusted", if (mark.trusted) 1 else 0)
                    put("status", "ACTIVE")
                    put("distance_km", distance)
                    put("fuel_used_l", snapshot.fuelUsedL ?: 0.0)
                    put("duration_ms", durationMs.coerceAtLeast(0L))
                    putNullable("average_l100", snapshot.averageConsumption)
                    putNullable("end_temp_c", snapshot.engineTempC)
                    if (sessionId != null) put("last_session_id", sessionId)
                }
                db.update("trip_records", values, "id=?", arrayOf(recordId.toString()))
                snapshot.speedKmh?.let {
                    db.execSQL("UPDATE trip_records SET max_speed_kmh=MAX(COALESCE(max_speed_kmh,0),?), sample_count=sample_count+1 WHERE id=?", arrayOf(it, recordId))
                } ?: db.execSQL("UPDATE trip_records SET sample_count=sample_count+1 WHERE id=?", arrayOf(recordId))
                snapshot.rpm?.let {
                    db.execSQL("UPDATE trip_records SET max_rpm=MAX(COALESCE(max_rpm,0),?) WHERE id=?", arrayOf(it, recordId))
                }
                if (snapshot.engineTempC != null) {
                    db.execSQL("UPDATE trip_records SET start_temp_c=COALESCE(start_temp_c,?) WHERE id=?", arrayOf(snapshot.engineTempC, recordId))
                }
            }
            if (sessionId != null) {
                val sessionValues = ContentValues().apply { put("trip_record_id", requireNotNull(recordId)) }
                db.update("drive_sessions", sessionValues, "id=?", arrayOf(sessionId.toString()))
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return recordId
    }

    fun findTripRecordId(tripToken: Long): Long? = findTripRecordId(readableDatabase, tripToken)

    fun assignSessionToTrip(sessionId: Long?, tripRecordId: Long?) {
        if (sessionId == null || tripRecordId == null) return
        val values = ContentValues().apply { put("trip_record_id", tripRecordId) }
        writableDatabase.update("drive_sessions", values, "id=?", arrayOf(sessionId.toString()))
    }

    fun parkTripRecord(recordId: Long?) {
        if (recordId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("status", "PARKED")
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
        }
        writableDatabase.update("trip_records", values, "id=? AND status='ACTIVE'", arrayOf(recordId.toString()))
    }

    fun finalizeTripRecord(
        tripToken: Long,
        distanceKm: Double,
        fuelUsedL: Double,
        durationMs: Long,
        averageL100: Double?,
        state: String = "ENDED",
        endMark: TimeMark? = null
    ): Long? {
        val recordId = findTripRecordId(tripToken) ?: return null
        val mark = endMark ?: currentMark()
        val values = ContentValues().apply {
            put("status", state)
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("distance_km", distanceKm.coerceAtLeast(0.0))
            put("fuel_used_l", fuelUsedL.coerceAtLeast(0.0))
            put("duration_ms", durationMs.coerceAtLeast(0L))
            putNullable("average_l100", averageL100)
        }
        writableDatabase.update("trip_records", values, "id=?", arrayOf(recordId.toString()))
        return recordId
    }

    fun listDriveHistory(maxItems: Int = 200): List<DriveHistoryItem> {
        val result = mutableListOf<DriveHistoryItem>()
        val sql = """
            SELECT r.id,r.trip_token,r.started_at_ms,r.ended_at_ms,r.start_time_trusted,r.end_time_trusted,
                   r.status,r.pinned,r.exported_at_ms,r.distance_km,r.fuel_used_l,r.duration_ms,r.average_l100,
                   r.max_speed_kmh,r.max_rpm,r.start_temp_c,r.end_temp_c,
                   (SELECT COUNT(*) FROM drive_sessions s WHERE s.trip_record_id=r.id) AS session_count
            FROM trip_records r
            WHERE r.distance_km>0.00001 OR r.sample_count>0
            ORDER BY CASE WHEN r.status='ACTIVE' THEN 0 WHEN r.status='PARKED' THEN 1 ELSE 2 END,
                     COALESCE(r.ended_at_ms,r.started_at_ms) DESC, r.id DESC
            LIMIT ?
        """.trimIndent()
        readableDatabase.rawQuery(sql, arrayOf(maxItems.toString())).use { c ->
            while (c.moveToNext()) {
                val end = if (c.isNull(3)) null else c.getLong(3)
                result += DriveHistoryItem(
                    id = c.getLong(0),
                    tripToken = c.getLong(1),
                    startedAtMs = c.getLong(2),
                    endedAtMs = end,
                    timeTrusted = c.getInt(4) == 1 && (end == null || c.getInt(5) == 1),
                    status = c.getString(6),
                    pinned = c.getInt(7) == 1,
                    exported = !c.isNull(8),
                    distanceKm = c.getDouble(9),
                    fuelUsedL = c.getDouble(10),
                    durationMs = c.getLong(11),
                    averageL100 = if (c.isNull(12)) null else c.getDouble(12),
                    maxSpeedKmh = if (c.isNull(13)) null else c.getInt(13),
                    maxRpm = if (c.isNull(14)) null else c.getInt(14),
                    startTempC = if (c.isNull(15)) null else c.getInt(15),
                    endTempC = if (c.isNull(16)) null else c.getInt(16),
                    sessionCount = c.getInt(17)
                )
            }
        }
        return result
    }

    fun setTripPinned(id: Long, pinned: Boolean): Boolean {
        val values = ContentValues().apply { put("pinned", if (pinned) 1 else 0) }
        return writableDatabase.update("trip_records", values, "id=?", arrayOf(id.toString())) > 0
    }

    fun deleteTripRecord(id: Long): Boolean {
        val db = writableDatabase
        val status = db.rawQuery("SELECT status FROM trip_records WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: return false
        if (status == "ACTIVE" || status == "PARKED" || status == "TIME_PENDING") return false
        db.beginTransaction()
        return try {
            db.delete("drive_sessions", "trip_record_id=?", arrayOf(id.toString()))
            val deleted = db.delete("trip_records", "id=?", arrayOf(id.toString())) > 0
            db.setTransactionSuccessful()
            deleted
        } finally {
            db.endTransaction()
        }
    }

    fun startTestSession(
        driveSessionId: Long?,
        testType: String,
        name: String,
        versionName: String,
        note: String? = null
    ): Long {
        val mark = currentMark()
        val values = ContentValues().apply {
            if (driveSessionId != null) put("drive_session_id", driveSessionId)
            put("test_type", testType)
            put("name", name)
            put("started_at_ms", mark.epochMs ?: 0L)
            put("started_elapsed_ms", mark.elapsedMs)
            put("start_boot_session_id", mark.bootSessionId)
            put("start_time_trusted", if (mark.trusted) 1 else 0)
            put("status", "ACTIVE")
            put("created_version", versionName)
            put("summary", note)
        }
        return writableDatabase.insertOrThrow("test_sessions", null, values)
    }

    fun insertTestSample(
        testSessionId: Long?,
        loopIndex: Int,
        loopMs: Long,
        snapshot: DashboardSnapshot,
        raw21cc: String,
        raw21a0: String,
        raw21a2: String,
        raw21cd: String
    ) {
        if (testSessionId == null) return
        val mark = currentMark()
        val db = writableDatabase
        db.beginTransaction()
        try {
            val values = ContentValues().apply {
                put("test_session_id", testSessionId)
                putTime(mark)
                put("loop_index", loopIndex)
                put("loop_ms", loopMs)
                putNullable("rpm", snapshot.rpm)
                putNullable("speed_kmh", snapshot.speedKmh)
                putNullable("coolant_c", snapshot.engineTempC)
                putNullable("fuel_mg", snapshot.injectionMg)
                putNullable("instant_value", snapshot.instantConsumption)
                put("instant_unit", snapshot.instantUnit)
                putNullable("pedal_percent", snapshot.pedalPercent)
                putNullable("map_mbar", snapshot.mapMbar)
                putNullable("air_charge", snapshot.airCharge)
                putNullable("ac_on", snapshot.acOn?.let { if (it) 1 else 0 })
                put("fan_state", snapshot.radiatorFanOn?.toString() ?: "UNKNOWN")
                put("fuel_source", snapshot.fuelSource)
                put("trip_state", snapshot.tripStateText)
                putNullable("trip_distance_km", snapshot.tripDistanceKm)
                putNullable("fuel_used_l", snapshot.fuelUsedL)
                putNullable("avg_l100", snapshot.averageConsumption)
                put("raw21cc", raw21cc)
                put("raw21a0", raw21a0)
                put("raw21a2", raw21a2)
                put("raw21cd", raw21cd)
            }
            db.insertOrThrow("test_samples", null, values)
            val sessionValues = ContentValues().apply {
                put("ended_at_ms", mark.epochMs ?: 0L)
                put("ended_elapsed_ms", mark.elapsedMs)
                put("end_boot_session_id", mark.bootSessionId)
                put("end_time_trusted", if (mark.trusted) 1 else 0)
            }
            db.update("test_sessions", sessionValues, "id=? AND status='ACTIVE'", arrayOf(testSessionId.toString()))
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun endTestSession(testSessionId: Long?, status: String = "COMPLETED", summary: String? = null) {
        if (testSessionId == null) return
        val mark = currentMark()
        val values = ContentValues().apply {
            put("ended_at_ms", mark.epochMs ?: 0L)
            put("ended_elapsed_ms", mark.elapsedMs)
            put("end_boot_session_id", mark.bootSessionId)
            put("end_time_trusted", if (mark.trusted) 1 else 0)
            put("status", status)
            if (summary != null) put("summary", summary)
        }
        writableDatabase.update("test_sessions", values, "id=?", arrayOf(testSessionId.toString()))
    }

    fun listTestHistory(maxItems: Int = 200): List<TestHistoryItem> {
        val result = mutableListOf<TestHistoryItem>()
        val sql = """
            SELECT t.id,t.name,t.test_type,t.started_at_ms,t.ended_at_ms,t.start_time_trusted,t.end_time_trusted,
                   t.status,t.pinned,t.exported_at_ms,
                   CASE WHEN t.ended_elapsed_ms IS NOT NULL THEN MAX(0,t.ended_elapsed_ms-t.started_elapsed_ms) ELSE 0 END AS duration_ms,
                   (SELECT COUNT(*) FROM test_samples s WHERE s.test_session_id=t.id) AS sample_count,t.summary
            FROM test_sessions t
            ORDER BY CASE WHEN t.status='ACTIVE' THEN 0 ELSE 1 END, COALESCE(t.ended_at_ms,t.started_at_ms) DESC,t.id DESC
            LIMIT ?
        """.trimIndent()
        readableDatabase.rawQuery(sql, arrayOf(maxItems.toString())).use { c ->
            while (c.moveToNext()) {
                val end = if (c.isNull(4)) null else c.getLong(4)
                result += TestHistoryItem(
                    id = c.getLong(0),
                    name = c.getString(1),
                    testType = c.getString(2),
                    startedAtMs = c.getLong(3),
                    endedAtMs = end,
                    timeTrusted = c.getInt(5) == 1 && (end == null || c.getInt(6) == 1),
                    status = c.getString(7),
                    pinned = c.getInt(8) == 1,
                    exported = !c.isNull(9),
                    durationMs = c.getLong(10),
                    sampleCount = c.getInt(11),
                    summary = if (c.isNull(12)) null else c.getString(12)
                )
            }
        }
        return result
    }

    fun setTestPinned(id: Long, pinned: Boolean): Boolean {
        val values = ContentValues().apply { put("pinned", if (pinned) 1 else 0) }
        return writableDatabase.update("test_sessions", values, "id=?", arrayOf(id.toString())) > 0
    }

    fun deleteTestRecord(id: Long): Boolean {
        val db = writableDatabase
        val status = db.rawQuery("SELECT status FROM test_sessions WHERE id=?", arrayOf(id.toString())).use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        } ?: return false
        if (status == "ACTIVE") return false
        return db.delete("test_sessions", "id=?", arrayOf(id.toString())) > 0
    }

    fun applyHistoryRetention(driveLimit: Int, testLimit: Int): Pair<Int, Int> {
        val db = writableDatabase
        var driveDeleted = 0
        var testDeleted = 0
        db.beginTransaction()
        try {
            if (driveLimit >= 0) {
                val ids = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT id FROM trip_records WHERE pinned=0 AND status NOT IN ('ACTIVE','PARKED','TIME_PENDING') ORDER BY COALESCE(ended_at_ms,started_at_ms) DESC,id DESC LIMIT -1 OFFSET ?",
                    arrayOf(driveLimit.toString())
                ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
                ids.forEach { id ->
                    db.delete("drive_sessions", "trip_record_id=?", arrayOf(id.toString()))
                    driveDeleted += db.delete("trip_records", "id=?", arrayOf(id.toString()))
                }
            }
            if (testLimit >= 0) {
                val ids = mutableListOf<Long>()
                db.rawQuery(
                    "SELECT id FROM test_sessions WHERE pinned=0 AND status<>'ACTIVE' ORDER BY COALESCE(ended_at_ms,started_at_ms) DESC,id DESC LIMIT -1 OFFSET ?",
                    arrayOf(testLimit.toString())
                ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
                ids.forEach { id -> testDeleted += db.delete("test_sessions", "id=?", arrayOf(id.toString())) }
            }
            // Legacy/technical sessions without a trip_record_id are never pruned
            // automatically. They may contain beta logs the user has not exported.
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
        return driveDeleted to testDeleted
    }

    fun historyStorageInfo(): HistoryStorageInfo {
        val db = readableDatabase
        fun count(sql: String): Int = db.rawQuery(sql, emptyArray()).use { c -> if (c.moveToFirst()) c.getInt(0) else 0 }
        val driveCount = count("SELECT COUNT(*) FROM trip_records")
        val testCount = count("SELECT COUNT(*) FROM test_sessions")
        val pinnedDrive = count("SELECT COUNT(*) FROM trip_records WHERE pinned=1")
        val pinnedTest = count("SELECT COUNT(*) FROM test_sessions WHERE pinned=1")
        val driveSamples = count("SELECT COUNT(*) FROM obd_samples s JOIN drive_sessions d ON d.id=s.session_id WHERE d.trip_record_id IS NOT NULL")
        val testSamples = count("SELECT COUNT(*) FROM test_samples")
        val dbFile = databaseFile()
        val total = listOf(dbFile, File(dbFile.absolutePath + "-wal"), File(dbFile.absolutePath + "-shm")).sumOf { if (it.exists()) it.length() else 0L }
        val driveApprox = driveSamples * 240L + driveCount * 1024L
        val testApprox = testSamples * 240L + testCount * 768L
        return HistoryStorageInfo(driveCount, testCount, pinnedDrive, pinnedTest, driveApprox, testApprox, total)
    }

    fun exportTripRecordText(recordId: Long, includeRaw: Boolean = false): String? {
        val item = listDriveHistory(500).firstOrNull { it.id == recordId } ?: return null
        val builder = StringBuilder().apply {
            appendLine("LOGANOS DRIVE HISTORY EXPORT")
            appendLine("record_id=${item.id}")
            appendLine("status=${item.status}")
            appendLine("pinned=${item.pinned}")
            appendLine("started=${formatTimestamp(item.startedAtMs, item.timeTrusted)}")
            appendLine("ended=${formatTimestamp(item.endedAtMs ?: 0L, item.timeTrusted)}")
            appendLine("duration=${formatDuration(item.durationMs)}")
            appendLine("distance_km=${String.format(Locale.US, "%.3f", item.distanceKm)}")
            appendLine("fuel_used_l=${String.format(Locale.US, "%.4f", item.fuelUsedL)}")
            appendLine("average_l100=${item.averageL100?.let { String.format(Locale.US, "%.3f", it) } ?: "--"}")
            appendLine("max_speed_kmh=${item.maxSpeedKmh ?: "--"}")
            appendLine("max_rpm=${item.maxRpm ?: "--"}")
            appendLine("start_temp_c=${item.startTempC ?: "--"}")
            appendLine("end_temp_c=${item.endTempC ?: "--"}")
            appendLine("obd_sessions=${item.sessionCount}")
            appendLine()
        }
        val sessionIds = mutableListOf<Long>()
        readableDatabase.rawQuery("SELECT id FROM drive_sessions WHERE trip_record_id=? ORDER BY id ASC", arrayOf(recordId.toString())).use { c ->
            while (c.moveToNext()) sessionIds += c.getLong(0)
        }
        sessionIds.forEachIndexed { index, id ->
            builder.appendLine("===== OBD SESSION ${index + 1}/${sessionIds.size} =====")
            builder.append(exportSessionText(id, includeRaw) ?: "")
            builder.appendLine()
        }
        val mark = currentMark()
        val values = ContentValues().apply { put("exported_at_ms", mark.epochMs ?: 0L) }
        writableDatabase.update("trip_records", values, "id=?", arrayOf(recordId.toString()))
        return builder.toString()
    }

    fun exportTestRecordText(recordId: Long, includeRaw: Boolean = true): String? {
        val item = listTestHistory(500).firstOrNull { it.id == recordId } ?: return null
        val builder = StringBuilder().apply {
            appendLine("LOGANOS TEST HISTORY EXPORT")
            appendLine("record_id=${item.id}")
            appendLine("test_type=${item.testType}")
            appendLine("name=${item.name}")
            appendLine("status=${item.status}")
            appendLine("pinned=${item.pinned}")
            appendLine("started=${formatTimestamp(item.startedAtMs, item.timeTrusted)}")
            appendLine("ended=${formatTimestamp(item.endedAtMs ?: 0L, item.timeTrusted)}")
            appendLine("duration=${formatDuration(item.durationMs)}")
            appendLine("samples=${item.sampleCount}")
            appendLine("summary=${item.summary ?: "--"}")
            appendLine()
            appendLine("[SAMPLES]")
        }
        readableDatabase.rawQuery("SELECT * FROM test_samples WHERE test_session_id=? ORDER BY elapsed_ms ASC,id ASC", arrayOf(recordId.toString())).use { c ->
            while (c.moveToNext()) {
                val trusted = c.optInt("time_trusted") == 1
                val at = if (trusted) formatTime(c.long("time_ms")) else "TIME_PENDING+${c.optLong("elapsed_ms") ?: 0L}ms"
                builder.appendLine(
                    "[LOOP #${c.str("loop_index") ?: "--"} at=$at ${c.long("loop_ms")}ms] speed=${c.str("speed_kmh") ?: "--"} rpm=${c.str("rpm") ?: "--"} temp=${c.str("coolant_c") ?: "--"} fuel=${c.str("fuel_mg") ?: "--"} instant=${c.str("instant_value") ?: "--"} ${c.str("instant_unit") ?: ""} pedal=${c.str("pedal_percent") ?: "--"} map=${c.str("map_mbar") ?: "--"} air=${c.str("air_charge") ?: "--"} ac=${c.str("ac_on") ?: "--"} fan=${c.str("fan_state") ?: "UNKNOWN"} src=${c.str("fuel_source") ?: "--"} trip=${c.str("trip_state") ?: "--"} dist=${c.str("trip_distance_km") ?: "--"} fuelUsed=${c.str("fuel_used_l") ?: "--"} avg=${c.str("avg_l100") ?: "--"}"
                )
                if (includeRaw) {
                    val rawValues = listOf("21CC" to c.str("raw21cc"), "21A0" to c.str("raw21a0"), "21A2" to c.str("raw21a2"), "21CD" to c.str("raw21cd"))
                    rawValues.filter { !it.second.isNullOrBlank() }.forEach { builder.appendLine("RAW ${it.first}=${it.second}") }
                }
            }
        }
        val mark = currentMark()
        val values = ContentValues().apply { put("exported_at_ms", mark.epochMs ?: 0L) }
        writableDatabase.update("test_sessions", values, "id=?", arrayOf(recordId.toString()))
        return builder.toString()
    }

    private fun findTripRecordId(db: SQLiteDatabase, tripToken: Long): Long? {
        return db.rawQuery("SELECT id FROM trip_records WHERE trip_token=? LIMIT 1", arrayOf(tripToken.toString())).use { c ->
            if (c.moveToFirst()) c.getLong(0) else null
        }
    }

    private fun latestTestStoredMark(db: SQLiteDatabase, testSessionId: Long): TestStoredMark? {
        return db.rawQuery(
            "SELECT time_ms,elapsed_ms,boot_session_id,time_trusted FROM test_samples WHERE test_session_id=? ORDER BY elapsed_ms DESC,id DESC LIMIT 1",
            arrayOf(testSessionId.toString())
        ).use { c ->
            if (c.moveToFirst()) TestStoredMark(c.getLong(0), c.getLong(1), c.getString(2), c.getInt(3) == 1) else null
        }
    }

    private fun pruneOrphanSessions(db: SQLiteDatabase, keep: Int) {
        val ids = mutableListOf<Long>()
        db.rawQuery(
            "SELECT id FROM drive_sessions WHERE trip_record_id IS NULL AND session_state<>'ACTIVE' ORDER BY id DESC LIMIT -1 OFFSET ?",
            arrayOf(keep.coerceAtLeast(0).toString())
        ).use { c -> while (c.moveToNext()) ids += c.getLong(0) }
        ids.forEach { db.delete("drive_sessions", "id=?", arrayOf(it.toString())) }
    }

    private fun currentMark(): TimeMark {
        val mark = timeSource.now()
        val epoch = mark.epochMs
        if (mark.trusted && epoch != null) {
            val offset = epoch - mark.elapsedMs
            val anchorChanged = anchoredBootId != mark.bootSessionId ||
                anchoredOffsetMs == null ||
                abs(offset - (anchoredOffsetMs ?: offset)) >= ANCHOR_REWRITE_TOLERANCE_MS
            if (anchorChanged) {
                applyTrustedAnchor(mark)
                anchoredBootId = mark.bootSessionId
                anchoredOffsetMs = offset
            }
        }
        return mark
    }

    /**
     * Rewrites every timestamp from the current boot from monotonic elapsed
     * time. This deliberately includes rows previously marked trusted: some
     * head units first expose a plausible but wrong clock and correct it after
     * GPS lock. Durations/order remain unchanged while wall time is repaired.
     */
    private fun applyTrustedAnchor(anchor: TimeMark) {
        val epoch = anchor.epochMs ?: return
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.execSQL(
                "UPDATE drive_sessions SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE drive_sessions SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE obd_samples SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_events SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE trip_records SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE start_boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE trip_records SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE end_boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_sessions SET started_at_ms=? + (started_elapsed_ms-?), start_time_trusted=1 WHERE start_boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_sessions SET ended_at_ms=? + (ended_elapsed_ms-?), end_time_trusted=1 WHERE end_boot_session_id=? AND ended_elapsed_ms IS NOT NULL",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.execSQL(
                "UPDATE test_samples SET time_ms=? + (elapsed_ms-?), time_trusted=1 WHERE boot_session_id=?",
                arrayOf(epoch, anchor.elapsedMs, anchor.bootSessionId)
            )
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun latestStoredMark(db: SQLiteDatabase, sessionId: Long): StoredMark? {
        val sql = """
            SELECT time_ms, elapsed_ms, time_trusted FROM (
                SELECT time_ms, elapsed_ms, time_trusted, id FROM obd_samples WHERE session_id=?
                UNION ALL
                SELECT time_ms, elapsed_ms, time_trusted, id FROM test_events WHERE session_id=?
            ) ORDER BY CASE WHEN elapsed_ms>0 THEN elapsed_ms ELSE time_ms END DESC, time_ms DESC, id DESC LIMIT 1
        """.trimIndent()
        var result: StoredMark? = null
        db.rawQuery(sql, arrayOf(sessionId.toString(), sessionId.toString())).use { c ->
            if (c.moveToFirst()) {
                result = StoredMark(c.getLong(0), c.getLong(1), c.getInt(2) == 1)
            }
        }
        return result
    }

    private fun latestSessionId(): Long? {
        var result: Long? = null
        readableDatabase.rawQuery("SELECT id FROM drive_sessions ORDER BY id DESC LIMIT 1", emptyArray()).use { c ->
            if (c.moveToFirst()) result = c.getLong(0)
        }
        return result
    }

    private fun createHistoryTables(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS trip_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trip_token INTEGER NOT NULL UNIQUE,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                start_boot_session_id TEXT NOT NULL,
                end_boot_session_id TEXT,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                pinned INTEGER NOT NULL DEFAULT 0,
                exported_at_ms INTEGER,
                distance_km REAL NOT NULL DEFAULT 0,
                fuel_used_l REAL NOT NULL DEFAULT 0,
                duration_ms INTEGER NOT NULL DEFAULT 0,
                average_l100 REAL,
                max_speed_kmh INTEGER,
                max_rpm INTEGER,
                start_temp_c INTEGER,
                end_temp_c INTEGER,
                sample_count INTEGER NOT NULL DEFAULT 0,
                first_session_id INTEGER,
                last_session_id INTEGER,
                created_version TEXT NOT NULL,
                note TEXT
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS test_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                drive_session_id INTEGER,
                test_type TEXT NOT NULL,
                name TEXT NOT NULL,
                started_at_ms INTEGER NOT NULL,
                ended_at_ms INTEGER,
                started_elapsed_ms INTEGER NOT NULL,
                ended_elapsed_ms INTEGER,
                start_boot_session_id TEXT NOT NULL,
                end_boot_session_id TEXT,
                start_time_trusted INTEGER NOT NULL DEFAULT 0,
                end_time_trusted INTEGER NOT NULL DEFAULT 0,
                status TEXT NOT NULL DEFAULT 'ACTIVE',
                pinned INTEGER NOT NULL DEFAULT 0,
                exported_at_ms INTEGER,
                created_version TEXT NOT NULL,
                summary TEXT,
                FOREIGN KEY(drive_session_id) REFERENCES drive_sessions(id) ON DELETE SET NULL
            )
            """.trimIndent()
        )
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS test_samples (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                test_session_id INTEGER NOT NULL,
                time_ms INTEGER NOT NULL,
                elapsed_ms INTEGER NOT NULL,
                boot_session_id TEXT NOT NULL,
                time_trusted INTEGER NOT NULL DEFAULT 0,
                loop_index INTEGER,
                loop_ms INTEGER,
                rpm INTEGER,
                speed_kmh INTEGER,
                coolant_c INTEGER,
                fuel_mg REAL,
                instant_value REAL,
                instant_unit TEXT,
                pedal_percent REAL,
                map_mbar INTEGER,
                air_charge REAL,
                ac_on INTEGER,
                fan_state TEXT,
                fuel_source TEXT,
                trip_state TEXT,
                trip_distance_km REAL,
                fuel_used_l REAL,
                avg_l100 REAL,
                raw21cc TEXT,
                raw21a0 TEXT,
                raw21a2 TEXT,
                raw21cd TEXT,
                FOREIGN KEY(test_session_id) REFERENCES test_sessions(id) ON DELETE CASCADE
            )
            """.trimIndent()
        )
    }

    private fun createCoreIndexes(db: SQLiteDatabase) {
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_samples_session_elapsed ON obd_samples(session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_events_session_elapsed ON test_events(session_id, elapsed_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sessions_state ON drive_sessions(session_state, id)")
    }

    private fun createIndexes(db: SQLiteDatabase) {
        createCoreIndexes(db)
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sessions_trip ON drive_sessions(trip_record_id, id)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_trip_records_status ON trip_records(status, pinned, ended_at_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_sessions_status ON test_sessions(status, pinned, ended_at_ms)")
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_test_samples_session_elapsed ON test_samples(test_session_id, elapsed_ms)")
    }

    private fun formatDuration(ms: Long): String {
        val totalSec = ms.coerceAtLeast(0L) / 1000L
        val hours = totalSec / 3600L
        val minutes = (totalSec % 3600L) / 60L
        val seconds = totalSec % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    private fun formatTimestamp(ms: Long, trusted: Boolean): String =
        if (trusted && ms > 0L) SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(ms)) else "TIME_PENDING"

    private fun formatTime(ms: Long): String = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(ms))

    private fun ContentValues.putTime(mark: TimeMark) {
        put("time_ms", mark.epochMs ?: 0L)
        put("elapsed_ms", mark.elapsedMs)
        put("boot_session_id", mark.bootSessionId)
        put("time_trusted", if (mark.trusted) 1 else 0)
    }

    private fun ContentValues.putNullable(key: String, value: Int?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun ContentValues.putNullable(key: String, value: Double?) {
        if (value == null) putNull(key) else put(key, value)
    }

    private fun Cursor.str(column: String): String? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getString(index) else null
    }

    private fun Cursor.long(column: String): Long = getLong(getColumnIndexOrThrow(column))

    private fun Cursor.optLong(column: String): Long? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getLong(index) else null
    }

    private fun Cursor.optInt(column: String): Int? {
        val index = getColumnIndex(column)
        return if (index >= 0 && !isNull(index)) getInt(index) else null
    }

    private data class StoredMark(val epochMs: Long, val elapsedMs: Long, val trusted: Boolean)
    private data class TestStoredMark(val epochMs: Long, val elapsedMs: Long, val bootSessionId: String, val trusted: Boolean)
    private data class RecoverableSession(
        val id: Long,
        val startedAtMs: Long,
        val startedElapsedMs: Long,
        val startTrusted: Boolean
    )

    companion object {
        private const val DB_NAME = "loganos_records.db"
        private const val DB_VERSION = 3
        private const val ANCHOR_REWRITE_TOLERANCE_MS = 1_500L
    }
}
