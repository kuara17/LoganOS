package com.dcui.loganos.obd

import android.os.SystemClock
import java.util.Locale
import kotlin.math.max
import kotlin.random.Random

data class TripComputerSnapshot(
    val state: String,
    val distanceKm: Double,
    val fuelUsedL: Double,
    val durationSec: Long,
    val averageL100: Double?,
    val displayState: String,
    val tripToken: Long
) {
    val durationText: String
        get() {
            val hours = durationSec / 3600
            val minutes = (durationSec % 3600) / 60
            val seconds = durationSec % 60
            return if (hours > 0) {
                String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
            } else {
                String.format(Locale.US, "%02d:%02d", minutes, seconds)
            }
        }
}

/** Serializable runtime state. Calculations are unchanged; this only allows a
 * short-stop trip to survive an Activity/process restart. */
data class TripComputerPersistedState(
    val tripStarted: Boolean,
    val durationMs: Long,
    val totalDistanceKm: Double,
    val totalFuelL: Double,
    val pendingDistanceKm: Double,
    val pendingFuelL: Double,
    val smoothedAverage: Double?,
    val tripToken: Long
)

class TripComputer(
    private val startSpeedKmh: Double = 5.0,
    private val startDistanceKm: Double = 0.05,
    private val avgDisplayMinDistanceKm: Double = 1.0,
    private val smoothingAlpha: Double = 0.20,
    private val smoothingIntervalMs: Long = 2000L
) {
    private var lastTimeMs: Long? = null
    private var tripStarted: Boolean = false
    private var startTimeMs: Long? = null
    private var totalDistanceKm: Double = 0.0
    private var totalFuelL: Double = 0.0
    private var pendingDistanceKm: Double = 0.0
    private var pendingFuelL: Double = 0.0
    private var smoothedAverage: Double? = null
    private var lastSmoothingMs: Long = 0L
    private var tripToken: Long = newTripToken()

    fun reset(nowMs: Long = SystemClock.elapsedRealtime()) {
        lastTimeMs = nowMs
        tripStarted = false
        startTimeMs = null
        totalDistanceKm = 0.0
        totalFuelL = 0.0
        pendingDistanceKm = 0.0
        pendingFuelL = 0.0
        smoothedAverage = null
        lastSmoothingMs = 0L
        tripToken = newTripToken()
    }

    fun update(
        speedKmh: Double?,
        fuelLh: Double?,
        nowMs: Long = SystemClock.elapsedRealtime()
    ): TripComputerSnapshot {
        val previousTime = lastTimeMs
        lastTimeMs = nowMs
        if (previousTime == null) return snapshot(nowMs)

        val dt = ((nowMs - previousTime).coerceAtLeast(0L)) / 1000.0
        if (dt <= 0.0 || dt > 10.0) {
            // Android lifecycle / sleep jumps are discarded, not backfilled.
            return snapshot(nowMs)
        }

        val speed = (speedKmh ?: 0.0).coerceAtLeast(0.0)
        val lh = (fuelLh ?: 0.0).coerceAtLeast(0.0)
        val distanceStep = speed * dt / 3600.0
        val fuelStep = lh * dt / 3600.0

        if (!tripStarted) {
            if (distanceStep > 0.0) {
                pendingDistanceKm += distanceStep
                pendingFuelL += fuelStep
            }
            if (speed > startSpeedKmh || pendingDistanceKm > startDistanceKm) {
                tripStarted = true
                startTimeMs = nowMs
                totalDistanceKm += pendingDistanceKm
                totalFuelL += pendingFuelL
                pendingDistanceKm = 0.0
                pendingFuelL = 0.0
            }
        } else {
            totalDistanceKm += distanceStep
            totalFuelL += fuelStep
        }

        updateAverage(nowMs)
        return snapshot(nowMs)
    }

    fun exportState(nowMs: Long = SystemClock.elapsedRealtime()): TripComputerPersistedState {
        val durationMs = if (tripStarted) {
            (nowMs - (startTimeMs ?: nowMs)).coerceAtLeast(0L)
        } else 0L
        return TripComputerPersistedState(
            tripStarted = tripStarted,
            durationMs = durationMs,
            totalDistanceKm = totalDistanceKm,
            totalFuelL = totalFuelL,
            pendingDistanceKm = pendingDistanceKm,
            pendingFuelL = pendingFuelL,
            smoothedAverage = smoothedAverage,
            tripToken = tripToken
        )
    }

    fun restore(state: TripComputerPersistedState, nowMs: Long = SystemClock.elapsedRealtime()) {
        tripStarted = state.tripStarted
        startTimeMs = if (state.tripStarted) nowMs - state.durationMs.coerceAtLeast(0L) else null
        totalDistanceKm = state.totalDistanceKm.coerceAtLeast(0.0)
        totalFuelL = state.totalFuelL.coerceAtLeast(0.0)
        pendingDistanceKm = state.pendingDistanceKm.coerceAtLeast(0.0)
        pendingFuelL = state.pendingFuelL.coerceAtLeast(0.0)
        smoothedAverage = state.smoothedAverage
        lastSmoothingMs = nowMs
        lastTimeMs = nowMs
        tripToken = state.tripToken.takeIf { it != 0L } ?: newTripToken()
    }

    /**
     * Removes a previously restored trip prefix while preserving samples that
     * accumulated after the current boot. Used when GPS/system time arrives
     * late and the configured stop threshold is resolved as a new trip.
     */
    fun detachRestoredPrefix(
        prefix: TripComputerPersistedState,
        nowMs: Long = SystemClock.elapsedRealtime()
    ) {
        val current = exportState(nowMs)
        val currentDistance = current.totalDistanceKm + current.pendingDistanceKm
        val currentFuel = current.totalFuelL + current.pendingFuelL
        val prefixDistance = prefix.totalDistanceKm + prefix.pendingDistanceKm
        val prefixFuel = prefix.totalFuelL + prefix.pendingFuelL
        val deltaDistance = (currentDistance - prefixDistance).coerceAtLeast(0.0)
        val deltaFuel = (currentFuel - prefixFuel).coerceAtLeast(0.0)
        val moved = deltaDistance > 0.00001
        val deltaDuration = (current.durationMs - prefix.durationMs).coerceAtLeast(0L)

        tripStarted = moved
        startTimeMs = if (moved) nowMs - deltaDuration else null
        totalDistanceKm = if (moved) deltaDistance else 0.0
        totalFuelL = if (moved) deltaFuel else 0.0
        pendingDistanceKm = if (moved) 0.0 else deltaDistance
        // Idle fuel before the new trip actually starts remains excluded, which
        // matches the existing TripComputer waiting behavior.
        pendingFuelL = if (moved) 0.0 else 0.0
        smoothedAverage = if (moved && deltaDistance >= avgDisplayMinDistanceKm) {
            (deltaFuel / max(deltaDistance, 0.0001)) * 100.0
        } else null
        lastSmoothingMs = nowMs
        lastTimeMs = nowMs
        tripToken = newTripToken()
    }

    private fun updateAverage(nowMs: Long) {
        if (totalDistanceKm < avgDisplayMinDistanceKm) return
        val raw = (totalFuelL / max(totalDistanceKm, 0.0001)) * 100.0
        if (smoothedAverage == null || nowMs - lastSmoothingMs >= smoothingIntervalMs) {
            smoothedAverage = smoothedAverage?.let { old -> old + smoothingAlpha * (raw - old) } ?: raw
            lastSmoothingMs = nowMs
        }
    }

    fun snapshot(nowMs: Long = SystemClock.elapsedRealtime()): TripComputerSnapshot {
        val duration = if (tripStarted) {
            val startedAt = startTimeMs ?: nowMs
            ((nowMs - startedAt).coerceAtLeast(0L)) / 1000L
        } else 0L
        val state = when {
            !tripStarted -> "WAITING"
            totalDistanceKm < avgDisplayMinDistanceKm -> "CALCULATING"
            else -> "ACTIVE"
        }
        val display = when (state) {
            "WAITING" -> "Sürüş bekleniyor"
            "CALCULATING" -> "Hesaplanıyor"
            else -> "Aktif"
        }
        return TripComputerSnapshot(
            state = state,
            distanceKm = totalDistanceKm,
            fuelUsedL = totalFuelL,
            durationSec = duration,
            averageL100 = smoothedAverage,
            displayState = display,
            tripToken = tripToken
        )
    }

    private fun newTripToken(): Long {
        val elapsedPart = SystemClock.elapsedRealtimeNanos()
        return elapsedPart xor Random.nextLong()
    }
}
