package com.dcui.loganos.data

data class DriveHistoryItem(
    val id: Long,
    val tripToken: Long,
    val startedAtMs: Long,
    val endedAtMs: Long?,
    val timeTrusted: Boolean,
    val status: String,
    val pinned: Boolean,
    val exported: Boolean,
    val distanceKm: Double,
    val fuelUsedL: Double,
    val durationMs: Long,
    val averageL100: Double?,
    val maxSpeedKmh: Int?,
    val maxRpm: Int?,
    val startTempC: Int?,
    val endTempC: Int?,
    val sessionCount: Int
) {
    val activeLike: Boolean get() = status == "ACTIVE" || status == "PARKED" || status == "TIME_PENDING"
}

data class TestHistoryItem(
    val id: Long,
    val name: String,
    val testType: String,
    val startedAtMs: Long,
    val endedAtMs: Long?,
    val timeTrusted: Boolean,
    val status: String,
    val pinned: Boolean,
    val exported: Boolean,
    val durationMs: Long,
    val sampleCount: Int,
    val summary: String?
) {
    val activeLike: Boolean get() = status == "ACTIVE"
}

data class HistoryStorageInfo(
    val driveRecordCount: Int = 0,
    val testRecordCount: Int = 0,
    val pinnedDriveCount: Int = 0,
    val pinnedTestCount: Int = 0,
    val driveApproxBytes: Long = 0L,
    val testApproxBytes: Long = 0L,
    val databaseBytes: Long = 0L
)
