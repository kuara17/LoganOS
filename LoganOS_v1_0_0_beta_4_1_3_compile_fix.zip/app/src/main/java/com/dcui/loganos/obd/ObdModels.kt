package com.dcui.loganos.obd

import com.dcui.loganos.data.DriveHistoryItem
import com.dcui.loganos.data.HistoryStorageInfo
import com.dcui.loganos.data.TestHistoryItem
import com.dcui.loganos.model.DashboardSnapshot

data class PairedObdDevice(
    val name: String,
    val address: String
) {
    val displayName: String get() = if (name.isBlank()) address else "$name • $address"
}



data class CrankAnalysisResult(
    val timestampMs: Long,
    val manual: Boolean,
    val durationSec: Double,
    val startVoltage: Double?,
    val minVoltage: Double?,
    val engineTempC: Int?,
    val rpmAtFinish: Int?,
    val obdGapDetected: Boolean,
    val status: String,
    val batteryStatus: String,
    val comment: String
)

data class ObdState(
    val pairedDevices: List<PairedObdDevice> = emptyList(),
    val selectedAddress: String? = null,
    val selectedName: String? = null,
    val status: String = "Bluetooth cihazı bekleniyor",
    val connected: Boolean = false,
    val connecting: Boolean = false,
    val lastError: String? = null,
    val logText: String = "",
    val snapshot: DashboardSnapshot = DashboardSnapshot.empty(),
    val raw21A0: String = "",
    val raw21A2: String = "",
    val raw21CC: String = "",
    val raw21CD: String = "",
    val timingText: String = "",
    val savedLogPath: String? = null,
    val savedLogFileName: String? = null,
    val sharedLogReady: Boolean = false,
    val activeDeveloperTest: String? = null,
    val developerTestPhaseText: String? = null,
    val developerTestRemainingSec: Int? = null,
    val developerTestDoneMessage: String? = null,
    val sqlSessionId: Long? = null,
    val sqlDbPath: String? = null,
    val loopCount: Int = 0,
    val noDataCount: Int = 0,
    val stoppedCount: Int = 0,
    val busInitCount: Int = 0,
    val slowLoopCount: Int = 0,
    val timeTrusted: Boolean = true,
    val rawEcuLogEnabled: Boolean = false,
    val longTripLogEnabled: Boolean = false,
    val manualCrankArmed: Boolean = false,
    val crankingInProgress: Boolean = false,
    val lastAutoCrankResult: CrankAnalysisResult? = null,
    val recentAutoCrankResults: List<CrankAnalysisResult> = emptyList(),
    val savedManualCrankTests: List<CrankAnalysisResult> = emptyList(),
    val driveHistory: List<DriveHistoryItem> = emptyList(),
    val testHistory: List<TestHistoryItem> = emptyList(),
    val historyStorage: HistoryStorageInfo = HistoryStorageInfo(),
    val exportInProgress: Boolean = false
)
