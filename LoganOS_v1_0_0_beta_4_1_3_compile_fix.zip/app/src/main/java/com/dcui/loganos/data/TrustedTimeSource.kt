package com.dcui.loganos.data

import android.content.Context
import android.os.SystemClock
import java.io.File
import java.util.UUID
import kotlin.math.abs

/**
 * Monotonic + wall-clock time source for Android head units whose date/time may
 * arrive late from GPS. elapsedRealtime is always used for durations; epoch
 * time is exposed only after a trustworthy wall-clock anchor is available.
 *
 * A short first-launch settling window deliberately keeps new boot records in
 * TIME_PENDING state. When Android/GPS corrects the clock, the same-boot
 * elapsed timestamps can be anchored without changing event order or duration.
 */
data class TimeMark(
    val epochMs: Long?,
    val elapsedMs: Long,
    val bootSessionId: String,
    val trusted: Boolean
)

class TrustedTimeSource(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val trustedEpochFloorMs: Long = MIN_TRUSTED_EPOCH_MS
    private val sourceCreatedElapsedMs = SystemClock.elapsedRealtime()
    private val bootSessionId: String = resolveBootSessionId()
    private var lastElapsedPersistMs: Long = prefs.getLong(KEY_LAST_ELAPSED, -1L)

    @Synchronized
    fun now(): TimeMark {
        val elapsed = SystemClock.elapsedRealtime()
        if (lastElapsedPersistMs < 0L || elapsed - lastElapsedPersistMs >= ELAPSED_PERSIST_INTERVAL_MS) {
            prefs.edit().putLong(KEY_LAST_ELAPSED, elapsed).apply()
            lastElapsedPersistMs = elapsed
        }

        val wall = System.currentTimeMillis()
        val wallPlausible = wall >= trustedEpochFloorMs
        val anchorBoot = prefs.getString(KEY_ANCHOR_BOOT, null)
        val anchorEpoch = prefs.getLong(KEY_ANCHOR_EPOCH, 0L)
        val anchorElapsed = prefs.getLong(KEY_ANCHOR_ELAPSED, 0L)
        val sameBootAnchor = anchorBoot == bootSessionId && anchorEpoch >= trustedEpochFloorMs

        if (sameBootAnchor) {
            val predictedEpoch = anchorEpoch + (elapsed - anchorElapsed)
            if (wallPlausible && abs(wall - predictedEpoch) >= CLOCK_JUMP_REANCHOR_MS) {
                // GPS/network/system clock changed materially. Publish the new
                // anchor; LoganSqlStore re-anchors every row from this boot.
                saveAnchor(wall, elapsed)
                return TimeMark(wall, elapsed, bootSessionId, trusted = true)
            }
            return TimeMark(predictedEpoch, elapsed, bootSessionId, trusted = true)
        }

        val settledLongEnough = elapsed - sourceCreatedElapsedMs >= INITIAL_CLOCK_SETTLE_MS
        if (wallPlausible && settledLongEnough) {
            saveAnchor(wall, elapsed)
            return TimeMark(wall, elapsed, bootSessionId, trusted = true)
        }

        return TimeMark(null, elapsed, bootSessionId, trusted = false)
    }

    fun isTrusted(): Boolean = now().trusted

    fun gapMillis(older: TimeMark?, newer: TimeMark): Long? {
        if (older == null) return null
        if (older.bootSessionId == newer.bootSessionId) {
            return (newer.elapsedMs - older.elapsedMs).coerceAtLeast(0L)
        }
        val oldEpoch = older.epochMs
        val newEpoch = newer.epochMs
        return if (older.trusted && newer.trusted && oldEpoch != null && newEpoch != null) {
            (newEpoch - oldEpoch).coerceAtLeast(0L)
        } else null
    }

    private fun saveAnchor(epochMs: Long, elapsedMs: Long) {
        prefs.edit()
            .putString(KEY_ANCHOR_BOOT, bootSessionId)
            .putLong(KEY_ANCHOR_EPOCH, epochMs)
            .putLong(KEY_ANCHOR_ELAPSED, elapsedMs)
            .apply()
    }

    private fun resolveBootSessionId(): String {
        val kernelBootId = runCatching {
            File("/proc/sys/kernel/random/boot_id").readText().trim().takeIf { it.isNotBlank() }
        }.getOrNull()
        if (kernelBootId != null) {
            prefs.edit()
                .putString(KEY_BOOT_SESSION, kernelBootId)
                .putLong(KEY_LAST_ELAPSED, SystemClock.elapsedRealtime())
                .apply()
            return kernelBootId
        }

        val elapsed = SystemClock.elapsedRealtime()
        val storedElapsed = prefs.getLong(KEY_LAST_ELAPSED, -1L)
        var storedId = prefs.getString(KEY_BOOT_SESSION, null)
        if (storedId == null || (storedElapsed >= 0L && elapsed + REBOOT_TOLERANCE_MS < storedElapsed)) {
            storedId = UUID.randomUUID().toString()
        }
        prefs.edit()
            .putString(KEY_BOOT_SESSION, storedId)
            .putLong(KEY_LAST_ELAPSED, elapsed)
            .apply()
        return storedId
    }

    companion object {
        // 2026-01-01 UTC. beta.4 is released in 2026, so older boot dates are not trustworthy.
        private const val MIN_TRUSTED_EPOCH_MS = 1_767_225_600_000L
        private const val INITIAL_CLOCK_SETTLE_MS = 20_000L
        private const val CLOCK_JUMP_REANCHOR_MS = 2_000L
        private const val REBOOT_TOLERANCE_MS = 60_000L
        private const val ELAPSED_PERSIST_INTERVAL_MS = 30_000L
        private const val PREFS_NAME = "loganos_trusted_time"
        private const val KEY_BOOT_SESSION = "boot_session_id"
        private const val KEY_LAST_ELAPSED = "last_elapsed_ms"
        private const val KEY_ANCHOR_BOOT = "anchor_boot_session_id"
        private const val KEY_ANCHOR_EPOCH = "anchor_epoch_ms"
        private const val KEY_ANCHOR_ELAPSED = "anchor_elapsed_ms"
    }
}
