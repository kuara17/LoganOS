# LoganOS v1.0.0-beta.4.1.3

## Uygulanan değişiklikler
- Double kokpit geniş ekran için yeniden düzenlendi: solda tek sürüş özeti kartı, ortada büyük hız göstergesi, sağda üstte ortalama ve altında anlık tüketim.
- Kiraz kırmızısı Logan arka görünüş PNG asset'i hem telefon hem double hız göstergesine eklendi.
- Fan simgesi, fan durumu ve “Hararet / Fan” kullanıcı arayüzünden kaldırıldı; yalnızca doğrulanmış hararet değeri gösteriliyor.
- Onaylı ikonlar Fit/merkez yaklaşımıyla korunuyor; sıcaklık kartı artık ayrı coolant asset kullanıyor.
- Güvenilir saat beklenirken eski sürüş toplamları canlı kokpitte gösterilmiyor.
- Manuel sürüş bitirme bağlı SQL oturumunu da ENDED_MANUAL olarak kapatıyor.
- Tüm geçmiş exportu aynı anda yalnızca bir kez çalışıyor, işlem durumunu gösteriyor ve ham log açıksa ham ECU paketlerini dahil ediyor.
- Geçmiş ZIP içindeki sürüş dosya adları kayıt ID'si ve başlangıç zaman damgasıyla sadeleştirildi.

## Dokunulmayan çekirdek
DelphiParser, FuelAlgorithmV3, injection mg/stroke hesabı, CUTOFF, COAST_GUARD, KWP polling ve AC_FAST ana biti değiştirilmedi.

## Derleme notu
Bu çalışma ortamında Gradle aracı bulunmadığı için yerel APK derlemesi çalıştırılamadı. GitHub Actions ile assembleDebug/assembleRelease doğrulaması yapılmalıdır.
