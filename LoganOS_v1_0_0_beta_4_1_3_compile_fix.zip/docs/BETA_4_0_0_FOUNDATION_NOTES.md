# beta.4.0.0 Foundation Notes

## Kabul testleri

1. Aynı imzaya sahip beta.3.9.3 kurulumu beta.4.0.0 ile güncellendiğinde uygulama verisi silinmemeli ve SQL v1 kayıtları okunabilmeli. Eski geçici GitHub debug anahtarı farklıysa bir defalık kaldırıp kurma gerekebileceği açıkça belirtilmeli.
2. OBD/KWP bağlantısı, 21A0/21CC polling, parser ve FuelAlgorithmV3 önceki sürümle aynı davranmalı.
3. Uygulama açıldıktan sonra double teybin saati henüz yanlışsa başlıkta `Saat eşitleniyor…` görünmeli; süre/loop sırası çalışmaya devam etmeli.
4. Sistem saati düzeldiğinde yeni exportta gerçek saatler görünmeli, süreler değişmemeli.
5. Kısa kontak kapatma/açma, seçilen 30/60/90 dakika sınırının altındaysa trip devam etmeli.
6. Eşik aşılmışsa yeni trip başlamalı. Saat güvenilir değilse karar saat anchor’ına kadar ertelenmeli.
7. `Sürüşü şimdi bitir` onaydan sonra trip toplamlarını kapatmalı; sonraki hareket yeni trip token ile başlamalı.
8. Otomatik / Telefon / Double seçimi Setup Wizard sıfırlanmadan çalışmalı.
9. Yazı Boyutu ve Kokpit Yoğunluğu seçenekleri hem portre hem yatay kokpitte gözle görülür fark üretmeli.
10. Küçük telefonda kırpılma, büyük telefonda aşırı küçük gösterge, double teypte gereksiz scroll olmamalı.
11. Digital OEM yay kusursuz dairesel görünmeli; başlık ve üst header ile çakışmamalı.
12. Ortalama, Anlık, Mesafe, Maliyet, Hararet/Fan, Klima, Devir ve Süre ikonları kırpılmamalı.
13. Aktif OBD bağlantısı varken tüm SQL/log temizleme engellenmeli.
14. GitHub Actions debug APK üretmeli. Release, secrets hazırlandıktan sonra aynı kalıcı anahtarla imzalanmalı.

## Veri şeması v2

Yeni zaman alanları eski kayıtları silmeden eklenir:

- `started_elapsed_ms`, `ended_elapsed_ms`
- `boot_session_id`
- `start_time_trusted`, `end_time_trusted`, `time_trusted`
- `session_state`

Legacy kayıtlar `boot_session_id=legacy` ve güvenilir eski wall-clock zamanı ile korunur. Yeni boot kayıtları monotonic zamandan eşlenir.

## Kapsam sınırı

Bu sürüm geçmiş listeleme/retention veya OTA indirme istemcisi içermez. Ama kalıcı release imza zinciri, güvenli DB ve zaman temeli sonraki sürümlerin ön koşuludur.
