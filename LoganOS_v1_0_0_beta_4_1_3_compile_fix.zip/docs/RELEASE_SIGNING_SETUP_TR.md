# LoganOS Kalıcı Release İmzası — GitHub Kurulumu

Bu işlem yalnızca bir kez yapılır. Anahtar kaybedilirse mevcut release kurulumlarının üzerine yeni APK yüklemek mümkün olmayabilir.

## 1. Keystore oluştur

Bilgisayarda JDK kurulu bir terminalde:

```bash
keytool -genkeypair \
  -v \
  -keystore loganos-release.jks \
  -alias loganos \
  -keyalg RSA \
  -keysize 4096 \
  -validity 10000
```

Şifreleri güçlü ve benzersiz seç. `loganos-release.jks` dosyasını kaynak depoya veya proje ZIP’ine koyma. İki ayrı şifreli yedek oluştur.

## 2. Base64 hazırla

### Windows PowerShell

```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("loganos-release.jks")) | Set-Content -NoNewline loganos-keystore-base64.txt
```

### Linux/macOS

```bash
base64 -w 0 loganos-release.jks > loganos-keystore-base64.txt
```

macOS `base64` komutu `-w` desteklemiyorsa:

```bash
base64 < loganos-release.jks | tr -d '\n' > loganos-keystore-base64.txt
```

## 3. GitHub Secrets ekle

Repo → Settings → Secrets and variables → Actions → New repository secret:

- `LOGANOS_KEYSTORE_BASE64`: base64 metninin tamamı
- `LOGANOS_STORE_PASSWORD`: keystore şifresi
- `LOGANOS_KEY_ALIAS`: `loganos` (başka alias seçtiysen onu yaz)
- `LOGANOS_KEY_PASSWORD`: anahtar şifresi

## 4. Workflow

Actions → `Build LoganOS APK` → Run workflow:

- İlk cihaz/UI testi: `debug`
- Kalıcı dağıtım: `release`

Secrets tanımlıysa debug APK da aynı kalıcı anahtarla imzalanır; böylece sonraki debug test sürümleri birbirinin üzerine kurulabilir. Secrets yoksa debug derlemesi geçici runner anahtarıyla yine oluşur, ancak bir sonraki GitHub çalışmasındaki APK onun üzerine kurulamayabilir. Release işi secrets eksikse bilinçli olarak durur.

Başarılı işte APK ve `.sha256` artifact olarak oluşur; release APK imzası `apksigner verify` ile kontrol edilir.

## 5. Önemli paket farkı

- Debug: `com.dcui.loganos.debug`
- Release: `com.dcui.loganos`

Bu yüzden mevcut debug sürümden ilk release sürüme geçiş Android tarafından ayrı uygulama olarak görülür. Ayrıca eski GitHub debug APK geçici bir runner anahtarıyla imzalandıysa beta.4 debug APK için bir defalık kaldırıp kurma gerekebilir. İlk kalıcı imzalı debug/release kurulumundan sonra aynı paket türündeki sürümler birbirinin üzerine kurulabilir. Her yeni sürümde `versionCode` artırılmalıdır.

## Güvenlik

- Keystore’u ChatGPT/Gemini/Claude’a yükleme.
- GitHub repo dosyalarına commit etme.
- Şifreleri belge/README içinde yazma.
- Yedeklerin en az biri çevrimdışı ve şifreli olsun.
