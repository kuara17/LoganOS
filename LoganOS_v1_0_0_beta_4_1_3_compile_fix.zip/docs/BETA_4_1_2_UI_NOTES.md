# LoganOS beta.4.1.2 UI Notes

## Scope

This patch is limited to UI presentation, settings organization and demo-display consistency.

## Cockpit icon mapping

The generated beta.4.1.1 `cockpit_*.png` files are removed from the active project. The active `approved_*.png` resources are normalized copies of the existing selected `asset_*.png` artwork:

- FuelAverage → `asset_fuel_average.png`
- FuelInstant → `asset_fuel_instant.png`
- Distance → `asset_distance.png`
- Cost → `asset_trip_cost.png`
- TemperatureFan → `asset_temp_fan.png`
- AC → `asset_ac.png`
- RPM → `asset_rpm.png`
- Time → `asset_trip_time.png`

Each output uses a 512×512 transparent canvas, centered optical artwork and at least 46 px safety margin. Compose uses the existing beta.4.1.1 icon slot size with `ContentScale.Fit` and no runtime drawing/cropping/offset.

## Static checks completed

- All XML resources parsed successfully.
- GitHub Actions YAML parsed successfully.
- All `R.drawable.*` references resolve to a resource.
- Kotlin source delimiter/string/comment scan completed successfully.
- ZIP must still be built by GitHub Actions for a real Android/Compose compile and device render test.

## Frozen files

The following files are byte-for-byte unchanged from beta.4.1.1:

- `DelphiParser.kt`
- `FuelAlgorithmV3.kt`
- `TripComputer.kt`
- `ObdController.kt`
- `LoganSqlStore.kt`
- `TrustedTimeSource.kt`
