## 1.0.0-beta.4.1.3
- Double cockpit redesigned for large displays with larger speed, a single trip summary card and stacked average/instant consumption.
- Added approved cherry-red Logan rear PNG to phone and double speed panels.
- Removed fan UI/status; coolant temperature remains.
- Fixed history export duplication feedback and raw packet inclusion.
- Manual trip finish now closes the linked SQL session.

# LoganOS Changelog

## 1.0.0-beta.4.1.2 — UI Cleanup & Settings Reorganization

- 4.1.1’deki gösterge, kart, yazı ve ikon yuvası ölçüleri korunarak yalnızca kalan UI sorunları düzeltildi.
- Sonradan çizilip rasterize edilen `cockpit_*.png` ikonları kaldırıldı; daha önce seçilen LoganOS ikon artwork’lerinin mevcut `asset_*.png` kaynakları kullanıldı.
- Seçilen ikonların şeffaf tuvalleri normalize edildi; tüm ikonlar ortak 512×512 tuvalde merkezlenip aynı optik ölçüye getirildi. Runtime Canvas çizimi, `Crop`, rastgele offset ve asimetrik padding kullanılmıyor.
- Ortalama, Anlık, Mesafe, Maliyet, Hararet/Fan, Klima, Devir ve Sürüş Süresi ikonları `ContentScale.Fit` ile ortak büyük yuvada tamamen görünür hale getirildi. Kaynak görsel kenar kalıntıları temizlendi; yeni ikon şekli çizilmedi.
- Kokpitte alt navigasyonun arkasında kalan içerik için güvenli alt boşluk artırıldı; tekrarlanan ve kesilen “Demo veri” altyazıları kaldırıldı.
- Sürüş Merkezi’nde uzun `L/100 km` biriminin ve alt açıklamanın kırpılması engellendi; Ortalama ve Süre kartlarının güvenli yüksekliği artırıldı.
- Güncel yolculuk açıklaması gerçek bağlantı/trip durumuna bağlandı: demo aktif, sürüş aktif, hareket bekleniyor veya OBD bekleniyor.
- Kısa sürüşlerde kullanılan yakıt `0.0 L` yerine iki ondalıkla gösteriliyor; 1 litre ve üzeri değerler tek ondalıkla gösteriliyor.
- Demo sürüş süresi tüm ekranlarda ileri doğru ilerleyen ortak snapshot zamanına bağlandı; sekme değişiminde geriye gitmesi önlendi.
- Sürüş geçmişi özeti “Sabit kayıtlar korunur” şeklinde kısaltıldı.
- Dil ayarındaki gereksiz ikinci “Uygulama dili” adımı kaldırıldı; Dil ekranı açıldığında Türkçe ve English seçenekleri doğrudan gösteriliyor.
- “Bağlantı & Veri” ayrıldı: normal kullanıcı için ayrı **Bağlantı** ve **Sürüş ve Kayıtlar** bölümleri oluşturuldu.
- Smart Trip süresi, sürüşü şimdi bitir, geçmiş limitleri, depolama bilgisi, toplu dışa aktarma ve temizleme işlemleri **Sürüş ve Kayıtlar** bölümünde toplandı.
- Ham ECU logu, teknik testler, teknik log dışa aktarma/paylaşma ve destek paketi yalnızca **Geliştirici** bölümünde tutuldu.
- Hakkında ekranının tipografi hiyerarşisi sadeleştirildi; gövde metinleri eşitlendi ve “Türkçe ana dildir. İngilizce çeviri AI desteklidir.” satırı kaldırıldı. GPLv3, gizlilik, bağımsızlık ve AI geliştirme araçları açıklamaları korundu.
- Sürüm `1.0.0-beta.4.1.2`, versionCode `100000412` yapıldı.
- OBD/KWP polling, Delphi parser, FuelAlgorithmV3, injection mg/stroke, CUTOFF/COAST_GUARD, AC_FAST, fan `UNKNOWN`, veritabanı migration/History ve TripComputer hesaplama çekirdeği değiştirilmedi.

## 1.0.0-beta.4.1.1 — Cockpit & OBD UX Polish

- Ana kokpitte gereksiz “HIZ” başlığı kaldırıldı; aynı gösterge alanı içinde Digital OEM kadranı büyütüldü. Kurulum önizlemesindeki başlık korunur.
- Digital OEM kadranının dairesel/alan-duyarlı çizimi ve History/Reliability altyapısı korunarak yalnızca kokpit yerleşimi iyileştirildi.
- Önceden belirlenen kokpit sembolleri yüksek çözünürlüklü, normalize edilmiş bitmap asset’lere dönüştürüldü; uygulama içinde yeni ikon çizimi yapılmıyor.
- Ortalama, Anlık, Mesafe, Maliyet, Hararet/Fan, Klima, Devir ve Sürüş Süresi ikonları ortak büyük yuvada, merkezde ve `ContentScale.Fit` ile tam görünür çiziliyor.
- Hararet/Fan tek dengeli asset olarak kullanılıyor; gri balon, runtime offset ve kırpma hileleri kaldırıldı.
- Kart başlıkları için eşit yükseklikte başlık alanı, değer/birim için ortak baseline ve eşit altyazı alanı eklendi; sağ/sol sütun hizası düzeltildi.
- Portre kokpit metrik satırları kullanılabilir ekran yüksekliğini daha dengeli dolduracak şekilde hesaplanıyor; alttaki gereksiz boşluk azaltıldı.
- Yazı Boyutu profilleri belirginleştirildi: Küçük 0.90×, Normal 1.00×, Büyük 1.22×.
- Kokpit ikon yuvaları ve metin ölçüleri büyütüldü; yoğunluk profillerinde gösterge okunamayacak kadar küçülmüyor.
- LOGANOS wordmark sola hizalandı; OBD durum pill’i ve menü sağ blok olarak ayrıldı.
- Kokpit üç nokta menüsü daha görünür ve daha geniş dokunma alanlı hale getirildi.
- OBD durum pill’i tıklanabilir yapıldı. Araç dururken pill üzerinden son kullanılan/eşleşmiş adaptör seçilip doğrudan bağlanılabilir.
- OBD bağlıyken pill; bağlı cihaz, “Bağlantıyı kes” ve “Cihaz değiştir” işlemlerini gösterir.
- Araç hareket halindeyken OBD cihaz seçimi güvenlik nedeniyle engellenir ve kısa uyarı gösterilir.
- Sürüm `1.0.0-beta.4.1.1`, versionCode `100000411` yapıldı.
- OBD/KWP polling, Delphi parser, FuelAlgorithmV3, CUTOFF/COAST_GUARD ve TripComputer hesaplama formülleri değiştirilmedi.

## 1.0.0-beta.4.1.0 — History

- SQLite şeması v3'e yükseltildi; v2 → v3 migration kayıtları silmeden `trip_records`, `test_sessions` ve `test_samples` tablolarını ekler.
- Tamamlanan sürüşler Smart Trip token'ı üzerinden otomatik olarak tek geçmiş kaydında birleştirilir.
- Kısa moladan sonra devam eden OBD oturumları aynı sürüş kaydına bağlanır; uzun mola veya “Sürüşü şimdi bitir” kaydı tamamlar.
- Manuel marş ve geliştirici testleri otomatik Test Geçmişi'ne yazılır; güç/kontak kesintisi durumunda `INTERRUPTED` olarak kurtarılır.
- Sürüş ve test geçmişi için varsayılan 10 kayıt; 25, 50 ve sınırsız saklama seçenekleri eklendi.
- Sabitle/Koru, İncele, Dışa aktar, Sil ve Tüm geçmişi dışa aktar işlemleri eklendi.
- Limit düşürülürken silinecek eski kayıtlar için onay ekranı eklendi.
- Otomatik geçmiş kapatılırken mevcut kayıtların korunacağı açıkça belirtilen onay eklendi; sınırsız saklama seçiminde depolama uyarısı gösterilir.
- Limit düşürme onayındaki silinecek kayıt sayısı yalnızca sabitlenmemiş ve aktif olmayan kayıtlar üzerinden hesaplanır.
- Kayıt sayısı, sabitlenen kayıtlar ve yaklaşık depolama kullanımı Ayarlar > Bağlantı & Veri'de gösterilir.
- Aktif/PARKED/TIME_PENDING sürüşler ile aktif testler silme ve otomatik retention dışında tutulur.
- Eski `drive_sessions` kayıtları otomatik temizlenmez; beta loglarının sessizce kaybolması engellendi.
- “Tüm Kayıtları ve Logları Temizle” onayı sürüş/test geçmişi, SQL örnekleri ve indirilen LoganOS loglarının kapsamını açıkça belirtir.
- Güç kesintisinden kurtarılan PARKED sürüşlerde son gerçek kayıt zamanı korunur; sonraki uygulama açılış saati bitiş zamanı olarak yazılmaz.
- OBD/KWP/parser/FuelAlgorithmV3/CUTOFF/COAST_GUARD/TripComputer core logic değiştirilmedi.

# LoganOS v1.0.0-beta.4.0.0 — Reliability Foundation

## Veri ve güç kesintisi güvenliği
- SQLite şeması `v2` yapıldı.
- beta.3.9.3 kayıtlarını silmeden taşıyan `v1 -> v2` migration eklendi.
- Destructive `DROP TABLE` yükseltmesi kaldırıldı.
- WAL ve foreign-key desteği etkinleştirildi.
- Ani kontak/güç kesintisinde ACTIVE kalan SQL oturumları son örnek/olay zamanı ile `RECOVERED` olarak kapatılıyor.
- Aktif OBD oturumu varken “Tüm logları temizle” işlemi engelleniyor.

## Güvenilir zaman
- Süreler `SystemClock.elapsedRealtime()` ile hesaplanıyor.
- Her Android açılışı için boot session kimliği tutuluyor.
- İlk açılışta GPS/sistem saati beklenirken kayıtlar `TIME_PENDING` olarak sıralı biçimde tutuluyor.
- Güvenilir saat geldiğinde aynı boot içindeki geçmiş satırlar monotonic zamandan geriye dönük eşleniyor.
- Sistem/GPS saati sonradan değişirse aynı boot kayıtları yeni anchor ile tekrar düzeltiliyor.
- Log/destek paketi adları güvenilir saat yokken yanlış 1970/2020 tarihi kullanmıyor.

## Smart Trip
- Varsayılan mola eşiği 60 dakika.
- Ayarlar: her kontakta yeni sürüş / 30 / 60 / 90 dakika.
- Kısa mola sonrası trip toplamları process/Activity yeniden başlatmalarında korunuyor.
- Sert güç kesintisinde son 3 saniyelik runtime checkpoint, stop zamanı için yedek kaynak olarak kullanılıyor.
- “Sürüşü şimdi bitir” işlemi kokpit menüsüne ve Ayarlar’a eklendi.
- Marş süresi ölçümü duvar saatinden ayrılıp monotonic zamana taşındı.

## Cihaz ve uyarlanabilir arayüz
- Cihaz modu: Otomatik / Telefon / Android Multimedya-Double.
- Double modu yataya kilitli; Telefon serbest; Otomatik ekran/araç UI özelliklerinden karar veriyor.
- Küçük, standart ve büyük telefonlarla kısa/uzun yatay ekranlar için responsive ölçüler eklendi.
- Yazı Boyutu artık kart metinleriyle birlikte hız göstergesi başlık/rakam/birimini de etkiliyor.
- Gerçekte bir foreground service başlatmayan “Arka planda kaydı sürdür” anahtarı tamamlanana kadar arayüzden gizlendi.
- Kokpit Yoğunluğu portrede kart/gösterge yüksekliğini, yatayda gösterge-metrik alan oranını ve boşlukları etkiliyor.
- Digital OEM dairesel kalacak şekilde kullanılabilir genişlik/yükseklikten hesaplanıyor.
- Ana kokpit ikonları kırpılmış PNG’ler yerine temiz ve ölçeklenebilir vector drawable setine geçirildi.
- Hararet/Fan işareti tek 44dp optik alanda, çerçevesiz ve kırpılmadan çiziliyor.

## Release temeli
- Sürüm: `1.0.0-beta.4.0.0`, versionCode: `100000400`.
- GitHub Actions’a debug/release seçimi ve kalıcı imza desteği eklendi; secrets varsa debug test APK’ları da tutarlı imzalanıyor.
- Release APK için SHA-256 ve `apksigner` doğrulaması eklendi.
- Keystore projeye/ZIP’e eklenmez; GitHub Secrets üzerinden verilir.

## Hakkında
- Renault Group/Dacia ile resmî bağlantı bulunmadığı açıklaması eklendi.
- ChatGPT, Gemini ve Claude AI araçlarından yararlanıldığı şeffaf biçimde belirtildi.

## Bilerek yapılmayanlar
- Sürüş/Test geçmişi ve son 10 otomatik kayıt: beta.4.1.0
- Uygulama içi GitHub OTA ve yedekleme: beta.4.2.0
- Yeni gösterge stilleri: altyapı ve Digital OEM tamamen doğrulanana kadar ertelendi.
