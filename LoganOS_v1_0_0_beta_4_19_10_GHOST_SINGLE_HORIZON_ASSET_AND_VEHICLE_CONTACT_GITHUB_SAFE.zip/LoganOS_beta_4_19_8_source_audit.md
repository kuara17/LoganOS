# LoganOS beta.4.19.8 Source Audit

## Scope

- Base package: `1.0.0-beta.4.19.7`.
- New version: `1.0.0-beta.4.19.8` / versionCode `100000708`.
- Scope is isolated to Ghost Single Original source, its asset renderer/assets, preview, validation rules, and release documentation.

## Corrected implementation

- Removed runtime accent tint from `ghost_single_original_road_edges.webp`; road boundaries remain fixed white.
- Removed `RoadFadeLayer` and its unsupported coloured horizontal rectangle.
- Added true alpha fade to road base, edges and sheen assets between logical Y=468 and Y=512.
- Reduced road geometry to top half-width 24 and bottom half-width 188; bottom Y is 704.
- Rebuilt all six horizon assets with centre-weighted glow and no full-width crisp line.
- Preserved the horizon source ratio (`1846x180`) in Compose and anchored it inside the central reference cluster.
- Removed the post-car `VehicleContactLayer`; regenerated both shadow assets and kept them behind the car.
- Repositioned centre data so speed is above the separator and RPM is below it.
- Reduced needle width, tail, hub and active progress-arc visual weight.
- Reused the approved `cockpit_coolant`, `cockpit_fuel_instant`, and `cockpit_fuel_average` assets at larger sizes beside their headings.
- Updated the packaged settings preview to use the same white-road and horizon rules.

## Data policy

No unsupported values were introduced. Ghost Single Original still exposes only trusted/live speed, RPM, coolant temperature, instant consumption, average consumption, and connection/demo status.

## Validation

- `tools/preflight_source.py`: PASS.
- `tools/validate_ghost_single_original.py`: PASS, including pixel-level road fade and horizon checks.
- `tools/validate_release.py`: PASS.
- Android SDK/Gradle wrapper is not included in this source package, so an actual APK build was not executed in this environment.
