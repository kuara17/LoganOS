# LoganOS AI Review Pack — beta.4.19.8

## Goal

Bring Ghost Single Original closer to the supplied Megane-style reference without inventing vehicle data or adding new scene concepts.

## Architectural decisions

- Static dial numerals, road, horizon and calibrated shadows remain assets.
- Speed, RPM, coolant and consumption values remain live Compose layers.
- Accent selection affects the horizon and live dial progress only; road edges are permanently white.
- Road disappearance is encoded in asset alpha rather than a fake Compose overlay.
- Gauge, road, horizon, car and shadows share the same `1000x760` central reference coordinate system.

## Key source changes

### `GhostSingleOriginalCockpit.kt`

- Removed `RoadFadeLayer`, `VehicleContactLayer`, road-edge tint and road-sheen tint.
- Moved horizon rendering into `CentralReferenceCluster` and preserved `1846:180` aspect ratio.
- Moved speed to `cy=0.315`, `km/h` to `cy=0.382`, and RPM below the separator at `cy=0.478`.
- Reduced needle geometry and added a restrained centre readout shield.
- Enlarged and realigned approved coolant/instant/average icons.
- Vignette now sits behind live side information.

### `render_ghost_single_original_assets.py`

- Road: `TOP_Y=468`, `FADE_END_Y=512`, `BOTTOM_Y=704`, top half-width `24`, bottom half-width `188`.
- Road base/edges/sheen share a physical alpha fade.
- Road edges are generated fixed white.
- Road sheen is neutral.
- Horizon uses a central glow with side falloff and no full-width hard line.
- Shadows and settings preview were regenerated.

## Validation additions

- Reject road accent tint and the retired overlay functions.
- Verify road-edge alpha is zero at its top and rises progressively.
- Verify horizon alpha is centre-weighted and absent at far side samples.
- Verify RPM is below the separator and approved icon assets are wired.

## Review questions

1. Does the actual Double device preserve the intended road-to-horizon gap after Compose scaling?
2. Is the thinner needle readable without covering the centre values?
3. Do the three existing icon assets remain visually balanced at the larger runtime size?
4. Does the recalibrated shadow remove the pasted-on look for every selectable Logan asset/model?
