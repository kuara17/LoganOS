#!/usr/bin/env python3
from pathlib import Path
from PIL import Image

root = Path(__file__).resolve().parents[1]
res = root / "app/src/main/res/drawable-nodpi"
source_path = root / "app/src/main/java/com/dcui/loganos/ui/cockpit/GhostSingleOriginalCockpit.kt"
source = source_path.read_text(encoding="utf-8")
models = (root / "app/src/main/java/com/dcui/loganos/model/Models.kt").read_text(encoding="utf-8")
dashboard = (root / "app/src/main/java/com/dcui/loganos/ui/screens/DashboardScreen.kt").read_text(encoding="utf-8")
main = (root / "app/src/main/java/com/dcui/loganos/MainActivity.kt").read_text(encoding="utf-8")
settings = (root / "app/src/main/java/com/dcui/loganos/ui/screens/SettingsScreen.kt").read_text(encoding="utf-8")
generator_path = root / "tools/render_ghost_single_original_assets.py"
generator = generator_path.read_text(encoding="utf-8")


def require(cond, msg):
    if not cond:
        raise SystemExit(f"[FAIL] {msg}")
    print(f"[PASS] {msg}")


stage_assets = [
    "ghost_single_original_background.webp",
    "ghost_single_original_preview.webp",
    "ghost_single_original_vignette.webp",
]
cluster_assets = [
    "ghost_single_original_gauge_shell.webp",
    "ghost_single_original_road_base.webp",
    "ghost_single_original_road_edges.webp",
    "ghost_single_original_road_sheen.webp",
    "ghost_single_original_shadow_contact.webp",
    "ghost_single_original_shadow_soft.webp",
]
horizons = [f"ghost_single_original_horizon_{c}.webp" for c in ["purple", "red", "green", "white", "blue", "yellow"]]

for name in stage_assets:
    p = res / name
    require(p.exists(), f"stage asset exists: {name}")
    require(Image.open(p).size == (1846, 852), f"stage asset uses 1846x852: {name}")
for name in cluster_assets:
    p = res / name
    require(p.exists(), f"cluster asset exists: {name}")
    require(Image.open(p).size == (1000, 760), f"cluster asset uses undistorted 1000x760 reference space: {name}")
for name in horizons:
    p = res / name
    require(p.exists(), f"horizon asset exists: {name}")
    require(Image.open(p).size == (1846, 180), f"horizon is a thin 1846x180 strip: {name}")

require("GhostSingleOriginal(\"Ghost Single Original\")" in models, "separate GaugeStyle identity exists")
require("GhostOriginalAccent" in models, "separate accent enum exists")
require("fun GhostSingleOriginalCockpit" in source, "isolated cockpit composable exists")
require("GhostSingleV2" not in source, "retired V2 identity is not reused")
require("GhostSingleOriginalCockpit(" in dashboard, "dashboard routes to the isolated cockpit")
require("settings.gaugeStyle == GaugeStyle.GhostSingleOriginal" in dashboard, "dashboard branch is separately keyed")
require("GaugeStyle.GhostSingleOriginal" in main and "SCREEN_ORIENTATION_LANDSCAPE" in main, "phone orientation remains landscape-only")
require("Ghost Single Original ışık rengi" in settings, "dedicated glow-colour setting is exposed")
require("CentralReferenceCluster" in source, "gauge, road and car share one reference coordinate system")
require("clusterWidth * 0.76f" in source, "central cluster preserves the 1000x760 asset ratio")
require("RoadMotionLayer" not in source, "invented moving motorway lines are removed")
require("TemperatureBlock" not in source and "LeftInformationPanel" in source, "coolant moved from road bottom to the left information zone")
require("RightInformationPanel" in source, "average-consumption zone is enlarged and independent")
require("vehicleVisualDrawableRes" in source, "existing Logan I/III asset selector is reused")
require("GhostSpeedMaxKmh = 200" in source, "live speed is clamped to the Logan 0–200 km/h scale")
require("GaugeProgressLayer" in source, "live speed progress remains separate from static numerals")
require("SPEED_LABELS = list(range(0, 201, 20))" in generator, "asset-baked speed scale is 0–200 in 20 km/h steps")
require("ROAD_TOP_Y = 468" in generator and "ROAD_FADE_END_Y = 512" in generator, "road ends below the horizon and fades in physically")
require("ROAD_TOP_HALF_WIDTH = 24" in generator and "ROAD_BOTTOM_HALF_WIDTH = 188" in generator, "road uses the narrower reference geometry")
require("no centre dashes" in generator.lower(), "generator documents that centre lane markings are forbidden")
require("RoadMotionLayer" not in generator, "asset generator does not add moving road segments")

require("RoadFadeLayer" not in source, "invented Compose road-fade overlay is removed")
require("VehicleContactLayer" not in source, "post-vehicle black oval shadow is removed")
require("ColorFilter.tint(roadEdge" not in source and "roadEdgeColor" not in source, "white road-edge asset is not accent-tinted")
require("ghost_single_original_road_sheen" in source and "ColorFilter.tint" not in source, "road sheen stays neutral and untinted")
require("CenterReadoutShield" in source, "needle is visually separated from the centre readout")
require("cy = 0.478f" in source, "RPM readout is below the centre separator")
require("PanelIcon(R.drawable.cockpit_coolant" in source, "approved coolant asset icon is used")
require("PanelIcon(R.drawable.cockpit_fuel_instant" in source, "approved instant-consumption asset icon is used")
require("PanelIcon(R.drawable.cockpit_fuel_average" in source, "approved average-consumption asset icon is used")
require("horizonWidth * (180f / 1846f)" in source, "horizon asset aspect ratio is preserved")

# Pixel-level checks for physical road fade and centre-weighted horizon glow.
edge_alpha = Image.open(res / "ghost_single_original_road_edges.webp").convert("RGBA").getchannel("A")
def row_max(y):
    return max(edge_alpha.getpixel((x, y)) for x in range(250, 751))
require(row_max(468) == 0, "road edge alpha is zero at the upper endpoint")
require(row_max(480) < row_max(500) < row_max(530), "road boundaries fade in progressively below the horizon")

horizon_alpha = Image.open(res / "ghost_single_original_horizon_green.webp").convert("RGBA").getchannel("A")
require(horizon_alpha.getpixel((923, 90)) > horizon_alpha.getpixel((600, 90)), "horizon glow is strongest at the centre")
require(horizon_alpha.getpixel((300, 90)) == 0 and horizon_alpha.getpixel((1546, 90)) == 0, "horizon has no full-width ruler line")

for forbidden in ["MENZİL", "VİTES", "DIŞ SICAKLIK", "HIZ SINIRI", "ADAS", "ECO", "COMFORT"]:
    require(forbidden not in source, f"unsupported field is absent: {forbidden}")

# Basic source integrity checks.
require(source.count("{") == source.count("}"), "Kotlin source braces are balanced")
require(source.count("(") == source.count(")"), "Kotlin source parentheses are balanced")
print("\nGhost Single Original reference-layout validation passed.")
