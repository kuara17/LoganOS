#!/usr/bin/env python3
"""Render Ghost Single Original assets for the Megane-reference layout.

The reference composition is preserved deliberately:
- near-circular 0–200 km/h centre gauge,
- compact single-lane road inside the lower gauge opening,
- thin horizon band,
- no centre lane markings or wide motorway geometry.

Only static artwork is baked into assets. Live speed, RPM, consumption and
coolant values remain Compose layers.
"""
from __future__ import annotations

import math
from pathlib import Path
from PIL import Image, ImageChops, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res/drawable-nodpi"
STAGE_W, STAGE_H = 1846, 852
GAUGE_W, GAUGE_H = 1000, 760
HORIZON_W, HORIZON_H = 1846, 180
SCALE = 2

SPEED_LABELS = list(range(0, 201, 20))
GAUGE_CENTER = (500, 390)
GAUGE_RADIUS = 350
GAUGE_START_DEG = 165.0
GAUGE_SWEEP_DEG = 210.0

# Compact road geometry copied from the reference composition: a narrow road
# that begins at the horizon and remains inside the centre gauge.
ROAD_TOP_Y = 468
ROAD_FADE_END_Y = 512
ROAD_BOTTOM_Y = 704
ROAD_TOP_HALF_WIDTH = 24
ROAD_BOTTOM_HALF_WIDTH = 188

FONT_REGULAR = "/usr/share/fonts/opentype/inter/InterDisplay-Regular.otf"
FONT_MEDIUM = "/usr/share/fonts/opentype/inter/InterDisplay-Medium.otf"
if not Path(FONT_REGULAR).exists():
    FONT_REGULAR = "/usr/share/fonts/truetype/lato/Lato-Regular.ttf"
if not Path(FONT_MEDIUM).exists():
    FONT_MEDIUM = "/usr/share/fonts/truetype/lato/Lato-Medium.ttf"


def sc(v: float) -> int:
    return int(round(v * SCALE))


def rgba(size: tuple[int, int]) -> Image.Image:
    return Image.new("RGBA", (size[0] * SCALE, size[1] * SCALE), (0, 0, 0, 0))


def font(size: int, medium: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(FONT_MEDIUM if medium else FONT_REGULAR, sc(size))


def line(draw: ImageDraw.ImageDraw, points, fill, width=1):
    flat = tuple(sc(v) for point in points for v in point)
    draw.line(flat, fill=fill, width=sc(width), joint="curve")


def point_on_gauge(radius: float, angle_deg: float) -> tuple[float, float]:
    a = math.radians(angle_deg)
    return (
        GAUGE_CENTER[0] + radius * math.cos(a),
        GAUGE_CENTER[1] + radius * math.sin(a),
    )


def render_gauge_shell() -> Image.Image:
    base = rgba((GAUGE_W, GAUGE_H))

    # Very restrained shell glow. The bright colour progress arc stays live.
    glow = rgba((GAUGE_W, GAUGE_H))
    gd = ImageDraw.Draw(glow)
    bbox = (
        sc(GAUGE_CENTER[0] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] - GAUGE_RADIUS),
        sc(GAUGE_CENTER[0] + GAUGE_RADIUS),
        sc(GAUGE_CENTER[1] + GAUGE_RADIUS),
    )
    gd.arc(
        bbox,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(103, 119, 151, 92),
        width=sc(11),
    )
    base.alpha_composite(glow.filter(ImageFilter.GaussianBlur(sc(7))))

    d = ImageDraw.Draw(base)
    d.arc(
        bbox,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(235, 239, 247, 235),
        width=sc(3),
    )

    inner_radius = GAUGE_RADIUS - 17
    inner_box = (
        sc(GAUGE_CENTER[0] - inner_radius),
        sc(GAUGE_CENTER[1] - inner_radius),
        sc(GAUGE_CENTER[0] + inner_radius),
        sc(GAUGE_CENTER[1] + inner_radius),
    )
    d.arc(
        inner_box,
        int(GAUGE_START_DEG),
        int(GAUGE_START_DEG + GAUGE_SWEEP_DEG),
        fill=(115, 127, 151, 145),
        width=sc(1),
    )

    # 0–200 scale: 20 km/h major, 10 km/h medium, 2 km/h minor.
    subdivisions = 100
    for i in range(subdivisions + 1):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * i / subdivisions
        if i % 10 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 7, GAUGE_RADIUS - 36, 4, 245
        elif i % 5 == 0:
            outer, inner, width, alpha = GAUGE_RADIUS - 8, GAUGE_RADIUS - 28, 3, 215
        else:
            outer, inner, width, alpha = GAUGE_RADIUS - 9, GAUGE_RADIUS - 18, 2, 160
        line(
            d,
            (point_on_gauge(inner, angle), point_on_gauge(outer, angle)),
            (235, 239, 247, alpha),
            width,
        )

    number_font = font(27, medium=True)
    label_radius = GAUGE_RADIUS - 73
    for idx, value in enumerate(SPEED_LABELS):
        angle = GAUGE_START_DEG + GAUGE_SWEEP_DEG * idx / (len(SPEED_LABELS) - 1)
        x, y = point_on_gauge(label_radius, angle)
        text = str(value)
        box = d.textbbox((0, 0), text, font=number_font)
        tw, th = box[2] - box[0], box[3] - box[1]
        d.text(
            (sc(x) - tw / 2, sc(y) - th / 2),
            text,
            font=number_font,
            fill=(239, 242, 249, 240),
        )

    # Thin centre separator, matching the reference's restrained OEM layout.
    sep = rgba((GAUGE_W, GAUGE_H))
    sd = ImageDraw.Draw(sep)
    sd.line((sc(356), sc(340), sc(644), sc(340)), fill=(105, 133, 188, 80), width=sc(4))
    base.alpha_composite(sep.filter(ImageFilter.GaussianBlur(sc(6))))
    d = ImageDraw.Draw(base)
    d.line((sc(372), sc(340), sc(628), sc(340)), fill=(128, 143, 174, 110), width=sc(1))

    return base.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def road_polygon_scaled():
    return [
        (sc(GAUGE_W / 2 - ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(GAUGE_W / 2 + ROAD_TOP_HALF_WIDTH), sc(ROAD_TOP_Y)),
        (sc(GAUGE_W / 2 + ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
        (sc(GAUGE_W / 2 - ROAD_BOTTOM_HALF_WIDTH), sc(ROAD_BOTTOM_Y)),
    ]


def road_fade_mask() -> Image.Image:
    """Road alpha is physically zero at the top and reaches full visibility below the horizon."""
    polygon = Image.new("L", (GAUGE_W * SCALE, GAUGE_H * SCALE), 0)
    ImageDraw.Draw(polygon).polygon(road_polygon_scaled(), fill=255)
    vertical = Image.new("L", polygon.size, 0)
    vd = ImageDraw.Draw(vertical)
    for y in range(sc(ROAD_TOP_Y), sc(ROAD_BOTTOM_Y) + 1):
        logical_y = y / SCALE
        if logical_y <= ROAD_TOP_Y:
            a = 0
        elif logical_y < ROAD_FADE_END_Y:
            t = (logical_y - ROAD_TOP_Y) / (ROAD_FADE_END_Y - ROAD_TOP_Y)
            # Smoothstep avoids a visible hard edge at the top of the road.
            t = t * t * (3.0 - 2.0 * t)
            a = int(255 * t)
        else:
            a = 255
        vd.line((0, y, GAUGE_W * SCALE, y), fill=a, width=1)
    return ImageChops.multiply(polygon, vertical)


def render_road_base() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    mask = road_fade_mask()
    gradient = rgba((GAUGE_W, GAUGE_H))
    gd = ImageDraw.Draw(gradient)
    for y in range(sc(ROAD_TOP_Y), sc(ROAD_BOTTOM_Y) + 1):
        t = (y / SCALE - ROAD_TOP_Y) / (ROAD_BOTTOM_Y - ROAD_TOP_Y)
        shade = int(12 + 12 * t)
        alpha = int(128 + 58 * t)
        gd.line((0, y, GAUGE_W * SCALE, y), fill=(shade, shade + 2, shade + 5, alpha), width=1)
    gradient.putalpha(ImageChops.multiply(gradient.getchannel("A"), mask))
    img.alpha_composite(gradient)
    return img.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_road_edges() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    left_top = (GAUGE_W / 2 - ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    right_top = (GAUGE_W / 2 + ROAD_TOP_HALF_WIDTH, ROAD_TOP_Y)
    left_bottom = (GAUGE_W / 2 - ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)
    right_bottom = (GAUGE_W / 2 + ROAD_BOTTOM_HALF_WIDTH, ROAD_BOTTOM_Y)

    # Exactly two fixed white boundaries: no centre dashes and no accent tint.
    line(d, (left_top, left_bottom), (248, 250, 255, 225), 3)
    line(d, (right_top, right_bottom), (248, 250, 255, 225), 3)
    img.putalpha(ImageChops.multiply(img.getchannel("A"), road_fade_mask()))
    return img.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_road_sheen() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    # Neutral sheen only; selected accent colour belongs exclusively to the horizon asset.
    d.polygon(
        [
            (sc(GAUGE_W / 2 - 15), sc(ROAD_TOP_Y + 4)),
            (sc(GAUGE_W / 2 + 15), sc(ROAD_TOP_Y + 4)),
            (sc(GAUGE_W / 2 + 98), sc(ROAD_BOTTOM_Y - 10)),
            (sc(GAUGE_W / 2 - 98), sc(ROAD_BOTTOM_Y - 10)),
        ],
        fill=(226, 232, 245, 34),
    )
    img = img.filter(ImageFilter.GaussianBlur(sc(17)))
    img.putalpha(ImageChops.multiply(img.getchannel("A"), road_fade_mask()))
    return img.resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_shadow_soft() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    d.ellipse((sc(415), sc(610), sc(585), sc(686)), fill=(0, 0, 0, 122))
    return img.filter(ImageFilter.GaussianBlur(sc(23))).resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_shadow_contact() -> Image.Image:
    img = rgba((GAUGE_W, GAUGE_H))
    d = ImageDraw.Draw(img)
    d.ellipse((sc(438), sc(644), sc(562), sc(674)), fill=(0, 0, 0, 190))
    return img.filter(ImageFilter.GaussianBlur(sc(7))).resize((GAUGE_W, GAUGE_H), Image.Resampling.LANCZOS)


def render_horizon(rgb: tuple[int, int, int]) -> Image.Image:
    img = rgba((HORIZON_W, HORIZON_H))
    cx = HORIZON_W / 2
    cy = HORIZON_H / 2

    # Central OEM-style light: strong near the vanishing point, rapidly fading sideways.
    glow = rgba((HORIZON_W, HORIZON_H))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((sc(cx - 310), sc(cy - 34), sc(cx + 310), sc(cy + 34)), fill=(*rgb, 150))
    gd.ellipse((sc(cx - 520), sc(cy - 18), sc(cx + 520), sc(cy + 18)), fill=(*rgb, 72))
    img.alpha_composite(glow.filter(ImageFilter.GaussianBlur(sc(18))))

    # No full-width ruler line. Build a one-pixel core whose alpha falls toward the sides.
    core = Image.new("RGBA", img.size, (0, 0, 0, 0))
    pixels = core.load()
    y = int(cy * SCALE)
    for x in range(sc(170), sc(HORIZON_W - 170)):
        logical_x = x / SCALE
        distance = abs(logical_x - cx)
        falloff = max(0.0, 1.0 - distance / 720.0)
        alpha = int(118 * (falloff ** 2.4))
        if alpha > 0:
            for yy in range(max(0, y - sc(1)), min(core.height, y + sc(1) + 1)):
                pixels[x, yy] = (*rgb, alpha)
    img.alpha_composite(core)
    return img.resize((HORIZON_W, HORIZON_H), Image.Resampling.LANCZOS)


def save_webp(image: Image.Image, name: str, *, lossless: bool = True) -> None:
    path = RES / name
    image.save(path, "WEBP", lossless=lossless, quality=94, method=6)
    print(f"wrote {path.relative_to(ROOT)} {image.size} {path.stat().st_size} bytes")


def fit_rgba(image: Image.Image, box: tuple[int, int]) -> Image.Image:
    copy = image.copy().convert("RGBA")
    copy.thumbnail(box, Image.Resampling.LANCZOS)
    return copy


def draw_centered(draw: ImageDraw.ImageDraw, text: str, x: float, y: float, fnt, fill):
    box = draw.textbbox((0, 0), text, font=fnt)
    draw.text((x - (box[2] - box[0]) / 2, y - (box[3] - box[1]) / 2), text, font=fnt, fill=fill)


def render_preview() -> Image.Image:
    """Settings preview follows the same white-road, centred-horizon and readout layout."""
    bg = Image.open(RES / "ghost_single_original_background.webp").convert("RGBA").resize((STAGE_W, STAGE_H), Image.Resampling.LANCZOS)

    cluster_w = 980
    cluster_h = round(cluster_w * GAUGE_H / GAUGE_W)
    cluster_x = (STAGE_W - cluster_w) // 2
    cluster_y = 8

    def cluster_asset(name: str):
        return Image.open(RES / name).convert("RGBA").resize((cluster_w, cluster_h), Image.Resampling.LANCZOS)

    horizon = Image.open(RES / "ghost_single_original_horizon_purple.webp").convert("RGBA")
    horizon_w = round(cluster_w * 1.25)
    horizon_h = round(horizon_w * HORIZON_H / HORIZON_W)
    horizon = horizon.resize((horizon_w, horizon_h), Image.Resampling.LANCZOS)
    bg.alpha_composite(horizon, ((STAGE_W - horizon_w) // 2, cluster_y + round(cluster_h * 0.505)))

    bg.alpha_composite(cluster_asset("ghost_single_original_road_base.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_road_sheen.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_road_edges.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_shadow_soft.webp"), (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_shadow_contact.webp"), (cluster_x, cluster_y))

    car = fit_rgba(Image.open(RES / "loganos_logan_rear_oem_cherry_red.webp"), (162, 180))
    bg.alpha_composite(car, ((STAGE_W - car.width) // 2, 505))

    progress = Image.new("RGBA", (cluster_w, cluster_h), (0, 0, 0, 0))
    pd = ImageDraw.Draw(progress)
    sx = cluster_w / GAUGE_W
    sy = cluster_h / GAUGE_H
    bbox = (
        (GAUGE_CENTER[0] - GAUGE_RADIUS) * sx,
        (GAUGE_CENTER[1] - GAUGE_RADIUS) * sy,
        (GAUGE_CENTER[0] + GAUGE_RADIUS) * sx,
        (GAUGE_CENTER[1] + GAUGE_RADIUS) * sy,
    )
    pd.arc(bbox, int(GAUGE_START_DEG), int(GAUGE_START_DEG + GAUGE_SWEEP_DEG * 88 / 200), fill=(155, 92, 255, 190), width=3)
    bg.alpha_composite(progress, (cluster_x, cluster_y))
    bg.alpha_composite(cluster_asset("ghost_single_original_gauge_shell.webp"), (cluster_x, cluster_y))

    # Thin preview needle under a dark readout shield.
    needle = Image.new("RGBA", (cluster_w, cluster_h), (0, 0, 0, 0))
    nd = ImageDraw.Draw(needle)
    ratio = 88 / 200
    a = math.radians(GAUGE_START_DEG + GAUGE_SWEEP_DEG * ratio)
    center = (GAUGE_CENTER[0] * sx, GAUGE_CENTER[1] * sy)
    tip = (center[0] + math.cos(a) * 285 * sx, center[1] + math.sin(a) * 285 * sx)
    nd.line((center, tip), fill=(247, 249, 255, 220), width=3)
    nd.ellipse((center[0]-6, center[1]-6, center[0]+6, center[1]+6), fill=(10, 12, 16, 245))
    bg.alpha_composite(needle, (cluster_x, cluster_y))

    d = ImageDraw.Draw(bg)
    d.ellipse((STAGE_W/2-124, 145, STAGE_W/2+124, 392), fill=(0, 0, 0, 25))
    d.ellipse((STAGE_W/2-92, 165, STAGE_W/2+92, 374), fill=(0, 0, 0, 55))
    regular = lambda size: ImageFont.truetype(FONT_REGULAR, size)
    medium = lambda size: ImageFont.truetype(FONT_MEDIUM, size)
    draw_centered(d, "88", STAGE_W / 2, 247, regular(72), (247, 249, 255, 255))
    draw_centered(d, "km/h", STAGE_W / 2, 302, medium(20), (183, 193, 208, 255))
    draw_centered(d, "2673 rpm", STAGE_W / 2, 370, medium(25), (235, 239, 247, 225))

    coolant = fit_rgba(Image.open(RES / "cockpit_coolant.webp"), (58, 58))
    instant = fit_rgba(Image.open(RES / "cockpit_fuel_instant.webp"), (62, 62))
    average = fit_rgba(Image.open(RES / "cockpit_fuel_average.webp"), (62, 62))
    bg.alpha_composite(coolant, (175, 198))
    bg.alpha_composite(instant, (165, 448))
    bg.alpha_composite(average, (STAGE_W - 410, 220))

    d = ImageDraw.Draw(bg)
    d.line((95, 430, 395, 430), fill=(86, 101, 130, 100), width=1)
    d.line((STAGE_W - 395, 500, STAGE_W - 95, 500), fill=(86, 101, 130, 100), width=1)
    draw_centered(d, "HARARET", 285, 225, medium(18), (183, 193, 208, 255))
    draw_centered(d, "59 °C", 285, 302, medium(34), (247, 249, 255, 255))
    draw_centered(d, "ANLIK", 275, 480, medium(18), (183, 193, 208, 255))
    draw_centered(d, "3.5", 245, 548, medium(40), (247, 249, 255, 255))
    draw_centered(d, "L/100 km", 245, 598, regular(17), (183, 193, 208, 255))
    draw_centered(d, "ORTALAMA", STAGE_W - 285, 252, medium(18), (183, 193, 208, 255))
    draw_centered(d, "5.1", STAGE_W - 275, 410, medium(48), (247, 249, 255, 255))
    draw_centered(d, "L/100 km", STAGE_W - 275, 470, regular(17), (183, 193, 208, 255))

    vignette = Image.open(RES / "ghost_single_original_vignette.webp").convert("RGBA").resize((STAGE_W, STAGE_H), Image.Resampling.LANCZOS)
    bg.alpha_composite(vignette)
    return bg.convert("RGB")


def main() -> None:
    RES.mkdir(parents=True, exist_ok=True)
    save_webp(render_gauge_shell(), "ghost_single_original_gauge_shell.webp")
    save_webp(render_road_base(), "ghost_single_original_road_base.webp")
    save_webp(render_road_edges(), "ghost_single_original_road_edges.webp")
    save_webp(render_road_sheen(), "ghost_single_original_road_sheen.webp")
    save_webp(render_shadow_soft(), "ghost_single_original_shadow_soft.webp")
    save_webp(render_shadow_contact(), "ghost_single_original_shadow_contact.webp")

    colours = {
        "purple": (155, 92, 255),
        "red": (255, 59, 48),
        "green": (46, 230, 107),
        "white": (241, 245, 255),
        "blue": (53, 149, 255),
        "yellow": (255, 193, 46),
    }
    for name, rgb in colours.items():
        save_webp(render_horizon(rgb), f"ghost_single_original_horizon_{name}.webp")

    save_webp(render_preview(), "ghost_single_original_preview.webp", lossless=False)


if __name__ == "__main__":
    main()
